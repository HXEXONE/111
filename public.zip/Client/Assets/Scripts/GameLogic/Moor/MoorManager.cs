﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;

public class MoorAwardItem//末日荒野奖励结构
{
    public uint uiType;
    public uint uiItemId;
    public uint uiNumber;
}

public class MoorManager : SingletonObject<MoorManager>
{
    public struct stSelfData//玩家自己数据结构
    {
        public WildMyInfo MyInfo;
    }
    public struct stEnemyData//敌人数据结构
    {
        public uint uiJobId;//职业id
        public PartnerSortItem partner;
        public WildMatcherInfo MatherInfo;
    }
    public List<WildMatcherBrief> WildMatherHistoryList { get; set; }//历史玩家数据
    public ePartnerType SelectPartnerType { get; set; }//选择伙伴类型
    public uint battleID { get; set; }//当前挑战的战场ID
    public stEnemyData StEnemyDataInfo { get; set; }//当前匹配到的对手的数据
    public stSelfData StSelfDataInfo { get; set; }//玩家自身数据


    public List<ShopElement> pvpShopList { get; set; }
    public int pvpRefreshTimes { get; set; }
    public delegate void MoorShopBuyFinished();
    public MoorShopBuyFinished moorBuyFinished;

    public bool m_bActivityTurn = false;
    public uint m_uiActivityTimes;


    public uint uiYieldActivity;    //收益多倍的活动id，没有活动为0
    public byte uiYeildRate;    //收益率，正常为1，有多倍时>1
    public List<SaoDangWild> vSaoDangWildList = new List<SaoDangWild>();
    public uint uiSaoDangMaxMapId;

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_WILD_BATTLE_PLAYER_DATA, onG2CAckWildBattlePlayerData, true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_RESTART_WILD_BATTLE, onG2CAckRestartBattle, true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_OPEN_WILD_BATTLE_BOX, onG2CAckOpenBattleBox, true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_WILD_MATCHERS_HISTORY, OnG2CWildMatchersHistory, true);

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_OPEN_MORISHOP, OnG2COpenMoriShopResult, true);//打开商店
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_REFRESH_MORISHOP, OnG2CRefreshMoriShopResult, true);//刷新商店货物
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_BUY_MORISHOP_ITEM, OnG2CBuyMoriShopResult, true);//购买商店货物

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_START_WILD, OnG2CAckStartWild, true);//回复末日荒野开始战斗

        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_START_WILD, OnG2CAckStartWild, true);//回复末日荒野开始战斗
         
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_SAO_DANG_WILD, OnG2CAckSaoDangWild, true);//回复末日荒野扫荡,
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_WILD_SAODANG_STATUS, OnG2CNotifyWildSaoDangStatus, false);//通知末日荒野扫荡状态
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_FINISH_WILD_BATTLE, OnG2CFinishWildBattle, true);//回复末日荒野扫荡,
        
    }

    #region 协议返回
    private void OnG2CFinishWildBattle(BinaryReader br)
    {
        G2CAckFinishWildBattle msg = new G2CAckFinishWildBattle();
        msg.Read(br);
        if ((EnumProtocolResult)msg.uiResult == EnumProtocolResult.EnumProtocolResult_Success)
        {
        }
        else
        {
            ResultErrorCode((ushort)msg.uiResult);
        }
    }
    private void OnG2CNotifyWildSaoDangStatus(BinaryReader br)
    {
        G2CNotifyWildSaoDangStatus msg = new G2CNotifyWildSaoDangStatus();
        msg.Read(br);
        uiSaoDangMaxMapId =  msg.uiSaoDangMaxMapId;
        SingletonObject<MoorMediator>.GetInst().SetSaoDangState();
    }
    private void OnG2CAckSaoDangWild(BinaryReader br)//回复末日荒野扫荡,
    {
        G2CAckSaoDangWild msg = new G2CAckSaoDangWild();
        msg.Read(br);
        if ((EnumProtocolResult)msg.uiResult == EnumProtocolResult.EnumProtocolResult_Success)
        {
            uiYieldActivity = msg.uiYieldActivity;
            uiYeildRate = msg.uiYeildRate;
            vSaoDangWildList = msg.vList;
            
            SingletonObject<MoorSweepMediator>.GetInst().Open(delegate()
            {
                SingletonObject<MoorSweepMediator>.GetInst().getDropItem(vSaoDangWildList);
                OnRequestHistory();
            });
        }
        else
        {
            ResultErrorCode((ushort)msg.uiResult);
        }
    }

    private void OnG2CAckStartWild(BinaryReader br)//回复末日荒野开始战斗
    {
        G2CAckStartWild msg = new G2CAckStartWild();
        msg.Read(br);
        if ((EnumBattleResult)msg.uiResult == EnumBattleResult.EnumBattleResult_SUCCESS)
        {
            SingletonObject<MoorReadyMediator>.GetInst().EnterBatteScene();
        }
        else if ((EnumBattleResult)msg.uiResult == EnumBattleResult.EnumBattleResult_MercPartnerCanNotUse)
        {
            //不能使用佣兵
            MyLog.LogError("Can not use mercenay!");
        }
        else
        {
            MyLog.LogError("Error Code:" + msg.uiResult);
        }
    }

    private void OnG2CBuyMoriShopResult(BinaryReader br)//末日荒野商店购买返回
    {
        G2CBuyMoriShopResult result = new G2CBuyMoriShopResult();
        result.Read(br);
        MoorShopMediator pvpShopMediator = SingletonObject<MoorShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            //购买成功，刷新该item UI界面，变量重置，锁住用户，不让其购买
            string tips = Common.GetText(9949004);
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.green);

            pvpShopList = new List<ShopElement>();
            pvpShopList.Clear();
            pvpShopList = result.elements;
            int count = pvpShopList.Count;
            for (int i = 0; i < count; i++)
            {
                if (result.elements[i].uiItemNum == 0)
                {
                    pvpShopMediator.IsAllowBuy[i] = false;
                }
                else
                {
                    pvpShopMediator.IsAllowBuy[i] = true;
                }
            }
            if (moorBuyFinished != null)
                moorBuyFinished();

        }
        else
        {
            ResultErrorCode(result.uiResult);

        }
    }

    private void OnG2CRefreshMoriShopResult(BinaryReader br)//刷新返回
    {
        G2CRefreshMoriShopResult result = new G2CRefreshMoriShopResult();
        result.Read(br);
        MoorShopMediator pvpShopMediator = SingletonObject<MoorShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            //刷新成功，//重置购买标示，重新填充界面
            pvpRefreshTimes = result.uiTimes;
            pvpShopList = new List<ShopElement>();
            pvpShopList.Clear();
            pvpShopList = result.elements;
            int count = pvpShopList.Count;
            for (int i = 0; i < count; i++)
            {
                pvpShopMediator.IsAllowBuy[i] = true;
            }
            pvpShopMediator.ReSetPosition();
            pvpShopMediator.InitItem();
        }
        else
        {
            ResultErrorCode(result.uiResult);
            //SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("ErrorCode:" + result.uiResult.ToString());
        }
    }

    private void OnG2COpenMoriShopResult(BinaryReader br)//打开商店
    {
        G2COpenMoriShopResult result = new G2COpenMoriShopResult();
        result.Read(br);
        MoorShopMediator pvpShopMediator = SingletonObject<MoorShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            int count = result.elements.Count;
            pvpShopMediator.IsAllowBuy = new bool[count];
            for (int i = 0; i < count; i++)
            {
                if (result.elements[i].uiItemNum == 0)
                {
                    pvpShopMediator.IsAllowBuy[i] = false;
                }
                else
                {
                    pvpShopMediator.IsAllowBuy[i] = true;
                }
            }
            //打开UI，初始变量数据，填充界面
            pvpRefreshTimes = result.uiTimes;
            pvpShopList = new List<ShopElement>(result.elements);
            if (pvpShopMediator.IsOpen)
                pvpShopMediator.InitItem();
        }
        else
        {
            //SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("ErrorCode:" + result.uiResult.ToString());
            ResultErrorCode(result.uiResult);
        }
    }

    private void OnG2CWildMatchersHistory(BinaryReader br)//返回历史玩家列表
    {
        G2CWildMatchersHistory result = new G2CWildMatchersHistory();
        result.Read(br);
        if (result.BriefList != null)
        {
            WildMatherHistoryList = new List<WildMatcherBrief>(result.BriefList);
            uiSaoDangMaxMapId = result.uiSaoDangMaxMapId;
            SingletonObject<MoorMediator>.GetInst().InitItem();
        }
        else
        {
            MyLog.LogError("history list from game server is null!");
        }
    }

    private void onG2CAckWildBattlePlayerData(BinaryReader br)//匹配对手返回
    {
        G2CAckWildBattlePlayerData msg = new G2CAckWildBattlePlayerData();
        msg.Read(br);
        if ((EnumEnterWildBattle)msg.uiResult == EnumEnterWildBattle.EnumEnterWildBattle_Success || 
            (EnumEnterWildBattle)msg.uiResult == EnumEnterWildBattle.EnumEnterWildBattle_NoMatched)
        {
            //敌人数据
            Avatar pAvatar = SingletonObject<Avatar>.GetInst();
            EnemyAvatar pEnemyAvatar = SingletonObject<EnemyAvatar>.GetInst();

            stEnemyData enemy = new stEnemyData();
            enemy.MatherInfo = msg.MatcherInfo;

            pEnemyAvatar.UseRide = !MyConvert_Convert.ToBoolean(enemy.MatherInfo.bCanUseMount);
            pEnemyAvatar.UseFly = !MyConvert_Convert.ToBoolean(enemy.MatherInfo.bCanUsePet);
            enemy.uiJobId = DEFINE.JOB_START_ID + uint.Parse(enemy.MatherInfo.uiPlayerID.ToString().Substring(enemy.MatherInfo.uiPlayerID.ToString().Length - 1, 1));

            //检查以下资源是否存在目前资源包中,如果不存在则找替代资源.
            enemy.MatherInfo.uiClothesId = UIManager.GetInst().CheckResourc(enemy.MatherInfo.uiClothesId, enemy.uiJobId, eAssetMapCheckType.Cloth);
            enemy.MatherInfo.uiWeaponId = UIManager.GetInst().CheckResourc(enemy.MatherInfo.uiWeaponId, enemy.uiJobId, eAssetMapCheckType.Weapon);
            enemy.MatherInfo.uiMountId = UIManager.GetInst().CheckResourc((uint)enemy.MatherInfo.uiMountId, enemy.uiJobId, eAssetMapCheckType.Mount);
            enemy.MatherInfo.uiPetID = UIManager.GetInst().CheckResourc((uint)enemy.MatherInfo.uiPetID, enemy.uiJobId, eAssetMapCheckType.Pet);
            MyLog.Log("Game Server Send Partner ID:" + msg.MatcherInfo.partner.uiPartnerId);
            PartnerMsgInfo newpartner = msg.MatcherInfo.partner;
            if (newpartner != null)
                newpartner.uiPartnerId = UIManager.GetInst().CheckResourc(newpartner.uiPartnerId, enemy.uiJobId, eAssetMapCheckType.Partner);
            MyLog.Log("After Partner ID:" + newpartner.uiPartnerId);
            enemy.partner = new PartnerSortItem(newpartner);
            enemy.partner.info.vecSkillList = Common.GetReplacePartnerSkillList(enemy.partner.info.vecSkillList, enemy.partner.loader);
            enemy.partner.PartnerHpPre = msg.MatcherInfo.fPartnerHpPer;
            StEnemyDataInfo = enemy;



            //自身数据
            stSelfData self = new stSelfData();
            self.MyInfo = msg.MyInfo;
            StSelfDataInfo = self;
            battleID = SingletonObject<CPlayer>.GetInst().GetPlayerInfo().uiWildBattleID;

            pAvatar.UseRide = false; //不需要从服务端获取
            pAvatar.UseFly = false;//不需要从服务端获取

            //MyLog.Log("battleID:" + battleID);
            UsualContent loader = HolderManager.m_UsualHolder.GetStaticInfo(DEFINE.DEFAULT_MOOR_USUAL_ID);
            if (battleID == 0 && loader != null)
                battleID = (uint)loader.Mapid[0];

            if (!SingletonObject<MoorReadyMediator>.GetInst().IsOpen)
                SingletonObject<MoorReadyMediator>.GetInst().ReadyStartBattle(battleID);

        }
        else
        {
            ResultErrorCode((ushort)msg.uiResult);
        }
    }


    private void onG2CAckRestartBattle(BinaryReader br)//刷新返回
    {
        G2CAckRestartBattle msg = new G2CAckRestartBattle();
        msg.Read(br);
        if ((EnumRestartBattle)msg.uiResult == EnumRestartBattle.EnumRestartBattle_Success)
        {
            //刷新界面
            CPlayer cplayer = SingletonObject<CPlayer>.GetInst();
            stPlayerInfo playerinfo = cplayer.GetPlayerInfo();
            playerinfo.uiWildBattleID = msg.uiWildBattleID;
            playerinfo.bIsFinishBattle = msg.bIsFinishBattle;
            playerinfo.uiRestartBattleTimes = msg.uiRestartBattleTimes;
            cplayer.SetInfoBack(playerinfo);
            SingletonObject<MoorMediator>.GetInst().RefreshMediator(true);
            SingletonObject<MoorMediator>.GetInst().ShowRemainNumber(msg.uiRestartBattleTimes);
        }
        else
        {
            ResultErrorCode(msg.uiResult);
        }
    }

    public List<HUDAwardItem> awardlist = new List<HUDAwardItem>();
    private void onG2CAckOpenBattleBox(BinaryReader br)//开宝箱返回
    {
        G2CAckOpenBattleBox msg = new G2CAckOpenBattleBox();
        msg.Read(br);
        if (msg.uiResult == (ushort)EnumOpenBattleBox.EnumOpenBattleBox_Success)
        {
            if (msg.uiYieldActivity == DEFINE.MOOR_ACTIVITY_ID)
            {
                m_bActivityTurn = true;
                m_uiActivityTimes = msg.uiYeildRate;
            }
            else
            {
                m_bActivityTurn = false;
                m_uiActivityTimes = msg.uiYeildRate;
            }
            List<MoorAwardItem> m_moorAwardList = new List<MoorAwardItem>();
            //显示奖励
            CPlayer cplayer = SingletonObject<CPlayer>.GetInst();
            stPlayerInfo playerinfo = cplayer.GetPlayerInfo();
            playerinfo.uiWildBattleID = msg.uiWildBattleID;
            playerinfo.bIsFinishBattle = msg.bIsFinishBattle;
            cplayer.SetInfoBack(playerinfo);
            MoorAwardItem item2 = new MoorAwardItem();
            item2.uiType = (ushort)EnumBoxItemType.BoxItemType_Item;
            item2.uiItemId = DEFINE.ITEM_GOLD;
            item2.uiNumber = msg.uiExp;
            m_moorAwardList.Add(item2);
            BoxItemList ItemList = msg.ItemList;
            //MyLog.Log("award count :"+msg.ItemList.Count);
            for (int i = 0, count = ItemList.Count; i < count; i++)
            {

                MoorAwardItem item = new MoorAwardItem();
                item.uiType = ItemList[i].uiItemType;
                item.uiItemId = ItemList[i].uiItemId;
                item.uiNumber = ItemList[i].uiItemCount;
                //MyLog.Log("item.uiType:" + item.uiType + "======item.uiItemId" + item.uiItemId + "================" + item.uiNumber);
                m_moorAwardList.Add(item);
            }
            uint m_uiTimes = 0;
            ShopManager.GetInst().IsStartActivity(ActivityType.Moor, ref m_uiTimes);
            awardlist.Clear();
            for (int i = 0, count = m_moorAwardList.Count; i < count; i++)
            {
                MoorAwardItem item = m_moorAwardList[i];

                HUDAwardItem award = new HUDAwardItem();
                award.number = item.uiNumber;
                switch (item.uiType)
                {
                    case (ushort)EnumBoxItemType.BoxItemType_Item:
                        if (item.uiItemId != DEFINE.ITEM_GOLD)
                        {
                            if (item.uiItemId.ToString().Length == 4)
                            {
                                PartnerBoxContent boxLoader = HolderManager.m_PartnerBoxHolder.GetStaticInfo(item.uiItemId);
                                if (boxLoader != null)
                                {
                                    award.id = (uint)boxLoader.ItemArgs[0];
                                    award.number = (uint)boxLoader.ItemArgs[1] * ((m_uiTimes == 0) ? 1 : m_uiTimes);
                                }
                            }
                            else
                            {
                                if (item.uiItemId.ToString().Length == 6)
                                {
                                    ItemBoxContent boxLoader = HolderManager.m_ItemBoxHolder.GetStaticInfo(item.uiItemId);
                                    if (boxLoader != null)
                                    {
                                        award.id = (uint)boxLoader.ItemArgs[0];
                                        award.number = (uint)boxLoader.ItemArgs[1] * ((m_uiTimes == 0) ? 1 : m_uiTimes);
                                    }
                                }
                                else
                                {
                                    award.id = item.uiItemId;
                                    award.number = item.uiNumber * ((m_uiTimes == 0) ? 1 : m_uiTimes);
                                }
                            }
                        }
                        else
                        {
                            award.id = DEFINE.ITEM_GOLD;
                            award.number = item.uiNumber * ((m_uiTimes == 0) ? 1 : m_uiTimes);
                        }
                        awardlist.Add(award);
                        break;
                    case (ushort)EnumBoxItemType.BoxItemType_Equip:
                        award.id = item.uiItemId;
                        award.number = item.uiNumber * ((m_uiTimes == 0) ? 1 : m_uiTimes);
                        awardlist.Add(award);
                        break;
                    case (ushort)EnumBoxItemType.BoxItemType_Partner:
                        if (item.uiItemId.ToString().Length == 4)
                        {
                            PartnerBoxContent partnerBoxLoader = HolderManager.m_PartnerBoxHolder.GetStaticInfo(item.uiItemId);
                            if (partnerBoxLoader != null) award.id = (uint)partnerBoxLoader.Partnerid;
                            award.number = 1;
                            awardlist.Add(award);

                            if (m_uiTimes != 0)
                            {
                                HUDAwardItem award2 = new HUDAwardItem();
                                if (partnerBoxLoader != null)
                                {
                                    award2.id = (uint)partnerBoxLoader.ItemArgs[0];
                                    award2.number = partnerBoxLoader.ItemArgs[1] * (m_uiTimes - 1);
                                }
                                awardlist.Add(award2);
                            }
                        }
                        break;
                }
            }
            //for (int i = 0; i < awardlist.Count; i++)
            //{
            //    MyLog.Log("id:" + awardlist[i] + "number:" + awardlist[i].number);
            //}
            //SingletonObject<HUDAwardMediator>.GetInst().ShowAward(awardlist);

            SingletonObject<MoorMediator>.GetInst().InitAwardItem(m_moorAwardList);
        }
        else
        {
            ResultErrorCode(msg.uiResult);
        }
    }

    private void ResultErrorCode(ushort errorcode)
    {
        string tips = string.Empty;
        switch (errorcode)
        {
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_VigorNotEnough:
                tips = Common.GetText(9954007);
                break;
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_LevelNotEnough:
                tips = Common.GetText(9100046);
                break;
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_NotOpen:
                tips = Common.GetText(9954008);
                break;
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_CantSkip:
                tips = Common.GetText(9954009);
                break;
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_AlreadyChllenged:
                tips = Common.GetText(9954010);
                break;
            case (ushort)EnumEnterWildBattle.EnumEnterWildBattle_BattleNotExist:
                tips = Common.GetText(9954011);
                break;
            case (ushort)EnumOpenBattleBox.EnumOpenBattleBox_NotFinishBattle://没有完成此战场
                tips = Common.GetText(9954012);
                break;
            case (ushort)EnumRestartBattle.EnumRestartBattle_NotEnoughTimes:
                tips = Common.GetText(9954013);
                break;
            case (ushort)EnumPvpShopErr.EnumPvpShopErr_NotHaveThisItem:
                tips = Common.GetText(9100035);
                break;
            case (ushort)EnumPvpShopErr.EnumPvpShopErr_NotEnoughItem:
                tips = Common.GetText(9100049);
                break;
            case (ushort)EnumPvpShopErr.EnumPvpShopErr_NotOpen:
                tips = Common.GetText(9954008);
                break;
            case (ushort)EnumPvpShopErr.EnumPvpShopErr_NotEnoughHonor:
                tips = Common.GetText(9954004);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_WildSaoDang_VipLevelNotEnough:
                tips = Common.GetText(9954022);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_WildSaoDang_NeedRestartTwice:
                tips = Common.GetText(9954023);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_WildSaoDang_NoBattleSaoDang:
                tips = Common.GetText(9954024);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_WildSaoDang_CanNotSaoDang:
                tips = Common.GetText(9954029);
                break;
            default:
                tips = "Unknow error,Error Code:" + errorcode;
                break;
        }
        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(tips);
    }
    #endregion

    #region 协议请求

    public void OnRequestSaoDang()//请求扫荡末日荒野
    {
        NullStruct nullStruct = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_SAO_DANG_WILD, (ushort)ProCG.GAME_ACK_SAO_DANG_WILD, nullStruct);
    }

    public void OnRequestHistory()  //请求历史对手信息
    {
        NullStruct nullStruct = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_WILD_MATCHERS_HISTORY, (ushort)ProCG.GAME_ACK_WILD_MATCHERS_HISTORY, nullStruct);
    }

    /// <summary>
    /// 请求挑战
    /// </summary>
    /// <param name="battleid">挑战的ID</param>
    public void OnC2GChallengeWildBattle(uint battleid)
    {
        C2GChallengeWildBattle msg = new C2GChallengeWildBattle();
        msg.uiBattleID = battleid;
        battleID = battleid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_CHALLENGE_WILD_BATTLE, (ushort)ProCG.GAME_ACK_CLIENT_WILD_BATTLE_PLAYER_DATA, msg);
    }

    /// <summary>
    /// 通知服务端战斗结果
    /// </summary>
    /// <param name="battleid">战场ID</param>
    /// <param name="flag">胜利标志：0失败，1胜利</param>
    /// <param name="enemyRoleHpPer">敌人主角血量百分比</param>
    /// <param name="enemyPartnerHpPer">敌人伙伴血量百分比</param>
    /// <param name="selfRoleHpPer">自己英雄主角血量百分比</param>
    /// <param name="partnerHpList">自己伙伴血量百分(受影响的伙伴都加入到这个列表)</param>
    /// <param name="canusepet">是否可以使用宠物,是1,否0 敌方</param>
    /// <param name="canusemount">是否可以使用坐骑,同上 敌方 </param>
    public void OnC2GFinishWildBattle(uint battleid, ushort flag)
    {
        Avatar pAvatar = SingletonObject<Avatar>.GetInst();
        EnemyAvatar pEnemyAvatar = SingletonObject<EnemyAvatar>.GetInst();

        C2GFinishWildBattle msg = new C2GFinishWildBattle();
        msg.uiBattleID = battleid;
        msg.bSuccessed = flag;
        msg.fMactherRoleHpPer = pEnemyAvatar.AvatarLifePercent;    //对手主角当前血量占比[0.0,1.0]
        msg.fMactherPartnerHpPer = pEnemyAvatar.PartnerLifePercent;    //对手伙伴当前血量占比[0.0,1.0]


        msg.fRoleHpPer = flag != 0 ? pAvatar.AvatarLifePercent : 0f;    //自己主角当前血量占比[0.0,1.0]

        msg.bMactherCanUseMount = MyConvert_Convert.ToByte(!pEnemyAvatar.UseRide);
        msg.bMactherCanUsePet = MyConvert_Convert.ToByte(!pEnemyAvatar.UseFly);

        msg.bMeCanUseMount = MyConvert_Convert.ToByte(!pAvatar.UseRide);
        msg.bMeCanUsePet = MyConvert_Convert.ToByte(!pAvatar.UseFly);

        WildPartnerHpList templist = new WildPartnerHpList();
        for (int i = 0, count = pAvatar.PartnerList.Count; i < count; i++)
        {
            WildPartnerHp info = new WildPartnerHp();
            //如果是佣兵的话,则传递佣兵所属人的玩家id,非佣兵则为0
            if (pAvatar.PartnerList[i].PartenrSortItem.bIsMercenary)
            {
                info.uiMasterID = pAvatar.PartnerList[i].PartenrSortItem.uiMasterID;
                //如果佣兵已经死亡则本地剔除存储记录
                if (pAvatar.PartnerList[i].LifePercent <= 0)
                {
                    PartnerManager.GetInst().SaveTempMercenay(eBattleType.Wasteland, null);
                    PartnerManager.GetInst().ClearMercenay(eBattleType.Wasteland, true);
                }
                else
                {
                    PartnerSortItem item = pAvatar.PartnerList[i].PartenrSortItem;
                    item.PartnerHpPre = pAvatar.PartnerList[i].LifePercent;
                    PartnerManager.GetInst().SaveTempMercenay(eBattleType.Wasteland, item);
                }
            }
            info.fHpPer = flag != 0 ? pAvatar.PartnerList[i].LifePercent : 0f;
            info.uiPartnerID = (uint)pAvatar.PartnerList[i].PartnerLoader.Key;
            templist.Add(info);
        }
        msg.PartnerHpList = templist;    //自己伙伴当前血量占比列表
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_FINISH_WILD_BATTLE,(ushort)ProCG.GAME_ACK_FINISH_WILD_BATTLE ,msg);
    }

    /// <summary>
    /// 刷新挑战纪录
    /// </summary>
    public void OnRefreshChanglle()
    {
        NullStruct nullStruct = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_RESTART_WILD_BATTLE, (ushort)ProCG.GAME_ACK_RESTART_WILD_BATTLE, nullStruct);
    }

    public void OnOpenBox()
    {
        NullStruct nullStruct = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_OPEN_WILD_BATTLE_BOX, (ushort)ProCG.GAME_ACK_OPEN_WILD_BATTLE_BOX, nullStruct);
    }




    /// <summary>
    /// 打开moor shop
    /// </summary>
    /// <param name="playerid"></param>
    public void OnC2GOpenPvpShop(ulong playerid)
    {
        if (playerid == 0)
        {
            MyLog.Log("playerid is zero! can not open pvp shop!");
            return;
        }
        C2GOpenMoriShop msg = new C2GOpenMoriShop();
        msg.uiPlayerid = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_OPEN_MORISHOP, (ushort)ProCG.GAME_ACK_OPEN_MORISHOP, msg);
    }


    /// <summary>
    /// 刷新moor商店货物请求
    /// </summary>
    /// <param name="playerid"></param>
    public void OnC2GRefreshPvpShop(ulong playerid)
    {
        if (playerid == 0)
        {
            MyLog.LogError("playerid is" + playerid);
            return;
        }
        C2GRefreshMoriShop msg = new C2GRefreshMoriShop();
        msg.uiPlayerid = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_REFRESH_MORISHOP, (ushort)ProCG.GAME_ACK_REFRESH_MORISHOP, msg);
    }


    /// <summary>
    /// 购买末日荒野商店商店货物
    /// </summary>
    /// <param name="playerid">玩家自身ID</param>
    /// <param name="itemid">货物id</param>
    /// <param name="number">数量</param>
    public void OnC2GBuyPvpShop(ulong playerid, ushort index, uint itemid, uint number)
    {
        if (playerid == 0)
        {
            MyLog.LogError("playerid is" + playerid);
            return;
        }
        C2GBuyMoriShop msg = new C2GBuyMoriShop();
        msg.uiPlayerid = playerid;
        msg.uiIndex = index;
        msg.uiItemID = itemid;
        msg.uiItemNum = number;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_BUY_MORISHOP_ITEM, (ushort)ProCG.GAME_ACK_BUY_MORISHOP_ITEM, msg);
    }


    public void OnC2GReqStartWild(ulong uiMercMasterID, uint partnerid)
    {
        C2GReqStartWild msg = new C2GReqStartWild();
        msg.uiMercMasterID = uiMercMasterID;
        msg.uiMercPartnerID = partnerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_START_WILD, (ushort)ProCG.GAME_ACK_START_WILD, msg);
    }
    #endregion
}
