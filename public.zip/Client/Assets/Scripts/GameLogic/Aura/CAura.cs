﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//光环类
public class CAura 
{
    private List<CBaseNpc> m_effecList = new List<CBaseNpc>();//被光环作用的npclist

    private AuraContent m_pAuraLoader;
    private AttrContent m_pAttrLoader; //Attribute 读表loader
    private CBaseNpc m_pNpc;

    private Timer m_pDurationTimer; //
    private CAuraManger m_pAuraMgr;

    private float m_fRange; //范围
    private float m_fDuration; //剩余时间    
    private uint m_particleIndex;
 

    private CSkillupInfo m_pSkillUpInfo = null;
    private float m_fDragonPromotion = 0f;

    public CAura(uint uiAuraID, CBaseNpc pNpc, CAuraManger auraMgr, CSkillupInfo pSkillUpInfo = null, float dragonPromotion = 0f) 
    {
        AuraContent pAura = HolderManager.m_AuraHolder.GetStaticInfo(uiAuraID);
        if ( null == pAura )
        {
            MyLog.LogError(" Error ! can not find auraID : " + uiAuraID + " in AuraContent.");
            return;
        }

        m_pAuraLoader = pAura;
        m_pNpc = pNpc;
        m_pAuraMgr = auraMgr;
        m_pSkillUpInfo = pSkillUpInfo;
        m_fDragonPromotion = dragonPromotion;
//         AttrContent pAttrLoader = HolderManager.m_AttrHolder.GetStaticInfo(m_pAuraLoader.GetAttributeID());
//         if (null == pAttrLoader) return;
// 
//         m_pAttrLoader = pAttrLoader;
        //m_pNpc.RangeTrigger = Mathf.Max(m_pAuraLoader.GetAuraRange(), m_pNpc.RangeTrigger);

        //施法者显示特效
        uint uiEffectID = (uint)m_pAuraLoader.SponsorParticleID;
        if (uiEffectID != 0)
        {
            m_particleIndex = m_pNpc.CreateParticle(uiEffectID);
        }

        float duration = m_pAuraLoader.Duration;
        if ( duration != 0 )
        {
            m_pDurationTimer = new Timer();
            m_pDurationTimer.SetTimer(duration);
        }

        m_fRange = m_pAuraLoader.AuraRange;

    }


    //光环读表id
    public uint AuraLoaderKey
    {
        get { return (uint)m_pAuraLoader.Key; }
    }

    //buff表ID
    public uint BuffID
    {
        get { return (uint)m_pAuraLoader.BuffID; }
    }

    //重置时间
    public void ResetTime()
    {
        m_fDuration = m_pAuraLoader.Duration;
    }

    //持续时间
    public float Duration
    {
        get 
        {
            return m_fDuration;
        }
        set
        {

        }
    }

    public void Update() 
    {
        RangeCheck();

        if (null != m_pDurationTimer)
        {
            if (m_pDurationTimer.IsExpired(false))
            {
                m_pAuraMgr.DelAura((uint)m_pAuraLoader.Key);
            }
        }
        
    }

    //范围检测
    private void RangeCheck()
    {                
        List<CBaseNpc> rangeNpcList = m_pNpc.GetRangeNpcList();
        if (rangeNpcList.Count > 0)
        {
            //foreach (CBaseNpc pNpc in m_pNpc.BattleScene.GetNpcDict().Values)
            foreach (CBaseNpc pNpc in rangeNpcList)
            {
                float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), pNpc.GetPosition());
                //范围
                if (distance <= m_pAuraLoader.AuraRange)
                {
                    //作用对象判断
                    if (CBaseNpc.AffectResult((eAffectType)m_pAuraLoader.AffectType, (eAffectEffect)m_pAuraLoader.AffectEffect, m_pNpc, pNpc, eEffectRangeType.HurtType, eSkillAtkType.GroundAirAtk, m_pAuraLoader.LockList))
                    {
                        //npc进入光环
                        pNpc.EnterAura(this, m_pSkillUpInfo,m_fDragonPromotion);
                    }
                }
                else
                {
                    //离开光环
                    pNpc.LeaverAura(this);
                }

            }
        }
    }

    public void Release() 
    {
//         BaseNpcTargetTrigger bntt = m_pNpc.GetTransform().GetComponent<BaseNpcTargetTrigger>();
//         if (bntt != null)
//         {
//             bntt.Radius = 10f;
//         }

        foreach (CBaseNpc pNpc in m_pNpc.CurrBattleScene.GetNpcDict().Values)
        {
            pNpc.LeaverAura(this);
        }        

        CParticleManager.GetInst().AddDestroyParticle(m_particleIndex);
    }
	
}
