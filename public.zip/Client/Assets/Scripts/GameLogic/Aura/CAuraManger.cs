﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//光环管理器
public class CAuraManger
{
    private CBaseNpc m_pNpc;

    private Dictionary<uint, CAura> m_auraDict = new Dictionary<uint, CAura>();
    private List<uint> m_delList = new List<uint>();

    public CAuraManger(CBaseNpc pNpc)
    {
        m_pNpc = pNpc;
    }

    public void AddAura(uint uiAuraID, CSkillupInfo pSkillUpLoader = null, float dragonPromotion = 0f) 
    {
        if (!m_auraDict.ContainsKey(uiAuraID))
        {
            CAura aura = new CAura(uiAuraID, m_pNpc, this, pSkillUpLoader, dragonPromotion);
            m_auraDict.Add(uiAuraID, aura);
        }                
    }

    public CAura GetAura(uint uiAuraID) 
    {
        CAura aura = null;
        m_auraDict.TryGetValue(uiAuraID, out aura);

        return aura;
    }

    public void DelAura(uint uiAuraID)
    {
        m_delList.Add(uiAuraID);
    }

    public void Release() 
    {
        if (m_auraDict.Count > 0)
        {
            foreach (CAura pAura in m_auraDict.Values)
            {
                DelAura(pAura.AuraLoaderKey);
            }

        }
    }

    public void Update() 
    {
        if (m_auraDict.Count > 0)
        {
            foreach (KeyValuePair<uint, CAura> kvp in m_auraDict)
            {
                if (null != kvp.Value)
                {
                    kvp.Value.Update();
                }
            }
        }
        
        int count = m_delList.Count;

        for (int i = 0; i < count; ++i)
        {
            uint auraID =  m_delList[i];
            if (m_auraDict.ContainsKey(auraID))
            {
                CAura aura = m_auraDict[auraID];
                aura.Release();

                m_auraDict.Remove(auraID);
            }            
        }

        if (count > 0)
        {
            m_delList.Clear();
        }        
    }

}
