using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class NpcAI
{
    private BaseAIContent m_baseAIInfo;
    private List<CExtraEvent> m_extraList = new List<CExtraEvent>();

    private CBaseNpc m_pNpc;

    private eMonsterNature m_monsterBehaviour;

    private int m_waypointIndex = 1;
    public int WaypointIndex
    {
        get { return m_waypointIndex; }
    }
    private int m_weaknessTotalHp;//进入虚弱累计的HP

    private Timer m_aiSkillTimer;

    public NpcAI(CBaseNpc pNpc)
    {
        m_pNpc = pNpc;
        m_weaknessTotalHp = 0;
    }

    public void SetSkill(Dictionary<int, CSkillupInfo> skillDict)
    {
        foreach (KeyValuePair<int, CSkillupInfo> kvp in skillDict)
        {
            m_pNpc.AddSkill((uint)kvp.Key,kvp.Value, 0);
        }
        m_pNpc.CountAttackRange();
    }

    public void SetAI(uint uiBaseAIID, List<int> extraList, Dictionary<int, CSkillupInfo> skillDict)
    {
        BaseAIContent baseAIInfo = HolderManager.m_BaseAIHolder.GetStaticInfo(uiBaseAIID);
        if ( null == baseAIInfo )
        {
            return;
        }

        m_baseAIInfo = baseAIInfo;
        m_monsterBehaviour = (eMonsterNature)m_baseAIInfo.Behavior;

        if (extraList != null)
        {
            for (int i = 0, count = extraList.Count; i < count; ++i)
            {
                CExtraEvent pExtraEvent = new CExtraEvent(m_pNpc, (uint)extraList[i]);
                m_extraList.Add(pExtraEvent);
            }
        }

        SetSkill(skillDict);

        m_aiSkillTimer = new Timer();
        m_aiSkillTimer.SetTimer(m_baseAIInfo.SkillInterval);
        m_aiSkillTimer.ExpireNow();
    }

    public void AddAI(List<int> aiList)
    {
        if (aiList != null)
        {
            for (int i = 0, count = aiList.Count; i < count; ++i)
            {
                CExtraEvent pExtraEvent = new CExtraEvent(m_pNpc, (uint)aiList[i]);
                m_extraList.Add(pExtraEvent);
            }
        }

      
    }

    public void AddSkill(List<int> skillList)
    {
        if (skillList != null)
        {
            for (int i = 0, count = skillList.Count; i < count; ++i)
            {
                m_pNpc.AddSkill((uint)skillList[i], null, 0);
            }
        }

       
    }

    public bool CanMove()
    {
        if (null == m_baseAIInfo)
        {
            return true;
        }
        return m_baseAIInfo.IsCanMove && m_pNpc.MoveSpeed != 0f;
    }

    public bool CanTurn()
    {
        if (null == m_baseAIInfo)
        {
            return true;
        }
        return m_baseAIInfo.IscanTurn;
    }

    //警戒半径
    public float WarnRadius
    {
        get
        {
            if (null == m_baseAIInfo)
            {
                return 0f;
            }

            return m_baseAIInfo.GuideRadius;
        }
    }

    //专为BOSS漫步AI使用
    //public uint GetTargetList(ref List<CBaseNpc> targetList)
    //{
    //    if (SingletonObject<BattleScene>.GetInstance().IsGameOver())
    //    {
    //        return 0;
    //    }

    //    uint uiSkillType = 0;
    //    eNpcBehaviour eBehaviour = eNpcBehaviour.None;

    //    foreach (CSkill pSkill in m_skillList)
    //    {
    //        SkillContent pSkillInfo = pSkill.GetSkillInfo();
    //        if (pSkillInfo == null)
    //        {
    //            continue;
    //        }

    //        if (pSkill.CD != 0)
    //        {
    //            continue;
    //        }

    //        targetList = m_pNpc.GetTargets(pSkillInfo.GetKey(), ref eBehaviour, true);
    //        if (targetList.Count != 0)
    //        {
    //            uiSkillType = pSkillInfo.GetKey();
    //            break;
    //        }
    //    }

    //    return uiSkillType;
    //}



    private bool CheckTarget(float radius,ref CBaseNpc chaseTarget) 
    {        
        bool check = false;        

        if ( null != chaseTarget)
        {
            if (radius < 0 ) //检测友军
            {
                if (chaseTarget.NpcGroup != m_pNpc.NpcGroup)
                {
                    chaseTarget = null;
                    check = true;
                }
            }
            else //检测敌军
            {
                if (chaseTarget.NpcGroup == m_pNpc.NpcGroup)
                {
                    chaseTarget = null;
                    check = true;
                }
            }     
        }

        return check;
    }

    //currNature当前行为,被动怪被攻击后临时拥有主动行为
    public uint GetTargetList(ref List<CBaseNpc> targetList, ref eNpcBehaviour eBehaviour,ref CBaseNpc chaseTarget,eMonsterNature currNature)
    {
        BattleScene pScene = m_pNpc.CurrBattleScene;
        uint uiSkillType = 0;

        float radius = m_baseAIInfo.GuideRadius;
        //当前已锁定目标的话不再判断警戒区域
        if ( chaseTarget == null || chaseTarget.NpcSortType == eNpcSortType.Chest || CheckTarget(radius,ref chaseTarget))
        {
            //小明说：“警戒半径小于零代表对友军释放”
            if(radius < 0)
            {
                chaseTarget = pScene.GetNearestNpc(m_pNpc,eCheckNpcType.Ally,radius,360);
            }
            else
            {
                //先按TAG找
                string tag = m_baseAIInfo.DefaultTargetTag;
                if(!tag.Equals("0") && !tag.Equals(""))
                {
                    chaseTarget = pScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, radius, 360, false, true, tag);
                }

                //没找到就忽略TAG找不是无敌的怪
                if (chaseTarget == null || chaseTarget.NpcSortType == eNpcSortType.Chest)
                {
                    chaseTarget = pScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, radius, 360);
                }

                //实在不行就找无敌怪
                if (chaseTarget == null)
                {
                    chaseTarget = pScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, radius, 360, false, true);
                }

                //主角还要去开箱子
                if (chaseTarget == null)
                {
                    if (m_pNpc is Avatar)
                    {
                        chaseTarget = pScene.GetNearestNpc(m_pNpc, eCheckNpcType.Neutrality, radius, 360);
                    }
                }
            }

            //if (chaseTarget != null && (chaseTarget.IsInvincibility() || chaseTarget.IsHide()))
            //{
            //    chaseTarget = null;
            //}


            if (chaseTarget != null)
            {
                //在警戒范围内
                UpdateCondition(eExtraAICondition.FindEnemy, "");
            }
            else
            {          
                //进入闲逛状态
                if (m_pNpc.NpcGroup == eNpcGroup.Evil)
                {
                    eBehaviour = eNpcBehaviour.Scaunter;
                }   
                //离开警戒范围
                ResetCondition(eExtraAICondition.FindEnemy);
   
            } 
        }
        //else if(chaseTarget.NpcGroup == eNpcGroup.Neutral)
        //{
        //    float radius = m_baseAIInfo.GetGuideRadius();
        //    CBaseNpc anyEnemy = pScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, radius, 360, true); 
        //    if (anyEnemy != null)
        //    {
        //        chaseTarget = anyEnemy;
        //    }
        //}

        if ( null != chaseTarget && currNature == eMonsterNature.Active )
        {
            bool bAttackAir = false;
            bool hasDefaultSkill = false;//是否有普通攻击
            SkillContent defaultSkill = HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.DefaultSkillID);
            if (defaultSkill != null)
            {
                hasDefaultSkill = true;
            }

            //先检查是否可以放技能
            if (m_baseAIInfo.IsAutoUseSkill && (m_aiSkillTimer.IsExpired(true) || m_pNpc.CanStruggleManully()) && m_pNpc.CanUseSkillManully())
            {
                for (int i = 0, count = m_pNpc.SkillList.Count; i < count; ++i)
                {
                    CInitiativeSkill pSkill = m_pNpc.SkillList[i];
                    SkillContent pSkillInfo = pSkill.GetSkillInfo();
                    if (pSkillInfo == null)
                    {
                        continue;
                    }

                    if (!bAttackAir)
                    {
                        eSkillAtkType atkType = (eSkillAtkType)pSkillInfo.SkillAtkType;
                        if (atkType == eSkillAtkType.AirAtk ||
                            atkType == eSkillAtkType.GroundAirAtk)
                        {
                            bAttackAir = true;
                        }
                    }

                    if (pSkillInfo.SkillType != (byte)eSkillType.SkillType && pSkillInfo.SkillType != (byte)eSkillType.CreateNpc)
                    {
                        continue;
                    }

                    targetList = m_pNpc.GetTargets((uint)pSkillInfo.Key, ref eBehaviour, eEffectRangeType.JudgeType);
                    if (eBehaviour == eNpcBehaviour.Attack)
                    {
                        if (pSkill.CD != 0)//技能CD中
                        {
                            if (!hasDefaultSkill)//只有当当前NPC没有普通攻击时才去等待技能CD
                            {
                                eBehaviour = eNpcBehaviour.Stay;
                            }
                            else
                            {
                                eBehaviour = eNpcBehaviour.None;
                            }
                            continue;
                        }
                        else
                        {
                            uiSkillType = (uint)pSkillInfo.Key;
                            break;
                        }
                    }
                }
            }

            //再检查是否可以普通攻击
            if (eBehaviour != eNpcBehaviour.Attack && m_pNpc.CanUseNormalAttackManully())
            {
                //普通攻击
                if (m_pNpc.DefaultSkillCD <= 0)
                {
                    targetList = m_pNpc.GetTargets(m_pNpc.DefaultSkillID, ref eBehaviour, eEffectRangeType.JudgeType);
                    if (eBehaviour == eNpcBehaviour.Attack)
                    {
                        uiSkillType = m_pNpc.DefaultSkillID;
                    }
                }
            }
            
            //否则视情况跑向目标或停在原地
            if (eBehaviour == eNpcBehaviour.None && m_pNpc.CanActManully())
            {
                bool bInRange = true;                

                if (m_pNpc.MinAttackRange != 0f && null != m_pNpc.CurrTarget)
                {
                    if (m_pNpc.CurrTarget.GetCurrActState() != eActionState.Shapeshift &&  !m_pNpc.CurrTarget.IsHide())
                    {
                        float distance  = m_pNpc.MinAttackRange;
                        bInRange = CBaseNpc.InRange(distance, m_pNpc, m_pNpc.CurrTarget); //判断目标是否在身边
                    }                    
                }

                if (CanMove() && m_pNpc.CurrTarget != null && !bInRange)  // targetDistance > judgeDis)
                {
                    eBehaviour = eNpcBehaviour.Chase;
                }
                else
                {
                    eBehaviour = eNpcBehaviour.Stay;
                }

                //怪物不会跑向切换小伙伴中的主角
                if (eBehaviour == eNpcBehaviour.Chase && m_pNpc is Monster && m_pNpc.CurrTarget != null && m_pNpc.CurrTarget is Avatar)
                {
                    Avatar pavatar = (Avatar)m_pNpc.CurrTarget;
                    if (pavatar.PartnerState == ePartnerState.SwitchingToAvatar || pavatar.PartnerState == ePartnerState.SwitchingToPartner)
                    {
                        eBehaviour = eNpcBehaviour.Stay;
                    }
                }

                //打最近的
                //CBaseNpc nearNPC = m_pNpc.BattleScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, 1000, true);
                //if (nearNPC != null && m_pNpc.CurrTarget != nearNPC)
                //{
                //    float nearDistance = Common.Get2DVecter3Length(nearNPC.GetPosition(), m_pNpc.GetPosition());
                //    float nearRadius = nearNPC.GetCharacterRadius(nearNPC.ModelSize);
                //    if (nearDistance < (CloseDistance + nearRadius))
                //    {
                //        chaseTarget = nearNPC;
                //    }
                //}
            }
        }
        return uiSkillType;
    }


    public void UpdateCondition(eExtraAICondition condition,string arg)
    {
        float fMaxHP = 1;
        CExtraEvent pHPEvent = null;
        for (int i = 0, count = m_extraList.Count; i < count; ++i)
        {
            CExtraEvent pExtraEvent = m_extraList[i];
            if (pExtraEvent.TriggeredState != eExtraEventState.NotTriggered)
            {
                continue;
            }
            if (pExtraEvent.ExtraAICondition == condition)
            {
                switch (condition)
                {
                    case eExtraAICondition.Hp:
                        {
                            //当HP下降过快时只会触发最后一个满足条件的扩展AI
                            int nConditionArg = MyConvert_Convert.ToInt32(pExtraEvent.GetConditionArg());
                            float fConditionArg = nConditionArg / 10000.0f;
                            float fPercent = MyConvert_Convert.ToSingle(arg);
                            if (fConditionArg != -1)
                            {
                                if(  fConditionArg >= fPercent )
                                {
                                    pExtraEvent.TriggeredState = eExtraEventState.Triggered;
                                }

                                if (fConditionArg < fMaxHP && fConditionArg >= fPercent)
                                {
                                    fMaxHP = fConditionArg;
                                    pHPEvent = pExtraEvent;
                                }
                            }
                        }
                        break;
                    case eExtraAICondition.AppointSkillAttack:
                        {
                            string conditionArg = pExtraEvent.GetConditionArg();
                            string[] strs = conditionArg.Split('~');
                            if(strs.Length != 2)
                            {
                                MyLog.Log("UpdateCondition error,strs.Length != 2,conditionArg:"+conditionArg);
                                break;
                            }
                            if (strs[0] == arg)
                            {
                                int range = MyConvert_Convert.ToInt32(strs[1]);
                                if (Random.Range(0, 10000) < range)
                                {
                                    pExtraEvent.UpdateCondition();
                                }
                                
                            }
                        }
                        break;
                    case eExtraAICondition.TotalDamage:
                        {
                            int nHp = MyConvert_Convert.ToInt32(arg);
                            nHp = Mathf.Abs(nHp);
                            m_weaknessTotalHp += nHp;

                            string conditionArg = pExtraEvent.GetConditionArg();
                            int nConditionArg = MyConvert_Convert.ToInt32(conditionArg);

                            if (nConditionArg > 0)
                            {
                                //百分比
                                if ((float)m_weaknessTotalHp / (float)m_pNpc.GetMaxHp() >= nConditionArg / 10000.0f)
                                {
                                    pExtraEvent.UpdateCondition();
                                    m_weaknessTotalHp = 0;
                                }
                            }
                            else
                            {
                                //绝对数值
                                if (m_weaknessTotalHp >= Mathf.Abs(nConditionArg))
                                {
                                    pExtraEvent.UpdateCondition();
                                    m_weaknessTotalHp = 0;
                                }
                            }
                        }
                        break;
                    default:
                        {
                            pExtraEvent.UpdateCondition();
                        }
                        break;
                }
                
            }
        }

        if (pHPEvent != null)
        {
            pHPEvent.TriggeredState = eExtraEventState.NotTriggered;
            pHPEvent.UpdateCondition();
        }
    }

    public void ResetCondition(eExtraAICondition condition)
    {
        for (int i = 0, count = m_extraList.Count; i < count;++i )
        {
            CExtraEvent pExtraEvent = m_extraList[i];
            if (pExtraEvent.ExtraAICondition == condition)
            {
                pExtraEvent.Reset();
            }
        }
    }

    //攻击模式
    public eMonsterNature MonsterBehaviour
    {
        set
        {
            m_monsterBehaviour = value;
        }
        get
        {
            return m_monsterBehaviour;
        }
    }

    public void Update()
    {
        for (int i = 0; i < m_extraList.Count;++i )
        {
            m_extraList[i].Update();
        }
    }

    public void Behit(CBaseNpc attacker)
    {
        //判断是否可以进行反击
        if (attacker != null && m_baseAIInfo != null && m_baseAIInfo.IsAutoBeatBack)
        {
            if (attacker is SkillNpc)
            {
                SkillNpc pSkillNpc = attacker as SkillNpc;
                if (pSkillNpc.ParentNpc != null && pSkillNpc.ParentNpc.CanBeAttacked())
                {
                    m_pNpc.CurrTarget = pSkillNpc.ParentNpc;
                }
            }
            else if (attacker.CanBeAttacked() && attacker.NpcSort != eNpcSort.Mechanism)
            {
                m_pNpc.CurrTarget = attacker;
            }  
        }
    }

    public eNpcBehaviour CheckNpcBehaviour()
    {
        CBattleSceneLoading bsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (bsl != null && (m_pNpc is Avatar || m_pNpc is EnemyAvatar || m_pNpc is OnlineAvatar))
        {
            BaseBattlePlayer pbbp = (BaseBattlePlayer)m_pNpc;
            if (pbbp.PartnerState != ePartnerState.Partner && !pbbp.IsInRide() && !pbbp.IsInFly() && !pbbp.AvatarDead)
            {
                if (bsl.battleType == eBattleType.Arena)//竞技场骑乘战斗逻辑
                {

                    if (pbbp.BeginRide())
                    {
                        return eNpcBehaviour.None;
                    }

                    if (pbbp.BeginFly())
                    {
                        return eNpcBehaviour.None;
                    }
                }
                else if (bsl.battleType == eBattleType.Wasteland)//末日荒野骑乘战斗逻辑
                {
                    if (pbbp.GetHp() < pbbp.GetMaxHp() * 0.7f && m_pNpc.NpcSort == eNpcSort.EnermyAvatar && pbbp.BeginRide())
                    {
                        return eNpcBehaviour.None;
                    }
                    else if (pbbp.GetHp() < pbbp.GetMaxHp() * 0.3f && m_pNpc.NpcSort == eNpcSort.EnermyAvatar && pbbp.BeginFly())
                    {
                        return eNpcBehaviour.None;
                    }
                }
            }
        }


        CBaseNpc chaseTarget = null;
        eMonsterNature currNature;

        currNature = MonsterBehaviour;
        if (m_pNpc.CurrTarget != null)
        {
            if (m_pNpc.CurrTarget.IsDead() || m_pNpc.CurrTarget == m_pNpc)
            {
                m_pNpc.CurrTarget = null;
            }
            else
            {
                //如果有锁定目标,被动怪暂时升级为主动怪
                currNature = eMonsterNature.Active;
                m_pNpc.Escape = false;
                chaseTarget = m_pNpc.CurrTarget;
            }
        }

        List<CBaseNpc> targetList = null;
        eNpcBehaviour eBehaviour = eNpcBehaviour.None;
        if (m_pNpc.Escape)
        {
            eBehaviour = eNpcBehaviour.Escape;
        }
        else
        {
            uint uiSkillType = GetTargetList(ref targetList, ref eBehaviour, ref chaseTarget, currNature);
            switch (eBehaviour)
            {
                case eNpcBehaviour.Attack:
                    {
                        if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve && m_pNpc is Monster)
                        {
                            (m_pNpc as Monster).ReqDoAttack(uiSkillType);
                            eBehaviour = eNpcBehaviour.WaitMessage;
                        }
                        else
                        {
                            m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg(uiSkillType, targetList));

                            Transform targetTrans = chaseTarget.GetTransform();
                            m_pNpc.SetFollowTransform(targetTrans, true);
                        }                        
                    }
                    break;
                case eNpcBehaviour.Chase:
                    {
                        eActionState currState = m_pNpc.GetCurrActState();

                        if (chaseTarget is BaseBattlePlayer)
                        {
                            eActionState playerState = chaseTarget.GetCurrActState();
                            if (playerState == eActionState.SwitchPartner)
                            {
                                break;
                            }
                        }

                        if (currState != eActionState.Run ||
                            m_pNpc.CurrTarget != chaseTarget)
                        {

                            Transform targetTrans = chaseTarget.GetTransform();

                            if (Common.Get2DVecter3Length(m_pNpc.GetPosition(), targetTrans.position) > m_pNpc.MinAttackRange)
                            {
                                if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve && m_pNpc is Monster)
                                {
                                    (m_pNpc as Monster).ReqMove(chaseTarget.Index);
                                    eBehaviour = eNpcBehaviour.WaitMessage;
                                }
                                else
                                {
                                    m_pNpc.SetFollowTransform(targetTrans, true, true);
                                    m_pNpc.EnterState(eActionState.Run);
                                }                                
                            }
                    
                            m_pNpc.CurrTarget = chaseTarget;                           
                        }
                    }
                    break;
                case eNpcBehaviour. Stay:
                    {
                        if (chaseTarget != null && m_pNpc.CurrTarget != chaseTarget)
                        {
                            m_pNpc.CurrTarget = chaseTarget;
                        }

                        eActionState currState = m_pNpc.GetCurrActState();
                        if (currState != eActionState.Idle)
                        {
                            m_pNpc.EnterState(eActionState.Idle);
                        }

//                         if (m_pNpc.BattleScene.BattleType == eBattleType.MultiPve && m_pNpc is Monster)
//                         {
//                             //暂不发消息
//                         }
//                         else
                        {
                            //如果该NPC当前有目标则转向该目标
                            if (m_pNpc.CurrTarget != null)
                            {
                                Vector3 lookDirection = m_pNpc.CurrTarget.GetPosition() - m_pNpc.GetPosition();
                                lookDirection.y = 0;
                                m_pNpc.UpdateTurn(lookDirection, false);
                            }
                        }

   
                    }
                    break;
                case eNpcBehaviour.Scaunter:
                    {
                        if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve && m_pNpc is Monster)
                        {
                            //暂不发消息
                        }
                        else
                        {
                            eActionState currState = m_pNpc.GetCurrActState();
                            if (currState != eActionState.Scaunter)
                            {
                                m_pNpc.EnterState(eActionState.Scaunter);
                            }
                        }                                                
                    }
                    break;
            }
        }

        //做一些角色类型相关的其它行动
        if (eBehaviour == eNpcBehaviour.None && m_pNpc.CanActManully())
        {
            if (m_pNpc.NpcSort == eNpcSort.Avatar)//主角不捡东西了，主角要保护马车  //如果是主角就要捡东西
            {
                //CObject obj = CDropObjectManager.GetInst().GetRadiusDrop(m_pNpc.GetPosition(), DEFINE.TRUSTEESHIP_CHECK_RADIUS);
                //if (obj != null && m_pNpc.GetCurrActState() != eActionState.Run)
                //{
                //    m_pNpc.Command(eCommandType.RunTo, new RunToCommandArg(obj.transform.position, true, true));
                //    eBehaviour = eNpcBehaviour.RunTo;
                //}
                //else
                //{
                //    //找远处的怪
                //    CBaseNpc farNPC = m_pNpc.BattleScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, 1000, 360, false, true);
                //    if (farNPC != null && m_pNpc.GetCurrActState() != eActionState.Run)
                //    {
                //        m_pNpc.Command(eCommandType.RunTo, new RunToCommandArg(farNPC.GetPosition(),true,true));
                //        eBehaviour = eNpcBehaviour.RunTo;
                //    }
                //}

                bool escort = bsl.battleType == eBattleType.Escort || m_pNpc.CurrBattleScene.RoomType == eRoomType.Escort; //护送

                if (m_pNpc.CurrBattleScene.EscrotStage || m_pNpc.CurrBattleScene.ProtectStage) //护送、守护逻辑
                {
                    //CBaseNpc pCarriage = m_pNpc.BattleScene.GetCarriage();
                    CBaseNpc pCarriage = (m_pNpc as Avatar).ProtectNpc;
                    if (pCarriage != null && !pCarriage.IsDead())
                    {
                        float distance = Common.Get2DVecter3Length(pCarriage.GetPosition(), m_pNpc.GetPosition());
                        float dstDistance = Common.Get2DVecter3Length(pCarriage.GetPosition(), m_pNpc.GetDestPosition());

                        float snuglyDistance = m_pNpc.GetSnuglyDistance(pCarriage) + 2;
                        //float snuglyDistance = 6.0f;

                        if ((m_pNpc.GetCurrActState() != eActionState.Run && distance > snuglyDistance) || (m_pNpc.GetCurrActState() == eActionState.Run && dstDistance > snuglyDistance))
                        {
                            Vector3 dstPosition = m_pNpc.CurrBattleScene.SummonPosition(pCarriage.GetPosition(), m_pNpc.CharacterRadius,false, pCarriage, pCarriage.NpcCollider);
                            float angel = m_pNpc.CurrBattleScene.EscrotStage ? 45f : -45f;
                            dstPosition = dstPosition + Quaternion.Euler(Vector3.up * angel) * pCarriage.GetTransform().forward * (snuglyDistance - 1);

                            m_pNpc.Command(eCommandType.RunTo, new RunToCommandArg(dstPosition, true, true));
                            eBehaviour = eNpcBehaviour.RunTo;
                        }
                    }
                }
            
            }
            else if (m_pNpc.NpcSort == eNpcSort.AIFriend)//如果是好友就守护主角
            {
                Avatar pavatar = SingletonObject<Avatar>.GetInst();
                if (pavatar != null && !pavatar.InPlatform)
                {
                    float distance = Common.Get2DVecter3Length(pavatar.GetPosition(), m_pNpc.GetPosition());
                    float dstDistance = Common.Get2DVecter3Length(pavatar.GetPosition(), m_pNpc.GetDestPosition());

                    if ((m_pNpc.GetCurrActState() != eActionState.Run && distance > 4.0f) || (m_pNpc.GetCurrActState() == eActionState.Run && dstDistance > 4.0f))
                    {
                        Vector3 dstPosition = m_pNpc.CurrBattleScene.SummonPosition(pavatar.GetPosition(), m_pNpc.CharacterRadius,false, pavatar, pavatar.NpcCollider);
                        m_pNpc.Command(eCommandType.RunTo, new RunToCommandArg(dstPosition, true, true));
                        eBehaviour = eNpcBehaviour.RunTo;
                    }
                }
            }

            if (m_baseAIInfo.IsFollowWayPoint && eBehaviour == eNpcBehaviour.None &&
                (m_pNpc.NpcSort != eNpcSort.Avatar || bsl.battleType != eBattleType.Escort && m_pNpc.CurrBattleScene.RoomType != eRoomType.Escort)) //如果无事可干并且要走路点的话，那就去走路点吧
            {

                Monster monster = m_pNpc as Monster;
                if ( null != monster && monster.IsCarriage)
                {
                    //马车附近有怪就不走
                    CBaseNpc findMonster = m_pNpc.CurrBattleScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, 20f, 360);
                    if ( null != findMonster )
                    {
                        //有怪物,                  
                        m_pNpc.EnterState(eActionState.Idle);
                        return eNpcBehaviour.None;
                    }                    
                }

                if (m_waypointIndex != 0)
                {
                    GameObject gobj = m_pNpc.CurrBattleScene.FindWaypoint("area_" + string.Format("{0:D2}", m_waypointIndex));
                    if (gobj != null && gobj.activeSelf)
                    {
                        m_pNpc.Command(eCommandType.RunTo, new RunToCommandArg(gobj.transform.position, true, true));
                        
                        
                        float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), gobj.transform.position);

                        if (distance < 0.5f)
                        {
                            m_waypointIndex++;
                        }
                    }
                    else
                    {
                        m_waypointIndex++;
                        if (m_waypointIndex >= DEFINE.MAX_WAY_POINT_COUNT)//暂时只找0~DEFINE.MAX_WAY_POINT_COUNT-1
                        {
                            m_waypointIndex = 0;
                        }
                    }
                }
            }
        }

        //BattleScene pScene = m_pBattleScene;
        //SceneContent pSceneLoader = pScene.GetSceneLoader();
        //switch (pSceneLoader.GetWinCondition())
        //{
        //    case eBattleWinCondition.Wave:
        //    case eBattleWinCondition.AppointMonsterNum:
        //    case eBattleWinCondition.KillNpc:
        //    case eBattleWinCondition.SurvivalTimeLimit:
        //    case eBattleWinCondition.ProtectNpc:
        //    case eBattleWinCondition.ArriveAppointArea:
        //    default:
        //        {
        //        }
        //        break;
        //}

        return eBehaviour;
    }

    public void ResetWeaknessCount()
    {
        m_weaknessTotalHp = 0;
    }

}
