﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eExtraEventState
{
    NotTriggered,//还没有触发
    WaitForTriggered,//等待触发
    Triggered,//触发过了
}

public class CExtraEvent
{
    protected CBaseNpc m_pNpc;
    protected ExtraAIContent m_pExtraAIInfo;
    public ExtraAIContent ExtraAILoader
    {
        get { return m_pExtraAIInfo; }
    }
    private eExtraEventState m_state;

    //2014年1月21日新加变量 全部为ExecEvent()所用到的局部变量转为全局变量
    private eExtraAIEvent m_eExtraAIEventBuff;

    private Monster m_pMonster;
    private NpcAI m_pAI;
    private Avatar m_pAvatar;
    private List<CBaseNpc> m_targetList;
    //2014年1月21日新加变量 end

    public CExtraEvent(CBaseNpc pNpc, uint uiExtraAIID)
    {
        m_pNpc = pNpc;
        m_pExtraAIInfo = HolderManager.m_ExtraAIHolder.GetStaticInfo(uiExtraAIID);
        m_state = eExtraEventState.NotTriggered;

        if ( null != m_pExtraAIInfo )
        {
            if (m_pExtraAIInfo.EventType == (byte)eExtraAIEvent.UseSkill )
            {
                uint skillID = MyConvert_Convert.ToUInt32(m_pExtraAIInfo.EventArg);
                SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(skillID);
                if ( null != pSkillLoader )
                {
                    m_pNpc.CheckAttackRange(pSkillLoader);
                    m_pNpc.CheckRangeNpcInclude(pSkillLoader);
                }                
            }            
        }
    }

    //protected void ExecEvent()
    //{
    //    eExtraAIEvent e = m_pExtraAIInfo.GetEventType();

    //    string eventArg = m_pExtraAIInfo.GetEventArg();

    //    switch (e)
    //    {
    //        case eExtraAIEvent.UseSkill:
    //            {
    //                uint uiSkillID = MyConvert_Convert.ToUInt32(eventArg);
    //                eNpcBehaviour eBehaviour = eNpcBehaviour.None;
    //                List<CBaseNpc> targetList = m_pNpc.GetTargets(uiSkillID, ref eBehaviour, true);
    //                if (eBehaviour == eNpcBehaviour.Attack)
    //                {
    //                    m_pNpc.UseSkill(uiSkillID, targetList, false,true);
    //                } 
    //            }
    //            break;
    //        case eExtraAIEvent.Escape:
    //            {
    //                if (m_pNpc.NpcSort == eNpcSort.Monster)
    //                {
    //                    //强制设置为被动怪
    //                    Monster pMonster = (Monster)m_pNpc;
    //                    NpcAI pAI = pMonster.AI;
    //                    pAI.MonsterBehaviour = eMonsterNature.Passive;

    //                    float fDistance = MyConvert_Convert.ToUInt32(eventArg);
    //                    Avatar pAvatar = SingletonObject<Avatar>.GetInst();
    //                    pMonster.EscapeFromTarget(pAvatar, fDistance);
    //                }
                    
    //            }
    //            break;
    //        case eExtraAIEvent.Talk:
    //            {
    //                uint uiTextID = MyConvert_Convert.ToUInt32(eventArg);
    //                string text = Common.GetText(uiTextID);
    //                m_pNpc.CreateChatBubble(text);
    //            }
    //            break;
    //        case eExtraAIEvent.Shapeshift:
    //            { 
    //                uint uiNpcID = MyConvert_Convert.ToUInt32(eventArg);
    //                m_pNpc.Shapeshift(uiNpcID);
    //            }
    //            break;
    //        case eExtraAIEvent.Trigger:
    //            {
    //                uint uiTriggerID = MyConvert_Convert.ToUInt32(eventArg);
    //                TriggerManager.GetInst().ActiveTrigger(uiTriggerID);
    //            }
    //            break;
    //        case eExtraAIEvent.AddBuff:
    //            {
    //                uint uiBuffID = MyConvert_Convert.ToUInt32(eventArg);
    //                m_pNpc.GetBuffManager().AddBuff(uiBuffID);
    //            }
    //            break;
    //    }
    //}

    //2014年1月21日修改局部变量为全局变量

    protected bool ExecEvent()
    {
        m_eExtraAIEventBuff = (eExtraAIEvent)m_pExtraAIInfo.EventType;

        string eventArg = m_pExtraAIInfo.EventArg;
        bool result = true;

        uint uiID;
        string text;

        switch (m_eExtraAIEventBuff)
        {
            case eExtraAIEvent.UseSkill:
                {
                    if (!m_pNpc.CanUseSkillManully())
                    {
                        result = false;
                        break;
                    }
                  
                    uiID = MyConvert_Convert.ToUInt32(eventArg);

                    eNpcBehaviour eBehaviour = eNpcBehaviour.None;
                    m_targetList = m_pNpc.GetTargets(uiID, ref eBehaviour, eEffectRangeType.JudgeType);
                    eCommandReply reply = m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg(uiID, m_targetList, true));

                    result = reply == eCommandReply.YesSir ? true : false;

                    //这里要做技能条件判断
                }
                break;
            case eExtraAIEvent.Escape:
                {
                    if (m_pNpc.NpcSort == eNpcSort.Monster)
                    {
                        //强制设置为被动怪
                        m_pMonster = (Monster)m_pNpc;
                        m_pAI = m_pMonster.AI;
                        m_pAI.MonsterBehaviour = eMonsterNature.Passive;

                        uiID = MyConvert_Convert.ToUInt32(eventArg);
                        m_pAvatar = SingletonObject<Avatar>.GetInst();
                        m_pMonster.EscapeFromTarget(m_pAvatar, (float)uiID);
                    }

                }
                break;
            case eExtraAIEvent.Talk:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);
                    text = Common.GetText(uiID);
                    m_pNpc.CreateChatBubble(text);
                }
                break;
            case eExtraAIEvent.Shapeshift:
                {
                    string[] strs = eventArg.Split('~');
                    if (strs.Length != 2)
                    {
                        MyLog.LogError("Shapeshift error,AIID is " + m_pExtraAIInfo.Key + "eventArg is" + eventArg);
                        break;
                    }
                    uiID = MyConvert_Convert.ToUInt32(strs[0]);
                    uint uiActionID = MyConvert_Convert.ToUInt32(strs[1]);

                    CShapeshiftState pShapeshiftState = (CShapeshiftState)m_pNpc.GetStateMgr().GetState(eActionState.Shapeshift);
                    if (pShapeshiftState != null)
                    {
                        pShapeshiftState.SetReplaceNpcID(uiID);
                        pShapeshiftState.SetActionID(uiActionID);
                        m_pNpc.EnterState(eActionState.Shapeshift);
                    }
                }
                break;
            case eExtraAIEvent.Trigger:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);
                    TriggerManager.GetInst().ActiveTrigger(uiID);
                }
                break;
            case eExtraAIEvent.AddBuff:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);
                    m_pNpc.AddBuff(uiID);
                }
                break;
            case eExtraAIEvent.DelBuff:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);
                    m_pNpc.DelBuff(uiID);
                }
                break;
            case eExtraAIEvent.BossRamble:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);
                    CBossRambleState pRambleState = (CBossRambleState)m_pNpc.GetStateMgr().GetState(eActionState.BossRamble);
                    if (pRambleState != null)
                    {
                        pRambleState.SetTimer((float)uiID);
                        pRambleState.SetActionInfo(1.0f);
                        m_pNpc.EnterState(eActionState.BossRamble);
                    }
                }
                break;
            case eExtraAIEvent.BossSneer:
                {
                    CBossSneerState pSneerState = (CBossSneerState)m_pNpc.GetStateMgr().GetState(eActionState.BossSneer);
                    if (pSneerState != null)
                    {
                        pSneerState.SetActionInfo(1.0f);
                        m_pNpc.EnterState(eActionState.BossSneer);
                    }
                }
                break;
            case eExtraAIEvent.BossWeakness:
                {
                    //状态不能重复进入
                    eActionState currState = m_pNpc.GetCurrActState();
                    if (currState == eActionState.BossWeakness)
                    {
                        break;
                    }
                    CBossWeaknessState weakState = (CBossWeaknessState)m_pNpc.GetStateMgr().GetState(eActionState.BossWeakness);
                    if (weakState != null)
                    {
                        m_pNpc.EnterState(eActionState.BossWeakness);
                        weakState.SetTimer(5);
                    }
                   
                }
                break;
            case eExtraAIEvent.Scared:
                {
                    CScaredState pScaredState = (CScaredState)m_pNpc.GetStateMgr().GetState(eActionState.Scared);
                    if (pScaredState != null)
                    {
                        pScaredState.SetActionInfo(1.0f);
                        m_pNpc.EnterState(eActionState.Scared);
                    }
                }
                break;
            case eExtraAIEvent.UseScript:
                {
                    uiID = MyConvert_Convert.ToUInt32(eventArg);                   
                    ScriptManager.RequestScript(uiID, m_pNpc);
                }
                break;
        }

        return result;
    }

    public eExtraEventState TriggeredState
    {
        get
        {
            return m_state;
        }
        set
        {
            m_state = value;
        }
    }

    public eExtraAICondition ExtraAICondition
    {
        get
        {
            if (null == m_pExtraAIInfo)
            {
                return eExtraAICondition.None;
            }
            return (eExtraAICondition)m_pExtraAIInfo.Condition;
        }
    }

    public void UpdateCondition()
    {
        if (m_state != eExtraEventState.NotTriggered)
        {
            return;
        }

        m_state = eExtraEventState.WaitForTriggered;
    }

    public string GetConditionArg()
    {
        if (null == m_pExtraAIInfo)
        {
            return "0";
        }
        return m_pExtraAIInfo.Arg;
    }

    //重置事件触发
    public void Reset()
    {
        m_state = eExtraEventState.NotTriggered;
    }


    public void Update()
    {
        switch (m_state)
        {
            case eExtraEventState.WaitForTriggered:
                {
                    bool result = ExecEvent();

                    if (!result)
                    {
                        //没成功就一直触发
                        m_state = eExtraEventState.WaitForTriggered;
                    }
                    else
                    {
                        if (m_pExtraAIInfo.IsRepeat)
                        {
                            m_state = eExtraEventState.NotTriggered;
                        }
                        else
                        {
                            m_state = eExtraEventState.Triggered;
                        }
                    }                                                            
                }
                break;
        }
    }
}
