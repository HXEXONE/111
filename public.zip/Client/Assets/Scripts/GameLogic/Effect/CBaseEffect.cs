﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CBaseEffect {

    protected Avatar m_pAvatar;     //当前英雄
    protected Transform m_AvatarEffevtFather;    //储存特效的物体
    protected GameObject m_skillEffectObj;   //当前技能特效

    private string m_path;       //资源路径
    private eBaseEffectState m_state;
    protected SkillEffectContent m_effectInfo;

    protected float m_fDelayTime;//延时时间
    protected float m_fLastTime;//持续时间

    protected float m_fStartTime;//开始计时时间

    protected eAvatarEffect m_effectType;

    protected Dictionary<eAvatarEffect, GameObject> m_effectDirect = new Dictionary<eAvatarEffect, GameObject>();   //用于储存正在使用特效列表
    protected Dictionary<eAvatarEffect, GameObject> m_effectDelect = new Dictionary<eAvatarEffect, GameObject>();   //用于储存备用的特效列表


    public virtual void Init(SkillEffectContent pInfo, Transform father)
    {
        m_effectInfo = pInfo;
        m_fDelayTime = pInfo.DelayTime;
        m_fLastTime = pInfo.LastTime;
        m_path = pInfo.Path;
        m_fStartTime = Time.time;

        m_AvatarEffevtFather = father;

        if (m_pAvatar == null)
            m_pAvatar = SingletonObject<Avatar>.GetInst();

        if (m_skillEffectObj == null)
        {
            LoadHelp.LoadObject("", m_path, ThreadPriority.Normal, SkillSelectRangeEffect);
            return;
        }

        m_state = eBaseEffectState.EFFECT_STATE_WAIT;
    }

    private void SkillSelectRangeEffect(string interim, UnityEngine.Object asset)
    {
        m_state = eBaseEffectState.EFFECT_STATE_WAIT;
        if (null == asset) { MyLog.LogError("" + interim); return; }
        m_skillEffectObj = Object.Instantiate(asset) as GameObject;
        Object.DontDestroyOnLoad(m_skillEffectObj);
        m_skillEffectObj.SetActive(false);
        m_skillEffectObj.transform.parent = m_AvatarEffevtFather;
        
    }

    public void SetState(eBaseEffectState state)
    {
        if (m_state == state)
        {
            return;
        }
        m_state = state;

        switch (state)
        {
            case eBaseEffectState.EFFECT_STATE_ENTER:
                {
                    Enter();
                }
                break;
            case eBaseEffectState.EFFECT_STATE_LEAVE:
                {
                    Leave();
                }
                break;
        }
    }

    protected virtual void Enter()
    {
    }

    protected virtual void Leave()
    {
        m_state = eBaseEffectState.EFFECT_STATE_NONE;
    }

    public bool Update()
    {
        if (m_skillEffectObj == null || m_pAvatar == null)
        {
            return false;
        }

        switch (m_state)
        {
            case eBaseEffectState.EFFECT_STATE_WAIT:
                {
                    if (Time.time - m_fStartTime >= m_fDelayTime)//延时播放
                    {
                        SetState(eBaseEffectState.EFFECT_STATE_ENTER);
                    }
                }
                break;
            case eBaseEffectState.EFFECT_STATE_ENTER:
                {
                    SetState(eBaseEffectState.EFFECT_STATE_UPDATE);
                }
                break;
            case eBaseEffectState.EFFECT_STATE_UPDATE:
                {
                    UpdateMovement();

                    if (m_fLastTime != -1 && Time.time - m_fStartTime >= m_fDelayTime + m_fLastTime)//持续时间
                    {
                        SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                    }

                }
                break;
        }

        return true;

    }


    protected virtual void UpdateMovement()
    {

    }

    protected void Reset()
    {
        if (m_skillEffectObj != null)
        {
            m_skillEffectObj.transform.localPosition = Vector3.zero;
            m_skillEffectObj.transform.localRotation = Quaternion.Euler(Vector3.zero);
        }
    }

    public eAvatarEffect GetEffectType()
    {
        return m_effectType;
    }
}
