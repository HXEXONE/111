﻿using UnityEngine;
using System.Collections;

public class CSelectRangeEffect : CBaseEffect {

    public CSelectRangeEffect()
    {
        m_effectType = eAvatarEffect.SkillSelectRange;
    }

    public override void Init(SkillEffectContent pInfo, Transform father)
    {
        base.Init(pInfo, father);
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_pAvatar != null)
            m_skillEffectObj.transform.parent = m_pAvatar.GetTransform();

        Reset();
        m_skillEffectObj.SetActive(true);
    }

    protected override void Leave()
    {
        base.Leave();
        m_skillEffectObj.SetActive(false);
        if (m_pAvatar != null && m_AvatarEffevtFather != null)
            m_skillEffectObj.transform.parent = m_AvatarEffevtFather;
    }

    protected override void UpdateMovement()
    {
        base.UpdateMovement();
    }
}
