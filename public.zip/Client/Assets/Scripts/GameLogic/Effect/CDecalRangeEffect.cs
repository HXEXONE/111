﻿using UnityEngine;
using System.Collections;

public class CDecalRangeEffect: CBaseEffect {

    private Ray m_ray;
    private RaycastHit m_hit;
    private Camera m_cam;
    private System.Collections.Generic.List<string> m_list;
    private Transform m_sourceTrans;

    private float m_distance;
    private float m_rayLen;
    public Vector3 m_rayHitPos;

    private bool m_isRightRetate;    //左转还是右转
    private float m_rotateSpeed;     //速度，以度/秒 计算

	 public CDecalRangeEffect()
    {
        m_effectType = eAvatarEffect.Projector;
        m_list = new System.Collections.Generic.List<string>();
        m_rayLen = 200;
        m_distance = 5;
    }

    public override void Init(SkillEffectContent pInfo, Transform father)
    {
        base.Init(pInfo, father);
        m_cam = CCamera.GetInst().GetCamera();

        m_list = m_effectInfo.ExtraArgToSingleList;
        m_isRightRetate = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));
        m_rotateSpeed = MyConvert_Convert.ToSingle(m_list[1]);
    }

    protected override void Enter()
    {
        base.Enter();
        m_sourceTrans = m_skillEffectObj.transform;
        Reset();
        m_skillEffectObj.SetActive(true);
    }

    protected override void Leave()
    {
        base.Leave();
        m_skillEffectObj.SetActive(false);
        Reset();
    }

    protected override void UpdateMovement()
    {
        base.UpdateMovement();

        if (m_cam != null & m_skillEffectObj != null)
        {
            m_sourceTrans.position = GetPosition();

            Rotate();
        }
    }

    private Vector3 GetPosition()
    {
        m_ray = m_cam.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(m_ray, out m_hit, m_rayLen, 1 << DEFINE.TERRAINLAYER))
        {
            m_rayHitPos = m_hit.point;
            Vector3 upNom = Vector3.up;
            if (Mathf.Abs(Vector3.Dot(upNom, m_hit.normal)) > 0.2f)
            {
                Vector3 pos = m_rayHitPos - m_ray.direction * m_distance;
                return pos;
            }
            return Vector3.zero;
        }
        return Vector3.zero;
    }

    private void Rotate()
    {
        if (m_isRightRetate)
        {
            m_sourceTrans.Rotate(Vector3.up, m_rotateSpeed * Time.deltaTime);
        }
        else
        {
            m_sourceTrans.Rotate(Vector3.up, -m_rotateSpeed * Time.deltaTime);
        }
    }
}
