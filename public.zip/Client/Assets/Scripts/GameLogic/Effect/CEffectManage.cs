﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CEffectManage
{
    private Dictionary<eAvatarEffect, CBaseEffect> m_EffectDict = new Dictionary<eAvatarEffect, CBaseEffect>();

    private GameObject m_effectFather;
    private Transform m_effectFatherTrans;

    public void Init()
    {
        if (m_effectFather == null)
        {
            m_effectFather = new GameObject("Effevt");
            Object.DontDestroyOnLoad(m_effectFather);
            m_effectFatherTrans = m_effectFather.transform;
        }

        RegisteEffect(new CSelectRangeEffect());
        RegisteEffect(new CDecalRangeEffect());
    }

    public void RegisteEffect(CBaseEffect baseEffect)
    {
        eAvatarEffect type = baseEffect.GetEffectType();
        if (!m_EffectDict.ContainsKey(type))
            m_EffectDict.Add(type, baseEffect);
    }

    public void SetEffect(uint dwEffectID)
    {

        SkillEffectContent info = HolderManager.m_SkillEffectHolder.GetStaticInfo(dwEffectID);
        if (null == info)
        {
            return;
        }

        CBaseEffect effect = GetExistEffect((eAvatarEffect)info.EffectType);
        if (effect != null)
        {
            effect.Init(info, m_effectFatherTrans);
        }
    }

    public GameObject GetFatherEffect()
    {
        return m_effectFather;
    }

    public CBaseEffect GetExistEffect(eAvatarEffect type)
    {
        CBaseEffect effect = null;
        m_EffectDict.TryGetValue(type, out effect);
        return effect;
    }

    public void Update()
    {
        if (m_EffectDict.Count > 0)
        {
            foreach (KeyValuePair<eAvatarEffect, CBaseEffect> kvp in m_EffectDict)
            {
                kvp.Value.Update();
            }
        }
       
    }
}
