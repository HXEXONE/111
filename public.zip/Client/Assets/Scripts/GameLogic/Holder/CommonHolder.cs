﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class HolderManager
{
    public static Dictionary<string, string> AssetDict = new Dictionary<string, string>
    {
        {"guitext","GUITextHolder"},
        {"channel","ChannelHolder"},
        {"sound","AudioHolder"},
        {"pixiemodelres","ParticleHolder"},
        {"panel","PanelHolder"},
        {"playerconfig","PlayerConfigHolder"},
        {"map","SceneHolder"},
        {"mapinfo","SceneInfoHolder"},
        {"player","PlayerHolder"},
        {"monstermodel","MonsterModelHolder"},
        {"monster","MonsterHolder"},
        {"item","ItemHolder"},
        {"pet","PetHolder"},
        {"petmodel","PetModelHolder"},
        {"skill","SkillHolder"},
        {"action","ActionHolder"},
        {"buff","BuffHolder"},
        {"attribute","AttrHolder"},
        {"aibase","BaseAIHolder"},
        {"aiex","ExtraAIHolder"},
        {"camera","CameraHolder"},
        {"dropitem","DropItemHolder"},
        {"dropobject","DropObjectHolder"},
        {"script","ScriptHolder"},
        {"equip","EquipHolder"},
        {"equipmodel","EquipModelHolder"},
        {"petskill","PetSkillHolder"},
        {"tech","TechHolder"},
        {"mount","MountsHolder"},
        {"mountmodel","MountModelHolder"},
        {"partner","PartenrHolder"},
        {"partnermodel","PartnerModelHolder"},
        {"skillup","SkillUpHolder"},
        {"homenpc","HomeNPCHolder"},
        {"quest","QuestHolder"},
        {"levelup","LevelUpHolder"},
        {"tips","TipsHolder"},
        {"shop","ShopHolder"},
        {"skilleffect","SkillEffectHolder"},
        {"battlepve","BattlePVEHolder"},
        {"gamestory","SceneStoryHolder"},
        {"storynpc","SceneStoryNpcHolder"},
        {"dialogue","TalkHolder"},
        {"aura","AuraHolder"},
        {"award","AwardHolder"},
        {"relice","ReliceHolder"},
        {"mechanism","MechanismHolder"},
        {"randomname","NameHolder"},
        {"achieve","AchieveHolder"},
        {"goal","EverydayTargetHolder"},
        {"uieffect","UIEffectHolder"},
        {"guid","GuidHolder"},
        {"homeguide","HomeGuideHolder"},
        {"uiscene","UISceneHolder"},
        {"itembox","ItemBoxHolder"},
        {"usual","UsualHolder"},
        {"boss","BossInfoHolder"},
        {"partnerbox","PartnerBoxHolder"},
        {"sociatywar","SociatyWarHolder"},
        {"sign","SignHolder"},
        {"open","OpenHolder"},
        {"shield","ShieldHolder"},
        {"vip","VipHolder"},
        {"activity","ActivityHolder"},
        {"target","TargetHolder"},
        {"sociatyicon","SociatyIconHolder"},
        {"maidian","MaiDianHolder"},
        {"assetsmap","AssetsMapHolder"},
        {"forge","ForgeHolder"},
        {"invite","InviteHolder"},
        {"league","LeagueHolder"},
        {"leaguegoods","LeagueGoodHolder"},
        {"leagueshop","LeagueShopHolder"},
        {"towershop","TowerShopHolder"},
        {"toweraward","TowerAwardHolder"},
        {"towermonster","TowerMonsterHolder"},
        {"dirtyword","DirtywordHolder"},
        {"dragoncrystal","DragoncrystalHolder"}

    };

    public static GUITextHolder m_GUITextHolder = new GUITextHolder();
    public static AudioHolder m_AudioHolder = new AudioHolder();
    public static ParticleHolder m_ParticleHolder = new ParticleHolder();
    public static PanelHolder m_PanelHolder = new PanelHolder();
    public static PlayerConfigHolder m_PlayerConfigHolder = new PlayerConfigHolder();
    public static SceneHolder m_SceneHolder = new SceneHolder();
    public static SceneInfoHolder m_SceneInfoHolder = new SceneInfoHolder();
    public static PlayerHolder m_PlayerHolder = new PlayerHolder();
    public static MonsterModelHolder m_MonsterModelHolder = new MonsterModelHolder();
    public static MonsterHolder m_MonsterHolder = new MonsterHolder();
    public static ItemHolder m_ItemHolder = new ItemHolder();
    public static PetHolder m_PetHolder = new PetHolder();
    public static PetModelHolder m_PetModelHolder = new PetModelHolder();
    public static SkillHolder m_SkillHolder = new SkillHolder();
    public static ActionHolder m_ActionHolder = new ActionHolder();
    public static BuffHolder m_BuffHolder = new BuffHolder();
    public static AttrHolder m_AttrHolder = new AttrHolder();
    public static BaseAIHolder m_BaseAIHolder = new BaseAIHolder();
    public static ExtraAIHolder m_ExtraAIHolder = new ExtraAIHolder();
    public static CameraHolder m_CameraHolder = new CameraHolder();
    public static DropItemHolder m_DropItemHolder = new DropItemHolder();
    public static DropObjectHolder m_DropObjectHolder = new DropObjectHolder();
    public static ScriptHolder m_ScriptHolder = new ScriptHolder();
    public static EquipHolder m_EquipHolder = new EquipHolder();
    public static EquipModelHolder m_EquipModelHolder = new EquipModelHolder();
    public static PetSkillHolder m_PetSkillHolder = new PetSkillHolder();
    public static TechHolder m_TechHolder = new TechHolder();
    public static MountsHolder m_MountsHolder = new MountsHolder();
    public static MountModelHolder m_MountModelHolder = new MountModelHolder();
    public static PartenrHolder m_PartenrHolder = new PartenrHolder();
    public static PartnerModelHolder m_PartnerModelHolder = new PartnerModelHolder();
    public static SkillUpHolder m_SkillUpHolder = new SkillUpHolder();
    public static HomeNPCHolder m_HomeNPCHolder = new HomeNPCHolder();
    public static QuestHolder m_QuestHolder = new QuestHolder();
    public static LevelUpHolder m_LevelUpHolder = new LevelUpHolder();
    public static TipsHolder m_TipsHolder = new TipsHolder();
    public static ShopHolder m_ShopHolder = new ShopHolder();
    public static SkillEffectHolder m_SkillEffectHolder = new SkillEffectHolder();
    public static BattlePVEHolder m_BattlePVEHolder = new BattlePVEHolder();
    public static SceneStoryHolder m_SceneStoryHolder = new SceneStoryHolder();
    public static SceneStoryNpcHolder m_SceneStoryNpcHolder = new SceneStoryNpcHolder();
    public static TalkHolder m_TalkHolder = new TalkHolder();
    public static AuraHolder m_AuraHolder = new AuraHolder();
    public static AwardHolder m_AwardHolder = new AwardHolder();
    public static ReliceHolder m_ReliceHolder = new ReliceHolder();
    public static MechanismHolder m_MechanismHolder = new MechanismHolder();
    public static NameHolder m_NameHolder = new NameHolder();
    public static AchieveHolder m_AchieveHolder = new AchieveHolder();
    public static EverydayTargetHolder m_EverydayTargetHolder = new EverydayTargetHolder();
    public static UIEffectHolder m_UIEffectHolder = new UIEffectHolder();
    public static GuidHolder m_GuidHolder = new GuidHolder();
    public static HomeGuideHolder m_HomeGuideHolder = new HomeGuideHolder();
    public static UISceneHolder m_UISceneHolder = new UISceneHolder();
    public static ItemBoxHolder m_ItemBoxHolder = new ItemBoxHolder();
    public static UsualHolder m_UsualHolder = new UsualHolder();
    public static BossInfoHolder m_BossInfoHolder = new BossInfoHolder();
    public static PartnerBoxHolder m_PartnerBoxHolder = new PartnerBoxHolder();
    public static SociatyWarHolder m_SociatyWarHolder = new SociatyWarHolder();
    public static SignHolder m_SignHolder = new SignHolder();
    public static OpenHolder m_OpenHolder = new OpenHolder();
    public static ShieldHolder m_ShieldHolder = new ShieldHolder();
    public static VipHolder m_VipHolder = new VipHolder();
    public static ActivityHolder m_ActivityHolder = new ActivityHolder();
    public static TargetHolder m_TargetHolder = new TargetHolder();
    public static ChannelHolder m_ChannelHolder =new ChannelHolder();
    public static SociatyIconHolder m_SociatyIconHolder = new SociatyIconHolder();
    public static MaiDianHolder m_MaiDianHolder = new MaiDianHolder();
    public static AssetsMapHolder m_AssetsMapHolder = new AssetsMapHolder();
    public static ForgeHolder m_ForgeHolder = new ForgeHolder();
    public static TriggerHolder m_TriggerHolder = new TriggerHolder();
    public static  InviteHolder m_InviteHolder = new InviteHolder();
    public static LeagueHolder m_LeagueHolder = new LeagueHolder();
    public static LeagueGoodHolder m_LeagueGoodHolder = new LeagueGoodHolder();
    public static LeagueShopHolder m_LeagueShopHolder = new LeagueShopHolder();
    public static TowerShopHolder m_TowerShopHolder = new TowerShopHolder();
    public static TowerAwardHolder m_TowerAwardHolder = new TowerAwardHolder();
    public static TowerMonsterHolder m_TowerMonsterHolder = new TowerMonsterHolder();
    public static DirtywordHolder m_DirtywordHolder = new DirtywordHolder();
    public static DragoncrystalHolder m_DragoncrystalHolder = new DragoncrystalHolder();

}
public class INTEqualityComparer : IEqualityComparer<int>
{
    public bool Equals(int a, int b)
    {

        return a == b;

    }
    public int GetHashCode(int w)
    {
        return w;
    }
}
public abstract class BaseHolder<T>  where T : BaseContent,new()
{
    #if UNITY_IOS
    static Dictionary<int , GUITextContent> m_dict_GUITextContent= new Dictionary<int,GUITextContent>();
	static Dictionary<int , AudioContent> m_dict_AudioContent= new Dictionary<int,AudioContent>();
	static Dictionary<int , ParticleContent> m_dict_ParticleContent= new Dictionary<int,ParticleContent>();
	static Dictionary<int , PanelContent> m_dict_PanelContent= new Dictionary<int,PanelContent>();
	static Dictionary<int , PlayerConfigContent> m_dict_PlayerConfigContent= new Dictionary<int,PlayerConfigContent>();
	static Dictionary<int , SceneContent> m_dict_SceneContent= new Dictionary<int,SceneContent>();
	static Dictionary<int , SceneInfoContent> m_dict_SceneInfoContent= new Dictionary<int,SceneInfoContent>();
	static Dictionary<int , PlayerContent> m_dict_PlayerContent= new Dictionary<int,PlayerContent>();
	static Dictionary<int , MonsterModelContent> m_dict_MonsterModelContent= new Dictionary<int,MonsterModelContent>();
	static Dictionary<int , MonsterContent> m_dict_MonsterContent= new Dictionary<int,MonsterContent>();
	static Dictionary<int , ItemContent> m_dict_ItemContent= new Dictionary<int,ItemContent>();
	static Dictionary<int , PetContent> m_dict_PetContent= new Dictionary<int,PetContent>();
	static Dictionary<int , PetModelContent> m_dict_PetModelContent= new Dictionary<int,PetModelContent>();
	static Dictionary<int , SkillContent> m_dict_SkillContent= new Dictionary<int,SkillContent>();
	static Dictionary<int , ActionContent> m_dict_ActionContent= new Dictionary<int,ActionContent>();
	static Dictionary<int , BuffContent> m_dict_BuffContent= new Dictionary<int,BuffContent>();
	static Dictionary<int , AttrContent> m_dict_AttrContent= new Dictionary<int,AttrContent>();
	static Dictionary<int , BaseAIContent> m_dict_BaseAIContent= new Dictionary<int,BaseAIContent>();
	static Dictionary<int , ExtraAIContent> m_dict_ExtraAIContent= new Dictionary<int,ExtraAIContent>();
	static Dictionary<int , CameraContent> m_dict_CameraContent= new Dictionary<int,CameraContent>();
	static Dictionary<int , DropItemContent> m_dict_DropItemContent= new Dictionary<int,DropItemContent>();
	static Dictionary<int , DropObjectContent> m_dict_DropObjectContent= new Dictionary<int,DropObjectContent>();
	static Dictionary<int , ScriptContent> m_dict_ScriptContent= new Dictionary<int,ScriptContent>();
	static Dictionary<int , EquipContent> m_dict_EquipContent= new Dictionary<int,EquipContent>();
	static Dictionary<int , EquipModelContent> m_dict_EquipModelContent= new Dictionary<int,EquipModelContent>();
	static Dictionary<int , PetSkillContent> m_dict_PetSkillContent= new Dictionary<int,PetSkillContent>();
	static Dictionary<int , TechContent> m_dict_GTechContent= new Dictionary<int,TechContent>();
	static Dictionary<int , MountsContent> m_dict_MountsContent= new Dictionary<int,MountsContent>();
	static Dictionary<int , MountModelContent> m_dict_MountModelContent= new Dictionary<int,MountModelContent>();
	static Dictionary<int , PartenrContent> m_dict_PartenrContent= new Dictionary<int,PartenrContent>();
	static Dictionary<int , PartnerModelContent> m_dict_PartnerModelContent= new Dictionary<int,PartnerModelContent>();
	static Dictionary<int , SkillUpContent> m_dict_SkillUpContentr= new Dictionary<int,SkillUpContent>();
	static Dictionary<int , HomeNPCContent> m_dict_HomeNPCContent= new Dictionary<int,HomeNPCContent>();
	static Dictionary<int , QuestContent> m_dict_QuestContent= new Dictionary<int,QuestContent>();
	static Dictionary<int , LevelUpContent> m_dict_LevelUpContent= new Dictionary<int,LevelUpContent>();
	static Dictionary<int , TipsContent> m_dict_TipsContent= new Dictionary<int,TipsContent>();
	static Dictionary<int , ShopContent> m_dict_ShopContent= new Dictionary<int,ShopContent>();
	static Dictionary<int , SkillEffectContent> m_dict_SkillEffectContent= new Dictionary<int,SkillEffectContent>();
	static Dictionary<int , BattlePVEContent> m_dict_BattlePVEContent= new Dictionary<int,BattlePVEContent>();
	static Dictionary<int , SceneStoryContent> m_dict_SceneStoryContent= new Dictionary<int,SceneStoryContent>();
    static Dictionary<int, SceneStoryNpcContent> m_dict_SceneStoryNpcContent = new Dictionary<int, SceneStoryNpcContent>();
	static Dictionary<int , TalkContent> m_dict_TalkContent= new Dictionary<int,TalkContent>();
	static Dictionary<int , AuraContent> m_dict_AuraContent= new Dictionary<int,AuraContent>();
	static Dictionary<int , AwardContent> m_dict_AwardContent= new Dictionary<int,AwardContent>();
	static Dictionary<int , ReliceContent> m_dict_ReliceContent= new Dictionary<int,ReliceContent>();
	static Dictionary<int , MechanismContent> m_dict_MechanismContent= new Dictionary<int,MechanismContent>();
	static Dictionary<int , NameContent> m_dict_NameContent= new Dictionary<int,NameContent>();
	static Dictionary<int , AchieveContent> m_dict_AchieveContent= new Dictionary<int,AchieveContent>();
	static Dictionary<int , EverydayTargetContent> m_dict_EverydayTargetContent= new Dictionary<int,EverydayTargetContent>();
	static Dictionary<int , UIEffectContent> m_dict_UIEffectContent= new Dictionary<int,UIEffectContent>();
	static Dictionary<int , GuidContent> m_dict_GuidContent= new Dictionary<int,GuidContent>();
	static Dictionary<int , HomeGuideContent> m_dict_HomeGuideContent= new Dictionary<int,HomeGuideContent>();
	static Dictionary<int , UISceneContent> m_dict_UISceneContent= new Dictionary<int,UISceneContent>();
	static Dictionary<int , ItemBoxContent> m_dict_ItemBoxContent= new Dictionary<int,ItemBoxContent>();
	static Dictionary<int , UsualContent> m_dict_UsualContent= new Dictionary<int,UsualContent>();
	static Dictionary<int , BossInfoContent> m_dict_BossInfoContent= new Dictionary<int,BossInfoContent>();
	static Dictionary<int , PartnerBoxContent> m_dict_PartnerBoxContent= new Dictionary<int,PartnerBoxContent>();
	static Dictionary<int , SociatyWarContent> m_dict_SociatyWarContent= new Dictionary<int,SociatyWarContent>();
	static Dictionary<int , SignContent> m_dict_SignContent= new Dictionary<int,SignContent>();
	static Dictionary<int , OpenContent> m_dict_OpenContent= new Dictionary<int,OpenContent>();
	static Dictionary<int , ShieldContent> m_dict_ShieldContent= new Dictionary<int,ShieldContent>();
	static Dictionary<int , VipContent> m_dict_VipContent= new Dictionary<int,VipContent>();
	static Dictionary<int , ActivityContent> m_dict_ActivityContent= new Dictionary<int,ActivityContent>();
	static Dictionary<int , TargetContent> m_dict_TargetContent= new Dictionary<int,TargetContent>();
	static Dictionary<int , ChannelContent> m_dict_ChannelContent= new Dictionary<int,ChannelContent>();
	static Dictionary<int , SociatyIconContent> m_dict_SociatyIconContent= new Dictionary<int,SociatyIconContent>();
	static Dictionary<int , MaiDianContent> m_dict_MaiDianContent= new Dictionary<int,MaiDianContent>();
	static Dictionary<int , AssetsMapContent> m_dict_AssetsMapContent= new Dictionary<int,AssetsMapContent>();
	static Dictionary<int , ForgeContent> m_dict_ForgeContent= new Dictionary<int,ForgeContent>();
	static Dictionary<int , TriggerContent> m_dict_TriggerContent= new Dictionary<int,TriggerContent>();
    static Dictionary<int ,InviteContent> m_dict_InviteContent = new Dictionary<int ,InviteContent>();
    static Dictionary<int ,TowerShopHolder> m_dict_TowerShopHolder = new Dictionary<int ,TowerShopHolder>();
    static Dictionary<int ,TowerAwardHolder> m_dict_TowerAwardHolder = new Dictionary<int ,TowerAwardHolder>();
    static Dictionary<int ,TowerMonsterHolder> m_dict_TowerMonsterHolder = new Dictionary<int ,TowerMonsterHolder>();
    static Dictionary<int ,LeagueGoodHolder> m_dict_LeagueGoodHolder = new Dictionary<int ,LeagueGoodHolder>();
    static Dictionary<int ,LeagueHolder> m_dict_LeagueHolder = new Dictionary<int ,LeagueHolder>();
    static Dictionary<int ,LeagueShopHolder> m_dict_LeagueShopHolder = new Dictionary<int ,LeagueShopHolder>();
    static Dictionary<int ,DirtywordContent> m_dict_DirtywordContent = new Dictionary<int ,DirtywordContent>();
    static Dictionary<int ,DragoncrystalContent> m_dict_DragoncrystalContent= new Dictionary<int ,DragoncrystalContent>();


#endif
    protected Dictionary<int, T> m_Dict;

    public void Init(List<FileStreamElement> arraylist)
    {
        if (null == m_Dict) m_Dict = new Dictionary<int, T>();
        else m_Dict.Clear();

        foreach (FileStreamElement array in arraylist)
        {
            T element = new T();
            element.Init(array);

            if (m_Dict.ContainsKey(element.Key))
            {
                Debug.Log(GetType().ToString() + "has the same key:" + element.Key);
                continue;
            }

            m_Dict.Add(element.Key, element);
        }
    }

    public Dictionary<int, T> GetDict()
    {
        return m_Dict;
    }

    public T GetStaticInfo(uint key)
    {
        if (null == m_Dict) return null;
        T t = null;
        m_Dict.TryGetValue((int)key, out t);

        if (t == null && key != 0)
        {
            Debug.LogError("can't fing id:" + key + " in staticdata:" + GetType().ToString());
        }
        return t;
    }

    public T GetStaticInfo(int key)
    {
        if (null == m_Dict) return null;
        T t = null;
        m_Dict.TryGetValue(key, out t);
        if (t == null && key != 0)
        {
            Debug.LogError("can't fing id:" + key + " in staticdata:" + GetType().ToString());
        }
        return t;
    }

}

public abstract class BaseContent
{
    public int Key;
    public virtual void Init(FileStreamElement element)
    {
        Key = element.intList[0];
    }
}

public class CommonFunction
{
    public static List<int> GetSounds(List<string> sounds)
    {
        List<int> soundList = new List<int>();
        for (int i = 0, len = sounds.Count; i < len; i++)
        {
            string[] playsounds = sounds[i].Split(new char[] { '$' });  
            int index = UnityEngine.Random.Range(0, playsounds.Length);
            int soundId = Convert.ToInt32(playsounds[index]);
            soundList.Add(soundId);
        }
        return soundList;
    }
}


public class CommonHolder
{
    /***************************仅支持这么多类型,不能再扩展******/
    public static string GetString(object s)
    {
        return Convert.ToString(s);
    }

    public static double GetDouble(object s)
    {
        try
        {
            return Convert.ToDouble(s);
        }
        catch
        {
            return 0;
        }
    }

    public static float GetSingle(object s)
    {
        try
        {
            return Convert.ToSingle(s);
        }
        catch
        {
            return 0;
        }
    }


    public static int GetInt32(object s)
    {
        try
        {
            return Convert.ToInt32(s);
        }
        catch
        {
            return 0;
        }

    }


    public static bool GetBoolean(object s)
    {
        string str = Convert.ToString(s);
        bool result = (str.Equals("0") ? false : true);

        return result;
    }

    public static byte GetByte(object s)
    {
        try
        {
            return Convert.ToByte(s);
        }
        catch
        {
            return 0;
        }
    }
    //将值转为List;
    public static List<byte> TransStrToByteList(object arg, char[] separator)
    {
        List<byte> list = new List<byte>();

        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            if (string.IsNullOrEmpty(strs[i])) continue;
            //if (strs[i].Equals("0")) continue;
            byte tmp = GetByte(strs[i]);
            list.Add(tmp);
        }

        return list;
    }

    public static List<int> TransStrToIntList(object arg, char[] separator)
    {
        List<int> list = new List<int>();
        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            if (string.IsNullOrEmpty(strs[i])) continue;
            //if (strs[i].Equals("0")) continue;
            int tmp = GetInt32(strs[i]);
            list.Add(tmp);
        }

        return list;
    }

    public static List<float> TransStrToFloatList(object arg, char[] separator)
    {
        List<float> list = new List<float>();
        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            if (string.IsNullOrEmpty(strs[i])) continue;
            //if (strs[i].Equals("0")) continue;
            float tmp = GetSingle(strs[i]);
            list.Add(tmp);
        }

        return list;
    }

    public static List<double> TransStrToDoubleList(object arg, char[] separator)
    {
        List<double> list = new List<double>();
        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            if (string.IsNullOrEmpty(strs[i])) continue;
            //if (strs[i].Equals("0")) continue;
            double tmp = GetDouble(strs[i]);
            list.Add(tmp);
        }

        return list;
    }

    public static List<string> TransStrToStringList(object arg, char[] separator)
    {
        List<string> list = new List<string>();
        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            //if (strs[i].Equals("0")) continue;
            list.Add(strs[i]);
        }

        return list;

    }

    public static List<Vector3> TransStrToVector3List(object arg, char[] separator1, char[] separator2)
    {
        List<Vector3> list = new List<Vector3>();
        string str = Convert.ToString(arg);
        string[] strs = str.Split(separator1);

        for (int i = 0, len = strs.Length; i < len; ++i)
        {
            string[] strs2 = strs[i].Split(separator2);
            if (strs2.Length == 3)
            {
                float x = GetSingle(strs2[0]);
                float y = GetSingle(strs2[1]);
                float z = GetSingle(strs2[2]);

                list.Add(new Vector3(x, y, z));
            }
        }

        return list;

    }

    public static Vector2 TransToVector2(object arg, char[] separator)
    {
        Vector2 src;

        string str = Convert.ToString(arg);
        if (str.Equals("0")) return Vector3.zero;
        string[] strs = str.Split(separator);
        if (strs.Length != 2)
        {
            return Vector3.zero;
        }

        float x = GetSingle(strs[0]);
        float y = GetSingle(strs[1]);
        src = new Vector2(x, y);

        return src;
    }

    public static Vector3 TransToVector3(object arg, char[] separator)
    {
        Vector3 src;
        string str = Convert.ToString(arg);
        if (str.Equals("0")) return Vector3.zero;

        string[] strs = str.Split(separator);
        if (strs.Length != 3)
        {
            return Vector3.zero;
        }

        float x = GetSingle(strs[0]);
        float y = GetSingle(strs[1]);
        float z = GetSingle(strs[2]);
        src = new Vector3(x, y, z);

        return src;
    }

    public static Vector4 TransToVector4(object arg, char[] separator)
    {
        Vector4 src;
        string str = Convert.ToString(arg);
        if (str == "0") return Vector4.zero;

        string[] strs = str.Split(separator);
        if (strs.Length != 4)
        {
            return Vector3.zero;
        }


        float x = GetSingle(strs[0]);
        float y = GetSingle(strs[1]);
        float z = GetSingle(strs[2]);
        float w = GetSingle(strs[3]);

        src = new Vector4(x, y, z, w);
        return src;
    }
    public static Rect TransToRect(object arg, char[] separator)
    {
        Rect src = new Rect();
        string str = Convert.ToString(arg);
        if (str.Equals("0")) return src;
        string[] strs = str.Split(separator);
        if (strs.Length != 4)
        {
            return src;
        }
        src.x = GetSingle(strs[0]);
        src.y = GetSingle(strs[1]);
        src.height = GetSingle(strs[2]);
        src.width = GetSingle(strs[3]);
        return src;
    }

    //将表里的值转为颜色
    public static Color TransStrToColor(object arg, char[] separator)
    {
        Color color = Color.white;
        string str = Convert.ToString(arg);
        if (str.Equals("0")) return Color.white;

        string[] strs = str.Split(separator);
        if (strs.Length != 3)
        {
            return color;
        }

        color.r = GetSingle(strs[0]) / 255.0f;
        color.g = GetSingle(strs[1]) / 255.0f;
        color.b = GetSingle(strs[2]) / 255.0f;
        return color;
    }

    public static List<BaseIntContent> TransStrToListIntClass(object arg, char[] separator1, char[] separator2)
    {
        List<BaseIntContent> list = new List<BaseIntContent>();
        string str = Convert.ToString(arg); ;
        string[] strs = str.Split(separator1);
        for (int i = 0; i < strs.Length; ++i)
        {
            string[] strs2 = strs[i].Split(separator2);

            BaseIntContent tmp = new BaseIntContent();
            tmp.list = new List<int>();
            for (int j = 0; j < strs2.Length; ++j)
            {
                if (string.IsNullOrEmpty(strs2[j])) continue;
                //if (strs2[j].Equals("0")) continue;
                tmp.list.Add(GetInt32(strs2[j]));
            }
            list.Add(tmp);
        }
        return list;
    }

    public static List<BaseStringContent> TransStrToListStringClass(object arg, char[] separator1, char[] separator2)
    {
        List<BaseStringContent> list = new List<BaseStringContent>();
        string str = Convert.ToString(arg); ;
        string[] strs = str.Split(separator1);
        for (int i = 0; i < strs.Length; ++i)
        {
            string[] strs2 = strs[i].Split(separator2);

            BaseStringContent tmp = new BaseStringContent();
            tmp.list = new List<string>();
            for (int j = 0; j < strs2.Length; ++j)
            {
                if (string.IsNullOrEmpty(strs2[j])) continue;
                //if (strs2[j].Equals("0")) continue;
                tmp.list.Add(GetString(strs2[j]));
            }

            list.Add(tmp);
        }
        return list;
    }

    public static List<BaseFloatContent> TransStrToListFloatClass(object arg, char[] separator1, char[] separator2)
    {
        List<BaseFloatContent> list = new List<BaseFloatContent>();
        string str = Convert.ToString(arg); ;
        string[] strs = str.Split(separator1);
        for (int i = 0; i < strs.Length; ++i)
        {
            string[] strs2 = strs[i].Split(separator2);

            BaseFloatContent tmp = new BaseFloatContent();
            tmp.list = new List<float>();
            for (int j = 0; j < strs2.Length; ++j)
            {
                if (string.IsNullOrEmpty(strs2[j])) continue;
                //if (strs2[j].Equals("0")) continue;
                tmp.list.Add(GetSingle(strs2[j]));
            }

            list.Add(tmp);
        }
        return list;
    }
}