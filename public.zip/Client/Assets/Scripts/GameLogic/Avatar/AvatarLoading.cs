﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AvatarLoading : StageLoading
{
    private int indexOf = 0;

    protected CObject avatarLoad;
    protected CObject weaponRight;
    protected CObject weaponLeft;
    protected CObject headwearLoad;
    protected CObject atkDragoncrystalObj;
    protected CObject defDragoncrystalObj;

    protected CBaseHomeAvatar avatarInfo;

    protected uint uiClothId = 0;
    protected uint uiWeaponId = 0;
    protected uint uiJobID = 0;
    protected uint uiAttackDragoncrystalID;//攻击龙晶
    protected uint uiDefenceDragoncrystalID;//防御龙晶

    protected Vector3 localAvatarPosition = new Vector3(0f, -0.83f, 3.5f);
    protected Vector3 localAvatarRotation = new Vector3(5.0f, 180.0f, 0);
    protected Vector3 localAvatarScale = Vector3.one;
    private eNpcNameType npcNameType = eNpcNameType.None;
    protected Vector3 localNpcRotation = new Vector3(5.0f, 180.0f, 0);

    private bool m_bDeleted;

    private CObject m_texture2D;

    private CObject m_leftWeaponTexture;
    private CObject m_rigthWeaponTexture;

    private string m_modelPath;

    private string m_modelTexPath;
    private string m_leftWeaponTexPath;
    private string m_rightWeaponTexPath;
    private string m_leftWeaponPath;
    private string m_rightWeaponPath;
    private string m_atkDragoncrystalPath;
    private string m_defDragoncrystalPath;

    protected GameObject avatarObj;

    private bool m_bAvatar;

    private uint npcId;

    public AvatarLoading(bool bLoop, bool blimit = true)
        : base(bLoop, blimit)
    {
        StageType = eObjectType.HomeAvatar;
        m_bDeleted = false;
    }

    public virtual void InitAvatar(CBaseHomeAvatar baseAvatar,eBattleType battleType = eBattleType.PVE, eNpcNameType type = eNpcNameType.None)
    {
        m_bDeleted = false;
        npcNameType = type;
        avatarInfo = baseAvatar;
        uiJobID = baseAvatar.GetHomeAvatarInfo().uiPlayerJob;
        uiClothId = baseAvatar.GetHomeAvatarInfo().uiClothesID;
        uiWeaponId = baseAvatar.GetHomeAvatarInfo().uiWeaponID;


        List<CrystalItemInfo> atkCryItem = LongjingManager.GetInst().GetLongJingList(battleType, eLongJingPos.Attack);
        List<CrystalItemInfo> defCryItem = LongjingManager.GetInst().GetLongJingList(battleType, eLongJingPos.Defense);
        if (atkCryItem.Count > 0)
        {
            uiAttackDragoncrystalID = atkCryItem[0].uiCrystalId;
        }

        if (defCryItem.Count > 0)
        {
            uiDefenceDragoncrystalID = defCryItem[0].uiCrystalId;
        }

        base.Init(baseAvatar.GetHomeAvatarInfo().uiPlayerJob);
        LoadCloth();
    }

    public void CreateBackStage(string stageAvatar = null)
    {
        base.CreateStage(stageAvatar);
    }

    //public void CreateAvatar(CBaseHomeAvatar baseAvatar)
    //{
    //    m_bDeleted = false;

    //    avatarInfo = baseAvatar;
    //    uiJobID = baseAvatar.GetHomeAvatarInfo().uiPlayerJob;
    //    uiClothId = baseAvatar.GetHomeAvatarInfo().uiClothesID;
    //    uiWeaponId = baseAvatar.GetHomeAvatarInfo().uiWeaponID;
    //    uiAttackDragoncrystalID = baseAvatar.GetHomeAvatarInfo().uiAttackCrystalId;
    //    uiDefenceDragoncrystalID = baseAvatar.GetHomeAvatarInfo().uiDefenceCrystalId;
    //    base.Init(uiJobID);
    //    CreateBackStage();
    //    LoadCloth();
    //}
    public void CreateAvatar(EnemyInfoData avatarData, bool bcreatbg = true)
    {
        m_bDeleted = false;

        uiJobID = avatarData.uiJob;
        uiClothId = avatarData.uiEquipID;
        uiWeaponId = avatarData.uiWeaponID;
        uiAttackDragoncrystalID = avatarData.uiAttackDragoncrystalID;
        uiDefenceDragoncrystalID = avatarData.uiDefenceDragoncrystalID;
        base.Init(uiJobID);
        if (bcreatbg)
            CreateBackStage();
        LoadCloth();
    }

    public void CreateAvatar(uint jobType, uint clothes, uint weapon, uint uiAtkLongjingID,uint uiDefLongjingID)
    {
        m_bDeleted = false;
        uiJobID = jobType;
        uiClothId = clothes;
        uiWeaponId = weapon;
        uiAttackDragoncrystalID = uiAtkLongjingID;
        uiDefenceDragoncrystalID = uiDefLongjingID;
        base.Init(uiJobID);
        LoadCloth();
    }

    #region 加载NPC

    /// <summary>
    /// 创建Npc Avatar,非主角外的模型。
    /// </summary>
    /// <param name="id">对应monster 或者对应homenpc的ID </param>
    /// bSystemOpen 是否是功能开放的3渲染2
    public void CreatNpc(uint id, bool bSystemOpen = false, eNpcNameType type = eNpcNameType.None)
    {
        m_bAvatar = false;
        npcNameType = type;
        Vector3 tempcamerapos = Vector3.zero;
        m_modelPath = "";
        m_modelTexPath = "";
        npcId = id;
        if (id.ToString().StartsWith("1"))
        {
            HomeNPCContent npcLoader = HolderManager.m_HomeNPCHolder.GetStaticInfo(id);
            if (npcLoader != null)
            {
                m_modelPath = npcLoader.ResPath;
                m_animatorPath = m_modelPath.Replace("_model", "_ctrl");

                if (bSystemOpen)
                {
                    //localNpcRotation = npcLoader.NpcRation;
                    tempcamerapos = npcLoader.NpcSystemOpenCameraPos;
                    CameraTrans.localPosition = tempcamerapos;
                }
                else
                {
                    //localNpcRotation = npcLoader.NpcRation;
                    tempcamerapos = npcLoader.NpcCameraPos;
                    if (type == eNpcNameType.Left)
                    {

                        CameraTrans.localPosition = new Vector3(tempcamerapos.x * Screen.width / 1024f, tempcamerapos.y, tempcamerapos.z);
                    }
                    else if (type == eNpcNameType.Right)
                    {
                        CameraTrans.localPosition = new Vector3(-tempcamerapos.x * Screen.width / 1024f, tempcamerapos.y, tempcamerapos.z);
                    }
                }

                uiClothId = 0;
                uiWeaponId = 0;
            }
        }
        else
        {
            MonsterContent monsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(id);
            if (monsterLoader != null)
            {
                if (null != monsterLoader.ModelLoader)
                {
                    m_modelPath = monsterLoader.ModelLoader.Path;
                    m_animatorPath = monsterLoader.ModelLoader.AniPath;
                    m_modelTexPath = monsterLoader.ModelLoader.TextureName;
                    tempcamerapos = monsterLoader.ModelLoader.PoltCameraPos;
                    uiClothId = 0;
                    uiWeaponId = (uint)monsterLoader.WeaponID;
                    //CameraTrans.localPosition = new Vector3(tempcamerapos.x * Screen.width / 1024f, tempcamerapos.y, tempcamerapos.z);
                    if (type == eNpcNameType.Left)
                    {
                        CameraTrans.localPosition = new Vector3(tempcamerapos.x * Screen.width / 1024f, tempcamerapos.y, tempcamerapos.z);
                    }
                    else if (type == eNpcNameType.Right)
                    {
                        CameraTrans.localPosition = new Vector3(-tempcamerapos.x * Screen.width / 1024f, tempcamerapos.y, tempcamerapos.z);
                    }

                }
                
                //localNpcRotation = monsterLoader.poltAvatarRation == Vector3.zero ? new Vector3(5.0f, 180.0f, 0) : monsterLoader.poltAvatarRation;
            }
        }



        cam.rect = new Rect(DEFINE.CAMERA_STORY_NPC_RECT_X, 0, 1, 1);

        SetWeaponPath(uiWeaponId);

        AddStart();
        AddLoadState(m_modelPath);
        AddLoadState(m_animatorPath);
        AddLoadState(m_modelTexPath);
        AddLoadState(m_leftWeaponTexPath);
        AddLoadState(m_rightWeaponTexPath);
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddOver();
    }

    private void SetWeaponPath(uint uiWeaponID)
    {
        EquipContent weapon = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponId);
        if (weapon != null)
        {
            List<string> texturePath = weapon.ModelLoader.TexturePath;
            List<string> pathList = weapon.ModelLoader.ModelPath;

            if (texturePath.Count == 2)
            {
                m_leftWeaponTexPath = texturePath[0];
                m_rightWeaponTexPath = texturePath[1];
            }
            else
            {
                m_leftWeaponTexPath = "";
                m_rightWeaponTexPath = "";
            }

            if (pathList.Count == 2)
            {
                m_leftWeaponPath = pathList[0];
                m_rightWeaponPath = pathList[1];
            }



        }
        else
        {
            m_leftWeaponTexPath = "";
            m_rightWeaponTexPath = "";
            m_leftWeaponPath = "";
            m_rightWeaponPath = "";
        }
    }

    private void SetDragoncrystalPath(uint uiLongjingID, eDragonshardType type)
    {
        DragoncrystalContent pDragonContent = HolderManager.m_DragoncrystalHolder.GetStaticInfo(uiLongjingID);
        if (null == pDragonContent)
        {
            return;
        }

        ParticleContent pParticleContent = HolderManager.m_ParticleHolder.GetStaticInfo(pDragonContent.CrystalAndEnchantEffect[0]);
        if (null == pParticleContent)
        {
            return;
        }

        if (type == eDragonshardType.avatarAttack)
        {
            m_atkDragoncrystalPath = pParticleContent.Path;
        }
        else if (type == eDragonshardType.avatarDef)
        {
            m_defDragoncrystalPath = pParticleContent.Path;
        }
       
    }



    public override void PreloadCompleted()
    {
        if (!m_bAvatar)
        {
            if (m_modelTexPath.Equals("") || m_modelTexPath.Equals("0"))
            {
                m_texture2D = null;

                if (!string.IsNullOrEmpty(m_modelPath))
                {
                    avatarLoad = new CObject(m_modelPath);
                    avatarLoad.CallBack = LoadNpcCompleted;
                    avatarLoad.IsMemoryFactory = true;
                    avatarLoad.ObjectType = StageType;
                    avatarLoad.Layer = DEFINE.AVATAR_LAYER;
                    avatarLoad.LoadObject();

                }
                else
                {
                    MyLog.LogError("path is null.");
                }
            }
            else
            {
                m_texture2D = new CObject(m_modelTexPath);
                m_texture2D.IsMemoryFactory = true;
                m_texture2D.ObjectType = eObjectType.Texture;
                m_texture2D.CallBack = LoadTextureCompleted;
                m_texture2D.LoadObject();
            }
        }
        else
        {

            avatarLoad = new CObject(m_modelPath);
            avatarLoad.CallBack = LoadClothCompleted;
            avatarLoad.IsMemoryFactory = true;
            avatarLoad.ObjectType = StageType;
            avatarLoad.Layer = DEFINE.AVATAR_LAYER;
            avatarLoad.LoadObject();
        }


    }

    protected void LoadTextureCompleted(GameObject obj, params object[] args)
    {
        if (!string.IsNullOrEmpty(m_modelPath))
        {
            avatarLoad = new CObject(m_modelPath);
            avatarLoad.CallBack = LoadNpcCompleted;
            avatarLoad.IsMemoryFactory = true;
            avatarLoad.ObjectType = StageType;
            avatarLoad.Layer = DEFINE.AVATAR_LAYER;
            avatarLoad.LoadObject();
        }
        else
        {
            MyLog.LogError("path is null.");
        }
    }
    Vector3 direct = Vector3.zero;
    public virtual void LoadNpcCompleted(GameObject npc, params object[] args)
    {
        if (npc == null)
        {
            return;
        }
        direct = npc.transform.forward;
        DynamicShader.SetMaterialToVertexLight(npc, eNpcRenderType.SkinMeshRender, direct);
        //DynamicShader.SetMaterialToVertex(npc, eNpcRenderType.SkinMeshRender);        
        avatarObj = npc;

        npc.SetActive(false);

        npc.transform.parent = GetParent;
        npc.transform.localPosition = localAvatarPosition;
        if (npcNameType == eNpcNameType.Left)
        {
            npc.transform.localEulerAngles = localNpcRotation;
        }
        else if (npcNameType == eNpcNameType.Right)
        {
            npc.transform.localEulerAngles = new Vector3(localNpcRotation.x, 360 - localNpcRotation.y, localNpcRotation.z);
        }
        else
        {
            npc.transform.localEulerAngles = new Vector3(5.0f, 180.0f, 0);
        }

        npc.transform.localScale = Vector3.one;

        Rigidbody[] rigidbodys = avatarObj.GetComponentsInChildren<Rigidbody>(true);

        //#用布娃娃
        if (rigidbodys != null)
        {
            for (int i = 0, len = rigidbodys.Length; i < len; i++)
            {
                Rigidbody rigid = rigidbodys[i];
                if (rigid.name == avatarObj.transform.name)
                {
                    continue;
                }
                rigid.isKinematic = true;
                rigid.detectCollisions = false;
            }
        }

        //赋予贴图
        if (m_texture2D != null)
        {
            SkinnedMeshRenderer[] smrs = npc.GetComponentsInChildren<SkinnedMeshRenderer>(true);

            foreach (SkinnedMeshRenderer smr in smrs)
            {
                smr.material.mainTexture = m_texture2D.PTexture2D;
            }
        }


        DynamicShader.ReplaceUnSupportShader(npc);

        if (npcId == (uint)eHomeNpcType.LongQiMic)
        {
            npc.transform.localEulerAngles = new Vector3(270f, 270.0f, 0);
            npc.SetActive(true);
            return;
        }

        LoadHelp.LoadObject("", m_animatorPath, ThreadPriority.Normal, LoadNpcAcnimatorCtrl);

        Common.ShowAvatarClothes(npc, false);

        //加载武器,其他
        LoadWeapon();

    }

    private void LoadNpcAcnimatorCtrl(string interim, Object asset)
    {
        GameObject go = (GameObject)asset;
        if (go == null)
        {
            MyLog.Log("load npc faild" + m_modelPath);
            return;
        }
        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }
        if (null == avatarObj)
        {
            MyLog.LogError(" can not find avatarObj ");
            return;
        }

        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //         if (avaAnimator == null)
        //         {
        //             avaAnimator = avatarObj.AddComponent<Animator>();
        //         }

        //         avaAnimator.enabled = true;
        //         avaAnimator.applyRootMotion = false;
        //         avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //         avaAnimator.avatar = animator.avatar;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");


        if (avatarObj != null)
        {
            avatarObj.SetActive(true);
        }

    }
    #endregion

    public void CreateAvatar(string strStage, uint jobType, uint clothes, uint weapon)
    {
        m_bDeleted = false;

        uiJobID = jobType;
        uiClothId = clothes;
        uiWeaponId = weapon;
        base.Init(uiJobID);
        if (LoadStage)
        {
            CreateBackStage(strStage);
        }
        //else
        //{
        //    CreateBackStage();
        //}
        LoadCloth();
    }

    //加载衣服，也就基本模型
    private void LoadCloth()
    {
        EquipContent cloth = null;
        uint clothId = uiClothId;
        m_bAvatar = true;
        cloth = HolderManager.m_EquipHolder.GetStaticInfo(clothId);
        if (cloth == null)
        {
            return;
        }
        List<string> pathList = cloth.ModelLoader.ModelPath;
        if (pathList == null || pathList.Count <= 0 || pathList[0] == "0")
        {
            return;
        }

        m_modelPath = pathList[0];
        PlayerContent animatorInfo = HolderManager.m_PlayerHolder.GetStaticInfo(uiJobID);
        if (animatorInfo != null)
        {
            //m_animatorPath = animatorInfo.GetAmimatorPath();
            m_animatorPath = Common.ReplaceHomeAniPath(animatorInfo.AmimatorPath);
        }
        else
        {
            m_animatorPath = "";
        }

        SetWeaponPath(uiWeaponId);
        SetDragoncrystalPath(uiAttackDragoncrystalID, eDragonshardType.avatarAttack);
        SetDragoncrystalPath(uiDefenceDragoncrystalID, eDragonshardType.avatarDef);

        AddStart();
        AddLoadState(m_modelPath);
        AddLoadState(m_animatorPath);
        AddLoadState(m_leftWeaponTexPath);
        AddLoadState(m_rightWeaponTexPath);
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddLoadState(m_atkDragoncrystalPath);
        AddLoadState(m_defDragoncrystalPath);
        AddOver();
    }

    private void LoadWeaponTexture(uint weaponID)
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(weaponID);

        if (weapon == null)
        {
            return;
        }
        List<string> texturePath = weapon.ModelLoader.TexturePath;
        List<string> pathList = weapon.ModelLoader.ModelPath;

        int weaponCount = pathList.Count;

        if (texturePath != null && texturePath.Count == 2)
        {
            if (weaponCount >= 1 && !texturePath[0].Equals("0"))
            {
                m_leftWeaponTexture = new CObject(texturePath[0]);
                m_leftWeaponTexture.IsMemoryFactory = true;
                m_leftWeaponTexture.ObjectType = eObjectType.Texture;
                m_leftWeaponTexture.LoadObject();
            }

            if (weaponCount >= 2 && !texturePath[1].Equals("0"))
            {
                m_rigthWeaponTexture = new CObject(texturePath[1]);
                m_rigthWeaponTexture.IsMemoryFactory = true;
                m_rigthWeaponTexture.ObjectType = eObjectType.Texture;
                m_rigthWeaponTexture.LoadObject();
            }
        }

        if (pathList.Count == 2)
        {
            LoadWeapon(true, pathList[0]);
            LoadWeapon(false, pathList[1]);
        }

    }

    public void LoadWeapon(bool left, string path)
    {
        if (path.Equals("0"))
        {
            return;
        }

        if (left)
        {
            if (weaponLeft != null)
                weaponLeft.DestroyGameObject(eObjectDestroyType.Memory);
            weaponLeft = new CObject(path);
            //weaponLeft.Name = "weaponL" + weapon.GetKey().ToString();
            weaponLeft.CallBack = LoadWeaponLeftCompleted;
            weaponLeft.IsMemoryFactory = true;
            weaponLeft.ObjectType = eObjectType.Weapon;
            weaponLeft.Layer = DEFINE.AVATAR_LAYER;
            weaponLeft.LoadObject();
        }
        else
        {
            if (weaponRight != null)
                weaponRight.DestroyGameObject(eObjectDestroyType.Memory);
            weaponRight = new CObject(path);
            //weaponRight.Name = "weaponR" + weapon.GetKey().ToString();
            weaponRight.CallBack = LoadWeaponRightCompleted;
            weaponRight.IsMemoryFactory = true;
            weaponRight.ObjectType = eObjectType.Weapon;
            weaponRight.Layer = DEFINE.AVATAR_LAYER;
            weaponRight.LoadObject();
        }
    }
    //加载玩家武器
    private void LoadWeapon()
    {
        LoadWeaponTexture(uiWeaponId);
    }

    //加载龙晶
    private void LoadDragoncrystal()
    {
        if (uiAttackDragoncrystalID != 0 && !string.IsNullOrEmpty(m_atkDragoncrystalPath))
        {
            atkDragoncrystalObj = new CObject(m_atkDragoncrystalPath);
            atkDragoncrystalObj.Name = uiAttackDragoncrystalID.ToString();
            atkDragoncrystalObj.CallBack = LoadDragoncrystalCompleted;
            atkDragoncrystalObj.IsMemoryFactory = true;
            atkDragoncrystalObj.ObjectType = eObjectType.LongJing;
            atkDragoncrystalObj.Layer = DEFINE.AVATAR_LAYER;
            atkDragoncrystalObj.LoadObject();
        }

        if (uiDefenceDragoncrystalID != 0 && !string.IsNullOrEmpty(m_defDragoncrystalPath))
        {
            defDragoncrystalObj = new CObject(m_defDragoncrystalPath);
            defDragoncrystalObj.Name = uiDefenceDragoncrystalID.ToString();
            defDragoncrystalObj.CallBack = LoadDragoncrystalCompleted;
            defDragoncrystalObj.IsMemoryFactory = true;
            defDragoncrystalObj.ObjectType = eObjectType.LongJing;
            defDragoncrystalObj.Layer = DEFINE.AVATAR_LAYER;
            defDragoncrystalObj.LoadObject();
        }
        
    }

    private void LoadDragoncrystalCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        o.transform.parent = avatarObj.transform;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;
    }

    //重新加载龙晶
    public void ReloadDragoncrystal(eBattleType type)
    {
        //获取龙晶信息
        List<CrystalItemInfo> atkCryItem = LongjingManager.GetInst().GetLongJingList(type, eLongJingPos.Attack);
        List<CrystalItemInfo> defCryItem = LongjingManager.GetInst().GetLongJingList(type, eLongJingPos.Defense);

        if (atkDragoncrystalObj != null)
        {
            atkDragoncrystalObj.DestroyGameObject(eObjectDestroyType.Memory);
            atkDragoncrystalObj = null;
        }

        if (defDragoncrystalObj != null)
        {
            defDragoncrystalObj.DestroyGameObject(eObjectDestroyType.Memory);
            defDragoncrystalObj = null;
        }

        if (atkCryItem.Count > 0)
        {
            uiAttackDragoncrystalID = atkCryItem[0].uiCrystalId;
            SetDragoncrystalPath(uiAttackDragoncrystalID, eDragonshardType.avatarAttack);
        }
        else
        {
            uiAttackDragoncrystalID = 0;
            m_atkDragoncrystalPath = null;
        }

        if (defCryItem.Count > 0)
        {
            uiDefenceDragoncrystalID = defCryItem[0].uiCrystalId;
            SetDragoncrystalPath(uiDefenceDragoncrystalID, eDragonshardType.avatarDef);
        }
        else
        {
            uiDefenceDragoncrystalID = 0;
            m_defDragoncrystalPath = null;
        }

        LoadDragoncrystal();
    }

    //加载动画控件
    public void LoadAnimator()
    {
        PlayerContent animatorInfo = HolderManager.m_PlayerHolder.GetStaticInfo(uiJobID);
        if (animatorInfo == null)
        {
            return;
        }

        string szPath = Common.ReplaceHomeAniPath(animatorInfo.AmimatorPath);

        LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadAcnimatorControl);
    }

    public override void LoadStageCompleted(GameObject stage, params object[] args)
    {
        base.LoadStageCompleted(stage, args);
        if (avatarLoad != null)
        {
            if (avatarLoad.GetObj() != null)
            {
                //这里暂时先写死,到时候美术弄好，读表或者，直接加载
                Quaternion localRotation = Quaternion.Euler(new Vector3(5.0f, 180.0f, 0));
                avatarLoad.GetObj().transform.localPosition = new Vector3(-0.09f, -0.83f, 3.5f);
                avatarLoad.GetObj().transform.localRotation = localRotation;
                avatarLoad.GetObj().transform.localScale = Vector3.one;
            }
        }

    }

    public virtual void LoadClothCompleted(GameObject cloth, params object[] args)
    {

        if (cloth == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            return;
        }

        avatarObj = cloth;

        avatarObj.SetActive(false);


        Common.ShowAvatarClothes(cloth, false);

        //if (CameraTrans !=null)
        //{
        //    DynamicShader.SetMaterialToVertexLight(cloth,eNpcRenderType.SkinMeshRender, CameraTrans.forward);
        //}
        NavMeshAgent nma = cloth.GetComponent<NavMeshAgent>();
        if (nma != null)
            nma.enabled = false;
        cloth.transform.parent = GetParent;
        //这里暂时先写死,到时候美术弄好，读表或者，直接加载
        cloth.transform.localPosition = localAvatarPosition;
        cloth.transform.localEulerAngles = localAvatarRotation;
        cloth.transform.localScale = localAvatarScale;
        if (npcNameType == eNpcNameType.Left)
        {
            cloth.transform.localEulerAngles = new Vector3(localNpcRotation.x, localNpcRotation.y - 40, localNpcRotation.z);
        }
        else if (npcNameType == eNpcNameType.Right)
        {
            cloth.transform.localEulerAngles = new Vector3(localNpcRotation.x, 10 + localNpcRotation.y, localNpcRotation.z);
        }
        else if (npcNameType == eNpcNameType.Middle)
        {
            cloth.transform.localEulerAngles = localNpcRotation;
        }
       
        AddSpinMouse(avatarObj);
        direct = -cloth.transform.forward;
        DynamicShader.SetMaterialToVertexLight(cloth, eNpcRenderType.SkinMeshRender, direct);

        //DynamicShader.SetMaterialToVertex(cloth, eNpcRenderType.SkinMeshRender);
        DynamicShader.ReplaceUnSupportShader(cloth);

        LoadAnimator();
        LoadWeapon();
        //加载武器,其他
        LoadDragoncrystal();

    }
    public virtual void LoadWeaponLeftCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            return;
        }
        Transform boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        if (boneTran == null)
        {
            boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        }
        if (null == weapon)
        {
            return;
        }
        weapon.transform.parent = boneTran;
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        weapon.transform.localScale = Vector3.one;
        DynamicShader.ReplaceUnSupportShader(weapon);
        if (m_leftWeaponTexture != null)
            weapon.renderer.material.mainTexture = m_leftWeaponTexture.PTexture2D;

        if (avatarObj != null)
        {
            DynamicShader.SetMaterialToVertexLight(weapon, eNpcRenderType.MeshRender, direct);

            //DynamicShader.SetMaterialToVertex(weapon, eNpcRenderType.MeshRender);
        }
    }
    public virtual void LoadWeaponRightCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            return;
        }
        Transform boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        if (boneTran == null)
        {
            boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        }
        if (null == weapon)
        {
            return;
        }
        weapon.transform.parent = boneTran;
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        weapon.transform.localScale = Vector3.one;

        DynamicShader.ReplaceUnSupportShader(weapon);

        if (m_rigthWeaponTexture != null)
            weapon.renderer.material.mainTexture = m_rigthWeaponTexture.PTexture2D;

        if (avatarObj != null)
        {
            DynamicShader.SetMaterialToVertexLight(weapon, eNpcRenderType.MeshRender, direct);

            //DynamicShader.SetMaterialToVertex(weapon, eNpcRenderType.MeshRender);
        }
    }

    public virtual void LoadAcnimatorControl(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("e:" + interim); return; }
        GameObject go = (GameObject)asset;
        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
        }
        if (avatarObj == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            return;
        }

        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //         if (avaAnimator == null)
        //         {
        //             avaAnimator = avatarObj.AddComponent<Animator>();
        //         }
        //         avaAnimator.enabled = true;
        //         avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //         avaAnimator.avatar = animator.avatar;
        //         avaAnimator.applyRootMotion = false;

        myAnimator = new CAnimator(avaAnimator);
        //avaAnimator.Play("idle");
        myAnimator.PlayAction("idle");

        if (avatarObj != null)
            avatarObj.SetActive(true);
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (AvatarObj != null)
        {
            MuoseSpin spinMouse = AvatarObj.GetComponent<MuoseSpin>();
            if (spinMouse != null)
            {
                GameObject.Destroy(spinMouse);
            }
        }

        if (avatarLoad != null)
        {
            avatarLoad.DestroyGameObject(destroyType);
        }
        if (weaponLeft != null)
        {
            weaponLeft.DestroyGameObject(destroyType);
        }
        if (weaponRight != null)
        {
            weaponRight.DestroyGameObject(destroyType);
        }

        if (atkDragoncrystalObj != null)
        {
            atkDragoncrystalObj.DestroyGameObject(destroyType);
            atkDragoncrystalObj = null;
        }

        if (defDragoncrystalObj != null)
        {
            defDragoncrystalObj.DestroyGameObject(destroyType);
            defDragoncrystalObj = null;
        }

        myAnimator = null;
        base.Release(destroyType);
        m_bDeleted = true;

        if (m_leftWeaponTexture != null)
            m_leftWeaponTexture.DestroyGameObject(eObjectDestroyType.Memory);

        if (m_rigthWeaponTexture != null)
            m_rigthWeaponTexture.DestroyGameObject(eObjectDestroyType.Memory);

        if (m_texture2D != null)
            m_texture2D.DestroyGameObject(eObjectDestroyType.Memory);
    }

    #region get and set
    public int IndexOf
    {
        get { return indexOf; }
        set { this.indexOf = value; }
    }

    public Vector3 LocalAvatarPosition
    {
        get { return localAvatarPosition; }
        set { localAvatarPosition = value; }
    }
    public Vector3 LocalAvatarRotation
    {
        get { return localAvatarRotation; }
        set { localAvatarRotation = value; }
    }
    public Vector3 LocalAvatarScale
    {
        get { return localAvatarScale; }
        set { localAvatarScale = value; }
    }

    public GameObject AvatarObj { get { return avatarObj; } set { avatarObj = value; } }
    #endregion

}
