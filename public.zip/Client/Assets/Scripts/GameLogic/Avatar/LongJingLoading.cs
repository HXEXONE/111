﻿using UnityEngine;
using System.Collections;

public class LongJingLoading : StageLoading
{
    private int indexOf = 0;
    public GameObject avatarObj;
    private CObject avatarLoadObj;
    private CharacterController control;
    private CObject weaponRight;
    private CObject weaponLeft;

    public float mBodyHeight;

    public delegate void OnLoadModelFinish();

    private DragoncrystalContent m_longJingLoader;
    private ParticleContent m_modelLoader;
    private Animator m_animator;

    private string m_modelPath;

    public OnLoadModelFinish onLoadModelFinish;

    public LongJingLoading(bool bLoop, bool blimit = true)
        : base(bLoop,blimit)
    {
        StageType = eObjectType.LongJing;
    }

    public void InitLongJing(uint longJingID)
    {
        base.Init(longJingID);
        LoadLongJing();
    }
    public void CreateLongJingWithBG(uint longJingID)
    {
        base.Init(longJingID);
        CreateBackStage();
        LoadLongJing();
    }

    public void CreateBackStage(string stageEquip = null)
    {
        base.CreateStage(stageEquip);
    }
    public void CreatLongJing(uint longJingID)
    {
        base.Init(longJingID);
        LoadLongJing();
    }
    private void LoadLongJing()
    {
        m_longJingLoader = HolderManager.m_DragoncrystalHolder.GetStaticInfo(avatarID);
        if (m_longJingLoader == null) return;

        m_modelLoader = HolderManager.m_ParticleHolder.GetStaticInfo(m_longJingLoader.CrystalAndEnchantEffect[0]);
        if (m_modelLoader !=null)
        {

            m_modelPath = m_modelLoader.Path;
            //m_animatorpath = m_modelPath.Replace("_model", "_ctrl");


            AddStart();
            AddLoadState(m_modelPath);

            AddOver();
        }


        if (cam != null)
        {
            cam.backgroundColor = new Color(60 / 255f, 60 / 255f, 60 / 255f,0);
        }
        //Quaternion localRotation2 = Quaternion.Euler(m_modelLoader.PartnerRotation);//Quaternion.Euler(new Vector3(5.0f, 178f, 0));
        //localPosition = m_longJingLoader.ModelLoader.PartnerPos;//new Vector3(0f, -0.9f, 3.4f); ;
        //localRotation = localRotation2;


    }
    
    public override void PreloadCompleted()
    {

        avatarLoadObj = new CObject(m_modelPath);
        avatarLoadObj.Name = avatarID.ToString();
        avatarLoadObj.CallBack = LoadAvatarCompleted;
        avatarLoadObj.IsMemoryFactory = true;
        avatarLoadObj.ObjectType = eObjectType.LongJing;
        avatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
        avatarLoadObj.LoadObject();

    }

    private void LoadAvatarCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        avatarObj = o;
        avatarObj.transform.parent = GetParent;
        avatarObj.transform.localPosition = localPosition;
    }

    public void SetLocalPos(Vector3 pos)
    {
        localPosition = pos;
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (avatarLoadObj != null)
        {
            avatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        base.Release(destroyType);
    }
}
