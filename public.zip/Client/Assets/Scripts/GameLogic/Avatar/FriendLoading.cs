﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FriendLoading : StageLoading
{
    private GameObject avatarObj;
    private CObject avatarLoad;
    private CharacterController control;
    private string avatarPath = string.Empty;
    private CObject weaponRight;
    private CObject weaponLeft;

    private NavMeshAgent navMesh;

    private uint uiClothId = 0;
    private uint uiWeaponId = 0;
    private uint uiJobID = 0;

    private string m_modelPath;

    private string m_leftWeaponTexPath;
    private string m_rightWeaponTexPath;
    private string m_leftWeaponPath;
    private string m_rightWeaponPath;

    public FriendLoading(bool bLoop)
        : base(bLoop)
    {
        StageType = eObjectType.HomeAvatar;
    }

    public void InitFriend(uint jobId, uint clothId, uint weaponId)
    {
        this.uiJobID = jobId;
        uiClothId = clothId;
        uiWeaponId = weaponId;
        base.Init(jobId);
        LoadCloth();
    }

    private void LoadCloth()
    {
        EquipContent cloth = null;
        cloth = HolderManager.m_EquipHolder.GetStaticInfo(uiClothId);
        if (cloth == null)
        {
            return;
        }
        List<string> pathList = cloth.ModelLoader.ModelPath;
        if (pathList == null || pathList.Count <= 0 || pathList[0] == "0")
        {
            return;
        }

        m_modelPath = pathList[0];
        PlayerContent animatorInfo = HolderManager.m_PlayerHolder.GetStaticInfo(uiJobID);
        if (animatorInfo != null)
        {
            m_animatorPath = Common.ReplaceHomeAniPath(animatorInfo.AmimatorPath);
        }
        SetWeaponPath(uiWeaponId);


    }

    public override void PreloadCompleted()
    {

        avatarLoad = new CObject(m_modelPath);
        avatarLoad.CallBack = LoadClothCompleted;
        avatarLoad.IsMemoryFactory = true;
        avatarLoad.ObjectType = eObjectType.HomeAvatar;
        avatarLoad.ObjectType = StageType;
        avatarLoad.Layer = DEFINE.AVATAR_LAYER;
        avatarLoad.LoadObject();
    }

    private void SetWeaponPath(uint uiWeaponID)
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponId);
        if (weapon != null)
        {
            List<string> texturePath = weapon.ModelLoader.TexturePath;
            List<string> pathList = weapon.ModelLoader.ModelPath;

            if (texturePath.Count == 2)
            {
                m_leftWeaponTexPath = texturePath[0];
                m_rightWeaponTexPath = texturePath[1];
            }
            else
            {
                m_leftWeaponTexPath = "";
                m_rightWeaponTexPath = "";
            }

            if (pathList.Count == 2)
            {
                m_leftWeaponPath = pathList[0];
                m_rightWeaponPath = pathList[1];
            }
           
        }
        else
        {
            m_leftWeaponTexPath = "";
            m_rightWeaponTexPath = "";
            m_leftWeaponPath = "";
            m_rightWeaponPath = "";
        }
    }

    private void LoadClothCompleted(GameObject cloth, params object[] args)
    {
        if (cloth == null)
        {
            return;
        }
        avatarObj = cloth;
        control = cloth.GetComponent<CharacterController>();
        if (control != null)
        {
            control.enabled = false;
        }
        navMesh = cloth.GetComponent<NavMeshAgent>();
        if (navMesh != null)
        {
            navMesh.enabled = false;
        }
        cloth.transform.parent = GetParent;
        //这里暂时先写死,到时候美术弄好，读表或者，直接加载
        Quaternion localRotation = Quaternion.Euler(new Vector3(5.0f, 178f, 0));
        cloth.transform.localPosition = new Vector3(0f, -1.11f, 3.4f);
        cloth.transform.localRotation = localRotation;
        cloth.transform.localScale = Vector3.one;

        DynamicShader.ReplaceUnSupportShader(cloth);
        LoadAnimator();
        LoadWeapon();
    }

    private void LoadAnimator()
    {
        LoadHelp.LoadObject("animator", m_animatorPath, ThreadPriority.Normal, LoadAcnimatorControl);
    }

    private void LoadAcnimatorControl(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("e:" + interim); return; }
        GameObject go = (GameObject)asset;
        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
        }
        if (avatarObj == null)
        {
            return;
        }
        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
//         if (avaAnimator == null)
//         {
//             avaAnimator = avatarObj.AddComponent<Animator>();
//         }
//         avaAnimator.enabled = true;
//         avaAnimator.applyRootMotion = false;
//         avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
//         avaAnimator.avatar = animator.avatar;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");
    }

    private void LoadWeapon()
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponId);
        if (weapon == null)
        {
            MyLog.LogError("weapon: " + uiWeaponId);
            return;
        }
        List<string> pathList = weapon.ModelLoader.ModelPath;
        if (!pathList[0].Equals("0"))
        {
            weaponLeft = new CObject(pathList[0]);
            weaponLeft.Name = "weaponL" + weapon.Key.ToString();
            weaponLeft.CallBack = LoadWeaponLeftCompleted;
            weaponLeft.IsMemoryFactory = true;
            weaponLeft.ObjectType = eObjectType.Weapon;
            weaponLeft.Layer = DEFINE.AVATAR_LAYER;
            weaponLeft.LoadObject();
        }

        if (!pathList[1].Equals("0"))
        {
            weaponRight = new CObject(pathList[1]);
            weaponRight.Name = "weaponR" + weapon.Key.ToString();
            weaponRight.CallBack = LoadWeaponRightCompleted;
            weaponRight.IsMemoryFactory = true;
            weaponRight.ObjectType = eObjectType.Weapon;
            weaponRight.Layer = DEFINE.AVATAR_LAYER;
            weaponRight.LoadObject();
        }
    }

    public void LoadWeaponLeftCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null || null == weapon)
        {
            return;
        }
        weapon.transform.parent = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        DynamicShader.ReplaceUnSupportShader(weapon);
    }
    public void LoadWeaponRightCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null || null == weapon)
        {
            return;
        }
        weapon.transform.parent = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        DynamicShader.ReplaceUnSupportShader(weapon);
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (null != avatarLoad)
        {
            avatarLoad.DestroyGameObject(eObjectDestroyType.Memory);
        }

        if (null != weaponRight)
        {
            weaponRight.DestroyGameObject(eObjectDestroyType.Memory);
        }

        if (null != weaponLeft)
        {
            weaponLeft.DestroyGameObject(eObjectDestroyType.Memory);
        }

        base.Release(eObjectDestroyType.Memory);
    }
}
