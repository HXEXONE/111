﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;

//public class TowerAvatar : StageLoading
//{
//    private string avatarPath = "resources/cardbackground/prefab/building/pata.x";
//    private int indexOf = 0;
//    private GameObject[] avatarObj;
//    private CObject[] avatarLoadObj;
//    private CharacterController control;
//    private Vector3[] avatarPos = new Vector3[3] { new Vector3(0, 0, 56.64f), new Vector3(0, 16.52f, 56.64f), new Vector3(0, 33.1f, 56.64f) };
//    private Vector3 avatarEulerAngles = new Vector3(270, 180, 0);
//    private int uinltlayer = 40;//每个塔有多少层
//    private int uinltNode = 20;
//    private int mCurrentLayer = 0;
//    private ClimbTowerMediator towerMediator;
//    private GameObject[] m_towerBgObj;//背景

//    public TowerAvatar(bool bLoop)
//        : base( bLoop)
//    {
//        StageType = eObjectType.Tower;
//    }

//    public void InitTower(int layer, ClimbTowerMediator mediator)
//    {
//        towerMediator = mediator;
//        mCurrentLayer = layer;
//        SetPosition(new Vector3(500, 0, 0));
//        LoadTower();
//    }

//    private void LoadTower()
//    {
//        int totallayer = (int)DEFINE.CLIMBTOWER_TOTAL_LAYER;
//        int count = Mathf.CeilToInt((float)totallayer / uinltlayer);
//        avatarLoadObj = new CObject[count];
//        m_towerBgObj = new GameObject[count];
//        avatarObj = new GameObject[count];
//        for (int i = 0; i < count; i++)
//        {
//            AddLoadState(i, false);
//            avatarLoadObj[i] = new CObject(avatarPath);
//            avatarLoadObj[i].Name = "Tower" + i.ToString();
//            avatarLoadObj[i].CallBack = LoadAvatarCompleted;
//            avatarLoadObj[i].Args = new object[] { i };
//            avatarLoadObj[i].IsMemoryFactory = true;
//            avatarLoadObj[i].ObjectType = eObjectType.Tower;
//            avatarLoadObj[i].Layer = DEFINE.AVATAR_LAYER;
//            avatarLoadObj[i].LoadObject();

//            Modelpath = avatarPath;
//        }

//        UISceneContent pUISceneLoader = HolderManager.m_UISceneHolder.GetStaticInfo(DEFINE.UISCENE_PATA_ID);
//        if (null != pUISceneLoader)
//        {
//            LoadHelp.LoadObject("", pUISceneLoader.GetLightmapPath(), ThreadPriority.Normal, LoadLightmapCompleted, false, true);
//        }

       
//    }

//    public void RecoverTowerObj()
//    {
//        //avatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
//    }

//    private void LoadAvatarCompleted(GameObject o, params object[] args)
//    {
//        if (o == null) return;
//        int index = (int)args[0];

//        avatarObj[index] = o;
//        avatarObj[index].transform.parent = GetParent;
//        avatarObj[index].transform.localPosition = avatarPos[index];
//        avatarObj[index].transform.eulerAngles = Vector3.zero;//avatarEulerAngles;
//        avatarObj[index].transform.localScale = Vector3.one;
//        CameraTrans.eulerAngles = new Vector3(0,180,0);
//        CameraTrans.localPosition = new Vector3(6,0,80);
//        GetCamera.fieldOfView = 40;

//        if (index == 0)
//        {
//            m_towerBgObj[index] = avatarObj[index].transform.FindChild("pata_beijing").gameObject;
//            m_towerBgObj[index].transform.parent = CameraTrans;
//        }
//        else
//        {
//            m_towerBgObj[index] = avatarObj[index].transform.FindChild("pata_beijing").gameObject;
//            m_towerBgObj[index].SetActive(false);
//        }


//        for (int i = 0; i < uinltNode; i++)
//        {
//            if (towerMediator.TowerLayerIndex < DEFINE.CLIMBTOWER_TOTAL_LAYER)
//            {
//                GameObject temp = o.transform.FindChild("GameObject/"+(i + 1).ToString()).gameObject;
//                ClimbTowerLayerComponent layer = new ClimbTowerLayerComponent(towerMediator, temp, i, index, towerMediator.m_cuiTexture);
//                layer.SetCamera();
//                layer.panel.SetActive(false);
//                layer.panel.SetActive(true);
//                towerMediator.TowerLayerIndex+=2;
//            }
//        }

//        SetLoadState(index, true);
//    }

//    private void LoadLightmapCompleted(string interim, UnityEngine.Object asset)
//    {
//        LightMapAsset lightmapAsset = asset as LightMapAsset;
//        int Count = lightmapAsset.lightmapFar.Length;
//        LightmapData[] lightmapDatas = new LightmapData[Count];

//        for (int i = 0; i < Count; ++i)
//        {
//            LightmapData Lightmap = new LightmapData();
//            Lightmap.lightmapFar = lightmapAsset.lightmapFar[i];
//            Lightmap.lightmapNear = lightmapAsset.lightmapNear[i];
//            lightmapDatas[i] = Lightmap;
//        }
//        LightmapSettings.lightmaps = lightmapDatas;
//    }

//    //回收，释放内存
//    protected override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
//    {
        
//        if (avatarLoadObj != null)
//        {
//            if (control != null)
//            {
//                control.enabled = true;
//            }
//            for (int i = 0,len =avatarLoadObj.Length; i < len; i++)
//            {
//                m_towerBgObj[i].transform.parent = avatarObj[i].transform;
//                avatarLoadObj[i].DestroyGameObject(destroyType);
//            }
//        }
//        base.Release(destroyType);

//        SingletonObject<HomeScene>.GetInst().ResetLightmap();
//    }


//}
