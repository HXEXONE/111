﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PetLoading : StageLoading {

    private int indexOf = 0;
    public GameObject avatarObj;
    private CObject avatarLoadObj;
    private CharacterController control;
    private string avatarPath = string.Empty;

    private uint petId;

    private int m_index;
    private float m_x;
    private float m_y;
    private float m_z;
    private bool m_replaceModel;

    public PetLoading(bool bLoop,bool bLimit = true)
        : base(bLoop, bLimit)
    {
        StageType = eObjectType.Pet;
    }
    /// <summary>
    /// 单独加载宠物模型display 需要
    /// </summary>
    /// <param name="PetID"></param>
    public void InitPet(uint PetID, int index, List<float> vect)
    {
        base.Init(PetID);
        petId = PetID;
        LoadPet(index, vect[0], vect[1], vect[2]);                                           //单独加载宠物模型
    }

    public void CreatePet(uint PetID, List<float> vect)
    {
        base.Init(PetID);
        //CreateBackStage();//加载背景（）
        petId = PetID;
        LoadPet(0, vect[0], vect[1], vect[2]);
    }

    public void CreateBackStage(string stageEquip = null)
    {
        base.CreateStage(stageEquip);
    }

    private void LoadPet(int index,float x,float y,float z,bool replaceModel = false)
    {
        PetContent petLoader = HolderManager.m_PetHolder.GetStaticInfo(avatarID);
        if (petLoader == null) return;

        avatarPath = petLoader.ModelLoader.Path;
        m_animatorPath = avatarPath.Replace("_model", "_ctrl");

        m_index = index;
        m_x = x;
        m_y = y;
        m_z = z;
        m_replaceModel = replaceModel;

        AddStart();
        AddLoadState(avatarPath);
        AddLoadState(m_animatorPath);
        AddOver();
    }

    public override void PreloadCompleted()
    {
        avatarLoadObj = new CObject(avatarPath);
        avatarLoadObj.CallBack = LoadAvatarCompleted;
        avatarLoadObj.Args = new object[] { m_index, m_x, m_y, m_z, m_replaceModel };
        avatarLoadObj.IsMemoryFactory = true;
        avatarLoadObj.ObjectType = m_replaceModel ? eObjectType.ReplaceModel : eObjectType.Pet;
        avatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
        avatarLoadObj.LoadObject();
        SingletonObject<PetDisplayMediator>.GetInst().objList.Add(avatarLoadObj);
    }

    public void RecoverPetObj()
    {
        avatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
    }

    private void LoadAvatarCompleted(GameObject o, params object[] args)
    {  
        object[] objectArgs = avatarLoadObj.Args;
        if (o == null)
        {
            avatarID = DEFINE.REPLACE_PET_LOADER_KEY;

            LoadPet((int)objectArgs[0], (float)objectArgs[1], (float)objectArgs[2], (float)objectArgs[3], true);
            return;
        }

        if (objectArgs.Length > 4)
        {
            bool replace = (bool)objectArgs[4];
            if (replace)
            {
                Common.MaterialCulling(o);
            }
               
        }
        int index = MyConvert_Convert.ToInt32(args[0]);

        float px = MyConvert_Convert.ToSingle(args[1]);
        float py = MyConvert_Convert.ToSingle(args[2]);
        float pz = MyConvert_Convert.ToSingle(args[3]);
        localPosition = new Vector3(index*10+px-0.4f,py,pz);
        MyLog.LogError(localPosition + " localPosition");

        localRotation = Quaternion.Euler(new Vector3(0, 145, 0));

        control = o.GetComponent<CharacterController>();
        if (control != null)
            control.enabled = false;
        avatarObj = o;
        AddSpinMouse(avatarObj);
        MyLog.LogError(avatarObj.name + "  == avatarObj");
        avatarObj.transform.parent = GetParent;
        avatarObj.transform.localPosition = localPosition;
        avatarObj.transform.localRotation = localRotation;
        avatarObj.transform.localScale = Vector3.one;
        CBaseHomeAvatar.setPetParticals(avatarObj, petId);
        LoadHelp.LoadObject("animator",m_animatorPath, ThreadPriority.Normal, LoadAcnimatorControl);
    }

    private void LoadAcnimatorControl(string interim, Object asset)
    {
        if (null == asset) { MyLog.LogError("e:" + interim); return; }
        GameObject go = (GameObject)asset;
        Animator animator = go.GetComponent<Animator>();
        if (animator == null) return;
        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        if (avaAnimator == null)
            avaAnimator = avatarObj.AddComponent<Animator>();
        avaAnimator.enabled = true;
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //avaAnimator.avatar = animator.avatar;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (avatarLoadObj != null)
        {
            if (control != null)
            {
                control.enabled = true;
            }
            avatarLoadObj.DestroyGameObject(destroyType);
        }
        base.Release(destroyType);
    }
}
