﻿using System.Collections;
using System.Collections.Generic;
using System.Reflection.Emit;
using UnityEngine;

public class CardLoading : StageLoading
{
    private CObject m_cardObj;
    private GameObject m_cardGameObject;
    private string m_cardPath = "resources/other/kabao.x";

    private float m_cardRotationTime;//卡包翻转时间
    private float m_cardMoveTo;//卡包移动时间
    public delegate void RotationFinish();
    public RotationFinish OnRotationFinish;

    public delegate void MoveToFinish();
    public MoveToFinish OnMoveToFinish;
    public CardLoading(bool bLoop, bool bLimit = true, bool loadState = false)
        : base(bLoop, bLimit, loadState)
    {
        StageType = eObjectType.Card;
    }

    public void CreateCard(string path)
    {
        base.Init();
        m_cardPath = path;
        cam.depth = 31;
        AddStart();
        AddLoadState(path);
        AddOver();
    }

    public override void PreloadCompleted()
    {
        if (!string.IsNullOrEmpty(m_cardPath))
        {
            m_cardObj = new CObject(m_cardPath);
            m_cardObj.CallBack = LoadCardComplete;
            m_cardObj.Args = new object[] { };
            m_cardObj.Name = "card";
            m_cardObj.IsMemoryFactory = true;
            m_cardObj.ObjectType = eObjectType.Card;
            m_cardObj.Layer = DEFINE.AVATAR_LAYER;
            m_cardObj.LoadObject();
        }
    }

    private void LoadCardComplete(GameObject o, params object[] args)
    {
        if (o == null)
        {
            return;
        }
        m_cardGameObject = o;
        o.transform.parent = GetParent;
        o.transform.localPosition = Vector3.zero;
        o.transform.localEulerAngles = Vector3.zero;
        o.transform.localScale = Vector3.one;

    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (m_cardGameObject != null)
        {
            iTween itween = m_cardGameObject.GetComponent<iTween>();
            if (itween != null)
            {
                NGUITools.Destroy(itween);
            }
        }
        if (m_cardObj != null)
        {
            m_cardObj.DestroyGameObject(destroyType);
        }
        base.Release(destroyType);
    }

    public void MoveTo(MoveToFinish callBack, Vector3 endposition, float time)
    {
        OnMoveToFinish = callBack;
        m_cardMoveTo = time;
        iTween.MoveTo(m_cardGameObject, iTween.Hash("position", endposition, "islocal", true, "time", m_cardMoveTo, "oncomplete", (OnCallBack)OnMoveComlete));
        if (callBack != null)
        {
            //移动到外界的，淡出
            //Hashtable args = new Hashtable();
            //args.Add("from",new Color32(1,1,1,1));
            //args.Add("to",new Color32(1,1,1,0));
            //args.Add("time", m_cardMoveTo);
            //args.Add("onupdate",(OnCallBack)OnMoveComlete);
            //args.Add("onupdatetarget",m_cardGameObject);
            //iTween.ValueTo(m_cardGameObject, args)
            ;
        }
    }

    public void RotationToReadyPlay()
    {
        iTween.RotateAdd(m_cardGameObject, new Vector3(0, 180 * 3, 8), m_cardRotationTime);
    }

    public void ScaleToReadyPlay(float time)
    {
        iTween.ScaleTo(m_cardGameObject, iTween.Hash("scale", Vector3.one, "islocal", true, "time", time, "easetype", iTween.EaseType.bounce));
    }

    private void OnMoveComlete(params object[] arg)
    {
        if (OnMoveToFinish != null)
        {
            OnMoveToFinish();
            OnMoveToFinish = null;
        }
    }

    /// <summary>
    /// 翻转到正面
    /// </summary>
    public void RotationToFront(float time, RotationFinish callback)
    {
        m_cardRotationTime = time;
        if (m_cardGameObject != null)
        {
            OnRotationFinish = callback;
            RotationTo(Vector3.zero, new Vector3(0, 180, 0));
        }
    }

    /// <summary>
    /// 翻转到反面
    /// </summary>
    public void RotationToReverse(float time, RotationFinish callback)
    {
        m_cardRotationTime = time;
        if (m_cardGameObject != null)
        {
            OnRotationFinish = callback;
            RotationTo(new Vector3(0, 180, 0), Vector3.zero);
        }
    }

    private void RotationTo(Vector3 startrotiaon, Vector3 endrotiaon)
    {
        //m_cardGameObject.transform.localEulerAngles = startrotiaon;
        iTween.RotateTo(m_cardGameObject, iTween.Hash("rotation", endrotiaon, "islocal", true, "time", m_cardRotationTime, "oncomplete", (OnCallBack)OnRotationComlete));
    }

    private void OnRotationComlete(params object[] arg)
    {
        if (OnRotationFinish != null)
        {
            OnRotationFinish();
            OnRotationFinish = null;
        }
    }

    public GameObject CardGameObject { get { return m_cardGameObject; } }
    public CObject CardObject { get { return m_cardObj; } }

    public Transform CardTran
    {
        get
        {
            if (m_cardGameObject != null)
                return m_cardGameObject.transform;
            return null;
        }
    }

    public Vector3 LocalPosition
    {
        get
        {
            if (CardTran != null)
                return CardTran.localPosition;
            return Vector3.zero;
        }
    }

    public Vector3 LocalEulerAngles
    {
        get
        {
            if (CardTran != null)
                return CardTran.localEulerAngles;
            return Vector3.zero;
        }
    }

    public Vector3 LocalScale
    {
        get
        {
            if (CardTran != null)
                return CardTran.localScale;
            return Vector3.one;
        }
    }
}