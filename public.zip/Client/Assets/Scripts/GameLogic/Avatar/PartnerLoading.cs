﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class PartnerLoading : StageLoading
{

    private int indexOf = 0;
    public GameObject avatarObj;
    private CObject avatarLoadObj;
    private CharacterController control;
    private CObject weaponRight;
    private CObject weaponLeft;
    private CObject DragoncrystalObj;

    private Vector3 rightWeaponPos = new Vector3(0,0,0);//右手武器临时坐标
    private Vector3 leftWeaponPos = new Vector3(0,0,0);//左手武器临时坐标
    public float mBodyHeight;

    public delegate void OnLoadModelFinish();

    private PartenrContent m_partnerLoader;
    private Animator m_animator;
    private GameObject m_leftWeapon;
    private GameObject m_rightWeapon;

    private string m_modelPath;

    private string m_leftWeaponPath;
    private string m_rightWeaponPath;

    private int m_nDragoncrystalID;
    private string m_DragoncrystalPath;

    public OnLoadModelFinish onLoadModelFinish;
    public PartnerLoading(bool bLoop,bool blimit = true)
        : base(bLoop,blimit)
    {
        StageType = eObjectType.Partner;
    }


    public void CreatPartner(uint partnerID, int nDragoncrystalID = 0)
    {
        base.Init(partnerID);
        m_nDragoncrystalID = nDragoncrystalID;
        LoadPartner();
    }

    private void LoadPartner()
    {
        m_partnerLoader = HolderManager.m_PartenrHolder.GetStaticInfo(avatarID);
        if (m_partnerLoader == null) return;

        Quaternion localRotation2 = Quaternion.Euler(m_partnerLoader.ModelLoader.PartnerRotation);//Quaternion.Euler(new Vector3(5.0f, 178f, 0));
        localPosition = m_partnerLoader.ModelLoader.PartnerPos;//new Vector3(0f, -0.9f, 3.4f); ;
        localRotation = localRotation2;


        m_modelPath = m_partnerLoader.ModelLoader.ModelRes;
        m_animatorPath = m_modelPath.Replace("_model", "_home_ctrl");
        //m_animatorpath = m_modelPath.Replace("_model", "_ctrl");
        SetWeaponPath((uint)m_partnerLoader.ModelLoader.WeaponID);

        m_DragoncrystalPath = GetDragoncrystalPath(m_nDragoncrystalID);


        AddStart();
        AddLoadState(m_modelPath);
        AddLoadState(m_animatorPath);
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddLoadState(m_DragoncrystalPath);
        AddOver();
    }


    private string GetDragoncrystalPath(int nLongjingID)
    {
        DragoncrystalContent pDragonContent = HolderManager.m_DragoncrystalHolder.GetStaticInfo(nLongjingID);
        if (null == pDragonContent)
        {
            return null;
        }

        ParticleContent pParticleContent = HolderManager.m_ParticleHolder.GetStaticInfo(pDragonContent.CrystalAndEnchantEffect[0]);
        if (null == pParticleContent)
        {
            return null;
        }

        return pParticleContent.Path;
    }


    private void LoadAvatarCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        avatarObj = o;
        avatarObj.transform.parent = GetParent;
        TweenPosition tweenPosition = avatarObj.GetComponent<TweenPosition>();
        if (tweenPosition != null) tweenPosition.enabled = false;
        avatarObj.transform.localPosition = localPosition;
        //针对库洛根特殊处理。不计算蒙皮高度来调整相机高度了。因为部分模型其实高度跟库洛根差不多。如果也调整了相机坐标人物就会变小
        //if (avatarObj.transform.FindChild("kuluogen") != null && !Loop)
        //{
        //    avatarObj.transform.localPosition = new Vector3(0, -1.3f, 3.8f);
        //}
        avatarObj.transform.localRotation = localRotation;
        avatarObj.transform.localScale = Vector3.one;
        AddSpinMouse(avatarObj);
        //获取模型高度
        SkinnedMeshRenderer[] smrs = avatarObj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (smrs.Length > 0)
            mBodyHeight = smrs[0].bounds.size.y;
        else
            mBodyHeight = 2.0f; //默认高度
        if (onLoadModelFinish != null)
        {
            onLoadModelFinish();
            onLoadModelFinish = null;
        }
    }

    private void SetWeaponPath(uint uiWeaponID)
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponID);
        if (weapon != null)
        {
            List<string> pathList = weapon.ModelLoader.ModelPath;

            if (pathList.Count == 2)
            {
                m_leftWeaponPath = pathList[0];
                m_rightWeaponPath = pathList[1];
            }

        }
        else
        {
            m_leftWeaponPath = "";
            m_rightWeaponPath = "";
        }
    }


    private void LoadWeapon()
    {
        m_leftWeapon = null;
        m_rightWeapon = null;
        if (null == m_partnerLoader)
        {
            return;
        }
        if (!m_leftWeaponPath.Equals("0"))
        {
            weaponLeft = new CObject(m_leftWeaponPath);

            weaponLeft.CallBack = LoadWeaponLeftCompleted;
            weaponLeft.IsMemoryFactory = true;
            weaponLeft.ObjectType = eObjectType.Weapon;
            weaponLeft.Layer = DEFINE.AVATAR_LAYER;
            weaponLeft.LoadObject();
        }

        if (!m_rightWeaponPath.Equals("0"))
        {
            weaponRight = new CObject(m_rightWeaponPath);
            weaponRight.CallBack = LoadWeaponRightCompleted;
            weaponRight.IsMemoryFactory = true;
            weaponRight.ObjectType = eObjectType.Weapon;
            weaponRight.Layer = DEFINE.AVATAR_LAYER;
            weaponRight.LoadObject();
        }       
    }

    public virtual void LoadWeaponLeftCompleted(GameObject weapon, params object[] args)
    {
        if (null == weapon)
        {
            return;
        }
        if (null == avatarObj)
        {
            return;
        }
        m_leftWeapon = weapon;

        m_leftWeapon.transform.parent = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        m_leftWeapon.transform.localPosition = leftWeaponPos;
        m_leftWeapon.transform.localRotation = Quaternion.identity;
        DynamicShader.ReplaceUnSupportShader(m_leftWeapon);
    }
    public virtual void LoadWeaponRightCompleted(GameObject weapon, params object[] args)
    {
        if (null == weapon)
        {
            return;
        }
        if (null == avatarObj)
        {
            return;
        }
        m_rightWeapon = weapon;

        m_rightWeapon.transform.parent = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        m_rightWeapon.transform.localPosition = rightWeaponPos;
        m_rightWeapon.transform.localRotation = Quaternion.identity;
        DynamicShader.ReplaceUnSupportShader(m_rightWeapon);
    }

    public override void PreloadCompleted()
    {
        avatarLoadObj = new CObject(m_modelPath);
        avatarLoadObj.Name = avatarID.ToString();
        avatarLoadObj.CallBack = LoadAvatarCompleted;
        avatarLoadObj.IsMemoryFactory = true;
        avatarLoadObj.ObjectType = eObjectType.Partner;
        avatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
        avatarLoadObj.LoadObject();

        LoadHelp.LoadObject("animator", m_animatorPath, ThreadPriority.Normal, LoadAcnimatorControl);

        LoadWeapon();

        if(Loop)
            LoadDragoncrystal();
    }

    private void LoadAcnimatorControl(string interim, Object asset)
    {
        if (null == asset)
        {
            return;
        }
        GameObject go = (GameObject)asset;
        m_animator = go.GetComponent<Animator>();

        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        if (avaAnimator == null)
            avaAnimator = avatarObj.AddComponent<Animator>();
        avaAnimator.enabled = true;
        avaAnimator.runtimeAnimatorController = m_animator.runtimeAnimatorController;
        //avaAnimator.avatar = m_animator.avatar;
        avaAnimator.applyRootMotion = false;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");

    }

    //加载龙晶
    private void LoadDragoncrystal()
    {
        if (m_nDragoncrystalID != 0 && !string.IsNullOrEmpty(m_DragoncrystalPath))
        {
            DragoncrystalObj = new CObject(m_DragoncrystalPath);
            DragoncrystalObj.Name = m_nDragoncrystalID.ToString();
            DragoncrystalObj.CallBack = LoadDragoncrystalCompleted;
            DragoncrystalObj.IsMemoryFactory = true;
            DragoncrystalObj.ObjectType = eObjectType.LongJing;
            DragoncrystalObj.Layer = DEFINE.AVATAR_LAYER;
            DragoncrystalObj.LoadObject();
        }

    }

    private void LoadDragoncrystalCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        o.transform.parent = avatarObj.transform;
        o.transform.localPosition = new Vector3(0, mBodyHeight - 2.2f, 0);//2.2米是龙晶离原点的高度
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;
    }


    public void CreateBackStage(string stageEquip = null)
    {
        base.CreateStage(stageEquip);
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (avatarLoadObj != null)
        {
            if (control != null)
            {
                control.enabled = true;
            }
            avatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        if (weaponLeft != null) weaponLeft.DestroyGameObject(eObjectDestroyType.Memory);//TOCHECK:检查小伙伴左右手武器。
        if (weaponRight != null) weaponRight.DestroyGameObject(eObjectDestroyType.Memory);
        if (DragoncrystalObj != null) DragoncrystalObj.DestroyGameObject(eObjectDestroyType.Memory);
        //string animatorPath = avatarPath.Replace("_model", "_home_ctrl");
        //LoadHelp.RemoveObject(animatorPath, true);
        base.Release(destroyType);
    }
}
