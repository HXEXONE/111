﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RenderAvatarMgr : SingletonObject<RenderAvatarMgr>
{
    private List<BaseRenderAvatar> m_list = new List<BaseRenderAvatar>();
    public void AddRenderAvatar(BaseRenderAvatar ra)
    {
        m_list.Add(ra);
    }

    public void RemoveRenderAvatar(BaseRenderAvatar ra)
    {
        if (m_list.Contains(ra))
        {
            m_list.Remove(ra);
        }
    }

    public void Update()
    {
        for (int i = 0, icount = m_list.Count; i < icount; ++i)
        {
            m_list[i].Update();
        }
    }
}