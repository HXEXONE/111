﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eBaseRenderAvatarState
{
    Avatar = 1,
    Background = 2,
    Rect = 4,
}

public abstract class BaseRenderAvatar
{

    public delegate void AllLoadCompleteDelegate();

    public AllLoadCompleteDelegate loadComplete;

    protected Camera cam;
    private GameObject rootObj;
    protected GameObject cameraObj;
    protected GameObject spinTarget;

    /// <summary>
    /// 是否被删除
    /// </summary>
    protected bool bDelete;

    protected Transform cameraTransform;
    protected float distance = 5.0f;
    protected Vector3 adjustPos = new Vector3(0.0f, 1.0f, 0.0f);

    protected Camera uiCamera;

    protected Vector3 avatarPos;
    protected Rect m_rect;
    protected Vector3 movePos = Vector3.one;

    protected Vector3 topLeft;//屏幕坐标的左上
    protected Vector3 bottomRight;//屏幕坐标的右下

    protected bool m_bLoop;

    private CUITexture m_pUITexture;

    private bool isLoadStage;          //默认加载

    private byte m_loadState;

    private static int mPositionIndex = 1;

    private bool m_bLimitBounds;
    protected bool bGray = false;       //模型至灰
    protected float grayFactor = 1.0f;
    protected bool caremaGray = false;  //相机至灰
    protected float caremaGrayFactor = 1.0f;
    protected ImageEffectParamGrayEffect grayEffect;
    protected int crayCameraDepht = 0;
    public bool bSpinMouse = true;

    protected string m_animatorPath;

    private Dictionary<string, SkinnedMeshRenderer> initAvatarRenderDict = new Dictionary<string, SkinnedMeshRenderer>();
    private Dictionary<string, MeshRenderer> initOtherRenderDict = new Dictionary<string, MeshRenderer>();

    #region Avatar Render Texture 类型构造方法

    public BaseRenderAvatar(bool bLoop, bool bLimitBounds = true,bool loadStage = false)
    {
        bDelete = false;

        m_bLoop = bLoop;

        m_bLimitBounds = bLimitBounds;

        LoadStage = loadStage;

        RenderAvatarMgr.GetInst().AddRenderAvatar(this);
    }

    public void Init()
    {
        bDelete = false;
        if (m_bLoop)
        {
            rootObj = SingletonObject<RenderAvatarFactory>.GetInst().GetMemoryObj("RenderAvatar_Loop", ref cam, ref cameraObj);
        }
        else
        {
            rootObj = SingletonObject<RenderAvatarFactory>.GetInst().GetMemoryObj("RenderAvatar_NoLoop", ref cam, ref cameraObj);
        }

        rootObj.transform.position = new Vector3(20, 0, 0f) * (++mPositionIndex);
        rootObj.transform.localScale = Vector3.one;

        cameraObj.transform.localPosition = Vector3.zero;
        cameraObj.transform.localRotation = Quaternion.identity;
        cameraObj.transform.localScale = Vector3.one;
        //add camera component
        cam.fieldOfView = 45;//恢复到默认透视相机的field of view;
        if (!m_bLoop)
        {
            cam.clearFlags = CameraClearFlags.Skybox;
        }
        else
        {
            cam.clearFlags = CameraClearFlags.Depth;
            cam.depth = 100;
        }
    }


    public CUITexture SetUITexture
    {
        set
        {
            m_pUITexture = value;

            float x = 0;
            float y = 0;

            float w = 1;
            float h = 1;
            if (m_pUITexture != null)
            {
                w = m_pUITexture.Size.x;
                h = m_pUITexture.Size.y;
            }

            if (m_bLoop)
            {
                float scale = UIManager.GetInst().GetUIScale();
                if (m_pUITexture != null)
                {
                    Vector3 uiposition = UIPosition(m_pUITexture.MyTexture);
                    x = (uiposition.x - w / 2.0f) * scale + Screen.width / 2.0f;
                    y = (uiposition.y + h / 2.0f) * scale + Screen.height / 2.0f;
                    w *= scale;
                    h *= scale;
                    m_pUITexture.texture = null;
                    //m_pUITexture.MyTexture.enabled = false;
                }
            }

            MyRect = new Rect(x, y, w, h);
        }
    }

    private Vector3 UIPosition(UITexture tex)
    {
        GameObject o = tex.gameObject;

        Vector3 localPosition = o.transform.localPosition;
        Transform parent = o.transform.parent;
        while (parent != null && !parent.name.Contains("UICamera"))
        {
            localPosition += parent.localPosition;
            parent = parent.parent;
        }

        return localPosition;
    }

    public bool LoadStage
    {
        set
        {
            isLoadStage = value;

            //if (!isLoadStage)
            //{
            //    m_loadState |= (byte)eBaseRenderAvatarState.Background;
            //}
        }
        get
        {
            return isLoadStage;
        }
    }

    //如果是静态图片的话,那么仅仅设置rect的w和h即可
    private Rect MyRect
    {
        set
        {
            m_rect = value;
            Rect rect = value;
            if (m_bLoop)
            {
                topLeft = new Vector3(rect.x, rect.y, 0);
                bottomRight = new Vector3(rect.x + rect.width, rect.y - rect.height, 0);

                //创建渲染视口
                MyUIViewport uv = cameraObj.GetComponent<MyUIViewport>();
                if (null == uv)
                {
                    uv = cameraObj.AddComponent<MyUIViewport>();
                }
                uv.topLeft = topLeft;
                uv.bottomRight = bottomRight;
                uv.fullSize = 1;

                if (m_bLimitBounds)
                {
                    uv.enabled = true;
                }
                else
                {
                    uv.enabled = false;
                    cam.ResetAspect();
                    cam.rect = new Rect(0,0,1,1);
                }

            }
            else
            {
                topLeft = new Vector3(Screen.width / 2.0f - rect.width / 2.0f, Screen.height / 2.0f + rect.height / 2.0f, 0);
                bottomRight = new Vector3(Screen.width / 2.0f + rect.width / 2.0f, Screen.height / 2.0f - rect.height / 2.0f, 0);

                //创建渲染图片
                MyUIViewImage uv = cameraObj.GetComponent<MyUIViewImage>();
                if (null == uv)
                {
                    uv = cameraObj.AddComponent<MyUIViewImage>();
                    uv.Callback = RenderCallback;
                }
                uv.topLeft = topLeft;
                uv.bottomRight = bottomRight;
                uv.fullSize = 1;
            }

            //核实状态
            m_loadState |= (byte)eBaseRenderAvatarState.Rect;
            CheckState();
        }
    }

    #endregion

    //加载所有资源完毕,判断是否可以开始渲染
    public virtual void LoadAllComplete()
    {
        m_loadState |= (byte)eBaseRenderAvatarState.Avatar;
        CheckState();
        if (loadComplete != null)
        {
            loadComplete();
        }
        if (bGray)
        {
            SetGray();
        }

        

    }

    //加载背景完毕
    public virtual void LoadStageCompleted(GameObject stage, params object[] args)
    {
        m_loadState |= (byte)eBaseRenderAvatarState.Background;
        CheckState();
    }

    private void CheckState()
    {
        if (rootObj == null)
        {
            return;
        }
        if (!rootObj.activeSelf)
        {
            return;
        }
        //if (m_bLoop)
        //{
        //    Render();
        //    return;
        //}
        if (LoadStage)
        {
            if ((m_loadState & (byte)eBaseRenderAvatarState.Rect) != 0 &&
            (m_loadState & (byte)eBaseRenderAvatarState.Avatar) != 0 &&
            (m_loadState & (byte)eBaseRenderAvatarState.Background) != 0)
            {
                Render();
            }
        }
        else
        {
            if ((m_loadState & (byte)eBaseRenderAvatarState.Rect) != 0 &&
            (m_loadState & (byte)eBaseRenderAvatarState.Avatar) != 0)
            {
                Render();
            }
        }

    }


    private void SetGray()
    {
        if (rootObj != null &&bGray ==true)
        {
            SkinnedMeshRenderer[] skinnedArray = rootObj.GetComponentsInChildren<SkinnedMeshRenderer>();
            MeshRenderer[] meshArray = rootObj.GetComponentsInChildren<MeshRenderer>();

            for (int i = 0; i < skinnedArray.Length; i++)
            {
                string sname = skinnedArray[i].gameObject.name;
                if (sname =="shadow")
                {
                    continue;
                }
                if (!initAvatarRenderDict.ContainsKey(sname))
                {
                    initAvatarRenderDict.Add(sname, skinnedArray[i]);
                }

            }
            for (int i = 0; i < meshArray.Length; i++)
            {
                string sname = meshArray[i].gameObject.name;
                if (sname == "shadow")
                {
                    continue;
                }
                if (!initOtherRenderDict.ContainsKey(sname))
                {
                    initOtherRenderDict.Add(sname, meshArray[i]);
                }
            }
        }

        if (bGray)
        {
            Shader grayShader = DynamicShader.GetShader("MyMobile/Gray/Diffuse");
          
            if (grayShader == null)
            {
                return;
            }
            foreach (KeyValuePair<string,SkinnedMeshRenderer> kvp in initAvatarRenderDict)
            {
                Material[] materals = kvp.Value.materials;
                for (int i = 0; i < materals.Length;i++ )
                {
                    materals[i].shader = grayShader;
                    materals[i].SetFloat("_Gray", GrayFactor);
                }
            }
            foreach (KeyValuePair<string, MeshRenderer> kvp in initOtherRenderDict)
            {
                Material[] materals = kvp.Value.materials;
                for (int i = 0; i < materals.Length; i++)
                {
                    materals[i].shader = grayShader;
                    materals[i].SetFloat("_Gray", GrayFactor);

                }
            }
        }

    }

    private void SetCameraGray()
    {
        if (rootObj != null && cam !=null)
        {
            if (caremaGray && grayEffect == null)
            {

                grayEffect = new ImageEffectParamGrayEffect(cam, caremaGrayFactor,crayCameraDepht);
                ImageEffectManager.GetInst().CreateImageEffect(grayEffect);
            }
            else
            {
                if (grayEffect != null)
                {
                    ImageEffectManager.GetInst().CloseEffect(eImageEffect.GrayEffect, cam);
                }
            }
        }
    }

    private void ResetShader()
    {

    }

    //渲染
    private void Render()
    {
        if (m_bLoop)
        {
            if (cam != null)
            {
                cam.enabled = true;
            }
            //设置置灰延迟0.1秒
            SetCameraGray();
            AddSpinMouse(spinTarget);
        }
        else
        {
            MyUIViewImage muiv = cameraObj.GetComponent<MyUIViewImage>();
            if (muiv != null)
            {
                muiv.Render();
            }
        }
    }


    private void RenderCallback(Texture tex)
    {
        if (rootObj != null)
        {
            rootObj.SetActive(false);
        }


        //m_pUITexture.SetShader = DynamicShader.GetShader(DEFINE.SHADER_UNLIT_TRANSPARENT_COLORED_IMAGE);
#if UNITY_EDITOR
        Quaternion rotation = Quaternion.identity;
        if (QualitySettings.antiAliasing > 0)
        {
            rotation = Quaternion.Euler(180, 0, 0);
        }
        m_pUITexture.ElementObj.transform.localRotation = rotation;
#endif
        m_pUITexture.SetTexture(tex);
        m_loadState = 0;

    }


    //设置旋转
    public void AddSpinMouse(GameObject target =null)
    {
        spinTarget = target;
        if (spinTarget != null && m_pUITexture != null && m_bLoop && bSpinMouse)
        {
            GameObject o = m_pUITexture.ElementObj;
            BoxCollider collider = o.GetComponent<BoxCollider>();
            if (collider == null)
            {
                collider = o.AddComponent<BoxCollider>();
            }
            collider.size = new Vector3(m_pUITexture.Size.x, m_pUITexture.Size.y, 1);
            SpinWithMouse spinMouse = o.GetComponent<SpinWithMouse>();
            if (spinMouse == null)
            {
                spinMouse = o.AddComponent<SpinWithMouse>();
            }
            spinMouse.target = spinTarget.transform;
        }
    }

    //IEnumerator Capture()
    //{
    //    yield return new WaitForEndOfFrame();

    //    if (m_pUITexture != null)
    //    {


    //        int w = (int)Mathf.Floor(bottomRight.x - topLeft.x);
    //        int h = (int)Mathf.Floor(topLeft.y - bottomRight.y);

    //        int x = (int)Mathf.Ceil(topLeft.x);
    //        int y = (int)Mathf.Ceil(bottomRight.y);

    //        cam.Render();

    //        Texture2D showTexture = new Texture2D(w, h, TextureFormat.ARGB32, false);
    //        showTexture.ReadPixels(new Rect(x, y, w, h), 0, 0);
    //        showTexture.Compress(true);
    //        showTexture.Apply();

    //        m_pUITexture.SetTexture(showTexture);
    //        m_pUITexture.Size = new Vector2(m_rect.width, m_rect.height);
    //        //if (rootObj != null)
    //        //{
    //        //    UnityEngine.GameObject.Destroy(rootObj);
    //        //    rootObj = null;
    //        //}

    //        m_loadState = 0;
    //    }


    //}

    public virtual void Update()
    {
 
    }

    public virtual void Release(eObjectDestroyType destroyType)
    {
        bDelete = true;

        if (rootObj != null)
        {
            UnityEngine.Object.Destroy(rootObj);
            SingletonObject<RenderAvatarFactory>.GetInst().RemoveMemoryObj(rootObj);
            rootObj = null;
        }
     

        if (m_pUITexture != null && m_pUITexture.texture != null)
        {
            UnityEngine.Object.DestroyImmediate(m_pUITexture.texture);
            m_pUITexture.texture = null;
        }

        if (grayEffect != null)
        {
            ImageEffectManager.GetInst().CloseEffect(eImageEffect.GrayEffect, cam);
        } 

        bGray = false;

        RenderAvatarMgr.GetInst().RemoveRenderAvatar(this);
    }
    #region get and set
    //获取相机控件
    public Camera GetCamera
    {
        get
        {
            return cam;
        }
    }
    //获得挂载点父节点
    public Transform GetParent
    {
        get
        {
            if (null == rootObj)
            {
                return null;
            }
            return rootObj.transform;
        }
    }

    public bool Loop
    {
        get { return m_bLoop; }
    }

    //获取渲染的整个物体
    public Vector3 AvatarPosition
    {
        get { return rootObj.transform.localPosition; }
        set { rootObj.transform.localPosition = value; }
    }

    //相机的transform属性
    public Transform CameraTrans
    {
        get
        {
            if (null == cameraObj)
            {
                if (cameraTransform != null)
                {
                    return cameraTransform;
                }
                return null;
            }
            return cameraObj.transform;
        }
        set
        {
            cameraTransform = value;
        }
    }


    /// <summary>
    /// avatar 相机多时，相邻直接的距离，
    /// </summary>
    public Vector3 MovePos
    {
        get
        {
            return movePos;
        }
        set
        {
            movePos = value;
        }
    }

    public int Depth
    {
        set
        {
            cam.depth = value;
            crayCameraDepht = value;
        }
    }

    public int CrayCameraDepht
    {
        set
        {
            crayCameraDepht = value;
        }
    }

    public void SetPosition(Vector3 position)
    {
        if (rootObj != null)
        {
            ParticleSystem[] ps = rootObj.GetComponentsInChildren<ParticleSystem>();
            for (int i = 0; i < ps.Length; i++)
            {
                ps[i].gameObject.SetActive(false);
            }
            rootObj.transform.position = position;
            for (int i = 0; i < ps.Length; i++)
            {
                ps[i].gameObject.SetActive(true);
            }
        }

    }

    public virtual void SetActive(bool bActive)
    {
        if (rootObj != null)
        {
            rootObj.SetActive(bActive);
        }

        CheckState();
    }

    public void SetAspect(float aspect)
    {
        if (cam != null && m_bLimitBounds)
        {
            cam.aspect = aspect;
        }
    }

    //public bool Gray
    //{
    //    get
    //    {
    //        return bGray;
    //    }
    //    set
    //    {
    //        if (bGray != value)
    //        {
    //            SetGray();
    //        }
    //        bGray = value;
    //    }
    //}

    public float GrayFactor
    {
        get
        {
            return grayFactor;
        }
        set
        {
            if (value != grayFactor && bGray)
            {
                SetGray();
            }
            grayFactor = value;

        }
    }

    public bool CaremaGray
    {
        get
        {
            return caremaGray;
        }
        set
        {
            if (caremaGray != value)
            {
                //SetCameraGray();
            }
            caremaGray = value;
        }
    }

    public float CameraGrayFactor
    {
        get
        {
            return caremaGrayFactor;
        }
        set
        {
            if (value != caremaGrayFactor && caremaGray)
            {
                //SetCameraGray();
            }
            caremaGrayFactor = value;

        }
    }

    #endregion


}
