﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class StageLoading : BaseRenderAvatar
{

    protected uint avatarID = 0;
    protected GameObject stageObj;                                      //舞台对象
    protected CObject loadObj;
    protected static string stagePath = "resources/other/kapai.x";
   
    protected Vector3 localPosition = Vector3.zero;
    protected Quaternion localRotation;

    protected eObjectType StageType = eObjectType.HomeAvatar;

    //protected bool isShow = true;
    
    //private static object lockCamera = new object();

    private List<string> m_loadFinished = new List<string>();
    private int m_loadCount;

    protected CAnimator myAnimator;

    public StageLoading(bool bLoop,bool bLimit = true,bool loadState = false):
        base(bLoop,bLimit,loadState)
    {
    }

    protected virtual void Init(uint id)
    {
        avatarID = id;
    }

    protected virtual void CreateStage(string path = null)
    {
        if (!LoadStage)
        {
            return;
        }
        if (path != null)
        {
            stagePath = path;
        }

        loadObj = new CObject(stagePath);
        loadObj.Name = "Stage" + StageType.ToString();
        loadObj.CallBack = LoadStageCompleted;
        loadObj.IsMemoryFactory = true;
        loadObj.ObjectType = eObjectType.Stage;
        loadObj.Layer = DEFINE.AVATAR_LAYER;
        loadObj.LoadObject();
    }

    public override void LoadStageCompleted(GameObject stage, params object[] args)
    {
        base.LoadStageCompleted(stage, args);
        if (null == stage) { MyLog.LogError("Error ：loadStageCompleted"); return; }
        stageObj = stage;

        //暂时设置一下，等美术设计好，应该直接导入，不需设置
        Vector3 localPos = new Vector3(7.65f, 2.7135f, 4.8215f);
        Quaternion q = new Quaternion();
        q.eulerAngles = new Vector3(350.0f, 0.0f, 0.0f);

        stageObj.transform.parent = GetParent;
        stageObj.transform.localPosition = localPos;
        stageObj.transform.localRotation = q;
        stageObj.transform.localScale = Vector3.one;
        DynamicShader.ReplaceUnSupportShader(stageObj);
    }

    public override void Update()
    {
        base.Update();

        if (myAnimator != null )
        {
            myAnimator.Update();
           
        }
    }

    public override void Release(eObjectDestroyType destroyType)
    {
        base.Release(destroyType);
        if (loadObj != null)
        {
            loadObj.DestroyGameObject(destroyType);
        }

        myAnimator = null;
    }

    #region get and set

    public string SetStagePath
    {
        set
        {
            stagePath = value;
        }
    }
    public GameObject GetStageObject
    {
        get
        {
            return stageObj;
        }
        set
        {
            stageObj = value;
        }
    }

    public eObjectType GetStageType
    {
        get
        {
            return StageType;
        }
    }

    #endregion

    /// <summary>
    /// 增加起始状态
    /// </summary>
    /// <param name="flag"></param>
    public void AddLoadState(string path)
    {
        if (string.IsNullOrEmpty(path) || path.Equals("0"))
        {
            return;
        }
        m_loadFinished.Add(path);
    }

    public void AddStart()
    {
        m_loadFinished.Clear();
        m_loadCount = 0;
    }

    public void AddOver()
    {
        foreach (string path in m_loadFinished)
        {
            LoadHelp.LoadObject(path, path, ThreadPriority.Normal, LoadResCompleted);
        }
    }

    private void LoadResCompleted(string interim, UnityEngine.Object asset)
    {
        m_loadCount++;
        if (m_loadCount == m_loadFinished.Count)
        {
            if (bDelete) return;
            PreloadCompleted();
            LoadAllComplete();
        }
    }

    public virtual void PreloadCompleted()
    {
       
    }

}
