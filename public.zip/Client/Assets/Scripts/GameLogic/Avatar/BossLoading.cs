﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BossLoading : StageLoading
{
    private CObject m_cotexture2D;
    private CObject m_coAvatarLoadObj;
    private CharacterController m_ccControl;
    private GameObject avatarObj;

    private CObject m_leftWeaponTexture;
    private CObject m_rigthWeaponTexture;

    protected CObject weaponRight;
    protected CObject weaponLeft;
    protected uint uiWeaponId = 0;

    private bool m_bDeleted;

    private Texture2D m_texture2D;

    private string m_modelPath;

    private string m_modelTexPath;
    private string m_leftWeaponTexPath;
    private string m_rightWeaponTexPath;
    private string m_leftWeaponPath;
    private string m_rightWeaponPath;
    private uint modelKey = 0;

    public float skinnSize = 1f;

    public BossLoading(bool bLoop, bool blimit = true)
        : base(bLoop, blimit)               //是否实时渲染
    {
        StageType = eObjectType.Npc ;
        m_bDeleted = false;
    }

    public void CreateBossWithBG(uint BossID, bool isE, Vector3 lp, Vector3 lr)
    {
        base.Init(BossID);
        LoadBoss(lp, lr);
    }
    public void CreateBossTeamBoss(uint BossID, bool isE)
    {
        base.Init(BossID);
        LoadTeamBoss();
    }

    private void LoadBoss(Vector3 lp, Vector3 lr)
    {
        m_bDeleted = false;
        BossInfoContent loader = HolderManager.m_BossInfoHolder.GetStaticInfo(avatarID);
        if (loader == null) return;
        MonsterContent monsterloader = HolderManager.m_MonsterHolder.GetStaticInfo(loader.MonsterId);
        if (monsterloader == null) return;
        if (null == monsterloader.ModelLoader)
        {
            MyLog.DebugLogException("monstermodel is null,npcid:" + avatarID);
            return;
        }

        Quaternion localRotation2 = Quaternion.Euler(lr);
        localPosition = lp;
        localRotation = localRotation2;

        ////if(SingletonObject <WorldBossCheckMediator>.GetInst().IsOpen )
        ////{
        //    Quaternion localRotation2 = Quaternion.Euler(new Vector3(0.0f, 200f, 0));
        //    localPosition = new Vector3(5.0f, -1.96f, 7.24f); ;
        //    localRotation = localRotation2;
        ////}

        uiWeaponId = (uint)monsterloader.WeaponID;

        m_modelPath = monsterloader.ModelLoader.Path;
        m_animatorPath = m_modelPath.Replace("_model", "_home_ctrl");
        m_modelTexPath = monsterloader.ModelLoader.TextureName;
        SetWeaponPath(uiWeaponId);

        AddStart();
        AddLoadState(m_modelPath);
        AddLoadState(m_animatorPath);
        AddLoadState(m_modelTexPath);
        AddLoadState(m_leftWeaponTexPath);
        AddLoadState(m_rightWeaponTexPath);
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddOver();


    }
    private void SetWeaponPath(uint uiWeaponID)
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponId);
        if (weapon != null)
        {
            List<string> texturePath = weapon.ModelLoader.TexturePath;
            List<string> pathList = weapon.ModelLoader.ModelPath;

            if (texturePath.Count == 2)
            {
                m_leftWeaponTexPath = texturePath[0];
                m_rightWeaponTexPath = texturePath[1];
            }
            else
            {
                m_leftWeaponTexPath = "";
                m_rightWeaponTexPath = "";
            }

            if (pathList.Count == 2)
            {
                m_leftWeaponPath = pathList[0];
                m_rightWeaponPath = pathList[1];
            }
          
        }
        else
        {
            m_leftWeaponTexPath = "";
            m_rightWeaponTexPath = "";
            m_leftWeaponPath = "";
            m_rightWeaponPath = "";
        }
    }

    public override void PreloadCompleted()
    {

        //if (modelKey >= 6001 && modelKey <= 6017 && m_modelTexPath == "0")
        if (m_modelTexPath == "0")
        {
            m_coAvatarLoadObj = new CObject(m_modelPath);
            //m_coAvatarLoadObj.Name = o.name;
            m_coAvatarLoadObj.CallBack = LoadAvatarCompleted;
            m_coAvatarLoadObj.IsMemoryFactory = true;
            m_coAvatarLoadObj.ObjectType = eObjectType.Npc;
            m_coAvatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
            m_coAvatarLoadObj.LoadObject();
        }
        else
        {
            m_cotexture2D = new CObject(m_modelTexPath);
            m_cotexture2D.CallBack = LoadTextureCompleted;
            m_cotexture2D.IsMemoryFactory = true;
            m_cotexture2D.ObjectType = eObjectType.Texture;
            m_cotexture2D.LoadObject();
        }

    }

    private void LoadTeamBoss()
    {
        m_bDeleted = false;

        MonsterContent monsterloader = HolderManager.m_MonsterHolder.GetStaticInfo(avatarID);
        if (monsterloader == null) return;
        if (null == monsterloader.ModelLoader)
        {
            MyLog.DebugLogException("monstermodel is null,npcid:" + avatarID);
            return;
        }
        modelKey = (uint)monsterloader.ModelLoaderKey;

        uiWeaponId = (uint)monsterloader.WeaponID;
        m_modelPath = monsterloader.ModelLoader.Path;
        m_animatorPath = m_modelPath.Replace("_model", "_home_ctrl");
        m_modelTexPath = monsterloader.ModelLoader.TextureName;
        SetWeaponPath(uiWeaponId);

        Quaternion localRotation2 = Quaternion.Euler(new Vector3(5.0f, 160f, 0));
        localPosition = new Vector3(-0.0f, -1.96f, 7.24f); ;
        localRotation = localRotation2;

        AddStart();
        AddLoadState(m_modelPath);
        AddLoadState(m_animatorPath);
        AddLoadState(m_modelTexPath);
        AddLoadState(m_leftWeaponTexPath);
        AddLoadState(m_rightWeaponTexPath);
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddOver();
    }

    protected void LoadTextureCompleted(GameObject o, params object[] args)
    {
        if (m_cotexture2D == null || m_cotexture2D.PTexture2D == null)
        {
            if (null != args && null != args[0])
            {
                MyLog.LogError("Can not find Texture ,Path = " + args[0]);
            }
            else
            {
                MyLog.LogError("Can not find Texture ");
            }
        }
        else
        {
            m_texture2D = m_cotexture2D.PTexture2D;
        }
        
        m_coAvatarLoadObj = new CObject(m_modelPath);
        //m_coAvatarLoadObj.Name = o.name;
        m_coAvatarLoadObj.CallBack = LoadAvatarCompleted;
        m_coAvatarLoadObj.IsMemoryFactory = true;
        m_coAvatarLoadObj.ObjectType = eObjectType.Npc;
        m_coAvatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
        m_coAvatarLoadObj.LoadObject();
    }

    private void LoadAvatarCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        if (m_bDeleted)
        {
            m_coAvatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        m_ccControl = o.GetComponent<CharacterController>();
        if (m_ccControl != null)
            m_ccControl.enabled = false;
        avatarObj = o;
        avatarObj.transform.parent = GetParent;
        avatarObj.transform.localPosition = localPosition;
        avatarObj.transform.localRotation = localRotation;
        avatarObj.transform.localScale = Vector3.one;
        AddSpinMouse(avatarObj);

        Rigidbody[] rigidboys = avatarObj.GetComponentsInChildren<Rigidbody>();
        for (int i = 0, len = rigidboys.Length; i < len; i++)
        {
            Rigidbody rigid = rigidboys[i];
            if (rigid.transform == avatarObj.transform)
            {
                continue;
            }
            string name = rigid.transform.name;
            if (name.Equals("TriggerObject") || name.Equals("TriggerRange"))
            {
                continue;
            }
            rigid.isKinematic = true;
            rigid.detectCollisions = false;
        }            

        //赋予贴图
        if (m_texture2D != null)
        {
            SkinnedMeshRenderer[] smrs = o.GetComponentsInChildren<SkinnedMeshRenderer>();
            foreach (SkinnedMeshRenderer smr in smrs)
            {
                smr.material.mainTexture = m_texture2D;
            }
            if (smrs.Length>0)
            {
                skinnSize = smrs[0].bounds.size.y;
            }
        }

        LoadHelp.LoadObject("animator", m_animatorPath, ThreadPriority.Normal, LoadAcnimatorControl);

        LoadWeapon();
    }

    private void LoadAcnimatorControl(string interim, Object asset)
    {
        if (null == asset) { MyLog.LogError("e:" + interim); return; }
        GameObject go = (GameObject)asset;
        Animator animator = go.GetComponent<Animator>();
        if (animator == null) return;
        if (avatarObj == null)
        {
            return;
        }
        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        if (avaAnimator == null)
            avaAnimator = avatarObj.AddComponent<Animator>();
        avaAnimator.enabled = true;
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;
        //avaAnimator.avatar = animator.avatar;
        avaAnimator.applyRootMotion = false;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");
    }

    private void LoadWeapon()
    {
        LoadWeaponTexture(uiWeaponId);
    }

    private void LoadWeaponTexture(uint weaponID)
    {
        EquipContent weapon = null;
        weapon = HolderManager.m_EquipHolder.GetStaticInfo(weaponID);

        if (weapon == null)
        {
            return;
        }

        List<string> texturePath = weapon.ModelLoader.TexturePath;
        List<string> pathList = weapon.ModelLoader.ModelPath;

        int weaponCount = pathList.Count;

        if (texturePath != null && texturePath.Count == 2)
        {
            if (weaponCount >= 1 && !texturePath[0].Equals("0"))
            {
                m_leftWeaponTexture = new CObject(texturePath[0]);
                m_leftWeaponTexture.IsMemoryFactory = true;
                m_leftWeaponTexture.ObjectType = eObjectType.Texture;
                m_leftWeaponTexture.LoadObject();
            }

            if (weaponCount >= 2 && !texturePath[1].Equals("0"))
            {
                m_rigthWeaponTexture = new CObject(texturePath[1]);
                m_rigthWeaponTexture.IsMemoryFactory = true;
                m_rigthWeaponTexture.ObjectType = eObjectType.Texture;
                m_rigthWeaponTexture.LoadObject();
            }
        }


        if (pathList.Count == 2)
        {
            LoadWeapon(true, pathList[0]);
            LoadWeapon(false, pathList[1]);
        }
    }


    public void LoadWeapon(bool left, string path)
    {
        if (path.Equals("0"))
        {
            return;
        }

        if (left)
        {
            if (weaponLeft != null)
                weaponLeft.DestroyGameObject(eObjectDestroyType.Memory);
            weaponLeft = new CObject(path);
            weaponLeft.CallBack = LoadWeaponLeftCompleted;
            weaponLeft.IsMemoryFactory = true;
            weaponLeft.ObjectType = eObjectType.Weapon;
            weaponLeft.Layer = DEFINE.AVATAR_LAYER;
            weaponLeft.LoadObject();
        }
        else
        {
            if (weaponRight != null)
                weaponRight.DestroyGameObject(eObjectDestroyType.Memory);
            weaponRight = new CObject(path);
            weaponRight.CallBack = LoadWeaponRightCompleted;
            weaponRight.IsMemoryFactory = true;
            weaponRight.ObjectType = eObjectType.Weapon;
            weaponRight.Layer = DEFINE.AVATAR_LAYER;
            weaponRight.LoadObject();
        }
    }

    public virtual void LoadWeaponLeftCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            weaponLeft.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        Transform boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        if (boneTran == null)
        {
            boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        }
        if (null == weapon)
        {
            return;
        }
        weapon.transform.parent = boneTran;
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        weapon.transform.localScale = Vector3.one;
        DynamicShader.ReplaceUnSupportShader(weapon);
        if (m_leftWeaponTexture != null)
            weapon.renderer.material.mainTexture = m_leftWeaponTexture.PTexture2D;

        if (avatarObj != null)
        {
            DynamicShader.SetMaterialToVertex(weapon, eNpcRenderType.MeshRender);
        }
    }
    public virtual void LoadWeaponRightCompleted(GameObject weapon, params object[] args)
    {
        if (avatarObj == null)
        {
            return;
        }
        if (m_bDeleted)
        {
            weaponRight.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        Transform boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop1");
        if (boneTran == null)
        {
            boneTran = Common.GetBone(avatarObj.transform, "Bip01 Prop2");
        }
        if (null == weapon)
        {
            return;
        }
        weapon.transform.parent = boneTran;
        weapon.transform.localPosition = Vector3.zero;
        weapon.transform.localRotation = Quaternion.identity;
        weapon.transform.localScale = Vector3.one;

        DynamicShader.ReplaceUnSupportShader(weapon);

        if (m_rigthWeaponTexture != null)
            weapon.renderer.material.mainTexture = m_rigthWeaponTexture.PTexture2D;

        if (avatarObj != null)
        {
            DynamicShader.SetMaterialToVertex(weapon, eNpcRenderType.MeshRender);
        }
    }

    public void CreateBackStage(string stageEquip = null)
    {
        base.CreateStage(stageEquip);
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {

        if (m_leftWeaponTexture != null)
            m_leftWeaponTexture.DestroyGameObject(eObjectDestroyType.Memory);

        if (m_rigthWeaponTexture != null)
            m_rigthWeaponTexture.DestroyGameObject(eObjectDestroyType.Memory);

        if (weaponLeft != null)
        {
            weaponLeft.DestroyGameObject(destroyType);
        }
        if (weaponRight != null)
        {
            weaponRight.DestroyGameObject(destroyType);
        }

        if (m_coAvatarLoadObj != null)
        {
            if (m_ccControl != null)
            {
                m_ccControl.enabled = true;
            }
            m_coAvatarLoadObj.DestroyGameObject(destroyType);
        }

       

        base.Release(destroyType);
        m_bDeleted = true;

       
    }
}
