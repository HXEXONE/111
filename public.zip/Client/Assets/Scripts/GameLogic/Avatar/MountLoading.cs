﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MountLoading : StageLoading {

    private int indexOf = 0;
    public GameObject avatarObj;
    private CObject avatarLoadObj;
    private CharacterController control;
    private string avatarPath = string.Empty;

    private uint petId;

    private int m_index;
    private float m_x;
    private float m_y;
    private float m_z;
    private Vector3 m_rot;

    public MountLoading(bool bLoop,bool bLimit = true)
        : base(bLoop,bLimit)
    {
        StageType = eObjectType.Mount;
    }
    //不带背景
    public void InitMount(uint mountID,int index,List<float> vect,Vector3 rot)
    {
        base.Init(mountID);
        petId = mountID;
        LoadMount(index, vect[0], vect[1], vect[2], rot);
    }

    public void CreateMount(uint mountID, List<float> vect, Vector3 rot)
    {
        base.Init(mountID);
        //CreateBackStage();
        petId = mountID;
        LoadMount(0, vect[0], vect[1], vect[2], rot);
    }

    public void CreateBackStage(string stageEquip = null)
    {
        base.CreateStage(stageEquip);
    }


    private void LoadMount(int index, float x, float y, float z,Vector3 rot)
    {
        MountsContent mountLoader = HolderManager.m_MountsHolder.GetStaticInfo(avatarID);
        if (mountLoader == null) return;
        avatarPath = mountLoader.ModelLoader.MountsModelPath;
        m_animatorPath = avatarPath.Replace("_model", "_home_ctrl");
        m_index = index;
        m_x = x;
        m_y = y;
        m_z = z;
        m_rot = rot;

        AddStart();
        AddLoadState(avatarPath);
        AddLoadState(m_animatorPath);
        AddOver();
    }

    public override void PreloadCompleted()
    {
        MountsContent mountLoader = HolderManager.m_MountsHolder.GetStaticInfo(avatarID);
        if (mountLoader == null) return;

        avatarLoadObj = new CObject(avatarPath);
        avatarLoadObj.Name = mountLoader.Key.ToString();
        avatarLoadObj.CallBack = LoadAvatarCompleted;
        avatarLoadObj.Args = new object[] { m_index, m_x, m_y, m_z, m_rot };
        avatarLoadObj.IsMemoryFactory = true;
        avatarLoadObj.ObjectType = StageType;
        avatarLoadObj.Layer = DEFINE.AVATAR_LAYER;
        avatarLoadObj.LoadObject();

        SingletonObject<MountDisplayMediator>.GetInst().objList.Add(avatarLoadObj);

    }

    public void RecoverPetObj()
    {
        avatarLoadObj.DestroyGameObject(eObjectDestroyType.Memory);
    }

    private void LoadAvatarCompleted(GameObject o, params object[] args)
    {

        if (o == null) return;
        int index = MyConvert_Convert.ToInt32(args[0]);
        float px = MyConvert_Convert.ToSingle(args[1]);
        float py = MyConvert_Convert.ToSingle(args[2]);
        float pz = MyConvert_Convert.ToSingle(args[3]);
        Vector3 rot = (Vector3)args[4];
        localPosition = new Vector3(index * 20 + px, py, pz);

        localRotation = Quaternion.Euler(rot);

        control = o.GetComponent<CharacterController>();
        if (control != null)
            control.enabled = false;
        avatarObj = o;
        AddSpinMouse(avatarObj);
        avatarObj.transform.parent = GetParent;
        avatarObj.transform.localPosition = localPosition;
        avatarObj.transform.localRotation = localRotation;
        avatarObj.transform.localScale = Vector3.one;
        CBaseHomeAvatar.setMountParticals(avatarObj, petId);
        LoadHelp.LoadObject("animator", m_animatorPath, ThreadPriority.Normal, LoadAcnimatorControl);
    }

    private void LoadAcnimatorControl(string interim, Object asset)
    {
        if (null == asset)
        {
            return;
        }
        GameObject go = (GameObject)asset;
        Animator animator = go.GetComponent<Animator>();
        if (animator == null) return;

        Animator avaAnimator = avatarObj.GetComponent<Animator>();
        if (avaAnimator == null)
            avaAnimator = avatarObj.AddComponent<Animator>();

        avaAnimator.enabled = true;
        avaAnimator.runtimeAnimatorController = animator.runtimeAnimatorController;

        //avaAnimator.avatar = animator.avatar;

        myAnimator = new CAnimator(avaAnimator);
        myAnimator.PlayAction("idle");
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (avatarLoadObj != null)
        {
            if (control != null)
            {
                control.enabled = true;
            }
            avatarLoadObj.DestroyGameObject(destroyType);

        }
        base.Release(destroyType);
    }
}
