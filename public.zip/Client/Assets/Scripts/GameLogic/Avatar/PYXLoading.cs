﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;

//public class PYXLoading : StageLoading
//{
//    private CObject mRelics;
//    private Transform relicsTran;
//    private uint mId;
//    private ReliceContent mLoader;

//    private ParticleContent mParticleLoader;

//    private CObject mEffect;
//    private bool bActive;//圣器是否已经激活

//    public GameObject GetRelicsObj()
//    {
//        if (null != mRelics)
//        {
//            return mRelics.gameCObject;
//        }
//        return null;
//    }
    
//    public PYXLoading(bool bLoop):base(bLoop,true,true)
//    {
       
//    }

//    public void InitPYX(uint id)
//    {
//        base.Init();

//        mId = id;
//        mLoader = HolderManager.m_ReliceHolder.GetStaticInfo(id);
//        mRelics = new CObject(mLoader.GetModle());
//        mRelics.Name = "Relics";
//        mRelics.CallBack = LoadRelicsCompleted;
//        mRelics.IsMemoryFactory = true;
//        mRelics.ObjectType = eObjectType.PYX;
//        mRelics.Layer = DEFINE.AVATAR_LAYER;
//        mRelics.LoadObject();

//        Modelpath = mLoader.GetModle();
//        AddLoadState(1, false);
//    }

//    public void InitPYX(ReliceContent loader,bool bactive =false)
//    {
//        base.Init();
//        bActive = bactive;
//        mLoader = loader;
//        CreateStage();
//        mId = loader.GetKey();
//        mRelics = new CObject(loader.GetModle());
//        mRelics.Name = "Relics";
//        mRelics.CallBack = LoadRelicsCompleted;
//        mRelics.IsMemoryFactory = true;
//        mRelics.ObjectType = eObjectType.PYX;
//        mRelics.Layer = DEFINE.AVATAR_LAYER;
//        mRelics.LoadObject();

//        Modelpath = loader.GetModle();
//        AddLoadState(1, false);
//    }

//    private void LoadRelicsCompleted(GameObject o, params object[] args)
//    {
//        if (o == null) return;

//        relicsTran = o.transform;
//        relicsTran.parent = GetParent;
//        CameraTrans.eulerAngles = Vector3.zero;
//        CameraTrans.localPosition = Vector3.zero;
//        GetCamera.depth = 25;
//        GetCamera.fieldOfView = 40;
//        uint particleid = bActive ? mLoader.GetActiveEffect() : mLoader.GetNormalEffect();//是否激活:决定加载哪种特效
//        mParticleLoader = HolderManager.m_ParticleHolder.GetStaticInfo(particleid);
//        mEffect = new CObject(mParticleLoader.GetPath());
//        mEffect.CallBack = LoadEffectComplected;
//        mEffect.IsMemoryFactory = true;
//        mEffect.ObjectType = eObjectType.Particle;
//        mEffect.Layer = DEFINE.EFFECT_LAYER;
//        mEffect.LoadObject();

//        //CParticleManager.GetInst().CreateBindEffect(mLoader.GetNormalEffect(), mRelics.GetObj());
//        AddLoadState(5, false);
//        switch (mId)
//        {
//            case 61000101:
//                relicsTran.localPosition = new Vector3(0f, -0.6f, 2f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000201:
//                relicsTran.localPosition = new Vector3(0f, -0.75f, 2.5f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000301:
//                relicsTran.localPosition = new Vector3(0f, -0.7f, 2.5f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000401:
//                relicsTran.localPosition = new Vector3(0f, -0.75f, 2.5f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000501:
//                relicsTran.localPosition = new Vector3(0f, -1f, 3.5f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(new Vector3(0,180,0));
//                break;
//            case 61000601:
//                relicsTran.localPosition = new Vector3(0f, -1f, 3.5f);
//                relicsTran.localScale = new Vector3(1f, 1, 1);
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000701:
//                relicsTran.localPosition = new Vector3(0f, -0.6f, 2f);
//                relicsTran.localScale = new Vector3(1f, 1, 1);
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000801:
//                relicsTran.localPosition = new Vector3(0f, -0.7f, 2.5f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(Vector3.zero);
//                break;
//            case 61000901:
//                relicsTran.localPosition = new Vector3(0f, -0.5f, 2f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(new Vector3(0, 180, 0));
//                break;
//            case 61001001:
//                relicsTran.localPosition = new Vector3(0f, -0.65f, 2.3f);
//                relicsTran.localScale = Vector3.one;
//                relicsTran.localRotation = Quaternion.Euler(new Vector3(0,180,0));
//                break;
//        }

//        SetLoadState(1, true);
//    }

//    private void LoadEffectComplected(GameObject o, params object[] args)
//    {
//        Transform m_bindTrans = null;
//        string bindPoint = mParticleLoader.GetBindPoint();
//        m_bindTrans = Common.GetBone(mRelics.GetObj().transform, bindPoint);
//        o.transform.parent = m_bindTrans;
//        o.transform.localPosition = new Vector3(0, 0, 0);
//        o.transform.localRotation = Quaternion.identity;
//        o.transform.localScale = Vector3.one;
//        o.SetActive(true);
//        SetLoadState(5, true);
//    }

//    protected override void Release(eObjectDestroyType destroyType)
//    {
//        if (mRelics != null)
//        {
//            mRelics.DestroyGameObject(eObjectDestroyType.Memory);
//            mRelics = null;
//        }
//        if (mEffect != null)
//        {
//            mEffect.GetObj().SetActive(false);
//            mEffect.DestroyGameObject(eObjectDestroyType.Memory);
//            mEffect = null;
//        }
//        base.Release(destroyType);
//    }
//}
