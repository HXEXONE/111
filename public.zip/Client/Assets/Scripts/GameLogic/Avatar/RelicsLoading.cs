﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Protocol;

public class RelicsLoading : StageLoading
{
    private CObject mRelics;
    private CObject mExpmExpBackground;
    private CObject mExpForeground;
    private Transform relicsTran;
    private Transform backTran;
    private Transform foreTran;

    public UIBaseProgress mUIEffectProgressBar;

    private List<PYXParticle> mPYXParticle = new List<PYXParticle>();

    private TweenPosition mTweenPosition;

    private ReliceContent mReliceLoader;
    private bool bActive;

    private uint m_uiParticleID;
    private string m_modelPath;

    public LoadUICallback m_loadCallback;

    private string m_jindutiaoPath = "resources/cardbackground/prefab/building/shengqijindutiao.x";
    private string m_jindutiaoEffectPath = "resources/effect/other/ui_shengqijindutiao_effect.x";

    public class PYXParticle
    {
        public uint id;
        public uint index;
    }

    public class PYXPackItem
    {
        public uint id;
        public uint exp;
    }

    public RelicsLoading(bool bactive = false)
        : base(true, false)
    {
        bActive = bactive;
    }

    public void InitRelics(uint id)
    {
        base.Init();
        mReliceLoader = HolderManager.m_ReliceHolder.GetStaticInfo(id);


        m_modelPath = mReliceLoader.Modle;

        AddStart();
        m_uiParticleID = (uint)(bActive ? mReliceLoader.ActiveEffect : mReliceLoader.NormalEffect);
        ParticleContent pParticleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(m_uiParticleID);
        if (null != pParticleInfo)
        {
            AddLoadState(pParticleInfo.Path);
        }
        AddLoadState(m_modelPath);
        AddLoadState(m_jindutiaoPath);
        AddLoadState(m_jindutiaoEffectPath);
        AddOver();
    }

    public override void PreloadCompleted()
    {
        mRelics = new CObject(m_modelPath);
        mRelics.Name = "Relics";
        mRelics.CallBack = LoadRelicsCompleted;
        mRelics.IsMemoryFactory = true;
        mRelics.ObjectType = eObjectType.PYX;
        mRelics.Layer = DEFINE.PARTNERPAGE_LAYER;//不用DEFINE.AVATAR_LAYER,因为用这个层会把家园场景的模型也拍进来
        mRelics.LoadObject();

        if (m_loadCallback != null) m_loadCallback();
    }

    private void LoadRelicsCompleted(GameObject o, params object[] args)
    {
         if (null != o)
        {
            relicsTran = o.transform;

           GetParent.position = new Vector3(0, 0, 0);
          
            //partenrObj.transform.parent = GetParent;
            relicsTran.parent = GetParent;
            //_mRelicsAnim = relicsTran.GetComponent<Animation>();
            //_mRelicsAnim.playAutomatically = false;
            relicsTran.localScale = Vector3.zero;
            relicsTran.localPosition = mReliceLoader.FromPosition;
            relicsTran.eulerAngles = mReliceLoader.InitRotation;
        }
        
        MyUIViewport mMyUIViewport = CameraTrans.GetComponent<MyUIViewport>();
        if (mMyUIViewport != null)
        {
            mMyUIViewport.enabled = false;
        }
        CameraTrans.eulerAngles = Vector3.zero;
        CameraTrans.localPosition = Vector3.zero;
        Camera mCamera = GetCamera;
        mCamera.depth = 35;
        mCamera.fieldOfView = 40;
        mCamera.rect = new Rect(0, 0, 1, 1);
        mCamera.cullingMask = 1 << DEFINE.PARTNERPAGE_LAYER | 1 << DEFINE.EFFECT_LAYER;

        PlayParticle(m_uiParticleID,true);

        mExpmExpBackground = new CObject(m_jindutiaoPath);
        mExpmExpBackground.Name = "mExpBackground";
        mExpmExpBackground.CallBack = LoadmExpBackgroundCompleted;
        mExpmExpBackground.IsMemoryFactory = true;
        mExpmExpBackground.ObjectType = eObjectType.PYX;
        mExpmExpBackground.Layer = DEFINE.PARTNERPAGE_LAYER;
        mExpmExpBackground.LoadObject();
    }

    public void UpdataRelice(bool isActive)
    {
        if (isActive != bActive)
        {
            bActive = isActive;
            m_uiParticleID = (uint)(bActive ? mReliceLoader.ActiveEffect : mReliceLoader.NormalEffect);
            PlayParticle(m_uiParticleID, true);
        }
    }

    private void LoadmExpBackgroundCompleted(GameObject o, params object[] args)
    {
        if (o == null) { MyLog.LogError("Error : "); return; }
        backTran = o.transform;
        backTran.parent = GetParent;
        backTran.localPosition = new Vector3(0, -2.67f, 120f);
        backTran.localRotation = Quaternion.Euler(new Vector3(270f, 0, 0));
        backTran.localScale = Vector3.one;

        mExpForeground = new CObject(m_jindutiaoEffectPath);
        mExpForeground.Name = "progress";
        mExpForeground.CallBack = LoadmExpForegroundCompleted;
        mExpForeground.IsMemoryFactory = true;
        mExpForeground.ObjectType = eObjectType.PYX;
        mExpForeground.Layer = DEFINE.PARTNERPAGE_LAYER; ;
        mExpForeground.LoadObject();

        if (mTweenPosition != null)
        {
            mTweenPosition.enabled = true;
        }
    }
    
    private void LoadmExpForegroundCompleted(GameObject o, params object[] args)
    {
         if (null != o)
        {
            foreTran = o.transform;
            foreTran.parent = backTran.transform;
            foreTran.localPosition = new Vector3(0, 0f, 0f);
            foreTran.localRotation = Quaternion.Euler(new Vector3(90f, 0, 0));
            foreTran.localScale = new Vector3(1f, 1f, 1f);

            UIEffectProgressBar[] mUIEffect = foreTran.GetComponentsInChildren<UIEffectProgressBar>();
            if (mUIEffect != null && mUIEffect.Length > 0)
            {
                mUIEffectProgressBar = mUIEffect[0];
            }
        }
        if (null != relicsTran && null != mReliceLoader)
        {
            iTween.MoveTo(relicsTran.gameObject, iTween.Hash("position", mReliceLoader.ToPosition, "islocal", true, "time", 0.5f));
            iTween.ScaleTo(relicsTran.gameObject, iTween.Hash("scale", new Vector3(1f, 1f, 1f), "time", 0.5f));
        }
        if (null != backTran)
        {
            iTween.MoveTo(backTran.gameObject, iTween.Hash("position", new Vector3(0, -1.4f, 5.5f), "islocal", true, "time", 0.5f));
        }
    }

    public void PlayParticle(uint id,bool isRemove)
    {
        if (null == mRelics) return;
        if (isRemove)
        {
            for (int i = 0, j = mPYXParticle.Count; i < j; i++)
            {
                CParticleManager.GetInst().AddDestroyParticle(mPYXParticle[i].index);
            }
            mPYXParticle.Clear();
        }
        GameObject obj = mRelics.GetObj();

        if (obj != null)
        {
            PYXParticle mParticle = new PYXParticle();
            mParticle.id = id;
            mParticle.index = CParticleManager.GetInst().CreateBindEffect(id, obj,false,false,OnLoadComplete,true);
            if (isRemove)
            {
                mPYXParticle.Add(mParticle);
            }
        }
       
    }

    private void OnLoadComplete()
    {
        LookCamera[] lookCamera = mRelics.GetObj().GetComponentsInChildren<LookCamera>();
        if (lookCamera.Length > 0)
        {
            for (int i = 0, count = lookCamera.Length; i < count; i++)
                lookCamera[i].targetCameraObj = CameraTrans.gameObject;
        }
    }

    public override void Release(eObjectDestroyType destroyType)
    {
        for (int i = 0, j = mPYXParticle.Count; i < j; i++)
        {
            CParticleManager.GetInst().AddDestroyParticle(mPYXParticle[i].index);
        }
        if (null != mRelics)
        {
            mRelics.DestroyGameObject(eObjectDestroyType.Memory);
        }
        if (null != mPYXParticle)
        {
            mPYXParticle.Clear();
        }
        if (null != mExpmExpBackground)
        {
            mExpmExpBackground.DestroyGameObject(eObjectDestroyType.Memory);
        }
        if (null != mExpForeground)
        {
            mExpForeground.DestroyGameObject(eObjectDestroyType.Memory);
        }

        relicsTran = null;
        backTran = null;
        foreTran = null;

        mUIEffectProgressBar = null;

        base.Release(eObjectDestroyType.Memory);
    }

    public Transform GetRelicsTransform()
    {
        if (mRelics != null && mRelics.gameCObject != null)
        {
            return mRelics.gameCObject.transform;
        }
        return null;
    }
}
