﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EquipLoading :StageLoading {

    private CObject rightWeaponObject;
    private CObject leftWeaponObject;
    private CObject clothObject;

    private Vector3 localPosition_l;
    private Quaternion localrotation_l;
    private List<float> leftpos = new List<float>();
    private List<float> rightpos = new List<float>();
    private List<float> leftrot = new List<float>();
    private List<float> rightrot = new List<float>();

    private string m_leftWeaponPath;
    private string m_rightWeaponPath;
    private string m_clothPath;

    public EquipLoading(bool bLoop)
        : base(bLoop,true,true)
    {
        StageType = eObjectType.Weapon;
    }

    public void InitEquip(uint equipID)
    {
        CreateBackStage();
        InitEquipNoBack(equipID);
    }
    public void InitEquipNoBack(uint equipID)
    {
        base.Init(equipID);

        EquipContent equipload = HolderManager.m_EquipHolder.GetStaticInfo(equipID);
        if (null == equipload)
        {
            return;
        }

        byte eqtype = equipload.EquipType;
        if (eqtype == 0) //武器
        {
            leftpos = equipload.ModelLoader.Localposition[0].list;
            rightpos = equipload.ModelLoader.Localposition[1].list;
            leftrot = equipload.ModelLoader.Localrotation[0].list;
            rightrot = equipload.ModelLoader.Localrotation[1].list;
        }
        else    //衣服
        {

            rightpos = equipload.ModelLoader.Localposition[0].list;
            rightrot = equipload.ModelLoader.Localrotation[0].list;
        }
       
        LoadEquip();
    }

    public void CreateBackStage(string stageEquip =null)
    {
        base.CreateStage(stageEquip);
    }
    public void LoadEquip()
    {
        EquipContent equipInfo = HolderManager.m_EquipHolder.GetStaticInfo(avatarID);
        if (equipInfo == null)
        {
            return;
        }
        byte equipType = equipInfo.EquipType;

        m_leftWeaponPath = "";
        m_rightWeaponPath = "";
        m_clothPath = "";

        if (equipType == 0)
        {
            List<string> pathArray = equipInfo.ModelLoader.ModelPath;
            if (!pathArray[0].Equals("0"))
            {
                localPosition_l = new Vector3(leftpos[0], leftpos[1], leftpos[2]);
                localrotation_l = Quaternion.Euler(new Vector3(leftrot[0], leftrot[1], leftrot[2]));


                m_leftWeaponPath = pathArray[0];
            }

            if (!pathArray[1].Equals("0"))
            {
                localPosition = new Vector3(rightpos[0], rightpos[1], rightpos[2]);
                localRotation = Quaternion.Euler(new Vector3(rightrot[0], rightrot[1], rightrot[2]));


                m_rightWeaponPath = pathArray[1];
            }
        }
        else if (equipType == 1)
        {
            localPosition = new Vector3(rightpos[0], rightpos[1], rightpos[2]);
            localRotation = Quaternion.Euler(new Vector3(rightrot[0], rightrot[1], rightrot[2]));

            List<string> pathArray = equipInfo.ModelLoader.ModelPath;
            m_clothPath = pathArray[0];
        }

        AddStart();
        AddLoadState(m_leftWeaponPath);
        AddLoadState(m_rightWeaponPath);
        AddLoadState(m_clothPath);
        AddOver();
    }

    public override void PreloadCompleted()
    {
        if (m_leftWeaponPath != "")
        {
            leftWeaponObject = new CObject(m_leftWeaponPath);
            leftWeaponObject.CallBack = LoadLeftWeaponCompleted;
            leftWeaponObject.Args = new object[] { };
            leftWeaponObject.Name = avatarID.ToString() + "L";
            leftWeaponObject.IsMemoryFactory = true;
            leftWeaponObject.ObjectType = eObjectType.Weapon;
            leftWeaponObject.Layer = DEFINE.AVATAR_LAYER;
            leftWeaponObject.LoadObject();
        }

        if (m_rightWeaponPath != "")
        {
            rightWeaponObject = new CObject(m_rightWeaponPath);
            rightWeaponObject.Name = avatarID.ToString();
            rightWeaponObject.CallBack = LoadRightWeaponCompleted;
            rightWeaponObject.IsMemoryFactory = true;
            rightWeaponObject.ObjectType = eObjectType.Weapon;
            rightWeaponObject.Layer = DEFINE.AVATAR_LAYER;
            rightWeaponObject.LoadObject();
        }

        if (m_clothPath != "")
        {
            clothObject = new CObject(m_clothPath);
            clothObject.Name = avatarID.ToString();
            clothObject.CallBack = LoadClothCompleted;
            clothObject.IsMemoryFactory = true;
            clothObject.ObjectType = eObjectType.Weapon;
            clothObject.Layer = DEFINE.AVATAR_LAYER;
            clothObject.LoadObject();
        }
    }

    private void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        if (o == null)
        {
            return;
        }

        o.transform.parent = GetParent;
        o.transform.localPosition = localPosition_l;
        o.transform.localRotation = localrotation_l;
        o.transform.localScale = Vector3.one;
        Vector3 viewDirect = GetParent == null ? Vector3.forward : GetParent.transform.forward;
        DynamicShader.SetMaterialToVertexLight(o, eNpcRenderType.MeshRender, viewDirect);
    }

    private void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        if (null == o)
        {
            return;
        }
        o.transform.parent = GetParent;
        o.transform.localPosition = localPosition;
        o.transform.localRotation = localRotation;
        o.transform.localScale = Vector3.one;
        Vector3 viewDirect = GetParent == null ? Vector3.forward : GetParent.transform.forward;
        DynamicShader.SetMaterialToVertexLight(o, eNpcRenderType.MeshRender, viewDirect);
    }

    private void LoadClothCompleted(GameObject o, params object[] args)
    {
        if (null == o)
        {
            return;
        }
        o.transform.parent = GetParent;
        o.transform.localPosition = localPosition;
        o.transform.localRotation = localRotation;
        o.transform.localScale = Vector3.one;
        Vector3 viewDirect = GetParent == null ? Vector3.forward : GetParent.transform.forward;
        DynamicShader.SetMaterialToVertexLight(o, eNpcRenderType.MeshRender, viewDirect);

        Common.ShowAvatarClothes(o, true);
    }

    public override void Release(eObjectDestroyType destroyType = eObjectDestroyType.Memory)
    {
        if (leftWeaponObject != null)
        {
            leftWeaponObject.DestroyGameObject(destroyType);
        }
        if (rightWeaponObject != null)
        {

            rightWeaponObject.DestroyGameObject(destroyType);
        }

        if (clothObject != null)
        {
            clothObject.DestroyGameObject(destroyType);
        }
        base.Release(destroyType);
    }


}
