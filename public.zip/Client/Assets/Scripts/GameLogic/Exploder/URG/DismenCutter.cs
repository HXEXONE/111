﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class DismenCutter
{
    private static Dictionary<Transform, int> m_removeBP = new Dictionary<Transform, int>();
    private static List<Transform> m_bones = new List<Transform>();

    public static GameObject Dismember(Transform p_targetTrans, Material p_material, DismemberDate p_dismemDate = null, GameObject p_parentParticle = null, GameObject p_childParticle = null, bool p_cinematicCut = true)
    {
        if (p_targetTrans == null)
        {
            MyLog.LogError("Null body part. Aborting.");
            return null;
        }
        if (p_dismemDate == null)
        {
            DismemberDate[] dds = p_targetTrans.root.GetComponentsInChildren<DismemberDate>();
            if (dds.Length > 0)
            {
                p_dismemDate = dds[0];
            }
        }
        if (p_dismemDate == null)
        {
            MyLog.LogError("Null DM. Aborting.");
            return null;
        }

        int varbonecounter = p_dismemDate.m_boneIndexes.IndexOf(p_targetTrans);
        if (varbonecounter < 0)
        {
            MyLog.LogError("Bone not indexed. Aborting.");
            return null;
        }
        int varparentboneindex = p_dismemDate.m_boneIndexes.IndexOf(p_targetTrans.parent);
        if (varparentboneindex < 0)
        {
            return null;
        }

        bool varcreatestump = false;
        if (p_material != null)
        {
            varcreatestump = true;
        }

        p_dismemDate.m_parallelCutCounter++;

        GameObject tparentstump = new GameObject(p_targetTrans.name + "_stump");
        GameObject varchildstump = null;
        Transform varparentstumptransform = tparentstump.transform;
        Transform varchildstumptransform = null;
        SkinnedMeshRenderer varoriginalrenderer = p_dismemDate.m_skinnedMeshRenderer;
        SkinnedMeshRenderer varnewrenderer = null;
        Mesh varoriginalmesh = varoriginalrenderer.sharedMesh;
        Transform[] varoriginalbones = varoriginalrenderer.bones;
        Mesh varnewparentmesh = new Mesh();
        varnewparentmesh.name = "DismenCutter1";
        Mesh varnewchildmesh = null;
        Vector3[] varoriginalvertices = varoriginalmesh.vertices;
        Vector3[] varoriginalnormals = varoriginalmesh.normals;
        Vector2[] varoriginaluvs = varoriginalmesh.uv;
        BoneWeight[] varoriginalboneweights = varoriginalmesh.boneWeights;
        int[] varoriginaltriangles = varoriginalmesh.triangles;
        Matrix4x4[] varoriginalbindposes = varoriginalmesh.bindposes;
        Material[] varoriginalmaterials = varoriginalrenderer.materials;

        Transform[] varnewchildbones = new Transform[varoriginalbones.Length];
        varoriginalbones.CopyTo(varnewchildbones, 0);
        Matrix4x4[] varnewchildbindposes = new Matrix4x4[varoriginalbindposes.Length];
        varoriginalbindposes.CopyTo(varnewchildbindposes, 0);


        //m_bones.Clear();
        //m_bones.AddRange(varoriginalbones);
        //RemoveBP(p_targetTrans);



        tparentstump.layer = varoriginalbones[varparentboneindex].gameObject.layer;
        varparentstumptransform.position = p_targetTrans.position;
        varparentstumptransform.rotation = p_targetTrans.rotation;
        varparentstumptransform.localScale = p_targetTrans.lossyScale;

        int[] varcloneboneindexes = p_dismemDate.m_boneRelationsIndexes[varbonecounter].childrenSide.indexes;
        int vartotalbonestoclone = varcloneboneindexes.Length;
        int varcloneboneindex = -1;
        int varcloneparentboneindex = -1;
        GameObject varclonepart = null;
        Transform varclonetransform = null;
        Rigidbody varcurrentbody = null;
        Rigidbody varclonebody = null;
        Collider varcurrentcollider = null;
        CharacterJoint varcurrentjoint = null;
        List<int> varbonetocutpatch = new List<int>();
        int varseparationindex = 0;
        Vector3 varscale;

        for (int vardetachcounter = -1; vardetachcounter < vartotalbonestoclone; vardetachcounter++)
        {

            varclonepart = new GameObject();
            varclonetransform = varclonepart.transform;
            varcurrentjoint = null;

            if (vardetachcounter == -1)
            {
                if (varcloneboneindex >= varoriginalbones.Length)
                {
                    MyLog.LogError("DismemberDate wrong");
                    return null;
                }
                varcloneboneindex = varbonecounter;
                varchildstump = varclonepart;
                varchildstumptransform = varclonetransform;
                varnewrenderer = varclonepart.AddComponent<SkinnedMeshRenderer>();
                varnewchildmesh = new Mesh();
                varnewchildmesh.name = "DismenCutter2";
                varscale = varoriginalbones[varcloneboneindex].lossyScale;
            }
            else
            {
                varcloneboneindex = varcloneboneindexes[vardetachcounter];
                varcloneparentboneindex = p_dismemDate.m_boneIndexesParents[varcloneboneindex];
                if (varcloneparentboneindex < 0 || varcloneparentboneindex >= varnewchildbones.Length)
                {
                    MyLog.LogError("DismemberDate wrong");
                    return null;
                }
                if (varcloneboneindex < 0 || varcloneboneindex >= varoriginalbones.Length)
                {
                    MyLog.LogError("DismemberDate wrong");
                    return null;
                }
                varclonetransform.parent = varnewchildbones[varcloneparentboneindex];
                varcurrentjoint = varoriginalbones[varcloneboneindex].GetComponent<CharacterJoint>();
                varscale = varoriginalbones[varcloneboneindex].localScale;
            }

            varclonepart.name = varoriginalbones[varcloneboneindex].name;
            varclonepart.layer = varoriginalbones[varcloneboneindex].gameObject.layer;
            varclonetransform.position = varoriginalbones[varcloneboneindex].position;
            varclonetransform.rotation = varoriginalbones[varcloneboneindex].rotation;
            varclonetransform.localScale = varscale;

            //m_bones[varcloneboneindex] = varclonetransform;

            varclonebody = null;
            varcurrentbody = varoriginalbones[varcloneboneindex].rigidbody;
            if (varcurrentbody != null)
            {
                varclonebody = varclonepart.AddComponent<Rigidbody>();
                varclonebody.drag = 1;
                varclonebody.angularDrag = 1;
                varclonebody.mass = varcurrentbody.mass / 2f;
                varclonebody.isKinematic = true;
                varclonebody.constraints = varcurrentbody.constraints;
            }

            varcurrentcollider = varoriginalbones[varcloneboneindex].collider;
            if (varcurrentcollider != null)
            {
                System.Type varcurrenttype = varcurrentcollider.GetType();
                if (varcurrenttype == typeof(SphereCollider))
                {
                    SphereCollider varcurrentspherecollider = varoriginalbones[varcloneboneindex].GetComponent<SphereCollider>();
                    SphereCollider varnewscollider = varclonepart.AddComponent<SphereCollider>();
                    varnewscollider.radius = varcurrentspherecollider.radius;
                    varnewscollider.center = varcurrentspherecollider.center;
                    varnewscollider = varcurrentspherecollider;
                }
                else if (varcurrenttype == typeof(CapsuleCollider))
                {
                    CapsuleCollider varcurrentcapsulecollider = varoriginalbones[varcloneboneindex].GetComponent<CapsuleCollider>();
                    CapsuleCollider varnewccollider = varclonepart.AddComponent<CapsuleCollider>();
                    varnewccollider.height = varcurrentcapsulecollider.height;
                    varnewccollider.direction = varcurrentcapsulecollider.direction;
                    varnewccollider.radius = varcurrentcapsulecollider.radius;
                    varnewccollider.center = varcurrentcapsulecollider.center;
                }
                else if (varcurrenttype == typeof(BoxCollider))
                {
                    BoxCollider varcurrentboxcollider = varoriginalbones[varcloneboneindex].GetComponent<BoxCollider>();
                    BoxCollider varnewbcollider = varclonepart.AddComponent<BoxCollider>();
                    varnewbcollider.center = varcurrentboxcollider.center;
                    varnewbcollider.size = varcurrentboxcollider.size;
                    varnewbcollider = varcurrentboxcollider;
                }
                else if (varcurrenttype == typeof(MeshCollider))
                {
                    MeshCollider varcurrentmeshcollider = varoriginalbones[varcloneboneindex].GetComponent<MeshCollider>();
                    MeshCollider varnewmcollider = varclonepart.AddComponent<MeshCollider>();
                    varnewmcollider.sharedMesh = varcurrentmeshcollider.sharedMesh;
                    varnewmcollider.convex = varcurrentmeshcollider.convex;
                    varnewmcollider = varcurrentmeshcollider;
                }
                else if (varcurrenttype == typeof(WheelCollider))
                {
                    WheelCollider varcurrentwheelcollider = varoriginalbones[varcloneboneindex].GetComponent<WheelCollider>();
                    BoxCollider varnewwcollider = varclonepart.AddComponent<BoxCollider>();
                    varnewwcollider.center = varcurrentwheelcollider.center;
                    varnewwcollider.size = new Vector3(varcurrentwheelcollider.radius / 3, varcurrentwheelcollider.radius * 2, varcurrentwheelcollider.radius * 2);
                    if (varcurrentbody == null)
                    {
                        varclonebody = varclonepart.AddComponent<Rigidbody>();
                        varclonebody.mass = varcurrentwheelcollider.mass;
                        varclonebody.isKinematic = true;
                    }
                }
                else if (varcurrenttype == typeof(Collider))
                {
                    MyLog.LogError("Missing collider on cut.");
                    if (varchildstump != null)
                        Object.Destroy(varchildstump);
                    return null;
                }
                else
                {
                    MyLog.LogError("Can't manage collider type " + varoriginalbones[varcloneboneindex].collider.GetType().ToString());
                    if (varchildstump != null)
                        Object.Destroy(varchildstump);
                    return null;
                }
            }

            if (varcurrentjoint != null)
            {
                if (p_dismemDate.m_boneIndexesCharacterJointConnect[varcloneboneindex] > -1)
                {
                    varcurrentjoint = varclonepart.AddComponent<CharacterJoint>();

                    Rigidbody varexistingbody = varnewchildbones[p_dismemDate.m_boneIndexesCharacterJointConnect[varcloneboneindex]].rigidbody;
                    if (varexistingbody == null)
                    {
                        varcurrentjoint.connectedBody = varnewchildbones[varbonecounter].rigidbody;
                    }
                    else
                    {
                        varcurrentjoint.connectedBody = varnewchildbones[p_dismemDate.m_boneIndexesCharacterJointConnect[varcloneboneindex]].rigidbody;
                    }
                }
            }

            if (p_dismemDate.m_cutPartScache == null)
                p_dismemDate.m_cutPartScache = new List<Transform>();
            p_dismemDate.m_cutPartScache.Add(varoriginalbones[varcloneboneindex]);
            varnewchildbones[varcloneboneindex] = varclonetransform;
        }

        int varconnectors = p_dismemDate.m_rigidbodyConnections[varbonecounter].indexes.Length;
        if (varconnectors > 1)
        {
            int varconnectionindex = p_dismemDate.m_rigidbodyConnections[varbonecounter].indexes[0];

            varcurrentbody = varoriginalbones[varconnectionindex].rigidbody;
            if (varcurrentbody != null)
            {
                for (int varconnectorcounter = 1; varconnectorcounter < p_dismemDate.m_rigidbodyConnections[varbonecounter].indexes.Length; varconnectorcounter++)
                {
                    varconnectionindex = p_dismemDate.m_rigidbodyConnections[varbonecounter].indexes[varconnectorcounter];
                    if (varoriginalbones[varconnectionindex] != null)
                    {
                        varcurrentjoint = varoriginalbones[varconnectionindex].GetComponent<CharacterJoint>();
                        if (varcurrentjoint != null)
                        {
                            varcurrentjoint.connectedBody = varcurrentbody;
                        }
                    }
                }
            }
        }

        int varseparationverticescount = p_dismemDate.m_boneSeparationVertices[varbonecounter].indexes.Length;
        int varpatchtriangles = 0;
        int varparenttrianglesindex = 0;
        int varparenttriangleslength = 0;
        int varchildtrianglesindex = 0;
        int[] varnewparenttriangles = new int[0];
        int[] varnewchildtriangles = new int[0];
        if (varseparationverticescount > 0)
        {
            varpatchtriangles = (varseparationverticescount - 2) * 3;
        }

        varparenttrianglesindex = varoriginaltriangles.Length;
        varparenttriangleslength = varparenttrianglesindex;
        varchildtrianglesindex = p_dismemDate.m_boneFullTrianglesIndexes[varbonecounter].indexes.Length * 3;
        varnewparenttriangles = new int[varparenttrianglesindex + varpatchtriangles];
        varnewchildtriangles = new int[varchildtrianglesindex + varpatchtriangles];
        varoriginaltriangles.CopyTo(varnewparenttriangles, 0);

        int vartriangleindex;
        int vartrianglechildindex;

        int varindex2, varindex3;
        for (int varstumptrianglecounter = 0; varstumptrianglecounter < p_dismemDate.m_boneFullTrianglesIndexes[varbonecounter].indexes.Length; varstumptrianglecounter++)
        {
            vartriangleindex = p_dismemDate.m_boneFullTrianglesIndexes[varbonecounter].indexes[varstumptrianglecounter];
            varindex2 = vartriangleindex + 1;
            varindex3 = vartriangleindex + 2;

            varnewparenttriangles[vartriangleindex] = 0;
            varnewparenttriangles[varindex2] = 0;
            varnewparenttriangles[varindex3] = 0;

            vartrianglechildindex = varstumptrianglecounter * 3;
            varnewchildtriangles[vartrianglechildindex] = varoriginaltriangles[vartriangleindex];
            varnewchildtriangles[vartrianglechildindex + 1] = varoriginaltriangles[varindex2];
            varnewchildtriangles[vartrianglechildindex + 2] = varoriginaltriangles[varindex3];
        }

        int varmaterialscount = varoriginalmaterials.Length;
        int varstumpmaterialindex = -1;
        Material[] varnewparentmaterials = new Material[0];
        Material[] varnewchildmaterials;
        bool varaddedstumpmaterial = false;
        int[] varstumpmaterialsubmeshtriangles = new int[0];
        if (p_material != null)
        {
            for (int varmaterialscounter = 0; varmaterialscounter < varmaterialscount; varmaterialscounter++)
            {
                if (varoriginalmaterials[varmaterialscounter].name == p_material.name || varoriginalmaterials[varmaterialscounter].name == p_material.name + " (Instance)")
                {
                    varstumpmaterialindex = varmaterialscounter;
                    varstumpmaterialsubmeshtriangles = varoriginalmesh.GetTriangles(varstumpmaterialindex);
                    break;
                }
            }
            if (varstumpmaterialindex < 0)
            {
                varnewparentmaterials = new Material[varmaterialscount + 1];
                varoriginalmaterials.CopyTo(varnewparentmaterials, 0);
                varnewparentmaterials[varmaterialscount] = p_material;
                varstumpmaterialindex = varmaterialscount;
                varaddedstumpmaterial = true;
            }
            else
            {
                varnewparentmaterials = varoriginalmaterials;
            }
        }
        else
        {
            varnewparentmaterials = varoriginalmaterials;
        }
        varnewchildmaterials = new Material[varnewparentmaterials.Length];
        varnewparentmaterials.CopyTo(varnewchildmaterials, 0);

        int vardetachindex;

        int[] varrelatedboneindexes = p_dismemDate.m_boneRelationsIndexes[varbonecounter].parentSide.indexes;
        int varcurrenttriangleindex;
        int[] vartemptriangles;
        int vartemptrianglesindexer = 0;
        for (int vardetachcounter = 0; vardetachcounter < varrelatedboneindexes.Length; vardetachcounter++)
        {
            vardetachindex = varrelatedboneindexes[vardetachcounter];
            varnewchildbones[vardetachindex] = varchildstumptransform;
            varnewchildbindposes[vardetachindex] = varoriginalbindposes[varbonecounter];
        }
        varparenttriangleslength = p_dismemDate.m_boneSeparationSubMeshHelper.Length * 3;

        varrelatedboneindexes = p_dismemDate.m_boneRelationsIndexes[varbonecounter].childrenSide.indexes;
        for (int vardetachcounter = 0; vardetachcounter < varrelatedboneindexes.Length; vardetachcounter++)
        {
            vardetachindex = varrelatedboneindexes[vardetachcounter];

            varoriginalbones[vardetachindex] = varparentstumptransform;
            varoriginalbindposes[vardetachindex] = varoriginalbindposes[varbonecounter];

            varseparationindex = p_dismemDate.m_boneseparationPatchTriangleIndexes[vardetachindex].indexes.Length;
            if (varseparationindex > 0)
            {
                vartemptriangles = new int[varseparationindex * 3];
                vartemptrianglesindexer = 0;
                for (int vartriangleindexcounter = 0; vartriangleindexcounter < varseparationindex; vartriangleindexcounter++)
                {
                    varcurrenttriangleindex = p_dismemDate.m_boneseparationPatchTriangleIndexes[vardetachindex].indexes[vartriangleindexcounter];

                    vartemptriangles[vartemptrianglesindexer] = varstumpmaterialsubmeshtriangles[varcurrenttriangleindex];
                    vartemptriangles[vartemptrianglesindexer + 1] = varstumpmaterialsubmeshtriangles[varcurrenttriangleindex + 1];
                    vartemptriangles[vartemptrianglesindexer + 2] = varstumpmaterialsubmeshtriangles[varcurrenttriangleindex + 2];

                    varstumpmaterialsubmeshtriangles[varcurrenttriangleindex] = 0;
                    varstumpmaterialsubmeshtriangles[varcurrenttriangleindex + 1] = 0;
                    varstumpmaterialsubmeshtriangles[varcurrenttriangleindex + 2] = 0;
                    vartemptrianglesindexer += 3;
                }

                varbonetocutpatch.AddRange(vartemptriangles);

                p_dismemDate.m_boneseparationPatchTriangleIndexes[vardetachindex].indexes = new int[0];
            }
        }

        tparentstump.transform.parent = varoriginalbones[varparentboneindex];

        int[] varnewchildpatchtriangles = new int[0];
        int[] varnewparentpatchtriangles = new int[0];

        if (varcreatestump)
        {
            int varloopvertices = p_dismemDate.m_boneSeparationVertices[varbonecounter].indexes.Length;
            int varstart, varend, varnewdimension;
            varstart = varoriginalvertices.Length;
            varend = varloopvertices;
            varnewdimension = varstart + varend;
            Vector3 varnewparentnormalvector = p_dismemDate.m_originalBonePositions[varbonecounter] - p_dismemDate.m_originalBonePositions[varparentboneindex];
            Vector3 varnewchildnormalvector = p_dismemDate.m_originalBonePositions[varparentboneindex] - p_dismemDate.m_originalBonePositions[varbonecounter];
            Vector3[] varnewvertices = new Vector3[varnewdimension];
            Vector2[] varnewuvs = new Vector2[varnewdimension];
            Vector3[] varnewparentnormals = new Vector3[varnewdimension];
            Vector3[] varnewchildnormals = new Vector3[varnewdimension];
            BoneWeight[] varnewboneweights = new BoneWeight[varnewdimension];
            int[] varnewverticesindices = new int[varloopvertices];
            int varcurrentvertexindex, varextendedvertexindex;
            varoriginalvertices.CopyTo(varnewvertices, 0);
            varoriginaluvs.CopyTo(varnewuvs, 0);
            varoriginalnormals.CopyTo(varnewparentnormals, 0);
            varoriginalnormals.CopyTo(varnewchildnormals, 0);
            varoriginalboneweights.CopyTo(varnewboneweights, 0);
            for (int varnewvertexcounter = 0; varnewvertexcounter < varloopvertices; varnewvertexcounter++)
            {
                varcurrentvertexindex = p_dismemDate.m_boneSeparationVertices[varbonecounter].indexes[varnewvertexcounter];
                varextendedvertexindex = varnewvertexcounter + varstart;
                varnewvertices[varextendedvertexindex] = varoriginalvertices[varcurrentvertexindex];
                varnewboneweights[varextendedvertexindex] = varoriginalboneweights[varcurrentvertexindex];
                varnewparentnormals[varextendedvertexindex] = varnewparentnormalvector;
                varnewchildnormals[varextendedvertexindex] = varnewchildnormalvector;
                varnewverticesindices[varnewvertexcounter] = varextendedvertexindex;
            }
            p_dismemDate.m_boneSeparationVerticesUV[varbonecounter].uvcoordInates.CopyTo(varnewuvs, varstart);

            varnewchildpatchtriangles = new int[varpatchtriangles];
            varnewparentpatchtriangles = new int[varpatchtriangles];

            int varvertexindex0 = varnewverticesindices[0];
            int varvertexindex1;
            int varvertexindex2;
            int varvertexindex0aux, varvertexindex1aux, varvertexindex2aux;

            int vartriangleoffsetter = 0;
            for (int varseparationverticescounter = 2; varseparationverticescounter < varseparationverticescount; varseparationverticescounter++)
            {
                varvertexindex0aux = varseparationverticescounter - 2 + vartriangleoffsetter;
                varvertexindex1aux = varseparationverticescounter - 1 + vartriangleoffsetter;
                varvertexindex2aux = varseparationverticescounter + vartriangleoffsetter;

                varvertexindex1 = varnewverticesindices[varseparationverticescounter - 1];
                varvertexindex2 = varnewverticesindices[varseparationverticescounter];
                varnewparentpatchtriangles[varvertexindex0aux] = varvertexindex0;
                varnewparentpatchtriangles[varvertexindex1aux] = varvertexindex1;
                varnewparentpatchtriangles[varvertexindex2aux] = varvertexindex2;

                varnewchildpatchtriangles[varvertexindex0aux] = varvertexindex0;
                varnewchildpatchtriangles[varvertexindex1aux] = varvertexindex2;
                varnewchildpatchtriangles[varvertexindex2aux] = varvertexindex1;
                vartriangleoffsetter += 2;
            }

            varnewparentpatchtriangles.CopyTo(varnewparenttriangles, varparenttrianglesindex);
            varnewchildpatchtriangles.CopyTo(varnewchildtriangles, varchildtrianglesindex);

            int[] varnewparenttrianglessubmesh = new int[varparenttriangleslength];
            System.Array.Copy(varnewparenttriangles, varnewparenttrianglessubmesh, varparenttriangleslength);


            varoriginalbones[varbonecounter] = tparentstump.transform;

            varnewparentmesh.vertices = varnewvertices;
            varnewparentmesh.normals = varnewparentnormals;
            varnewparentmesh.uv = varnewuvs;
            varnewparentmesh.boneWeights = varnewboneweights;
            varnewparentmesh.triangles = varnewparenttriangles;
            varnewparentmesh.bindposes = varoriginalbindposes;

            varnewchildmesh.vertices = varnewvertices;
            varnewchildmesh.normals = varnewchildnormals;
            varnewchildmesh.uv = varnewuvs;
            varnewchildmesh.boneWeights = varnewboneweights;
            varnewchildmesh.triangles = varnewchildtriangles;
            varnewchildmesh.bindposes = varnewchildbindposes;

        }
        else
        {
            varoriginalbones[varbonecounter] = tparentstump.transform;

            varnewparentmesh.vertices = varoriginalvertices;
            varnewparentmesh.normals = varoriginalnormals;
            varnewparentmesh.uv = varoriginaluvs;
            varnewparentmesh.boneWeights = varoriginalboneweights;
            varnewparentmesh.triangles = varnewparenttriangles;
            varnewparentmesh.bindposes = varoriginalbindposes;

            varnewchildmesh.vertices = varoriginalvertices;
            varnewchildmesh.normals = varoriginalnormals;
            varnewchildmesh.uv = varoriginaluvs;
            varnewchildmesh.boneWeights = varoriginalboneweights;
            varnewchildmesh.triangles = varnewchildtriangles;
            varnewchildmesh.bindposes = varnewchildbindposes;

        }

        int varsubmeshcount = varoriginalmesh.subMeshCount;

        if (varaddedstumpmaterial)
        {
            varsubmeshcount++;
        }
        int[][] varsubmeshmatrix = new int[varsubmeshcount][];
        int[][] varsubmeshmatrixchild = new int[varsubmeshcount][];
        for (int varsubmeshcounter = 0; varsubmeshcounter < varsubmeshcount; varsubmeshcounter++)
        {
            if (varsubmeshcounter == varstumpmaterialindex)
            {
                varsubmeshmatrix[varsubmeshcounter] = new int[varstumpmaterialsubmeshtriangles.Length + varnewparentpatchtriangles.Length];
                varstumpmaterialsubmeshtriangles.CopyTo(varsubmeshmatrix[varsubmeshcounter], 0);
                varnewparentpatchtriangles.CopyTo(varsubmeshmatrix[varsubmeshcounter], varstumpmaterialsubmeshtriangles.Length);

                varbonetocutpatch.AddRange(varnewchildpatchtriangles);
                varsubmeshmatrixchild[varsubmeshcounter] = varbonetocutpatch.ToArray();
            }
            else
            {
                varsubmeshmatrix[varsubmeshcounter] = varoriginalmesh.GetTriangles(varsubmeshcounter);
                varsubmeshmatrixchild[varsubmeshcounter] = new int[varsubmeshmatrix[varsubmeshcounter].Length];
            }
        }

        if (varnewparenttriangles.Length > 0)
        {
            for (int varnewparenttrianglescounter = 0; varnewparenttrianglescounter < varparenttriangleslength; varnewparenttrianglescounter += 3)
            {
                if (varnewparenttriangles[varnewparenttrianglescounter] == 0 && varnewparenttriangles[varnewparenttrianglescounter + 1] == 0)
                {
                    int vartrianglesubmesh = (int)p_dismemDate.m_boneSeparationSubMeshHelper[varnewparenttrianglescounter / 3].x;
                    int vartrianglesubmeshindex = (int)p_dismemDate.m_boneSeparationSubMeshHelper[varnewparenttrianglescounter / 3].y * 3;

                    varsubmeshmatrix[vartrianglesubmesh][vartrianglesubmeshindex] = 0;
                    varsubmeshmatrix[vartrianglesubmesh][vartrianglesubmeshindex + 1] = 0;
                    varsubmeshmatrix[vartrianglesubmesh][vartrianglesubmeshindex + 2] = 0;

                    varsubmeshmatrixchild[vartrianglesubmesh][vartrianglesubmeshindex] = varoriginaltriangles[varnewparenttrianglescounter];
                    varsubmeshmatrixchild[vartrianglesubmesh][vartrianglesubmeshindex + 1] = varoriginaltriangles[varnewparenttrianglescounter + 1];
                    varsubmeshmatrixchild[vartrianglesubmesh][vartrianglesubmeshindex + 2] = varoriginaltriangles[varnewparenttrianglescounter + 2];
                }
            }
        }

        varnewparentmesh.subMeshCount = varsubmeshcount;
        varnewchildmesh.subMeshCount = varsubmeshcount;

        for (int varsubmeshcounter = 0; varsubmeshcounter < varsubmeshcount; varsubmeshcounter++)
        {
            varnewparentmesh.SetTriangles(varsubmeshmatrix[varsubmeshcounter], varsubmeshcounter);
            varnewchildmesh.SetTriangles(varsubmeshmatrixchild[varsubmeshcounter], varsubmeshcounter);
        }

        int varnewparentpatchindex = varstumpmaterialsubmeshtriangles.Length;
        p_dismemDate.m_boneseparationPatchTriangleIndexes[varbonecounter].indexes = new int[varnewparentpatchtriangles.Length / 3];
        for (int varnewparentpatchindexcounter = 0; varnewparentpatchindexcounter < p_dismemDate.m_boneseparationPatchTriangleIndexes[varbonecounter].indexes.Length; varnewparentpatchindexcounter++)
        {
            p_dismemDate.m_boneseparationPatchTriangleIndexes[varbonecounter].indexes[varnewparentpatchindexcounter] = varnewparentpatchindex;
            varnewparentpatchindex += 3;
        }


        p_dismemDate.m_skinnedMeshRenderer.bones = varoriginalbones;
        p_dismemDate.m_skinnedMeshRenderer.sharedMesh = varnewparentmesh;
        p_dismemDate.m_skinnedMeshRenderer.materials = varnewparentmaterials;

        varnewrenderer.bones = varnewchildbones;
        varnewrenderer.sharedMesh = varnewchildmesh;
        varnewrenderer.materials = varnewchildmaterials;


        p_dismemDate.m_parallelCutCounter--;
        if (p_dismemDate.m_parallelCutCounter == 0)
        {
            for (int vardestroycounter = 0; vardestroycounter < p_dismemDate.m_cutPartScache.Count; vardestroycounter++)
            {
                if (p_dismemDate.m_cutPartScache[vardestroycounter].gameObject != null)
                {
                    GameObject.Destroy(p_dismemDate.m_cutPartScache[vardestroycounter].gameObject);
                }
            }
            p_dismemDate.m_cutPartScache.Clear();
        }


        if (p_parentParticle != null)
        {
            GameObject varparentparticle = GameObject.Instantiate(p_parentParticle, varparentstumptransform.position, varparentstumptransform.rotation) as GameObject;
            varparentparticle.transform.parent = varparentstumptransform;
        }
        if (p_parentParticle != null)
        {
            GameObject varchildparticle = GameObject.Instantiate(p_parentParticle, varchildstumptransform.position, Quaternion.Inverse(varchildstumptransform.rotation)) as GameObject;
            varchildparticle.transform.parent = varchildstumptransform;
        }

        if (p_cinematicCut)
        {
            Rigidbody[] varstumpbodies = varchildstump.GetComponentsInChildren<Rigidbody>();
            for (int varchildcounter = 0; varchildcounter < varstumpbodies.Length; varchildcounter++)
            {
                varstumpbodies[varchildcounter].isKinematic = false;
                varstumpbodies[varchildcounter].velocity = Vector3.zero;
                varstumpbodies[varchildcounter].angularVelocity = Vector3.zero;
            }
            if (varchildstump.rigidbody != null)
            {
                varchildstump.rigidbody.velocity = Vector3.zero;
                varchildstump.rigidbody.angularVelocity = Vector3.zero;
            }
        }

        //GetBP();

        return varchildstump;
    }



    private static void RemoveBP(Transform root)
    {
        m_removeBP.Clear();
        if (root != null)
        {
            int index = -1;
            Transform[] bps = root.GetComponentsInChildren<Transform>();
            for (int i = 0; i < bps.Length; i++)
            {
                if (bps[i].name.Contains("BP_"))
                {
                    index = m_bones.IndexOf(bps[i].parent);
                    if (index > -1)
                    {
                        m_removeBP.Add(bps[i], index);
                        bps[i].parent = null;
                    }
                }
            }
        }
    }

    private static void GetBP()
    {
        foreach(KeyValuePair<Transform,int> val in m_removeBP)
        {
            val.Key.parent = m_bones[val.Value];
        }
    }
}
