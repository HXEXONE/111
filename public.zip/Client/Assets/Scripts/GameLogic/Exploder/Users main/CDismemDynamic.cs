﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CDismemDynamic : CBaseExploder
{
    private GameObject m_dismemor;
    private DismemberDate m_dismemData;

    private float m_downForce = 10;

    private float m_wh_ratio = 0.2f;  //宽高比

    private float m_addForceTime = 0.2f;

    private float m_upSpeed = 50;

    public CDismemDynamic(string ID, int cutNum, float fadeTime)
        : base(ID, cutNum, fadeTime)
    {
        m_state = eExploderState.Update;
    }

    public override GameObject GetExploderObj(eExploderType type, GameObject exploded, RegisterEvent callback = null, params object[] args)
    {
        m_exploder = Object.Instantiate(exploded) as GameObject;

        Component[] components = m_exploder.GetComponents<Component>();
        if (components != null)
        {
            int len = components.Length;
            for (int i = 0; i < len; i++)
            {
                System.Type componentType = components[i].GetType();
                if (componentType != typeof(DismemberDate) && componentType != typeof(Transform) && componentType != typeof(Rigidbody))
                    Object.DestroyImmediate(components[i]);
            }
        }

        exploded.SetActive(false);
        sExploderObject eo = GetExploder(type);

        return eo.go;
    }

    protected override sExploderObject GetExploder(eExploderType type)
    {
        sExploderObject eo = new sExploderObject();
        m_dismemData = m_exploder.GetComponent<DismemberDate>();
        m_dismemData.m_material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTILT_SCREEN_BLEND_ALPHA_3000);
        if (m_dismemData == null)
        {
            MyLog.LogError("Object has not DismemberDate Component:"+m_exploder.name);
            return eo;
        }
        Transform bipBone = GetBip(type,m_exploder.transform);

        if (bipBone == null)
        {
            MyLog.LogError("Object has not This bone:"+ m_exploder.name);
            return eo;
        }
        bool isRight = ChickTarget(bipBone);
        if (!isRight)
        {
            return eo;
        }

        SkinnedMeshRenderer[] smrs = m_exploder.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        Material[] mats = smrs[0].materials;
        int count = mats.Length;
        for (int i = 0; i < count; i++)
        {
            mats[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
        }


        Rigidbody[] rigidbodys = m_exploder.GetComponentsInChildren<Rigidbody>();
        int rigidbodyCount = rigidbodys.Length;
        for (int i = 0; i < rigidbodyCount; i++)
        {
            rigidbodys[i].useGravity = true;
            rigidbodys[i].isKinematic = false;
        }

        m_dismemor = DismenCutter.Dismember(bipBone, m_dismemData.m_material, m_dismemData);

        SkinnedMeshRenderer smr = m_dismemor.GetComponent<SkinnedMeshRenderer>();
        Material[] mats1 = smr.materials;

        eo.parentObj = m_exploder;
        eo.go = m_dismemor;
        eo.mats = new List<Material>();
        eo.mats.AddRange(mats);
        eo.mats.AddRange(mats1);
        eo.lastUseTime = Time.time;
        eo.trans = m_dismemor.transform;
        eo.trans.parent = m_root.transform;
        eo.bUseing = true;

        Rigidbody[] rig = m_dismemor.GetComponentsInChildren<Rigidbody>();

        if (rig != null)
        {
            switch (type)
            {
                case eExploderType.LeftArm: eo.force = m_exploder.transform.TransformDirection(-Vector3.right) * m_wh_ratio + Vector3.up; break;
                case eExploderType.LeftThigh: eo.force = m_exploder.transform.TransformDirection(-Vector3.forward); break;
                case eExploderType.RightArm: eo.force = m_exploder.transform.TransformDirection(Vector3.right) * m_wh_ratio + Vector3.up; break;
                case eExploderType.RightThigh: eo.force = m_exploder.transform.TransformDirection(-Vector3.forward); break;
                case eExploderType.UpDown: eo.force = Vector3.up + m_exploder.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
                case eExploderType.Head: eo.force = Vector3.up + m_exploder.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
            }
            eo.force.Normalize();
            eo.downForce = -Vector3.up * m_downForce * 9.8f * rig[0].mass;
            eo.startTime = Time.time;

            if (type == eExploderType.UpDown)
                rig[0].velocity = m_upSpeed * eo.force * 2;
            else
                rig[0].velocity = m_upSpeed * eo.force;
        }
        else
        {
            eo.force = Vector3.zero;
            eo.downForce = Vector3.zero;
            eo.startTime = -1;
        }

        

        m_explodedUsing.Add(eo);

        m_dismemData = null;
        m_dismemor = null;

        return eo;
    }

    private bool ChickTarget(Transform trans)
    {
        if (trans != null)
        {
            CharacterJoint cj = trans.GetComponent<CharacterJoint>();
            if (cj == null)
            {
                MyLog.LogError("bone " + trans.name + "not contain CharacterJoint Component");
                return false;
            }
            return true;
        }
        return false;
    }

    protected override void ForUpdate()
    {
        int count = m_explodedUsing.Count;
        sExploderObject val;
        for (int i = 0; i < count; i++)
        {
            val = m_explodedUsing[i];
            if (Time.time > val.lastUseTime + m_fadeTime)
            {
                val.alpha -= Time.deltaTime * m_fadeSpeed;
                val.alpha = Mathf.Clamp01(val.alpha);
                
                int matCount = val.mats.Count;
                for (int mi = 0; mi < matCount; mi++)
                {
                    val.mats[mi].SetFloat("_AlphaCon", val.alpha);
                }
                if (val.alpha <= 0.001f)
                {
                    m_temp.Add(val);
                }
            }
            if (val.force != Vector3.zero && val.downForce != Vector3.zero && val.startTime >= 0)
            {
                if (Time.time > val.startTime + m_addForceTime)
                    val.go.rigidbody.AddForce(val.downForce);
            }

            m_explodedUsing[i] = val;
        }

        count = m_temp.Count;
        for (int i = 0; i < count; i++)
        {
            Object.Destroy(m_temp[i].go);
            Object.Destroy(m_temp[i].parentObj);
            m_explodedUsing.Remove(m_temp[i]);
        }

        m_temp.Clear();
    }

}
