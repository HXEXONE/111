﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eExploderType
{
    None = 0,     //无

    Double = 1,   //掉两只手(破碎)

    LeftForeArm = 2,  //掉左手（从腕关节开始）
    RightForeArm = 3, //掉右手（从腕关节开始）

    LeftArm = 4,     //掉左手(整个手臂)
    RightArm = 5,    //掉右手(整个手臂)
    UpDown = 6,   //掉上体（手臂与上体相连） 

    LeftThigh = 7,   //掉左大腿
    RightThigh = 8,  //掉右大腿

    Head = 9,       //掉头

    LeftCalf = 10,    //掉左小腿
    RightCalf = 11,  //掉右小腿
}

public enum eExploderMemoryType
{
    Memory = 0,       //进入场景已经创建（截面）
    MemoryDynamic = 1,//动态创建，创建后用内存池回收（截面）
    Dismemer = 2,     //动态创建，直接删除（截肢）
    DismemerMemory = 3,     //内存池（截肢）
    Exploder = 4,     //破碎
}

public class sExploderObject
{
    public GameObject go;
    public GameObject parentObj;
    public Transform parentTran;
    public Transform trans;
    public List<Material> mats;
    public bool bUseing;
    public float lastUseTime;
    public float alpha;
    public IList<Collider> collider;
    public IList<Rigidbody> rigidbodyList;
    public Rigidbody rigidbody;
    public Quaternion rotate;
    public Color[] color;
    public Vector3 force;
    public Vector3 downForce;
    public float startTime;
    public eExploderType type;
    public bool isActive;

    public sExploderObject()
    {
        isActive = true;
    }

    public sExploderObject(sExploderObject instance,bool removeFade)
    {
        parentObj = Object.Instantiate(instance.parentObj) as GameObject;
        parentTran = parentObj.transform;
        parentObj.name = instance.parentObj.name;
        trans = Common.GetBone(parentObj.transform, instance.trans.name);
        
        go = trans.GetChild(0).gameObject;

        
            SkinnedMeshRenderer[] smr = parentObj.GetComponentsInChildren<SkinnedMeshRenderer>();
            int count = smr.Length;
            mats = new List<Material>();
            for (int i = 0; i < count; i++)
            {
                if (smr.Length > 0)
                {
                    mats.AddRange(smr[i].materials);
                }
            }
    
        if (!removeFade)
        {
            int len;
            Collider[] colliderList = parentObj.GetComponentsInChildren<Collider>();
            if (colliderList != null)
                collider = new List<Collider>(colliderList);
            len = collider.Count;
            for (int i = 0; i < len; i++)
            {
                if (collider[i] != null)
                    collider[i].enabled = true;
            }

            Rigidbody[] rigidbodys = parentObj.GetComponentsInChildren<Rigidbody>();
            if (rigidbodys != null)
                rigidbodyList = new List<Rigidbody>(rigidbodys);

            len = rigidbodyList.Count;
            for (int i = 0; i < len; i++)
            {
                if (rigidbodyList[i] != null)
                    rigidbodyList[i].useGravity = true;
            }
        }

        Rigidbody rig = go.GetComponent<Rigidbody>();
        rigidbody = rig;

        color = instance.color;
        bUseing = false;
        isActive = true;
        lastUseTime = -1;
        alpha = 1;
        type = instance.type;
        force = instance.force;
        downForce = instance.downForce;
    }
}

public enum eExploderState
{
    None,
    Init,
    Dismem,
    Update,
}

public class CBaseExploder {

    protected static GameObject m_root;
    protected static GameObject m_ecplodedObjectsContainer;
    protected static Transform m_ecplodedObjectsContainerTran;
    protected Transform m_groopTrans;
    protected int m_count;
    protected int m_realCount;
    protected float m_fadeTime;

    protected Color m_color;
    protected eExploderState m_state;
    protected float m_fadeSpeed;
    protected GameObject m_exploder;

    protected List<sExploderObject> m_explodedUsing = new List<sExploderObject>();
    protected List<sExploderObject> m_explodedNotUsed = new List<sExploderObject>();

    protected List<sExploderObject> m_temp = new List<sExploderObject>();

    protected GameObject[] m_childs;

    private bool m_enableUpdate = true;
    protected bool m_canGetExploderObject = false;

    protected bool m_removeFade = true;
    protected float m_removeNotFadeTime = 0.5f;
    protected Vector3 m_downDirect = -Vector3.up;
    protected float m_m_downDragForce = 5f;
    protected Vector3 m_downSpeed;

    public static void Init()
    {
        m_root = new GameObject("ExploderGameObject");
        UnityEngine.Object.DontDestroyOnLoad(m_root);

        m_ecplodedObjectsContainer = new GameObject("EcplodedObjectsContainer");
        m_ecplodedObjectsContainerTran = m_ecplodedObjectsContainer.transform;
        m_ecplodedObjectsContainerTran.parent = m_root.transform;
    }

    public CBaseExploder()
    {
        if (m_root == null)
            return;
        m_state = eExploderState.None;
        m_enableUpdate = false;
    }

    public CBaseExploder(string ID, int cutNum, float fadeTime)
    {
        if (m_root == null)
            return;

        m_fadeTime = fadeTime;
        GameObject go = new GameObject(ID);
        m_groopTrans = go.transform;
        m_groopTrans.parent = m_root.transform;
        m_realCount = 0;
        m_fadeSpeed = 0.5f;
        m_count = cutNum;

        m_state = eExploderState.Init;

        m_enableUpdate = true;
    }

    public void Update()
    {
        if (!m_enableUpdate)
            return;
        switch (m_state)
        {
            case eExploderState.None: break;
            case eExploderState.Init: CreateExploder(); break;
            case eExploderState.Dismem: DismenGameObjectInList(); break;
            case eExploderState.Update: ForUpdate(); break;
            default: break;
        }
    }

    protected virtual void ForUpdate()
    {

    }

    public virtual GameObject GetExploderObj(eExploderType type, GameObject exploded, RegisterEvent callback = null, params object[] args)
    {
        return null;
    }

    protected virtual sExploderObject GetExploder(eExploderType type)
    {
        return new sExploderObject();
    }

    protected virtual void CreateExploder()
    {
        
    }

    protected virtual void DismenGameObjectInList()
    {
 
    }

    protected virtual void RetrieveObj(sExploderObject eb)
    {

    }

    //protected void SetActive(GameObject go, bool show)
    //{
    //    go.SetActive(show);
    //}

    protected int Swap(sExploderObject a, sExploderObject b)
    {
        float temp = a.lastUseTime - b.lastUseTime;
        int result = 0;
        if (temp > 0)
            result = -1;
        else if (temp < 0)
            result = 1;
        return result;
    }

    protected virtual void Fade(sExploderObject eb)
    {
        eb.alpha -= m_fadeSpeed * Time.deltaTime;
        if (eb.alpha <= 0)
        {
            eb.alpha = 0;
            m_temp.Add(eb);
        }
        Color color = m_color;
        color.a = eb.alpha;

        int count = eb.mats.Count;
        for (int i = 0; i < count; i++)
        {
            eb.mats[i].color = color;
        }
    }

    public virtual void Release(bool delete)
    {
        m_canGetExploderObject = false;
        sExploderObject temp;
        if (delete)
        {
            GameObject destory;
            m_state = eExploderState.None;
            int count = m_explodedUsing.Count;
            for (int i = 0; i < count; i++)
            {
                temp = m_explodedUsing[i];
                destory = temp.parentObj;
                temp.parentObj = null;
                temp.parentTran = null;
                if (destory != null)
                    Object.Destroy(destory);

                destory = temp.go;
                temp.go = null;
                temp.trans = null;
                if (destory != null)
                    Object.Destroy(destory);

                temp.trans = null;
            }
            m_explodedUsing.Clear();
            count = m_explodedNotUsed.Count;
            temp = null;
            for (int i = 0; i < count; i++)
            {
                temp = m_explodedNotUsed[i];
                destory = temp.parentObj;
                temp.parentObj = null;
                temp.parentTran = null;
                if (destory != null)
                    Object.Destroy(destory);

                destory = temp.go;
                temp.go = null;
                if (destory != null)
                    Object.Destroy(destory);

                temp.trans = null;
            }
            m_explodedNotUsed.Clear();
            Object.Destroy(m_groopTrans.gameObject);
            m_realCount = 0;
            m_enableUpdate = false;
            temp = null;
        }
        else
        {
            int countUse = m_explodedUsing.Count;
            for (int i = 0; i < countUse; i++)
            {
                temp = m_explodedUsing[i];

                temp.alpha = 1;

                temp.bUseing = false;
                temp.lastUseTime = -1;

                if (m_removeFade)
                {
                    if (temp.mats != null)
                    {
                        int count = temp.mats.Count;
                        for (int m = 0; m < count; m++)
                        {
                            temp.mats[m].SetFloat("_AlphaCon", 1);
                        }
                    }
                }
                else
                {
                    if (temp.collider != null)
                    {
                        int len = temp.collider.Count;
                        for (int c = 0; c < len; c++)
                        {
                            if (temp.collider[c] != null)
                                temp.collider[c].enabled = true;
                        }
                    }

                    if (temp.rigidbodyList != null)
                    {
                        int len = temp.rigidbodyList.Count;
                        for (int c = 0; c < len; c++)
                        {
                            if (temp.rigidbodyList[c] != null)
                                temp.rigidbodyList[c].useGravity = true;
                        }
                    }
                    temp.isActive = true;
                }
                temp.go.transform.parent = temp.trans;
                temp.go.transform.localPosition = Vector3.zero;
                temp.parentObj.SetActive(false);
            }

            m_explodedNotUsed.AddRange(m_explodedUsing);
            m_explodedUsing.Clear();
        }
    }

    protected Transform GetBip(eExploderType type, Transform tr)
    {
        Transform trans = null;
        string bipName = "";
        switch (type)
        {
            case eExploderType.LeftArm: bipName = DEFINE.BONE_L_UpperArm; break;// "Bip01 L UpperArm"; break;
            case eExploderType.LeftCalf: bipName = DEFINE.BONE_L_Calf; break; //"Bip01 L Calf"; break;
            case eExploderType.LeftThigh: bipName = DEFINE.BONE_L_Thigh; break; //"Bip01 L Thigh"; break;
            case eExploderType.LeftForeArm: bipName = DEFINE.BONE_L_Forearm; break; //"Bip01 L Forearm"; break;
            case eExploderType.RightArm: bipName = DEFINE.BONE_R_UpperArm; break; //"Bip01 R UpperArm"; break;
            case eExploderType.RightCalf: bipName = DEFINE.BONE_R_Calf; break; //"Bip01 R Calf"; break;
            case eExploderType.RightThigh: bipName = DEFINE.BONE_R_Thigh; break; //"Bip01 R Thigh"; break;
            case eExploderType.RightForeArm: bipName = DEFINE.BONE_R_Forearm; break; //"Bip01 R Forearm"; break;
			case eExploderType.UpDown: bipName = DEFINE.BONE_Spine; break; //"BP_Spine"; break;
            case eExploderType.Head: bipName = DEFINE.BONE_Head; break; //"Bip01 Head"; break;
            default: bipName = DEFINE.BONE_Head; break;//"Bip01 Head"; break;
        }

        if (bipName != "")
        {
            trans = Common.GetBone(tr, bipName);
        }
        else
        {
            MyLog.LogError("Can not find eExploderType-Transform type : " + type);
        }
        return trans;
    }


    public virtual bool CreateOneExploderObject(GameObject exploded, eExploderType type,Color color)
    {
        return true;
    }

    public virtual bool CreateOneEcploderObjectForPath(GameObject exploded, eExploderType type)
    {
        return true;
    }

    public bool CloneExploderObject(eExploderType type)
    {
        sExploderObject clone = null;
        int count = m_explodedNotUsed.Count;
        for (int i = 0; i < count; i++)   //先检测没用到的物体有没有，如果没有检测到这执行下一个for循环开始检测以及用到的有没有
        {
            if (m_explodedNotUsed[i].type == type)
            {
                sExploderObject temp = m_explodedNotUsed[i];
                if (temp.parentObj == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedNotUsed.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject parentObj is null in m_explodedNotUsed");
                    return false;
                }
                if (temp.go == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedNotUsed.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject go is null in m_explodedNotUsed");
                    return false;
                }
                if (temp.trans == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedNotUsed.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject trans is null in m_explodedNotUsed");
                    return false;
                }
                if (temp.trans.childCount == 0)
                {
                    temp.go.transform.parent = temp.trans;
                }
                temp.parentObj.SetActive(true);
                clone = new sExploderObject(temp, m_removeFade);
                temp.parentObj.SetActive(false);
                clone.parentObj.transform.parent = m_groopTrans;
                clone.parentObj.SetActive(false);
                m_explodedNotUsed.Add(clone);
                return true;
            }
        }

        count = m_explodedUsing.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_explodedUsing[i].type == type)
            {
                sExploderObject temp = m_explodedUsing[i];
                if (temp.parentObj == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedUsing.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject parentObj is null in m_explodedUsing");
                    return false;
                }
                if (temp.go == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedUsing.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject go is null in m_explodedUsing");
                    return false;
                }
                if (temp.trans == null)
                {
                    Object.Destroy(temp.parentObj);
                    m_explodedUsing.Remove(temp);
                    MyLog.LogError("Clone Error sExploderObject trans is null in m_explodedUsing");
                    return false;
                }

                bool isInParent = true;
                if (temp.trans.childCount == 0)
                {
                    temp.go.transform.parent = temp.trans;
                    isInParent = false;
                }

                clone = new sExploderObject(temp, m_removeFade);
                clone.parentObj.transform.parent = m_groopTrans;
                clone.parentObj.SetActive(false);
                m_explodedNotUsed.Add(clone);

                if (!isInParent)
                    temp.go.transform.parent = m_ecplodedObjectsContainerTran;
                return true;
            }
        }
        return false;
    }

    public int GetTypeCount(eExploderType type)
    {
        int count = 0,len = 0;
        len = m_explodedNotUsed.Count;
        for (int i = 0; i < len; i++)
        {
            if (m_explodedNotUsed[i].type == type)
                count++;
        }

        len = m_explodedUsing.Count;
        for (int i = 0; i < len; i++)
        {
            if (m_explodedUsing[i].type == type)
                count++;
        }
        return count;
    }

    public void SrartUpdate()
    {
        m_canGetExploderObject = true;
    }






    public virtual GameObject GetExploderObjForPath(eExploderType type, Material mat, GameObject exploded, RegisterEvent callback = null, params object[] args)
    {
        return null;
    }
}
