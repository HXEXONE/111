﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CExploderManage : SingletonObject<CExploderManage>
{
    private eExploderMemoryType m_memoryType;
    private bool m_openExploder;
    private bool m_startUpdate;
    private Color m_color = new Color(0, 0, 0, 0);
    private float m_force = 25f;
    private bool m_exploderFinish = true;

    private Dictionary<uint, int> m_npcTypeList = new Dictionary<uint, int>();
    private Dictionary<uint, CBaseExploder> m_kindOfExploderList = new Dictionary<uint, CBaseExploder>();
    private List<uint> m_removeID = new List<uint>();

    private bool m_isMemory = false;

    private List<uint> m_persistenceIDList = new List<uint>();    //用来存储当前关卡和下一个关卡的怪物ID，除了列表里的ID，其他的都释放掉
    private List<string> m_persistencePathList = new List<string>();//用来存储当前关卡和下一个关卡的怪物路径，除了列表里的路径，其他的都释放掉

    public CExploderManage()
    {
        //IgnoreLayerCollision(true);
    }

    private void RegistExploderMemory(uint ID, CBaseExploder em)
    {
        if (!m_kindOfExploderList.ContainsKey(ID))
            m_kindOfExploderList.Add(ID, em);
    }

    public void RemoveRegistExploder(uint ID)
    {
        m_removeID.Add(ID);
    }

    public GameObject Exploder(uint ID, Transform trans,ref bool explod)
    {
        explod = false;
        if (!m_openExploder || !m_startUpdate || trans == null)
            return null;

        MonsterContent info = HolderManager.m_MonsterHolder.GetStaticInfo(ID);
        if (info == null)
            return null;
        eExploderType type = ChackExploder(info);

        if (type == eExploderType.None)
            return null;

        return GetExploder(ID, type, trans, info, ref explod);
    }

    private GameObject GetExploder(uint ID, eExploderType type, Transform trans, MonsterContent info,ref bool explod)
    {

        GameObject go = null;
        CBaseExploder em;

        if (type == eExploderType.Double)
        {
            m_memoryType = eExploderMemoryType.Exploder;
            m_kindOfExploderList.TryGetValue((uint)m_memoryType, out em);
        }
        else
        {
            if (!m_isMemory)
            {
                m_memoryType = eExploderMemoryType.Dismemer;
                m_kindOfExploderList.TryGetValue((uint)m_memoryType, out em);
            }
            else
            {
                m_memoryType = eExploderMemoryType.DismemerMemory;
                m_kindOfExploderList.TryGetValue(ID, out em);
            }
        }

        if (em == null)
            return null;

        switch (m_memoryType)
        {
            case eExploderMemoryType.Dismemer:
                {
                    DismemberDate DD = trans.GetComponent<DismemberDate>();
                    if (DD == null)
                        return null;
                    uint effectID = (uint)info.ModelLoader.ExploderEffectID;
                    UnityCallBackManager.GetInst().AddCallBack(0.1f, SetRagdollHelper, new object[] { trans, em, type, effectID });
                    explod = true;
                    return null;
                }
            case eExploderMemoryType.DismemerMemory:
                {
                    GameObject tempGo = em.GetExploderObj(type, trans.gameObject, ExploderCallback);
                    if (tempGo != null)
                        explod = true;
                    return tempGo;
                }
        }

        

        if (go != null)
        {
            if (m_memoryType != eExploderMemoryType.Dismemer)
            {
                go.transform.position = trans.position;
                go.transform.rotation = trans.rotation;
                go.SetActive(true);

                if (m_memoryType == eExploderMemoryType.Memory)
                {
                    Vector3 force = trans.position - SingletonObject<Avatar>.GetInst().GetPosition();
                    force.Normalize();
                    force = force * m_force;
                    Rigidbody[] rigs = go.GetComponentsInChildren<Rigidbody>();
                    for (int i = 0; i < rigs.Length; i++)
                    {
                        rigs[i].velocity = force;
                        rigs[i].drag = 0;
                    }
                }
            }
        }
        else
        {
            return null;
        }

        explod = true;

        return go;
    }

    public void Init(uint[] ID, int countNum,bool isMemory,params eExploderMemoryType[] types)
    {
        if (!m_openExploder)
            return;

        m_isMemory = isMemory;

        int count = types.Length;
        for (int i = 0; i < count; i++)
        {
            switch (types[i])
            {
                case eExploderMemoryType.Dismemer:
                    {
                        if (isMemory)
                            break;
                        if (!m_kindOfExploderList.ContainsKey((uint)types[i]))
                            RegistExploderMemory((uint)types[i], new CDismemDynamic(types[i].ToString(), 0, 4));
                    } break;
                case eExploderMemoryType.DismemerMemory:
                    {
                        if (!isMemory)
                            break;
                        for (int j = 0, c = ID.Length; j < c; j++)
                        {
                            uint id = ID[j];

                            MonsterContent monsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(id);
                            if (null == monsterLoader)
                                continue;

                            List<BaseIntContent> exploderTypes = monsterLoader.ModelLoader.ExploderType;
                            if (exploderTypes.Count <= 0)
                                continue;

                            RegistExploderMemory(id, new CDismenMemory(id.ToString(), countNum, 5, monsterLoader));
                        }
                    } break;
                default: break;
            }
        }

        //StartUpdate(open, isMemory);
        //StartUpdate();
    }

    public void Update()
    {
        if (!m_openExploder || !m_startUpdate)
        {
            return;
        }

        //不保留最后一波怪物的尸体
        //bool isGameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();
        
        //if (isGameOver)
        //    return;

        if (m_kindOfExploderList.Count > 0)
        {
            foreach (KeyValuePair<uint, CBaseExploder> val in m_kindOfExploderList)
            {
                val.Value.Update();
            }
        }
        int count = m_removeID.Count;
        if (count <= 0)
            return;

        for (int i = 0; i < count; i++)
        {
            uint ID = m_removeID[i];
            if (m_kindOfExploderList.ContainsKey(ID))
                m_kindOfExploderList.Remove(ID);
        }
        m_removeID.Clear();
    }

    private void SetRagdollHelper(params object[] args)
    {
        GameObject npcObj = (args[0] as Transform).gameObject;
        CBaseExploder em = args[1] as CBaseExploder;
        eExploderType type = (eExploderType)args[2];
        uint effectID = (uint)args[3];
        RagdollHelper ragdollHelper = npcObj.GetComponent<RagdollHelper>();

        if (null != ragdollHelper)
        {
            ragdollHelper.ragdolled = true;
        }

        UnityCallBackManager.GetInst().AddCallBack(0.02f, Dismemer, new object[] { npcObj, em, type, effectID });
    }

    private void Dismemer(params object[] args)
    {
        GameObject npcObj = args[0] as GameObject;
        CBaseExploder em = args[1] as CBaseExploder;
        eExploderType type = (eExploderType)args[2];
        uint effectID = (uint)args[3];

        SingletonObject<CParticleManager>.GetInst().CreateGroundEffect(effectID, npcObj.transform.position, npcObj.transform.forward);

        GameObject go = em.GetExploderObj(type, npcObj);
    }

    private void ExploderCallback(params object[] args)
    {
        m_exploderFinish = true;
    }
    
    //忽略碰撞
    //public void IgnoreLayerCollision(bool ignore)
    //{
    //    Physics.IgnoreLayerCollision(DEFINE.EXPLODER_LAYER, DEFINE.MONSTER_LAYER, ignore);
    //    Physics.IgnoreLayerCollision(DEFINE.EXPLODER_LAYER, DEFINE.AVATAR_LAYER, ignore);    
    //    Physics.IgnoreLayerCollision(DEFINE.EXPLODER_LAYER, DEFINE.AIR_WALL, ignore);
    //    Physics.IgnoreLayerCollision(DEFINE.EXPLODER_LAYER, DEFINE.AIFRIEND_LAYER, ignore);
    //}

    private eExploderType ChackExploder(MonsterContent info)
    {
        if (info.ModelLoader.ExploderType.Count == 0)
            return eExploderType.None;
        int exploderProbaility = info.ModelLoader.ExploderProbaility;
        exploderProbaility = Mathf.Min(exploderProbaility, 5000); //碎尸概率<50%
        
        int temp = Random.Range(1, 100) * 100;
        if (temp - exploderProbaility > 0)
            return eExploderType.None;

        List<BaseIntContent> exploderType = info.ModelLoader.ExploderType;

        temp = Random.Range(1, 100) * 100;
        foreach (BaseIntContent val in exploderType)
        {
            temp = temp - val.list[1];
            if (temp <= 0)
            {
                return (eExploderType)val.list[0];
            }
        }

        MyLog.LogError("CExploderManage ChackExploder ExploderProbaility Sum is not 10000");
        foreach (BaseIntContent val in exploderType)
        {
            if (val.list.Count == 2)
                MyLog.LogError("CExploderManage ChackExploder ExploderProbaility list[0] = " + val.list[0].ToString() + "\t\t list[1] = " + val.list[1].ToString());
            else
                MyLog.LogError("CExploderManage ChackExploder ExploderProbaility val is not equal 2");
        }
        return eExploderType.UpDown;

        temp = Random.Range(1, 100);
        int[] types = new int[] { 0, 0, 0, 0, 0, 50, 0, 0, 50, 0, 0 };
        for (int i = 1; i <= 11; i++)
        {
            temp = temp - types[i - 1];
            if (temp <= 0)
            {
                return (eExploderType)i;
            }
        }

        return eExploderType.None;
    }

    public bool CreateExploder(uint ID,GameObject obj,eExploderType exploderType,eExploderMemoryType memoryType,float fadeTime)
    {
        if (!m_openExploder || obj == null)
            return false;

        obj.transform.localScale = Vector3.one;

        DismemberDate ddata = obj.GetComponent<DismemberDate>();
        if (null == ddata)
        {
            Object.Destroy(obj);
            return false;
        }

        if (exploderType == eExploderType.Double)
        {
            Object.Destroy(obj);
            return false;
        }
        
        SkinnedMeshRenderer[] smrs = obj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (smrs == null || smrs.Length <= 0)
        {
            Object.Destroy(obj);
            return false;
        }

        CBaseExploder baseExploder;
        if (!m_kindOfExploderList.ContainsKey(ID))
        {
            baseExploder = new CDismenMemory(ID.ToString(), fadeTime);
            m_kindOfExploderList.Add(ID, baseExploder);
        }
        else
        {
            baseExploder = m_kindOfExploderList[ID];
            if (GetTypeCount(ID, exploderType) > 0)
            {
                Object.Destroy(obj);
                return true;
            }
        }

        if (baseExploder == null)
        {
            Object.Destroy(obj);
            return false;
        }

        FixingBP_Buff fb = obj.GetComponent<FixingBP_Buff>();
        if (fb != null)
            Object.DestroyImmediate(fb);

        CapsuleCollider CC = obj.GetComponent<CapsuleCollider>();
        if (CC != null)
            Object.DestroyImmediate(CC);

        Transform tran = Common.GetBone(obj.transform, DEFINE.BONE_Pelvis);
        if (tran)
        {
            BoxCollider boxCollider = tran.GetComponent<BoxCollider>();
            if (boxCollider)
                Object.DestroyImmediate(boxCollider);
        }

        Rigidbody rigidbody = obj.GetComponent<Rigidbody>();
        if(rigidbody != null)
            Object.DestroyImmediate(rigidbody);

        Transform shadow = obj.transform.FindChild("shadow");
        if (shadow != null)
        {
            shadow.parent = null;
            Object.DestroyImmediate(shadow.gameObject);
        }

        MonsterContent info = HolderManager.m_MonsterHolder.GetStaticInfo(ID);
        int shaderIndex = 0;
        Color color = Color.white;
        if (info != null)
        {
            //shaderIndex = info.GetShaderIndex();
            color = info.ShaderColor;
        }
        bool sus = baseExploder.CreateOneExploderObject(obj, exploderType, color);

        if (!sus)
            Object.Destroy(obj);

        return sus;
    }

    public bool CloneExploderObject(uint ID, eExploderType type,int count)
    {
        if (!m_openExploder)
            return false;
        if (GetTypeCount(ID, type) >= count)
            return true;  //尸块数量大于存在的数量就跳过，返回真

        CBaseExploder baseExploder = null;
        if(m_kindOfExploderList.ContainsKey(ID))
            baseExploder = m_kindOfExploderList[ID];

        if (baseExploder == null)
            return false;

        return baseExploder.CloneExploderObject(type);
    }

    public int GetTypeCount(uint ID, eExploderType type)
    {
        if (!m_openExploder)
            return -1;
        CBaseExploder baseExploder = null;
        if (m_kindOfExploderList.ContainsKey(ID))
            baseExploder = m_kindOfExploderList[ID];

        if (baseExploder == null)
            return -1;

        return baseExploder.GetTypeCount(type);
    }

    //public void StartUpdate(bool open,bool isMenmory)
    public void StartUpdate(bool isMenmory)
    {
        if (!m_openExploder)
            return;
        foreach (KeyValuePair<uint, CBaseExploder> val in m_kindOfExploderList)
        {
            val.Value.SrartUpdate();
        }
        m_isMemory = isMenmory;
        m_startUpdate = true;
    }

    public void Release(bool delete)
    {
        if (!m_openExploder)
            return;
        m_exploderFinish = true;
        m_startUpdate = false;

        foreach (KeyValuePair<uint, CBaseExploder> val in m_kindOfExploderList)
        {
            val.Value.Release(delete);
        }

        if (delete)
        {
            m_kindOfExploderList.Clear();
            m_npcTypeList.Clear();
            m_removeID.Clear();
        }
    }

    public void CloseExploder()
    {
        Release(true);
        ReleaseForPath(true);
        m_openExploder = false;
    }

    public void OpenExploder()
    {
        m_openExploder = true;
    }

    public void RemoveID(uint ID)
    {
        if (!m_openExploder)
            return;
        if (m_kindOfExploderList.ContainsKey(ID))
        {
            m_kindOfExploderList[ID].Release(true);
            m_kindOfExploderList.Remove(ID);
        }

        if (m_kindOfExploderList.Count <= 0)
        {
            m_kindOfExploderList.Clear();
            m_npcTypeList.Clear();
            m_removeID.Clear();

            m_exploderFinish = true;
            m_startUpdate = false;
        }
    }





    public bool IsOpenExploder()
    {
        return m_openExploder;
    }

    private Dictionary<string, CBaseExploder> m_kindOfExploderListForPath = new Dictionary<string, CBaseExploder>();

    public bool CreateExploderForPath(string path, GameObject obj, eExploderType exploderType, float fadeTime)
    {
        if (!m_openExploder || obj == null)
        {
            if (obj != null)
                Object.Destroy(obj);
            return false;
        }

        obj.transform.localScale = Vector3.one;

        DismemberDate ddata = obj.GetComponent<DismemberDate>();
        if (null == ddata)
        {
            Object.Destroy(obj);
            return false;
        }

        if (exploderType == eExploderType.Double)
        {
            Object.Destroy(obj);
            return false;
        }

        SkinnedMeshRenderer[] smrs = obj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (smrs == null || smrs.Length <= 0)
        {
            Object.Destroy(obj);
            return false;
        }

        RemoveComponent(obj);

        CBaseExploder baseExploder;
        if (!m_kindOfExploderListForPath.ContainsKey(path))
        {
            baseExploder = new CDismenMemory(path, fadeTime);
            m_kindOfExploderListForPath.Add(path, baseExploder);
        }
        else
        {
            baseExploder = m_kindOfExploderListForPath[path];
            if (GetTypeForPathCount(path, exploderType) > 0)
            {
                Object.Destroy(obj);
                return true;
            }
        }

        if (baseExploder == null)
        {
            Object.Destroy(obj);
            return false;
        }

        Rigidbody[] rigidbodys = obj.GetComponentsInChildren<Rigidbody>(true);

        int rigCount = rigidbodys.Length;
        for (int i = 0; i < rigCount; i++)
        {
            Rigidbody rg = rigidbodys[i];

            if (rg.name == DEFINE.BONE_L_Calf ||
                rg.name == DEFINE.BONE_R_Calf ||
                rg.name == DEFINE.BONE_L_Forearm ||
                rg.name == DEFINE.BONE_R_Forearm)
            {
                DestoryCompent(rg);
            }
            else
            {
                rg.isKinematic = false;
                rg.useGravity = true;
            }            
        }

        bool sus = baseExploder.CreateOneEcploderObjectForPath(obj, exploderType);

        if (!sus)
            Object.Destroy(obj);

        return sus;
    }

    private void DestoryCompent(Rigidbody rg)
    {
        Collider cd = rg.gameObject.GetComponent<Collider>();
        if (null != cd)
        {
            GameObject.DestroyImmediate(cd);
        }

        CharacterJoint cj = rg.gameObject.GetComponent<CharacterJoint>();
        if (null != cj)
        {
            GameObject.DestroyImmediate(cj);
        }

        GameObject.DestroyImmediate(rg);
    }

    public bool CloneExploderObjectForPath(string path, eExploderType type, int count)
    {
        if (!m_openExploder)
            return false;
        if (GetTypeForPathCount(path, type) >= count)
            return true;  //尸块数量大于存在的数量就跳过，返回真

        CBaseExploder baseExploder = null;
        if (m_kindOfExploderListForPath.ContainsKey(path))
            baseExploder = m_kindOfExploderListForPath[path];

        if (baseExploder == null)
            return false;

        return baseExploder.CloneExploderObject(type);
    }

    public bool CreateDynamicForPath(string path, GameObject obj, eExploderType exploderType, float fadeTime, ref CBaseExploder baseExploder)
    {
        baseExploder = null;

        GameObject varNewObject = GameObject.Instantiate(obj) as GameObject;
        varNewObject.name = path;
        bool result = CreateExploderForPath(path, varNewObject, exploderType, fadeTime);

        if (result && m_kindOfExploderListForPath.ContainsKey(path))
        {
            baseExploder = m_kindOfExploderListForPath[path];
            baseExploder.SrartUpdate();
        }
        else
        {
            Object.Destroy(varNewObject);
        }
        return result;
    }

    public int GetTypeForPathCount(string path, eExploderType type)
    {
        if (!m_openExploder)
            return -1;
        CBaseExploder baseExploder = null;
        if (m_kindOfExploderListForPath.ContainsKey(path))
            baseExploder = m_kindOfExploderListForPath[path];

        if (baseExploder == null)
            return -1;

        return baseExploder.GetTypeCount(type);
    }

    private void RemoveComponent(GameObject obj)
    {
        Component[] components = obj.GetComponents<Component>();
        Component temp;
        int count = components.Length;
        for (int i = 0; i < count; i++)
        {
            temp = components[i];
            if ((temp is Transform) || (temp is DismemberDate))
                continue;

            Object.DestroyImmediate(temp);
        }

        Transform shadow = obj.transform.FindChild("shadow");
        if (shadow != null)
        {
            shadow.parent = null;
            Object.DestroyImmediate(shadow.gameObject);
        }

        Transform audiosource = obj.transform.FindChild("AudioSource");
        if (audiosource != null)
        {
            audiosource.parent = null;
            Object.DestroyImmediate(audiosource.gameObject);
        }

        Transform followobject = obj.transform.FindChild("FollowObject");
        if (followobject != null)
        {
            followobject.parent = null;
            Object.DestroyImmediate(followobject.gameObject);
        }

        Transform triggerrange = obj.transform.FindChild("TriggerRange");
        if (triggerrange != null)
        {
            triggerrange.parent = null;
            Object.DestroyImmediate(triggerrange.gameObject);
        }

        Transform triggerobject = obj.transform.FindChild("TriggerObject");
        if (triggerobject != null)
        {
            triggerobject.parent = null;
            Object.DestroyImmediate(triggerobject.gameObject);
        }

        Transform tran = Common.GetBone(obj.transform, DEFINE.BONE_Pelvis);
        if (tran)
        {
            BoxCollider boxCollider = tran.GetComponent<BoxCollider>();
            if (boxCollider)
                Object.DestroyImmediate(boxCollider);
        }

        DynamicShader.ReplaceUnSupportShader(obj);
    }

    public GameObject ExploderForPath(string path,uint ID,Material mat, Transform trans, ref bool explod)
    {
        explod = false;
        if (!m_openExploder || !m_startUpdate || trans == null || mat == null)
            return null;

        MonsterContent info = HolderManager.m_MonsterHolder.GetStaticInfo(ID);
        if (info == null)
            return null;

        eExploderType type = ChackExploder(info);

        if (type == eExploderType.None)
            return null;

        return GetExploderForPath(path, type, mat, trans, info, ref explod);
    }

    private GameObject GetExploderForPath(string path, eExploderType type,Material mat, Transform trans, MonsterContent info, ref bool explod)
    {
        GameObject go = null;
        CBaseExploder em;

        if (type == eExploderType.Double)
        {
            m_memoryType = eExploderMemoryType.Exploder;
            m_kindOfExploderListForPath.TryGetValue(m_memoryType.ToString(), out em);
        }
        else
        {
            if (!m_isMemory)
            {
                m_memoryType = eExploderMemoryType.Dismemer;
                m_kindOfExploderListForPath.TryGetValue(m_memoryType.ToString(), out em);
            }
            else
            {
                m_memoryType = eExploderMemoryType.DismemerMemory;
                m_kindOfExploderListForPath.TryGetValue(path, out em);
            }
        }

        if (em == null)
        {
            return null;
        }


        switch (m_memoryType)
        {
            case eExploderMemoryType.Dismemer:
                {
                    DismemberDate DD = trans.GetComponent<DismemberDate>();
                    if (DD == null)
                        return null;
                    uint effectID = (uint)info.ModelLoader.ExploderEffectID;
                    UnityCallBackManager.GetInst().AddCallBack(0.1f, SetRagdollHelper, new object[] { trans, em, type, effectID });
                    explod = true;
                    return null;
                }
            case eExploderMemoryType.DismemerMemory:
                {
                    GameObject tempGo = em.GetExploderObjForPath(type, mat,trans.gameObject, ExploderCallback);
                    if (tempGo != null)
                    {
                        uint effectID = (uint)info.ModelLoader.ExploderEffectID;
                        SingletonObject<CParticleManager>.GetInst().CreateGroundEffect(effectID, trans.position, trans.forward);
                        explod = true;
                    }
                    return tempGo;
                }
        }



        if (go != null)
        {
            if (m_memoryType != eExploderMemoryType.Dismemer)
            {
                go.transform.position = trans.position;
                go.transform.rotation = trans.rotation;
                go.SetActive(true);

                if (m_memoryType == eExploderMemoryType.Memory)
                {
                    Vector3 force = trans.position - SingletonObject<Avatar>.GetInst().GetPosition();
                    force.Normalize();
                    force = force * m_force;
                    Rigidbody[] rigs = go.GetComponentsInChildren<Rigidbody>();
                    for (int i = 0; i < rigs.Length; i++)
                    {
                        rigs[i].velocity = force;
                        rigs[i].drag = 0;
                    }
                }
            }
        }
        else
        {
            return null;
        }

        explod = true;

        return go;
    }

    public void UpdateForPath()
    {
        if (!m_openExploder || !m_startUpdate)
        {
            return;
        }

        //不保留最后一波怪物的尸体
        //bool isGameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();

        //if (isGameOver)
        //    return;

        if (m_kindOfExploderListForPath.Count > 0)
        {
            foreach (KeyValuePair<string, CBaseExploder> val in m_kindOfExploderListForPath)
            {
                val.Value.Update();
            }
        }
    }

    public void StartUpdateForPath(bool isMenmory)
    {
        if (!m_openExploder)
            return;
        foreach (KeyValuePair<string, CBaseExploder> val in m_kindOfExploderListForPath)
        {
            val.Value.SrartUpdate();
        }
        m_isMemory = isMenmory;
        m_startUpdate = true;
    }

    public void ReleaseForPath(bool delete)
    {
        if (!m_openExploder)
            return;
        m_exploderFinish = true;
        m_startUpdate = false;

        foreach (KeyValuePair<string, CBaseExploder> val in m_kindOfExploderListForPath)
        {
            val.Value.Release(delete);
        }

        if (delete)
        {
            m_kindOfExploderListForPath.Clear();
            m_npcTypeList.Clear();
            m_removeID.Clear();
        }
    }

    public void RemovePath(string path)
    {
        if (!m_openExploder)
            return;
        if (m_kindOfExploderListForPath.ContainsKey(path))
        {
            m_kindOfExploderListForPath[path].Release(true);
            m_kindOfExploderListForPath.Remove(path);
        }

        if (m_kindOfExploderListForPath.Count <= 0)
        {
            m_kindOfExploderListForPath.Clear();
            m_npcTypeList.Clear();
            m_removeID.Clear();

            m_exploderFinish = true;
            m_startUpdate = false;
        }
    }

    public void ExceptRelease(uint curMapID,bool usePath)
    {
        if (!m_openExploder)
            return;
        m_persistenceIDList.Clear();
        m_persistencePathList.Clear();

        SceneContent mapInfo = HolderManager.m_SceneHolder.GetStaticInfo(curMapID);
        if (mapInfo != null)
        {
            ExceptReleaseAddList(mapInfo);
        }
        

        //uint nextMapID = BattlePVEContent.GetNextMapID(mapInfo.GetKey());

        //SceneContent nextScene = HolderManager.m_SceneHolder.GetStaticInfo(nextMapID);
        //if (nextScene == null)
        //    return;

        //ExceptReleaseAddList(nextScene);


        int count;
        if (usePath)
        {
            List<string> deleteList = new List<string>();
            foreach (KeyValuePair<string, CBaseExploder> val in m_kindOfExploderListForPath)
            {
                if (!m_persistencePathList.Contains(val.Key))
                    deleteList.Add(val.Key);
            }

            count = deleteList.Count;
            for (int i = 0; i < count; i++)
            {
                RemovePath(deleteList[i]);
            }
        }
        else
        {
            List<uint> deleteList = new List<uint>();
            foreach (KeyValuePair<uint, CBaseExploder> val in m_kindOfExploderList)
            {
                if (!m_persistenceIDList.Contains(val.Key))
                    deleteList.Add(val.Key);
            }

            count = deleteList.Count;
            for (int i = 0; i < count; i++)
            {
                RemoveID(deleteList[i]);
            }
        }
    }

    private void ExceptReleaseAddList(SceneContent mapInfo)
    {
        List<BaseIntContent> temp = mapInfo.MaxMonsterList;
        
        int count = temp.Count;
        uint ID;
        for (int i = 0; i < count; i++)
        {
            if (temp[i].list.Count < 2)
                continue;

            ID = (uint)temp[i].list[0];
            
            if (m_persistenceIDList.Contains(ID))
                continue;
            m_persistenceIDList.Add(ID);
        }

        count = m_persistenceIDList.Count;

        MonsterContent monsterInfo;

        string path;

        for (int i = 0; i < count; i++)
        {
            monsterInfo = HolderManager.m_MonsterHolder.GetStaticInfo(m_persistenceIDList[i]);
            if (monsterInfo == null)
                continue;

            path = monsterInfo.ModelLoader.Path;
            
            if (m_persistencePathList.Contains(path))
                continue;
            m_persistencePathList.Add(path);
        }
    }
}
