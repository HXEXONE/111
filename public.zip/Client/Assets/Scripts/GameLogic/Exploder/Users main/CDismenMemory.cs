﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CDismenMemory : CBaseExploder {

    private enum eForUpdateState
    {
        None,
        FillBoneName,
        Update,
    }

    private GameObject m_tempReturnObj;
    private sExploderObject m_tempExploderObj;

    private Transform[] m_origObjsTrans;
    private Transform[] m_dismemedTrans;

    private float lastTime;

    private uint m_ID;

    private float m_downForce = 0f;
    private float m_wh_ratio = 0.2f;  //宽高比
    private float m_addForceTime = 0.2f;
    private float m_upSpeed = 10f;

    private List<GameObject> m_memoryObject = new List<GameObject>();
    private List<int> m_typesList = new List<int>();

    private Dictionary<eExploderType, int[]> m_boneIndex = new Dictionary<eExploderType, int[]>();
    private List<eExploderType> m_fillBoneIndexListType = new  List<eExploderType>();
    private List<string[]> m_fillBoneIndexListBonesName = new List<string[]>();
    private eForUpdateState m_forUpdateState = eForUpdateState.None;

    private int m_countOfAll;


    private bool m_next = true;
    private GameObject m_tempObj;
    private int m_tempType;
    private int m_indexType = 0;

    private MonsterContent m_info;
    private string m_path;

    private bool m_relsase = false;


    public CDismenMemory(string ID, int cutNum, float fadeTime,MonsterContent info)
        : base(ID, cutNum, fadeTime)
    {
        m_info = info;
      
        m_ID = MyConvert_Convert.ToUInt32(ID);

        m_path = info.ModelLoader.Path;
        List<BaseIntContent> tmpList = info.ModelLoader.ExploderType;
        for (int i = 0; i < tmpList.Count; ++i)
        {
            if (tmpList[i].list.Count > 0)
                m_typesList.Add(tmpList[i].list[0]);
        }
        m_countOfAll = cutNum * m_typesList.Count;

        if (m_countOfAll <= 0)
        {
            m_state = eExploderState.None;
            Release(true);
        }
       
        m_downSpeed = m_downDirect * m_m_downDragForce;
        m_removeFade = false;
    }

    public CDismenMemory(string ID, float fadeTime)
        : base(ID, 0, fadeTime)
    {
        m_state = eExploderState.Update;
        m_downSpeed = m_downDirect * m_m_downDragForce;
        m_removeFade = false;
    }

    protected override void CreateExploder()
    {
        if (m_relsase)
        {
            Release(true);
            CExploderManage.GetInst().RemoveRegistExploder(m_ID);
            return;
        }
        CreateObject();
    }  

    protected override void DismenGameObjectInList()
    {
        int tempCount = m_memoryObject.Count;
        if (tempCount <= 0 || m_typesList.Count <= 0)
        {
            m_state = eExploderState.Update;
            m_canGetExploderObject = true;

            for (int i = 0; i < tempCount; i++)
            {
                Object.Destroy(m_memoryObject[i]);
            }
            m_memoryObject.Clear();
            m_typesList.Clear();
            m_realCount = m_explodedNotUsed.Count;
            return;
        }


        if (m_realCount < m_count)
        {
            m_tempObj = m_memoryObject[0];
            if (m_indexType >= m_typesList.Count)
            {
                m_memoryObject.Clear();
                return;
            }
            CreateOne(m_tempObj, m_typesList[m_indexType], Color.white);
            m_memoryObject.Remove(m_tempObj);
        }
        else
        {
            m_realCount = 0;
            m_indexType += 1;
        }

    }

    private void CreateObject()
    {
        LoadHelp.LoadObject("", m_path, ThreadPriority.Normal, LoadCompleteDiseme);
    }

    public override bool CreateOneExploderObject(GameObject exploded, eExploderType type, Color color)
    {
        return CreateOne(exploded, (int)type, color);
    }

    private bool CreateOne(GameObject memoryObj, int type,Color color)
    {
        memoryObj.SetActive(true);

        DismemberDate ddata = memoryObj.GetComponent<DismemberDate>();

        if (m_removeFade)
            ddata.m_material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTILT_SCREEN_BLEND_ALPHA_3000);

        SkinnedMeshRenderer[] smrs = memoryObj.GetComponentsInChildren<SkinnedMeshRenderer>();

        if (color.Equals(Color.white))
        {
            smrs[0].material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_TIME_HART_DIFFUSE);
            //Color color = DynamicShader.GetMonsterSpecialMaterialColor(shaderIndex);
            smrs[0].material.SetColor(DEFINE.SHADER_PROPERTY_COLOR, color);
            smrs[0].material.SetFloat(DEFINE.SHADER_PROPERTY_EXPAND, 0.0125f);
        }
        else
        {
            if (m_removeFade)
                smrs[0].material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
            else
                smrs[0].material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        }

        if (m_removeFade)
            smrs[0].material.SetFloat("_AlphaCon", 1);

        Collider[] colliders = memoryObj.GetComponentsInChildren<Collider>();
        int countRig = colliders.Length;
        for (int i = 0; i < countRig; i++)
        {
            colliders[i].gameObject.layer = DEFINE.EXPLODER_LAYER;
        }

        sExploderObject obj = new sExploderObject();
        obj.bUseing = false;
        obj.lastUseTime = -1;
        obj.alpha = 1;

        obj.type = (eExploderType)type;

        if (!m_fillBoneIndexListType.Contains((eExploderType)type))
        {
            string[] bonesName = FillingBoneIndexName((eExploderType)type, memoryObj);
            m_fillBoneIndexListType.Add((eExploderType)type);
            m_fillBoneIndexListBonesName.Add(bonesName);
        }

        Transform tran = GetBip(obj.type, memoryObj.transform);

        if (tran == null)
        {
            MyLog.LogError("Create dismen object can not find transform type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.go = DismenCutter.Dismember(tran, ddata.m_material, ddata);

        if (obj.go == null)
        {
            MyLog.LogError("Create dismen object Dismember fail , type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.trans = Common.GetBone(memoryObj.transform, obj.go.name + "_stump");
        if (obj.trans == null)
        {
            Object.Destroy(obj.go);
            MyLog.LogError("Create dismen object can not find \"" + obj.go.name + "_stump\" transform type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.parentObj = memoryObj;
        obj.parentTran = memoryObj.transform;
        obj.go.transform.parent = obj.trans;
        obj.parentObj.transform.parent = m_groopTrans;

        
        SkinnedMeshRenderer[] newSmrs = obj.parentObj.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (newSmrs == null)
        {
            MyLog.LogError("Create dismen object can not find SkinnedMeshRenderer : is null" + "\t name : " + memoryObj.name);
            return false;
        }

        int count = newSmrs.Length;
        if (count <= 0)
        {
            MyLog.LogError("Create dismen object can not find SkinnedMeshRenderer : count <= 0" + "\t name : " + memoryObj.name);
            return false;
        }
        if (m_removeFade)
        {
            obj.mats = new List<Material>();
            for (int i = 0; i < count; i++)
            {
                if (newSmrs.Length > 0)
                {
                    obj.mats.AddRange(newSmrs[i].materials);
                }
            }
            count = obj.mats.Count;
            if (count <= 0)
            {
                MyLog.LogError("Create dismen object can not find material : count <= 0" + "\t name : " + memoryObj.name);
                return false;
            }
        }

        Rigidbody[] newRig = obj.go.GetComponentsInChildren<Rigidbody>();
        if (newRig == null && newRig.Length <= 0)
        {
            MyLog.LogError("Create dismen object can not find Rigidbody : is null" + "\t name : " + memoryObj.name);
            return false;
        }
        obj.rigidbody = newRig[0];

        switch (obj.type)
        {
            case eExploderType.LeftArm: obj.force = memoryObj.transform.TransformDirection(-Vector3.right) * m_wh_ratio + Vector3.up; break;
            case eExploderType.LeftThigh: obj.force = memoryObj.transform.TransformDirection(-Vector3.forward); break;
            case eExploderType.RightArm: obj.force = memoryObj.transform.TransformDirection(Vector3.right) * m_wh_ratio + Vector3.up; break;
            case eExploderType.RightThigh: obj.force = memoryObj.transform.TransformDirection(-Vector3.forward); break;
            case eExploderType.UpDown: obj.force = Vector3.up + memoryObj.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
            case eExploderType.Head: obj.force = Vector3.up + memoryObj.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
        }
        obj.force.Normalize();
        obj.downForce = -Vector3.up * m_downForce * 9.8f * obj.rigidbody.mass;
        //if (obj.type == eExploderType.UpDown)
        //    obj.downForce *= 5;

        obj.parentObj.SetActive(false);
        m_explodedNotUsed.Add(obj);

        m_realCount += 1;

        m_forUpdateState = eForUpdateState.FillBoneName;
        return true;
    }

    public override GameObject GetExploderObj(eExploderType type, GameObject exploded, RegisterEvent callback = null, params object[] args)
    {
        if (!m_canGetExploderObject)
            return null;

        m_tempReturnObj = null;
        if (m_realCount > 0)
        {
            m_tempExploderObj = GetExploder(type);
            bool remove = false;
            if ( null == m_tempExploderObj)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error m_tempExploderObj  is null in m_explodedNotUsed");                
            }
           
            if (!remove && m_tempExploderObj.parentObj == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject parentObj is null in m_explodedNotUsed");
            }
            if (!remove && m_tempExploderObj.go == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject go is null in m_explodedNotUsed");
            }
            if (!remove && m_tempExploderObj.trans == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject trans is null in m_explodedNotUsed");
            }

            if (remove)
            {
                m_explodedUsing.Remove(m_tempExploderObj);
                CloneExploderObject(type);
                return null;
            }
            
            m_tempReturnObj = m_tempExploderObj.go;
            m_tempExploderObj.alpha = 1;

            m_tempExploderObj.parentObj.SetActive(true);

            bool resule = ResetTransform(type, exploded.transform);

            if (!resule)
                ResetTransform(exploded.transform);

            exploded.SetActive(false);

            Vector3 force = Vector3.zero;
            if (m_tempExploderObj.rigidbody)
            {
                force = m_upSpeed * m_tempExploderObj.force * m_tempExploderObj.rigidbody.mass;
                if (type == eExploderType.UpDown)
                    force *= 1.5f;
                m_tempExploderObj.rigidbody.velocity = force;
            }
        }
        if (callback != null)
            callback(args);
        return m_tempReturnObj;
    }

    protected override sExploderObject GetExploder(eExploderType type)
    {
        sExploderObject eobj = null;

        int count = m_explodedNotUsed.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_explodedNotUsed[i].type == type)
            {
                eobj = m_explodedNotUsed[i];
                eobj.bUseing = true;
                eobj.lastUseTime = Time.time;
                eobj.isActive = true;
                m_explodedNotUsed.Remove(eobj);
                m_explodedUsing.Add(eobj);
                return eobj;
            }
        }

        bool createSus = CloneExploderObject(type);

        if (createSus)
        {
            count = m_explodedNotUsed.Count;
            eobj = m_explodedNotUsed[count - 1];
            eobj.bUseing = true;
            eobj.lastUseTime = Time.time;
            eobj.isActive = true;
            if (m_removeFade)
            {
                int len = eobj.mats.Count;
                for (int i = 0; i < len; i++)
                {
                    eobj.mats[i].SetFloat("_AlphaCon", 1);
                }
            }

            m_explodedNotUsed.Remove(eobj);
            m_explodedUsing.Add(eobj);
            return eobj;
        }

        count = m_explodedUsing.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_explodedUsing[i].type == type)
            {
                Retrieve(i);
                eobj = m_explodedUsing[i];

                eobj.bUseing = true;
                eobj.lastUseTime = Time.time;
                eobj.isActive = true;
                break;
            }
        }
        return eobj;
    }

    protected override void ForUpdate()
    {
        if (!m_canGetExploderObject)
            return;

        switch (m_forUpdateState)
        {
            case eForUpdateState.FillBoneName :
                if (!ForFillBoneIndex())
                    m_forUpdateState = eForUpdateState.Update;
                break;
            case eForUpdateState.Update :
                ForUpdateFuntion();
                break;
        }
    }

    private bool ForFillBoneIndex()
    {
        bool result = m_fillBoneIndexListType.Count > 0;
        if (result)
        {
            eExploderType type = m_fillBoneIndexListType[0];
            string[] bonesName = m_fillBoneIndexListBonesName[0];
            int len = m_explodedNotUsed.Count;
            for (int i = 0; i < len; i++)
            {
                if (m_explodedNotUsed[i].type == type)
                {
                    FillingBoneIndex(type, m_explodedNotUsed[i].parentObj, bonesName);
                    break;
                }
            }
            if (!m_removeFade)
            {
                for (int i = 0; i < len; i++)
                {

                    Collider[] collider = m_explodedNotUsed[i].parentObj.GetComponentsInChildren<Collider>(true);
                    if (collider == null)
                        return false;
                    m_explodedNotUsed[i].collider = new List<Collider>(collider);

                    Rigidbody[] rigidbodys = m_explodedNotUsed[i].parentObj.GetComponentsInChildren<Rigidbody>(true);
                    if (rigidbodys == null)
                        return false;
                    m_explodedNotUsed[i].rigidbodyList = new List<Rigidbody>(rigidbodys);
                    int count = rigidbodys.Length;
                    for (int co = 0; co < count; co++)
                    {
                        rigidbodys[co].isKinematic = false;
                    }
                }
            }

            m_fillBoneIndexListType.RemoveAt(0); ;
            m_fillBoneIndexListBonesName.RemoveAt(0); ;
        }

        return result;
    }

    private void ForUpdateFuntion()
    {
        if (m_realCount > 0)
        {
            float curTime = Time.time;

            int count = m_explodedUsing.Count;
            for (int i = 0; i < count; i++)
            {
                m_tempExploderObj = m_explodedUsing[i];

                lastTime = m_tempExploderObj.lastUseTime;
                if (curTime > lastTime + m_fadeTime)
                {
                    if (m_removeFade)
                    {
                        m_tempExploderObj.alpha -= m_fadeSpeed * Time.deltaTime;
                        if (m_tempExploderObj.alpha <= 0)
                        {
                            m_temp.Add(m_tempExploderObj);
                            Retrieve(i);
                        }
                        else
                        {
                            int countMat = m_tempExploderObj.mats.Count;
                            for (int j = 0; j < countMat; j++)
                            {
                                m_tempExploderObj.mats[j].SetFloat("_AlphaCon", m_tempExploderObj.alpha);
                            }
                        }
                    }
                    else
                    {
                        if (m_tempExploderObj.isActive)
                        {
                            int len = m_tempExploderObj.collider.Count;
                            for (int c = 0; c < len; c++)
                            {
                                if (m_tempExploderObj.collider[c] == null)
                                {
                                    m_tempExploderObj.collider.RemoveAt(c);
                                    c--;
                                    len--;
                                    continue;
                                }
                                m_tempExploderObj.collider[c].enabled = false;
                            }

                            len = m_tempExploderObj.rigidbodyList.Count;
                            for (int c = 0; c < len; c++)
                            {
                                if (m_tempExploderObj.rigidbodyList[c] == null)
                                {
                                    m_tempExploderObj.rigidbodyList.RemoveAt(c);
                                    c--;
                                    len--;
                                    continue;
                                }
                                m_tempExploderObj.rigidbodyList[c].useGravity = false;
                            }
                            m_tempExploderObj.isActive = false;
                            m_tempExploderObj.go.transform.parent = m_tempExploderObj.trans;
                        }
                        else
                            m_tempExploderObj.parentTran.Translate(m_downSpeed * Time.deltaTime);

                        if (curTime > lastTime + m_fadeTime + m_removeNotFadeTime)
                        {
                            m_temp.Add(m_tempExploderObj);
                            Retrieve(i);
                        }
                    }
                }

                //改为unity 的系统重力加速调整为25
                //if (m_tempExploderObj.isActive && curTime > lastTime + m_addForceTime)
                //{
                //    if (m_tempExploderObj.rigidbody)
                //        m_tempExploderObj.rigidbody.AddForce(m_tempExploderObj.downForce);
                //}

                m_explodedUsing[i] = m_tempExploderObj;
            }

            count = m_temp.Count;
            for (int i = 0; i < count; i++)
            {
                m_explodedUsing.Remove(m_temp[i]);
            }
            m_explodedNotUsed.AddRange(m_temp);
            m_temp.Clear();
        }
    }

    private bool ResetTransform(Transform tran)
    {
        if (m_tempReturnObj != null)
        {
            m_origObjsTrans = tran.GetComponentsInChildren<Transform>();
            m_dismemedTrans = m_tempExploderObj.parentObj.GetComponentsInChildren<Transform>();

            int countI = m_dismemedTrans.Length;
            int countJ = m_origObjsTrans.Length;
            string nameI, nameJ;
            Transform dismemedTrans;
            Transform origObjsTrans;
            for (int i = 0; i < countI; i++)
            {
                dismemedTrans = m_dismemedTrans[i];
                nameI = dismemedTrans.name;
                
                for (int j = 0; j < countJ; j++)
                {
                    origObjsTrans = m_origObjsTrans[j];
                    nameJ = origObjsTrans.name;
                    if (nameJ.Equals(nameI))
                    {
                        dismemedTrans.localPosition = origObjsTrans.localPosition;
                        dismemedTrans.localRotation = origObjsTrans.localRotation;
                        break;
                    }
                }
            }

            m_tempExploderObj.trans.localPosition = Vector3.zero;
            m_tempExploderObj.trans.localRotation = Quaternion.identity;

            m_tempExploderObj.parentObj.transform.position = tran.position;
            m_tempExploderObj.parentObj.transform.rotation = tran.rotation;
            m_tempExploderObj.parentObj.transform.localScale = tran.localScale;

            m_tempExploderObj.go.transform.parent = m_ecplodedObjectsContainerTran;

            return true;
        }

        return false;
    }  

    private bool ResetTransform(eExploderType type,Transform orig)
    {
        if(!m_boneIndex.ContainsKey(type))
            return false;
        int[] bonesIndex = m_boneIndex[type];

        if (bonesIndex == null)
            return false;

        SkinnedMeshRenderer[] smr = orig.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (smr == null || smr.Length <= 0)
            return false;
        if (m_tempExploderObj.trans.childCount == 0)
        {
            MyLog.Log("ResetTransform m_tempExploderObj.trans.childCount == 0");
            m_tempExploderObj.go.transform.parent = m_tempExploderObj.trans;
        }

        m_dismemedTrans = m_tempExploderObj.parentObj.GetComponentsInChildren<Transform>();
        m_origObjsTrans = smr[0].bones;

        Transform dismemedTrans;
        Transform origObjsTrans;

        int lenDis = m_dismemedTrans.Length;

        int lenBone = m_origObjsTrans.Length;
        int index = -1;
        for (int i = 0; i < lenBone; i++)
        {
            index = bonesIndex[i];
            if (index >= lenDis)
            {
                MyLog.LogError("ResetTransform fial \"parentObj\" GameObject childs <TransForm> count < bonesIndex.Length");
                return false;
            }

            dismemedTrans = m_dismemedTrans[index];
            origObjsTrans = m_origObjsTrans[i];

            dismemedTrans.localPosition = origObjsTrans.localPosition;
            dismemedTrans.localRotation = origObjsTrans.localRotation;
        }

        m_tempExploderObj.trans.localPosition = Vector3.zero;
        m_tempExploderObj.trans.localRotation = Quaternion.identity;

        m_tempExploderObj.parentObj.transform.position = orig.position;
        m_tempExploderObj.parentObj.transform.rotation = orig.rotation;
        m_tempExploderObj.parentObj.transform.localScale = orig.localScale;

        //m_tempExploderObj.go.transform.localPosition = Vector3.zero;
        //m_tempExploderObj.go.transform.localRotation = Quaternion.identity;
        m_tempExploderObj.go.transform.parent = m_ecplodedObjectsContainerTran;

        return true;
    }

    private void FillingBoneIndex(eExploderType type,GameObject exploded,string[] bonesName)
    {
        if (bonesName == null)
            return;

        if (m_boneIndex.ContainsKey(type))
            return;

        int boneLen = bonesName.Length;
        int[] indexs = new int[boneLen];
        m_dismemedTrans = exploded.GetComponentsInChildren<Transform>(true);

        int countDisTrasn = m_dismemedTrans.Length;

        string nameDis, nameBone;
        Transform dismemedTrans;
        for (int i = 0; i < boneLen; i++)
        {
            nameBone = bonesName[i];

            for (int j = 0; j < countDisTrasn; j++)
            {
                dismemedTrans = m_dismemedTrans[j];
                nameDis = dismemedTrans.name;
                if (nameDis.Equals(nameBone))
                {
                    indexs[i] = j;
                    break;
                }
            }
        }
        m_boneIndex.Add(type, indexs);
    }

    private string[] FillingBoneIndexName(eExploderType type, GameObject obj)
    {
        if (m_boneIndex.ContainsKey(type))
            return null;

        SkinnedMeshRenderer[] smr = obj.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (smr == null || smr.Length <= 0)
            return null;
        m_origObjsTrans = smr[0].bones;
        int boneLen = m_origObjsTrans.Length;
        string[] bonesName = new string[boneLen];
        for (int i = 0; i < boneLen; i++)
        {
            bonesName[i] = m_origObjsTrans[i].name;
        }

        return bonesName;
    }

    private void Retrieve(int index)
    {
        sExploderObject eb = m_explodedUsing[index];
        eb.alpha = 1;

        eb.bUseing = false;
        eb.lastUseTime = -1;

        if (m_removeFade)
        {
            int count = eb.mats.Count;
            for (int i = 0; i < count; i++)
            {
                eb.mats[i].SetFloat("_AlphaCon", 1);
            }
            eb.go.transform.parent = eb.trans;
        }
        else
        {
            int len = m_explodedUsing[index].collider.Count;
            for (int c = 0; c < len; c++)
            {
                if (m_explodedUsing[index].collider[c] != null)
                    m_explodedUsing[index].collider[c].enabled = true;
            }
            len = m_explodedUsing[index].rigidbodyList.Count;
            for (int c = 0; c < len; c++)
            {
                if (m_explodedUsing[index].rigidbodyList[c] != null)
                    m_explodedUsing[index].rigidbodyList[c].useGravity = true;
            }
            m_explodedUsing[index].isActive = true;
        }
        eb.go.transform.localPosition = Vector3.zero;
        m_explodedUsing[index] = eb;
        eb.parentObj.SetActive(false);
    }

    private void LoadCompleteDiseme(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { m_relsase = true; return; }
        GameObject go = Object.Instantiate(asset) as GameObject;
        if (null == go)
        {
            m_relsase = true;
            return;
        }

        DismemberDate dd = go.GetComponent<DismemberDate>();
        if (dd == null)
        {
            m_relsase = true;
            Object.Destroy(go);
            return;
        }

        Transform shadow = Common.GetBone(go.transform, "shadow");
        Object.Destroy(shadow.gameObject);
        FixingBP_Buff fb = go.GetComponent<FixingBP_Buff>();
        Object.Destroy(fb);
        CapsuleCollider cc = go.GetComponent<CapsuleCollider>();
        Object.Destroy(cc);

        go.SetActive(false);

        m_memoryObject.Add(go);

        m_realCount++;
        if (m_realCount >= m_countOfAll)
        {
            m_state = eExploderState.Dismem;
            m_realCount = 0;
        }
    }

    public override void Release(bool delete)
    {
        base.Release(delete);
        if (delete)
        {
            m_tempReturnObj = null;
            m_tempExploderObj = null;
            m_origObjsTrans = null;
            m_dismemedTrans = null;
            m_memoryObject.Clear();
            m_typesList.Clear();
            m_boneIndex.Clear();
            m_fillBoneIndexListType.Clear();
            m_fillBoneIndexListBonesName.Clear();
            m_forUpdateState = eForUpdateState.None;
            m_tempObj = null;
            m_info = null;
        }
    }





    public override bool CreateOneEcploderObjectForPath(GameObject exploded, eExploderType type)
    {
        return CreateOneForPath(exploded, (int)type);
    }

    private bool CreateOneForPath(GameObject memoryObj, int type)
    {
        memoryObj.SetActive(true);

        DismemberDate ddata = memoryObj.GetComponent<DismemberDate>();

        if (m_removeFade)
            ddata.m_material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTILT_SCREEN_BLEND_ALPHA_3000);

        SkinnedMeshRenderer[] smrs = memoryObj.GetComponentsInChildren<SkinnedMeshRenderer>();


        if (m_removeFade)
            smrs[0].material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
        else
            smrs[0].material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_removeFade)
            smrs[0].material.SetFloat("_AlphaCon", 1);

        Collider[] colliders = memoryObj.GetComponentsInChildren<Collider>();
        int countRig = colliders.Length;
        for (int i = 0; i < countRig; i++)
        {
            colliders[i].gameObject.layer = DEFINE.EXPLODER_LAYER;
        }

        sExploderObject obj = new sExploderObject();
        obj.bUseing = false;
        obj.lastUseTime = -1;
        obj.alpha = 1;

        obj.type = (eExploderType)type;

        if (!m_fillBoneIndexListType.Contains((eExploderType)type))
        {
            string[] bonesName = FillingBoneIndexName((eExploderType)type, memoryObj);
            m_fillBoneIndexListType.Add((eExploderType)type);
            m_fillBoneIndexListBonesName.Add(bonesName);
        }

        Transform tran = GetBip(obj.type, memoryObj.transform);

        if (tran == null)
        {
            MyLog.LogError("Create dismen object can not find transform type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.go = DismenCutter.Dismember(tran, ddata.m_material, ddata);

        if (obj.go == null)
        {
            MyLog.LogError("Create dismen object Dismember fail , type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.trans = Common.GetBone(memoryObj.transform, obj.go.name + "_stump");
        if (obj.trans == null)
        {
            Object.Destroy(obj.go);
            MyLog.LogError("Create dismen object can not find \"" + obj.go.name + "_stump\" transform type : " + obj.type + "\t name : " + memoryObj.name);
            return false;
        }

        obj.parentObj = memoryObj;
        obj.parentTran = memoryObj.transform;
        obj.go.transform.parent = obj.trans;
        obj.parentObj.transform.parent = m_groopTrans;


        SkinnedMeshRenderer[] newSmrs = obj.parentObj.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (newSmrs == null)
        {
            MyLog.LogError("Create dismen object can not find SkinnedMeshRenderer : is null" + "\t name : " + memoryObj.name);
            return false;
        }

        int count = newSmrs.Length;
        if (count <= 0)
        {
            MyLog.LogError("Create dismen object can not find SkinnedMeshRenderer : count <= 0" + "\t name : " + memoryObj.name);
            return false;
        }

        obj.mats = new List<Material>();
        for (int i = 0; i < count; i++)
        {
            if (newSmrs.Length > 0)
            {
                obj.mats.AddRange(newSmrs[i].materials);
            }
        }
        count = obj.mats.Count;
        if (count <= 0)
        {
            MyLog.LogError("Create dismen object can not find material : count <= 0" + "\t name : " + memoryObj.name);
            return false;
        }

        Rigidbody[] newRig = obj.go.GetComponentsInChildren<Rigidbody>();
        if (newRig == null || newRig.Length <= 0)
        {
            MyLog.LogError("Create dismen object can not find Rigidbody : is null" + "\t name : " + memoryObj.name);
            return false;
        }
        obj.rigidbody = newRig[0];

        switch (obj.type)
        {
            case eExploderType.LeftArm: obj.force = memoryObj.transform.TransformDirection(-Vector3.right) * m_wh_ratio + Vector3.up; break;
            case eExploderType.LeftThigh: obj.force = memoryObj.transform.TransformDirection(-Vector3.forward); break;
            case eExploderType.RightArm: obj.force = memoryObj.transform.TransformDirection(Vector3.right) * m_wh_ratio + Vector3.up; break;
            case eExploderType.RightThigh: obj.force = memoryObj.transform.TransformDirection(-Vector3.forward); break;
            case eExploderType.UpDown: obj.force = Vector3.up + memoryObj.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
            case eExploderType.Head: obj.force = Vector3.up + memoryObj.transform.TransformDirection(-Vector3.forward) * m_wh_ratio; break;
        }
        obj.force.Normalize();
        obj.downForce = -Vector3.up * m_downForce * 9.8f * obj.rigidbody.mass;
        //if (obj.type == eExploderType.UpDown)
        //    obj.downForce *= 5;

        obj.parentObj.SetActive(false);
        m_explodedNotUsed.Add(obj);

        m_realCount += 1;

        m_forUpdateState = eForUpdateState.FillBoneName;
        return true;
    }

    public override GameObject GetExploderObjForPath(eExploderType type, Material mat,GameObject exploded, RegisterEvent callback = null, params object[] args)
    {
        if (!m_canGetExploderObject)
            return null;

        m_tempReturnObj = null;
        if (m_realCount > 0)
        {
            m_tempExploderObj = GetExploder(type);
            bool remove = false;
            if (null == m_tempExploderObj)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error m_tempExploderObj  is null in m_explodedNotUsed");
            }

            if (!remove && m_tempExploderObj.parentObj == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject parentObj is null in m_explodedNotUsed");
            }
            if (!remove && m_tempExploderObj.go == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject go is null in m_explodedNotUsed");
            }
            if (!remove && m_tempExploderObj.trans == null)
            {
                remove = true;
                MyLog.LogError("GetExploderObj Error sExploderObject trans is null in m_explodedNotUsed");
            }

            if (remove)
            {
                m_explodedUsing.Remove(m_tempExploderObj);
                CloneExploderObject(type);
                return null;
            }

            ResetMaterials(m_tempExploderObj, mat);

            m_tempReturnObj = m_tempExploderObj.go;
            m_tempExploderObj.alpha = 1;

            m_tempExploderObj.parentObj.SetActive(true);

            bool resule = ResetTransform(type, exploded.transform);

            if (!resule)
                ResetTransform(exploded.transform);

            exploded.SetActive(false);

            Vector3 force = Vector3.zero;
            if (m_tempExploderObj.rigidbody)
            {
                force = m_upSpeed * m_tempExploderObj.force * m_tempExploderObj.rigidbody.mass;
                if (type == eExploderType.UpDown)
                    force *= 1.5f;
                m_tempExploderObj.rigidbody.velocity = force;
            }
        }
        if (callback != null)
            callback(args);
        return m_tempReturnObj;
    }

    private void ResetMaterials(sExploderObject temp, Material mat)
    {
        int count = temp.mats.Count;
        Material tt;
        for (int i = 0; i < count; i++)
        {
            tt = temp.mats[i];
            if (tt.name.Equals("qiemian"))
                continue;
            tt.shader = mat.shader;
            tt.CopyPropertiesFromMaterial(mat);
        }
    }

}
