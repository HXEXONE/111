﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;
using System;


public class CrystalItemInfo
{
    public DragoncrystalContent longjingItem;
    public uint uiCrystalId;    //龙晶ID
    public uint uiCrystalLevel;    //龙晶等级
    public uint uiCrystalStar;    //龙晶星级
    public int quality;         //品质
    public uint uiCrystalFight; //战斗力
    public uint uiCrystalShowLevel; //显示龙晶等级


    public int jingJieID;       //进阶材料消耗ID
    public bool isActive =false;       //是否获得
    public int type = 1;       //是否获得
    public int dropLevel = 1;       //掉落层数
    public List<int> maxAdd = new List<int>();
    public List<int> maxLevel = new List<int>();

    public List< int> curAdd = new List<int>();
    public List<int> techArray = new List<int>();
    public List<bool> activeList = new List<bool>();

    public CrystalItemInfo()
    {

        uiCrystalId = 0;
        uiCrystalLevel = 0;
        uiCrystalStar = 0;
        uiCrystalFight = 0;

        quality = 1;
    }

    public CrystalItemInfo(CrystalInfo info)
    {
        uiCrystalId = info.uiCrystalId;
        uiCrystalLevel = info.uiCrystalLevel;
        uiCrystalStar = info.uiCrystalStar;
        uiCrystalFight = info.uiCrystalFight;
        uiCrystalShowLevel = info.uiCrystalShowLevel;
        longjingItem = HolderManager.m_DragoncrystalHolder.GetStaticInfo(uiCrystalId);
        if (longjingItem!=null)
        {
            quality = CalculateQuality((int)uiCrystalId);
            if (longjingItem.UseItem.Count>0)
            {
                if (longjingItem.UseItem[0].list.Count>0)
                {
                    jingJieID = longjingItem.UseItem[0].list[0];
                }
                
            }
            if (longjingItem.UseType.Count>0)
            {
                type = longjingItem.UseType[0];
            }
            int useId = longjingItem.UseItem[0].list[0];
            ItemContent itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(useId);
            if (itemInfo != null)
            {
                if (itemInfo.DropLevel1[0] == 11)
                {
                    dropLevel = itemInfo.DropLevel1[1];

                }
                else
                {
                    dropLevel = 1;

                }
            }
            if (uiCrystalFight == 0)
            {
                uiCrystalFight = (uint)CalculateGS(longjingItem.PassiveAttrID);
            }
        }
        else
        {
            quality = 1;
        }
    }
    public CrystalItemInfo(int id)
    {
        uiCrystalId = (uint)id;
        uiCrystalLevel = 1;
        uiCrystalStar = 1;
        uiCrystalFight = 0;
        longjingItem = HolderManager.m_DragoncrystalHolder.GetStaticInfo(id);
        uiCrystalShowLevel = 1;
        
        if (longjingItem != null)
        {
            quality = CalculateQuality((int)uiCrystalId);
            if (longjingItem.UseItem.Count > 0)
            {
                if (longjingItem.UseItem[0].list.Count > 0)
                {
                    jingJieID = longjingItem.UseItem[0].list[0];
                }

            }
            if (longjingItem.UseType.Count > 0)
            {
                type = longjingItem.UseType[0];
            }
            int useId = longjingItem.UseItem[0].list[0];
            ItemContent itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(useId);
            if (itemInfo != null)
            {
                if (itemInfo.DropLevel1[0] == 11)
                {
                    dropLevel = itemInfo.DropLevel1[1];

                }
                else
                {
                    dropLevel = 1;

                }
            }
            if (uiCrystalFight ==0)
            {
                uiCrystalFight = (uint)CalculateGS(longjingItem.PassiveAttrID);
            }
        }
        else
        {
            quality = 1;
        }
        isActive = false;
    }

    public int CalculateQuality(int id )
    {
        int quality = 0;
        if (longjingItem != null)
        {
            quality = CalculateQuality(longjingItem);
            if (longjingItem.UseItem.Count>0)
            {
                if (longjingItem.UseItem[0].list.Count>0)
                {
                    jingJieID = longjingItem.UseItem[0].list[0];
                }
                
            }
        
        }
        else
        {
            longjingItem = HolderManager.m_DragoncrystalHolder.GetStaticInfo(id);
            if (longjingItem != null)
            {
                quality = CalculateQuality(longjingItem);
                if (longjingItem.UseItem.Count > 0)
                {
                    if (longjingItem.UseItem[0].list.Count > 0)
                    {
                        jingJieID = longjingItem.UseItem[0].list[0];
                    }

                }
        
            }
        }
        return quality;
    }
    private int CalculateQuality(DragoncrystalContent item)
    {
        int quality = 0;
        quality = item.Key % 100000 % 100;
        return quality;
    }
    private float CalculateGS(int id)
    {
        TechContent techInfo = HolderManager.m_TechHolder.GetStaticInfo(id);
        float gs = 0;
        float attrGS = 0;
        float skillGS = 0f;
        float teshuGS = 0;
        if (techInfo !=null)
        {
            if (SDKManager.GetInst().SdkType == eSdkType.YYB)
            {
                attrGS = techInfo.Livevaluemax[1] * 0.4f + techInfo.Attackvaluemax[1] + techInfo.Fangyuvalue[1] + techInfo.Mingzhongvalue[1] * 4.8f + techInfo.Shanbivalue[1] * 4.8f + techInfo.Baoji[1] * 4.8f + techInfo.Baojishanghai[1] * 4000f + techInfo.Movespeed[1] * 40000;
                teshuGS = techInfo.Shanghaijianmian[1] * 40000f + techInfo.Shanghaizengjia[1] * 40000f + techInfo.Mingzhonglvvalue[1] * 40000f + techInfo.Shanbilvvalue[1] * 40000f + techInfo.Baojilv[1] * 40000f;
            }
            else
            {
                attrGS = techInfo.Livevaluemax[1] * 0.4f + techInfo.Attackvaluemax[1] + techInfo.Fangyuvalue[1] + techInfo.Mingzhongvalue[1] * 4.8f + techInfo.Shanbivalue[1] * 4.8f + techInfo.Baoji[1] * 6.7f + techInfo.Baojishanghai[1] * 4000f + techInfo.Movespeed[1] * 40000;
                teshuGS = techInfo.Shanghaijianmian[1] * 40000f + techInfo.Shanghaizengjia[1] * 40000f + techInfo.Mingzhonglvvalue[1] * 40000f + techInfo.Shanbilvvalue[1] * 40000f + techInfo.Baojilv[1] * 40000f;
            }
          
        }
        gs = attrGS + skillGS;
        gs = gs * (uiCrystalStar + 1);
        gs = gs + teshuGS;
        return gs;
    }

    private void CalculateAttribute()
    {
        uint maxId = uiCrystalId;
        //if (quality>0)
        {
            maxId = (uint)(uiCrystalId + (5 - quality));
        }
        DragoncrystalContent maxlongjingItem = HolderManager.m_DragoncrystalHolder.GetStaticInfo(maxId);
        if (maxlongjingItem!=null)
        {
            maxAdd.Clear();
            maxLevel.Clear();

            for (int i=0;i<maxlongjingItem.ActivateAttrID.Count;i++)
            {
                maxAdd.Add(maxlongjingItem.ActivateAttrID[i].list[0]);
                maxLevel.Add( maxlongjingItem.ActivateAttrID[i].list[1]);
            }
            
        }
        //if (longjingItem != null)
        //{
        //    curAdd.Clear();
        //    for (int i = 0; i < longjingItem.ActivateAttrID.Count; i++)
        //    {
        //        curAdd.Add(longjingItem.ActivateAttrID[i]);
        //    }
        //}

        bool active = false;
        techArray.Clear();
        activeList.Clear();
        for (int i = 0; i < maxAdd.Count;i++ )
        {
            active = false;

            if (i < quality-1)
            {
                active = true;

                techArray.Add(maxAdd[i]);
                activeList.Add(active);

            }
            else if (i == quality - 1)
            {
                if (uiCrystalLevel < 20)
                {
                    techArray.Add(maxAdd[i]);
                    activeList.Add(active);
                }
                else
                {
                    active = true;

                    techArray.Add(maxAdd[i]);
                    activeList.Add(active);
                }
            }
            else
            {

                techArray.Add(maxAdd[i]);
                activeList.Add(active);

            }

        }
    }

    public string  GetActivetAttribute(string color )
    {
        CalculateAttribute();
        string attribute = string.Empty;


        for (int i = 0; i < techArray.Count; i++)
        {

            if (activeList[i] == true)
            {
                Dictionary<string, string> addDict = Common.GetTechNameAndValueDic((uint)techArray[i]);
                foreach (KeyValuePair<string, string> kvp1 in addDict)
                {
                    if (!string.IsNullOrEmpty(attribute))
                    {
                        attribute += "\n";
                    }

                    attribute += (kvp1.Key + "" + kvp1.Value);
                }
            }
        }
        if (!string.IsNullOrEmpty(attribute))
        {
            attribute = (color + attribute + "[-]");

        }
        else
        {
            attribute = "";
        }
        return attribute;
    }
    public string GetNoActivetAttribute(string color)
    {
        CalculateAttribute();
        string attribute = string.Empty;

        int level = 0;
        for (int t = 0; t < techArray.Count; t++)
        {

            if (activeList[t] == false)
            {
                Dictionary<string, string> addDict = Common.GetTechNameAndValueDic((uint)techArray[t]);
                foreach (KeyValuePair<string, string> kvp1 in addDict)
                {
                    if (!string.IsNullOrEmpty(attribute))
                    {
                        attribute += "\n";
                    }

                    attribute += (kvp1.Key + "" + kvp1.Value);

                }
                //只能这样了，属性填的有相同的，我也是醉了，只能这样去找了。不能一样对应，
                if (maxLevel.Count>t)
                {
                    level = maxLevel[t];
                }

                if (level != 0)
                {
                    attribute += Common.GetTextS(9974315, level);
                }
            }
        }
        if (!string.IsNullOrEmpty(attribute))
        {
            attribute = (color + attribute + "[-]");

        }
        else
        {
            attribute = "";
        }
        return attribute;
    }
}

public class LongjingManager : SingletonObject<LongjingManager>
{
    private Dictionary<uint, CrystalItemInfo> allLongJongList = new Dictionary<uint, CrystalItemInfo>();                //所以龙晶
    private Dictionary<uint, CrystalItemInfo> playerAttackList = new Dictionary<uint, CrystalItemInfo>();               //玩家攻击龙晶
    private Dictionary<uint, CrystalItemInfo> playerDefenseList = new Dictionary<uint, CrystalItemInfo>();              //玩家防御龙晶
    private Dictionary<uint, CrystalItemInfo> partnerLongJingList = new Dictionary<uint, CrystalItemInfo>();            //伙伴龙晶

    private Dictionary<uint, CrystalItemInfo> localLongJingList = new Dictionary<uint, CrystalItemInfo>();            //本地伙伴龙晶
    private Dictionary<uint, CrystalItemInfo> playerAttackDict = new Dictionary<uint, CrystalItemInfo>();               //玩家攻击龙晶 (获得与未获得混合)
    private Dictionary<uint, CrystalItemInfo> playerDefenseDict = new Dictionary<uint, CrystalItemInfo>();              //玩家防御龙晶 (获得与未获得混合)
    private Dictionary<uint, CrystalItemInfo> partnerLongJingDict = new Dictionary<uint, CrystalItemInfo>();            //伙伴龙晶 (获得与未获得混合)

    private CrystalItemInfo LongJingItem;
    private ushort uType = 0;
    private string accountid = "";
    private string playerid = "";

    public int LongJingID;
    public int ShengShiID;
    public uint LongJingLevel;


    public int selectMax = 1;
    public int allSelectMax = 2;
    public bool isLogin = true;

    public CrystalItemInfo beforeLongjingItem;
    public CrystalItemInfo curLongjingItem;


    //不应该这样做，但是他们不分index，哎。
    private int STAR_SHENGSHI_ID = 41900118;
    private int END_SHENGSHI_ID = 41900137;
    private int[] SHENGSHI_ID = new int[] { 41900118, 41900119, 41900120, 41900121, 41900122,41900123,41900124,41900125,41900126,41900127,41900128,41900129,
                                            41900130,41900131,41900132,41900133,41900134,41900135,41900136,41900137};           

    public void RegisteMessages(NetworkClient client)
    {
        client.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CRYSTAL_LIST, ReturnLongJingList, true);//回复龙晶列表,G2CAckCrystalList
        client.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CRYSTAL_STARUP, ReturnLongJingStarUP, true); //回复龙晶升星,G2CAckCrystalStarUp
        client.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CRYSTAL_LEVELUP, ReturnLongJingLevelUp, true);//回复龙晶升阶,G2CAckCrystalLevelUp
        client.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_ADD_CRYSTAL, ReturnGetNewLongJong, false);//客户端通知激活龙晶,G2CNotifyAddCrystal
        client.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CRYSTAL_INFO, ReturnLongJingInfo, true);//服务端回复龙晶信息,G2CAckCrystalInfo
        client.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_UPDATE_CRYSTAL, ReturnUpLongJingInfo, false);//服务端通知升级龙晶,G2CNotifyUpdateCrystal
        client.AddOnMessageHandler((ushort)ProCG.GAME_ACK_SELECT_BATTLE_CRYSTAL, ReturnSelectLongjingInfo, false);//服务端回复关卡前选择龙晶,G2CAckSelectBattleCrystal

    }


    #region 客户端请求挖矿信息
    //客户端请求龙晶列表,C2GReqCrystalList
    public void RequestLongJingList()
    {
        //Debug.LogError("...............RequestLongJingList.........." + (ushort)ProCG.CLIENT_REQ_CRYSTAL_LIST+"....");
        C2GReqCrystalList requsetMsg = new C2GReqCrystalList();
        requsetMsg.uiRequest = 0;
        //uType = type;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_CRYSTAL_LIST, (ushort)ProCG.GAME_ACK_CRYSTAL_LIST, requsetMsg);
    }
    //客户端请求龙晶升星,C2GReqCrystalStarUp
    public void RequestLongJingStarUp(int longJingId)
    {
        Debug.LogError("...............RequestLongJingStarUp.........." + (ushort)ProCG.CLIENT_REQ_CRYSTAL_STARUP);
        C2GReqCrystalStarUp requsetMsg = new C2GReqCrystalStarUp();
        requsetMsg.uiCrystalId = (uint)longJingId;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_CRYSTAL_STARUP, (ushort)ProCG.GAME_ACK_CRYSTAL_STARUP, requsetMsg);
    }
    //客户端请求龙晶升阶,C2GReqCrystalLevelUp
    public void RequestLongJingLevelUp(int longJingId,int itemID)
    {
        //Debug.LogError("...............RequestLongJingLevelUp.........." + (ushort)ProCG.CLIENT_REQ_CRYSTAL_LEVELUP);
        C2GReqCrystalLevelUp requsetMsg = new C2GReqCrystalLevelUp();
        requsetMsg.uiCrystalId = (uint)longJingId;
        requsetMsg.uiShengShiId = (uint)itemID;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_CRYSTAL_LEVELUP, (ushort)ProCG.GAME_ACK_CRYSTAL_LEVELUP, requsetMsg);
    }
    //客户端请求龙晶升阶,C2GReqCrystalLevelUp
    public void RequestLongJingInfo(int longJingId)
    {
        //Debug.LogError("...............RequestLongJingInfo.........." + (ushort)ProCG.CLIENT_REQ_CRYSTAL_LEVELUP + "......." + longJingId);
        C2GReqCrystalInfo requsetMsg = new C2GReqCrystalInfo();
        requsetMsg.uiCrystalId = (uint)longJingId;
        LongJingID = longJingId;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_CRYSTAL_INFO, (ushort)ProCG.GAME_ACK_CRYSTAL_INFO, requsetMsg);
    }
    //客户端关卡前选择龙晶,C2GReqSelectBattleCrystal
    public void RequestSelectLongjing(uint attackId,uint defense)
    {
       // Debug.LogError("...............RequestSelectLongjing.........." + attackId + "......." + defense);
        C2GReqSelectBattleCrystal requsetMsg = new C2GReqSelectBattleCrystal();
        requsetMsg.uiAttackCrystalId = attackId;
        requsetMsg.uiDefenseCrystalId = defense;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_SELECT_BATTLE_CRYSTAL, (ushort)ProCG.GAME_ACK_SELECT_BATTLE_CRYSTAL, requsetMsg);
    }
    #endregion

    #region 服务器返回挖矿结果
    //回复龙晶列表,G2CAckCrystalList
    private void ReturnLongJingList(BinaryReader br)
    {
        G2CAckCrystalList resultMsg = new G2CAckCrystalList();
        resultMsg.Read(br);
        //Debug.LogError("...............ReturnLongJingList.........."+resultMsg.aCrystalList.Count);
        allLongJongList.Clear();
        playerAttackList.Clear();
        playerDefenseList.Clear();
        partnerLongJingList.Clear();

        GetLoaclData();

        //allLongJongList = localLongJingList;
        for (int i = 0, iCount = resultMsg.aCrystalList.Count; i < iCount;i++ )
        {
            CrystalItemInfo crystalItem = new CrystalItemInfo();
            uint key =resultMsg.aCrystalList[i].uiCrystalId /100;
            crystalItem.uiCrystalId = resultMsg.aCrystalList[i].uiCrystalId;
            crystalItem.uiCrystalLevel = resultMsg.aCrystalList[i].uiCrystalLevel;
            crystalItem.uiCrystalStar = resultMsg.aCrystalList[i].uiCrystalStar;
            crystalItem.uiCrystalFight=  resultMsg.aCrystalList[i].uiCrystalFight;
            crystalItem.uiCrystalShowLevel = resultMsg.aCrystalList[i].uiCrystalShowLevel;

            crystalItem.isActive = true;
            DragoncrystalContent Longjing =HolderManager.m_DragoncrystalHolder.GetStaticInfo(crystalItem.uiCrystalId);
            if (Longjing !=null)
            {
                crystalItem.longjingItem = Longjing;
                crystalItem.quality = crystalItem.CalculateQuality((int)crystalItem.uiCrystalId);
                if (Longjing.UseType.Count<=0)
                {
                    continue;
                }
                if (Longjing.UseType[0] == 1)//主角武器龙晶(攻击)
                {
                    if (!playerAttackList.ContainsKey(key))
                    {
                        playerAttackList.Add(key, crystalItem);

                    }
                    else
                    {
                        playerAttackList[key] = crystalItem;

                    }
                    if (!playerAttackDict.ContainsKey(key))
                    {
                        playerAttackDict.Add(key, crystalItem);

                    }
                    else
                    {
                        playerAttackDict[key] = crystalItem;

                    }
                }
                if (Longjing.UseType[0] == 2)//主角衣服龙晶(防御)
                {
                    if (!playerDefenseList.ContainsKey(key))
                    {
                        playerDefenseList.Add(key, crystalItem);

                    }
                    else
                    {
                        playerDefenseList[key] = crystalItem;

                    }
                    if (!playerDefenseDict.ContainsKey(key))
                    {
                        playerDefenseDict.Add(key, crystalItem);

                    }
                    else
                    {
                        playerDefenseDict[key] = crystalItem;

                    }
                }
                if (Longjing.UseType[0] == 4)//伙伴龙晶
                {
                    if (!partnerLongJingList.ContainsKey(key))
                    {
                        partnerLongJingList.Add(key, crystalItem);

                    }
                    else
                    {
                        partnerLongJingList[key] = crystalItem;

                    }
                    if (!partnerLongJingDict.ContainsKey(key))
                    {
                        partnerLongJingDict.Add(key, crystalItem);

                    }
                    else
                    {
                        partnerLongJingDict[key] = crystalItem;

                    }
                }
                if (!allLongJongList.ContainsKey(key))
                {
                    allLongJongList.Add(key, crystalItem);

                }
                else
                {
                    allLongJongList[key] = crystalItem;

                }
                if (!localLongJingList.ContainsKey(key))
                {
                    localLongJingList.Add(key, crystalItem);

                }
                else
                {
                    localLongJingList[key] = crystalItem;

                }
                
            }
            else
            {
                MyLog.LogError("cant find longjing id " + crystalItem.uiCrystalId);
                continue;
            }

        }
        SingletonObject<LongjingSelectMediator>.GetInst().GetLocalData();
        SingletonObject<LongjingMainMediator>.GetInst().InitComponent(0);
        SingletonObject<LongjingSelectMediator>.GetInst().InitComponent(0,true);
    }
    //回复龙晶列表,G2CAckCrystalStarUp
    private void ReturnLongJingStarUP(BinaryReader br)
    {
        G2CAckCrystalStarUp resultMsg = new G2CAckCrystalStarUp();
        resultMsg.Read(br);
        //Debug.LogError("...............ReturnLongJingStarUP..........");
        EnumProtocolResult result =(EnumProtocolResult)resultMsg.uiResult;
        if (result == EnumProtocolResult.EnumProtocolResult_Success)
        {
            DragoncrystalContent Longjing =HolderManager.m_DragoncrystalHolder.GetStaticInfo(resultMsg.uiCrystalId);
            CrystalItemInfo itemInfo = null;

            if (Longjing !=null)
            {
                uint key =resultMsg.uiCrystalId /100;

                allLongJongList.TryGetValue(key, out itemInfo);
                if (itemInfo !=null)
                {
                    itemInfo.longjingItem = Longjing;
                    itemInfo.uiCrystalId = resultMsg.uiCrystalId;
                    itemInfo.uiCrystalStar = resultMsg.uiCrystalNewStar;
                    //itemInfo.uiCrystalShowLevel =resultMsg.s
                    RefreshData(itemInfo);
                }
                
            }
            curLongjingItem = itemInfo;

            SingletonObject<LongjingInfoMediator>.GetInst().AfterEvovePartner();
        }
        else
        {
            ResultTipControl(result);

        }

    }
    //回复龙晶列表,G2CAckCrystalLevelUp
    private void ReturnLongJingLevelUp(BinaryReader br)
    {
        G2CAckCrystalLevelUp resultMsg = new G2CAckCrystalLevelUp();
        resultMsg.Read(br);
        //Debug.LogError("...............ReturnLongJingLevelUp..........");
        EnumProtocolResult result = (EnumProtocolResult)resultMsg.uiResult;

        if (result == EnumProtocolResult.EnumProtocolResult_Success)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9974320), Color.green);

        }
        else if (result == EnumProtocolResult.EnumProtocolResult_DragonCrystal_LevelUpRandFailed)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9974321), Color.red);

        }
        else
        {
            ResultTipControl(result);

        }
    }
    //回复龙晶列表,G2CNotifyAddCrystal
    private void ReturnGetNewLongJong(BinaryReader br)
    {
        G2CNotifyAddCrystal resultMsg = new G2CNotifyAddCrystal();
        resultMsg.Read(br);
        //Debug.LogError("...............ReturnGetNewLongJong..........");
        DragoncrystalContent Longjing = HolderManager.m_DragoncrystalHolder.GetStaticInfo(resultMsg.info.uiCrystalId);
        CrystalItemInfo crystalItem = new CrystalItemInfo();
        crystalItem.uiCrystalId = resultMsg.info.uiCrystalId;
        crystalItem.uiCrystalLevel = resultMsg.info.uiCrystalLevel;
        crystalItem.uiCrystalStar = resultMsg.info.uiCrystalStar;
        crystalItem.uiCrystalFight = resultMsg.info.uiCrystalFight;
        crystalItem.uiCrystalShowLevel = resultMsg.info.uiCrystalShowLevel;

        if (Longjing != null)
        {
            crystalItem.longjingItem =Longjing;
            RefreshData(crystalItem);
            SingletonObject<LongjingMainMediator>.GetInst().RefreshComponent();

        }
    }

    //服务端回复龙晶信息,G2CAckCrystalInfo
    private void ReturnLongJingInfo(BinaryReader br)
    {
        G2CAckCrystalInfo resultMsg = new G2CAckCrystalInfo();
        resultMsg.Read(br);
        EnumProtocolResult result = (EnumProtocolResult)resultMsg.uiResult;

        if (result == EnumProtocolResult.EnumProtocolResult_Success)
        {

            //Debug.LogError("...............ReturnLongJingInfo.........." + resultMsg.info.uiCrystalId);
            DragoncrystalContent Longjing = HolderManager.m_DragoncrystalHolder.GetStaticInfo(resultMsg.info.uiCrystalId);
            CrystalItemInfo crystalItem = new CrystalItemInfo();
            crystalItem.uiCrystalId = resultMsg.info.uiCrystalId;
            crystalItem.uiCrystalLevel = resultMsg.info.uiCrystalLevel;
            crystalItem.uiCrystalStar = resultMsg.info.uiCrystalStar;
            crystalItem.uiCrystalFight = resultMsg.info.uiCrystalFight;
            crystalItem.uiCrystalShowLevel = resultMsg.info.uiCrystalShowLevel;

            if (Longjing != null)
            {

                crystalItem.longjingItem = Longjing;
                crystalItem.quality = CalculateQuality((int)crystalItem.uiCrystalId);

                RefreshData(crystalItem);


                SingletonObject<LongjingInfoMediator>.GetInst().SetLongjingInfo(crystalItem);
            }
        }
        else
        {
            ResultTipControl(result);
        }
    }


    //服务端通知升级龙晶,G2CNotifyUpdateCrystal
    private void ReturnUpLongJingInfo(BinaryReader br)
    {
        G2CNotifyUpdateCrystal resultMsg = new G2CNotifyUpdateCrystal();
        resultMsg.Read(br);

        //Debug.LogError("...............ReturnUpLongJingInfo.........." + resultMsg.info.uiCrystalId + "...." + resultMsg.info.uiCrystalFight);
        DragoncrystalContent Longjing = HolderManager.m_DragoncrystalHolder.GetStaticInfo(resultMsg.info.uiCrystalId);
        CrystalItemInfo crystalItem = new CrystalItemInfo();
        crystalItem.uiCrystalId = resultMsg.info.uiCrystalId;
        crystalItem.uiCrystalLevel = resultMsg.info.uiCrystalLevel;
        crystalItem.uiCrystalStar = resultMsg.info.uiCrystalStar;
        crystalItem.uiCrystalFight = resultMsg.info.uiCrystalFight;
        crystalItem.uiCrystalShowLevel = resultMsg.info.uiCrystalShowLevel;
        
        if (Longjing != null)
        {
            crystalItem.longjingItem = Longjing;
            crystalItem.quality = CalculateQuality((int)crystalItem.uiCrystalId);
            RefreshData(crystalItem);

            SingletonObject<LongjingInfoMediator>.GetInst().SetLongjingInfo(crystalItem);
            SingletonObject<LongjingMainMediator>.GetInst().RefreshComponent();
        }
    }
    //服务端回复关卡前选择龙晶,G2CAckSelectBattleCrystal
    private void ReturnSelectLongjingInfo(BinaryReader br)
    {
        G2CAckSelectBattleCrystal resultMsg = new G2CAckSelectBattleCrystal();
        resultMsg.Read(br);
        EnumProtocolResult result = (EnumProtocolResult)resultMsg.uiResult;

        //Debug.LogError("...............ReturnSelectLongjingInfo.........." + result);
        if (result == EnumProtocolResult.EnumProtocolResult_Success)
        {

        }
        else
        {
            ResultTipControl(result);
        }
    }
    #endregion



    private void ResultTipControl(EnumProtocolResult result)
    {
        string mssageText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        PopFrameMediator popMssage = SingletonObject<PopFrameMediator>.GetInst();

        switch (result)
        {
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_PlayerNotExist: //无Player对象
                mssageText = Common.GetText(9974303);
                break; 
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_CrystalNotExist: //无龙晶对象
                mssageText = Common.GetText(9974304);
                break; 
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_LevelUpReachMax :     //升到顶阶了
                mssageText = Common.GetText(9974309);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_ShengShiNotExist: //背包没有圣石
                mssageText = Common.GetText(9974306);
                break; 
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_StarUpReachMax:  //满星了
                mssageText = Common.GetText(9974308);
                break; 
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_MoneyNotEnough:  //钱不够
                mssageText = Common.GetText(9974310);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_StarUpMaterialNotEnough:  //材料不够
                mssageText = Common.GetText(9974311);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_SystemError:  //系统异常
                mssageText = Common.GetText(9974313);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_ModuleNotOpen:   //模块没有打开
                mssageText = Common.GetText(9974314);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_SelectAttackNotExist:   //选择的攻击龙晶不存在
                mssageText = Common.GetText(9974333);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_SelectDefenseNotExist:    //选择的防御龙晶不存在
                mssageText = Common.GetText(9974334);
                break;
            case EnumProtocolResult.EnumProtocolResult_DragonCrystal_SelectBothNotExist:    //选择的龙晶都不存在
                mssageText = Common.GetText(9974332);
                break;
            default:
                mssageText ="the long jing error "+result;

                break;
        }
        if (result == EnumProtocolResult.EnumProtocolResult_Success)
        {

        }
        else
        {
            popMssage.SetPopFrameTips(mssageText, frameType);
        }
    }

    private void GetLoaclData()
    {
        if (isLogin)
        {
            localLongJingList.Clear();
            playerAttackDict.Clear();
            playerDefenseDict.Clear();
            partnerLongJingDict.Clear();
            Dictionary<int, DragoncrystalContent> dragDict = HolderManager.m_DragoncrystalHolder.GetDict();
            uint key = 0;
            CrystalItemInfo crystalItem;
            foreach(KeyValuePair<int ,DragoncrystalContent> kvp in dragDict)
            {
                key = (uint)(kvp.Key / 100);
                crystalItem = new CrystalItemInfo(kvp.Key);
                if (crystalItem.type == 1)
                {
                    if (!playerAttackDict.ContainsKey(key))
                    {
                        playerAttackDict.Add(key, crystalItem);
                    }
                    
                }
                if (crystalItem.type == 2)
                {
                    if (!playerDefenseDict.ContainsKey(key))
                    {
                        playerDefenseDict.Add(key, crystalItem);
                    }
                }
                if (crystalItem.type == 4)
                {
                    if (!partnerLongJingDict.ContainsKey(key))
                    {
                        partnerLongJingDict.Add(key, crystalItem);
                    }
                }
                if (!localLongJingList.ContainsKey(key))
                {
                    localLongJingList.Add(key, crystalItem);
                }
                
            }
            isLogin = false;
        }
    }

    public void RefreshData(CrystalItemInfo crystalItem)
    {

        uint key = crystalItem.uiCrystalId / 100;

        if (crystalItem.longjingItem != null)
        {
            crystalItem.quality = CalculateQuality((int)crystalItem.uiCrystalId);
            crystalItem.isActive = true;
            if (!allLongJongList.ContainsKey(key))
            {
                allLongJongList.Add(key, crystalItem);

            }
            else
            {
                allLongJongList[key] = crystalItem;

            }

            if (!localLongJingList.ContainsKey(key))
            {
                localLongJingList.Add(key, crystalItem);

            }
            else
            {
                localLongJingList[key] = crystalItem;

            }

            int index = 0;
            if (crystalItem.longjingItem.UseType.Count > 0)
            {
                index = crystalItem.longjingItem.UseType[0];
            }


            if (index == 1)//主角武器龙晶(攻击)
            {
                if (!playerAttackList.ContainsKey(key))
                {
                    playerAttackList.Add(key, crystalItem);

                }
                else
                {
                    playerAttackList[key] = crystalItem;

                }
                if (!playerAttackDict.ContainsKey(key))
                {
                    playerAttackDict.Add(key, crystalItem);

                }
                else
                {
                    playerAttackDict[key] = crystalItem;

                }
            }
            if (index == 2)//主角衣服龙晶(防御)
            {
                if (!playerDefenseList.ContainsKey(key))
                {
                    playerDefenseList.Add(key, crystalItem);

                }
                else
                {
                    playerDefenseList[key] = crystalItem;

                }
                if (!playerDefenseDict.ContainsKey(key))
                {
                    playerDefenseDict.Add(key, crystalItem);

                }
                else
                {
                    playerDefenseDict[key] = crystalItem;

                }
            }
            if (index == 4)//伙伴龙晶
            {
                if (!partnerLongJingList.ContainsKey(key))
                {
                    partnerLongJingList.Add(key, crystalItem);

                }
                else
                {
                    partnerLongJingList[key] = crystalItem;

                }
                if (!partnerLongJingDict.ContainsKey(key))
                {
                    partnerLongJingDict.Add(key, crystalItem);

                }
                else
                {
                    partnerLongJingDict[key] = crystalItem;

                }
            }

        }
        else
        {
            MyLog.LogError("the long jing contant is null  ID " + crystalItem.uiCrystalId);
        }
    }
    public float GetStarFor(uint star)
    {

        if (star <= 0)
        {
            star = 1;
        }
        if (star >= 5)
        {
            star = 5;
        }

        if (star == 1)
        {
            return 1f;
        }
        else if (star == 2)
        {
            return 1.05f;
        }
        else if (star == 3)
        {
            return 1.1f;
        }
        else if (star == 4)
        {
            return 1.2f;
        }
        else if (star == 5)
        {
            return 1.4f;
        }
        else
        {
            return 1f;
        }
    }
    public int CalculateQuality(int id)
    {
        int quality = 0;

        DragoncrystalContent longjingItem = HolderManager.m_DragoncrystalHolder.GetStaticInfo(id);
        if (longjingItem != null)
        {
            quality = CalculateQuality(longjingItem);
        }
        return quality;
    }
    private int CalculateQuality(DragoncrystalContent item)
    {
        int quality = 0;
        quality = item.Key % 100000 % 100;
        return quality;
    }
    public int  CalculatePercent(int arg,int level)
    {
        int subLevel = arg - level;
        int percent =0;
        if (subLevel>=10)
        {
            percent = 100; 
        }else if (subLevel>=9)
        {
            percent = 90;
        }
        else if (subLevel >= 8)
        {
            percent =  80;
        }
        else if (subLevel >= 7)
        {
            percent = 70;
        }
        else if (subLevel >= 6)
        {
            percent = 65;
        }
        else if (subLevel >= 5)
        {
            percent = 60;
        }
        else if (subLevel >= 4)
        {
            percent = 55;
        }
        else if (subLevel >= 3)
        {
            percent = 50;
        }
        else if (subLevel >= 2)
        {
            percent = 45;
        }
        else if (subLevel >= 1)
        {
            percent = 40;
        }
        else if (subLevel >= 0)
        {
            percent = 35;
        }
        else if (subLevel >= -1)
        {
            percent = 25;
        }
        else if (subLevel >= -2)
        {
            percent = 15;
        }
        else if (subLevel >= -3)
        {
            percent = 5;
        }
        else if (subLevel > -10)
        {
            percent = 1;
        }
        else
        {
            percent = 1;

        }
        return percent;
    }
    public  string GetCurDescribe(DragoncrystalContent content, uint star,uint level, string color)
    {
        string desc = Common.GetText(content.CurrentDesc);
        if (desc.Contains("#S"))
        {
            string[] strs = desc.Split(new string[] { "%s" }, StringSplitOptions.None);
            string result = "";

            for (int i = 0, count = strs.Length; i < count; ++i)
            {
                result += strs[i];
                if (i<1)
                {
                    if (star <= 0)
                    {
                        star = 0;
                    }
                    if (star > 4)
                    {
                        star = 4;
                    }

                    result += (content.TriggerUp[(int)star] / 100.0f) + "%";
                }
                if (i==1)
                {
                    List<string> args = content.CurrentDescArg;
                    string atr = "";
                    if (args.Count > 1)
                    {
                        string basicStr = args[0].Replace("%", "");
                        float basic = float.Parse(basicStr);
                        string changeStr = args[1].Replace("%", "");
                        float change = float.Parse(changeStr);
                        float title = basic + change * level;
                        if (args[0].Contains("%"))
                        {
                            atr += title + "%";
                        }
                        else
                        {
                            atr = title.ToString();
                        }

                        result += atr;

                    }
                }
            }
            return result.Replace("#S", color).Replace("#E", "[-]");
        }
        return desc;
    }
    public string GetActiveAtr(CrystalItemInfo crystalItem, uint level, string color,bool active)
    {
        /*
        int quality = 0;
        quality = (int)crystalItem.uiCrystalId % 100000 % 100;
        int tempID =0;
        if (quality>1)
        {
            tempID=(int)crystalItem.uiCrystalId -quality+1;
        }
        else
        {
            tempID = (int)crystalItem.uiCrystalId;
        }
        //Debug.LogError("........" + crystalItem.uiCrystalId + "...." + quality + "......" + tempID);

        Dictionary<int, int> techArray = new Dictionary<int, int>();

        for (int i=0;i<5;i++)
        {
            DragoncrystalContent Longjing = HolderManager.m_DragoncrystalHolder.GetStaticInfo(tempID+i);
            if (Longjing!=null)
            {
                if (active)
                {
                    if (level >= (Longjing.SkillLevel[0]+Longjing.MaxLevel))
                    {
                        if (!techArray.ContainsKey(Longjing.ActivateAttrID))
                        {
                            techArray.Add(Longjing.ActivateAttrID, 0);
                        }
                    }
                }
                
                else
                {
                    if (level < (Longjing.SkillLevel[0] + Longjing.MaxLevel))
                    {
                        if (!techArray.ContainsKey(Longjing.ActivateAttrID))
                        {
                            techArray.Add(Longjing.ActivateAttrID, Longjing.SkillLevel[0]+Longjing.MaxLevel);
                        }
                    }
                }
            }
            
        }
        string attribute = string.Empty;
        foreach (KeyValuePair<int, int> kvp1 in techArray)
        {
            Dictionary<string, string> addDict = Common.GetTechNameAndValueDic((uint)kvp1.Key);
            bool keyLen = false;
            foreach (KeyValuePair<string, string> kvp in addDict)
            {
                if (!string.IsNullOrEmpty(attribute))
                {
                    attribute += "\n";
                }
                
                attribute += (kvp.Key + "" + kvp.Value);
                if (kvp1.Value !=0)
                {
                    attribute += Common.GetTextS(9974315, kvp1.Value);
                }
            }

        }
        if (!string.IsNullOrEmpty(attribute))
        {
            attribute = (color + attribute + "[-]");

        }
        else
        {
            attribute = "";
        }
        return attribute;
         * */
        return "";
    }
    public int GetUseItemCount(uint id)
    {
        List<PackItemInfo> normallist = ItemManager.GetInst().GetNormalItemList();
        int number = 0;
        if (normallist != null )
        {
            for (int i = 0, count = normallist.Count; i < count; i++)
            {
                if (normallist[i].uiItemId == id)
                {
                    number += (int)normallist[i].uiItemNum;
                }
            }
        }
        return number;
    }

    public bool longJingShengjie = false;
    public bool longJingQiangHua = false;
    public bool CheckShengJie(uint key)
    {
        if (allLongJongList.ContainsKey(key))
        {

            if (allLongJongList[key].longjingItem == null)
            {
                return false;
            }
            else
            {
                if (allLongJongList[key].uiCrystalStar >= 5)
                {
                    return false;
                }
                int index = (int)allLongJongList[key].uiCrystalStar;
                if (index <= 0)
                {
                    index = 0;
                }
                if (index > 4)
                {
                    index = 4;
                }

                int iCount = allLongJongList[key].longjingItem.UseItem[0].list[index];
                if (GetUseItemCount((uint)allLongJongList[key].jingJieID) >= iCount)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }
        else
        {
            return false;
        }
    }

    public bool CheckAllShengJie()
    {
        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in allLongJongList)
        {
            if (CheckShengJie(kvp.Key))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckAttackShengJie()
    {
        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in playerAttackList)
        {
            if (CheckShengJie(kvp.Key))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckDefenseShengJie()
    {
        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in playerDefenseList)
        {
            if (CheckShengJie(kvp.Key))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckPartnerShengJie()
    {
        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in partnerLongJingList)
        {
            if (CheckShengJie(kvp.Key))
            {
                return true;
            }
        }
        return false;
    }

    public bool CheckIntensify()
    {
        if (GetShengShiList().Count > 0)
        {
            return true;
        }
        return false;
    }

    private List<CrystalItemInfo> DictTranList(Dictionary<uint, CrystalItemInfo> dict)
    {
        List<CrystalItemInfo> list = new List<CrystalItemInfo>();
        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in dict)
        {
            list.Add(kvp.Value);
        }
        list.Sort(delegate(CrystalItemInfo a, CrystalItemInfo b) { return b.uiCrystalFight.CompareTo(a.uiCrystalFight); });
        return list;
    }

    private List<CrystalItemInfo> DictSortList(Dictionary<uint, CrystalItemInfo> dict)
    {
        List<CrystalItemInfo> activeList = new List<CrystalItemInfo>();
        List<CrystalItemInfo> noActiveList = new List<CrystalItemInfo>();

        foreach (KeyValuePair<uint, CrystalItemInfo> kvp in dict)
        {
            if (kvp.Value.isActive)
            {
                activeList.Add(kvp.Value);
            }
            else
            {
                noActiveList.Add(kvp.Value);

            }
        }
        activeList.Sort(delegate(CrystalItemInfo a, CrystalItemInfo b) { return b.uiCrystalFight.CompareTo(a.uiCrystalFight); });
        noActiveList.Sort(delegate(CrystalItemInfo a, CrystalItemInfo b) { return a.dropLevel.CompareTo(b.dropLevel); });
        List<CrystalItemInfo> list = new List<CrystalItemInfo>();

        list.AddRange(activeList);
        list.AddRange(noActiveList);
        return list;

    }

    public Dictionary<uint, CrystalItemInfo> AllLongJongList()
    {
        return allLongJongList;
    }
    public  List<CrystalItemInfo> PlayerActtackList()
    {
        return DictTranList(playerAttackList);
    }
    public List<CrystalItemInfo> PlayerDefenseList()
    {
        return DictTranList(playerDefenseList);
    }
    public List<CrystalItemInfo> PartnerLongJongList()
    {
        return DictTranList(partnerLongJingList); 
    }

    public List<CrystalItemInfo> PlayerActtackAllList()
    {

        return DictSortList(playerAttackDict);
    }
    public List<CrystalItemInfo> PlayerDefenseAllList()
    {
        return DictSortList(playerDefenseDict);
    }
    public List<CrystalItemInfo> PartnerLongJongAllList()
    {
        return DictSortList(partnerLongJingDict);
    }

    public List<PackItemInfo> GetShengShiList()
    {
        List<PackItemInfo> normallist = ItemManager.GetInst().GetNormalItemList();
        List<PackItemInfo> shengShiList = new List<PackItemInfo>();
        if (normallist != null)
        {
            for (int s = 0, scount = SHENGSHI_ID.Length; s < scount; s++)
            {
                for (int i = 0, count = normallist.Count; i < count; i++)
                {
                    if (normallist[i].uiItemId == SHENGSHI_ID[s])
                    {
                        shengShiList.Add(normallist[i]);
                    }
                }
            }
        }
        return shengShiList;
    }

    public CrystalItemInfo PartnerLongJing(int partnerID)
    {
        PartenrContent partnerInfo = HolderManager.m_PartenrHolder.GetStaticInfo(partnerID);
        CrystalItemInfo longjingItem = null;
        if (partnerInfo !=null)
        {
            foreach (KeyValuePair<uint,CrystalItemInfo> kvp in partnerLongJingList)
            {
                if (kvp.Value.longjingItem.UseType.Count>1)
                {
                    if (partnerInfo.LongJingID == kvp.Value.uiCrystalId)
                    {
                        longjingItem = kvp.Value;
                        return longjingItem;
                    }
                }
                
                
            }
            
            
        }
        return longjingItem;
    }



    #region 龙晶存在本地的数据

    /// <summary>
    /// 保存本地龙晶数据 
    /// </summary>
    /// <param name="type"> 战场类型</param>
    /// <param name="index"> 龙晶挂载对象点</param>
    /// <param name="id">龙晶ID</param>
    public void SaveLongJing(eBattleType type, eLongJingPos index, uint id)
    {
        //Debug.LogError(".........." + type + "....." + index + "....." + id);
        if (type == eBattleType.Protect)
        {
            type = eBattleType.Escort;
        }
        PlayerPrefs.SetInt(GetLongJingKey(type, index), (int)id);
    }
    /// <summary>
    /// 返回存储在本地的出战龙晶列表
    /// </summary>
    /// <param name="type">战场类型</param>
    /// <returns></returns>
    public List<CrystalItemInfo> GetLongJingList(eBattleType type,eLongJingPos pos)
    {

        if (type == eBattleType.Protect)
            type = eBattleType.Escort;
        List<CrystalItemInfo> result = new List<CrystalItemInfo>();
        List<uint> temp = GetLongJingListId(type, pos);
        //Debug.LogError("--------------------" + type + "....." + pos + "........." + temp.Count + "....." + allLongJongList.Count);

        for (int i = 0; i < temp.Count;i++ )
        {
            uint key = temp[i] / 100;
            //Debug.LogError(key+"--------------------" + type + "....." + pos + "........." + temp.Count + "....." + allLongJongList.Count);

            if (allLongJongList.ContainsKey(key))
            {
                result.Add(allLongJongList[key]);
            }
            else
            {
                //result.Add(0);
            }
        }
        switch (type)
        {
            case eBattleType.Wasteland:
                
                break;
            case eBattleType.PVE:

            case eBattleType.ClimbTower:
            case eBattleType.GlobalBoss:
            case eBattleType.Escort:
            case eBattleType.Protect:
            case eBattleType.Arena:
            case eBattleType.TeamPve:
            case eBattleType.Pvp:
                break;
        }
        //for (int i = 0; i < result.Count; i++)
        //{
        //    Debug.LogError("------------------" + type + ".........." + result[i].uiCrystalId);
        //}
        return result;
    }
    /// <summary>
    /// 返回存储在本地的出战龙晶列表
    /// </summary>
    /// <param name="type">战场类型</param>
    /// <returns>龙晶id </returns>
    public List<uint> GetLongJingListId(eBattleType type,eLongJingPos pos)
    {
        if (type == eBattleType.Protect)
            type = eBattleType.Escort;
        List<uint> result = new List<uint>();
        if (pos == eLongJingPos.All)
        {
            for (int i = 0; i < allSelectMax; i++)
            {
                if (PlayerPrefs.HasKey(GetLongJingKey(type, (eLongJingPos)i)))
                {
                    result.Add((uint)PlayerPrefs.GetInt(GetLongJingKey(type, (eLongJingPos)i)));
                }
            }
        }
        if (pos == eLongJingPos.Attack)
        {
            if (PlayerPrefs.HasKey(GetLongJingKey(type, (eLongJingPos)pos)))
            {
                result.Add((uint)PlayerPrefs.GetInt(GetLongJingKey(type, (eLongJingPos)pos)));
            }
        }
        if (pos == eLongJingPos.Defense)
        {
            if (PlayerPrefs.HasKey(GetLongJingKey(type, (eLongJingPos)pos)))
            {
                result.Add((uint)PlayerPrefs.GetInt(GetLongJingKey(type, (eLongJingPos)pos)));
            }
        }
        switch (type)
        {
            case eBattleType.Wasteland:

                break;
            case eBattleType.PVE:
            case eBattleType.ClimbTower:
            case eBattleType.GlobalBoss:
            case eBattleType.Escort:
            case eBattleType.Protect:
            case eBattleType.Arena:
            case eBattleType.TeamPve:
            case eBattleType.Pvp:
                break;
        }
        return result;
    }

    private string GetLongJingKey(eBattleType type, eLongJingPos pos)
    {
        string key = string.Empty;
        accountid = SingletonObject<LoginScene>.GetInst().getAccountId().ToString();
        playerid = SingletonObject<LoginScene>.GetInst().GetCurrentLoginAvatarPlayerID().ToString();
        string typestr = string.Empty;
        typestr = type.ToString();
        key = accountid + playerid + typestr + pos;
        return key;
    }
    #endregion
}
