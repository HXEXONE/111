﻿using UnityEngine;
using System.Collections;

public class Notification : SingletonObject<Notification>
{
#if UNITY_IOS
        public void Init()
    {
        CleanNotification();
    }

    //本地推送
    public static void NotificationMessage(string message, int hour, bool isRepeatDay)
    {
        int year = System.DateTime.Now.Year;
        int month = System.DateTime.Now.Month;
        int day = System.DateTime.Now.Day;
        System.DateTime newDate = new System.DateTime(year, month, day, hour, 0, 0);
        NotificationMessage(message, newDate, isRepeatDay);
    }
    //本地推送 你可以传入一个固定的推送时间 
    public static void NotificationMessage(string message, System.DateTime newDate, bool isRepeatDay)
    {
        //推送时间需要大于当前时间
        if (newDate > System.DateTime.Now)
        {
            LocalNotification localNotification = new LocalNotification();
            localNotification.fireDate = newDate;
            localNotification.alertBody = message;
            localNotification.applicationIconBadgeNumber = 1;
            localNotification.hasAction = true;
            if (isRepeatDay)
            {
                //是否每天定期循环
                localNotification.repeatCalendar = CalendarIdentifier.ChineseCalendar;
                localNotification.repeatInterval = CalendarUnit.Day;
            }
            localNotification.soundName = LocalNotification.defaultSoundName;
            NotificationServices.ScheduleLocalNotification(localNotification);
        }
    }
    //清空所有本地消息
    void CleanNotification()
    {
        LocalNotification l = new LocalNotification();
        l.applicationIconBadgeNumber = -1;
        NotificationServices.PresentLocalNotificationNow(l);
        NotificationServices.CancelAllLocalNotifications();
        NotificationServices.ClearLocalNotifications();
    }
#endif
    public void OnApplicationPause(bool paused)
    {
#if UNITY_IOS
        //程序进入后台时
        if (paused)
        {
            }
        else
        {
           
            CleanNotification();
        }
#elif UNITY_ANDROID
        if (paused)
        {
            string title = Common.GetText(9100211);
            string conten1 = Common.GetText(9100208);
            string conten2 = Common.GetText(9100209);
            string conten3 = Common.GetText(9100210);
            if (!string.IsNullOrEmpty(title) &&
                !string.IsNullOrEmpty(conten1) && !string.IsNullOrEmpty(conten2)
                && !string.IsNullOrEmpty(conten3))
            {
                ExternalInterface.GetInst().callJavaMethod("setAlarmA", new string[]
            {
                "12",Common.GetText(9100211),Common.GetText(9100208)
            });
                ExternalInterface.GetInst().callJavaMethod("setAlarmB", new string[]
            {
                "18",Common.GetText(9100211),Common.GetText(9100209)
            });
                ExternalInterface.GetInst().callJavaMethod("setAlarmC", new string[]
            {
                "21",Common.GetText(9100211),Common.GetText(9100210)
            });
            }
        }
       
#endif
    }


}
