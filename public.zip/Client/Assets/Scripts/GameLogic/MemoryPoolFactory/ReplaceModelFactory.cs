﻿using System;
using System.Collections.Generic;



class ReplaceModelFactory : ObjectFactory
{
    public ReplaceModelFactory()
        : base("ReplaceModel")
    {

    }
}

