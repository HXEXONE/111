﻿using UnityEngine;
using System.Collections;

public class ParticleSystemFactory : ObjectFactory
{

    private ParticleSystem[] m_particleSystem;
    private ParticleEmitter[] m_particleEmitter;

    private AnimationDelay[] anidelay;
    private Transform[] m_allTrans;

    public ParticleSystemFactory()
        : base("Particle")
    {
    }


    //private void ParticleSystemAbleControl(GameObject go, bool play)    //新版粒子系统控制,正常慢慢消失
    //{
    //    m_particleSystem = go.GetComponentsInChildren<ParticleSystem>();
    //    int count = m_particleSystem.Length;
    //    for (int i = 0; i < count; i++)
    //    {
    //        if (play)
    //        {
    //            m_particleSystem[i].loop = true;
    //            m_particleSystem[i].Play();
    //        }
    //        else
    //        {
    //            m_particleSystem[i].loop = false;
    //        }
    //    }
    //}

    protected override void SetActive(GameObject o, bool active)
    {
        //if (active)
        //    return;

        //base.SetActive(o, active);

        //if (active)
        //{
        //    m_allTrans = o.GetComponentsInChildren<Transform>(true);
        //    int len = m_allTrans.Length;
        //    for (int i = 0; i < len; i++)
        //    {
        //        m_allTrans[i].gameObject.SetActive(true);
        //    }
        //    ResetAnimationDelay(o, active);
        //}
    }

    private void ResetAnimationDelay(GameObject o, bool active)    //控制AnimationDelay脚本,为防止与SVN冲突，改名为AnimationDelay111(已经修正名字为AnimationDelay)
    {
        anidelay = o.GetComponentsInChildren<AnimationDelay>();
        if (anidelay == null)
            return;
        if (anidelay.Length == 0)
        {
            return;
        }

        int count = anidelay.Length;

        //这里有父子目录关系,所以不能优化这里的代码,将两个循环合并为一个循环
        for (int i = 0; i < count; i++)
        {
            anidelay[i].ResetTime();
        }

        for (int i = 0; i < count; i++)
        {
            anidelay[i].gameObject.SetActive(active);
        }
    }


}
