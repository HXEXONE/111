﻿using UnityEngine;
using System.Collections;

public class PYXFactory : ObjectFactory
{

    public PYXFactory()
        : base("PYX")
    {
    }
}
