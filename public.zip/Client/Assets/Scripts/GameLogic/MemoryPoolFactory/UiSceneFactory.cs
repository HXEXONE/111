﻿using UnityEngine;
using System.Collections;

public class UiSceneFactory : ObjectFactory
{

    public UiSceneFactory()
        : base("uiscene")
    {
 
    }
}
