﻿using UnityEngine;
using System.Collections;

public class HomeAvatarFactory : ObjectFactory
{
    public HomeAvatarFactory()
        : base("HomeAvatar")
    {
    }

    public override void ClearAllMemory()
    {
        //删除动作
        foreach (FactoryObject fo in m_memoryList)
        {
            string aniPath_battle = fo.path.Replace("_model", "_ctrl");
            LoadHelp.RemoveObject(Common.ReplaceModelToCtrl(aniPath_battle));            

            string aniPath_home = fo.path.Replace("_model", "_home_ctrl");
            LoadHelp.RemoveObject(Common.ReplaceModelToCtrl(aniPath_home));
        }

        base.ClearAllMemory();
    }

    
}
