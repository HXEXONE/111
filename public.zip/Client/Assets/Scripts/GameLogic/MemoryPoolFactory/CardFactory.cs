﻿using System;
using System.Collections.Generic;

public class CardFactory : ObjectFactory
{
    public CardFactory()
        : base("CardFactory")
    {

    }
}
