using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FactoryObject
{
    public string path;//����·��,����ʶ���Ƿ���ͬһ�����
    public bool bUsing;//�Ƿ�����ʹ��
    public GameObject obj;//����

    public void Release()
    {
        LoadHelp.RemoveObject(path,true);

        if (obj != null)
        {
            UnityEngine.Object.Destroy(obj);
        }
        
    }
}

public abstract class BaseFactory
{
    private static GameObject m_root;
    protected List<FactoryObject> m_memoryList = new List<FactoryObject>();
    protected Dictionary<uint, LoadDelegate> m_callbackDict = new Dictionary<uint, LoadDelegate>();
    //private Dictionary<string, List<GameObject>> m_memoryDict = new Dictionary<string, List<GameObject>>();
    protected Transform m_GroopTransform;
    private uint m_uiCallbackIndex;

    private ParticleSystem[] m_particleSystems;
    private Color m_tempColor;

    public static void Init()
    {
        m_root = new GameObject("MemoryPoolFactory");
        UnityEngine.Object.DontDestroyOnLoad(m_root);
    }

    public BaseFactory(string sName)
    {
        GameObject o = new GameObject(sName);
        m_GroopTransform = o.transform;
        m_GroopTransform.parent = m_root.transform;

        m_uiCallbackIndex = 0;
    }

    protected uint GetEmptyIndexBase()
    {
        return ++m_uiCallbackIndex;
    }

    protected abstract GameObject CreateGameObject(string sName);

    //һ�㲻��Ҫ������,�������л������������������Ĳ�������NPC��ȫ��ͬ,����ʱ�����ڴ�ռ�ù���ʱ��ִ��
    public virtual void ClearAllMemory()
    {
        foreach (FactoryObject fo in m_memoryList)
        {
            fo.Release();
        }
        m_memoryList.Clear();
    }

    //�������ָ��·���������ڴ�
    public void ClearMemoryExceptPlayer(string exceptPath)
    {
        List<FactoryObject> deleteList = new List<FactoryObject>();
        bool bFind = false;
        foreach (FactoryObject fo in m_memoryList)
        {
            if (exceptPath != null && exceptPath.Equals(fo.path) && !bFind)
            {
                bFind = true;
                continue;
            }

            deleteList.Add(fo);
        }

        for (int i = 0, count = deleteList.Count; i < count; ++i)
        {
            deleteList[i].Release();
            m_memoryList.Remove(deleteList[i]);
        }
    }

    protected int GetObjCount(string sPath)
    {
        int count = 0;
        foreach (FactoryObject fo in m_memoryList)
        {
            if (fo.path == sPath)
            {
                count++;
            }
        }
        return count;
    }

    //Ԥ����һ��������,���뾭��Ԥ����
    public virtual GameObject PreCreate(string sPath,int maxNum)
    {
        GameObject o = null;
        int currNum = 0;

        int count = m_memoryList.Count;
        for (int i = 0; i < count; ++i)
        {
            if (m_memoryList[i].obj == null)
            {
                m_memoryList.RemoveAt(i);
                count--;
                i--;
                continue;
            }

            if (m_memoryList[i].path.Equals(sPath))
            {
                o = m_memoryList[i].obj;
                currNum++;
            }
        }

        for (int i = currNum; i < maxNum; ++i)
        {
            FactoryObject fo = new FactoryObject();
            fo.path = sPath;
            fo.bUsing = false;
            fo.obj = CreateGameObject(sPath);
            fo.obj.transform.parent = m_GroopTransform;

            SetActive(fo.obj, false);
            m_memoryList.Add(fo);

            o = fo.obj;
        }

            

        return o;
    }


    //��ȡһ���ڴ������,ͬ��,ֻ�����Ѿ�Ԥ���ص������
    //public GameObject GetMemoryObj(string sPath,ref bool bUsed)
    //{
    //    GameObject o = null;
    //    bool bFind = false;

    //    foreach (FactoryObject fo in m_memoryList)
    //    {
    //        if (fo.path.Equals(sPath) && !fo.bUsing)
    //        {
    //            o = fo.obj;
    //            fo.bUsing = true;
    //            bFind = true;
    //            bUsed = true;
    //            break;
    //        }
    //    }


    //    if (!bFind)
    //    {
    //        FactoryObject fo = new FactoryObject();
    //        fo.path = sPath;
    //        fo.bUsing = true;
    //        fo.obj = CreateGameObject(sPath);
    //        fo.obj.transform.parent = m_GroopTransform;

    //        m_memoryList.Add(fo);
    //        bUsed = false;
    //        o = fo.obj;
    //    }

    //    o.transform.parent = null;
    //    return o;
    //}

    //��ȡһ���ڴ������,�첽,�κ�����¶����Ե���,����һ���������ص�
    public virtual void GetMemoryObj(string sPath, LoadDelegate callback)
    {
        GameObject o = null;
        bool bFind = false;

        //foreach (FactoryObject fo in m_memoryList)
        //{
        //    if (fo.path == sPath && fo.bUsing == false)
        //    {
        //        o = fo.obj;
        //        o.transform.parent = null;
        //        fo.bUsing = true;
        //        bFind = true;
        //        break;
        //    }
        //}
        int count = m_memoryList.Count;
        FactoryObject fo;
        for (int i = 0;i < count;i++)
        {
            fo = m_memoryList[i];
            if (fo.path == sPath && fo.bUsing == false)
            {
                o = fo.obj;
                if (o == null)
                {
                    m_memoryList.RemoveAt(i);
                    count--;
                    i--;
                    continue;
                }
                o.transform.parent = null;
                fo.bUsing = true;
                bFind = true;
                break;
            }
        }


        if (!bFind)
        {
            uint uiIndex = GetEmptyIndexBase();
            m_callbackDict.Add(uiIndex, callback);
            LoadHelp.LoadObject(sPath + "$" + uiIndex.ToString(), sPath, ThreadPriority.Normal, LoadCompleted);
        }
        else
        {
            callback(DEFINE.TRUE, o);
        }
  
    }

    protected void LoadCompleted(string interim, UnityEngine.Object asset)
    {
        string[] strs = interim.Split('$');
        string path = strs[0];
        uint index = MyConvert_Convert.ToUInt32(strs[1]);

        if (m_callbackDict.ContainsKey(index))
        {
            LoadDelegate callback = m_callbackDict[index];

            if (callback == null)
            {
                return;
            }

            if (asset == null)  //�ж�LoadHelp�ص����ݵ���Ϣ�Ƿ����سɹ�
            {
                callback(DEFINE.FALSE, null);
                m_callbackDict.Remove(index);
                return;
            }
            GameObject o = (GameObject)UnityEngine.Object.Instantiate(asset);
            o.name = path;

            FactoryObject fo = new FactoryObject();
            fo.path = path;
            fo.bUsing = true;
            fo.obj = o;

            m_memoryList.Add(fo);

            DynamicShader.ReplaceUnSupportShader(o);

            if (ClientMain.IsSupportShadowRunTime)
            {
                DestoryShadow(o);
            }

            //ClearAllParticle(o);

            callback(DEFINE.FALSE, o);

            m_callbackDict.Remove(index);
        }
        else
        {
            MyLog.LogError("BaseFactory LoadCompleted can not find index : " + index.ToString() + "\t interim : " + interim);
        }
    }

    //�ͷ�һ���ڴ������
    public void RemoveMemoryObj(GameObject o)
    {
        if (o == null)
        {
            return;
        }
        foreach (FactoryObject fo in m_memoryList)
        {
            if (fo.obj == null)
            {
                continue;
            }
            if (fo.obj == o)
            {
                m_particleSystems = o.GetComponentsInChildren<ParticleSystem>(true);
                if (m_particleSystems != null)
                {
                    int len = m_particleSystems.Length;
                    for (int i = 0; i < len; i++)
                    {
                        m_particleSystems[i].renderer.material.SetColor("_Color",Color.white);
                    }
                }

                fo.obj.name = fo.path;
                fo.bUsing = false;
                SetActive(fo.obj,false);
                fo.obj.layer = 0;
                fo.obj.transform.parent = m_GroopTransform;
                break;
            }
        }
    }

    protected virtual void SetActive(GameObject o, bool active)
    {
        if (o != null)
        {
            o.SetActive(active);
        }
        
    }

    public bool ObjectLoadAlready(string path)
    {
        int count = m_memoryList.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_memoryList[i].obj == null)
            {
                m_memoryList.RemoveAt(i);
                count--;
                i--;
                continue;
            }

            if (m_memoryList[i].path.Equals(path))
                return true;
        }
        return false;
    }

    public int GetLoadAlreadyCount(string path)
    {
        int count = 0,listCount = m_memoryList.Count;
        for (int i = 0; i < listCount; i++)
        {
            if (m_memoryList[i].obj == null)
            {
                m_memoryList.RemoveAt(i);
                listCount--;
                i--;
                continue;
            }

            if (m_memoryList[i].path.Equals(path))
            {
                count++;
            }
        }
        return count;
    }

    private void ClearAllParticle(GameObject o)
    {
        if (!(this is ParticleSystemFactory))
            return;

        MyLog.Log(o.name + "\t" + o.activeInHierarchy + "\t" + o.activeSelf);
        ParticleSystem[] pss = o.GetComponentsInChildren<ParticleSystem>();
        if (pss == null)
            return;

        int count = pss.Length;

        if (count == 0)
            return;

        for (int i = 0; i < count; i++)
        {
            pss[i].Stop();
            pss[i].Clear();
        }
        o.SetActive(false);
    }

    protected void DestoryShadow(GameObject o)
    {
        Transform shadowTran = o.transform.FindChild("shadow");
        if (shadowTran != null)
            Object.Destroy(shadowTran.gameObject);
    }
}
