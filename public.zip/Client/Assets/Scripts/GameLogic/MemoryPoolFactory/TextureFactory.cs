﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TextureFactory : ObjectFactory
{
    private Dictionary<string, Texture2D> m_textureDictionary = new Dictionary<string, Texture2D>();

    public TextureFactory()
        : base("Texture")
    {

    }

    //预创建一个个纹理,必须经过预加载
    public virtual GameObject PreCreate(string sPath, int maxNum)
    {
        return null;
    }

    public override void GetMemoryObj(string sPath, LoadDelegate callback)
    {
        if (callback != null)
            callback("", null);
    }

    public void GetMemoryTexture(string sPath, LoadDelegate callback)
    {
        int count = m_textureDictionary.Count;

        foreach (KeyValuePair<string, Texture2D> val in m_textureDictionary)
        {
            if (val.Key.Equals(sPath))
            {
                callback(DEFINE.TRUE, val.Value);
                return;
            }
        }

        uint uiIndex = GetEmptyIndexBase();
        m_callbackDict.Add(uiIndex, callback);
        LoadHelp.LoadObject(sPath + "$" + uiIndex.ToString(), sPath, ThreadPriority.Normal, LoadTextureCompleted);
    }

    private void LoadTextureCompleted(string interim, UnityEngine.Object asset)
    {
        string[] strs = interim.Split('$');
        string path = strs[0];
        uint index = MyConvert_Convert.ToUInt32(strs[1]);

        if (m_callbackDict.ContainsKey(index))
        {
            LoadDelegate callback = m_callbackDict[index];

            if (callback == null)
            {
                return;
            }

            if (asset == null)  //判断LoadHelp回调传递的信息是否下载成功
            {
                callback(DEFINE.FALSE, null);
                m_callbackDict.Remove(index);
                return;
            }
            Texture2D tex = asset as Texture2D;

            if (!m_textureDictionary.ContainsKey(path))
                m_textureDictionary.Add(path, tex);

            callback(DEFINE.FALSE, tex);

            m_callbackDict.Remove(index);
        }
        else
        {
            MyLog.LogError("BaseFactory LoadCompleted can not find index : " + index.ToString() + "\t interim : " + interim);
        }
    }

    public override void ClearAllMemory()
    {
        foreach (KeyValuePair<string, Texture2D> val in m_textureDictionary)
        {
            LoadHelp.RemoveObject(val.Key, false);
            UnityEngine.Object.DestroyImmediate(val.Value,true);
        }
        m_textureDictionary.Clear();
    }
}
