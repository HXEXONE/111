﻿using UnityEngine;
using System.Collections;

public class FlywordFactory : ObjectFactory
{
    public FlywordFactory()
        : base("Flyword")
    {
    }

    public GameObject GetMemoryObj(string sPath)
    {
        GameObject o = null;
        bool bFind = false;

        int count = m_memoryList.Count;
        FactoryObject fo;
        for (int i = 0; i < count; i++)
        {
            fo = m_memoryList[i];
            if (fo.path.Equals(sPath) && fo.bUsing == false)
            {
                o = fo.obj;
                if (o == null)
                {
                    m_memoryList.RemoveAt(i);
                    count--;
                    i--;
                    continue;
                }
                o.transform.parent = null;
                fo.bUsing = true;
                bFind = true;
                break;
            }
        }

        if (!bFind)
        {
            o = new GameObject(sPath);

            if (sPath.Equals("Flyword_damage") || sPath.Equals("Flyword_heal"))
            {
                CreateQuad(o);
                CreateQuad(o);
                CreateQuad(o);
            }
            else if (sPath.Equals("Flyword_miss"))
            {
                CreateQuad(o);
            }
            else if (sPath.Equals("Flyword_crit"))
            {
                CreateQuad(o);
                CreateQuad(o); 
                CreateQuad(o);
                CreateQuad(o);
            }
           

            fo = new FactoryObject();
            fo.path = sPath;
            fo.bUsing = true;
            fo.obj = o;

            m_memoryList.Add(fo);

        }
        else
        {
            SetActive(o, true);
        }

        return o;
    }

    public void ShowAllFlyWord(bool bShow)
    {
        int count = m_memoryList.Count;
        FactoryObject fo;
        for (int i = 0; i < count; i++)
        {
            fo = m_memoryList[i];
            if (fo.bUsing && fo.obj != null)
            {
                MeshRenderer[] mrs = fo.obj.GetComponentsInChildren<MeshRenderer>();
                foreach (MeshRenderer mr in mrs)
                {
                    mr.enabled = bShow;
                }
               
            }
        }
    }

    private void CreateQuad(GameObject parent)
    {
        GameObject quad = GameObject.CreatePrimitive(PrimitiveType.Quad);
        MeshRenderer mr = quad.GetComponent<MeshRenderer>();
        Material m = new Material(DynamicShader.GetShader("MyMobile/SceenWord_Blend"));
        mr.material = m;

        Collider collider = quad.GetComponent<Collider>();
        if (collider != null)
            Object.Destroy(collider);

        quad.transform.parent = parent.transform;
        quad.transform.localPosition = Vector3.zero;
        quad.transform.localRotation = Quaternion.Euler(0, 180, 0);
        quad.transform.localScale = Vector3.one;
    }
}