﻿using UnityEngine;
using System.Collections;

public class StageFactory : ObjectFactory
{

    public StageFactory()
        : base("Stage")
    {
    }
}
