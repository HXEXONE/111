using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ComponentFactoryObj
{
    public string name;//�������
    public bool bUsing;//�Ƿ�����ʹ��
    public CPanel panel;//���
}

public class ComponentFactory : BaseFactory
{
    private List<ComponentFactoryObj> m_componentList = new List<ComponentFactoryObj>();

    private GameObject m_tmpObj;

    public ComponentFactory()
        :base("Component")
    {
    }

    //��̬�齨�����ڽ����ǰ����Ԥ����
    protected override GameObject CreateGameObject(string sName)
    {
        string path = UITool.GetComponentRelativePath(sName);

        LoadHelp.LoadObject(sName, path, ThreadPriority.Normal, LoadComponentComplete, false, true);

        return m_tmpObj;
    }

    private void LoadComponentComplete(string interim, UnityEngine.Object asset)
    {
        m_tmpObj = (GameObject)GameObject.Instantiate(asset);
        m_tmpObj.name = interim;
    }

    public CPanel GetMemoryPanel(string sName,GameObject parent)
    {
        CPanel panel = null;
        bool bFind = false;

        for (int i = 0, count = m_componentList.Count; i < count; ++i)
        {
            if (m_componentList[i].name.Equals(sName) && !m_componentList[i].bUsing)
            {
                panel = m_componentList[i].panel;
                panel.SetLayer(parent.layer,true);
                panel.ParentObj = parent;
                //GameObject o = m_componentList[i].panel.ElementObj;
                //if(o != null)
                //{
                //    SetActive(o, true);
                //}
                m_componentList[i].bUsing = true;
                bFind = true;
                break;
            }
        }

        if (!bFind)
        {
            panel = new CPanel();
            panel.ElementName = sName;
            panel.ElementObj = CreateGameObject(sName);
            panel.ParentObj = parent;
            panel.SetLayer(parent.layer, false);
            panel.Init();
            panel.FirstInit(null, null);

            ComponentFactoryObj cfo = new ComponentFactoryObj();
            cfo.name = sName;
            cfo.bUsing = true;
            cfo.panel = panel;

            m_componentList.Add(cfo);
        }

        return panel;
    }

    public void RemoveMemoryPanel(CPanel panel)
    {
        for (int i = 0, count = m_componentList.Count; i < count; ++i)
        {
            if (m_componentList[i].panel == panel)
            {
                m_componentList[i].bUsing = false;
                panel.SetActive(false);
                panel.ResetAtlasUse();

                GameObject o = panel.ElementObj;
                if (o != null)
                {
                    o.transform.parent = m_GroopTransform;
                }

                
                break;
            }
        }
    }

    //public void PreCreate(string sName, int maxNum)
    //{
    //    int currNum = 0;

    //    int count = m_componentList.Count;
    //    for (int i = 0; i < count; ++i)
    //    {
    //        if (m_componentList[i].name.Equals(sName))
    //        {
    //            currNum++;
    //        }
    //    }

    //    CPanel panel;
    //    for (int i = currNum; i < maxNum; ++i)
    //    {
    //        panel = new CPanel();
    //        panel.ElementName = sName;
    //        panel.ElementObj = CreateGameObject(sName);
    //        panel.ParentObj = m_GroopTransform.gameObject;
    //        panel.Init();
    //        panel.FirstInit(null, null);

    //        ComponentFactoryObj cfo = new ComponentFactoryObj();
    //        cfo.name = sName;
    //        cfo.bUsing = false;
    //        cfo.panel = panel;

    //        panel.SetActive(false);

    //        m_componentList.Add(cfo);
    //    }
    //}
}
