﻿using UnityEngine;
using System.Collections;

public class CameraEffectFactory : ObjectFactory
{
    public CameraEffectFactory()
        : base("CameraEffect")
    {
    }
}
