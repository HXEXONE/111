﻿//using UnityEngine;
//using System.Collections;

//public class TowerFactory : ObjectFactory
//{
//    public TowerFactory()
//        : base("Tower")
//    {
//    }
//}
