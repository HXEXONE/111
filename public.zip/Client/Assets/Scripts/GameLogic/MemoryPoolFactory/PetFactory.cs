﻿using UnityEngine;
using System.Collections;

public class PetFactory : ObjectFactory
{

    public PetFactory()
        : base("Pet")
    {
    }

    public override void ClearAllMemory()
    {
        //删除动作
        foreach (FactoryObject fo in m_memoryList)
        {
            string aniPath = fo.path.Replace("_model", "_ctrl");
            LoadHelp.RemoveObject(aniPath);
        }
        base.ClearAllMemory();
    }
}
