﻿using UnityEngine;
using System.Collections;

public class RenderAvatarFactory : ObjectFactory
{
    public RenderAvatarFactory()
        :base("RenderAvatar")
    {
    }

    public GameObject GetMemoryObj(string sPath,ref Camera cam,ref GameObject cameraObj)
    {
        GameObject o = null;
        bool bFind = false;

        int count = m_memoryList.Count;
        FactoryObject fo;
        for (int i = 0; i < count; i++)
        {
            fo = m_memoryList[i];
            if (fo.path.Equals(sPath) && fo.bUsing == false)
            {
                o = fo.obj;
                if (o == null)
                {
                    m_memoryList.RemoveAt(i);
                    count--;
                    i--;
                    continue;
                }
                o.transform.parent = null;
                fo.bUsing = true;
                bFind = true;
                break;
            }
        }

        if (!bFind)
        {
            o = new GameObject(sPath);
            o.layer = DEFINE.AVATAR_LAYER;

            cameraObj = new GameObject("RenderCamema");
            cameraObj.transform.parent = o.transform;
            cameraObj.transform.localPosition = Vector3.zero;
            cameraObj.layer = DEFINE.AVATAR_LAYER;

            //add camera component
            cam = cameraObj.AddComponent<Camera>();

            cam.cullingMask = 1 << DEFINE.AVATAR_LAYER | 1 << DEFINE.EFFECT_LAYER; ;
            cam.orthographic = false;
            cam.fieldOfView = 45;
            cam.enabled = false;
            cam.useOcclusionCulling = false;

            fo = new FactoryObject();
            fo.path = sPath;
            fo.bUsing = true;
            fo.obj = o;

            //m_memoryList.Add(fo);

        }
        else
        {
            SetActive(o, true);
            cameraObj = o.transform.Find("RenderCamema").gameObject;
            cam = cameraObj.GetComponent<Camera>();
        }

        return o;
    }
}
