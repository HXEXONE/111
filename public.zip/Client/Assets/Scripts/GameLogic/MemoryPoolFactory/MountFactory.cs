﻿using UnityEngine;
using System.Collections;

public class MountFactory : ObjectFactory
{

    public MountFactory()
        : base("Mount")
    {
    }


    public override void ClearAllMemory()
    {
        //删除动作
        foreach (FactoryObject fo in m_memoryList)
        {       
            string aniPath = fo.path.Replace("_model", "_ctrl");            
            LoadHelp.RemoveObject(aniPath);

            string aniPath1 = fo.path.Replace("_model", "_home_ctrl");
            LoadHelp.RemoveObject(aniPath1);
        }
        base.ClearAllMemory();
    }
}
