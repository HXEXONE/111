using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class NpcFactory : ObjectFactory
{
    private SkinnedMeshRenderer[] m_skinMeshRenderers;


    public NpcFactory()
        : base("Npc")
    {
    }

    public override void GetMemoryObj(string sPath, LoadDelegate callback)
    {
        GameObject o = null;
        bool bFind = false;

        int count = m_memoryList.Count;
        FactoryObject fo;
        for (int i = 0; i < count; i++)
        {
            fo = m_memoryList[i];
            if (fo.path == sPath && fo.bUsing == false)
            {
                o = fo.obj;
                if (o == null)
                {
                    m_memoryList.RemoveAt(i);
                    count--;
                    i--;
                    continue;
                }

                m_skinMeshRenderers = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);
                if (m_skinMeshRenderers == null || m_skinMeshRenderers.Length <= 0)
                {
                    Object.Destroy(o);
                    m_memoryList.RemoveAt(i);
                    count--;
                    i--;
                    m_skinMeshRenderers = null;
                    continue;
                }
                m_skinMeshRenderers = null;

                o.transform.parent = null;
                fo.bUsing = true;
                bFind = true;
                break;
            }
        }


        if (!bFind)
        {
            uint uiIndex = GetEmptyIndexBase();
            m_callbackDict.Add(uiIndex, callback);
            LoadHelp.LoadObject(sPath + "$" + uiIndex.ToString(), sPath, ThreadPriority.Normal, LoadCompleted);
        }
        else
        {
            SetActive(o, true);
            callback(DEFINE.TRUE, o);
        }
    }


    public override void ClearAllMemory()
    {
        //ɾ������
        foreach (FactoryObject fo in m_memoryList)
        {
            string aniPath = fo.path.Replace("_model", "_ctrl");
            LoadHelp.RemoveObject(aniPath);

            string aniPath1 = fo.path.Replace("_model", "_home_ctrl");
            LoadHelp.RemoveObject(aniPath1);
        }
        base.ClearAllMemory();
    }
}
