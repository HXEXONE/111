using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DropObjectFactory : ObjectFactory
{
    public DropObjectFactory()
        : base("DropObject")
    {
    }

    protected override GameObject CreateGameObject(string sName)
    {
        return new GameObject();
    }

}
