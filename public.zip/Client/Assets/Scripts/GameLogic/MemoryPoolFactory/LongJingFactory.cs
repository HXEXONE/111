﻿using System;
using System.Collections.Generic;

public class LongjingFactory : ObjectFactory
{
    public LongjingFactory()
        : base("Longjing")
    {

    }
}
