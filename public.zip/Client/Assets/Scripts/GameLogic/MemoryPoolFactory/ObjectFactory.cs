using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectFactory : BaseFactory
{
    protected Dictionary<int, GameObject> m_Dict = new Dictionary<int, GameObject>();
    private int m_nIndex = 0;

    public ObjectFactory(string listName)
        : base(listName)
    {
    }

    public int GetEmptyIndex()
    {
        m_nIndex++;

        return m_nIndex;
    }

    //���뽨�����Ѿ�Ԥ���ص������
    protected override GameObject CreateGameObject(string sName)
    {
        int nIndex = GetEmptyIndex();
        LoadHelp.LoadObject(nIndex + "$" + sName,  sName, ThreadPriority.Normal, LoadObjCompleted);

        GameObject o = null;
        m_Dict.TryGetValue(nIndex, out o);

        if (null == o)
        {
            MyLog.LogError("Factory cant' find index:" + nIndex + "...name:" + sName);
            return new GameObject();
        }

        return o;
    }

    private void LoadObjCompleted(string interim, UnityEngine.Object asset)
    {
        string[] strs = interim.Split('$');

        int nIndex = MyConvert_Convert.ToInt32(strs[0]);
        string sName = strs[1];

        GameObject o = asset != null ? (GameObject)UnityEngine.Object.Instantiate(asset) : null;

        if ( null != o)
        {
            o.name = sName;
            if (ClientMain.IsSupportShadowRunTime)
            {
                DestoryShadow(o);
            }
        }        
        m_Dict.Add(nIndex, o);
    }
}
