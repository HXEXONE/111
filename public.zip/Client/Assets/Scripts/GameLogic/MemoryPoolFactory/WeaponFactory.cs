﻿using UnityEngine;
using System.Collections;

public class WeaponFactory : ObjectFactory
{

    public WeaponFactory()
        : base("Weapon")
    {
    }
}
