using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class CBuff
{
    private BuffContent m_pBuffInfo;
    private AttrContent m_pAttrInfo;
    private SkillContent m_pIntervalSkillInfo;//����ͷż��� 
    private short m_nAmount;

    private List<uint> m_particleIndex = new List<uint>();

    private Timer m_pTimer;
    private Timer m_pPeriodTimer;

    private CBuffManager m_parent;
    private bool m_bSpecial = false;
    public bool Speical
    {
        get { return m_bSpecial; }
    }

    private CBaseNpc m_pNpc;
    private CSkillupInfo m_pSkillupInfo = null; //����������Ϣ
    private float m_fDragonPromotion = 0f;

    public CBuff(uint uiBuffType, CBaseNpc pNpc, CSkillupInfo pSkillupInfo, CBuffManager parent, bool speical = false, float dragonPromotion = 0f)
    {
        m_parent = parent;
        m_pNpc = pNpc;

        m_pSkillupInfo = pSkillupInfo;
        m_bSpecial = speical;

        m_pBuffInfo = HolderManager.m_BuffHolder.GetStaticInfo(uiBuffType);
        if (m_pBuffInfo != null)
        {
            //������Ч
            List<int> effectlist = m_pBuffInfo.LastEffect;
            for (int i = 0, length = effectlist.Count; i < length; i++)
            {
                if (effectlist[i] != 0)
                {
                    uint index = m_pNpc.CreateParticle((uint)effectlist[i]);
                    m_particleIndex.Add(index);
                    if (m_pNpc.HideModel)
                    {
                        CParticle particle = CParticleManager.GetInst().GetParticle(index);
                        if (null != particle)
                        {
                            particle.ParticleEnabled = false;
                        }
                    }
                    //m_particleIndex = CParticleManager.GetInstance().CreateBindEffect(uiEffectID, pNpc.GetTransform().gameObject);
                }
            }

            LeftTime = m_pBuffInfo.LastTime + BuffTimePromotion;        
            m_nAmount = 1;

            m_pAttrInfo = HolderManager.m_AttrHolder.GetStaticInfo(m_pBuffInfo.AttrID);
            m_pIntervalSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(m_pBuffInfo.SkillID);

            float fPeriod = m_pBuffInfo.Period;
            if (fPeriod != 0)
            {
                m_pPeriodTimer = new Timer();
                m_pPeriodTimer.SetTimer(fPeriod);

                BuffEffect();
                CreateIntervalParticle();
            }
        }
    }

    //ˢ�»����¼�BUFF
    public void Refresh()
    {
        int sizeChange = m_pBuffInfo.SizeChange;
        if (sizeChange != 0)
        {
            Hashtable ht = new Hashtable();
            ht["scale"] = Vector3.one * m_pNpc.ModelSize * sizeChange / 10000.0f;
            ht["time"] = 1.0f;
            ht["easetype"] = iTween.EaseType.easeOutCubic;
            iTween.ScaleTo(m_pNpc.GetObject().gameCObject, ht);
        }
        
    }

    public uint GetBuffType()
    {
        if ( null == m_pBuffInfo)
        {
            return 0;
        }
        return (uint)m_pBuffInfo.Key;
    }

    //buff������Ϣ
    public BuffContent BuffLoader
    {
        get { return m_pBuffInfo; }
    }

    //���ݼ��ܵȼ� �����buff������ʱ��
    public float BuffTimePromotion
    {
        get
        {
            float timeUp = 0f;

            if (null != m_pSkillupInfo)
            {
                timeUp = m_pSkillupInfo.GetTimePromotion();
            }
           
            return timeUp;
        }
    }

    //���ݼ��ܵȼ� �����buff������Ч��
    public float BuffEffectPromotion
    {
        get 
        {
            float effectUp = 0f;

            if (null != m_pSkillupInfo)
            {
                effectUp = m_pSkillupInfo.GetEffectPromotion();
            }

            if (m_fDragonPromotion != 0f)
            {
                effectUp += m_fDragonPromotion;
            }

            return effectUp;
        }
    }


    public short Amount
    {
        set
        {
            m_nAmount = value;
        }
        get
        {
            return m_nAmount;
        }
    }

    public float LeftTime
    {
        get
        {
            if (null == m_pTimer)
            {
                return -1;
            }
            return m_pTimer.GetLeftTime();
        }
        set
        {
            if (value != -1)
            {
                if (null == m_pTimer) m_pTimer = new Timer();
                m_pTimer.SetTimer(value);
            }
            
        }
    }


    public void ReplaceBy(uint uiBuffType)
    {
        m_nAmount = 1;
        m_pBuffInfo = HolderManager.m_BuffHolder.GetStaticInfo(uiBuffType);
        if ( null == m_pBuffInfo)
        {
            return;
        }
        LeftTime = m_pBuffInfo.LastTime + BuffTimePromotion;
    }

    public bool ParticleEnabled
    {
        set 
        {
            for (int i = 0, len = m_particleIndex.Count; i < len;i++ )
            {
                CParticle pParticle = CParticleManager.GetInst().GetParticle(m_particleIndex[i]);
                if (null != pParticle)
                {
                    pParticle.ParticleEnabled = value;
                }
            }            
        }
    }

    public void Update()
    {
        if (m_pNpc.IsDead())
        {
            return;
        }

        if (m_pTimer != null)
        {
            if (m_pTimer.IsExpired(false))
            {
                m_parent.AddDestroyBuff((uint)m_pBuffInfo.Key);
                m_pTimer.Release();
            }
        }
        

        if (m_pPeriodTimer != null)
        {
            if (m_pPeriodTimer.IsExpired(true) && !m_pNpc.IsDead())
            {
                BuffEffect();
                CreateIntervalParticle();
            }
        }
    }


    /// <summary>
    /// Buff �������Ч��
    /// </summary>
    private void BuffEffect()
    {       
        //�������������Ӱ��(����ֻ������ֵӰ��)
        if (null != m_pAttrInfo)
        {
            if (m_pAttrInfo.AttrType != (byte)eAttrType.AddValue &&
            m_pAttrInfo.AttrType != (byte)eAttrType.ReduceValue)
            {
                return;
            }

            int nRate = 1;
            if (m_pAttrInfo.AttrType == (byte)eAttrType.ReduceValue)
            {
                nRate = -1;
            }

            stCharacterCard pCard = m_pNpc.CharacterCard;
            int nHp = m_pNpc.GetHp();
            int nMaxHp = pCard.nMaxHp;

            int nAddHp = nRate * m_nAmount * m_pNpc.CountBuffPower(nHp, m_pAttrInfo.HpList);
            if ( nAddHp <  0 )
            {
                //�˺�����
                nAddHp = (int)(nAddHp * m_pNpc.MaxHpReduceRatio(m_pAttrInfo.HpList, m_pNpc)) - 1;
            }

            int nAddHp_Max = m_pNpc.CountBuffPower(nMaxHp, m_pAttrInfo.MaxHpList) * nRate;
            if (nAddHp_Max < 0 )
            {
                //�˺�����
                nAddHp_Max = (int)(nAddHp_Max * m_pNpc.MaxHpReduceRatio(m_pAttrInfo.MaxHpList, m_pNpc)) - 1;
            }            
            nAddHp += m_nAmount * nAddHp_Max;

            //���㼼�ܵȼ��ӳ�

            if (m_pSkillupInfo != null)
            {
                float damageUp = m_pSkillupInfo.GetEffectPromotion();

                nAddHp = (int)(nAddHp + nAddHp * damageUp);
            }

            if (m_pNpc.ShowAddHpFlyWord(nAddHp))
            {
                SingletonObject<FlywordMediator>.GetInst().CreateFlyword( nAddHp, false, m_pNpc);
            }
            m_pNpc.AddHp(nAddHp);

//              //�����Ч
//             List<uint> effectlist = m_pBuffInfo.GetIntervalEffect();
//             for (int i = 0, length = effectlist.Count; i < length; i++)
//             {
//                 if (effectlist[i] != 0)
//                     m_pNpc.CreateParticle(effectlist[i]);
//              }
        }

        //����ͷż���
        if (null != m_pIntervalSkillInfo)
        {
            //����BUFF�������ܿ��ܵ���������ɾ��BUFF�����,����������Ҫ�����ӳ�
            UnityCallBackManager.GetInst().AddCallBack(0.01f, UseSkill, null);
        }
    }

    private void CreateIntervalParticle() 
    {
        //�����Ч
        List<int> effectlist = m_pBuffInfo.IntervalEffect;
        for (int i = 0, length = effectlist.Count; i < length; i++)
        {
            if (effectlist[i] != 0)
            {
                uint index = m_pNpc.CreateParticle((uint)effectlist[i]);
                m_particleIndex.Add(index);
            }
        }
    }
    
    private void UseSkill(params object[] args)
    {
        m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)m_pIntervalSkillInfo.Key, new List<CBaseNpc>(), true));
    }

    public void Release()
    {
        int sizeChange = m_pBuffInfo.SizeChange;
        if (sizeChange != 0)
        {
            Hashtable ht = new Hashtable();
            ht["scale"] = Vector3.one * m_pNpc.ModelSize;
            ht["time"] = 1.0f;
            ht["easetype"] = iTween.EaseType.easeOutCubic;
            iTween.ScaleTo(m_pNpc.GetObject().gameCObject, ht);
        }

        if ( null != m_particleIndex )
        {
            for (int i = 0, length = m_particleIndex.Count; i < length; i++)
            {                
                CParticleManager.GetInst().AddDestroyParticle(m_particleIndex[i]);
            }
            m_particleIndex.Clear();
        }
    }
}

