﻿using UnityEngine;
using System.Collections.Generic;
using System;


public class CBuffManager
{
    private Dictionary<uint, CBuff> m_BuffDict = new Dictionary<uint, CBuff>();
    private List<uint> m_deleteList = new List<uint>();
    private CBaseNpc m_pNpc;

    public CBuffManager(CBaseNpc pNpc)
    {
        m_pNpc = pNpc;


    }

    /// <summary>
    /// 加buff
    /// </summary>
    /// <param name="uiBuffType"></param>
    /// <param name="pSkillUpLoader">技能等级信息</param>
    public void AddBuff(uint uiBuffType, CSkillupInfo pSkillupInfo = null, bool speical = false, float dragonPromotion = 0f)
    {
        if (m_pNpc.IsDead())
        {
            return;
        }

        BuffContent pBuffInfo = HolderManager.m_BuffHolder.GetStaticInfo(uiBuffType);
        if (null == pBuffInfo)
        {
            return;
        }

        //击晕
        if (pBuffInfo.IsStun)
        {
            if (!m_pNpc.CanBeStun) return;
        }
        //冻结
        if (pBuffInfo.IsFrost)
        {
            if (!m_pNpc.CanBeStun) return;
        }

        //减速
        if (pBuffInfo.ChangeSpeed / 10000f < 0 )
        {
            if (!m_pNpc.CanReduceSpeed) return;            
        }

        CBuff pBuff = FindBuff(uiBuffType);

        if (pBuff != null)
        {
            if (uiBuffType == pBuff.GetBuffType())//相同BUFF叠加
            {
                short nAmount = pBuff.Amount;

                if (pBuff.LeftTime != -1)
                {
                    //取最大时间
                    if (pBuff.LeftTime < pBuffInfo.LastTime + pBuff.BuffTimePromotion)
                    {
                        pBuff.LeftTime = pBuffInfo.LastTime + pBuff.BuffTimePromotion;
                    }
                }                                
                int nMaxSpliceNum = pBuffInfo.SpliceNum;

                if (nMaxSpliceNum == -1)//无限叠加
                {
                    pBuff.Amount += 1;
                }
                else if (nMaxSpliceNum > 0)//可叠加
                {
                    if (pBuff.Amount < nMaxSpliceNum)
                    {
                        pBuff.Amount += 1;
                    }
                }
                else if (nMaxSpliceNum == 0)//不可叠加
                {
                    pBuff.Amount = 1;
                }
            }
            else//非相同BUFF顶替
            {
                pBuff.ReplaceBy(uiBuffType);
            }
        }
        else
        {
            pBuff = new CBuff(uiBuffType, m_pNpc, pSkillupInfo, this, speical, dragonPromotion);
            m_BuffDict.Add(uiBuffType, pBuff);
        }

        //法力护盾
        if (pBuffInfo.MagicShield.Count > 1)
        {
            pBuff.Amount = (short)(pBuffInfo.MagicShield[0]);
        }

        pBuff.Refresh();

        m_pNpc.UpdateBuffAttr();

    
    }

    public void AddDestroyBuff(uint uiBuffType)
    {
        CBuff findBuff = null;
        findBuff = FindBuff(uiBuffType);

        if (findBuff == null)
        {
            return;
        }


        m_deleteList.Add(uiBuffType);
    }

    public CBuff FindBuff(uint dwBuffType)
    {
        CBuff pBuff = null;

        if (m_BuffDict.ContainsKey(dwBuffType))
        {
            pBuff = m_BuffDict[dwBuffType];
        }
        return pBuff;
    }

    //找到法力护盾buff
    public CBuff FindMagicShield() 
    {
        CBuff findBuff = null;
        foreach (var buff in m_BuffDict.Values)
        {
            if (buff.BuffLoader.MagicShield.Count > 1)
            {
                findBuff = buff;
            }
        }
        return findBuff;
    }


    //buff特效开关
    public void SetAllParticleEnabled(bool state)
    {
        foreach (var buff in m_BuffDict.Values)
        {
            buff.ParticleEnabled = state;
        }
    }
    

    public Dictionary<uint, CBuff> GetBuffDict()
    {
        return m_BuffDict;
    }

    //public void Update()
    //{
    //    foreach (uint buffType in m_deleteList)
    //    {
    //        if (m_BuffDict.ContainsKey(buffType))
    //        {
    //            m_BuffDict[buffType].Release();
    //            m_BuffDict.Remove(buffType);

    //            m_pNpc.UpdateCharacterCard();
    //        }
    //    }

    //    if (m_deleteList.Count > 0)
    //    {
    //        m_deleteList.Clear();
    //    }

    //    foreach (CBuff pBuff in m_BuffDict.Values)
    //    {
    //        pBuff.Update();
    //    }
    //}
    public void Update()
    {
        if (m_BuffDict.Count > 0)
        {
            foreach (KeyValuePair<uint, CBuff> kvp in m_BuffDict)
            {
                kvp.Value.Update();
            }
        }

        int count = m_deleteList.Count;

        for (int i = 0; i < count; i++)
        {
            if (m_BuffDict.ContainsKey(m_deleteList[i]))
            {
                m_BuffDict[m_deleteList[i]].Release();
                m_BuffDict.Remove(m_deleteList[i]);
            }
        }

        if (count > 0)
        {
            m_pNpc.UpdateBuffAttr();
            m_deleteList.Clear();
        }
    }

    /// <summary>
    /// 清除所有BUFF
    /// </summary>
    /// <param name="force">是否强力清除，强力清除将会清除掉一些通常需要保留的BUFF</param>
    public void Release(bool force)
    {
        if (m_BuffDict.Count > 0)
        {
            foreach (CBuff pBuff in m_BuffDict.Values)
            {
                //pBuff.Release();
                if (!force)
                {
                    if (
                        pBuff.Speical
                        /*pBuff.GetBuffType() == DEFINE.ARENA_LIFE_BUFF || 
                         pBuff.GetBuffType() == DEFINE.ARENA_ENHANCE_BUFF  ||
                         pBuff.GetBuffType() == DEFINE.ARENA_IMMORTALIZATION_BUFF||
                         pBuff.GetBuffType() == DEFINE.WASTELAND_LIFE_BUFF||
                         pBuff.GetBuffType() == DEFINE.MINING_LIFE_BUFF ||
                         pBuff.GetBuffType() == DEFINE.WASTELAND_ATK_SPEED_BUFF_ID */
                        )
                    {
                        continue;
                    }

                    if (m_pNpc != null && m_pNpc is BaseBattlePlayer)
                    {
                        BaseBattlePlayer pbbp = m_pNpc as BaseBattlePlayer;
                        if (pbbp.Courageous && pBuff.GetBuffType() == DEFINE.FOREVER_ENDURE_BUFF_ID)
                        {
                            continue;
                        }
                    }
                }
               

                AddDestroyBuff(pBuff.GetBuffType());

            }
       
        }
        
        //m_BuffDict.Clear();
    }
}