﻿using UnityEngine;
using System.Collections;

public class AddAnimation : MonoBehaviour {

    private Animation m_animation;
    private AnimationState m_animationState;

    private OnCallBack m_callBack;
    private object[] m_args;

    private float m_normalTime;

    private WrapMode m_mode = WrapMode.ClampForever;

    public void PlayAnimation(Vector3[] path, Vector3[] angles, float[] time, string name, float slope = 0.5f)
    {
        m_animation = animation;
        if (m_animation == null)
            m_animation = gameObject.AddComponent<Animation>();

        AnimationClip clip = null;
        AnimationState state = m_animation[name];

        if (state != null)
            clip = state.clip;

        if (clip == null)
            clip = CreateClip(path, angles, time, name, slope);

        if (clip == null)
        {
            DestroyImmediate(this);
            return;
        }

        clip.wrapMode = m_mode;

        m_animation.AddClip(clip, clip.name);

        m_animation.Play(clip.name);

        m_animationState = m_animation[clip.name];
	}

    public void PlayAnimation(Vector3 toPos, float time, string name, float slope,OnCallBack callback,params object[] args)
    {
        Clear();

        m_callBack = callback;
        m_args = args;

        m_animation = animation;
        if (m_animation == null)
            m_animation = gameObject.AddComponent<Animation>();

        AnimationClip clip = null;

        AnimationState state = m_animation[name];
        if (state != null)
            clip = state.clip;

        Vector3[] path = new Vector3[2];
        path[0] = transform.position;
        path[1] = toPos;

        float[] times = new float[2];
        times[0] = 0;
        times[1] = time;

        if (clip == null)
            clip = CreateClip(path, null, times, name, slope);

        if (clip == null)
        {
            Clear();
            DestroyImmediate(this);
            return;
        }

        clip.wrapMode = m_mode;

        m_animation.AddClip(clip, clip.name);

        m_animation.Play(clip.name);

        m_animationState = m_animation[clip.name];
    }

    public void Stop()
    {
        if (m_animation != null)
        {
            m_animation.Stop();
            Clear();
            DestroyImmediate(this);
        }
    }

    private AnimationClip CreateClip(Vector3[] path, Vector3[] angles, float[] time, string name, float slope = 0.5f)
    {
        int count = path.Length;
        bool needAngle = angles != null;
        if (count < 2)
        {
            MyLog.LogError("Path[] length must greater than one");
        }
        if (needAngle && count != angles.Length)
        {
            MyLog.LogError("Path[] length is not equal angle[] length");
            return null;
        }
        if (count != time.Length)
        {
            MyLog.LogError("Path[] length is not equal time[] length");
            return null;
        }

        //slope = Mathf.Max(0.01f, slope);

        AnimationClip clip = new AnimationClip();

        Keyframe[] keyPosX = new Keyframe[count];
        Keyframe[] keyPosY = new Keyframe[count];
        Keyframe[] keyPosZ = new Keyframe[count];

        Keyframe[] keyAngleX = new Keyframe[count];
        Keyframe[] keyAngleY = new Keyframe[count];
        Keyframe[] keyAngleZ = new Keyframe[count];
        Keyframe[] keyAngleW = new Keyframe[count];

        Vector3 pos;
        Vector3 posNext = Vector3.zero;
        Vector3 posPrevious = Vector3.zero;
        Vector3 posInTangent, posOutTangent;
        Vector3 posTangant = Vector3.zero;

        Vector3 angle = Vector3.zero;
        Quaternion rotation;

        float tangentTimeIn, tangentTimeOut;

        bool isStart = false;
        bool isEnd = false;

        Transform parent = transform.parent;
        Matrix4x4 worldToObject;

        for (int i = 0; i < count; i++)
        {
            isStart = false;
            isEnd = false;

            if(i == 0)
                isStart = true;

            if(i == count - 1)
                isEnd = true;

            if (parent == null)
			{
                pos = path[i];
                if (needAngle)
                {
                    angle = angles[i];
                }

				if (!isEnd)
				{
					posNext = path[i+1];
				}
				
				if (!isStart)
				{
                    posPrevious = path[i - 1];
				}
			}
            else
            {
                worldToObject = parent.worldToLocalMatrix;
                pos = worldToObject.MultiplyPoint(path[i]);
                if (needAngle)
                    angle = (worldToObject * angles[i]);

                if (!isEnd)
                {
                    posNext = worldToObject.MultiplyPoint(path[i + 1]);
                }

                if (!isStart)
                {
                    posPrevious = worldToObject.MultiplyPoint(path[i - 1]);
                }
            }

            if (isStart)
            {
                posInTangent = Vector3.zero;
                posOutTangent = pos - posNext;
                tangentTimeIn = 0;
                tangentTimeOut = time[i] - time[i + 1];
                posTangant = (Vector3.zero + posOutTangent / tangentTimeOut) * slope;
            }
            else if (isEnd)
            {
                posInTangent = posPrevious - pos;
                posOutTangent = Vector3.zero;
                tangentTimeIn = time[i - 1] - time[i];
                tangentTimeOut = 0;
                posTangant = (posInTangent / tangentTimeIn + Vector3.zero) * slope;
            }
            else
            {
                posInTangent = posPrevious - pos;
                posOutTangent = pos - posNext;
                tangentTimeIn = time[i - 1] - time[i];
                tangentTimeOut = time[i] - time[i + 1];
                posTangant = (posInTangent / tangentTimeIn + posOutTangent / tangentTimeOut) * slope;
            }

            keyPosX[i] = new Keyframe(time[i], pos.x, posTangant.x, posTangant.x);
            keyPosY[i] = new Keyframe(time[i], pos.y, posTangant.y, posTangant.y);
            keyPosZ[i] = new Keyframe(time[i], pos.z, posTangant.z, posTangant.z);

            if (needAngle)
            {
                rotation = Quaternion.Euler(angle);
                keyAngleX[i] = new Keyframe(time[i], rotation.x);
                keyAngleY[i] = new Keyframe(time[i], rotation.y);
                keyAngleZ[i] = new Keyframe(time[i], rotation.z);
                keyAngleW[i] = new Keyframe(time[i], rotation.w);
            }

            
        }

        AnimationCurve curvePosX = new AnimationCurve(keyPosX);
        AnimationCurve curvePosY = new AnimationCurve(keyPosY);
        AnimationCurve curvePosZ = new AnimationCurve(keyPosZ);

        clip.SetCurve(null, typeof(Transform), "localPosition.x", curvePosX);
        clip.SetCurve(null, typeof(Transform), "localPosition.y", curvePosY);
        clip.SetCurve(null, typeof(Transform), "localPosition.z", curvePosZ);

        if (needAngle)
        {
            AnimationCurve curveAngleX = new AnimationCurve(keyAngleX);
            AnimationCurve curveAngleY = new AnimationCurve(keyAngleY);
            AnimationCurve curveAngleZ = new AnimationCurve(keyAngleZ);
            AnimationCurve curveAngleW = new AnimationCurve(keyAngleW);

            clip.SetCurve(null, typeof(Transform), "localRotation.x", curveAngleX);
            clip.SetCurve(null, typeof(Transform), "localRotation.y", curveAngleY);
            clip.SetCurve(null, typeof(Transform), "localRotation.z", curveAngleZ);
            clip.SetCurve(null, typeof(Transform), "localRotation.w", curveAngleW);
        }

        clip.name = name;

        return clip;
    }

    void Update()
    {
        if (m_animationState == null)
            return;

        if (m_animationState.normalizedTime >= 1)
        {
            m_animation.Stop();
            Clear();
            DestroyImmediate(this);
        }
    }

    private void Clear()
    {
        if (m_callBack != null)
            m_callBack(m_args);
        if (m_animation)
        {
            Object.DestroyImmediate(m_animation);
            m_animation = null;
        }
        m_animationState = null;
        m_callBack = null;
        m_args = null;
    }
}
