﻿using UnityEngine;
using System.Collections;

public class UITweenOnFinish : MonoBehaviour
{

    public delegate void OnFinishedDelegate();
    public OnFinishedDelegate onFinished;
    public string finishName = string.Empty;

    public void OnFinished()
    {
        if (onFinished != null)
        {
            onFinished();
        }
    }

    void Start()
    {
        /*
#if UNITY_EDITOR
        if (!Application.isPlaying) return;
#endif
        T toggle = GetComponent<T>();
        EventDelegate.Add(toggle.onFinished, OnFinished);
        */
    }
}
