﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class UITweenControl<T>  where T : UITweener
{
    
    public delegate void OnFinishDelegate(T tweener);
    public OnFinishDelegate onFinishDelegate;

    private T tween;
    private GameObject target;
    private Dictionary<string, bool> TweenerDict = new Dictionary<string, bool>();
    private string tweenName = string.Empty;
    private AnimationCurveTool curveTool;
    private UITweener uiTween = null;

    private EventDelegate.Callback FinishCallBack;

    /// <summary>
    /// 浮点型的是对 alpha 等其他的控制；
    /// </summary>
    private float fFrom;
    private float fTo;
    /// <summary>
    /// 向量类型是对 position，scale等做控制用
    /// </summary>
    private Vector3 vFrom;
    private Vector3 vTo;

    private float fdelayFrame;

    public T AddTweener(GameObject go)
    {
        target = go;
        tweenName = typeof(T).ToString();
        tween =(T)go.GetComponent(tweenName);
        if (tween == null)
        {
            tween = go.AddComponent<T>();
            fdelayFrame = 0;
        }
        else
        {
            fdelayFrame = 0.0000001f;
        }
        //if (tween.onFinished.Count <= 0)
        //{
        //    finish = null;
        //    finish = go.GetComponent<UITweenOnFinish>();

        //    if (finish == null)
        //    {
        //        finish = go.AddComponent<UITweenOnFinish>();
        //    }
        //    UITweenOnFinish[] finishs = go.GetComponents<UITweenOnFinish>();

        //    if (!string.IsNullOrEmpty(finish.finishName) && finish.finishName != tweenName)
        //    {
        //        finish = go.AddComponent<UITweenOnFinish>();
        //    }
        //    finish.finishName = tweenName;
        //    EventDelegate.Add(tween.onFinished, finish.OnFinished);
        //}
        curveTool = new AnimationCurveTool();
        uiTween = tween;
        return tween;
    }
    public T GetTweener(GameObject go) 
    {
        if (tween != null)
        {
            target = go;
            tweenName = typeof(T).ToString();
            tween = (T)go.GetComponent(tweenName);
            return tween;
        }
        else
        {
            return null;
        }
    }

    public void SetFinishDelegate(EventDelegate.Callback finishDelegate, bool oneShot = true)
    {
        if (uiTween ==null)
        {
            //MyLog.Log("the uiTweeen is null ");
            return;
        }
        EventDelegate.Add(uiTween.onFinished, finishDelegate, oneShot);
        FinishCallBack = finishDelegate;
    }
    public void SetFinishCallBack(EventDelegate.Callback finishDelegate, bool oneShot = false)
    {
        EventDelegate.Add(uiTween.onFinished, finishDelegate, oneShot);
        FinishCallBack = finishDelegate;
    }

    public void RemoveEventDelegate()
    {
        if (tween != null && tween.onFinished.Count >= 1 && FinishCallBack != null)
        {
            EventDelegate.Remove(tween.onFinished, FinishCallBack);
        }
    }
    private void OnFinishCallBack()
    {
        if (onFinishDelegate != null)
        {
            onFinishDelegate(tween);
        }
    }
    private void SetTween(float delay , AnimationCurveTool.CurveBaseType curveType, UITweener.Method method, UITweener.Style style, int index = 0,AnimationCurve curve = null)
    {
        if (uiTween != null)
        {
            if (curve != null)
            {
                uiTween.animationCurve = curve;
            }
            else
            {
                uiTween.animationCurve = curveTool.GetBaseCurve(curveType);
            }
            uiTween.method = method;
            uiTween.delay = delay + fdelayFrame;
            uiTween.ignoreTimeScale = true;
            uiTween.tweenGroup = index;
            uiTween.style = style;
        }
    }

    public void Reset(GameObject go)
    {
        AddTweener(go);
        switch (tweenName)
        {
            case "TweenAlpha":
                TweenAlpha ta = go.GetComponent<TweenAlpha>();
                if (ta !=null)
                {
                    ta.from = 1.0f;
                    ta.to = 1.0f;
                }
                break;
            case "TweenFOV":
                TweenFOV tf = go.GetComponent<TweenFOV>();
                if (tf != null)
                {
                    tf.from = 60.0f;
                    tf.to = 60.0f;
                }
                break;
            case "TweenHeight":
                TweenHeight th = go.GetComponent<TweenHeight>();
                if (th != null)
                {
                    th.from = 100;
                    th.to = 100;
                }
                break;
            case "TweenOrthoSize":
                TweenOrthoSize tos = go.GetComponent<TweenOrthoSize>();
                if (tos != null)
                {
                    tos.from = 1.0f;
                    tos.to = 1.0f;
                }
                break;
            case "TweenVolume":
                TweenVolume tv = go.GetComponent<TweenVolume>();
                if (tv != null)
                {
                    tv.from = 0.0f;
                    tv.to = 0.0f;
                }
                break;
            case "TweenWidth":
                TweenWidth tw = go.GetComponent<TweenWidth>();
                if (tw != null)
                {
                    tw.from = 100;
                    tw.to = 100;
                }
                break;
            case "TweenPosition":
                TweenPosition tp = go.GetComponent<TweenPosition>();
                if (tp != null)
                {
                    tp.from = Vector3.zero;
                    tp.to = Vector3.zero;
                }
                break;
            case "TweenScale":
                TweenScale ts = go.GetComponent<TweenScale>();
                if (ts != null)
                {
                    ts.from = Vector3.one;
                    ts.to = Vector3.one;
                }
                break;
        }
    }

    #region Single Begin function

    /// <summary>
    /// 开始TweenAlpha TweenWidth TweenFOV TweenHeight TweenOrthoSize TweenVolume TweenWidth的动画，是浮点型的 。基础类型
    /// </summary>
    public UITweener Begin(GameObject go ,float from,float fto,float duration =1.0f)
    {
        if (duration <= 0)
        {
            duration = 1.0f;
        }
        AddTweener(go);
        UIWidget widget = go.GetComponent<UIWidget>();
        switch (tweenName)
        {
            case "TweenAlpha":
                TweenAlpha ta = TweenAlpha.Begin(go, duration, fto);
                ta.from = from;

                uiTween = ta;
                break;
            case "TweenFOV":
                TweenFOV tf = TweenFOV.Begin(go, duration, fto);
                tf.from = from;
                uiTween = tf;
                break;
            case "TweenHeight":
                TweenHeight th = TweenHeight.Begin(widget, duration, (int)fto);
                th.from = (int)from;
                uiTween = th;
                break;
            case "TweenOrthoSize":
                TweenOrthoSize tos = TweenOrthoSize.Begin(go, duration, fto);
                tos.from = from;
                uiTween = tos;
                break;
            case "TweenVolume":
                TweenVolume tv = TweenVolume.Begin(go, duration, fto);
                tv.from = from;
                uiTween = tv;
                break;
            case "TweenWidth":
                TweenWidth tw = TweenWidth.Begin(widget, duration, (int)fto);
                tw.from = (int)from;
                uiTween = tw;
                break;
        }
        return uiTween;
    }

    /// <summary>
    /// 开始TweenPosition TweenScale的动画，是向量类型的 
    /// </summary>
    public UITweener Begin(GameObject go, Vector3 from, Vector3 vto, float duration = 1.0f)
    {
        if (duration <= 0)
        {
            duration = 1.0f;
        }
        AddTweener(go);
        switch (tweenName)
        {
            case "TweenPosition":
                TweenPosition tp = TweenPosition.Begin(go, duration, vto);
                tp.from = from;
                uiTween = tp;
                break;
            case "TweenScale":
                TweenScale ts = TweenScale.Begin(go, duration, vto);
                ts.from = from;
                uiTween = ts;
                break;
        }
        return uiTween;
    }
    //    
    /// <summary>
    /// 开始TweenRotation的动画，是四元素类型的 
    /// </summary>
    public UITweener Begin(GameObject go, Quaternion qfrom, Quaternion qto, float duration = 1.0f)
    {
        if (duration <= 0)
        {
            duration = 1.0f;
        }
        AddTweener(go);
        TweenRotation tr = TweenRotation.Begin(go, duration, qto);
        tr.from = qfrom.eulerAngles;
        uiTween = tr;
        return uiTween;

    }
    /// <summary>
    /// 开始TweenColor的动画，是颜色类型的 
    /// </summary>
    public UITweener Begin(GameObject go, Color cfrom, Color cto, float duration = 1.0f)
    {
        if (duration <= 0)
        {
            duration = 1.0f;
        }
        AddTweener(go);
        TweenColor tc = TweenColor.Begin(go, duration, cto);
        tc.from = cfrom;
        uiTween = tc;
        return uiTween;
    }
    /// <summary>
    /// 开始TweenTransform的动画，
    /// </summary>
    public UITweener Begin(GameObject go, Transform tfrom, Transform tto, float duration = 1.0f)
    {
        if (duration <= 0)
        {
            duration = 1.0f;
        }
        AddTweener(go);
        TweenTransform tt = TweenTransform.Begin(go, duration, tfrom, tto);
        uiTween = tt;
        return uiTween;
    }
        
#endregion
    
#region complex Begin function

    ///<summary>
    ///curveType 动画曲线类型，参考AnimationCurveTool.CurveBaseType 枚举类型
    /// method 动画效果类型，参考UITweener.Method 枚举类型
    /// delay 动画开始时等待时间 默认0
    /// </summary>

    
    /// <summary>
    /// 开始TweenAlpha TweenWidth TweenFOV TweenHeight TweenOrthoSize TweenVolume TweenWidth的动画，是浮点型的 。复杂类型
    /// </summary>
    public T Begin(GameObject go, float from, float fto, float duration, float delay = 0.0f, AnimationCurveTool.CurveBaseType curveType = AnimationCurveTool.CurveBaseType.VariableCurve, UITweener.Method method = UITweener.Method.Linear, UITweener.Style style = UITweener.Style.Once, int index = 0, AnimationCurve curve = null)
    {
        Begin(go, from, fto, duration);
        SetTween(delay,curveType,method,style,index,curve);
        return tween;
    }
    /// <summary>
    /// 开始TweenPosition TweenScale 的动画，是浮点型的 。复杂类型
    /// </summary>
    public T Begin(GameObject go, Vector3 from, Vector3 vto, float duration, float delay = 0.0f, AnimationCurveTool.CurveBaseType curveType = AnimationCurveTool.CurveBaseType.VariableCurve, UITweener.Method method = UITweener.Method.Linear, UITweener.Style style = UITweener.Style.Once, int index = 0, AnimationCurve curve = null)
    {
        Begin(go, from, vto, duration);
        SetTween(delay, curveType, method, style, index, curve);
        return tween;
    }
    /// <summary>
    /// 开始TweenRotation 的动画，是浮点型的 。复杂类型
    /// </summary>
    public T Begin(GameObject go, Quaternion from, Quaternion qto, float duration, float delay = 0.0f, AnimationCurveTool.CurveBaseType curveType = AnimationCurveTool.CurveBaseType.VariableCurve, UITweener.Method method = UITweener.Method.Linear, UITweener.Style style = UITweener.Style.Once, int index = 0, AnimationCurve curve = null)
    {
        Begin(go, from, qto, duration);
        SetTween(delay, curveType, method, style, index, curve);
        return tween;
    }
    /// <summary>
    /// 开始TweenColor 的动画，是浮点型的 。复杂类型
    /// </summary>
    public T Begin(GameObject go, Color from, Color cto, float duration, float delay = 0.0f, AnimationCurveTool.CurveBaseType curveType = AnimationCurveTool.CurveBaseType.VariableCurve, UITweener.Method method = UITweener.Method.Linear, UITweener.Style style = UITweener.Style.Once, int index = 0, AnimationCurve curve = null)
    {
        Begin(go, from, cto, duration);
        SetTween(delay, curveType, method, style, index, curve);
        return tween;
    }
    /// <summary>
    /// 开始TweenTransfor 的动画，对象的transform 。复杂类型
    /// </summary>
    /// <returns></returns>
    public T Begin(GameObject go, Transform tfrom, Transform tto, float duration, float delay = 0.0f, AnimationCurveTool.CurveBaseType curveType =AnimationCurveTool.CurveBaseType.VariableCurve, UITweener.Method method =UITweener.Method.Linear, UITweener.Style style = UITweener.Style.Once, int index = 0, AnimationCurve curve = null)
    {
        Begin(go, tfrom, tto, duration);
        SetTween(delay, curveType, method, style, index, curve);
        return tween;
    }


#endregion

    #region Stop tweener
    public void Stop(GameObject go)
    {
        tweenName = typeof(T).ToString();
        UITweener t = (T)go.GetComponent(tweenName);
        if (t !=null)
        {
            t.enabled = false;
        }           
    }
    #endregion

    public void Play()
    {
    
    }



    #region get and set

    public GameObject GetTarget
    {
        get
        {
            return target;
        }
    }

    public string GetTweenName
    {
        get
        {
            if (string.IsNullOrEmpty(tweenName))
            {
                MyLog.LogError("the tween name not init ,please check ");
                return null;
            }
            return tweenName;
        }
    }

    public AnimationCurveTool GetAnimationCurve
    {
        get
        {
            return curveTool;
        }
    }
    #endregion
}
