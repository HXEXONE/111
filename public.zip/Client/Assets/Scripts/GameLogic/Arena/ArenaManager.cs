﻿using Network;
using Protocol;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class stArenaAvatarInfo
{
    public ulong m_llAccountID;//玩家accountID
    public string szPlayerName;//玩家姓名
    public ushort uiPlayerLevel;//玩家等级
    public ulong uiPlayerID;//player id
    public uint uiWeaponID;//武器ID
    public uint uiClothesID;//衣服ID
    public uint uiJob;//职业ID
    public CrystalItemInfo AttactCrystalData;
    public CrystalItemInfo DefenseCrystalData;
}

public class ArenaManager : SingletonObject<ArenaManager>
{
    public uint playerRanking = 0;    //自身排名
    public uint remainingNumber = 0;//剩余挑战次数
    public uint cdTime = 0;        //cd时间
    public uint buyTimes = 1;  //购买挑战次数
    public List<CArenaBasicInfo> otherInfoList = new List<CArenaBasicInfo>();//创建玩家
    public List<CArenaBasicInfo> rankInfoList = new List<CArenaBasicInfo>();//排行信息 
    public List<CArenaLogInfo> logInfoList = new List<CArenaLogInfo>();//战报日志
    public uint petID = 0; //敌人当前宠物ID
    public uint mountID = 0;   //敌人当前坐骑ID
    public PartnerSortItem partner; //敌人当前出战伙伴ID
    public stArenaAvatarInfo arenaAvatarInfo = new stArenaAvatarInfo();//敌人avatar信息
    public stCharacterCard arenaCharacterCard = new stCharacterCard(1);//敌人属性
    public List<CSkillValue> arenaSkillInfo = new List<CSkillValue>();//敌人技能 

    #region 2014年6月10日10:15:59修改新增字段
    public byte challengeRst;    //战斗结果 1 胜利 0 失败
    public uint historyRank;//历史最高排名
    //public uint awardNum;//最高奖励
    public uint curRankHight;//当前最高排名
    public uint playerBeforeRank;//玩家打之前的排名
    public uint newAward;//奖励
    #endregion

    #region Shop新增字段

    private List<ShopElement> m_pvpShopList = new List<ShopElement>();
    public List<ShopElement> pvpShopList { get { return m_pvpShopList; } set { m_pvpShopList = value; } }
    private int m_pvpRefreshTimes = 1;//刷新次数
    public int pvpRefreshTimes { get { return m_pvpRefreshTimes; } set { m_pvpRefreshTimes = value; } }

    public delegate void ArenaShopBuyFinished();

    public ArenaShopBuyFinished arenaBuyFinished;
    #endregion

    /*
     * 战力
     */
    /// <summary>
    /// 玩家总战力
    /// </summary>
    public float playerTotalGS { get; set; }
    /// <summary>
    /// 玩家属性战力
    /// </summary>
    public float playerGS { get; set; }

    /// <summary>
    /// 敌人属性战力
    /// </summary>
    public float enemyGS { get; set; }

    /// <summary>
    /// 敌人战力
    /// </summary>

    public float enemyTotalGS { get; set; }

    public uint ReportState { get; set; }//战报表示

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.G2C_OPEN_ARENA_RESULT, onG2CChallengeInfoResult, true);//打开界面请求数据
        pClient.AddOnMessageHandler((ushort)ProCG.G2C_REQUEST_CHALLENGE_RESULT, onG2CACKChallenge, true);//被挑战玩家的属性信息返回
        //pClient.AddOnMessageHandler((ushort)ProCG.G2C_REPORT_CHALLENGE_RESULT, onG2CReportChallengeResult);//竞技场结果返回
        pClient.AddOnMessageHandler((ushort)ProCG.G2C_ACK_CLEAR_CHALLENGE_CD, onC2G_CLEAR_CHALLENGE_CD, true);//清除CD时间返回
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_ADD_ARENA_TIMES, onG2CAddArenaTimes, true);//竞技场增加挑战次数返回
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_ARENA_RANK, onG2CACKArenaRank, true);//竞技场排行榜信息返回
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_ARENA_LOG, onG2CACKArenaLog, true);//竞技场战报信息返回
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_ARENA_HISTRECORD, onG2CACKArenaHistRank, false);//竞技场通知最高纪录奖励
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_QUERY_ARENAATTRINFO, onG2CACKQueryRoleAttr, false);//竞技场拿排行榜玩家属性

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_OPEN_PVPSHOP, onG2COpenPvpShopResult, true);//竞技场打开PVP商店
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_REFRESH_PVPSHOP, onG2CRefreshPvpShopResult, true);//竞技场刷新pvp商店货物
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_BUY_PVPSHOP_ITEM, onG2CBuyPvpShopResult, true);//竞技场购买PVP商店货物
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_NEW_ARENA_LOG, onG2CNotifyNewArenaLog, false);//竞技场战报通知
    }

    private void onG2CNotifyNewArenaLog(BinaryReader br)
    {
        G2CNotifyNewArenaLog msg =new G2CNotifyNewArenaLog();
        msg.Read(br);
        ReportState = msg.uiStatus;
        SingletonObject<ArenaMediator>.GetInst().SetReportState();
    }

   
    //返回玩家属性（查看档案时）
    private void onG2CACKQueryRoleAttr(BinaryReader br)
    {
        G2CACKQueryRoleAttr result = new G2CACKQueryRoleAttr();
        result.Read(br);
        if (result.uiResult == (uint)EnumQueryRoleAttrResult.EnumQueryRoleAttrResult_Success)
        {
            EnemyInfoData enemyInfo = SingletonObject<ArenaMediator>.GetInst().enemyInfoData;
            if (result.uiOtherPlayerID != 0)
                enemyInfo.uiPlayerID = result.uiOtherPlayerID;
            AttrValue.GetAttrVec(ref enemyInfo.uiOutcharacterCard, result.attrVec);
            enemyInfo.uiExp = result.uiExp;
            //SingletonObject<ViewPlayerInfoMediator>.GetInst().Open();
            //SingletonObject<ViewPlayerInfoMediator>.GetInst().SetPlayerInfo(enemyInfo);
        }
        else
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9941040), Color.red);
        }
    }

    //竞技场排行榜信息返回
    private void onG2CACKArenaRank(BinaryReader br)
    {
        G2CACKArenaRank result = new G2CACKArenaRank();
        result.Read(br);
        if (result.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            rankInfoList.Clear();
            int ranklistlen = result.rankList.Count;
            rankInfoList = new List<CArenaBasicInfo>(result.rankList);
            List<CArenaBasicInfo> result2 = new List<CArenaBasicInfo>();
            for (int i = 0, count = rankInfoList.Count; i < count; i++)
            {
                CArenaBasicInfo temp = rankInfoList[i];
                temp.uiEquipID = UIManager.GetInst().CheckResourc(temp.uiEquipID, temp.uiJob, eAssetMapCheckType.Cloth);
                temp.uiWeaponID = UIManager.GetInst().CheckResourc(temp.uiWeaponID, temp.uiJob, eAssetMapCheckType.Weapon);
                result2.Add(temp);
            }
            rankInfoList = result2;
            List<uint> tempList = new List<uint>();
            for (int j = 0; j < ranklistlen; j++)
            {
                if (!tempList.Contains(rankInfoList[j].uiNum))
                    tempList.Add(rankInfoList[j].uiNum);
            }
            for (int i = 1; i < 11; i++)
            {
                if (!tempList.Contains((uint)i))
                {
                    //虚构NPC
                    CArenaBasicInfo menemyInfoData = new CArenaBasicInfo();
                    menemyInfoData.uiAccountID = 0;
                    menemyInfoData.uiPlayerID = 1000;
                    menemyInfoData.uiNum = (uint)i;
                    if (!rankInfoList.Contains(menemyInfoData))
                        rankInfoList.Add(menemyInfoData);
                }
            }
            rankInfoList.Sort(SortByRank);
            SingletonObject<ArenaMediator>.GetInst().InitRankPanel();
        }
        else
        {
            ArenaResultManage(result.uiResult);
        }
    }

    //排名比较器(顺序比较)
    private int SortByRank(CArenaBasicInfo x, CArenaBasicInfo y)
    {
        if (x.uiNum == null && y.uiNum == null) return 0;
        else if (x.uiNum == null) return 1;
        else if (y.uiNum == null) return -1;
        else
        {
            return x.uiNum.CompareTo(y.uiNum);
        }
    }

    //竞技场战报返回
    private void onG2CACKArenaLog(BinaryReader br)
    {
        G2CACKArenaLog result = new G2CACKArenaLog();
        result.Read(br);
        if (result.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            logInfoList = new List<CArenaLogInfo>(result.logList);
            SingletonObject<ArenaReportMediator>.GetInst().InitReport();
        }
        else
        {
            ArenaResultManage(result.uiResult);
        }


    }

    ////竞技场增加挑战次数返回
    private void onG2CAddArenaTimes(BinaryReader br)
    {
        G2CAddArenaTimes reslut = new G2CAddArenaTimes();
        reslut.Read(br);
        if (reslut.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9937016), Color.green);
            //购买成功

            buyTimes = reslut.uiBuyTimes;

            //补满次数
            UsualContent usualLoaer = HolderManager.m_UsualHolder.GetStaticInfo(DEFINE.DEFUALT_ARENA_USUAL_ID);

            remainingNumber = (uint)usualLoaer.Times;

            SingletonObject<ArenaMediator>.GetInst().RefreshRemainingNumber();
        }
        else
        {
            ArenaResultManage(reslut.uiResult);
        }
    }

    //竞技场通知最高纪录奖励
    private void onG2CACKArenaHistRank(BinaryReader br)
    {
        G2CACKArenaHistRank result = new G2CACKArenaHistRank();
        result.Read(br);
        curRankHight = result.uiCurRank;
        historyRank = result.uiLastRank;
        newAward = result.uiAward;
        ArenaResultMediator arenaResultMediator = SingletonObject<ArenaResultMediator>.GetInst();
        arenaResultMediator.IsGetAward = true;
    }

    //清除CD时间返回
    private void onC2G_CLEAR_CHALLENGE_CD(BinaryReader br)
    {
        G2CACKClearCD result = new G2CACKClearCD();
        result.Read(br);
        if (result.uiRst == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9941035), Color.green);
            //清除CD成功
            cdTime = 0;
            //刷新界面
            SingletonObject<ArenaMediator>.GetInst().InitData();
        }
        else
        {
            ArenaResultManage(result.uiRst);
        }
    }

    ////挑战玩家返回结果
    private void onG2CACKChallenge(BinaryReader br)
    {
        G2CACKChallenge result = new G2CACKChallenge();
        result.Read(br);
        ArenaReadyMediator arenaPartnerMediator = SingletonObject<ArenaReadyMediator>.GetInst();
        CPlayer cplayer = SingletonObject<CPlayer>.GetInst();
        playerBeforeRank = playerRanking;
        playerGS = cplayer.GetPlayerAttrGS();
        playerTotalGS = cplayer.GetPlayerGS();
        if (result.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            arenaAvatarInfo.uiPlayerID = result.uiOtherPlayerID;//请求的玩家的player ID
            arenaAvatarInfo.m_llAccountID = result.uiOtherAccountID;//请求的玩家的账号ID
            arenaAvatarInfo.uiJob = arenaPartnerMediator.ArenaBasicInfo.uiJob;//职业ID
            arenaAvatarInfo.szPlayerName = Common.GetNameByGUITextID(arenaPartnerMediator.ArenaBasicInfo.uiName);//玩家姓名
            arenaAvatarInfo.uiPlayerLevel = arenaPartnerMediator.ArenaBasicInfo.uiLvl;//玩家等级
            arenaAvatarInfo.uiWeaponID = arenaPartnerMediator.ArenaBasicInfo.uiWeaponID;//武器ID
            arenaAvatarInfo.uiClothesID = arenaPartnerMediator.ArenaBasicInfo.uiEquipID;//衣服ID

            arenaAvatarInfo.AttactCrystalData =new CrystalItemInfo( result.attackCrystalInfo);        //玩家攻击龙晶数据
            arenaAvatarInfo.DefenseCrystalData = new CrystalItemInfo(result.defenseCrystalInfo);        //玩家防御龙晶数据


            petID = (uint)result.uiOutPetID;//敌人当前宠物I
            mountID = (uint)result.uiOutMountID;//敌人当前坐骑ID
            if (result.partner.uiPartnerId == 0)
                partner = null;
            else
                partner = new PartnerSortItem(result.partner);//敵人夥伴信息

            arenaSkillInfo = new List<CSkillValue>(result.skillDataVec);//敌人技能

            AttrValue.GetAttrVec(ref arenaCharacterCard, result.attrVec); //请求的玩家的属性信息
            arenaCharacterCard = arenaCharacterCard.Decode();
            /*
             * 修改字段
             */
            challengeRst = result.challengeRst;    //战斗结果 1 胜利 0 失败
            remainingNumber = result.uiChallengeTimes; //剩余挑战次数
            cdTime = result.uiCD;    //CD时间 秒
            playerRanking = result.uiNum;    //玩家排名新的排名
            enemyGS = arenaPartnerMediator.EnemyInfoData.uiAttrFightValue;
            enemyTotalGS = arenaPartnerMediator.EnemyInfoData.uiFightCapacity;
            //AttrValue.CalcAttrVec(ref arenaCharacterCard, enemyGS, arenaAvatarInfo.uiPlayerLevel);

            if (partner != null)
                AttrValue.CalcPartnerAttrVec(ref partner.info.attrVec, arenaCharacterCard, partner.loader, (uint)partner.startlevel);

            //检查以下资源是否存在目前资源包中,如果不存在则找替代资源.
            arenaAvatarInfo.uiClothesID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiClothesID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Cloth);
            arenaAvatarInfo.uiWeaponID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiWeaponID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Weapon);
            mountID = UIManager.GetInst().CheckResourc(mountID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Mount);
            petID = UIManager.GetInst().CheckResourc(petID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Pet);
            PartnerSortItem newpartner = partner;
            if (partner != null)
            {
                newpartner.uiPartnerId = UIManager.GetInst().CheckResourc(partner.uiPartnerId, arenaAvatarInfo.uiJob, eAssetMapCheckType.Partner);
                if (newpartner.uiPartnerId != 0)
                {
                    PartenrContent laoder = HolderManager.m_PartenrHolder.GetStaticInfo(newpartner.uiPartnerId);
                    newpartner.loader = laoder;
                    
                }
                partner.info.vecSkillList = Common.GetReplacePartnerSkillList(newpartner.info.vecSkillList, newpartner.loader);
                partner = newpartner;
            }

            cplayer.OperArenaBattle(DEFINE.ARENA_MAP_ID);

        }
        else if (result.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_NPC)
        {

            arenaAvatarInfo.uiPlayerID = result.uiOtherPlayerID;//请求的玩家的player ID
            arenaAvatarInfo.m_llAccountID = result.uiOtherAccountID;//请求的玩家的账号ID
            arenaAvatarInfo.uiJob = arenaPartnerMediator.EnemyInfoData.uiJob;//职业ID
            arenaAvatarInfo.szPlayerName = arenaPartnerMediator.EnemyInfoData.uiName;//玩家姓名
            arenaAvatarInfo.uiPlayerLevel = arenaPartnerMediator.EnemyInfoData.uiLvl;//玩家等级
            arenaAvatarInfo.uiWeaponID = arenaPartnerMediator.EnemyInfoData.uiWeaponID;//武器ID
            arenaAvatarInfo.uiClothesID = arenaPartnerMediator.EnemyInfoData.uiEquipID;//衣服ID
            petID = (uint)result.uiOutPetID;//敌人当前宠物I
            mountID = (uint)result.uiOutMountID;//敌人当前坐骑ID
            if (result.partner.uiPartnerId == 0)
                partner = null;
            else
                partner = new PartnerSortItem(result.partner);//敵人夥伴信息
            AttrValue.GetAttrVec(ref arenaCharacterCard, result.attrVec); //请求的玩家的属性信息
            arenaCharacterCard = arenaCharacterCard.Decode();
            arenaSkillInfo = new List<CSkillValue>(result.skillDataVec);//敌人技能
            enemyGS = arenaPartnerMediator.EnemyInfoData.uiAttrFightValue;
            //AttrValue.CalcAttrVec(ref arenaCharacterCard, enemyGS, arenaAvatarInfo.uiPlayerLevel);
            //arenaCharacterCard = arenaCharacterCard.Decode();
            if (partner != null)
                AttrValue.CalcPartnerAttrVec(ref partner.info.attrVec, arenaCharacterCard, partner.loader, (uint)partner.startlevel);
            challengeRst = result.challengeRst;    //战斗结果 1 胜利 0 失败
            remainingNumber = result.uiChallengeTimes; //剩余挑战次数
            cdTime = result.uiCD;    //CD时间 秒
            playerRanking = result.uiNum;    //玩家排名新的排名
            newAward = result.uiAward;
            enemyTotalGS = arenaPartnerMediator.EnemyInfoData.uiFightCapacity;

            //检查以下资源是否存在目前资源包中,如果不存在则找替代资源.
            arenaAvatarInfo.uiClothesID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiClothesID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Cloth);
            arenaAvatarInfo.uiWeaponID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiWeaponID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Weapon);
            mountID = UIManager.GetInst().CheckResourc(mountID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Mount);
            petID = UIManager.GetInst().CheckResourc(petID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Pet);
            PartnerSortItem newpartner = partner;
            if (partner != null)
            {
                newpartner.uiPartnerId = UIManager.GetInst().CheckResourc(partner.uiPartnerId, arenaAvatarInfo.uiJob, eAssetMapCheckType.Partner);
                if (newpartner.uiPartnerId != 0)
                {
                    PartenrContent laoder = HolderManager.m_PartenrHolder.GetStaticInfo(newpartner.uiPartnerId);
                    newpartner.loader = laoder;
                }
                partner.info.vecSkillList = Common.GetReplacePartnerSkillList(newpartner.info.vecSkillList, newpartner.loader);
                partner = newpartner;
            }

            cplayer.OperArenaBattle(DEFINE.ARENA_MAP_ID);

        }
        else if (result.uiResult == (uint)EnumChallegeErr.EnumChallegeErr_TowBeat)
        {
            arenaAvatarInfo.uiPlayerID = result.uiOtherPlayerID;//请求的玩家的player ID
            arenaAvatarInfo.m_llAccountID = result.uiOtherAccountID;//请求的玩家的账号ID
            arenaAvatarInfo.uiJob = arenaPartnerMediator.ArenaBasicInfo.uiJob;//职业ID
            arenaAvatarInfo.szPlayerName = Common.GetNameByGUITextID(arenaPartnerMediator.ArenaBasicInfo.uiName);//玩家姓名
            arenaAvatarInfo.uiPlayerLevel = arenaPartnerMediator.ArenaBasicInfo.uiLvl;//玩家等级
            arenaAvatarInfo.uiWeaponID = arenaPartnerMediator.ArenaBasicInfo.uiWeaponID;//武器ID
            arenaAvatarInfo.uiClothesID = arenaPartnerMediator.ArenaBasicInfo.uiEquipID;//衣服ID
            petID = (uint)result.uiOutPetID;//敌人当前宠物I
            mountID = (uint)result.uiOutMountID;//敌人当前坐骑ID
            if (result.partner.uiPartnerId == 0)
                partner = null;
            else
                partner = new PartnerSortItem(result.partner);//敵人夥伴信息
            arenaSkillInfo = new List<CSkillValue>(result.skillDataVec);//敌人技能
            AttrValue.GetAttrVec(ref arenaCharacterCard, result.attrVec); //请求的玩家的属性信息
            arenaCharacterCard = arenaCharacterCard.Decode();
            /*
             * 修改字段
             */
            challengeRst = result.challengeRst;    //战斗结果 1 胜利 0 失败
            remainingNumber = result.uiChallengeTimes; //剩余挑战次数
            cdTime = result.uiCD;    //CD时间 秒
            playerRanking = result.uiNum;    //玩家排名新的排名
            enemyGS = arenaPartnerMediator.EnemyInfoData.uiAttrFightValue;
            enemyTotalGS = arenaPartnerMediator.EnemyInfoData.uiFightCapacity;


            //AttrValue.CalcAttrVec(ref arenaCharacterCard, enemyGS, arenaAvatarInfo.uiPlayerLevel);
            if (partner != null)
                AttrValue.CalcPartnerAttrVec(ref partner.info.attrVec, arenaCharacterCard, partner.loader, (uint)partner.startlevel);
            //cplayer.OperArenaBattle(DEFINE.ARENA_MAP_ID);

       
                //检查以下资源是否存在目前资源包中,如果不存在则找替代资源.
                arenaAvatarInfo.uiClothesID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiClothesID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Cloth);
                arenaAvatarInfo.uiWeaponID = UIManager.GetInst().CheckResourc(arenaAvatarInfo.uiWeaponID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Weapon);
                mountID = UIManager.GetInst().CheckResourc(mountID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Mount);
                petID = UIManager.GetInst().CheckResourc(petID, arenaAvatarInfo.uiJob, eAssetMapCheckType.Pet);
                PartnerSortItem newpartner = partner;
            if (partner != null)
            {
                newpartner.uiPartnerId = UIManager.GetInst().CheckResourc(partner.uiPartnerId, arenaAvatarInfo.uiJob, eAssetMapCheckType.Partner);
                if (newpartner.uiPartnerId != 0)
                {
                    PartenrContent laoder = HolderManager.m_PartenrHolder.GetStaticInfo(newpartner.uiPartnerId);
                    newpartner.loader = laoder;
                }
                partner.info.vecSkillList = Common.GetReplacePartnerSkillList(newpartner.info.vecSkillList, newpartner.loader);
                partner = newpartner;
            }

            challengeRst = result.challengeRst;    //战斗结果 1 胜利 0 失败
            remainingNumber = result.uiChallengeTimes; //剩余挑战次数
            cdTime = result.uiCD;    //CD时间 秒
            playerRanking = result.uiNum;    //玩家排名新的排名
            newAward = result.uiAward;
            cplayer.OperArenaBattle(DEFINE.ARENA_MAP_ID);
        }
        else
        {
            //SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(((EnumChallegeErr)result.uiResult).ToString(), PopFrameType.singleOkButton, null);
            ArenaResultManage(result.uiResult);
        }

    }



    //竞技场的信息 
    private void onG2CChallengeInfoResult(BinaryReader br)
    {
        G2CChallengeInfoResult result = new G2CChallengeInfoResult();
        result.Read(br);
        if (result.uiRst == (uint)EnumChallegeErr.EnumChallegeErr_Success)
        {
            //填充界面
            playerRanking = result.uiNum;
            remainingNumber = result.uiChallengeTimes;
            cdTime = result.uiCD;
            buyTimes = result.uiBuyTimes;
            playerBeforeRank = result.uiBestRecord;
            otherInfoList = new List<CArenaBasicInfo>(result.otherInfoList);
            List<CArenaBasicInfo> result2 = new List<CArenaBasicInfo>();
            for (int i = 0, count = otherInfoList.Count; i < count; i++)
            {
                CArenaBasicInfo temp = otherInfoList[i];
                temp.uiEquipID = UIManager.GetInst().CheckResourc(temp.uiEquipID, temp.uiJob, eAssetMapCheckType.Cloth);
                temp.uiWeaponID = UIManager.GetInst().CheckResourc(temp.uiWeaponID, temp.uiJob, eAssetMapCheckType.Weapon);
                result2.Add(temp);
            }
            otherInfoList = result2;
            otherInfoList.Sort(delegate(CArenaBasicInfo info, CArenaBasicInfo basicInfo)
            {
                return info.uiNum.CompareTo(basicInfo.uiNum);
            });
            ArenaMediator arenaMediator = SingletonObject<ArenaMediator>.GetInst();
            if (arenaMediator.IsOpen)
            {
                arenaMediator.InitMain();
            }
        }
        else
        {
            ArenaResultManage(result.uiRst);
        }
    }


    /// <summary>
    /// 错误码处理
    /// </summary>
    /// <param name="result"></param>
    private void ArenaResultManage(uint result)
    {
        string mssageText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        PopFrameMediator popMssage = SingletonObject<PopFrameMediator>.GetInst();

        switch ((EnumChallegeErr)result)
        {
            case EnumChallegeErr.EnumChallegeErr_Fail:
                mssageText = Common.GetText(9941036);
                break;
            case EnumChallegeErr.EnumChallegeErr_NomoreTimes:

                mssageText = Common.GetText(9941031);
                break;
            case EnumChallegeErr.EnumChallegeErr_ParamErr:
                mssageText = Common.GetText(9941037);
                break;
            case EnumChallegeErr.EnumChallegeErr_NotEnoughGold:
                mssageText = Common.GetText(9100055);
                break;
            case EnumChallegeErr.EnumChallegeErr_NotEnoughDiamond:
                mssageText = Common.GetText(9100056);
                break;
            case EnumChallegeErr.EnumChallegeErr_LevelLimit:
                mssageText = Common.GetText(9941038);
                break;
            case EnumChallegeErr.EnumChallegeErr_CD:
                mssageText = Common.GetText(9941030);
                break;
            case EnumChallegeErr.EnumChallegeErr_NeedFresh:
                mssageText = Common.GetText(9941039);
                popMssage.SetCallBack(NeedFreshData);
                break;
            default:
                mssageText = "Error Code:" + (ushort)result;
                break;
        }
        popMssage.SetPopFrameTips(mssageText, frameType);
    }

    private void NeedFreshData()
    {
        SingletonObject<ArenaReadyMediator>.GetInst().Close();
    }



    #region 竞技场协议请求
    //请求竞技场的信息
    public void OnC2GRequestChallengeInfo(uint playerid)
    {
        if (playerid == 0) return;
        C2GRequestChallengeInfo c2GRequestChallengeInfo = new C2GRequestChallengeInfo();
        c2GRequestChallengeInfo.uiPlayerID = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.C2G_OPEN_ARENA, (ushort)ProCG.G2C_OPEN_ARENA_RESULT, c2GRequestChallengeInfo);
    }

    //请求挑战玩家
    public void OnC2GRequestChallenge(ulong accountid, uint selfpartnerid, ulong uiotheraccountid, ulong playerid, uint gsnum, uint rank, uint uiAttackID, uint uiDefenseID, string npcname = "")
    {
        C2GRequestChallenge c2GRequestChallenge = new C2GRequestChallenge();
        if (playerid == 1000)
        {
            //NPC
            c2GRequestChallenge.uiAccountID = accountid;//npc的情况下，account id 发战斗力数值
            c2GRequestChallenge.uiOtherAccountID = gsnum;
            c2GRequestChallenge.uiOtherPlayerID = playerid;
            c2GRequestChallenge.NPCName = npcname;
            c2GRequestChallenge.num = rank;
        }
        else
        {
            //真人
            c2GRequestChallenge.uiAccountID = accountid;
            c2GRequestChallenge.uiOtherAccountID = uiotheraccountid;
            c2GRequestChallenge.uiOtherPlayerID = playerid;
            c2GRequestChallenge.num = rank;
            c2GRequestChallenge.NPCName = "";//不穿空字符，底层会挂。。。
            c2GRequestChallenge.uiAttackCrystalId = uiAttackID;
            c2GRequestChallenge.uiDefenseCrystalId = uiDefenseID;

        }
        c2GRequestChallenge.uiPartnerID = selfpartnerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.C2G_REQUEST_CHALLENGE, (ushort)ProCG.G2C_REQUEST_CHALLENGE_RESULT, c2GRequestChallenge);
    }

    /*请求竞技场挑战结果
    /// <summary>
    /// 请求竞技场挑战结果
    /// </summary>
    /// <param name="accountid">被挑战玩家的账号id</param>
    /// <param name="playerid">被挑战玩家的playerid</param>
    /// <param name="rank">被挑战玩家的排名</param>
    /// <param name="issuc">失败 0 成功 1</param>
    public void OnC2GReportChallenge(ulong otheraccountid, ulong otherplayerid, ulong rank, byte issuc)
    {
        C2GReportChallenge c2gReportChallenge = new C2GReportChallenge();
        c2gReportChallenge.uiAccountID = otheraccountid;
        c2gReportChallenge.uiPlayerID = otherplayerid;
        c2gReportChallenge.uiNum = rank;
        c2gReportChallenge.uiIsSuc = issuc;
        SingletonObject<ArenaResultMediator>.GetInst().isVictory = c2gReportChallenge.uiIsSuc;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.C2G_REPORT_CHALLENGE, (ushort)ProCG.G2C_REPORT_CHALLENGE_RESULT, c2gReportChallenge);
    }
     */

    //清除CD时间请求
    public void OnC2GRequestClearCD(ulong accountid)
    {
        C2GRequestClearCD c2gRequestClearCD = new C2GRequestClearCD();
        c2gRequestClearCD.uiAccountID = accountid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.C2G_CLEAR_CHALLENGE_CD, (ushort)ProCG.G2C_ACK_CLEAR_CHALLENGE_CD, c2gRequestClearCD);
    }

    //请求竞技场增加挑战次数
    public void OnC2GAddArenaTimes()
    {
        C2GAddArenaTimes c2gAddArenaTimes = new C2GAddArenaTimes();
        c2gAddArenaTimes.uiNum += 1;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_ADD_ARENA_TIMES, (ushort)ProCG.GAME_ACK_ADD_ARENA_TIMES, c2gAddArenaTimes);
    }

    //请求竞技场日志信息
    public void OnC2GRequestArenaLog()
    {
        C2GRequestArenaLog c2gRequestArenaLog = new C2GRequestArenaLog();
        NullStruct nullStruct = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_ARENA_LOG, (ushort)ProCG.GAME_ACK_ARENA_LOG, nullStruct);
    }

    //请求竞技场排行榜信息(固定请求1-10名玩家数据)
    public void OnC2GRequestArenaRank()
    {
        C2GRequestArenaRank c2gRequestArenaRank = new C2GRequestArenaRank();
        c2gRequestArenaRank.uiStart = 1;
        c2gRequestArenaRank.uiEnd = 10;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_ARENA_RANK, (ushort)ProCG.GAME_ACK_ARENA_RANK, c2gRequestArenaRank);
    }

    //请求竞技场排行榜玩家属性
    public void OnC2GQueryRoleAttr(ulong playerid)
    {
        if (playerid == 0) return;
        C2GQueryRoleAttr c2gQueryRoleAttr = new C2GQueryRoleAttr();
        c2gQueryRoleAttr.uiOtherPlayerID = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_QUERY_ARENAATTRINFO, (ushort)ProCG.GAME_ACK_QUERY_ARENAATTRINFO, c2gQueryRoleAttr);
    }
    #endregion

    #region 2014年7月18日16:00:28新增PVPShop

    /// <summary>
    /// 打开PVP shop
    /// </summary>
    /// <param name="playerid"></param>
    public void OnC2GOpenPvpShop(ulong playerid)
    {
        if (playerid == 0)
        {
            MyLog.Log("playerid is zero! can not open pvp shop!");
            return;
        }
        C2GOpenPvpShop c2gOpenPvpShop = new C2GOpenPvpShop();
        c2gOpenPvpShop.uiPlayerid = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_OPEN_PVPSHOP, (ushort)ProCG.GAME_ACK_OPEN_PVPSHOP, c2gOpenPvpShop);
    }

    /// <summary>
    /// 打开PVP商店返回
    /// </summary>
    /// <param name="br"></param>
    private void onG2COpenPvpShopResult(BinaryReader br)
    {
        G2COpenPvpShopResult result = new G2COpenPvpShopResult();
        result.Read(br);
        ArenaPVPShopMediator pvpShopMediator = SingletonObject<ArenaPVPShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            int count = result.elements.Count;
            pvpShopMediator.IsAllowBuy = new bool[count];
            for (int i = 0; i < count; i++)
            {
                if (result.elements[i].uiItemNum == 0)
                {
                    pvpShopMediator.IsAllowBuy[i] = false;
                }
                else
                {
                    pvpShopMediator.IsAllowBuy[i] = true;
                }
            }
            //打开UI，初始变量数据，填充界面
            m_pvpShopList.Clear();
            m_pvpRefreshTimes = result.uiTimes;
            m_pvpShopList = result.elements;
            if (pvpShopMediator.IsOpen)
                pvpShopMediator.InitItem();
        }
        else
        {
            ArenaResultManage(result.uiResult);
        }
    }

    /// <summary>
    /// 刷新PVP商店货物请求
    /// </summary>
    /// <param name="playerid"></param>
    public void OnC2GRefreshPvpShop(ulong playerid)
    {
        if (playerid == 0)
        {
            MyLog.LogError("playerid is" + playerid);
            return;
        }
        C2GRefreshPvpShop c2gRefreshPvpShop = new C2GRefreshPvpShop();
        c2gRefreshPvpShop.uiPlayerid = playerid;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_REFRESH_PVPSHOP, (ushort)ProCG.GAME_ACK_REFRESH_PVPSHOP, c2gRefreshPvpShop);
    }

    /// <summary>
    /// 刷新PVP商店货物返回
    /// </summary>
    private void onG2CRefreshPvpShopResult(BinaryReader br)
    {
        G2CRefreshPvpShopResult result = new G2CRefreshPvpShopResult();
        result.Read(br);
        ArenaPVPShopMediator pvpShopMediator = SingletonObject<ArenaPVPShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            //刷新成功，//重置购买标示，重新填充界面
            m_pvpRefreshTimes = result.uiTimes;
            m_pvpShopList.Clear();
            m_pvpShopList = result.elements;
            int count = m_pvpShopList.Count;
            for (int i = 0; i < count; i++)
            {
                pvpShopMediator.IsAllowBuy[i] = true;
            }
            pvpShopMediator.ReSetPosition();
            pvpShopMediator.InitItem();
        }
        else
        {
            ArenaResultManage(result.uiResult);
        }
    }

    /// <summary>
    /// 购买竞技场pvp商店货物
    /// </summary>
    /// <param name="playerid">玩家自身ID</param>
    /// <param name="itemid">货物id</param>
    /// <param name="number">数量</param>
    public void OnC2GBuyPvpShop(ulong playerid, ushort index, uint itemid, uint number)
    {
        if (playerid == 0)
        {
            MyLog.LogError("playerid is" + playerid);
            return;
        }
        C2GBuyPvpShop c2gBuyPvpShop = new C2GBuyPvpShop();
        c2gBuyPvpShop.uiPlayerid = playerid;
        c2gBuyPvpShop.uiIndex = index;
        c2gBuyPvpShop.uiItemID = itemid;
        c2gBuyPvpShop.uiItemNum = number;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_BUY_PVPSHOP_ITEM, (ushort)ProCG.GAME_ACK_BUY_PVPSHOP_ITEM, c2gBuyPvpShop);
    }


    /// <summary>
    /// 购买PVP商店货物返回
    /// </summary>
    /// <param name="br"></param>
    private void onG2CBuyPvpShopResult(BinaryReader br)
    {
        G2CBuyPvpShopResult result = new G2CBuyPvpShopResult();
        result.Read(br);
        ArenaPVPShopMediator pvpShopMediator = SingletonObject<ArenaPVPShopMediator>.GetInst();
        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
        {
            //购买成功，刷新该item UI界面，变量重置，锁住用户，不让其购买
            string tips = Common.GetText(9949004);
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.green);
            m_pvpShopList.Clear();
            m_pvpShopList = result.elements;
            int count = m_pvpShopList.Count;
            for (int i = 0; i < count; i++)
            {
                if (result.elements[i].uiItemNum == 0)
                {
                    pvpShopMediator.IsAllowBuy[i] = false;
                }
                else
                {
                    pvpShopMediator.IsAllowBuy[i] = true;
                }
            }
            if (arenaBuyFinished != null)
                arenaBuyFinished();

        }
        else
        {
            ArenaResultManage(result.uiResult);
        }
    }
    #endregion

}
