﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;

public class clFriendInfo
{
    public ulong uiPhoneNum;            //对应好友的手机号码
    public ulong uiPlayerID;            //对应好友的角色ID
    public uint uiFightValue;           //对应玩家的战斗力
    public string scPlayerName;         //对应好友的名字
    public ushort uiLevel;              //对应好友的等级

    public List<CSkillupInfo> skillList;

    public uint uiClothesID;            //对应好友的衣服
    public uint uiWeaponID;             //对应好友的武器
    public byte todayGiveVigor;         //今日是否赠送体力
    public byte todayAssist;            //今日是否助战
    public string friendIcon;           //好友头像图标
    public ushort uiVipLevel;    //对应玩家的VIP等级
    public ushort uiIsInAdrlst;    //是否在通讯录，0：不是；1：是
    public CrystalItemInfo attackCrystal;//攻击龙晶
    public CrystalItemInfo defenseCrystal; //防御龙晶
}

public struct stFriendInfo
{
    public ulong uiPhoneNum;            //对应好友的手机号码
    public ulong uiPlayerID;            //对应好友的角色ID
    public uint uiFightValue;           //对应玩家的战斗力
    public string scPlayerName;         //对应好友的名字
    public ushort uiLevel;              //对应好友的等级

    public List<CSkillupInfo> skillList;

    public uint uiClothesID;            //对应好友的衣服
    public uint uiWeaponID;             //对应好友的武器
    public byte todayGiveVigor;         //今日是否赠送体力
    public byte todayAssist;            //今日是否助战
    public string friendIcon;           //好友头像图标
    public ushort uiVipLevel;    //对应玩家的VIP等级
    public ushort uiIsInAdrlst;    //是否在通讯录，0：不是；1：是
    public CrystalItemInfo attackCrystal;//攻击龙晶
    public CrystalItemInfo defenseCrystal; //防御龙晶

    public void SetValue(clFriendInfo info)
    {
        if (info != null)
        {
            uiPhoneNum = info.uiPhoneNum;
            uiPlayerID = info.uiPlayerID;
            uiFightValue = info.uiFightValue;
            scPlayerName = info.scPlayerName;
            uiLevel = info.uiLevel;
            skillList = new List<CSkillupInfo>();
            for (int i = 0, j = info.skillList.Count; i < j; i++)
            {
                CSkillupInfo skill = new CSkillupInfo(info.skillList[i].skillupLevel, info.skillList[i].skilluploader);
                skillList.Add(skill);
            }
            uiClothesID = info.uiClothesID;
            uiWeaponID = info.uiWeaponID;
            todayGiveVigor = info.todayGiveVigor;
            todayAssist = info.todayAssist;
            friendIcon = info.friendIcon;
            uiVipLevel = info.uiVipLevel;
            uiIsInAdrlst = info.uiIsInAdrlst;
            attackCrystal = info.attackCrystal;
            defenseCrystal = info.defenseCrystal;
        }
    }
}

public delegate void RequestCallBack();
public class FriendManager : SingletonObject<FriendManager> {

    private List<clFriendInfo> friendDataList = new List<clFriendInfo>();
    private List<clFriendInfo> addDataList = new List<clFriendInfo>();

    private List<stAndroidAddress> addressList = null;

    private stFriendInfo mFightFriend;

    private RequestCallBack mRequestAddressCallBack = null;
    private List<RequestCallBack> mRequestFriendCallBack = new List<RequestCallBack>();
    public List<PackItemInfo> inviteKeyItemList = new List<PackItemInfo>();             //邀请好友奖励
    public List<InviteRewardCell> friendInviteList = new List<InviteRewardCell>(); //邀请好友信息

    public string strMyInviteCode;    //我的邀请码
    public uint uiAleadyInviteCount;    //已经成功邀请的玩家的数目

    private ushort m_CurrentPage = 0;
    public ushort CurrentPage
    {
        get { return m_CurrentPage; }
        set { m_CurrentPage = value; }
    }
    private ushort m_TotalPage = 0;
    public ushort TotalPage
    {
        get { return m_TotalPage; }
    }

    public bool sentCode = false;                   //是否发送验证码标识
    public bool newFriendTip = false;                   //好友奖励标识


    private eFriendBindType friendBind = eFriendBindType.NotBindPhone;

    public eFriendBindType BindType
    {
        get 
        {
            if (SingletonObject<CPlayer>.GetInst().PhoneNumber > 0)
            {
                if (addressList == null)
                {
                    friendBind = eFriendBindType.NotAllow;
                }
                else if (addressList.Count == 0)
                {
                    friendBind = eFriendBindType.NotAllow;
                }
                else if (addressList.Count > 1)
                {
                    if (friendDataList.Count > 1)
                    {
                        friendBind = eFriendBindType.Succeed;
                    }
                    else
                    {
                        friendBind = eFriendBindType.Allow;
                    }
                }
                else
                {
                    friendBind = eFriendBindType.NotAllow;
                }
            }
            else
            {
                if (friendDataList.Count > 0)
                {
                    friendBind = eFriendBindType.NotBindInvite;
                }
                else
                {
                    friendBind = eFriendBindType.NotBindPhone;

                }
                
            }
            return friendBind;
        }
    }

    public stAndroidAddress GetAddressByPhone(ulong phone)
    {
        stAndroidAddress mStAndroidAddress = new stAndroidAddress();
        if (null != addressList)
        {
            for (int i = 0, j = addressList.Count; i < j; i++)
            {
                if (addressList[i].number == phone.ToString())
                {
                    mStAndroidAddress = addressList[i];
                    break;
                }
            }
        }
        return mStAndroidAddress;
    }

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_QUERY_FRIEND_INFO_RESULT, ResultFriendInfo,true);//服务器返回好友信息
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_GIVE_FRIEND_VIGOR_RESULT, ResultGivePower,true);//服务器返回赠送体力结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_AUTH_CODE_RESULT, ResultSendPhone,true);//服务器返回发送绑定手机号结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CONFIRM_AUTH_CODE,ResultSendCode,true);//服务器返回发送验证码结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_UPLOADING_ADDRESS_LIST, ResultSendAddress,true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_INPUT_CODE, ResultInviteKey, true);//服务端回应输入邀请码
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_INVITE_BOARD_INFO, ResultInviteFriendInfo, true);//服务端回应请求邀请界面信息
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_GET_INVITE_REWARD, ResultInviteFriendReward, true);//服务端回应请求邀请界面信息

        
    }

    private void ResultFriendInfo(BinaryReader br)//返回好友信息
    {
        G2CAckQueryFriendInfo msg = new G2CAckQueryFriendInfo();
        msg.Read(br);
        EnumQueryFriendResult result = (EnumQueryFriendResult)msg.uiResult;
        if (result == EnumQueryFriendResult.EnumQueryFriendResult_Success)
        {
            addDataList.Clear();
            friendDataList.Clear();
            for (int i = 0, j = msg.sAvatarList.Count; i < j; i++)
            {
                clFriendInfo data = new clFriendInfo();
                data.uiPhoneNum = msg.sAvatarList[i].uiPhoneNum;
                data.uiPlayerID = msg.sAvatarList[i].uiPlayerID;
                data.uiFightValue = msg.sAvatarList[i].uiFightValue;
                data.scPlayerName = msg.sAvatarList[i].scPlayerName;
                data.uiLevel = msg.sAvatarList[i].uiLevel;
                data.uiVipLevel = msg.sAvatarList[i].uiVipLevel;
                data.uiIsInAdrlst = msg.sAvatarList[i].uiIsInAdrlst;
                data.skillList = new List<CSkillupInfo>();
                data.attackCrystal = new CrystalItemInfo(msg.sAvatarList[i].attackCrystal);
                data.defenseCrystal = new CrystalItemInfo(msg.sAvatarList[i].defenseCrystal);

                SkillBriefList briefList = msg.sAvatarList[i].lSkillList;
                for (int index = 0; index < briefList.Count; index++)
                {
                    uint loaderKey = briefList[index].uiSkillId;
                    SkillUpContent skillupLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(loaderKey);
                    if (null == skillupLoader)
                        continue;

                    CSkillupInfo skillInfo = new CSkillupInfo((ushort)briefList[index].uiSkillLevel, skillupLoader);
                    data.skillList.Add(skillInfo);
                }

                if (msg.sAvatarList[i].uiArmorID == 0)
                {
                    MyLog.LogError("SetPhoneFriendList error,msg.sAvatarList[i].uiArmorID == 0,accountid:" + msg.sAvatarList[i].uiPlayerID);
                    continue;
                }

                data.uiClothesID = (uint)(31200000 + (uint)(msg.sAvatarList[i].uiPlayerID % 10) * 10000 + msg.sAvatarList[i].uiArmorID * 100 + 1);
                data.uiWeaponID = (uint)(31100000 + (uint)(msg.sAvatarList[i].uiPlayerID % 10) * 10000 + msg.sAvatarList[i].uiWeaponID * 100 + 1);
                data.todayGiveVigor = msg.sAvatarList[i].todayGiveVigor;
                data.todayAssist = msg.sAvatarList[i].todayAssist;
                uint jobid = (uint)(11000000u + data.uiPlayerID % 10u);
                switch (jobid)
                {
                    case DEFINE.JOB_ID_CHIKE:
                        data.friendIcon = "cike";
                        break;
                    case DEFINE.JOB_ID_KUANGZHANSHI:
                        data.friendIcon = "kuangzhanshi";
                        break;
                    case DEFINE.JOB_ID_SHENGWUSHI:
                        data.friendIcon = "shengwushi";
                        break;
                    case DEFINE.JOB_ID_FASHI:
                        data.friendIcon = "fashi";
                        break;
                    default:
                        {
                            data.friendIcon = "none";
                            MyLog.LogError("Error: have no this job id");
                        }
                        break;
                }
                addDataList.Add(data);
            }

            friendDataList.AddRange(addDataList);
            m_TotalPage = msg.uiTotal;
            m_CurrentPage = msg.uiCurrent;
            if (null != mRequestFriendCallBack)
            {
                for (int i = 0, j = mRequestFriendCallBack.Count; i < j; i++)
                {
                    mRequestFriendCallBack[i]();
                }
                mRequestFriendCallBack.Clear();
            }
        }
        else
        {
            switch (result)
            {
                case EnumQueryFriendResult.EnumQueryFriendResult_TooOften:   
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938039));
                    }
                    break;
                case EnumQueryFriendResult.EnumQueryFriendResult_Sending: 
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938040));
                    }
                    break;
                case EnumQueryFriendResult.EnumQueryFriendResult_Finish :    
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938041));
                    }
                    break;
                case EnumQueryFriendResult.EnumQueryFriendResult_NoFriend :   
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938042));
                    }
                    break;
                case EnumQueryFriendResult.EnumQueryFriendResult_NotBind :   
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938043));
                    }
                    break;
                case EnumQueryFriendResult.EnumQueryFriendResult_FriendServerError :   
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938044));
                    }
                    break;
                    default:
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("the friend error "+result);//"error"
                    }
                    break;
            }
        }
    }

    private void ResultGivePower(BinaryReader br)//返回赠送体力结果
    {
        G2CGiveFriendVigorResult msg = new G2CGiveFriendVigorResult();
        msg.Read(br);
        switch (msg.uiResult)
        {
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_Success:
                {
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9938033), new Color(0, 1f, 0));
                    SingletonObject<FriendWindowMediator>.GetInst().GiveTiliResult();
                }
                break;
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_Fail:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100126));
                }
                break;
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_NotFriend:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100127));
                }
                break;
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_InCDTime:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100128));
                }
                break;
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_IsSelf:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100129));
                }
                break;
            case (ushort)EnumGiveVigorResult.EnumGiveVigorResult_FriendServerError:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938044));
                }
                break;
        }
    }

    private void ResultSendPhone(BinaryReader br)
    {
        G2CAuthCodeResult msg = new G2CAuthCodeResult();
        msg.Read(br);
        switch(msg.uiResult)
        {
            case (ushort)EnumAuthCode.EnumAuthCode_Invalid:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938030));
                }
                break;
            case (ushort)EnumAuthCode.EnumAuthCode_Success:
                {
                    //SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100120) + ": " + msg.uiAuthCode.ToString());//你的验证码是
                    sentCode = true;
                    SingletonObject<FriendWindowMediator>.GetInst().SetCountDown(60);

                    SingletonObject<FriendWindowMediator>.GetInst().UpdateSendCode();
                }
                break;
        }
    }

    private void ResultSendCode(BinaryReader br)
    {
        G2CConfirmAuthCodeResult msg = new G2CConfirmAuthCodeResult();
        msg.Read(br);
        //MyLog.LogError("........ResultSendCode......................." + msg.uiResult);
        switch(msg.uiResult)
        {
            case (ushort)EnumConfirmAuthCode.EnumConfirmAuthCode_Success:
                {
                    friendDataList.Clear();
                    addDataList.Clear();
                    m_CurrentPage = 0;
                    m_TotalPage = 0;

                    if (addressList == null)
                    {
                        ExternalInterface.GetInst().GetAddressList();
                    }
                    //SendAddressBook();
                    FriendManager mFriendManager = SingletonObject<FriendManager>.GetInst();
                    mFriendManager.CurrentPage = 0;
                    mFriendManager.FirstPage(SingletonObject<FriendWindowMediator>.GetInst().updataFriendInfo, 1);
                    SingletonObject<FriendWindowMediator>.GetInst().Refresh();
                }
                break;
            case (ushort)EnumConfirmAuthCode.EnumConfirmAuthCode_Error:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938031));
                }
                break;
            case (ushort)EnumConfirmAuthCode.EnumConfirmAuthCode_Timeout:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938032));
                }
                break;
        }
    }

    private void ResultSendAddress(BinaryReader br)
    {
        G2CUploadingAdrlstResult msg = new G2CUploadingAdrlstResult();
        msg.Read(br);
        switch(msg.uiResult)
        {
            case (ushort)EnumUploading.EnumUploading_Empty:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9905009));
                }
                break;
            case (ushort)EnumUploading.EnumUploading_NotBind:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100122));
                }
                break;
            case (ushort)EnumUploading.EnumUploading_Success:
                {
                    
                    if (null != addressList)
                    {
                        List<string> mAddress = new List<string>();
                        for (int i = 0, j = addressList.Count; i < j; i++)
                        {
                            mAddress.Add(addressList[i].number);
                        }
                        LocalConfig.DeleteConfig( Common.GetKey("addressInfo.txt"));
                        LocalConfig.SaveConfig( Common.GetKey("addressInfo.txt"), mAddress);
                    }
                    SingletonObject<FriendWindowMediator>.GetInst().updataFriendInfo() ;
                }
                break;
        }
    }

    private void ResultInviteKey(BinaryReader br)
    {
        G2CAckInviteInputCode msg = new G2CAckInviteInputCode();
        msg.Read(br);
        if ((EnumProtocolResult)msg.uiResult == EnumProtocolResult.EnumProtocolResult_Success)
        {
            SingletonObject<InviteKeyMediator>.GetInst().SetSucceed();
        }
        else
        {
            ErrorControl((EnumProtocolResult)msg.uiResult);
        }
    }

    private void ResultInviteFriendInfo(BinaryReader br)
    {
        G2CGetInviteBoardInfo msg = new G2CGetInviteBoardInfo();
        msg.Read(br);
        friendInviteList = msg.vRewardCellList;
        strMyInviteCode = msg.strMyInviteCode;
        uiAleadyInviteCount = msg.uiAleadyInviteCount;
        if ((EnumProtocolResult)msg.uiResult == EnumProtocolResult.EnumProtocolResult_Success)
        {
            SingletonObject<InviteFriendMediator>.GetInst().UpdateInviteInfo();
        }
        else
        {
            ErrorControl((EnumProtocolResult)msg.uiResult);
        }
    }

    private void ResultInviteFriendReward(BinaryReader br)
    {
        G2CGetInviteReward msg = new G2CGetInviteReward();
        msg.Read(br);
        if ((EnumProtocolResult)msg.uiResult == EnumProtocolResult.EnumProtocolResult_Success)
        {
            RequestInviteFriendInfo();
            List<HUDAwardItem> dict = new List<HUDAwardItem>();
            foreach (PackItemInfo packItemInfo in msg.vRewardItemList)
            {
                HUDAwardItem item = new HUDAwardItem();
                item.id = packItemInfo.uiItemId;
                item.number = packItemInfo.uiItemNum;
                dict.Add(item);
            }
            SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);

        }
        else
        {
            ErrorControl((EnumProtocolResult)msg.uiResult);
        }
    }

    private void RequestFriendInfo(byte isAssisted, ushort page = 1)
    {
        C2GReqFriendInfo msg = new C2GReqFriendInfo();
        msg.uiPageNum = page;
        msg.isShowAssisted = isAssisted;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_QUERY_FRIEND_INFO, (ushort)ProCG.GAME_ACK_CLIENT_QUERY_FRIEND_INFO_RESULT, msg);
    }

    public void RequestGivePower(ulong PhoneNum, ulong uiPlayerID)//请求赠送体力
    {
        C2GGiveFriendVigor msg = new C2GGiveFriendVigor();
        msg.uiFriendPhone = PhoneNum;
        msg.uiPlayerID = uiPlayerID;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_GIVE_FRIEND_VIGOR, (ushort)ProCG.GAME_ACK_CLIENT_GIVE_FRIEND_VIGOR_RESULT, msg);
    }

    public void SendPhoneNumber(string phone)
    {
        C2GReqAuthCode msg = new C2GReqAuthCode();
        msg.szPhone = phone;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_BIND_PHONE_AUTH_CODE, (ushort)ProCG.GAME_ACK_CLIENT_AUTH_CODE_RESULT, msg);
    }

    public void SendVerficationCode(uint code)
    {
        C2GConfirmAuthCode msg = new C2GConfirmAuthCode();
        msg.uiAuthCode = code;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_CONFIRM_AUTH_CODE, (ushort)ProCG.GAME_ACK_CONFIRM_AUTH_CODE, msg);

    }

    public void SendAddressBook()
    {
        if (null == addressList && SingletonObject<FriendWindowMediator>.GetInst().IsOpen)
        {
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100123));
            return;
        }
        else if (addressList.Count == 0 && SingletonObject<FriendWindowMediator>.GetInst().IsOpen)
        {
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9905009));
            return;
        }
        if (null == addressList)
        {
            MyLog.LogError("can't get address book date");
            return;
        }
        else if (addressList.Count == 0 )
        {
            MyLog.LogError("the address book date is empty");

            return;
        }
        ArrayList mAddress = LocalConfig.LoadConfig( Common.GetKey("addressInfo.txt"));
        C2GUploadingAdrlst msg = new C2GUploadingAdrlst();
        AddressBookList addressBookList = new AddressBookList();
        AddressBookInfo info = null;
        for (int i = 0, j = addressList.Count; i < j; i++)
        {
            if (null != mAddress && mAddress.Contains(addressList[i].number))
            {
                continue;
            }
            else
            {
                info = new AddressBookInfo();
                UInt64 value = 0;
                UInt64.TryParse(addressList[i].number, out value);
                info.uiPhoneNumber = value; //ulong.Parse(addressList[i].number);
                info.szName = addressList[i].name;
                addressBookList.Add(info);
            }
        }
        if (addressBookList.Count > 0)
        {
            msg.infoList = addressBookList;
            NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_UPLOADING_ADDRESS_LIST, (ushort)ProCG.GAME_ACK_UPLOADING_ADDRESS_LIST, msg);
        }
    }

    public void RequestAddressList(RequestCallBack mCallBack)//获得手机通讯录
    {
        mRequestAddressCallBack = mCallBack;
        ExternalInterface.GetInst().GetAddressList();
#if UNITY_EDITOR
        mRequestAddressCallBack();
        mRequestAddressCallBack = null;
#endif
    }

    //客户端请求输入邀请码
    public void RequestInviteKey(string key)
    {
        C2GReqInviteInputCode msg = new C2GReqInviteInputCode();
        msg.strCode = key;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLEINT_REQUEST_INPUT_CODE, (ushort)ProCG.GAME_ACK_INPUT_CODE, msg);
    }
    //客户端请求邀请界面信息,无结构
    public void RequestInviteFriendInfo()
    {
        NullStruct msg = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLEINT_REQUEST_INVITE_BOARD_INFO, (ushort)ProCG.GAME_ACK_INVITE_BOARD_INFO, msg);
   
    }
    //客户端请求获取邀请奖励
    public void RequestInviteReward(ushort uiRewardType)
    {
        C2GGetInviteReward msg = new C2GGetInviteReward();
        msg.uiRewardType = uiRewardType;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLEINT_REQUEST_GET_INVITE_REWARD, (ushort)ProCG.GAME_ACK_GET_INVITE_REWARD, msg);

    }
    public void SetAddressList(List<stAndroidAddress> list)//安卓返回手机通讯录
    {
        //MyLog.LogError("...........SetAddressList.........Android back..安卓返回手机通讯录...........");
        addressList = new List<stAndroidAddress>();
        List<string> mNumList = new List<string>();
        string myNumber = SingletonObject<CPlayer>.GetInst().PhoneNumber.ToString();
        for (int i = 0, j = list.Count; i < j; i++)
        {
            stAndroidAddress mStAndroidAddress = list[i];
            mStAndroidAddress.number = mStAndroidAddress.number.Replace(" ", "");
            mStAndroidAddress.number = mStAndroidAddress.number.Replace("-", "");
            if (string.IsNullOrEmpty(mStAndroidAddress.number))
            {
                continue;
            }
            //if (!System.Text.RegularExpressions.Regex.IsMatch(mStAndroidAddress.number, @"^[1]+[3,4,5,8]+\d{9}"))
            //{
            //    continue;
            //}
            if (!mStAndroidAddress.number.StartsWith("1") || mStAndroidAddress.number.Length != 11)
            {
                continue;
            }
            if (mNumList.Contains(mStAndroidAddress.number))
            {
                continue;
            }
            if (mStAndroidAddress.number == myNumber)
            {
                continue;
            }
            mNumList.Add(mStAndroidAddress.number);
            addressList.Add(mStAndroidAddress);
        }
        if (null != mRequestAddressCallBack)
        {
            //MyLog.LogError("........Android back...mRequestAddressCallBack..........");
            mRequestAddressCallBack();
            mRequestAddressCallBack = null;
        }
        else
        {
            //MyLog.LogError("........Android back...mRequestAddressCallBack....null......");

        }
        SendAddressBook();
        SingletonObject<FriendWindowMediator>.GetInst().UpdatePanelInfo();

    }

    public void ErrorControl(EnumProtocolResult result)
    {
        string mssageText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        PopFrameMediator popMssage = SingletonObject<PopFrameMediator>.GetInst();
        switch (result)
        {
            case EnumProtocolResult.EnumProtocolResult_InputCodeLevelNotEnough://10级之后才可以输入邀请码
                mssageText = Common.GetText(9938080);
                break;
            case EnumProtocolResult.EnumProtocolResult_InputCodeLevelTooHigh://该账号下存在超过50级的角色，不能输入邀请码
                mssageText = Common.GetText(9938081);
                break;
            case EnumProtocolResult.EnumProtocolResult_FriendsServerNoConnected://好友服务器没连接成功
                mssageText = Common.GetText(9938082);
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteCanNotInviteSelf://好友服务器没连接成功
                mssageText = Common.GetText(9938083);
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteTargetServerDown://对方服务器处于维护状态
                mssageText = Common.GetText(9938084);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(mssageText, Color.red);
                return;
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteCodeInvalid://验证码非法
                mssageText = Common.GetText(9938085);
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteUnKnow://未知错误
                mssageText = Common.GetText(9938086);
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteAlreadyFriend://对方玩家已经是你的好友
                mssageText = Common.GetText(9938088);
                break;
            case EnumProtocolResult.EnumProtocolResult_InviteRewardAlreadyGet://该奖励已经领取
                mssageText = Common.GetText(9938089);
                RequestInviteFriendInfo();
                break;
                
            default:
                mssageText = " invite key error result "+result;

                break;
        }
        popMssage.SetPopFrameTips(mssageText, frameType);

    }

    public List<clFriendInfo> GetFriendData()
    {
        return friendDataList;
    }

    public List<clFriendInfo> GetAddData()
    {
        return addDataList;
    }

    public List<stAndroidAddress> GetAddressData()
    {
        return addressList;
    }

    public void ResetFightFriend()
    {
        if (mFightFriend.uiPlayerID != 0)
        {
            for (int i = 0, j = friendDataList.Count; i < j; i++)
            {
                if (friendDataList[i].uiPlayerID == mFightFriend.uiPlayerID)
                {
                    friendDataList[i].todayAssist = 1;
                    break;
                }
            }
        }
    }

    /// <summary>
    /// 第一页
    /// </summary>
    /// <param name="callBack">回调</param>
    /// <param name="showAssisted">是否包含已经助战过的好友</param>
    public void FirstPage(RequestCallBack callBack, byte showAssisted)
    {
        if (m_CurrentPage > 0)
        {
            callBack();
        }
        else
        {
            mRequestFriendCallBack.Add(callBack);
            RequestFriendInfo(showAssisted);
        }
    }

    /// <summary>
    /// 下一页
    /// </summary>
    /// <param name="callBack">回调</param>
    /// <param name="showAssisted">是否包含已经助战过的好友</param>
    public void NextPage(RequestCallBack callBack, byte showAssisted)
    {
        if (m_TotalPage > m_CurrentPage)
        {
            mRequestFriendCallBack.Add(callBack);
            RequestFriendInfo(showAssisted, (ushort)(m_CurrentPage + 1));
        }
    }

    /// <summary>
    /// 上一页
    /// </summary>
    /// <param name="callBack">回调</param>
    /// <param name="showAssisted">是否包含已经助战过的好友</param>
    public void LastPage(RequestCallBack callBack, byte showAssisted)
    {
        if (m_CurrentPage > 1)
        {
            mRequestFriendCallBack.Add(callBack);
            RequestFriendInfo(showAssisted, (ushort)(m_CurrentPage - 1));
        }
    }

    public void SetFightFriend(stFriendInfo info)
    {
        mFightFriend = info;
    }

    public stFriendInfo GetFightFriend()//获得当前的助战好友，有可能是0的
    {
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.FriendFight);
        if (mode != eOpenMode.Acquiesce) ResetInitFightFriend();
        if (mFightFriend.uiPlayerID != 0)
        {
            for (int i = 0, j = friendDataList.Count; i < j; i++)
            {
                if (friendDataList[i] != null && friendDataList[i].uiPlayerID == mFightFriend.uiPlayerID)
                {
                    mFightFriend.todayAssist = friendDataList[i].todayAssist;
                }
            }
        }
        return mFightFriend;
    }

    public void ResetInitFightFriend()
    {
        mFightFriend.scPlayerName = "";
        mFightFriend.todayAssist = 0;
        mFightFriend.todayGiveVigor = 0;
        mFightFriend.uiClothesID = 0;
        mFightFriend.uiFightValue = 0;
        mFightFriend.uiLevel = 0;
        mFightFriend.uiPhoneNum = 0;
        mFightFriend.uiPlayerID = 0;
        if (null != mFightFriend.skillList)
        {
            mFightFriend.skillList.Clear();
        }
        mFightFriend.uiWeaponID = 0;
    }
}

public enum eFriendBindType
{
    NotBindPhone,           //手机未绑定
    NotAllow,               //手机绑定未允许访问通讯录
    Allow,                  //手机绑定允许访问通讯录
    Succeed,                //绑定完成，访问完成，邀请完成
    NotBindInvite,          //手机未绑定,已邀请
}