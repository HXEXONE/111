﻿//using Network;
//using Protocol;
//using UnityEngine;
//using System.Collections;
//using System.IO;
//using System.Collections.Generic;

//public class ClimbTowerManager : SingletonObject<ClimbTowerManager>
//{
//    public Dictionary<uint, TowerInfo> m_dicAllServerRank = new Dictionary<uint, TowerInfo>();
//    public List<TowerInfo> AllServerRankList = new List<TowerInfo>();//单服排行榜
//    public List<TowerInfo> FriendRankList = new List<TowerInfo>();//好友排行榜
//    public int SelfRankInAllServer = 0;//玩家自己在全服的排名
//    public int SelfTowerLayer = 0;//玩家自己层数
//    private bool m_bIsDrag = false;
//    private bool m_bIsDrag2 = false;

//    public delegate void ShopBuyFinished();

//    public ShopBuyFinished towerBuyFinished;
//    #region Shop新增字段

//    private List<ShopElement> m_pvpShopList = new List<ShopElement>();
//    public List<ShopElement> pvpShopList { get { return m_pvpShopList; } set { m_pvpShopList = value; } }
//    private int m_pvpRefreshTimes = 1;//刷新次数
//    public int pvpRefreshTimes { get { return m_pvpRefreshTimes; } set { m_pvpRefreshTimes = value; } }
//    #endregion


//    public void RegisteMessages(NetworkClient pClient)
//    {
//        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_QUERY_TOWERRANK, onG2CQueryTowerRank,true);//全服排行
//        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_QUERY_FRIEND_TOWERRANK, onG2CQueryFriendTowerRank,true);//好友排行

//        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_OPEN_TOWERSHOP, onG2COpenTowerShopResult,true);//打开爬塔商店返回
//        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_REFRESH_TOWERSHOP, onG2CRefreshTowerShopResult,true);//爬塔刷新商店货物
//        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_BUY_TOWERSHOP_ITEM, onG2CBuyTowerShopResult,true);//竞技场购买PVP商店货物
//    }

//    //全服排行返回
//    private void onG2CQueryTowerRank(BinaryReader br)
//    {
//        G2CQueryTowerRank result = new G2CQueryTowerRank();
//        result.Read(br);
//        ClimbTowerMediator towerMediator =SingletonObject<ClimbTowerMediator>.GetInst();
//        if (result.uiResult == (ushort)EnumTowerErr.EnumTowerErr_Suc)
//        {
//            towerMediator.isAllowGetRank = true;
//            towerMediator.m_pageIndex += 1;
//            if (AllServerRankList != null)
//            {
//                if (result.infoList.Count == 0)
//                    return;
//                for (int i = 0, count = result.infoList.Count; i < count; i++)
//                {
//                    if (!m_dicAllServerRank.ContainsKey(result.infoList[i].uiRank))
//                    {
//                        m_dicAllServerRank.Add(result.infoList[i].uiRank, result.infoList[i]);
//                    }
//                }
//            }
//            SelfRankInAllServer = (int)result.uiNum;
//            SelfTowerLayer = (int)result.uiTower;
//            AllServerRankList.Sort(RankComparison);
//            AllServerRankList = new List<TowerInfo>(m_dicAllServerRank.Values);

//            ///非拖拽，直接打開時獲取數據
//            if (!m_bIsDrag)
//            {
//                //加载后刷新数据排行榜
//                towerMediator.LoadData(AllServerRankList);
//            }
//            else
//            {
//                //刷新List。
//                towerMediator.scrollViewRank.UpdateCache(AllServerRankList);
//            }
//        }
//        else if (result.uiResult == (ushort)EnumTowerErr.EnumTowerErr_Fail)
//        {
//            MyLog.Log("there is no enough data in server...");
//            towerMediator.LoadData(AllServerRankList);
//            //AllServerRankList = new List<TowerInfo>();
//            //SingletonObject<ClimbTowerMediator>.GetInst().LoadFriendRank(AllServerRankList);
//        }
//        else
//        {
//            MyLog.LogError("Unknow Error" + result.uiResult);
//        }
//    }

//    //好友爬塔排行返回。
//    private void onG2CQueryFriendTowerRank(BinaryReader br)
//    {
//        G2CQueryFriendTowerRank result = new G2CQueryFriendTowerRank();
//        result.Read(br);
//        if (result.uiResult == (ushort)EnumTowerErr.EnumTowerErr_Suc)
//        {
//            ClimbTowerMediator towerMediator = SingletonObject<ClimbTowerMediator>.GetInst();
//            towerMediator.m_pageIndex += 1;
//            FriendRankList = new List<TowerInfo>(result.infoList);//好友排行榜，服务端一次性发完所有
//            //SelfRankInAllServer = (int)result.uiNum;
//            //SelfTowerLayer = (int)result.uiTower;
//            FriendRankList.Sort(RankComparison);
//            if (!m_bIsDrag2)
//            {
//                towerMediator.LoadFriendRank(FriendRankList);
//            }
//            else
//            {
//                towerMediator.scrollViewRank.UpdateCache(FriendRankList);
//            }
//        }
//        else if (result.uiResult == (ushort)EnumTowerErr.EnumTowerErr_Fail)
//        {
//            //排行榜为空
//            FriendRankList = new List<TowerInfo>();
//            SingletonObject<ClimbTowerMediator>.GetInst().LoadFriendRank(FriendRankList);
//        }
//        else
//        {
//            MyLog.LogError("Unknow Error" + result.uiResult);
//        }
//    }

//    //顺序排名比较器
//    private int RankComparison(TowerInfo x, TowerInfo y)
//    {
//        if (x.uiNum == null && y.uiNum == null) return 0;
//        else if (x.uiNum == null) return 1;
//        else if (y.uiNum == null) return -1;
//        else
//        {
//            return y.uiNum.CompareTo(x.uiNum);
//        }
//    }

//    //请求全服排行榜
//    public void OnC2GQueryTowerRank(ushort startindex, ushort endindex,bool bisFirst = true)
//    {
//        m_bIsDrag = !bisFirst;
//        C2GQueryTowerRank c2gQueryTowerRank = new C2GQueryTowerRank();
//        c2gQueryTowerRank.uiStart = startindex;
//        c2gQueryTowerRank.uiEnd = endindex;
//        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_QUERY_TOWERRANK, (ushort)ProCG.GAME_ACK_QUERY_TOWERRANK, c2gQueryTowerRank);
//    }

//    //请求好友排行榜
//    public void OnC2GQueryFriendTowerRank(ushort startindex, ushort endindex,bool bisFirst =true)
//    {
//        m_bIsDrag2 = !bisFirst;
//        C2GQueryFriendTowerRank c2gQueryFriendTowerRank = new C2GQueryFriendTowerRank();
//        c2gQueryFriendTowerRank.uiStart = startindex;
//        c2gQueryFriendTowerRank.uiEnd = endindex;
//        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_QUERY_FRIEND_TOWERRANK, (ushort)ProCG.GAME_ACK_QUERY_FRIEND_TOWERRANK, c2gQueryFriendTowerRank);
//    }


//    #region 2014年7月29日20:19:58新增爬塔Shop

//    /// <summary>
//    /// 打开 shop
//    /// </summary>
//    /// <param name="playerid"></param>
//    public void OnC2GOpenTowerShop(ulong playerid)
//    {
//        if (playerid == 0)
//        {
//            MyLog.Log("playerid is zero! can not open pvp shop!");
//            return;
//        }
//        C2GOpenTowerShop c2gOpenTowerShop = new C2GOpenTowerShop();
//        c2gOpenTowerShop.uiPlayerid = playerid;
//        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_OPEN_TOWERSHOP, (ushort)ProCG.GAME_ACK_OPEN_TOWERSHOP, c2gOpenTowerShop);
//    }

//    /// <summary>
//    /// 打开PVP商店返回
//    /// </summary>
//    /// <param name="br"></param>
//    private void onG2COpenTowerShopResult(BinaryReader br)
//    {
//        G2COpenTowerShopResult result = new G2COpenTowerShopResult();
//        result.Read(br);
//        ClimbTowerShopMediator pvpShopMediator = SingletonObject<ClimbTowerShopMediator>.GetInst();
//        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
//        {
//            int count = result.elements.Count;
//            pvpShopMediator.isAllowBuy = new bool[count];
//            for (int i = 0; i < count; i++)
//            {
//                if (result.elements[i].uiItemNum == 0)
//                {
//                    pvpShopMediator.isAllowBuy[i] = false;
//                }
//                else
//                {
//                    pvpShopMediator.isAllowBuy[i] = true;
//                }
//            }
//            //打开UI，初始变量数据，填充界面
//            m_pvpShopList.Clear();
//            m_pvpRefreshTimes = result.uiTimes;
//            m_pvpShopList = result.elements;
//            if (pvpShopMediator.IsOpen)
//            {
//                pvpShopMediator.InitItem();
//            }
//        }
//        else
//        {
//            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("ErrorCode:" + result.uiResult.ToString());
//        }
//    }

//    /// <summary>
//    /// 刷新PVP商店货物请求
//    /// </summary>
//    /// <param name="playerid"></param>
//    public void OnC2GRefreshTowerShop(ulong playerid)
//    {
//        if (playerid == 0)
//        {
//            MyLog.LogError("playerid is" + playerid);
//            return;
//        }
//        C2GRefreshTowerShop c2gRefreshTowerShop = new C2GRefreshTowerShop();
//        c2gRefreshTowerShop.uiPlayerid = playerid;
//        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_REFRESH_TOWERSHOP, (ushort)ProCG.GAME_ACK_REFRESH_TOWERSHOP, c2gRefreshTowerShop);
//    }

//    /// <summary>
//    /// 刷新PVP商店货物返回
//    /// </summary>
//    private void onG2CRefreshTowerShopResult(BinaryReader br)
//    {
//        G2CRefreshPvpShopResult result = new G2CRefreshPvpShopResult();
//        result.Read(br);
//        ClimbTowerShopMediator pvpShopMediator = SingletonObject<ClimbTowerShopMediator>.GetInst();
//        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
//        {
//            //刷新成功，//重置购买标示，重新填充界面
//            m_pvpRefreshTimes = result.uiTimes;
//            m_pvpShopList.Clear();
//            m_pvpShopList = result.elements;
//            int count = m_pvpShopList.Count;
//            for (int i = 0; i < count; i++)
//            {
//                pvpShopMediator.isAllowBuy[i] = true;
//            }
//            pvpShopMediator.ReSetPosition();
//            pvpShopMediator.InitItem();
//        }
//        else
//        {
//            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("ErrorCode:" + result.uiResult.ToString());
//        }
//    }

//    /// <summary>
//    /// 购买竞技场pvp商店货物
//    /// </summary>
//    /// <param name="playerid">玩家自身ID</param>
//    /// <param name="itemid">货物id</param>
//    /// <param name="number">数量</param>
//    public void OnC2GBuyTowerShop(ulong playerid, ushort index, uint itemid, uint number)
//    {
//        if (playerid == 0)
//        {
//            MyLog.LogError("playerid is" + playerid);
//            return;
//        }
//        C2GBuyTowerShop c2gBuyTowerShop = new C2GBuyTowerShop();
//        c2gBuyTowerShop.uiPlayerid = playerid;
//        c2gBuyTowerShop.uiIndex = index;
//        c2gBuyTowerShop.uiItemID = itemid;
//        c2gBuyTowerShop.uiItemNum = number;
//        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_BUY_TOWERSHOP_ITEM, (ushort)ProCG.GAME_ACK_BUY_TOWERSHOP_ITEM, c2gBuyTowerShop);
//    }


//    /// <summary>
//    /// 购买商店货物返回
//    /// </summary>
//    /// <param name="br"></param>
//    private void onG2CBuyTowerShopResult(BinaryReader br)
//    {
//        G2CBuyTowerShopResult result = new G2CBuyTowerShopResult();
//        result.Read(br);
//        ClimbTowerShopMediator pvpShopMediator = SingletonObject<ClimbTowerShopMediator>.GetInst();
//        if (result.uiResult == (ushort)EnumPvpShopErr.EnumPvpShopErr_Success)
//        {
//            //购买成功，刷新该item UI界面，变量重置，锁住用户，不让其购买
//            string tips = Common.GetText(9949004);
//            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.green);
//            m_pvpShopList.Clear();
//            m_pvpShopList = result.elements;
//            int count = m_pvpShopList.Count;
//            for (int i = 0; i < count; i++)
//            {
//                if (result.elements[i].uiItemNum == 0)
//                {
//                    pvpShopMediator.isAllowBuy[i] = false;
//                }
//                else
//                {
//                    pvpShopMediator.isAllowBuy[i] = true;
//                }
//            }
//            if (towerBuyFinished != null)
//                towerBuyFinished();
//        }
//        else
//        {
//            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("ErrorCode:" + result.uiResult.ToString());
//        }
//    }
//    #endregion
//}