using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//using System.IO;
//using System.Text;


public class CClientInitLoading : CLoadingCommon
{
    public void StartLoading()
    {
        CLoadingManager.GetInst().StartAddUrl(this, 5, true);
    }

    public void EndLoading()
    {
        CLoadingManager.GetInst().EndAddUrl();
    }

    public override float GetProgress()
    {
        float progress = base.GetProgress();

        return progress * 0.6f;
    }

    protected override void LoadingCompleted()
    {
        SingletonObject<CLoginLoading>.GetInst().EnterScene(DEFINE.LOGIN_SCENE_ID);

        TouchEffect2.GetInst().Init();

    }
}
