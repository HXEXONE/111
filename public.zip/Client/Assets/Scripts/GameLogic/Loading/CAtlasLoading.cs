using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CAtlasLoading : CLoadingCommon
{
    public void StartLoading()
    {
        CLoadingManager.GetInst().StartAddUrl(this, 10, false);
    }

    public void EndLoading()
    {
        CLoadingManager.GetInst().EndAddUrl();
    }

    public override float GetProgress()
    {
        float progress =  base.GetProgress();

        return  0.9f + progress * 0.1f;
    }

    protected override void LoadingCompleted()
    {

        ClientMain.GetInst().SetGameState(eGameState.Login);      
        
    }

}
