﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CLoadingCommon : CLoadingBase
{
    /// <summary>
    /// //加载主角
    /// </summary>
    /// <param name="uiNpcID"></param>
    /// <param name="bHomeAvatar">selfAvatar 是否为自己的avatar</param>
    /// <param name="selfAvatar"></param>
    protected void PreloadAvatar(uint uiNpcID,bool bHomeAvatar,bool selfAvatar = false)
    {
        PlayerContent playerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(uiNpcID);
        if (null == playerLoader)
        {
            return;
        }

        bool bBattleLoading = this is CBattleSceneLoading ? true : false;
        string animatorPath = bBattleLoading ? playerLoader.AmimatorPath : Common.ReplaceHomeAniPath(playerLoader.AmimatorPath);

        //预加载npc动作
        //AddAsset(animatorPath);
        //需要常驻内存
        LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, null, false);

        if (selfAvatar)        
            LoadHelp.LoadObject("", "resources/effect/other/jiantou.x", ThreadPriority.Normal, null,false);

        if (!bHomeAvatar)
        {
            PreloadSkill((uint)playerLoader.NormalSkill);
            PreloadAction((uint)playerLoader.m_DeadActID);
        }

        stHomeAvatarInfo pHomeAvatarInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        PreloadEquip (pHomeAvatarInfo.uiWeaponID);
        PreloadEquip(pHomeAvatarInfo.uiClothesID);
        PreloadEquip((uint)playerLoader.MountWeapon);
        PreloadEquip((uint)playerLoader.FlyWeapon);
    }

    protected void PreloadEnemyAvatar(uint playerKey, uint uiWeaponID, uint uiClothesID)
    {
        PlayerContent playerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(playerKey);
        if (null == playerLoader)
        {
            return;
        }

        bool bBattleLoading = this is CBattleSceneLoading ? true : false;
        string animatorPath = bBattleLoading ? playerLoader.AmimatorPath : Common.ReplaceHomeAniPath(playerLoader.AmimatorPath);

        //预加载npc动作
        //AddAsset(animatorPath);
        //需要常驻内存
        LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, null, false);

        PreloadSkill((uint)playerLoader.NormalSkill);
        PreloadAction((uint)playerLoader.m_DeadActID);

        PreloadEquip(uiWeaponID);
        PreloadEquip(uiClothesID);
        PreloadEquip((uint)playerLoader.MountWeapon);
        PreloadEquip((uint)playerLoader.FlyWeapon);
    }


    protected void PreloadPartner(PartnerSortItem info) 
    {
        if (null == info.loader)        
            return;

        LoadHelp.LoadObject("", info.loader.ModelLoader.ModelRes, ThreadPriority.Normal, null, false);

        bool bBattleLoading = this is CBattleSceneLoading ? true : false;
        string animatorPath = bBattleLoading ? info.loader.ModelLoader.ModelRes.Replace("_model", "_ctrl") : info.loader.ModelLoader.ModelRes.Replace("_model", "_home_ctrl");        

        //预加载npc动作
        //需要常驻内存
        LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, null, false);

        List<Protocol.SkillCell> skillcesList = info.info.vecSkillList;
        for (int i = 0, len = skillcesList.Count; i < len; i++)
        {
            Protocol.SkillCell cell = skillcesList[i];
            SkillUpContent skillupLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(cell.ID);//skillupID
            if (null == skillupLoader)
                continue;

            SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(skillupLoader.SkillId);
            if (pSkillLoader == null)
                continue;

            PreloadSkill((uint)pSkillLoader.Key);

            PreloadAction((uint)info.loader.ModelLoader.DeadActionID);
        }

        PreloadEquip((uint)info.loader.ModelLoader.WeaponID);
    }

    //加载好友
    protected void PreloadAIFriend(uint uiNpcID)
    {
        PlayerContent playerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(uiNpcID);
        if (null == playerLoader)
        {
            return;
        }

        bool bBattleLoading = this is CBattleSceneLoading ? true : false;
        string animatorPath = bBattleLoading ? playerLoader.AmimatorPath : Common.ReplaceHomeAniPath(playerLoader.AmimatorPath);

        //预加载npc动作
        LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, null, false);

        PreloadSkill((uint)playerLoader.NormalSkill);
        PreloadAction((uint)playerLoader.m_DeadActID);

        stFriendInfo pFriendInfo = SingletonObject<FriendManager>.GetInst().GetFightFriend();
        PreloadEquip(pFriendInfo.uiWeaponID);
        PreloadEquip(pFriendInfo.uiClothesID);
    }

    //加载战场中的所有怪物
    protected void PreloadAllmonster(SceneContent pSceneInfo)
    {
        //List<uint> preloadNpcList = new List<uint>();
        //List<uint> triggerList = pSceneInfo.GetTriggerList();
        //if (triggerList.Count >= 2)
        //{
        //    uint start = triggerList[0];
        //    uint end = triggerList[1];

        //    for (uint i = start; i <= end; ++i)
        //    {
        //        TriggerHolder pTriggerInfo = HolderManager.m_TriggerHolder.GetStaticInfo(i);
        //        if (pTriggerInfo != null)
        //        {
        //            List<List<int>> monsterList = pTriggerInfo.GetCreateMonsterList();

        //            for (int j = 0, count = monsterList.Count; j < count; ++j)
        //            {
        //                List<int> list = monsterList[j];
        //                if (list.Count != 3)
        //                {
        //                    continue;
        //                }
        //                uint uiNpcID = (uint)list[0];
        //                if (!preloadNpcList.Contains(uiNpcID))
        //                {
        //                    preloadNpcList.Add(uiNpcID);
        //                }
        //            }
        //        }
        //    }
        //    for (int i = 0, count = preloadNpcList.Count; i < count; ++i)
        //    {
        //        PreloadMonster(preloadNpcList[i]);
        //    }
        //}

        List<BaseIntContent> maxMonsterList = pSceneInfo.MaxMonsterList;
        List<int> tmpList;
        for (int i = 0, count = maxMonsterList.Count; i < count; ++i)
        {
            tmpList = maxMonsterList[i].list;
            if (tmpList.Count < 2)
            {
                continue;
            }

            uint uiMonsterID = (uint)tmpList[0];

            PreloadMonster(uiMonsterID);
        }
        
    }

    //加载怪物
    protected void PreloadMonster(uint uiNpcID, uint uiFatherNpcID = 0)
    {
        MonsterContent monsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(uiNpcID);
        if (null == monsterLoader)
        {
            return;
        }

        if (null == monsterLoader.ModelLoader)
        {
            MyLog.DebugLogException("monstermodel is null,npcid:" + uiNpcID);
            return;
        }

        string path = monsterLoader.ModelLoader.Path;
        //预加载npc
        AddAsset(path);

        //需要常驻内存
        string anPath = monsterLoader.ModelLoader.AniPath;
        LoadHelp.LoadObject("", anPath, ThreadPriority.Normal, null, false);

        //预加载武器
        PreloadEquip((uint)monsterLoader.WeaponID);

        List<int> skillList = monsterLoader.Skilllist;
        for (int i = 0, count = skillList.Count; i < count; ++i)
        {
            PreloadSkill((uint)skillList[i]);
        }

        PreloadAction((uint)monsterLoader.ModelLoader.DeadActID);

        //扩展AI
        List<int> AIex = monsterLoader.AIex;
        for (int i = 0, count = AIex.Count; i < count; ++i)
        {
            ExtraAIContent pExtraInfo = HolderManager.m_ExtraAIHolder.GetStaticInfo(AIex[i]);
            if (pExtraInfo != null)
            {
                if (pExtraInfo.EventType == (byte)eExtraAIEvent.Shapeshift)
                {
                    string[] strs = pExtraInfo.EventArg.Split('~');
                    if (strs.Length == 2)
                    {
                        uint uiShapeshiftID = MyConvert_Convert.ToUInt32(strs[0]);
                        if (uiShapeshiftID != uiFatherNpcID)
                        {
                            PreloadMonster(uiShapeshiftID, uiNpcID);
                        }
                        else
                        {
                            MyLog.LogError("dead circle!!!!!!!!!!!!!!!!");
                        }
                    }
                    
                }
            }
        }

        //预加载Animator Controller      组件
        //string ctrlPath = path.Replace("_model", "_ctrl");
        //AddAsset(ctrlPath);
    }

    //加载装备表
    protected void PreloadEquip(uint uiWeaponID)
    {
        EquipContent pEquipLoader = HolderManager.m_EquipHolder.GetStaticInfo(uiWeaponID);
        if (pEquipLoader != null && pEquipLoader.ModelLoader != null)
        {
            List<string> list = pEquipLoader.ModelLoader.ModelPath;
            for (int i = 0, count = list.Count; i < count; ++i)
            {
                LoadHelp.LoadObject("", list[i], ThreadPriority.Normal, null, false);
            }

            List<string> texList = pEquipLoader.ModelLoader.TexturePath;
            for (int i = 0, count = texList.Count; i < count; ++i)
            {
                LoadHelp.LoadObject("", texList[i], ThreadPriority.Normal, null, false);
            }

            List<string> pathTexture = pEquipLoader.ModelLoader.TexturePath;
            if (pathTexture.Count == 2)
            {
                if (pathTexture[0].Equals("0"))
                {
                    LoadHelp.LoadObject("", pathTexture[0], ThreadPriority.Normal, null, false);
                }                
                if (pathTexture[1].Equals("1"))
                {
                    LoadHelp.LoadObject("", pathTexture[1], ThreadPriority.Normal, null, false);
                }
            }
        }
    }

    //加载技能表
    protected void PreloadSkill(uint uiSkillTypeID)
    {
        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillTypeID);
        if (null == pSkillLoader) return;

        PreloadAction((uint)pSkillLoader.AttackID);
        PreloadAction((uint)pSkillLoader.DefenceID);

        List<int> nextSkillID = pSkillLoader.NextSkill;
        for (int i = 0, count = nextSkillID.Count; i < count; ++i)
        {
            int skillID = nextSkillID[i];
            if (skillID == uiSkillTypeID)
            {
                MyLog.LogError("PreloadSkill:" + uiSkillTypeID + " error,deadcircle");
                continue;
            }

            //值做了技能类型为1的预加载，等对其他技能预加载了再开放
            //List<uint> selfScripts = pSkillLoader.GetSelfScripts();
            //List<uint> targetScripts = pSkillLoader.GetTargetScripts();
            //selfScripts.AddRange(targetScripts);
            //int scriptsCount = selfScripts.Count;
            //ScriptContent scriptLoader;
            //for (int s = 0; s < scriptsCount; s++)
            //{
            //    scriptLoader = HolderManager.m_ScriptHolder.GetStaticInfo(selfScripts[s]);
            //    if (scriptLoader == null)
            //        continue;
            //    ushort actionID = scriptLoader.GetTrueAction();
            //    if (actionID == (ushort)eScriptAction.NPC_ChangeMaterial)
            //    {
            //        string actionValue = scriptLoader.GetTrueValue();
            //        string[] args = actionValue.Split('$');
            //        if (args.Length <= 1)
            //            continue;
            //        int materialIndex = MyConvert_Convert.ToInt32(args[0]);
            //        DynamicShader.LoadMaterialsObj(materialIndex);
            //    }
            //}

            PreloadSkill((uint)skillID);
        }
    }

    //加载动作表
    protected void PreloadAction(uint uiActID)
    {
        ActionContent pActInfo = HolderManager.m_ActionHolder.GetStaticInfo(uiActID);
        if (null == pActInfo) return;

        List<int> allEffects = Common.GetPlayEffects(pActInfo);
        for (int i = 0, count = allEffects.Count; i < count; ++i)
        {
            PreloadEffect(allEffects[i]);
        }

        List<string> extraArgs = pActInfo.ExtraArgs;
        if (extraArgs.Count == 3)
        {
            uint extraAction = MyConvert_Convert.ToUInt32(extraArgs[2]);
            ActionContent pExtraAction = HolderManager.m_ActionHolder.GetStaticInfo(extraAction);
            if (null != pExtraAction)
            {
                List<int> extraAllEffect = Common.GetPlayEffects(pExtraAction);
                for (int i = 0, count = extraAllEffect.Count; i < count; ++i)
                {
                    PreloadEffect(extraAllEffect[i]);
                }
            }
        }

        List<int> soundList = Common.GetSounds(pActInfo);
        for (int i = 0, count = soundList.Count; i < count; ++i)
        {
            PreloadSound(soundList[i]);
        }
    }

    //加载特效表 
    protected void PreloadEffect(int uiParticelID)
    {
        ParticleContent particleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(uiParticelID);
        if (null == particleInfo) return;

        string path = particleInfo.Path;
        AddAsset(path);

    }

    //卸载特效
    protected void ReleaseEffect(int uiParticelID)
    {
        ParticleContent particleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(uiParticelID);
        if (null == particleInfo) return;

        string path = particleInfo.Path;
        LoadHelp.RemoveObject(path);
    }

    //加载音效表
    protected void PreloadSound(int uiSoundID)
    {
        AudioContent audioInfo = HolderManager.m_AudioHolder.GetStaticInfo(uiSoundID);
        if (null == audioInfo) return;

        string path = audioInfo.Path;
        AddAsset(path);

    }

    public static void PreloadAtlas(string atlasName)
    {
        LoadHelp.LoadObject("", UITool.GetAtlasUIRelativePath(atlasName), ThreadPriority.Normal, null);
    }

    public static void ReleaseAtlas(string atlasName)
    {
        LoadHelp.RemoveObject(UITool.GetAtlasUIRelativePath(atlasName));
    }

}
