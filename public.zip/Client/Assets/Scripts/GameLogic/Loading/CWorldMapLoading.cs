﻿using UnityEngine;
using System.Collections;

public class CWorldMapLoading : CBaseSceneLoading
{
    protected uint sceneID = 0;
    protected override CBaseScene InitScene()
    {
        WorldMapScene pScene = SingletonObject<WorldMapScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key);
        return pScene;
    }

    protected override void OtherLoadings()
    {
        //SingletonObject<WorldMapMediator>.GetInst().PreloadUI();
        SingletonObject<BattlePveMediator>.GetInst().PreloadUI();
    }

    protected override void LoadSceneCompleted()
    {
        eGameState lastState = ClientMain.GetInst().GetCurrentState();

        BattlePveMediator battlePveLevel = SingletonObject<BattlePveMediator>.GetInst();
        WorldAreaMapMediator worldMap = SingletonObject<WorldAreaMapMediator>.GetInst();
        int iArea = worldMap.AreaIndex();
        if (lastState == eGameState.Home && battlePveLevel.tweenType ==eTweenCameraType.WorldTween)
        {
            //SingletonObject<WorldMapMediator>.GetInst().TweenPanel(1.0f, 0.0f, 0.5f);
            
            if (iArea < 0 || iArea >= WorldAreaMapMediator.areaCount)
            {
                iArea = (int)(sceneID - DEFINE.WORLD_MAP_ID);
            }
            //worldMap.WorldAreaTween(iArea);
            worldMap.WorldPanelTweenAphla(1.0f, 0.3f, 0.8f);
            //SingletonObject<BattlePVELevelMediator>.GetInst().TweenOpen(battlePveLevel.tweenType);
        }
        else if (lastState == eGameState.WorldMap)
        {
            if (iArea < 0 || iArea >= WorldAreaMapMediator.areaCount)
            {
                iArea = (int)(sceneID - DEFINE.WORLD_MAP_ID);
            }
            //worldMap.WorldAreaTween(iArea);
            worldMap.WorldPanelTweenAphla(1.0f, 0.3f, 0.8f);

        }
        else if (battlePveLevel.tweenType ==eTweenCameraType.FromTask)
        {
            ClientMain.GetInst().SetGameState(eGameState.WorldMap);
        }
        else if (battlePveLevel.tweenType == eTweenCameraType.FromBattle)
        {
            ClientMain.GetInst().SetGameState(eGameState.WorldMap);
        }
        else if (battlePveLevel.tweenType == eTweenCameraType.TeamPveGoto)
        {
            ClientMain.GetInst().SetGameState(eGameState.WorldMap);
        }
        else
        {
            ClientMain.GetInst().SetGameState(eGameState.WorldMap);
        }
        //MyLog.LogError("......................................." + battlePveLevel.tweenType);
        SingletonObject<LoadingCircleMediator>.GetInst().Close();
    }

    public override void EnterScene(uint uiSceneID, bool bEnterLoading = true)
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.Battle)
        {
            SingletonObject<LoadingCircleMediator>.GetInst().Open(null);
        }
        
        base.EnterScene(uiSceneID, bEnterLoading);
        sceneID = uiSceneID;
    }
}
