﻿using UnityEngine;
using System.Collections;

public class CArenaUILoading : CBaseSceneLoading
{
    protected override CBaseScene InitScene()
    {
        ArenaUIScene pScene = SingletonObject<ArenaUIScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key);
        return pScene;
    }

    protected override void OtherLoadings()
    {
        SingletonObject<ArenaMediator>.GetInst().PreloadUI();
    }

    protected override void LoadSceneCompleted()
    {
        ClientMain.GetInst().SetGameState(eGameState.ArenaUI);
    }
}
