﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eResourceType
{
    RESOURCE_NONE               = 0,
    RESOURCE_STATICDATA         = 1,    //数据表资源

}


public class CLoadingBase
{
    private Dictionary<string, stLoadInfo> m_rerquestList = new Dictionary<string,stLoadInfo>();

    private eLoadingState m_state;//状态
    protected float m_TotalProgress;

    private static List<string> assetList = new List<string>();

    protected void AddAsset(string path)
    {
        LoadHelp.LoadObject("", path, ThreadPriority.Normal, null, false);

        if (!assetList.Contains(path))
        {
            assetList.Add(path);
        }
    }

    public static void ClearAssets()
    {
        foreach (string path in assetList)
        {
            LoadHelp.RemoveObject(path);
        }
        assetList.Clear();
    }

    public CLoadingBase()
    {
        Reset();

    }

    public virtual float GetProgress()
    {
        return m_TotalProgress;
    }

    public virtual void Reset()
    {
        m_state = eLoadingState.None;
        m_rerquestList.Clear();
    }

    public virtual void StartAddUrl(bool bEnterLoading)
    {
        m_state = eLoadingState.AddUrl;
        m_TotalProgress = 0;
    }

    public virtual void AddUrl(stLoadInfo info)
    {
        if (m_state != eLoadingState.AddUrl)
        {
            return;
        }


        if(!m_rerquestList.ContainsKey(info.originPath))
        {
            m_rerquestList.Add(info.originPath, info);

        }

    }

    public virtual void EndAddUrl()
    {
        m_state = eLoadingState.Loading;

        UpdateProgress();
    }


    public virtual void SetLoadingContent( eResourceType type ,float fMin,float fMax )
    {
        float fTotal = fMax - fMin;

        if (GetProgress() < fMin || GetProgress() > fMax) return;

    }


    public void UpdateProgress()
    {
        switch (m_state)
        {
            case eLoadingState.AddUrl:
                {
                }
                break;
            case eLoadingState.Loading:
                {
                    if (m_rerquestList.Count <= 0)
                    {
                        m_TotalProgress = 1;

                        m_state = eLoadingState.Completed;
                        return;
                    }
                    float progress = 0;

                    foreach (KeyValuePair<string, stLoadInfo> kvp in m_rerquestList)
                    {
                        progress += kvp.Value.progress;
                    }

                    m_TotalProgress = progress / (float)m_rerquestList.Count;

                    if (m_TotalProgress >= 1)
                    {
                        m_state = eLoadingState.Completed;
                    }
                    else
                    {
                        Loading();
                    }

                }
                break;
            case eLoadingState.Completed:
                {
                    Reset();
                    LoadingCompleted();
                    
                }
                break;
        }

        Update();
    }

    protected virtual void Loading()
    {

    }

    protected virtual void LoadingCompleted()
    {

    }

    protected virtual void Update()
    {

    }

}