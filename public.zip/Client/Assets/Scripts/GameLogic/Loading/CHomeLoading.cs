﻿using UnityEngine;
using System.Collections;

public class CHomeLoading : CBaseSceneLoading
{
    protected override CBaseScene InitScene()
    {
        HomeScene pScene = SingletonObject<HomeScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key);
        return pScene;
    }

    protected override void OtherLoadings()
    {
        //stHomeAvatarInfo pAvatarInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        //PreloadAvatar(pAvatarInfo.uiPlayerJob, true);
        
        SingletonObject<HomeMainMediator>.GetInst().PreloadUI();
        SingletonObject<NpcMediator>.GetInst().PreloadUI();

        UITool.PreloadIconTexture("floor_partner1", eResType.Public);

        //预加载shader
        DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_DIRECTLIGHT);

        eGameState eBeforeState = CLoadingManager.GetInst().GetBeforeState();
        if (eBeforeState == eGameState.ArenaUI)
        {
            SingletonObject<ChooseArenaTypeMediator>.GetInst().PreLoadBgTexture();

        }
        else if (eBeforeState == eGameState.Battle)
        {
            CBattleSceneLoading cbsl = SingletonObject<CBattleSceneLoading>.GetInst();
            switch (cbsl.battleType)
            {
                case eBattleType.Wasteland:
                    SingletonObject<MoorMediator>.GetInst().PreLoadBgTexture(false);
                    break;
                case eBattleType.Escort:
                case eBattleType.Protect:
                    SingletonObject<EscortMediator>.GetInst().loadBackTexture(false);
                    break;
                case eBattleType.Mining:
                    SingletonObject<MiningMainMediator>.GetInst().loadBackTexture(false, false);
                    break;
                case eBattleType.ClimbTower:
                    SingletonObject<TowerMediator>.GetInst().loadBackTexture(false);
                    break;
            }
        }


        //SingletonObject<HomeScene>.GetInst().PreloadUIScene(DEFINE.UISCENE_CHARACTER_ID);
    }

    protected override void LoadSceneCompleted()
    {
        SingletonObject<CPlayer>.GetInst().RequestEnterHome();

    }

}
