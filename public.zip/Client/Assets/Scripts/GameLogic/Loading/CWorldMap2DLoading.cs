﻿using UnityEngine;
using System.Collections;

public class CWorldMap2DLoading : CLoadingCommon
{
    public void StartLoading()
    {
        UIManager.GetInst().IsLockNGUIEvent(true);
        CLoadingManager.GetInst().StartAddUrl(this, 10, false);
    }

    public void EndLoading()
    {
        CLoadingManager.GetInst().EndAddUrl();
    }

    protected override void LoadingCompleted()
    {
        UIManager.GetInst().IsLockNGUIEvent(false);
        SingletonObject<CPlayer>.GetInst().CloseHomeInfoMediator();
        SingletonObject<WorldAreaMapMediator>.GetInst().Open(null);
    }
}
