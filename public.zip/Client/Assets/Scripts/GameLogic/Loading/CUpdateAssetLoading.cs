﻿using UnityEngine;
using System.Collections;

public class CUpdateAssetLoading : CLoadingCommon
{
    public void StartLoading()
    {
        CLoadingManager.GetInst().StartAddUrl(this, 8, false);
    }

    public void EndLoading()
    {
        CLoadingManager.GetInst().EndAddUrl();
    }

    protected override void LoadingCompleted()
    {
        ClientMain.GetInst().CheckUpdate(onStartDownLoad, null);

    }


    private void onStartDownLoad(object parm)
    {
        SingletonObject<LoadingMediator>.GetInst().PreloadUI();
        ResourceManager.GetInst().StartDownLoad();
        //if (m_unloadDebug == null && Application.platform != RuntimePlatform.WindowsEditor && Application.platform != RuntimePlatform.OSXEditor)
        //{
        //    GameObject client = ClientMain.GetInst().gameObject;
        //    m_unloadDebug = client.AddComponent<UnloadFile>();
        //}
        //从cdn上取服务器列表和公告
        //CDNData.GetInst().RequestSrvList(false);
        //CDNData.GetInst().RequestNotice();
        //加载模型和特效的shader
        SingletonObject<ShaderConfigManager>.GetInst().LoadShader();

        UnityCallBackManager.GetInst().AddCallBack(0.3f, LoadDyncMat);
    }

    void LoadDyncMat(params object[] args)
    {
        DynamicShader.LoadAllMaterials();
    }
}
