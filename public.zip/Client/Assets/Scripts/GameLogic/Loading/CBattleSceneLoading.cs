﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eBattleSceneLoadingState
{
    None,
    CreateAvatar,//创建玩家
    CreatePet,//创建宠物
    ReadyPreloadMonster,//准备预加载怪物
    LoadingMonster,//正在加载怪物
    PreloadMonster,//预加载NPC
    PreloadExplorerMonster,//预加载碎尸前NPC
    ExplorerMonster,//碎尸
    CopyExplorer,//拷贝尸块
    ExplorerOver,//碎尸准备结束
    EnterBattle,//进入战场
}

//public enum eBattleSceneLoadingNPCAndDeploderState   //相同场景不加载场景时预加载怪物和碎尸
//{
//    None,
//    GetMonsterList,
//    LoadingObject,
//    PreCreateMonster,
//    GetExploderType,
//    PreExploder,
//    Wait,
//    Complete,
//}

public class CBattleSceneLoading : CBaseSceneLoading
{
    public eBattleType battleType = eBattleType.None;
    private eBattleSceneLoadingState m_battleLoadingState;
    // private eBattleSceneLoadingNPCAndDeploderState m_preCreateAndExploderState = eBattleSceneLoadingNPCAndDeploderState.None;
    //private Dictionary<uint, int> m_preCreateMonsterDirect = new Dictionary<uint, int>();

    //private int m_preCreateAndExploderIndex = 0;
    //private int m_preCreateAndExploderLoadCount = 0;

    private List<uint> m_monsterlist = new List<uint>();
    private uint m_currExplorerMonsterID;//当前正被碎尸的怪物的ID
    private GameObject m_currCloseMonster;//当前正被可控的怪物
    private GameObject m_currExplorerMonster;//当前正在被碎尸的怪物
    private List<int> m_explorerList = new List<int>();
    private string m_currExplorerMonsterPath;//当前正被碎尸的怪物的路径

    private bool m_exploderLimit = false;

    public override void EnterScene(uint uiSceneID, bool bEnterLoading = true)
    {
        m_battleLoadingState = eBattleSceneLoadingState.None;
        base.EnterScene(uiSceneID, bEnterLoading);
        //SingletonObject<LoadingMediator>.GetInst().SetLoadingText(Common.GetText(9000006), Common.GetText(9000007), Common.GetText(9000008));
    }

    protected override CBaseScene InitScene()
    {
        BattleScene pScene = SingletonObject<BattleScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key, battleType);
        AchieveManager.GetInst().bShowUnLocakEffect = false;
        switch (battleType)
        {
            case eBattleType.PVE:
                    pScene.SceneLogic = new PVESceneLogic();
                  break;
            case eBattleType.Arena:
                    pScene.SceneLogic = new ArenaSceneLogic();
                 break;
        }
        return pScene;
    }
    protected override void OtherLoadings()
    {
        stHomeAvatarInfo pAvatarInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        //自己
        PreloadAvatar(pAvatarInfo.uiPlayerJob, false,true);        
        //自己的伙伴
        List<PartnerSortItem> parterInfoList = PartnerManager.GetInst().GetPartnerList(battleType);
        for (int i = 0, len = parterInfoList.Count; i < len; i++)
        {
            PreloadPartner(parterInfoList[i]);
        }
        SingletonObject<BattleResultFailMediator>.GetInst().PreloadUI();
        SingletonObject<CPlayer>.GetInst().PreLoadSkillIcon(false);
        SingletonObject<BattleInfoMediator>.GetInst().PreloadUI();
        switch (battleType)
        {
            case eBattleType.PVE:
                SingletonObject<BattleResultWinMediator>.GetInst().PreloadUI();
                //SingletonObject<BattleResultFailMediator>.GetInst().PreloadUI();
                break;
            case eBattleType.ClimbTower:
                //SingletonObject<ClimbTowerResultMediator>.GetInst().PreloadUI();
                SingletonObject<BattleResultWinMediator>.GetInst().PreloadUI();
                //SingletonObject<BattleResultFailMediator>.GetInst().PreloadUI();
                break;
            case eBattleType.Arena:
                {
                    SingletonObject<ArenaResultMediator>.GetInst().PreloadUI();
                    ArenaManager ArenaMgr = ArenaManager.GetInst();
                    //敌人的伙伴
                    if (null != ArenaMgr.partner)
                    {
                        PreloadPartner(ArenaManager.GetInst().partner);
                    }

                    //敌人avatar
                    PreloadEnemyAvatar(ArenaMgr.arenaAvatarInfo.uiJob, ArenaMgr.arenaAvatarInfo.uiWeaponID, ArenaMgr.arenaAvatarInfo.uiClothesID);
                }                                
                break;
            case eBattleType.Wasteland:
                {
                    SingletonObject<BeforeBattleAnimMediator>.GetInst().PreloadUI();
                    //敌人的伙伴
                    MoorManager.stEnemyData pEnemyDataInfo = MoorManager.GetInst().StEnemyDataInfo;                    
                    if (null != pEnemyDataInfo.partner)
                    {
                        PreloadPartner(pEnemyDataInfo.partner);
                    }

                    //敌人avatar
                    PreloadEnemyAvatar(pEnemyDataInfo.uiJobId,pEnemyDataInfo.MatherInfo.uiWeaponId,pEnemyDataInfo.MatherInfo.uiClothesId);
                }
                break;
            case eBattleType.Mining:
                {
                    List<PartnerSortItem> EnemyParterInfoList = MiningManager.GetInst().GetEnemyPartner();
                    for (int i = 0, len = EnemyParterInfoList.Count; i < len; i ++ )
                    {
                        PreloadPartner(EnemyParterInfoList[i]);
                    }

                    //挖矿暂时没有avatar
                }
                break;
            case eBattleType.Pvp:
                {
                    SingletonObject<BeforeBattleAnimMediator>.GetInst().PreloadUI();
                    //敌人的伙伴                    
                    OnlineAvatar player = PvpManager.GetInst().GetEnemyPlayer();
                    PreloadPartner(player.BattleInfo.parterInfo);
                    //敌人avatar
                    PreloadEnemyAvatar(player.BattleInfo.jobId, player.BattleInfo.playerInfo.uiWeaponId, player.BattleInfo.playerInfo.uiClothesId);
                }
                break;
            case eBattleType.MultiPve:
                {
                    //盟友的伙伴                    
                    OnlineAvatar player = MultiPveManager.GetInst().GetEnemyPlayer();
                    PreloadPartner(player.BattleInfo.parterInfo);
                    //盟友avatar
                    PreloadEnemyAvatar(player.BattleInfo.jobId, player.BattleInfo.playerInfo.uiWeaponId, player.BattleInfo.playerInfo.uiClothesId);
                }
                break;
        }

        SingletonObject<AchieveUnLockMediator>.GetInst().PreloadUI();
        //释放家园的时候，预加载该图集防止战场解锁成就无法找到该图集。
        LoadHelp.LoadObject("systemfloor", "resources/uiresources/atlas/atlas_ui_systemfloor1_v2.x", ThreadPriority.Normal, null);

        SingletonObject<HpFrameMediator>.GetInst().PreloadUI();
        SingletonObject<FlywordMediator>.GetInst().preload();
    }

    protected override void LoadSceneCompleted()
    {
        //MyLog.Log("LoadSceneCompleted:" + Time.time);
        m_battleLoadingState = eBattleSceneLoadingState.CreateAvatar;
        if (battleType == eBattleType.Pvp)
        {
            PvpMsgMgr.RequestLoadingSecenFinish();
        }
        else if (battleType == eBattleType.MultiPve)
        {
            MultiPveMsg.RequestLoadingSecenFinish();
        }

        BattleScene bs = SingletonObject<BattleScene>.GetInst();

        GameObject pSceneObj = bs.GetSceneObj();

        if (pSceneObj != null)
        {
            int layer = 1 << DEFINE.AVATAR_LAYER;
            layer |= 1 << DEFINE.AIFRIEND_LAYER;

            Transform mechanismObject = pSceneObj.transform.FindChild("DynamicObject/Mechanism");
            CMechanismManage.GetInst().Init(bs.ModelTrans, mechanismObject, layer);
        }
    }

    protected override void Update()
    {
        base.Update();
        switch (m_battleLoadingState)
        {
            case eBattleSceneLoadingState.CreateAvatar:
                {
                    BattleScene pScene = SingletonObject<BattleScene>.GetInst();

                    //MyLog.Log("-----------------------------CreateAvatar----------------------" + Time.time);
                    SingletonObject<BattleInfoMediator>.GetInst().SetRoomType(pScene.RoomType);
                    Avatar pavatar = SingletonObject<BattleScene>.GetInst().CreateAvatar();
                    if (battleType == eBattleType.Arena)
                    {
                        ArenaManager pArena = ArenaManager.GetInst();
                        EnemyAvatar penemyavatar = SingletonObject<BattleScene>.GetInst().CreateEnemyAvatar();
                        SingletonObject<BattleScene>.GetInst().CreateEnemyPet();

                        //竞技场各种BUFF和设置
                        if (pavatar != null)
                        {
                            pavatar.Trusteeship = true;
                            pavatar.Courageous = true;
                        }
                        if (penemyavatar != null)
                        {
                            penemyavatar.Trusteeship = true;
                            penemyavatar.Courageous = true;
                        }

                        //竞技场输赢控制
                        if (pArena != null)
                        {
                            if (pArena.challengeRst == 1 && pArena.playerTotalGS < pArena.enemyTotalGS && pavatar != null)
                            {
                                pavatar.AddBuff(DEFINE.ARENA_ENHANCE_BUFF, null, true);
                            }
                            else if (pArena.challengeRst == 0 && pArena.playerTotalGS > pArena.enemyTotalGS && penemyavatar != null)
                            {
                                penemyavatar.AddBuff(DEFINE.ARENA_ENHANCE_BUFF, null, true);
                            }
                        }
                    }
                    else if (battleType == eBattleType.Wasteland)
                    {
                           SingletonObject<BattleScene>.GetInst().CreateEnemyAvatar();
                           SingletonObject<BattleScene>.GetInst().CreateEnemyPet();
                    }
                    else if (battleType == eBattleType.Pvp)
                    {
                        List<OnlineAvatar> playerList = SingletonObject<BattleScene>.GetInst().CreateOnlinePlayer(battleType);
                        for (int i = 0, len = playerList.Count; i < len; i++ )
                        {
                            SingletonObject<BattleScene>.GetInst().CreateEnemyPet(playerList[i]);
                        }                        
                    }
                    else if (battleType == eBattleType.MultiPve)
                    {
                        List<OnlineAvatar> playerList = SingletonObject<BattleScene>.GetInst().CreateOnlinePlayer(battleType);
                        for (int i = 0, len = playerList.Count; i < len; i++)
                        {
                            SingletonObject<BattleScene>.GetInst().CreateEnemyPet(playerList[i]);
                        }       
                    }
                    else if (battleType == eBattleType.Mining)
                    {
                        SingletonObject<BattleScene>.GetInst().CreateEnemyAvatar();                        
                    }
                    else if (battleType == eBattleType.PVE && mapSceneID != DEFINE.NEW_PLAYER_SCENE_ID)
                    {
                        SingletonObject<BattleScene>.GetInst().CreateAIFriend();
                        if (pScene.RoomType == eRoomType.Escort)
                        {
                            //PVE增加护送关卡
                            pavatar.ProtectNpc = SingletonObject<BattleScene>.GetInst().CreateCarriage();
                        }
                        if (pScene.RoomType == eRoomType.Protect)
                        {
                            //PVE增加守护关卡
                            pavatar.ProtectNpc = SingletonObject<BattleScene>.GetInst().CreateProtectNpc();
                        } 
                    }
                    else if (battleType == eBattleType.Escort) 
                    {
                        pavatar.ProtectNpc = SingletonObject<BattleScene>.GetInst().CreateCarriage();
                    }
                    else if (battleType == eBattleType.Protect)
                    {
                        pavatar.ProtectNpc = SingletonObject<BattleScene>.GetInst().CreateProtectNpc();
                    }
                    else if (eBattleType.Run == battleType)
                    {
                    }
           
                    m_battleLoadingState = eBattleSceneLoadingState.CreatePet;
                }
                break;
            case eBattleSceneLoadingState.CreatePet:
                {
                    //MyLog.Log("-----------------------------CreatePet----------------------" + Time.time);
                    SingletonObject<BattleScene>.GetInst().CreatePet();

                    m_battleLoadingState = eBattleSceneLoadingState.ReadyPreloadMonster;
                }
                break;
            case eBattleSceneLoadingState.ReadyPreloadMonster:
                {

                    m_monsterlist.Clear();

                    List<BaseIntContent> maxMonsterList = m_pSceneLoader.MaxMonsterList;

                    if (null == maxMonsterList) MyLog.Log("null == maxMonsterList");
                    List<int> tmpList;
                    //List<string> pathList = new List<string>();
                    for (int i = 0, count = maxMonsterList.Count; i < count; ++i)
                    {
                        if (null == maxMonsterList[i])
                        {
                            MyLog.Log("null == maxMonsterList[i]:" + i);
                            continue;
                        }
                        tmpList = maxMonsterList[i].list;
                        if (null == tmpList)
                        {
                            MyLog.Log("null == tmpList:" + i);
                            continue;
                        }
                        if (tmpList.Count < 2)
                        {
                            MyLog.LogError("GetMaxMonsterList count error:" + m_pSceneLoader.Key);
                            continue;
                        }

                        uint uiMonsterID = (uint)tmpList[0];
                        int nNum = 0;

                        MonsterContent pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(uiMonsterID);
                        if (null == pMonsterLoader)
                        {
                            continue;
                        }

                        switch ((eNpcSortType)pMonsterLoader.Sort)
                        {
                            case eNpcSortType.NormalMonster:
                            case eNpcSortType.LeaderMonster:
                            case eNpcSortType.EliteMonster:
                            case eNpcSortType.Turret:
                            case eNpcSortType.Chest:
                                {
                                    nNum = 2;
                                }
                                break;
                            default:
                                {
                                    nNum = 1;
                                }
                                break;
                        }

                        if (pMonsterLoader.Sort == (byte)eNpcSortType.NormalMonster)
                        {
                            for (int j = 0, count2 = nNum; j < count2; ++j)
                            {
                                m_monsterlist.Add(uiMonsterID);
                            }
                        }
                    }

                    m_exploderLimit = m_monsterlist.Count > 4;  //怪物数量大于4个后碎尸部位只有一个

                    //清空内存池
                    //SingletonObject<NpcFactory>.GetInst().ClearMemoryExceptAppoint(pathList);

                    //CExploderManage.GetInst().ExceptRelease(m_pSceneLoader.GetKey(), true);
                    //SingletonObject<DropObjectFactory>.GetInst().ClearAllMemory();
                    //SingletonObject<ParticleSystemFactory>.GetInst().ClearAllMemory();
                    //SingletonObject<WeaponFactory>.GetInst().ClearAllMemory();

                    //SingletonObject<FlywordMediator>.GetInst().Release();

                    PreloadAllmonster(m_pSceneLoader);

                    m_battleLoadingState = eBattleSceneLoadingState.LoadingMonster;
                }
                break;
            case eBattleSceneLoadingState.LoadingMonster:
                {
                    if (!LoadHelp.IsSomethingInLoading())
                    {
                        m_battleLoadingState = eBattleSceneLoadingState.PreloadMonster;
                    }
                }
                break;
            case eBattleSceneLoadingState.PreloadMonster:
                {

                    if (m_monsterlist.Count <= 0 || !CExploderManage.GetInst().IsOpenExploder())
                    {
                        m_battleLoadingState = eBattleSceneLoadingState.ExplorerOver;
                        break;
                    }
                    //MyLog.Log("-----------------------------PreloadMonster----------------------" + Time.time);

                    m_currExplorerMonsterID = m_monsterlist[0];
                    int maxNum = 0;
                    while (m_monsterlist.Contains(m_currExplorerMonsterID))
                    {
                        maxNum++;
                        m_monsterlist.Remove(m_currExplorerMonsterID);

                        if (maxNum > 100)
                        {
                            MyLog.LogError("dead circle!!!!!!!!!!");
                            break;
                        }
                    }

                    MonsterContent pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(m_currExplorerMonsterID);
                    if (pMonsterLoader != null && pMonsterLoader.ModelLoader != null)
                    {
                        m_currExplorerMonsterPath = pMonsterLoader.ModelLoader.Path;
                        //MyLog.Log("PreloadMonster:" + pMonsterInfo.GetKey());
                        m_currCloseMonster = SingletonObject<NpcFactory>.GetInst().PreCreate(m_currExplorerMonsterPath, maxNum);

                    }



                    //判断当前怪物是否能被碎尸
                    if (pMonsterLoader == null)
                        m_battleLoadingState = eBattleSceneLoadingState.PreloadMonster;
                    else if (pMonsterLoader.ModelLoader != null)
                    {
                        List<BaseIntContent> exploderDict = pMonsterLoader.ModelLoader.ExploderType;
                        if (null != exploderDict)
                        {
                            if (exploderDict.Count > 0)
                            {
                                if (!m_exploderLimit)
                                {
                                    m_explorerList.Clear();

                                    foreach (BaseIntContent content in exploderDict)
                                    {
                                        if (content.list != null && content.list.Count > 0)
                                            m_explorerList.Add(content.list[0]);
                                    }
                                }
                                else
                                {
                                    int exploderType = -1;
                                    int probability = 0;
                                    foreach (BaseIntContent content in exploderDict)
                                    {
                                        if (content.list != null && content.list.Count >= 2)
                                        {
                                            if (probability < content.list[1])
                                            {
                                                probability = content.list[1];
                                                exploderType = content.list[0];
                                            }
                                        }
                                    }
                                    if (exploderType > 0)
                                        m_explorerList.Add(exploderType);
                                }

                                //if (CExploderManage.GetInst().IsOpenExploder())
                                m_battleLoadingState = eBattleSceneLoadingState.PreloadExplorerMonster;
                                //else
                                //    m_battleLoadingState = eBattleSceneLoadingState.ExplorerOver;
                            }
                            else
                            {
                                m_battleLoadingState = eBattleSceneLoadingState.PreloadMonster;
                            }
                        }

                    }



                    //SingletonObject<CExploderManage>.GetInst().Init(IDS, 3, true, true, eExploderMemoryType.DismemerMemory);
                }
                break;
            case eBattleSceneLoadingState.PreloadExplorerMonster:
                {
                    if (m_explorerList.Count <= 0)
                    {
                        //完成一个怪物的所有预创建,执行下一个
                        m_battleLoadingState = eBattleSceneLoadingState.PreloadMonster;
                        break;
                    }
                    //MyLog.LogError("-----------------------------PreloadExplorerMonster----------------------" + Time.time);
                    if (SingletonObject<CExploderManage>.GetInst().GetTypeForPathCount(m_currExplorerMonsterPath, (eExploderType)m_explorerList[0]) > 0)
                    {
                        m_battleLoadingState = eBattleSceneLoadingState.CopyExplorer;
                    }
                    else
                    {
                        m_currExplorerMonster = (GameObject)UnityEngine.Object.Instantiate(m_currCloseMonster);

                        m_battleLoadingState = eBattleSceneLoadingState.ExplorerMonster;
                    }

                }
                break;
            case eBattleSceneLoadingState.ExplorerMonster:
                {
                    //MyLog.Log("-----------------------------ExplorerMonster----------------------" + Time.time);

                    eExploderType type = (eExploderType)m_explorerList[0];
                    DynamicShader.ReplaceUnSupportShader(m_currExplorerMonster);
                    //SingletonObject<CExploderManage>.GetInst().CreateExploder(m_currExplorerMonsterID, m_currExplorerMonster, type, eExploderMemoryType.DismemerMemory, 2.5f);
                    SingletonObject<CExploderManage>.GetInst().CreateExploderForPath(m_currExplorerMonsterPath, m_currExplorerMonster, type, 1.5f);
                    m_battleLoadingState = eBattleSceneLoadingState.CopyExplorer;
                }
                break;
            case eBattleSceneLoadingState.CopyExplorer:
                {
                    //MyLog.Log("-----------------------------CopyExplorer----------------------" + Time.time);
                    eExploderType type = (eExploderType)m_explorerList[0];
                    //SingletonObject<CExploderManage>.GetInst().CloneExploderObject(m_currExplorerMonsterID, type, 2);
                    SingletonObject<CExploderManage>.GetInst().CloneExploderObjectForPath(m_currExplorerMonsterPath, type, 1);
                    //继续肢解下一个部位
                    m_explorerList.RemoveAt(0);
                    m_battleLoadingState = eBattleSceneLoadingState.PreloadExplorerMonster;
                }
                break;
            case eBattleSceneLoadingState.ExplorerOver:
                {
                    if (!ClientMain.GetInst().EnterTestScene)
                    {
                        //SingletonObject<CExploderManage>.GetInst().StartUpdate(true, true);
                        SingletonObject<CExploderManage>.GetInst().StartUpdateForPath(true);
                    }
                    m_monsterlist.Clear();

                    m_battleLoadingState = eBattleSceneLoadingState.EnterBattle;
                }
                break;

            case eBattleSceneLoadingState.EnterBattle:
                {
                    MyLog.Log("eBattleSceneLoadingState.EnterBattle");
                    //MyLog.Log("-----------------------------EnterBattle----------------------"+Time.time);
                    ClientMain.GetInst().SetGameState(eGameState.Battle);
                }
                break;
        }
    }

    public void SetNextSceneLoader(SceneContent pSceneLoader)
    {
        m_pSceneLoader = pSceneLoader;
        m_battleLoadingState = eBattleSceneLoadingState.ReadyPreloadMonster;
    }


    //public void StartPreCreate()
    //{
    //    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.GetMonsterList);
    //}

    //private void SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState preCreateAndExploderState)  //相同场景不加载场景时预加载怪物和碎尸，设置状态
    //{
    //    m_preCreateAndExploderState = preCreateAndExploderState;
    //}

    //public bool PreCreateAndEcploder(SceneContent sceneInfo)    //相同场景不加载场景时预加载怪物和碎尸
    //{
    //    if (sceneInfo == null)
    //    {
    //        MyLog.Log("CBattleSceneLoading::PreCreateAndEcploder(SceneContent sceneInfo) error,the sceneInfo is null");
    //        return true;
    //    }
    //    switch (m_preCreateAndExploderState)
    //    {
    //        case eBattleSceneLoadingNPCAndDeploderState.GetMonsterList:
    //            {
    //                m_preCreateMonsterDirect.Clear();

    //                List<List<int>> tempMopnsterList = sceneInfo.GetMaxMonsterList();
    //                List<int> tempList;
    //                int count = tempMopnsterList.Count;
    //                List<string> pathList = new List<string>();
    //                for (int i = 0; i < count; i++)
    //                {
    //                    tempList = tempMopnsterList[i];
    //                    if (tempList.Count != 2)
    //                        continue;

    //                    uint monsterID = (uint)tempList[0];
    //                    MonsterContent pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(monsterID);
    //                    if (null == pMonsterLoader)
    //                    {
    //                        continue;
    //                    }
    //                    string path = pMonsterLoader.GetPath();

    //                    if (!pathList.Contains(path))
    //                    {
    //                        pathList.Add(path);
    //                    }

    //                    m_preCreateMonsterDirect.Add(monsterID, tempList[1]);
    //                }

    //                //清空内存池
    //                SingletonObject<NpcFactory>.GetInst().ClearMemoryExceptAppoint(pathList);
    //                CExploderManage.GetInst().Release(false);

    //                m_preCreateAndExploderIndex = 0;
    //                m_preCreateAndExploderLoadCount = 0;
    //                SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.LoadingObject);
    //            }
    //            break;
    //        case eBattleSceneLoadingNPCAndDeploderState.LoadingObject:
    //            {
    //                MonsterContent loadInfo = null;

    //                foreach (KeyValuePair<uint, int> val in m_preCreateMonsterDirect)
    //                {
    //                    loadInfo = HolderManager.m_MonsterHolder.GetStaticInfo(val.Key);

    //                    if (loadInfo == null)
    //                        continue;

    //                    if (loadInfo.GetExploderProbaility() > 0 && !m_monsterlist.Contains(val.Key))
    //                    {
    //                        m_monsterlist.Add(val.Key);
    //                    }

    //                    if (!SingletonObject<NpcFactory>.GetInst().ObjectLoadAlready(loadInfo.GetPath()))
    //                    {
    //                        LoadHelp.LoadObject("", loadInfo.GetPath(), ThreadPriority.Normal, PreCreateAndEcploderLoadComplete);
    //                        m_preCreateAndExploderIndex++;
    //                    }

    //                    loadInfo = null;
    //                }
    //                if (m_preCreateAndExploderIndex > 0)
    //                {
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.Wait);
    //                }
    //                else
    //                {
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.PreCreateMonster);
    //                }
    //            }
    //            break;
    //        case eBattleSceneLoadingNPCAndDeploderState.PreCreateMonster:
    //            {
    //                if (m_preCreateMonsterDirect.Count <= 0)
    //                {
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.GetExploderType);
    //                    goto case eBattleSceneLoadingNPCAndDeploderState.GetExploderType;
    //                }

    //                MonsterContent loadInfo = null;

    //                List<uint> tempDeleteList = new List<uint>();

    //                foreach (KeyValuePair<uint, int> val in m_preCreateMonsterDirect)
    //                {
    //                    loadInfo = HolderManager.m_MonsterHolder.GetStaticInfo(val.Key);

    //                    if (loadInfo == null)
    //                    {
    //                        tempDeleteList.Add(val.Key);
    //                        continue;
    //                    }

    //                    if (SingletonObject<NpcFactory>.GetInst().GetLoadAlreadyCount(loadInfo.GetPath()) >= val.Value)
    //                    {
    //                        tempDeleteList.Add(val.Key);
    //                        continue;
    //                    }
    //                    else
    //                    {
    //                        break;
    //                    }
    //                }
    //                for (int i = 0, count = tempDeleteList.Count; i < count; i++)
    //                {
    //                    m_preCreateMonsterDirect.Remove(tempDeleteList[i]);
    //                }
    //                tempDeleteList.Clear();
    //            }
    //            break;
    //        case eBattleSceneLoadingNPCAndDeploderState.GetExploderType:
    //            {
    //                if (m_monsterlist.Count <= 0)
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.Complete);
    //                else
    //                {
    //                    MonsterContent loadInfo = HolderManager.m_MonsterHolder.GetStaticInfo(m_monsterlist[0]);

    //                    m_explorerList.AddRange(loadInfo.GetExploderType().Keys);


    //                    //m_currCloseMonster = SingletonObject<NpcFactory>.GetInst().PreCreate(loadInfo.GetPath());
    //                    //m_currExplorerMonsterID = m_monsterlist[0];

    //                    m_monsterlist.RemoveAt(0);
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.PreExploder);
    //                }
    //            }
    //            break;
    //        case eBattleSceneLoadingNPCAndDeploderState.PreExploder:
    //            {
    //                if (m_explorerList.Count <= 0)
    //                {
    //                    SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.GetExploderType);
    //                    goto case eBattleSceneLoadingNPCAndDeploderState.GetExploderType;
    //                }
    //                else
    //                {
    //                    eExploderType type = (eExploderType)m_explorerList[0];
    //                    m_currExplorerMonster = Object.Instantiate(m_currCloseMonster) as GameObject;
    //                    DynamicShader.ReplaceUnSupportShader(m_currExplorerMonster);
    //                    SingletonObject<CExploderManage>.GetInst().CreateExploder(m_currExplorerMonsterID, m_currExplorerMonster, type, eExploderMemoryType.DismemerMemory, 2.5f);
    //                    m_currExplorerMonster = null;
    //                    m_explorerList.RemoveAt(0);
    //                }
    //            }
    //            break;
    //        case eBattleSceneLoadingNPCAndDeploderState.Complete:
    //            {
    //                if (!ClientMain.GetInst().EnterTestScene)
    //                    SingletonObject<CExploderManage>.GetInst().StartUpdate(true, true);
    //                SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.None);
    //                return true;
    //            }
    //            break;
    //    }
    //    return false;
    //}

    //private void PreCreateAndEcploderLoadComplete(string interim, UnityEngine.Object asset)
    //{
    //    m_preCreateAndExploderLoadCount++;
    //    if (m_preCreateAndExploderLoadCount >= m_preCreateAndExploderIndex)
    //        SetPreCreateAndEcploderState(eBattleSceneLoadingNPCAndDeploderState.PreCreateMonster);
    //}


    //新手

    public uint mapSceneID
    {
        get { if (m_pSceneLoader == null) return 0; return (uint)m_pSceneLoader.Key; }
    }
}
