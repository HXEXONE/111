using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System;

//�첽���ع�����

public delegate void LoadDelegate(string interim, UnityEngine.Object asset);

public enum eLoadState
{
    LOADSTATE_NONE,
    LOADSTATE_READY,//׼��
    LOADSTATE_DOING,//LOADING��
    LOADSTATE_DOING_ENCRYPT,//LOADING��
    LOADSTATE_COMPLETED,//�������
}

public enum eLoadLevelState
{
    None = 0,
    Start,
    Loading,
    Completed,
}

public class stLoadInfo
{
    public string interim;
    public string originPath;//ԭʼ·��
    public string url;
    public string innerUrl;
    public LoadDelegate asset;
    public eLoadState loadState;
    public UnityEngine.Object obj;
    public float progress;
    public byte byErrorCount;//����ʧ�ܴ���
    public eLoadLevelState levelState;//���س���״̬

    public WWW wwwRequest;
    public AssetBundleCreateRequest abcRequest;
    public AssetBundle ab;

    public bool bDeterministic;//�Ƿ�������
    public bool bSaveInMemory;//�Ƿ񱣴����ڴ���
    public bool bScene;//�Ƿ񳡾�
}

public class LoadHelp 
{
    private static List<stLoadInfo> m_LoadInfoList = new List<stLoadInfo>();
    private static List<stLoadInfo> m_WaitingList = new List<stLoadInfo>();
    private static Dictionary<string, UnityEngine.Object> m_AssetBundleDict = new Dictionary<string, UnityEngine.Object>();
   
    private static List<stLoadInfo> m_deleteList = new List<stLoadInfo>();
    private static List<stLoadInfo> m_tempdeleteList = new List<stLoadInfo>();
    private static Dictionary<string, AssetBundle> m_DeterministicDict = new Dictionary<string, AssetBundle>();//��������洢

    private static bool m_bLocked = false;

    private static int m_length = 0;

    public static bool m_bUsePersistentDataPath = true;

    public static string persistentDataPath =  Application.persistentDataPath;

  
    //interim:�����ַ���,����һЩ���õĶ���
    public static void LoadObject(string interim, string path, ThreadPriority priority, LoadDelegate asset, bool bDeterministic = false,bool bSaveInMemory = true) 
    {
        if (string.IsNullOrEmpty(path) || path.Equals("0"))
        {
            return;
        }
        //path = path.Replace("\\", "/");
        //path = path.Replace("\r\n", "");
        //path = path.ToLower();

        if (bDeterministic && m_DeterministicDict.ContainsKey(path))
        { 
            //�����������UI��,����������Դ�ò���
            if (asset != null)
            {
                asset(interim, m_DeterministicDict[path].mainAsset);
            }
            return;
        }
        

        if (m_AssetBundleDict.ContainsKey(path))
        {
            UnityEngine.Object obj = m_AssetBundleDict[path];
            if (asset != null) asset(interim, obj);
            return;
        }

        string url = "";
        string innerUrl = string.Empty;
#if UNITY_FLASH
        url = ResourceManager.GetInstance().GetURL() + path + ".swf";
#elif UNITY_ANDROID
        if(Application.platform == RuntimePlatform.Android)
        {
            //url = "file://" + CAssetPackManager.GetInst().ExternalAssetPackPath + "/" + path + ".android";
            //url = "file://" + Common.persistentDataPath + "/" + path + ".android";
            //url = Application.streamingAssetsPath + "/" + path + ".android";
            url = persistentDataPath + "/" + path + ".android";
            //if (File.Exists(url) && m_bUsePersistentDataPath)
            if (m_bUsePersistentDataPath)
            {
                url = "file://" + url;
                innerUrl = Application.streamingAssetsPath + "/" + path + ".android";
            }
            else
            {
                url = Application.streamingAssetsPath + "/" + path + ".android";
            }
        	//url = System.IO.Path.Combine(Application.streamingAssetsPath,path );
            //MyLog.Log("~~~~~~~~~~~url = System.IO.Path.Combine(Application.streamingAssetsPath, path + .android);~~~~~~~~~~~~~~~~~~~~");
        }
        else
        {
            url = persistentDataPath + "/" + path + ".android";
            //if (File.Exists(url) && m_bUsePersistentDataPath)
            if (m_bUsePersistentDataPath)
            {
                url = "file:///" + url;
                innerUrl = "file:///" + Application.dataPath + "/StreamingAssets/" + path + ".android";
            }
            else
            {
                url = "file://" + Application.dataPath + "/StreamingAssets/" + path + ".android";
            }
            //url = "file://" + Application.dataPath + "/StreamingAssets/" + path + ".android";
            //MyLog.Log("~~~~~~~~~~~url = file:// + Application.dataPath + /StreamingAssets/ + path + .android~~~~~~~~~~~~~~~~~~~~");
        }
#elif UNITY_IPHONE
        url = persistentDataPath + "/" + path + ".iphone";
        //if (File.Exists(url) && m_bUsePersistentDataPath)
        if (m_bUsePersistentDataPath)
        {
            url = "file://" + url;
            innerUrl = "file://" + Application.streamingAssetsPath + "/" + path + ".iphone";
            innerUrl = System.Uri.EscapeUriString(innerUrl);
        }
        else
        {
            url = "file://" + Application.streamingAssetsPath + "/" + path + ".iphone";
            //url = "file://" + Common.persistentDataPath + "/" + path + ".iphone";
            //url = "file://" + Application.streamingAssetsPath + "/" + path + ".iphone";unity
            url = System.Uri.EscapeUriString(url);
        }
#else
        if ((Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.OSXPlayer)
            && File.Exists(Application.dataPath + "/" + path))
        {

            url = "file://" + Application.dataPath + "/" + path;
        }
        else
        {
            url = ClientConfig.ResourceIP + path;
        }

#endif
        stLoadInfo info = new stLoadInfo();
        info.interim = interim;
        info.originPath = path;
        info.url = url;
        info.innerUrl = innerUrl;
        info.asset = asset;
        info.loadState = eLoadState.LOADSTATE_READY;
        info.progress = 0;
        info.byErrorCount = 0;
        info.wwwRequest = null;
        info.abcRequest = null;
        info.levelState = eLoadLevelState.Start;
        info.bDeterministic = bDeterministic;
        info.bSaveInMemory = bSaveInMemory;
        info.bScene = path.Contains(".scene");

#if UNITY_STANDALONE || UNITY_STANDALONE_WIN
        //�����΢�˲��Ҵ��ڸ��ļ��Ļ����ӱ��ؼ��ص��ڴ���
        if ((Application.platform == RuntimePlatform.WindowsPlayer  || Application.platform == RuntimePlatform.OSXPlayer)
            && File.Exists(Application.dataPath + "/" + path)
            )
        {
			info.bLoadLocal = true;   
		}
#endif

        if (!IsExistSameUrl(path))
        {
            m_LoadInfoList.Add(info);

            CLoadingManager.GetInst().AddUrl(info);
        }
        else
        {
            if(asset != null)
            {
                //��ʱwaitlist���ڴ���ɾ�����Ӳ���,������
                m_WaitingList.Add(info);
                
            }
        }
    }

    public static void Update()
    {
        int connectNum = ClientConfig.APACHE_CONNECT_NUM;
        int loadInfoCount = (m_LoadInfoList.Count > connectNum ? connectNum :m_LoadInfoList.Count) ;
        stLoadInfo info;
        for (byte i = 0; i < loadInfoCount; ++i)
        {
            info = m_LoadInfoList[i];
            if (info != null)
            {
                switch (info.loadState)
                {
                    case eLoadState.LOADSTATE_READY:
                        {
                            string path;
                            if (info.byErrorCount > 0 && m_bUsePersistentDataPath)
                                path = info.innerUrl;
                            else
                                path = info.url;
                            info.wwwRequest = new WWW(path);

                            info.loadState = eLoadState.LOADSTATE_DOING;
                        }
                        break;
                    case eLoadState.LOADSTATE_DOING:
                        {
                            if (info.wwwRequest.isDone)
                            {
                                //m_length += info.wwwRequest.bytes.Length;
                                //MyLog.LogError("*******************************");
                                //MyLog.LogError("url = " + info.originPath +"Time:"+Time.time);
                                //MyLog.LogError("length = " + info.wwwRequest.bytes.Length / 1000);
                                // MyLog.LogError("total = " + m_length / 1000);
                               
                                if (info.wwwRequest.error != null)
                                {
                                    info.byErrorCount++;
                                    info.progress = 1;

                                    MyLog.DebugLogException("Load error..................Errpr Msg : " + info.wwwRequest.error + "     Url = " + info.url);
                                    if (info.asset != null)
                                        info.asset(info.interim, null);
                                    if (!m_deleteList.Contains(info))
                                    {
                                        m_deleteList.Add(info);
                                    }
                                    RemoveLoadInfo(info, true);

                                    info.loadState = eLoadState.LOADSTATE_NONE;

                                    info.wwwRequest.Dispose();
                                    info.wwwRequest = null;

                                    break;
                                }

                                info.ab = info.wwwRequest.assetBundle;

                                if (info.ab == null)//������
                                {
                                    byte[] bytes = info.wwwRequest.bytes;
                                    if (bytes == null)
                                    {
                                        MyLog.DebugLogException("Load error bytes == null............." + info.url);
                                        return;
                                    }
                                    AssetsEncrypt.EncryptBytes(bytes);
                                    info.abcRequest = AssetBundle.CreateFromMemory(bytes);
                                    info.loadState = eLoadState.LOADSTATE_DOING_ENCRYPT;
                                    return;
                                }
                                else
                                {
                                    info.loadState = eLoadState.LOADSTATE_COMPLETED;
                                }
                              
                            }
                            else
                            {
                                info.progress = info.wwwRequest.progress;
                              
                                if (info.progress >= 1) info.progress = 0.99f;
                            }
                        }
                        break;
                    case eLoadState.LOADSTATE_DOING_ENCRYPT:
                        {
                            if (info.abcRequest != null && info.abcRequest.isDone)
                            {
                                info.ab = info.abcRequest.assetBundle;

                                info.loadState = eLoadState.LOADSTATE_COMPLETED;
                            }
                        }
                        break;
                    case eLoadState.LOADSTATE_COMPLETED:
                        {
                            if (IsInitCompleted(info))
                            {
                                if (info.obj != null)
                                {
                                    if (info.bSaveInMemory)
                                    {
                                        if (!m_AssetBundleDict.ContainsKey(info.originPath))
                                        {
                                            m_AssetBundleDict.Add(info.originPath, info.obj);
                                        }
                                    }
                                   
                                    if (info.asset != null)
                                    {
                                        info.asset(info.interim, info.obj);
                                    }

                                }

                                if (info.bDeterministic)
                                {
                                    if (!m_DeterministicDict.ContainsKey(info.originPath))
                                    {
                                        m_DeterministicDict.Add(info.originPath, info.ab);
                                    }

                                }
                                else
                                {
                                    info.ab.Unload(false);
                                }


                                info.wwwRequest.Dispose();
                                info.wwwRequest = null;

                                RemoveLoadInfo(info, false);

                                if (!m_deleteList.Contains(info))
                                {
                                    m_deleteList.Add(info);
                                }
                                info.progress = 1;
                                info.loadState = eLoadState.LOADSTATE_NONE;
                            }

                            
                        }
                        break;
                }
            }
        }

        //2014��1��21���޸�
        for (int i = 0, count = m_deleteList.Count; i < count; i++)
        {
            m_LoadInfoList.Remove(m_deleteList[i]);
        }
        m_deleteList.Clear();
    }


    private static bool IsInitCompleted(stLoadInfo info)
    {
        if (info.bScene)
        {
            switch (info.levelState)
            {
                case eLoadLevelState.Start:
                    {
                        Application.LoadLevelAsync(Path.GetFileNameWithoutExtension(info.originPath));

                        info.levelState = eLoadLevelState.Loading;
                    }
                    break;
                case eLoadLevelState.Loading:
                    {
                        if (!Application.isLoadingLevel)
                        {
                            info.obj = GameObject.Find(Path.GetFileNameWithoutExtension(info.originPath));
                            info.levelState = eLoadLevelState.None;
                            return true;
                        }
                    }
                    break;
            }
            
        }
        else
        {
            if (info.ab != null)
            {
                if(!info.bDeterministic)
                    info.obj = info.ab.mainAsset;
            }
            else
            {
                info.wwwRequest.Dispose();
                info.wwwRequest = null;

                RemoveLoadInfo(info, false);

                if (!m_deleteList.Contains(info))
                {
                    m_deleteList.Add(info);
                }
                info.progress = 1;
                info.loadState = eLoadState.LOADSTATE_NONE;
                MyLog.DebugLogException("Load error info.ab == null............." + info.url);
                return false;
            }

            return true;
        }


        return false;
    }

    public static void RemoveLoadInfo(stLoadInfo info ,bool bError)
    {
        for (int i = 0, count = m_WaitingList.Count; i < count; ++i)
        {
            stLoadInfo loadinfo = m_WaitingList[i];
            if (loadinfo.originPath.Equals(info.originPath))
            {
                if (loadinfo.asset != null && !bError)
                {
                    loadinfo.asset(loadinfo.interim, info.obj);
                }
                else
                {
                    loadinfo.asset(loadinfo.interim, null);
                }
                m_tempdeleteList.Add(loadinfo);
            }
        }
        for (int i = 0, count = m_tempdeleteList.Count; i < count; ++i)
        {
            m_WaitingList.Remove(m_tempdeleteList[i]);
        }

        m_tempdeleteList.Clear();
    }

    public static bool IsExistSameUrl(string path)
    {
        for (int i = 0, count = m_LoadInfoList.Count; i < count;++i )
        {
            if (m_LoadInfoList[i].originPath.Equals(path))
            {
                return true;
            }
        }

        return false;
    }

    public static bool IsInMemory(string path)
    {
        return m_AssetBundleDict.ContainsKey(path);
    }

    public static bool IsSomethingInLoading()
    {
        return m_LoadInfoList.Count > 0;
    }

    public static void RemoveObject(string path, bool bDestroyObject = true)
    {
        if (m_AssetBundleDict.ContainsKey(path))
        {
            UnityEngine.Object obj = m_AssetBundleDict[path];
            if (obj != null)
            {
                if (bDestroyObject)
                {
                    if (path.Contains(".tex"))
                    {
                        UnityEngine.Object.DestroyImmediate(obj, true);
                    }
                    else if (path.Contains("/atlas/"))
                    {
                        GameObject o = (GameObject)obj;
                        UIAtlas atlas = o.GetComponent<UIAtlas>();
                        if (atlas != null)
                        {
                            UnityEngine.Object.DestroyImmediate(atlas.spriteMaterial.mainTexture, true);
                            UnityEngine.Object.DestroyImmediate(atlas.spriteMaterial, true);

                        }
                        UnityEngine.Object.DestroyImmediate(obj, true);
                    }
                    else
                    {
                        UnityEngine.Object.DestroyImmediate(obj, true);
                    }
                }
                
  
            }

            m_AssetBundleDict.Remove(path);
        }
    }

    //�����������б�
    public static void ClearDeterministicList()
    {
        List<string> deleteList = new List<string>();
        foreach (KeyValuePair<string, AssetBundle> kvp in m_DeterministicDict)
        {
            if (kvp.Key.Contains(".shader") /*|| kvp.Key.Contains(".mat")*/)
            {
                continue;
            }

            if (kvp.Value != null)
            {
                kvp.Value.Unload(false);
            }
            else
            {
                MyLog.LogError("assetbundle has already released!:" + kvp.Key);
            }

            deleteList.Add(kvp.Key);
            
        }

        foreach (string path in deleteList)
        {
            m_DeterministicDict.Remove(path);
        }

    }

    public static void RemoveDeterministic(string sPath)
    {
        foreach (KeyValuePair<string, AssetBundle> kvp in m_DeterministicDict)
        {
            if (kvp.Key.Equals(sPath))
            {
                kvp.Value.Unload(false);
                m_DeterministicDict.Remove(kvp.Key);
                break;
            }
        }
    }

    //ж�����е�ͷ�����Ʒͼ��
    public static void RemoveAllHeadAndItemIcon(string unreleaseStr = "")
    {
        List<string> deleteList = new List<string>();
        foreach (KeyValuePair<string, UnityEngine.Object> kvp in m_AssetBundleDict)
        {
            if (kvp.Key.Contains(DEFINE.DEFUALT_PARTNER_ICON_PATH))
            {
                deleteList.Add(kvp.Key);
            }
            if (kvp.Key.Contains(DEFINE.DEFUALT_ITEM_ICON_PATH))
            {
                if (!string.IsNullOrEmpty(unreleaseStr)) continue;
                deleteList.Add(kvp.Key);
            }
        }

        foreach (string path in deleteList)
        {
            RemoveObject(path);
        }

        //ж�����ֵĲ�����
        UITool.ReleaseShieldMaterial();
    }

    //ж�����е�����ͼ��
    public static void RemoveAllLongJingIcon(string unreleaseStr = "")
    {
        List<string> deleteList = new List<string>();
        foreach (KeyValuePair<string, UnityEngine.Object> kvp in m_AssetBundleDict)
        {
            if (kvp.Key.Contains(DEFINE.DEFULAT_LONGJING_ICON_PATH))
            {
                deleteList.Add(kvp.Key);
            }
        }

        foreach (string path in deleteList)
        {
            RemoveObject(path);
        }

        //ж�����ֵĲ�����
        UITool.ReleaseShieldMaterial();
    }

    /// <summary>
    /// ж��ĩ�ջ�Ұ�ݵ�ͼƬ
    /// </summary>
    public static void RemoveMoor()
    {
        List<string> deleteList = new List<string>();
        foreach (KeyValuePair<string, UnityEngine.Object> kvp in m_AssetBundleDict)
        {
            if (kvp.Key.Contains(DEFINE.DEFULAT_MOOR_ICON_PATH))
            {
                deleteList.Add(kvp.Key);
            }
        }

        foreach (string path in deleteList)
        {
            RemoveObject(path);
        }

        //ж�����ֵĲ�����
        UITool.ReleaseShieldMaterial();
    }

    //ж�����ж�����Դ
    public static void RemoveAllAnimator(string exceptAnimatorPath)
    {
        List<string> deleteList = new List<string>();
        foreach (KeyValuePair<string, UnityEngine.Object> kvp in m_AssetBundleDict)
        {
            if (kvp.Key.Equals(exceptAnimatorPath))
            {
                continue;
            }
            if (kvp.Key.Contains("_ctrl.x"))
            {
                deleteList.Add(kvp.Key);
            }
        }

        foreach (string path in deleteList)
        {
            RemoveObject(path);
        }
    }

}
