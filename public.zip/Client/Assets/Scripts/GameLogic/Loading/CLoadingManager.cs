using UnityEngine;
using System.Collections;

public enum eLoadingType
{
    NONE        = 0,
    LOGIN       = 1,
    GAME        = 2,
    BATTLE_SCENE = 3,//������������Դ�ֿ�����
    BATTLE      = 4,
    NGUI_ATLAS  = 5,
    CHOOSE_ROLE = 6,
    Home = 7,    //��԰����
    BattlePVE = 8,    //ս��PVEѡ��
    PrepareBattle =9,
}

public delegate void JumpLoadingCallback();

public class CLoadingManager : SingletonObject<CLoadingManager>
{
    private CLoadingBase m_LoadingBase;
    private eGameState m_lastGameState = eGameState.LOADING;

    private JumpLoadingCallback m_callback;
    public void StartAddUrl(CLoadingBase pLoadingBase,int apacheNum,bool bEnterLoading)
    {
        ClientConfig.APACHE_CONNECT_NUM = apacheNum;
//#if UNITY_EDITOR
//        ClientConfig.APACHE_CONNECT_NUM = 100;
//#else
//        ClientConfig.APACHE_CONNECT_NUM = apacheNum;
//#endif
        m_LoadingBase = pLoadingBase;
        m_LoadingBase.StartAddUrl(bEnterLoading);

        if (bEnterLoading)
        {
            m_lastGameState =ClientMain.GetInst().GetCurrentState();
            if (m_lastGameState != eGameState.LOADING)
            {
                ClientMain.GetInst().SetGameState(eGameState.LOADING);
            }

            
        }
        
    }

    public string CurrloadingType
    {
        get
        {
            if(null == m_LoadingBase)
            {
                return "";
            }
            return m_LoadingBase.GetType().ToString();
        }
    }

    public void EndAddUrl()
    {
        if (m_LoadingBase != null)
        {
            m_LoadingBase.EndAddUrl();
        }

    }

    public void AddUrl(stLoadInfo info)
    {
        if (m_LoadingBase == null)
        {
            return;
        }

         m_LoadingBase.AddUrl(info);
    }

	public float GetProgress()
    {
        if (null == m_LoadingBase) return 0;
        return m_LoadingBase.GetProgress();
    }

    public void Release()
    {
        m_LoadingBase = null;
        ClientConfig.APACHE_CONNECT_NUM = 20;

    }

    public void Update()
    {
        if(m_LoadingBase == null)
        {
            return;
        }
        m_LoadingBase.UpdateProgress();
    }

    private eGameState m_beforeState;
    public eGameState GetBeforeState() { return m_beforeState; }
    private eGameState m_afterState;
    private bool m_enterLoading = true;
    //��ת����
    public void JumpTo(eGameState currState, eGameState nextState, eBattleType type,JumpLoadingCallback callback,bool enterLoading = true,string arg = "0")
    {
        if (nextState == eGameState.WorldMap && !arg.Equals("0"))
        {
            uint chapter = MyConvert_Convert.ToUInt32(arg);
            if (UpdateManager.GetInst().CheckMapChapterNeedUpdate(chapter, null))//CheckMapChapterUpdateCallback))
            {
                //SingletonObject<UIManager>.GetInst().CloseAllWnd();
                return;
            }
        }


        m_callback = callback;
        if (string.IsNullOrEmpty(arg))
            arg = "0";

        m_beforeState = currState;
        m_afterState = nextState;
        m_enterLoading = enterLoading;
        if (enterLoading)
        {
            string texturePath = "";
            switch (nextState)
            {
                case eGameState.Battle:
                    {
                        switch (type)
                        {
                            case eBattleType.PVE:
                                {
                                    texturePath = DEFINE.LOADING_PVE_TEXTURE;
                                }
                                break;
                            case eBattleType.Arena:
                                {
                                    texturePath = DEFINE.LOADING_ARENA_TEXTURE;
                                }
                                break;
                            case eBattleType.Protect:
                                {
                                    texturePath = DEFINE.LOADING_ESCORT_TEXTURE;
                                }
                                break;
                            case eBattleType.Escort:                                
                                {
                                    texturePath = DEFINE.LOADING_ESCORT_TEXTURE;
                                }
                                break;
                            case eBattleType.Wasteland:
                                {
                                    texturePath = DEFINE.LOADING_WASTELAND_TEXTURE;
                                }
                                break;
                            case eBattleType.Mining:
                                {
                                    texturePath = DEFINE.LOADING_MINING_TEXTURE;
                                }
                                break;
                            case eBattleType.GlobalBoss:
                                {
                                    texturePath = DEFINE.LOADING_GLOBALBOSS_TEXTURE;
                                }
                                break;
                            case eBattleType.TeamPve:
                                {
                                    texturePath = DEFINE.LOADING_TEAMPVE_TEXTURE;
                                }
                                break;
                            case eBattleType.Pvp:
                                {
                                    texturePath = DEFINE.LOADING_WASTELAND_TEXTURE;
                                }
                                break;
                            case eBattleType.MultiPve:
                                {
                                    texturePath = DEFINE.LOADING_WASTELAND_TEXTURE;
                                }
                                break;
                            case eBattleType.ClimbTower:
                                {
                                    texturePath = DEFINE.LOADING_TOWER_TEXTURE;
                                }
                                break;
                        }
                        CLoadingCommon.PreloadAtlas("atlas_ui_battles1_v2");
                    }
                    break;
                case eGameState.ChooseRole:
                    {
                        texturePath = DEFINE.LOADING_DEFAULT_TEXTURE;
                        CLoadingCommon.PreloadAtlas("atlas_ui_login1_v2");
                    }
                    break;
                case eGameState.ArenaUI:
                    {
                        texturePath = DEFINE.LOADING_ARENA_TEXTURE;
                        CLoadingCommon.PreloadAtlas("atlas_ui_arena1_v2");
                    }
                    break;
                case eGameState.Home:
                    {
                        texturePath = DEFINE.LOADING_DEFAULT_TEXTURE;
                        CLoadingCommon.PreloadAtlas("atlas_ui_city1_v2");
                    }
                    break;
                case eGameState.WorldMap:
                    {
                        texturePath = DEFINE.LOADING_DEFAULT_TEXTURE;
                        CLoadingCommon.PreloadAtlas("atlas_ui_level1_v2");
                        SingletonObject<WorldAreaMapMediator>.GetInst().PreloadTexture();
                    }
                    break;
                default:
                    {
                        texturePath = DEFINE.LOADING_DEFAULT_TEXTURE;
                    }
                    break;
            }

            //SingletonObject<UIParticleSystemFactory>.GetInst().ClearAllMemory();

            SingletonObject<LoadingMediator>.GetInst().SetBGPath(texturePath, StartCallBack);

            
            //ImageEffectManager.GetInst().CloseEffect(eImageEffect.FastBlur, null, true);

            CLoadingBase.ClearAssets();
        }


        if (!enterLoading)
        {
            Resources.UnloadUnusedAssets();
            StartCallBack();
        }

        MaiDianManager.GetInst().SetLoadingMD(m_afterState);
    }

    
    private void StartCallBack()
    {
        if (m_callback != null)
        {
            switch (m_beforeState)
            {
                case eGameState.Home:
                    {
                        if (m_afterState != eGameState.WorldMap)
                            CLoadingCommon.ReleaseAtlas("atlas_ui_city1_v2");
                    }
                    break;
                case eGameState.WorldMap:
                    {
                        if (m_enterLoading)
                        {
                            SingletonObject<WorldAreaMapMediator>.GetInst().ReleaseTexture();
                            CLoadingCommon.ReleaseAtlas("atlas_ui_level1_v2");
                            if (m_afterState != eGameState.Home)
                            {
                                CLoadingCommon.ReleaseAtlas("atlas_ui_city1_v2");

                            }

                        }

                    }
                    break;
                case eGameState.Battle:
                    {
                        CLoadingCommon.ReleaseAtlas("atlas_ui_battles1_v2");
                    }
                    break;
                case eGameState.ChooseRole:
                    {
                        CLoadingCommon.ReleaseAtlas("atlas_ui_login1_v2");
                        CLoadingCommon.ReleaseAtlas("atlas_ui_level1_v2");
                    }
                    break;
                case eGameState.ArenaUI:
                    {
                        CLoadingCommon.ReleaseAtlas("atlas_ui_arena1_v2");
                        CLoadingCommon.ReleaseAtlas("atlas_ui_battles1_v2");
                    }
                    break;
            }
            m_callback();
        }
        if(m_enterLoading)
            LoadHelp.RemoveAllHeadAndItemIcon();
    }

    private void CheckMapChapterUpdateCallback(object parm)
    {
        SingletonObject<UIManager>.GetInst().OpenCurrentWnd();
    }
}
