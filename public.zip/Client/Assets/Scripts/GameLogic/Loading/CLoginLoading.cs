﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//using System.IO;
//using System.Text;


public class CLoginLoading : CBaseSceneLoading
{

    public AudioClip clip;

    protected override CBaseScene InitScene()
    {
        AccountScene pScene = SingletonObject<AccountScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key);
        return pScene;
    }

    public override float GetProgress()
    {
        float progress = base.GetProgress();

        return 0.6f + progress * 0.3f;
    }

    protected override void LoadSceneCompleted()
    {
        SingletonObject<CAtlasLoading>.GetInst().StartLoading();
        CDNData.GetInst().RequestNotice();
        //CMusicManager.GetInst().CreateSound(DEFINE.UI_CLICK_SOUNDID);
        SingletonObject<LoadingCircleMediator>.GetInst().PreloadUI();
        SingletonObject<LoginMediator>.GetInst().PreloadUI();
        SingletonObject<ServerListMediator>.GetInst().PreloadUI();
        SingletonObject<PopFrameMediator>.GetInst().PreloadUI();
        SingletonObject<SelectRoleMediator>.GetInst().PreloadUI();

        SingletonObject<CAtlasLoading>.GetInst().EndLoading();


    }

    public void LoadUIClick(uint dwSoundID,bool bSaveInMemory)
    {


        AudioContent  m_pAudioInfo = HolderManager.m_AudioHolder.GetStaticInfo(dwSoundID);
        if (null == m_pAudioInfo)
        {
            MyLog.LogError("can't find audio:" + dwSoundID);
        }
        //m_AudioSource.loop = m_pAudioInfo.IsLoop();


        LoadHelp.LoadObject("", m_pAudioInfo.Path, ThreadPriority.Normal, LoadSoundCompleted, false, bSaveInMemory);
        
    }

    private void LoadSoundCompleted(string interim, UnityEngine.Object asset)
    {
        if (null == asset) return;

        clip = asset as AudioClip;


 
    }
}
