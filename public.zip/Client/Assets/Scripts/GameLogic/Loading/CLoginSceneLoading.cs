﻿using UnityEngine;
using System.Collections;

public class CSelectAvatarLoading : CBaseSceneLoading
{
    protected override CBaseScene InitScene()
    {
        LoginScene pScene = SingletonObject<LoginScene>.GetInst();
        pScene.Init((uint)m_pSceneLoader.Key);
        return pScene;
    }

    protected override void OtherLoadings()
    {
        base.OtherLoadings();

        //预加载登录特效资源
        PreloadEffect(DEFINE.LOGIN_GROUD);
        PreloadEffect(DEFINE.LOGIN_CK_L_WEA);
        PreloadEffect(DEFINE.LOGIN_CK_R_WEA);
        PreloadEffect(DEFINE.LOGIN_CK_STP);
        PreloadEffect(DEFINE.LOGIN_FS_R_WEA);
        PreloadEffect(DEFINE.LOGIN_FS_STP_T);
        PreloadEffect(DEFINE.LOGIN_FS_STP_O);
        PreloadEffect(DEFINE.LOGIN_FS_HAND);
        PreloadEffect(DEFINE.LOGIN_KZS_R_WEA);
        PreloadEffect(DEFINE.LOGIN_KZS_STP);
        PreloadEffect(DEFINE.LOGIN_SWS_R_WEA);
        PreloadEffect(DEFINE.LOGIN_SWS_STP_O);
        PreloadEffect(DEFINE.LOGIN_SWS_STP_T);

        PreloadAvatar(DEFINE.JOB_ID_CHIKE, true);
        PreloadAvatar(DEFINE.JOB_ID_FASHI, true);
        PreloadAvatar(DEFINE.JOB_ID_KUANGZHANSHI, true);
        PreloadAvatar(DEFINE.JOB_ID_SHENGWUSHI, true);

    }
    protected override void LoadSceneCompleted()
    {
        ClientMain.GetInst().SetGameState(eGameState.ChooseRole);
    }

}
