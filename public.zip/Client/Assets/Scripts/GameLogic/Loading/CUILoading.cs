using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//using System.IO;
//using System.Text;


public class CUILoading : CLoadingCommon
{
    public void StartAddUrl()
    {
        CLoadingManager.GetInst().StartAddUrl(this,10, false);
    }

    public void EndAddUrl()
    {
        CLoadingManager.GetInst().EndAddUrl();
    }
}
