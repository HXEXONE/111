﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public delegate void SceneLoadingCallback();
public struct stSceneStep
{
    public float process;
    public SceneLoadingCallback callback;
}

public class stSceneDynamicInfo
{
    public List<int> m_idList;
    public string path;
    public UnityEngine.Object obj;
}

public abstract class CBaseSceneLoading : CLoadingCommon
{
    private byte m_byStep;
    private float m_sceneProcess;
    private float m_sceneCumulateprocess;//累积的进度
    protected SceneContent m_pSceneLoader;
    public SceneContent SceneLoader { get { return m_pSceneLoader; } }
    protected SceneInfoContent m_pSceneInfoLoader;
    public SceneInfoContent SceneInfoLoader{get { return m_pSceneInfoLoader; }}
    protected string m_SceneName;

    private List<string> m_textureList = new List<string>();
    private List<string> m_shaderList = new List<string>();
    private List<string> m_materialList = new List<string>();
    private List<string> m_fbxList = new List<string>();

    private List<stSceneStep> m_sceneSteps = new List<stSceneStep>();

    private Dictionary<string, DynamicDependenciesHolder> m_dynamicLoaderDict = new Dictionary<string, DynamicDependenciesHolder>();//动态物体依赖配置,常驻内存
    private Dictionary<string, SceneConfigHolder> m_sceneConfigDict = new Dictionary<string, SceneConfigHolder>();//场景动态物体分布配置,常驻内存
    //private Dictionary<string, SceneDependenciesHolder> m_allsceneDict = new Dictionary<string, SceneDependenciesHolder>();//场景依赖配置,常驻内存

    private List<stSceneDynamicInfo> m_dynamicList = new List<stSceneDynamicInfo>();
    private GameObject m_sceneObject;
    private Dictionary<string, List<GameObject>> m_bantchObjects = new Dictionary<string, List<GameObject>>();


    public static AudioSource[] EVNAudios; //环境音效

    private Dictionary<string, Transform> m_faterTrans = new Dictionary<string, Transform>();//动态物体的父物体

    public override float GetProgress()
    {
        return (float)Math.Round(m_sceneProcess,4);
    }

    private bool m_bEnterLoading;

    private CBaseScene m_baseScene;


    private void AddStep(float process, SceneLoadingCallback callback)
    {
        stSceneStep pStep = new stSceneStep();
        pStep.process = process;
        pStep.callback = callback;

        m_sceneSteps.Add(pStep);
    }

    public virtual void EnterScene(uint uiSceneID,bool bEnterLoading = true)
    {
        //MyLog.Log("-----------------------------EnterScene--------------" + uiSceneID+"--------" + Time.time);
        m_pSceneLoader = HolderManager.m_SceneHolder.GetStaticInfo(uiSceneID);
        if( null == m_pSceneLoader)
        {
            return;
        }

        m_byStep = 0;
        m_sceneProcess = 0;
        m_sceneCumulateprocess = 0;
        m_bEnterLoading = bEnterLoading;

        if (m_sceneSteps.Count <= 0)
        {
            AddStep(0.1f, LoadConfig);
            AddStep(0.05f, LoadDynamicConfig);
            AddStep(0.10f, LoadTexture);
            AddStep(0.05f, LoadShader);
            AddStep(0.05f, LoadMaterial);
            //AddStep(0.05f, LoadFbx);
            AddStep(0.15f, LoadScene);
            AddStep(0.25f, LoadDynamic);
            AddStep(0.15f, LoadOther);
            //最后10%留给后期处理
        }

        LoadStep();

    }

    protected override void Loading()
    {   
        if (m_byStep >= m_sceneSteps.Count)
        {
            return;
        }
        stSceneStep pStep = m_sceneSteps[m_byStep];

        float sceneProcess = m_sceneCumulateprocess + m_TotalProgress * pStep.process;
        if (sceneProcess > m_sceneProcess) m_sceneProcess = sceneProcess;
    }

    protected override void LoadingCompleted()
    {
        base.LoadingCompleted();

        if (m_byStep >= m_sceneSteps.Count)
        {
            return;
        }
        stSceneStep pStep = m_sceneSteps[m_byStep];
        m_sceneCumulateprocess += pStep.process;
        m_byStep++;

        if (m_byStep >= m_sceneSteps.Count)
        {
            LoadOver();
        }
        else
        {
            LoadStep();
        }
    }

    private void LoadStep()
    {
        if (m_byStep >= m_sceneSteps.Count)
        {
            return;
        }
        stSceneStep pStep = m_sceneSteps[m_byStep];
        pStep.callback();
    }


    private void LoadConfig()
    {
        //MyLog.Log("-----------------------------LoadConfig--------------" + Time.time);
        if (null == m_pSceneLoader)
        {
            return;
        }
        CLoadingManager.GetInst().StartAddUrl(this, 20, m_bEnterLoading);
        uint mapinfoID = (uint)m_pSceneLoader.MapInfo;
        m_pSceneInfoLoader = HolderManager.m_SceneInfoHolder.GetStaticInfo(mapinfoID);
        if (null == m_pSceneInfoLoader)
        {
            return;
        }
        m_SceneName = m_pSceneInfoLoader.Path;

        if (!m_sceneConfigDict.ContainsKey(m_SceneName))
        {
            m_sceneConfigDict.Add(m_SceneName, null);
            LoadHelp.LoadObject(m_SceneName, "resources/scenes/config/sceneconfig/" + m_SceneName + ".config", ThreadPriority.Normal, LoadSceneConfigCompleted, false, false);
        }


        //预加载UDT
        if (m_pSceneLoader.WinCondition != 0)
            LoadHelp.LoadObject("", "resources/scenes/udt/" + m_SceneName + "_udt.x", ThreadPriority.Normal, null, false, true);
        //if (!m_allsceneDict.ContainsKey(m_SceneName))
        //{
        //    m_allsceneDict.Add(m_SceneName, null);
        //    LoadHelp.LoadObject(m_SceneName, "resources/scenes/config/scenedependencies/" + m_SceneName + ".config", ThreadPriority.Normal, LoadAllSceneCompleted, false, false);
        //}
        
        CLoadingManager.GetInst().EndAddUrl();
    }

    private void LoadSceneConfigCompleted(string interim, UnityEngine.Object asset)
    {
        SceneConfigHolder holder = asset as SceneConfigHolder;
        if (m_sceneConfigDict.ContainsKey(interim))
        {
            m_sceneConfigDict[interim] = holder;
        }
    }

    //private void LoadAllSceneCompleted(string interim, UnityEngine.Object asset)
    //{
    //    SceneDependenciesHolder holder = asset as SceneDependenciesHolder;

    //    if (m_allsceneDict.ContainsKey(interim))
    //    {
    //        m_allsceneDict[interim] = holder;
    //    }
    //}

    private void LoadDynamicConfig()
    {
        //MyLog.Log("-----------------------------LoadDynamicConfig--------------" + Time.time);
        if (!m_sceneConfigDict.ContainsKey(m_SceneName))
        {
            MyLog.LogError("LoadDynamicConfig error:" + m_SceneName);
            return;
        }
        CLoadingManager.GetInst().StartAddUrl(this, 50, false);
       SceneConfigHolder loaders = m_sceneConfigDict[m_SceneName];

        if (null != loaders && null != loaders.content)
        {
            for (int i = 0, len = loaders.content.Count; i < len; ++i)
            {
                string fileName = loaders.content[i].sName;
                if (m_dynamicLoaderDict.ContainsKey(fileName))
                {
                    continue;
                }
                m_dynamicLoaderDict.Add(fileName, null);//预先加进去
                LoadHelp.LoadObject(fileName, "resources/scenes/config/dynamicdependencies/" + fileName + ".config", ThreadPriority.Normal, LoadAllDynamicCompleted, false, false);
            }
        }
        
        CLoadingManager.GetInst().EndAddUrl();
    }

    private void LoadAllDynamicCompleted(string interim, UnityEngine.Object asset)
    {
        DynamicDependenciesHolder holder = asset as DynamicDependenciesHolder;

        if (m_dynamicLoaderDict.ContainsKey(interim))
        {
            m_dynamicLoaderDict[interim] = holder;
        }
    }

    private void LoadTexture()
    {
        //if (!m_allsceneDict.ContainsKey(m_SceneName))
        //{
        //    MyLog.LogError("LoadTexture error,m_allsceneDict don't has key:" + m_SceneName);
        //    return;
        //}
        //MyLog.Log("-----------------------------LoadTexture--------------" + Time.time);
        CLoadingManager.GetInst().StartAddUrl(this, 50, false);

        //加载场景依赖资源
        //SceneDependenciesHolder allSceneLoader = m_allsceneDict[m_SceneName];

        m_textureList.Clear();

        //List<string> textures = allSceneLoader.textureList;
        //for (int i = 0, count = textures.Count; i < count; ++i)
        //{
        //    string texture = textures[i];
        //    if (texture.Equals("0"))
        //    {
        //        continue;
        //    }

        //    if (!m_textureList.Contains(texture))
        //    {
        //        m_textureList.Add(texture);
        //    }
        //}

        List<string> textures;
        //加载动态物体依赖资源
        foreach (KeyValuePair<string, DynamicDependenciesHolder> kvp in m_dynamicLoaderDict)
        {
            if (kvp.Value == null) continue;
            textures = kvp.Value.textureList;
            if (null == textures) continue;
            for (int j = 0, count2 = textures.Count; j < count2; ++j)
            {
                string texture = textures[j];
                if (texture.Equals("0"))
                {
                    continue;
                }

                if (!m_textureList.Contains(texture))
                {
                    m_textureList.Add(texture);
                }
            }
        }

        for (int i = 0, count = m_textureList.Count; i < count; ++i)
        {
            LoadHelp.LoadObject("", "resources/scenes/texture/" + m_textureList[i] + ".tex", ThreadPriority.Normal, null, true, false);
        }

        CLoadingManager.GetInst().EndAddUrl();
    }


    private void LoadShader()
    {
        //if (!m_allsceneDict.ContainsKey(m_SceneName))
        //{
        //    MyLog.LogError("LoadShader error,m_allsceneDict don't has key:" + m_SceneName);
        //    return;
        //}
        //SceneDependenciesHolder allSceneLoader = m_allsceneDict[m_SceneName];

        CLoadingManager.GetInst().StartAddUrl(this, 50, false);

        m_shaderList.Clear();

        //List<string> shaders = allSceneLoader.shaderList;
        //for (int i = 0, count = shaders.Count; i < count; ++i)
        //{
        //    string shader = shaders[i];
        //    if (shader.Equals("0"))
        //    {
        //        continue;
        //    }

        //    if (!m_shaderList.Contains(shader))
        //    {
        //        m_shaderList.Add(shader);
        //    }
        //}

        List<string> shaders;
        foreach (KeyValuePair<string, DynamicDependenciesHolder> kvp in m_dynamicLoaderDict)
        {
            if (kvp.Value == null) continue;
            shaders = kvp.Value.shaderList;
            if (null == shaders) continue;
            for (int j = 0, count2 = shaders.Count; j < count2; ++j)
            {
                string shader = shaders[j];

                if (shader.Equals("0"))
                {
                    continue;
                }

                if (!m_shaderList.Contains(shader))
                {
                    m_shaderList.Add(shader);
                }
            }
        }

        for (int i = 0, count = m_shaderList.Count; i < count; ++i)
        {
            LoadHelp.LoadObject("", "resources/scenes/shader/" + m_shaderList[i] + ".shader", ThreadPriority.Normal, null, true, false);
        }

        CLoadingManager.GetInst().EndAddUrl();
    }

    private void LoadMaterial()
    {
        //if (!m_allsceneDict.ContainsKey(m_SceneName))
        //{
        //    MyLog.LogError("LoadShader error,m_allsceneDict don't has key:" + m_SceneName);
        //    return;
        //}
        //SceneDependenciesHolder allSceneLoader = m_allsceneDict[m_SceneName];

        CLoadingManager.GetInst().StartAddUrl(this, 50, false);

        m_materialList.Clear();

        //List<string> materials = allSceneLoader.materialList;
        //for (int i = 0, count = materials.Count; i < count; ++i)
        //{
        //    string material = materials[i];
        //    if (material.Equals("0"))
        //    {
        //        continue;
        //    }

        //    if (!m_materialList.Contains(material))
        //    {
        //        m_materialList.Add(material);
        //    }

        //}

        List<string> materials;
        foreach (KeyValuePair<string, DynamicDependenciesHolder> kvp in m_dynamicLoaderDict)
        {
            if (null == kvp.Value) continue;
            materials = kvp.Value.materialList;
            if (null == materials) continue;
            for (int j = 0, count2 = materials.Count; j < count2; ++j)
            {
                string material = materials[j];
                if (material.Equals("0"))
                {
                    continue;
                }

                if (!m_materialList.Contains(material))
                {
                    m_materialList.Add(material);
                }
            }
        }

        for (int i = 0, count = m_materialList.Count; i < count; ++i)
        {
            LoadHelp.LoadObject("", "resources/scenes/fbx/materials/" + m_materialList[i] + ".mat", ThreadPriority.Normal, null, true, false);
        }

        CLoadingManager.GetInst().EndAddUrl();

    }

    //private void LoadFbx()
    //{
    //    if (!m_allsceneDict.ContainsKey(m_SceneName))
    //    {
    //        MyLog.LogError("LoadFbx error,m_allsceneDict don't has key:" + m_SceneName);
    //        return;
    //    }
    //    CAllSceneLoader allSceneLoader = m_allsceneDict[m_SceneName];

    //    CLoadingManager.GetInst().StartAddUrl(this, 50, false);

    //    m_fbxList.Clear();

    //    List<string> fbxs = allSceneLoader.GetModelList();
    //    for (int i = 0, count = fbxs.Count; i < count; ++i)
    //    {
    //        string fbx = fbxs[i];
    //        if (fbx.Equals("0"))
    //        {
    //            continue;
    //        }

    //        if (!m_fbxList.Contains(fbx))
    //        {
    //            m_fbxList.Add(fbx);
    //        }
    //    }

    //    foreach (KeyValuePair<string, CAllDynamicLoader> kvp in m_dynamicLoaderDict)
    //    {
    //        fbxs = kvp.Value.GetModelList();

    //        for (int j = 0, count2 = fbxs.Count; j < count2; ++j)
    //        {
    //            string fbx = fbxs[j];
    //            if (fbx.Equals("0"))
    //            {
    //                continue;
    //            }

    //            if (!m_fbxList.Contains(fbx))
    //            {
    //                m_fbxList.Add(fbx);
    //            }

    //        }
    //    }

    //    for (int i = 0, count = m_fbxList.Count; i < count; ++i)
    //    {
    //        LoadHelp.LoadObject("", "resources/scenes/fbx/" + m_fbxList[i] + ".fbx", ThreadPriority.Normal, null, true, false);
    //    }

    //    CLoadingManager.GetInst().EndAddUrl();
    //}

    private void LoadScene()
    {
        //MyLog.Log("-----------------------------LoadScene--------------" + Time.time + "..." + m_sceneProcess);
        CLoadingManager.GetInst().StartAddUrl(this, 3, false);
        m_baseScene = InitScene();
        CLoadingManager.GetInst().EndAddUrl();
    }

    protected abstract CBaseScene InitScene();

    private void LoadDynamic()
    {
         if (!m_sceneConfigDict.ContainsKey(m_SceneName))
        {
            MyLog.LogError("LoadDynamic error:" + m_SceneName);
            return;
        }
        SceneConfigHolder loaders = m_sceneConfigDict[m_SceneName];

        //MyLog.Log("-----------------------------LoadDynamic--------------" + Time.time + "..." + m_sceneProcess);
        CLoadingManager.GetInst().StartAddUrl(this, 50, false);

        //m_sceneObject = GameObject.Find(m_pSceneLoader.GetPath());

        m_sceneObject = m_baseScene.GetSceneObj();

        if (null != m_sceneObject && null != m_faterTrans)
        {
            m_faterTrans.Clear();
            m_faterTrans.Add("adorneffect", m_sceneObject.transform.Find("DynamicObject/AdornEffect"));
            m_faterTrans.Add("building", m_sceneObject.transform.Find("DynamicObject/Building"));
            m_faterTrans.Add("grass", m_sceneObject.transform.Find("DynamicObject/Grass"));
            m_faterTrans.Add("gut", m_sceneObject.transform.Find("DynamicObject/GUT"));
            m_faterTrans.Add("other", m_sceneObject.transform.Find("DynamicObject/Other"));
            m_faterTrans.Add("tree", m_sceneObject.transform.Find("DynamicObject/Tree"));
            m_faterTrans.Add("usableeffect", m_sceneObject.transform.Find("DynamicObject/UsableEffect"));
            m_faterTrans.Add("weather", m_sceneObject.transform.Find("DynamicObject/Weather"));
            m_faterTrans.Add("terrain", m_sceneObject.transform.Find("DynamicObject/Terrain"));
            m_faterTrans.Add("mechanism", m_sceneObject.transform.Find("DynamicObject/Mechanism"));
        }
        

        string dynamicPath;
        bool bFind = false;
        m_dynamicList.Clear();
        if (null != loaders && null != loaders.content)
        {
            for (int i = 0, len = loaders.content.Count; i < len; ++i)
            {
                dynamicPath = "resources/scenes/prefab/" + loaders.content[i].sParentName + "/" + loaders.content[i].sName + ".x";
                bFind = false;
                for (int j = 0, count = m_dynamicList.Count; j < count; ++j)
                {
                    if (m_dynamicList[j].path.Equals(dynamicPath))
                    {
                        m_dynamicList[j].m_idList.Add(i);
                        bFind = true;
                        break;
                    }
                }

                if (!bFind)
                {
                    stSceneDynamicInfo info = new stSceneDynamicInfo();
                    info.path = dynamicPath;
                    info.m_idList = new List<int>();
                    info.m_idList.Add(i);
                    m_dynamicList.Add(info);

                    LoadHelp.LoadObject(dynamicPath, dynamicPath, ThreadPriority.Normal, LoadDynamicCompleted, false, false);
                }
            }
        }
        

        CLoadingManager.GetInst().EndAddUrl();
    }

    private void LoadDynamicCompleted(string interim, UnityEngine.Object asset)
    {
        for (int i = 0, count = m_dynamicList.Count; i < count; ++i)
        {
            if (m_dynamicList[i].path.Equals(interim))
            {
                m_dynamicList[i].obj = asset;
            }
        }

    }

    private void CreateDynamic()
    {
        if (!m_sceneConfigDict.ContainsKey(m_SceneName))
        {
            MyLog.LogError("CreateDynamic error:" + m_SceneName);
            return;
        }

        foreach (stSceneDynamicInfo info in m_dynamicList)
        {
            for (int i = 0, count = info.m_idList.Count; i < count; ++i)
            {
                SceneConfigHolder loaders = m_sceneConfigDict[m_SceneName];
                int uiId = info.m_idList[i];
                if (uiId >= loaders.content.Count)
                {
                    continue;
                }

                if (info.obj == null)
                {
                    continue;
                }

                SceneConfigElement pSceneConfigLoader = loaders.content[uiId];

                string fatherName = pSceneConfigLoader.sParentName;

                Transform fatherTran = null;
                m_faterTrans.TryGetValue(fatherName, out fatherTran);

                GameObject o = (GameObject)UnityEngine.Object.Instantiate(info.obj);
                o.transform.parent = fatherTran;
                o.transform.localPosition = pSceneConfigLoader.position;
                o.transform.localRotation = Quaternion.Euler(pSceneConfigLoader.rotation);
                o.transform.localScale = pSceneConfigLoader.scale;

                List<int> lightIndex = pSceneConfigLoader.lightmapIndex;
                List<Vector4> lightOffset = pSceneConfigLoader.lightmapOffset;

                if (fatherName.Equals("adorneffect"))
                {
                    //Renderer[] rs = o.GetComponentsInChildren<Renderer>();
                    //for (int j = 0, len = rs.Length; j < len; ++j)
                    //{
                    //    rs[j].gameObject.AddComponent<SceneDynamicHide>();
                    //}
                }
                else
                {
                    if (!fatherName.Equals("gut") && !o.name.Equals("jingjichang_yuantai_zhujue(Clone)"))
                    {
                        if (m_bantchObjects.ContainsKey(fatherName))
                        {
                            List<GameObject> list = m_bantchObjects[fatherName];
                            if (list == null) list = new List<GameObject>();

                            list.Add(o);
                        }
                        else
                        {
                            List<GameObject> list = new List<GameObject>();
                            list.Add(o);
                            m_bantchObjects.Add(fatherName, list);
                        }
                    }

                    MeshRenderer[] mrs = o.GetComponentsInChildren<MeshRenderer>();
                    for (int j = 0, length = mrs.Length; j < length; ++j)
                    {
                        if (j >= lightIndex.Count)
                        {
                            MyLog.LogError("dynamic object:" + o.name + "has no lightindex");
                            break;
                        }
                        mrs[j].lightmapIndex = lightIndex[j];
                        mrs[j].lightmapTilingOffset = lightOffset[j];
                    }
                }

                DynamicShader.ReplaceUnSupportShader(o);
            }
        }
        GameObject dynamicObj = GameObject.Find("DynamicObject");
        if (null != dynamicObj)
        {
            EVNAudios = dynamicObj.GetComponentsInChildren<AudioSource>();

            CMusicManager.EVNSoundEnabled = CMusicManager.GetInst().SoundEnabled;
        }        
    }


    protected virtual void OtherLoadings()
    {
        
    }


    private void LoadOther()
    {
        //MyLog.Log("-----------------------------OtherLoadings--------------" + Time.time + "..." + m_sceneProcess);
        CLoadingManager.GetInst().StartAddUrl(this, 20, false);
        OtherLoadings();
        CLoadingManager.GetInst().EndAddUrl();
    }

    public void Combine()
    {
        //将所有静态物体的网格连接起来
        if (m_pSceneLoader.Key != DEFINE.SELECT_AVATAR_SCENE_ID)
        {
            if (m_sceneObject != null)
            {
                //for (int i = 0, count = m_sceneObject.transform.childCount; i < count; ++i)
                //{
                //    Transform child = m_sceneObject.transform.GetChild(i);
                //    if (child.name.Equals("DynamicObject"))
                //    {
                //        continue;
                //    }
                //    if (child.name.Equals("pengzhuang_zong"))
                //    {
                //        continue;
                //    }
                //    if (child.name.Equals("Main Camera"))
                //    {
                //        continue;
                //    }
                //    if (child.name.Contains("start"))//电梯
                //    {
                //        continue;
                //    }
                //    if (child.name.Contains("common_jingjichang_yuantai00"))//竞技场云台
                //    {
                //        continue;
                //    }
                //    m_bantchObjects.Add(child.gameObject);
                //}
                foreach(KeyValuePair<string,List<GameObject>>kvp in m_bantchObjects )
                {
                    StaticBatchingUtility.Combine(kvp.Value.ToArray(), m_sceneObject);
                }
               
                m_bantchObjects.Clear();
            }

        }
    }

    private void LoadOver()
    {
        //MyLog.Log("-----------------------------LoadOver--------------" + Time.time);
        m_sceneProcess += 0.1f;

        m_bantchObjects.Clear();
        CreateDynamic();
        Combine();
        //这里不再释放动态物体(动态物体中并不包含图片)
        //if (m_sceneConfigDict.ContainsKey(m_SceneName))
        //{
        //    CSceneConfigLoader[] loaders = m_sceneConfigDict[m_SceneName];
        //    for (int i = 0, len = loaders.Length; i < len; ++i)
        //    {
        //        string path = "resources/scenes/prefab/" + loaders[i].GetFatherName() + "/" + loaders[i].GetName() + ".x";
        //        LoadHelp.RemoveObject(path.ToLower(), false);
        //    }
        //}

        //回调
        LoadSceneCompleted();

        m_faterTrans.Clear();
        m_textureList.Clear();
        m_shaderList.Clear();
        m_materialList.Clear();
        m_fbxList.Clear();
        m_dynamicList.Clear();
        //清除依赖的下载内存,仅仅清除fbx和texture,保留material和shader
        LoadHelp.ClearDeterministicList();

        m_dynamicLoaderDict.Clear();
        m_sceneConfigDict.Clear();
        //m_allsceneDict.Clear();

        //Resources.UnloadUnusedAssets();
    }

    protected abstract void LoadSceneCompleted();
}
