﻿using System.Collections;
using UnityEngine;
using System;
using System.Collections.Generic;

public class EasyTouchDragY : MonoBehaviour
{
    public Vector3 deltaPosition;
    public Transform trans;
    public Bounds dragBounds = new Bounds(Vector3.zero, Vector3.one);
    public BoxCollider boxBounds;
    public Camera worldCamera;
    private float scale = 1;
    public Vector3 startPosition = Vector3.zero;
   
    public delegate void OnFristDragFinshed();
    public OnFristDragFinshed onFristDragFinshed;
    private Vector3 mMomentum = Vector3.zero;
    private Vector3 mScroll = Vector3.zero;
    public float m_bottomMaxValue = 8;
    public float m_topMaxValue = 44;
    public float m_limitValue = 23;

    void Start()
    {
        boxBounds = new BoxCollider();
        trans = gameObject.transform;
        if (boxBounds == null)
            boxBounds = trans.root.gameObject.AddComponent<BoxCollider>();
        else
            boxBounds = trans.root.gameObject.GetComponent<BoxCollider>();
        SetBounds(new Vector3(0, 0, 40), new Vector3(46f, 100, 1f));
        worldCamera = gameObject.GetComponent<Camera>();
    }

    private void SetBounds(Vector3 center, Vector3 size)
    {
        boxBounds.center = center;
        boxBounds.size = size;
    }

    void OnEnable()
    {
        EasyTouch.On_DragStart = OnDragStart;
        EasyTouch.On_Drag = OnDrag;
        EasyTouch.On_DragEnd = OnDragEnd;
    }

    void OnDisable()
    {
        EasyTouch.On_DragStart = null;
        EasyTouch.On_Drag = null;
        EasyTouch.On_DragEnd = null;
    }

    private void OnDragEnd(Gesture gesture)
    {
        trans.position = trans.position;
    }


    private void OnDrag(Gesture gesture)
    {
        Vector3 pos = (-Input.mousePosition - deltaPosition) * scale;
        pos = startPosition + new Vector3(0, pos.y, 0);
        if (m_bottomMaxValue <= pos.y && pos.y <= m_topMaxValue)
        {
            mMomentum = Vector3.Lerp(mMomentum, mMomentum + pos * (0.01f * 35), 0.67f);
            if (trans.position.y + pos.y <= m_limitValue)
                return;

            trans.position = Vector3.Lerp(trans.position,
                new Vector3(trans.position.x, pos.y, trans.position.z), 0.67f);
        }
    }

    public void MoveTo(Vector3 start,Vector3 end)
    {
        iTween.MoveFrom(trans.gameObject, iTween.Hash("position", start, "time", 0.3f, "islocal", true, "easetype", iTween.EaseType.easeInCubic, "oncomplete", (OnCallBack)OnComplete));
    }

    private void OnComplete(params object[] arg)
    {
        if (onFristDragFinshed != null)
        {
            onFristDragFinshed();
            onFristDragFinshed = null;
        }
    }

    private void OnDragStart(Gesture gesture)
    {
        dragBounds = boxBounds.bounds;
        deltaPosition = -Input.mousePosition;
        startPosition = trans.position;
        Vector3 v1 = worldCamera.ScreenToWorldPoint(new Vector3(100.0f, 0, 10));
        Vector3 v2 = worldCamera.ScreenToWorldPoint(new Vector3(800, 0, 10));
        scale = (v1 - v2).magnitude / 100.0f;
    }
}

