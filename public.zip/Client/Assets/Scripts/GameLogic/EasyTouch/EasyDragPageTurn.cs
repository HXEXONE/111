﻿//using UnityEngine;
//using System.Collections;

//public class EasyDragPageTurn : MonoBehaviour {

//    // Use this for initialization
//    void Start () {
	
//    }
	
//    // Update is called once per frame
//    void Update () {
	
//    }

//    void OnEnable()
//    {
//        EasyTouch.On_Drag += OnDragPage;
//        EasyTouch.On_DragStart += OnDragPageStart;
//        EasyTouch.On_DragEnd += OnDragPageEnd;
//    }

//    void OnDisable()
//    {
//        EasyTouch.On_Drag -= OnDragPage;
//        EasyTouch.On_DragStart -= OnDragPageStart;
//        EasyTouch.On_DragEnd -= OnDragPageEnd;
//    }

//    void OnDestroy()
//    {
//        EasyTouch.On_Drag -= OnDragPage;
//        EasyTouch.On_DragStart -= OnDragPageStart;
//        EasyTouch.On_DragEnd -= OnDragPageEnd;
//    }

//    void OnDragPageStart(Gesture gesture)
//    {
//    }

//    void OnDragPage(Gesture gesture)
//    {
//        gesture.deltaTime = Mathf.Clamp(gesture.deltaTime, 0.4f, 0.6f);
//        float delta = gesture.deltaTime;
//        if (gesture.deltaPosition.x < 0)
//        {
//            delta =delta;
//            //MyLog.LogError("---------------------  " + gesture.deltaPosition.x + "----- " + delta);
//        }
//        else if (gesture.deltaPosition.x > 0)
//        {
//            delta = -delta;
//            //MyLog.LogError("++++++++++++++++++++  " + gesture.deltaPosition.x + "+++++++ " + delta);
            
//        }
//       //SingletonObject<PartnerGroupMediator>.GetInst().UpdateTurnPage(delta);
//    }

//    void OnDragPageEnd(Gesture gesture)
//    {
//    }
//}
