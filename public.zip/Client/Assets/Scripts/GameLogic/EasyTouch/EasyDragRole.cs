﻿using UnityEngine;
using System.Collections;

public class EasyDragRole : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnEnable()
    {
        //EasyTouch.On_Drag += OnDragRole;
        EasyTouch.On_DragStart = OnDragRoleStart;
        //EasyTouch.On_DragEnd += OnDragRoleEnd;
    }

    void OnDisable()
    {
        //EasyTouch.On_Drag -= OnDragRole;
        EasyTouch.On_DragStart = null;
        //EasyTouch.On_DragEnd -= OnDragRoleEnd;
    }

    void OnDestroy()
    {
        //EasyTouch.On_Drag -= OnDragRole;
        EasyTouch.On_DragStart = null;
        //EasyTouch.On_DragEnd -= OnDragRoleEnd;
    }

    void OnDragRole(Gesture gesture)
    {
        //MyLog.LogError("OnDragRole");
    }
    void OnDragRoleStart(Gesture gesture)
    {
        if (gesture.deltaPosition.x < 0)
            SingletonObject<LoginScene>.GetInst().TweenRotationLeft();
        else if (gesture.deltaPosition.x > 0)
            SingletonObject<LoginScene>.GetInst().TweenRotationRight();
    }

    void OnDragRoleEnd(Gesture gesture)
    {
        //MyLog.LogError("OnDragRoleEnd");
    }
}
