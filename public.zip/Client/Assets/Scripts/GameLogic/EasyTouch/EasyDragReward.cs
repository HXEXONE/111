﻿//using UnityEngine;
//using System.Collections;

//public class EasyDragReward : MonoBehaviour {

//    // Use this for initialization
//    void Start () {
        
//    }
	
//    // Update is called once per frame
//    void Update () {
	
//    }

//    void OnEnable()
//    {
//        EasyTouch.On_Drag += OnDragReward;
//        //EasyTouch.On_DragStart += OnDragRewardStart;
//        //EasyTouch.On_DragEnd += OnDragRewardEnd;
//    }

//    void OnDisable()
//    {
//        EasyTouch.On_Drag -= OnDragReward;
//        //EasyTouch.On_DragStart -= OnDragRewardStart;
//        //EasyTouch.On_DragEnd -= OnDragRewardEnd;
//    }

//    void OnDestroy()
//    {
//        EasyTouch.On_Drag -= OnDragReward;
//        //EasyTouch.On_DragStart -= OnDragRewardStart;
//        //EasyTouch.On_DragEnd -= OnDragRewardEnd;
//    }

//    //void OnDragRewardStart(Gesture gesture)
//    //{
        
//    //}

//    void OnDragReward(Gesture gesture)
//    {
//        float mag = gesture.deltaPosition.magnitude;
//        if (mag < 10f)
//        {
//            return;
//        }
//        if (gesture.deltaPosition.x < 0)
//        {
//            //if(SingletonObject<BattleResultMediator>.GetInst().IsOpen)
//                //SingletonObject<BattleResultMediator>.GetInst().DragLeft(mag >= 70f ? -1 : 1);
//            //if(SingletonObject<ClimbTowerResultMediator>.GetInst().IsOpen)
//            //    SingletonObject<ClimbTowerResultMediator>.GetInst().DragLeft(mag >= 70f ? -1 : 1);
//        }
//        else if (gesture.deltaPosition.x > 0)
//        {
//            //if (SingletonObject<BattleResultMediator>.GetInst().IsOpen)
//            //    SingletonObject<BattleResultMediator>.GetInst().DragRight(mag >= 70f ? -1 : 1);
//            //if (SingletonObject<ClimbTowerResultMediator>.GetInst().IsOpen)
//                //SingletonObject<ClimbTowerResultMediator>.GetInst().DragRight(mag >= 70f ? -1 : 1);
//        }
//    }

//    //void OnDragRewardEnd(Gesture gesture)
//    //{
        
//    //}
//}
