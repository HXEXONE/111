﻿using UnityEngine;
using System.Collections;

public class EasyDragCamera : MonoBehaviour {

    private Vector3 deltaPosition;
    private Transform trans;
    private float factor = -5.0f;

    private BoxCollider boxBound;
    private Vector3 size = Vector3.zero;
    private Vector3 center = Vector3.zero;

    private GameObject boundsObj ;
    public Rect screenRect;
    public Rect dragRect;
    private EasyTouch easyTouch;
    private Gesture easyGesture;
    private bool isNGUILayer = false;

    private float fz = 0.0f;
    public Camera worldCamera;

    public Vector2 startPos;
    public Vector2 lastPos;
    public Vector2 totalDelta;
    public Vector2 scale = Vector2.one;
    public float momentumAmount = 5f;
    public Vector2 delta = Vector2.one;
    private Vector2 mMomentum = Vector2.zero;
    private Vector3 tempPosition = Vector3.zero;

    private Vector3 minVector = Vector3.zero;
    private Vector3 maxVector = Vector3.zero;

	// Use this for initialization
	void Start () {
        easyTouch = CCamera.GetInst().GetEasyTouch();
        trans = transform;
        SetBounds(center,size );
        screenRect = new Rect(0.0f,0.0f, Screen.width, Screen.height);
        dragRect = new Rect(0.0f, 0.0f, Screen.width * 2, Screen.height * 2);
        worldCamera = gameObject.GetComponent<Camera>();
	}

    #region  get and set
    public void Factor(float fValue)
    {
        factor = fValue;
    }
    #endregion

    void OnEnable()
    {
        EasyTouch.On_DragStart = OnDragStart;
        EasyTouch.On_Drag = OnDrag;
        EasyTouch.On_DragEnd = OnDragEnd;

    }
	
    void OnDisable()
    {
        EasyTouch.On_DragStart = null;
        EasyTouch.On_Drag = null;
        EasyTouch.On_DragEnd = null;
    }

	// Update is called once per frame
	void Update () {
        
	}


    public void SetBounds(Vector3 center,Vector3 size)
    {
        this.size = size;
        this.center = center;
        if (trans == null)
        {
            return;
        }
        Transform rootTrans = trans.root;
        if (boxBound == null)
        {
            boxBound = rootTrans.gameObject.AddComponent<BoxCollider>();
        }
        boxBound.center = center;
        boxBound.size = size;

        minVector.x = center.x + size.x / 2;
        minVector.z = center.z + size.z / 2;
        minVector.y = 0f;

        maxVector.x = center.x - size.x / 2;
        maxVector.z = center.z - size.z / 2;
        maxVector.y = size.y;
    }
    
    public void OnDragStart(Gesture gesture)
    {

#if UNITY_EDITOR
        Transform rootTrans = transform.root;
        BoxCollider collider = rootTrans.GetComponent<BoxCollider>();
        if (collider!=null)
        {
            SetBounds(collider.center, collider.size);
        }
#endif

        if (UILayer())
        {
            isNGUILayer = true;
            return;
        }
        else
        {
            isNGUILayer = false;
        }
        startPos = Input.mousePosition;
        lastPos = startPos;
        tempPosition = transform.position;

    }

    public void OnDrag(Gesture gesture)
    {

        if (isNGUILayer == true)
        {
            return;
        }

        if (boxBound != null)
        {
            scale.x = (Time.deltaTime + 0.02f);
            scale.y = -(Time.deltaTime + 0.02f);
            Vector2 pos = Input.mousePosition;
            delta = pos - lastPos;
            Vector2 v2offset = Vector2.Scale(delta, scale);
            tempPosition = transform.position;
            tempPosition += new Vector3(v2offset.y, 0, v2offset.x);

            if (boxBound.bounds.Contains(tempPosition))
            {
                transform.position += new Vector3(v2offset.y, 0, v2offset.x);
            }
            else
            {
                //if (gesture.swipe == EasyTouch.SwipeType.Other)
                {
                    if (tempPosition.x > minVector.x)
                    {
                        tempPosition.x = minVector.x;
                    }
                    else if (tempPosition.x < maxVector.x)
                    {
                        tempPosition.x = maxVector.x;
                    }
                    if (tempPosition.z >= minVector.z)
                    {
                        tempPosition.z = minVector.z;
                    }
                    else if (tempPosition.z <= maxVector.z)
                    {
                        tempPosition.z = maxVector.z;
                    }
                    transform.position = tempPosition;
                }
            }
            lastPos = pos;
            // Adjust the momentum
            mMomentum = Vector2.Lerp(mMomentum, mMomentum + v2offset * (0.01f * momentumAmount), 0.67f);
  
        }

    }

    public void OnDragEnd(Gesture gesture)
    {
        if (UILayer())
        {
            return;
        }
        isNGUILayer = false;
        //trans.position = trans.position;
    }

    private bool UILayer()
    {
        GameObject hoveredObj = UICamera.hoveredObject;
        if (hoveredObj != null)
        {
            if (hoveredObj.layer == DEFINE.NGUI_LAYER_ONE ||
                hoveredObj.layer == DEFINE.NGUI_LAYER_TWO ||
                hoveredObj.layer == DEFINE.NGUI_LAYER_THREE ||
                hoveredObj.layer == DEFINE.NGUI3D_LAYER_TWO ||
                hoveredObj.layer == DEFINE.NGUI3D_LAYER)
            {
                return true;
            }

        }
        return false;
    }
    private Vector3 CalculateScale(Vector3 vPos)
    {
        if (worldCamera != null)
        {
            Ray hitRay = worldCamera.ScreenPointToRay(vPos);
            RaycastHit hit;
            if (Physics.Raycast(hitRay, out hit))//, 1000, 1 << DEFINE.TERRAINLAYER))
            {
                return hit.point;
            }
            else
            {
                MyLog.LogError("the RaycastHit not hit physics collider ");
                return Vector3.zero;
            }
        }
        else
        {
            MyLog.LogError("the RaycastHit not hit physics collider ");
            return Vector3.zero;
        }
    }

#if UNITY_EDITOR

    /// <summary>
    /// Draw a visible orange outline of the bounds.
    /// </summary>

    void OnDrawGizmos()
    {

    }
#endif
}

