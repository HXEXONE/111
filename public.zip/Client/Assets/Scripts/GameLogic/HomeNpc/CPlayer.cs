﻿using UnityEngine;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;
using System;

public struct stPlayerInfo
{
    public ushort uiMaxVigor;       //最大体力值
    public ushort uiCurVigor;       //当前体力值
    public uint uiAddVigorLeftSeconds;    //还有多少秒增加体力值 
    public uint uiGoldCoin;         //金币数
    public uint uiDiamond;          //钻石数
    public uint uiLongZuan;         //龙钻
    public uint uiExp;              //经验
    public ushort uiCurChapter;     //当前关卡
    public ushort uiEquipExtendBag; //装备包袱等级扩展包袱数    
    public uint uiSummonExp;        //伙伴召唤经验
    public uint uiSmeltExp;         //装备熔炼经验
    public ushort uiSmeltLevel;     //熔炉等级
    //public uint uiFightPartnerID;   //出战伙伴ID
    public uint uiQuestID;          //任务id
    public byte uiQuestIsFinshed;   //任务状态
    public ByteArray uiPartnerByte; //小伙伴携带数组
    public ushort uiTodayBuyVigorCount;//体力购买次数

    public uint uiNormalBoxRemainTime;//普通装备宝箱的免费剩余时间
    public ushort uiNormalBoxRemainNum;//普通宝箱免费开启剩余次数
    public uint uiGreatBoxRemainTime;  //高级装备宝箱的免费剩余时间


    public uint uiLegendRecruitRemainTime;      //传奇招募剩余时间
    public ushort uiNormalRecruitRemainNum;     //普通招募剩余次数
    public uint uiNormalRecruitRemainTime;      //普通招募的免费剩余时间
    public uint uiTowerNum;                     //爬塔次数
    public uint uiEscortNum;                    //护送次数
    public uint uiProtectNum;                   //守卫次数
    public uint uiWildBattleID;                 //末日荒野挑战地图ID
    public ushort bIsFinishBattle;              //是否完成这个末日荒野战场0:未完成
    public uint uiRestartBattleTimes;           //末日荒野剩余挑战次数
    public uint uiSBossVigor;                   //Sboss活力值
    public ushort uiSBossVigorCount;            //Sboss活力值购买次数
    public uint uiAddBossVigorLeftSeconds;    //还有多少秒增加BOSS活力值
    public uint uiMaxBossVigor;    //最大活力值
    public ushort uiGoldBuyCount;               //金币购买次数
    public long uiTowerAwardTime;
    public uint uiSkillPoint;
    public uint uiMakeEquipCountToday;//熔炼次数
    public uint uiMaxMakeEquipCount;//熔炼最大次数
    public ulong uiPartyID;//公会ID，没有加入公会的话就是0
    public uint uiPartyActive;    //公会活跃值，没有加入公会的话就是0
    public uint uiMyPartyActiveToday;//玩家当日活跃度多少
    public uint uiMyPartyActiveTodayMax;//玩家活跃度最大值
    public ushort uiPartyPost;    //公会职位，没有加入公会的话就是255
    public uint uiPetBuffItemID;    //宠物口粮喂食BUFF对应的物品ID,没有BUFF时是0
    public uint uiMountBuffItemID;    //坐骑口粮喂食BUFF对应的物品ID,没有BUFF时是0
    public uint uiAlreadyInputCode;    //是否已经输入了邀请码，0：没有；1：有
    public uint uiMaxLevelOfAccount;    //该账号下最大等级的角色是多少级

    public uint uiTowerRemainPlayTimes;//爬塔剩余挑战次数
    public uint uiTowerBuyTimes; //爬塔已购买次数
    public uint uiTowerMaxCanNum;//爬塔最大可挑战层数
    public CrystalInfo uiLastAttackCrystalInfo;   //上一次关卡选择攻击龙晶
    public CrystalInfo uiLastDefenseCrystalInfo;   //上一次关卡选择防御龙昌
}

public struct sBattleInfo
{
    public ulong uiKey;
    public ulong uiValue;
}

public class CPlayer : CBaseHomeAvatar
{
    public int m_homeCountIndex;//用来计算setavatarinfo是否首次进入主城发的,临时用

    private stPlayerInfo m_playerInfo;
    //private Timer m_syncPosTimer = new Timer();
    public Timer m_PlayerVigorTimer = new Timer();
    public Timer m_BossVigorTimer = new Timer();
    private ulong mPhoneNumber;

    private uint m_uiBattleInstanceID;//战场唯一实例
    public uint uiBattleInstanceID { get { return m_uiBattleInstanceID; } set { m_uiBattleInstanceID = value; } }
    private uint m_uiBattleType;//难度
    private uint m_uiBattleID;//战场类型
    private ushort ResurrectNum = 0;//战场复活次数

    private Vector3 m_position;
    private Quaternion m_rotation;


    private stCharacterCard m_playerAttr = new stCharacterCard(1);//加密后的玩家属性
    private stCharacterCard m_bakPlayerAttr;//原版玩家属性,不做任何用处,只用来验证是否被篡改内存
    private CHomeNpc cHomeNpc;
    public bool isClickNpc = false;    //是否点击NPC
    private GameObject mAgentObj;       //临时NPC gameobject
    public uint m_npcID = 0;
    private uint m_npcSelectParticle;//选中特效
    private bool m_bIsLoadParticle;//是否加载了特效
    public Vector3 m_npcPosition;
    private Vector3 m_lastSyncPosition = Vector3.zero;
    private int[] uiRecruitPartner;
    private uint startPveMapID = 10010006;
    public uint curPveMapID = 10010006;

    public bool levelUpInbattale;
    //升级之前的等级、体力、上限
    private uint oldLevel;
    private uint oldVigar;
    private uint oldMaxVigar;

    private bool isLevelUpdata;
    private bool isVigarUpdata;
    private bool isMaxVigarUpdata;

    /// <summary>
    /// 总战力
    /// </summary>
    private float fightTotalValue = 1f;
    /// <summary>
    /// 属性战力
    /// </summary>
    private float fightAttrValue;

    private bool m_bIsActiviTime;
    public bool m_bIsWeek = false;
    private uint m_uiIsActiviTimes;

    #region 爬塔战场奖励信息
    public Dictionary<uint, uint> m_towerSweepAwardDic = new Dictionary<uint, uint>();
    /// <summary>
    /// 扫荡奖励：包括爬塔前面未真正挑战的通关奖励和掉落奖励，以及后期通关奖励（ps：这里奖励只有物品、装备、等）
    /// </summary>
    public Dictionary<uint, uint> towerSweepAwardDic { get { return m_towerSweepAwardDic; } set { m_towerSweepAwardDic = value; } }
    private Dictionary<uint, uint> m_towerAwardDic = new Dictionary<uint, uint>();
    /// <summary>
    /// 扫荡奖励：包括爬塔前面未真正挑战的通关奖励和掉落奖励，以及后期通关奖励（ps：这里奖励只有经验，金币，等）
    /// </summary>
    public Dictionary<uint, uint> towerAwardDic { get { return m_towerAwardDic; } set { m_towerAwardDic = value; } }
    #endregion
    private Vector3 m_bornPosition = Vector3.zero;
    private List<Texture> _mInitiativeSkillIcon = new List<Texture>();//主动技能图标
    private List<string> _mInitiativeSkillPath = new List<string>();
    private List<Texture> _mPassivelySkillIcon = new List<Texture>();//被动技能图标
    private List<string> _mPassivelySkillPath = new List<string>();

    private EnumEnterHomeResult m_enterHomeResult;

    public static bool isInputEnable = true;//设置input的输入状态是否可用 

    private DateTime m_StartBattleDataTime;//战场房间创建的系统时间
    public DateTime StartBattleDataTime { get { return m_StartBattleDataTime; } set { m_StartBattleDataTime = value; } }
    private float m_StartBattleGameTime;//战场房间创建的游戏时间
    public float StartBattleGameTime { get { return m_StartBattleGameTime; } set { m_StartBattleGameTime = value; } }
    private uint mDelayCallBackIndex = 0;
    private bool mCanRefresh = false;

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_CLIENT_AVATAR_INFO, SetAvatarInfo, false);//进入游戏
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PHONE_NUM, BindPhoneNumber, false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_UPDATE_AVATAR_INFO, UpdateAvatarInfo, false);//更新玩家数据
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_REQUEST_BATTLE_OPER, OperBattleResult, true);//战场操作结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_ENTER_HOME_RESULT, EnterHomeResult, true);//进入家园结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_SET_USERNAME_RESULT, SetNickNameResult, true);//设置昵称结果
        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_RENAME_RESULT, ChangeNickNameResult, true);//更改昵称
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_BATTLETIMEOUT, BattleTimeOut, false);//战场战斗超时
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ASYN_ATTR_INFO, SyncPlayerAttr, false);//同步玩家属性
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_RESET_BUY_VIGOR_COUNT, OnSetVigorCount, false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_CLIENT_AWARDITEMS, OnGetAwardItemNotify, false);//战场单关通关奖励通知
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_TOWER_ITEMS, onGetSweepAwardList, false);//扫荡所有奖励不包括经验，金币等。

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTICE_MONEY_REWARD_RECORDS, onMoneyRewardRecord, false);//虚拟货币奖励统计
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTICE_CONSUME_RECORDS, onConsumeRecord, false);//游戏内消费点统计
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTICE_ITEM_CONSUME_RECORDS, onItemConsumeRecord, false);//道具消耗统计
    }

    #region 服务端返回关卡奖励
    //扫荡前面部分的奖励。
    private void onGetSweepAwardList(BinaryReader br)
    {
        G2CAckTowerItems msg = new G2CAckTowerItems();
        msg.Read(br);

        //获取爬塔扫荡前部分物品奖励信息
        List<CKeyValue> m_towerSweepAwardList = new List<CKeyValue>();
        m_towerSweepAwardList.Clear();
        m_towerSweepAwardList = new List<CKeyValue>(msg.items);
        for (int i = 0, count = m_towerSweepAwardList.Count; i < count; i++)
        {
            uint key = (uint)m_towerSweepAwardList[i].uiKey;
           if (key == DEFINE.ITEM_EXP) //奖励的经验
            {
                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_EXP))
                {
                    m_towerAwardDic[DEFINE.ITEM_EXP] += (uint)m_towerSweepAwardList[i].uiValue;
                }
                else
                {
                    m_towerAwardDic.Add(DEFINE.ITEM_EXP, (uint)m_towerSweepAwardList[i].uiValue);
                }
            }
            else if (key == DEFINE.ITEM_GOLD) //奖励的金币
            {
                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_GOLD))
                {
                    m_towerAwardDic[DEFINE.ITEM_GOLD] += (uint)m_towerSweepAwardList[i].uiValue;
                }
                else
                {
                    m_towerAwardDic.Add(DEFINE.ITEM_GOLD, (uint)m_towerSweepAwardList[i].uiValue);
                }
            }
            else if (key == DEFINE.ITEM_DIAM) //奖励的rmb
            {
                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_DIAM))
                {
                    m_towerAwardDic[DEFINE.ITEM_DIAM] += (uint)m_towerSweepAwardList[i].uiValue;
                }
                else
                {
                    m_towerAwardDic.Add(DEFINE.ITEM_DIAM, (uint)m_towerSweepAwardList[i].uiValue);
                }
            }
            else
            {
                if (m_towerSweepAwardDic.ContainsKey(key))
                {
                    m_towerSweepAwardDic[key] += (uint)m_towerSweepAwardList[i].uiValue;
                }
                else
                {
                    m_towerSweepAwardDic.Add(key, (uint)m_towerSweepAwardList[i].uiValue);
                }
            }
        }

    }

    //战场奖励通知（单关通关后获得通关奖励物品通知）
    private void OnGetAwardItemNotify(BinaryReader br)
    {
        G2CNotifyBattleAwardItem msg = new G2CNotifyBattleAwardItem();
        msg.Read(br);
        CBattleSceneLoading sceneLoading = SingletonObject<CBattleSceneLoading>.GetInst();
        switch (sceneLoading.battleType)
        {
            case eBattleType.ClimbTower:
                //SceneContent mapLoader = HolderManager.m_SceneHolder.GetStaticInfo(msg.uiBattleMapID);
                //List<BaseIntContent> passLevelAward = mapLoader.AwardList;

                //if (passLevelAward != null)
                //{
                //    for (int i = 0, count = passLevelAward.Count; i < count; i++)
                //    {
                //        if (passLevelAward[i].list.Count <= 1)
                //        {
                //            continue;
                //        }
                //        if (passLevelAward[i].list[0] == DEFINE.ITEM_EXP) //奖励的经验
                //        {
                //            if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_EXP))
                //            {
                //                m_towerAwardDic[DEFINE.ITEM_EXP] += (uint)passLevelAward[i].list[1];
                //            }
                //            else
                //            {
                //                m_towerAwardDic.Add(DEFINE.ITEM_EXP, (uint)passLevelAward[i].list[1]);
                //            }
                //        }
                //        else if (passLevelAward[i].list[0] == DEFINE.ITEM_GOLD) //奖励的金币
                //        {
                //            if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_GOLD))
                //            {
                //                m_towerAwardDic[DEFINE.ITEM_GOLD] += (uint)passLevelAward[i].list[1];
                //            }
                //            else
                //            {
                //                m_towerAwardDic.Add(DEFINE.ITEM_GOLD, (uint)passLevelAward[i].list[1]);
                //            }
                //        }
                //        else if (passLevelAward[i].list[0] == DEFINE.ITEM_DIAM) //奖励的rmb
                //        {
                //            if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_DIAM))
                //            {
                //                m_towerAwardDic[DEFINE.ITEM_DIAM] += (uint)passLevelAward[i].list[1];
                //            }
                //            else
                //            {
                //                m_towerAwardDic.Add(DEFINE.ITEM_DIAM, (uint)passLevelAward[i].list[1]);
                //            }
                //        }
                //    }
                //}

                //if (msg.sItemInfoVec != null)
                //{
                //    for (int i = 0, count = msg.sItemInfoVec.Count; i < count; i++)
                //    {
                //        //物品和装备
                //        uint key = msg.sItemInfoVec[i].uiItemId;
               //        if (m_towerSweepAwardDic != null)
                //        {
                //            if (key == DEFINE.ITEM_EXP) //奖励的经验
                //            {
                //                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_EXP))
                //                {
                //                    m_towerAwardDic[DEFINE.ITEM_EXP] += (uint)passLevelAward[i].list[1];
                //                }
                //                else
                //                {
                //                    m_towerAwardDic.Add(DEFINE.ITEM_EXP, (uint)passLevelAward[i].list[1]);
                //                }
                //            }
                //            else if (key == DEFINE.ITEM_GOLD) //奖励的金币
                //            {
                //                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_GOLD))
                //                {
                //                    m_towerAwardDic[DEFINE.ITEM_GOLD] += (uint)passLevelAward[i].list[1];
                //                }
                //                else
                //                {
                //                    m_towerAwardDic.Add(DEFINE.ITEM_GOLD, (uint)passLevelAward[i].list[1]);
                //                }
                //            }
                //            else if (key == DEFINE.ITEM_DIAM) //奖励的rmb
                //            {
                //                if (m_towerAwardDic.ContainsKey(DEFINE.ITEM_DIAM))
                //                {
                //                    m_towerAwardDic[DEFINE.ITEM_DIAM] += (uint)passLevelAward[i].list[1];
                //                }
                //                else
                //                {
                //                    m_towerAwardDic.Add(DEFINE.ITEM_DIAM, (uint)passLevelAward[i].list[1]);
                //                }
                //            }
                //            else
                //            {
                //                if (m_towerSweepAwardDic.ContainsKey(key))
                //                {
                //                    m_towerSweepAwardDic[key] += msg.sItemInfoVec[i].uiItemNum;
                //                }
                //                else
                //                {
                //                    m_towerSweepAwardDic.Add(key, msg.sItemInfoVec[i].uiItemNum);
                //                }
                //            }
                //        }
                //    }
                //}
                break;
            case eBattleType.PVE:
            case eBattleType.Escort:
            case eBattleType.Protect:
                SceneContent mapInfo = HolderManager.m_SceneHolder.GetStaticInfo(msg.uiBattleMapID);
                if (mapInfo == null)
                {
                    return;
                }
                if (msg.sItemInfoVec.Count > 0)
                {
                    BattleResultManager.GetInst().ClearBooty();
                    for (int i = 0; i < msg.sItemInfoVec.Count; i++)
                    {
                        uint uItemID = msg.sItemInfoVec[i].uiItemId;
                        uint ufirst = uItemID / 10000000;

                        CDropObjectInfo dropItem = new CDropObjectInfo(msg.sItemInfoVec[i].uiItemId, msg.sItemInfoVec[i].uiItemNum);
                        BattleResultManager.GetInst().AddBooty(dropItem);
                    }
                }
                break;
          
        }
    }
    #endregion


    private void OnSetVigorCount(BinaryReader br)//服务器凌晨5点清除体力购买次数
    {
        stPlayerInfo stPlayer = m_playerInfo;
        stPlayer.uiTodayBuyVigorCount = 1;
        SetInfoBack(stPlayer);
    }


    private void SetAvatarInfo(BinaryReader br)//服务器返回当前进入游戏的角色信息
    {
        G2CSendAvatarInfo msg = new G2CSendAvatarInfo();
        msg.Read(br);
        m_pHomeAvatarInfo.m_llAccountID = msg.uiAccountId;
        m_pHomeAvatarInfo.szPlayerName = msg.szPlayerName;
        m_pHomeAvatarInfo.uiPlayerLevel = msg.uiPlayerLevel;
        m_pHomeAvatarInfo.uiPlayerJob = msg.uiPlayerJob;
        m_pHomeAvatarInfo.uiPetID = msg.uiPetID;

        m_playerInfo.uiMaxVigor = msg.uiMaxVigor;
        m_playerInfo.uiCurVigor = msg.uiCurVigor;
        m_playerInfo.uiAddVigorLeftSeconds = msg.uiAddVigorLeftSeconds;
        m_playerInfo.uiGoldCoin = msg.uiGoldCoin;
        m_playerInfo.uiDiamond = msg.uiDiamond;
        m_playerInfo.uiLongZuan = msg.uiLongZuan;
        m_playerInfo.uiExp = msg.uiExp;
        m_playerInfo.uiCurChapter = msg.uiCurChapter;
        m_playerInfo.uiEquipExtendBag = msg.uiEquipExtendBag;
        m_playerInfo.uiSummonExp = msg.uiSummonExp;
        m_playerInfo.uiSmeltExp = msg.uiSmeltExp;
        m_playerInfo.uiSmeltLevel = msg.uiSmeltLevel;
        //m_playerInfo.uiFightPartnerID = msg.uiServedPartnerId;
        m_playerInfo.uiNormalBoxRemainTime = msg.uiNormalBoxRemainTime;
        m_playerInfo.uiNormalRecruitRemainTime = msg.uiNormalRecruitRemainTime;
        m_playerInfo.uiQuestID = msg.uiCurQuestID;

        m_playerInfo.uiPartnerByte = msg.aPartnerCollection;
        m_playerInfo.uiTodayBuyVigorCount = msg.uiTodayBuyVigorCount;

        m_playerInfo.uiGreatBoxRemainTime = msg.uiGreatBoxRemainTime;
        m_playerInfo.uiNormalBoxRemainNum = msg.uiNormalBoxRemainNum;
        m_playerInfo.uiLegendRecruitRemainTime = msg.uiLegendRecruitRemainTime;
        m_playerInfo.uiNormalRecruitRemainNum = msg.uiNormalRecruitRemainNum;
        m_playerInfo.uiTowerNum = msg.uiTowerNum;
        m_playerInfo.uiEscortNum = msg.uiEscortTimes;
        m_playerInfo.uiProtectNum = msg.uiShouWeiTimes;
        m_playerInfo.uiWildBattleID = msg.uiWildBattleID;
        m_playerInfo.bIsFinishBattle = msg.bIsFinishBattle;
        m_playerInfo.uiRestartBattleTimes = msg.uiRestartBattleTimes;
        m_playerInfo.uiSBossVigor = msg.uiSBossVigor;
        m_playerInfo.uiSBossVigorCount = msg.uiSBossVigorCount;
        m_playerInfo.uiAddBossVigorLeftSeconds = msg.uiAddBossVigorLeftSeconds;
        m_playerInfo.uiMaxBossVigor = msg.uiMaxBossVigor;
        m_playerInfo.uiGoldBuyCount = msg.uiGoldBuyCount;
        m_playerInfo.uiSkillPoint = msg.uiSkillPoint;
        m_playerInfo.uiMakeEquipCountToday = msg.uiMakeEquipCountToday;
        m_playerInfo.uiMaxMakeEquipCount = msg.uiMaxMakeEquipCount;
        m_playerInfo.uiPartyID = msg.uiPartyID;
        m_playerInfo.uiPartyActive = msg.uiPartyActive;
        m_playerInfo.uiMyPartyActiveToday = msg.uiMyPartyActiveToday;
        m_playerInfo.uiMyPartyActiveTodayMax = msg.uiMyPartyActiveTodayMax;
        m_playerInfo.uiPartyPost = msg.uiPartyPost;
        m_playerInfo.uiPetBuffItemID = msg.uiPetBuffItemID;
        m_playerInfo.uiMountBuffItemID = msg.uiMountBuffItemID;
        m_playerInfo.uiAlreadyInputCode = msg.uiAlreadyInputCode;
        m_playerInfo.uiMaxLevelOfAccount = msg.uiMaxLevelOfAccount;
        m_playerInfo.uiLastAttackCrystalInfo = msg.uiLastAttackCrystalInfo;
        m_playerInfo.uiLastDefenseCrystalInfo = msg.uiLastDefenseCrystalInfo;

        m_PlayerVigorTimer.SetDateTimer(m_playerInfo.uiAddVigorLeftSeconds);
        m_BossVigorTimer.SetDateTimer(m_playerInfo.uiAddBossVigorLeftSeconds);
        //升级前数据
        oldLevel = msg.uiPlayerLevel;
        oldVigar = msg.uiCurVigor;
        oldMaxVigar = msg.uiMaxVigor;

        //2014年7月7日14:02:36 如果为任务对话类型任务，上线收到通知，强制设置为完成状态
        if (m_playerInfo.uiQuestID != 0)
        {
            if (NpcTaskManager.GetInst().CheckIsDialogQuest(m_playerInfo.uiQuestID))
            {
                m_playerInfo.uiQuestIsFinshed = 1;
            }
            else
                m_playerInfo.uiQuestIsFinshed = msg.IsFinishQuest;
        }
        else
            m_playerInfo.uiQuestIsFinshed = msg.IsFinishQuest;

        //SingletonObject<SmithyMainMediator>.GetInst().SetCountDownTime(m_playerInfo.uiNormalBoxRemainTime);
        SingletonObject<OpenBoxMediator>.GetInst().SetNormalTimes(m_playerInfo.uiNormalBoxRemainTime);
        SingletonObject<OpenBoxMediator>.GetInst().SetAdvanceTimes(m_playerInfo.uiGreatBoxRemainTime);

        UpdateAvatarInfoComponent();
        UpdatePartnerIndex();
        SetLearnSkillState();
        setEquipState();

        m_homeCountIndex++;
        if (m_homeCountIndex == 1)
        {
            m_uiBattleInstanceID = 0;

            fightTotalValue = 1;//重置战力
            UIManager.GetInst().CanShowScene = true;//重置显示主城变量
            SociatyManager.GetInst().ReleaseData();//重置公会缓存数据
            WorldBossManager.GetInst().m_bBattleBoss = false;
            ChatRoomManager.GetInst().IsLoadPrivateInfo = false;
            if (ChatRoomManager.GetInst().m_lscChatDataList != null)
                ChatRoomManager.GetInst().m_lscChatDataList.Clear();
            if (ChatRoomManager.GetInst().m_lscPartyChatDataList != null)
                ChatRoomManager.GetInst().m_lscPartyChatDataList.Clear();
            if (ShopManager.GetInst().HaveGiftBag != null)
                ShopManager.GetInst().HaveGiftBag.Clear();
            //发送统计SDK数据
            LoginScene ls = SingletonObject<LoginScene>.GetInst();


            FLSDK.setAccountName(m_pHomeAvatarInfo.szPlayerName);
            FLSDK.setAccountType("TypeFL");
            FLSDK.setLevel(m_pHomeAvatarInfo.uiPlayerLevel);
            FLSDK.setRoleID(ls.GetCurrentLoginAvatarPlayerID().ToString());
            FLSDK.setRoleName(m_pHomeAvatarInfo.szPlayerName);
            CServerAddressInfo server = ls.getCurrentServer();
            //FLSDK.setServerID(server.uiServerId.ToString());

            //其他平台需要的统计数据
            ushort vipLv = ShopManager.GetInst().VipLevel;
            SDKManager.GetInst().onEnterGame(ls.GetCurrentLoginAvatarPlayerID().ToString(), Common.SetPlayerName(m_pHomeAvatarInfo.szPlayerName), m_pHomeAvatarInfo.uiPlayerLevel.ToString(), server.uiServerId.ToString(), server.SName, server.zoneId.ToString(), m_pHomeAvatarInfo.m_llAccountID.ToString(), m_playerInfo.uiPartyID.ToString(), m_playerInfo.uiDiamond.ToString(), vipLv.ToString());
        }

    }

    private void BindPhoneNumber(BinaryReader br)
    {
        G2CAckPhoneNum msg = new G2CAckPhoneNum();
        msg.Read(br);

        mPhoneNumber = msg.uiPhoneNum;

    }

    private void UpdateAvatarInfo(BinaryReader br)
    {
        G2CUpdateAvatarInfo msg = new G2CUpdateAvatarInfo();
        msg.Read(br);

        //List<AvatarUpdateInfo> updateList = msg.sAvatarUpdateList;

        //for (int i = 0, count = updateList.Count; i < count; ++i)
        //{
        //AvatarUpdateInfo info = updateList[i];
        switch ((EnumUpdateAvatarType)msg.uiType)
        {
            case EnumUpdateAvatarType.UpdateAvatarType_VipShow:
                {
                    if (msg.uiValue == 0)
                    {
                        ClientMain.GetInst().isHideVIP = true;
                    }
                    else if (msg.uiValue == 1)
                    {
                        ClientMain.GetInst().isHideVIP = false;
                    }
                    else
                    {
                        ClientMain.GetInst().isHideVIP = false;
                    }
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_Level:
                {

                    int oldLevel = GetHomeAvatarInfo().uiPlayerLevel;

                    if (oldLevel != msg.uiValue)
                    {
                      
                        isLevelUpdata = true;
                    }
                    SetLevel((ushort)msg.uiValue);
                    SetLearnSkillState();
                    setEquipState();

                    SingletonObject<LoginScene>.GetInst().UpdateLevel(m_pHomeAvatarInfo.uiPlayerJob, (ushort)msg.uiValue);
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_MaxVigor:
                {
                    isMaxVigarUpdata = true;
                    m_playerInfo.uiMaxVigor = (ushort)msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_CurVigor:
                {
                    isVigarUpdata = true;
                    if (m_playerInfo.uiCurVigor > (ushort)msg.uiValue && ClientMain.GetInst().GetCurrentState() != eGameState.ChooseRole)
                    {
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(DEFINE.ITEM_PHYSICAL_POWER, (int)msg.uiValue - m_playerInfo.uiCurVigor);
                    }
                    m_playerInfo.uiCurVigor = (ushort)msg.uiValue;
                  
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_GoldCoin:
                {
                    m_playerInfo.uiGoldCoin = msg.uiValue;
                    SetLearnSkillState();
                    setEquipState();
                    CheckHasPartnerCanUpgrade();
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_Diamond:
                {
                    m_playerInfo.uiDiamond = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_Exp:
                {
                    m_playerInfo.uiExp = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_CurChapter:
                {
                    m_playerInfo.uiCurChapter = (ushort)msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_ServedPartnerId:
                {
                    //m_playerInfo.uiFightPartnerID = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_ExtendBagNum:
                {
                    m_playerInfo.uiEquipExtendBag = (ushort)msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_RecoverAtFive:
                {
                    m_playerInfo.uiTodayBuyVigorCount = (ushort)msg.uiValue;
                    m_playerInfo.uiNormalBoxRemainTime = msg.uiValue;
                    m_playerInfo.uiNormalRecruitRemainTime = msg.uiValue;
                    m_playerInfo.uiNormalBoxRemainNum = (ushort)msg.uiValue;
                    m_playerInfo.uiNormalRecruitRemainNum = (ushort)msg.uiValue;
                    m_playerInfo.uiTowerNum = msg.uiValue;
                    m_playerInfo.uiEscortNum = msg.uiValue;
                    m_playerInfo.uiProtectNum = msg.uiValue;
                    m_playerInfo.uiSBossVigorCount = (ushort)msg.uiValue;
                    m_playerInfo.uiGoldBuyCount = (ushort)msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_BossVigor:
                {
                    m_playerInfo.uiSBossVigor = (uint)msg.uiValue;
                    if (SingletonObject<WorldBossEmergeMediator>.GetInst().IsOpen)
                    {
                        SingletonObject<WorldBossEmergeMediator>.GetInst().SetEnergy();
                    }
                    if (SingletonObject<WorldBossCheckMediator>.GetInst().IsOpen)
                    {
                        SingletonObject<WorldBossCheckMediator>.GetInst().SetEnergy();
                    }
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_NextTowerAwardTime:
                {
                    m_playerInfo.uiTowerAwardTime = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_MakeEquipCountToday:
                {
                    m_playerInfo.uiMakeEquipCountToday = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_WileRemainRestartTimes:
                m_playerInfo.uiRestartBattleTimes = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_AddBossVigorLeftSeconds:
                m_BossVigorTimer.SetDateTimer(msg.uiValue);
                SingletonObject<ItemTipMediator>.GetInst().RefreshTimer(ePlayerResType.BossVigor);
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_AddVigorLeftSeconds:
                m_PlayerVigorTimer.SetDateTimer(msg.uiValue);
                SingletonObject<ItemTipMediator>.GetInst().RefreshTimer(ePlayerResType.PlayerVigor);
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_PartyActive:
                {
                    m_playerInfo.uiPartyActive = msg.uiValue;
                }
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_MyPartyActiveToday:
                m_playerInfo.uiMyPartyActiveToday = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_WildCurrMapId:
                m_playerInfo.uiWildBattleID = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_WildCurrStatus:
                m_playerInfo.bIsFinishBattle = (ushort)msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_EscortRemainTimes:
                m_playerInfo.uiEscortNum = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_ShouWeiRemainTimes:
                m_playerInfo.uiProtectNum = msg.uiValue;
                break;

            case EnumUpdateAvatarType.UpdateAvatarType_PartyPost:     //公会职位 255无工会
                m_playerInfo.uiPartyPost = (ushort)msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_PetBuffItemID:     //宠物口粮喂食BUFF对应的物品ID,没有BUFF时是0
                m_playerInfo.uiPetBuffItemID = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_MountBuffItemID:     //坐骑口粮喂食BUFF对应的物品ID,没有BUFF时是0
                m_playerInfo.uiMountBuffItemID = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_uiAlreadyInputCode:    //是否已经输入了邀请码，0：没有；1：有
                m_playerInfo.uiAlreadyInputCode = msg.uiValue;
                SingletonObject<HomeMainMediator>.GetInst().SetInviteKey();
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_uiLongZuan:
                m_playerInfo.uiLongZuan = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_TowerRemainPlayTimes:
                m_playerInfo.uiTowerRemainPlayTimes = msg.uiValue;
                SingletonObject<TowerMediator>.GetInst().ShowChallgeTimes();
                SingletonObject<TowerSweepMediator>.GetInst().ShowChallgeTimes();
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_TowerBuyTimes:
                m_playerInfo.uiTowerBuyTimes = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_TowerMaxCanNum:
                m_playerInfo.uiTowerMaxCanNum = msg.uiValue;
                m_playerInfo.uiTowerMaxCanNum = (uint)TowerManager.GetInst().GetMaxStaticLayerNumber((int)m_playerInfo.uiTowerMaxCanNum);
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_PartnerCount:
                PartnerManager.GetInst().PartnerCount = msg.uiValue;
                break;
            case EnumUpdateAvatarType.UpdateAvatarType_PartnerAddFight:
                PartnerManager.GetInst().AddFight = msg.uiValue;
                break;
        }
        RefreshMedatior();
        //}
    }

    private void RefreshMedatior()//收到服務端通知時，如果當前界面打開，則刷新該界面需要刷新的數據
    {
        HomeMainMediator homeinfo = SingletonObject<HomeMainMediator>.GetInst();
        if (homeinfo.IsOpen)
        {
            if (SingletonObject<GoldShopMediator>.GetInst().IsOpen)
                homeinfo.SetValue();
            else
                homeinfo.SetPlayerAssets();
        }
        PetFoodMediator petMediator = SingletonObject<PetFoodMediator>.GetInst();
        if (petMediator.IsOpen)
        {
            petMediator.RefreshDiamond();
        }
        //ClimbTowerMediator towerMediator = SingletonObject<ClimbTowerMediator>.GetInst();
        //if (towerMediator.IsOpen)
        //{
        //    towerMediator.RefreshTower();
        //}
        RechargeMediaor shopMediator = SingletonObject<RechargeMediaor>.GetInst();
        if (shopMediator.IsOpen)
        {
            shopMediator.RefreshDiamond();
        }
        BattlePrewarChoseMediator battlePrewar = SingletonObject<BattlePrewarChoseMediator>.GetInst();
        if (battlePrewar.IsOpen)
        {
            battlePrewar.UpdateResourceInfo();
        }
        BattlePveMediator battlePve = SingletonObject<BattlePveMediator>.GetInst();
        if (battlePve.IsOpen)
        {
            battlePve.RefreshBattlePve();
        }
        SocietyTeamPveInfoMediator teamPveInfo = SingletonObject<SocietyTeamPveInfoMediator>.GetInst();
        if (teamPveInfo.IsOpen)
        {
            teamPveInfo.UpdateActive();
        }
        SociatyMainMediator mianSociaty = SingletonObject<SociatyMainMediator>.GetInst();
        if (mianSociaty.IsOpen)
        {
            mianSociaty.UpdateActiveValue();
            mianSociaty.UpdateMyActive();
        }
        MiningMainMediator mianMining = SingletonObject<MiningMainMediator>.GetInst();
        if (mianMining.IsOpen)
        {
            mianMining.UpdateAssets();
        }
        IntensifyMediator intensify = SingletonObject<IntensifyMediator>.GetInst();
        if (intensify.IsOpen)
        {
            intensify.RefreshDiamond();
            intensify.setMprice();
        }
        if (SingletonObject<BuddiesTeamMediator>.GetInst().IsOpen)
        {
            SingletonObject<BuddiesTeamMediator>.GetInst().RefreshPartnerInfo();
        }

    }

    public uint GetCurChapter()
    {
        return m_playerInfo.uiCurChapter;
    }



    //判断当前是新手阶段还是进入家园
    public void CheckChapterState()
    {
        if (0 == m_playerInfo.uiCurChapter)//新手关卡
        {
            MaiDianManager.GetInst().SetMaidianByHttp(FixPrarm.enterGame);
            CLoadingManager.GetInst().JumpTo(eGameState.ChooseRole, eGameState.Battle, eBattleType.PVE, delegate()
            {
                SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.PVE;
                SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(DEFINE.NEW_PLAYER_SCENE_ID);
            });


        }
        else//进入家园
        {
            CLoadingManager.GetInst().JumpTo(eGameState.ChooseRole, eGameState.Home, eBattleType.None, delegate()
            {
                InitHome();
            });

        }
    }

    //oper,操作类型
    //uiBattleInstanceID 服务端战场实例唯一ID,创建战场填0
    //uiBattleID,map表静态ID
    //uiBattleType,战场难度
    //item 佣兵结构
    public void OperBattle(EnumBattleOper oper, uint uiBattleInstanceID, uint uiBattleID, uint uiBattleType, CBattleDataVec dropList, PartnerSortItem item = null)
    {
        if (oper == EnumBattleOper.EnumBattleOper_Enter)
        {
            BattleInfoMediator mBattleInfoMediator = SingletonObject<BattleInfoMediator>.GetInst();
            mBattleInfoMediator.MapId = uiBattleID;
            mBattleInfoMediator.NeedShow = true;
            mBattleInfoMediator.ResetBattleInfo();
            BattleResultManager.GetInst().isNext = false;

            m_StartBattleDataTime = DateTime.Now;
            m_StartBattleGameTime = Time.realtimeSinceStartup;
        }

        C2GRequestOperBattle msgToGame = new C2GRequestOperBattle();
        if (item != null)
        {
            if (item.bIsMercenary)
            {
                msgToGame.uiMercMasterID = item.uiMasterID;
                msgToGame.uiMercPartnerID = item.uiPartnerId;
            }
        }
        msgToGame.uiOperType = (uint)oper;
        msgToGame.uiBattleInstanceID = uiBattleInstanceID;
        msgToGame.uiBattleID = uiBattleID;
        msgToGame.uiBattleType = uiBattleType;
        msgToGame.uiAccountID = m_pHomeAvatarInfo.m_llAccountID;
        msgToGame.uiUseTime = 0;
        uint uStar = (uint)SingletonObject<BattleScene>.GetInst().PveStageStar;
        if (uStar > 3)
        {
            uStar = 3;
        }
        if (uStar < 0)
        {
            uStar = 0;
        }
        msgToGame.uiStar = uStar;
        List<uint> temp = LongjingManager.GetInst().GetLongJingListId((eBattleType)uiBattleType, eLongJingPos.Attack);
        uint attackID = 0;
        uint deffense = 0;
        if (temp.Count > 0)
        {
            attackID = temp[0];
        }
        temp.Clear();
        temp = LongjingManager.GetInst().GetLongJingListId((eBattleType)uiBattleType, eLongJingPos.Defense);
        if (temp.Count > 0)
        {
            deffense = temp[0];
        }


        msgToGame.uiDefenseCrystalId = deffense;
        msgToGame.uiAttackCrystalId = attackID;

        if (dropList != null)
        {
            msgToGame.uiDataVec = dropList;
        }
        if (oper == EnumBattleOper.EnumBattleOper_Enter)
        {
            m_uiBattleType = uiBattleType;
            ResurrectNum = 0;
            FriendManager mFriend = SingletonObject<FriendManager>.GetInst();

            if (uiBattleID >= DEFINE.ESCORT_START_MAPID && uiBattleID <= DEFINE.ESCORT_END_MAPID)
            {
                msgToGame.uiFriendPhone = 0;
                msgToGame.uiFriendPlayerID = 0;

           }
            else
            {
                msgToGame.uiFriendPhone = mFriend.GetFightFriend().uiPhoneNum;
                msgToGame.uiFriendPlayerID = mFriend.GetFightFriend().uiPlayerID;

                mFriend.ResetFightFriend();
            }

            BattleResultManager.GetInst().SetResultInfo();
        }
        else if (oper == EnumBattleOper.EnumBattleOper_CompleteReport ||
            oper == EnumBattleOper.EnumBattleOper_TowerReport ||
            oper == EnumBattleOper.EnumBattleOper_Escort || oper == EnumBattleOper.EnumBattleOper_ShouWei)
        {
            double useSystemTime = (DateTime.Now - m_StartBattleDataTime).TotalSeconds;
            double useGameTime = Time.realtimeSinceStartup - m_StartBattleGameTime;
            msgToGame.uiUseTime = (ushort)(useSystemTime > useGameTime ? useSystemTime : useGameTime);
        }

        if (oper == EnumBattleOper.EnumBattleOper_CompleteReport)
        {
            List<CMonsterDropInfo> monsterDropList = SingletonObject<BattleScene>.GetInst().MonsterDropList;
            foreach (CMonsterDropInfo info in monsterDropList)
            {
                List<uint> indexList = info.indexList;
                for (int i = 0; i < indexList.Count; ++i)
                {
                    if (i >= info.dropList.Count) break;
                    UInt32Type type32 = new UInt32Type();
                    type32.uiInt32Value = info.dropList[i].uiDropSerialNum;
                    msgToGame.vNotGainDrop.Add(type32);
                }

            }
        }

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_BATTLE_OPER, (ushort)ProCG.GAME_ACK_REQUEST_BATTLE_OPER, msgToGame);
    }

    //玩家数据是否合法
    public bool IsNumberAccordFormula()
    {
        if (ClientMain.GetInst().EnterTestScene)
        {
            return true;
        }

        if (!stCharacterCard.IsNumberAccordFormula(m_bakPlayerAttr, m_playerAttr))
        {
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100146), PopFrameType.singleOkButton, ReLoginCallback, false);
            return false;
        }
        return true;
    }

    private void ReLoginCallback()
    {
        SingletonObject<LoginScene>.GetInst().BackToAccountScene();
    }

    public void OperCurBattle(EnumBattleOper oper, CBattleDataVec dropList)
    {
        OperBattle(oper, m_uiBattleInstanceID, m_uiBattleID, m_uiBattleType, dropList);
    }

    //开始加载竞技场
    public void OperArenaBattle(uint sceneid)
    {
        CLoadingManager.GetInst().JumpTo(eGameState.ArenaUI, eGameState.Battle, eBattleType.Arena, delegate()
        {
            SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.Arena;
            SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(sceneid);
        });

    }

    //战场操作结果
    public void OperBattleResult(BinaryReader br)
    {
        C2GRespondOperBattle operBattle = new C2GRespondOperBattle();
        operBattle.Read(br);
        /***********相关处理***********/
        MyLog.Log("OperBattleResult:" + (EnumBattleOper)operBattle.uiOperType);
        m_bIsWeek = false;
        switch ((EnumBattleOper)operBattle.uiOperType)
        {
            case EnumBattleOper.EnumBattleOper_Enter:
                {
                    /* 前2位表示地图的类型
                  10表示普通关卡地图
                  11表示爬塔关卡地图
                  12表示护送关卡地图
                  13表示末日荒野地图
                  14表示世界BOSS地图
                  15表示守护关卡地图
                  20表示精英关卡地图*/

                    if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_SUCCESS)
                    {
                        //保存战场动态信息
                        m_uiBattleInstanceID = operBattle.uiBattleInstanceID;
                        m_uiBattleID = operBattle.uiBattleID;

                        //保存怪物掉落列表
                        SingletonObject<BattleScene>.GetInst().SetMonsterDrop(m_uiBattleID, operBattle.vMonsterDrops);

                        BattleResultManager.GetInst().mExitBattle = ExitBattleType.Auto;//设置退出战场返回类型

                        //开始加载战场:
                        if (m_uiBattleID / 1000000 == 11)
                        //if (m_uiBattleID > DEFINE.CLIMBTOWER_MAP_START_ID && m_uiBattleID < 12011001)
                        {
                            //爬塔
                            //CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.ClimbTower, delegate()
                            //{
                            //    SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.ClimbTower;
                            //    SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(operBattle.uiBattleID);
                            //});

                        }
                        else if (m_uiBattleID / 1000000 == 12)
                        //else if (m_uiBattleID >= DEFINE.ESCORT_START_MAPID && m_uiBattleID <= DEFINE.ESCORT_END_MAPID)
                        {
                            //护送
                            if (operBattle.uiYieldActivity == DEFINE.ESCORT_ACTIVITY_ID)
                            {
                                m_bIsActiviTime = true;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }
                            else
                            {
                                m_bIsActiviTime = false;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }
                            CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.Escort, delegate()
                            {
                                SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.Escort;
                                SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(m_uiBattleID);
                            });

                        }
                        else if (m_uiBattleID / 1000000 == 15)
                        {
                            //守护
                            if (operBattle.uiYieldActivity == DEFINE.PROTECT_ACTIVITY_ID)
                            {
                                m_bIsActiviTime = true;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }
                            else
                            {
                                m_bIsActiviTime = false;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }
                            CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.Protect, delegate()
                            {
                                SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.Protect;
                                SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(m_uiBattleID);
                            });
                        }
                        else if (m_uiBattleID / 1000000 == 19)
                        {
                            //PVP
                            CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.Protect, delegate()
                            {
                                SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.Pvp;
                                SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(m_uiBattleID);
                            });
                        }
                        else
                        {
                            //PVE
                            if (operBattle.uiYieldActivity == DEFINE.PVE_ACTIVITY_ID || operBattle.uiYieldActivity == DEFINE.All_ACTIVITY_ID)
                            {
                                if (operBattle.uiYieldActivity == DEFINE.All_ACTIVITY_ID)
                                    m_bIsWeek = true;
                                m_bIsActiviTime = true;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }
                            else
                            {
                                m_bIsActiviTime = false;
                                m_uiIsActiviTimes = operBattle.uiYeildRate;
                            }

                            CLoadingManager.GetInst().JumpTo(eGameState.WorldMap, eGameState.Battle, eBattleType.PVE, delegate()
                            {
                                SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.PVE;

                                SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(operBattle.uiBattleID);
                                SingletonObject<BattlePveMediator>.GetInst().CloseReset();
                                SingletonObject<BattlePveMediator>.GetInst().tweenType = eTweenCameraType.FromBattle;
                                SingletonObject<WorldAreaMapMediator>.GetInst().WorldPanelReset();


                                uint type = operBattle.uiBattleID / 1000000;
                                uint star = 0;
                                if (type == 10)//普通关卡
                                    star = BattlePveManager.GetInst().GetCurBattleInfo(operBattle.uiBattleID);
                                else if (type == 20)//精英关卡
                                {
                                    BattlePVEContent pve = BattlePveManager.GetInst().GetPveLoader(operBattle.uiBattleID);
                                    uint pveId = 0;
                                    if (null != pve)
                                    {
                                        pveId = (uint)pve.Key;
                                    }
                                    stHeroBattleInfo hero = BattlePveManager.GetInst().HeroBattleInfoID(pveId);
                                    if (null != hero)
                                    {
                                        star = hero.uiStar;
                                    }
                                }
                                BattleResultManager.GetInst().mStarLevel = star;
                                if (star == 0)
                                {
                                    SceneContent mSceneLoader = HolderManager.m_SceneHolder.GetStaticInfo(operBattle.uiBattleID);
                                    if (mSceneLoader.BackType == 2)
                                    {
                                        BattleResultManager.GetInst().mExitBattle = ExitBattleType.BackHome;
                                    }
                                    else if (mSceneLoader.BackType == 3)
                                    {
                                        BattleResultManager.GetInst().mExitBattle = ExitBattleType.BackMap2d;
                                    }
                                }
                            });
                        }
                    }
                    else if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_AlreadyInBattle)
                    {
                       SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100207), PopFrameType.singleOkButton, delegate()
                        {
                            SingletonObject<LoginScene>.GetInst().BackToAccountScene();
                        });
                    }
                    else if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_HighFriendAssistLimit)
                    {
                        //今日使用等级大于自身10级的好友助战次数已达上限
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9938036));
                    }
                    else
                    {
                        BattleRelusetControl((EnumBattleResult)operBattle.uiResultCode);
                    }

                }
                break;
            case EnumBattleOper.EnumBattleOper_Exit:
                {
                    if (!BattleResultManager.GetInst().nextBattle())
                    {
                        ExistCurrBattle();
                    }

                    if (operBattle.uiResultCode != (uint)EnumBattleResult.EnumBattleResult_SUCCESS)
                    {
                        MyLog.Log(operBattle.uiBattleID + "=operBattle.uiBattleID   退出时mapID");
                        BattleRelusetControl((EnumBattleResult)operBattle.uiResultCode);

                    }
                    eBattleType battleType = SingletonObject<CBattleSceneLoading>.GetInst().battleType;
                    if (battleType == eBattleType.PVE)
                    {
                        BattlePveManager.GetInst().RequestHeroBattleInfo();
                        BattlePveManager.GetInst().RequestExpertBattleInfo();

                    }
                }
                break;
            case EnumBattleOper.EnumBattleOper_KillMonster:
                {
                }
                break;
            case EnumBattleOper.EnumBattleOper_CompleteReport:
                {
                    if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_ThirdTools)
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100144), PopFrameType.singleOkButton, CheckThirdPartyToolCallback, false);
                        break;
                    }
                    BattleResultManager.GetInst().SetLaterBattleInfo();


                }
                break;
            case EnumBattleOper.EnumBattleOper_TowerReport:
                {
                    //爬塔类型
                    if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_ThirdTools)
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100144), PopFrameType.singleOkButton, CheckThirdPartyToolCallback, false);
                        break;
                    }
                }
                break;
            case EnumBattleOper.EnumBattleOper_Revive://战场复活
                {
                    if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_NotEnoughDiamond)
                    {
                        return;
                    }
                    //SingletonObject<BattleLeftButtonMediator>.GetInst().RefreshPartner();
                    ResurrectNum++;
                    BattleResultManager.GetInst().ResurrectAvatar();
                }
                break;
            case EnumBattleOper.EnumBattleOper_Escort:
            case EnumBattleOper.EnumBattleOper_ShouWei:
                {
                    if (operBattle.uiResultCode == (uint)EnumBattleResult.EnumBattleResult_ThirdTools)
                    {
                        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100144), PopFrameType.singleOkButton, CheckThirdPartyToolCallback, false);
                        break;
                    }
                }
                break;
        }
    }


    public void CheckThirdPartyToolCallback()
    {
        ExistCurrBattle();
    }

    private void ExistCurrBattle()
    {
        CBattleSceneLoading m_sceneLoading = SingletonObject<CBattleSceneLoading>.GetInst();
        switch (m_sceneLoading.battleType)
        {
            case eBattleType.ClimbTower:
                ExitClimbTower();
                break;
            case eBattleType.PVE:
            case eBattleType.GlobalBoss:
            case eBattleType.TeamPve:
                ExistBattle();
                break;
            default:
                {
                    ExitBattleToHome();
                }
                break;
        }
    }

    private void ExistBattle()
    {
        if (0 == m_uiBattleInstanceID)
        {
            CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.Home, eBattleType.None, delegate()
            {
                InitHome();
            });
            return;
        }
        ExitBattleType mExitBattle = BattleResultManager.GetInst().mExitBattle;
        switch (mExitBattle)
        {
            case ExitBattleType.Auto:
                {
                    CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.WorldMap, eBattleType.None, delegate()
                    {
                        InitPve(curPveMapID, true);
                    });
                }
                break;
            case ExitBattleType.BackHome:
                {
                    CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.Home, eBattleType.None, delegate()
                    {
                        InitHome();
                    });
                }
                break;
            case ExitBattleType.BackPve:
                {
                    CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.WorldMap, eBattleType.None, delegate()
                    {
                        InitPve(curPveMapID, true);
                    });
                }
                break;
            case ExitBattleType.BackMap2d:
                {
                    CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.WorldMap, eBattleType.None, delegate()
                    {
                        InitPve(curPveMapID, true);
                        SingletonObject<WorldAreaMapMediator>.GetInst().normalPveOpen = true;
                    });
                }
                break;
        }
    }


    private void ExitBattleToHome()
    {
        CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.Home, eBattleType.None, delegate()
        {
            InitHome();
        });

    }

    private void ExitClimbTower()
    {
        CLoadingManager.GetInst().JumpTo(eGameState.Battle, eGameState.Home, eBattleType.None, delegate()
        {
            SingletonObject<BattleScene>.GetInst().ClimbData.ResetClimbData();
            InitHome();
            //清空爬塔奖励记录
            towerAwardDic.Clear();
            towerSweepAwardDic.Clear();
        });


    }

    public bool CanResurrect()//pve战场是否可以复活
    {
        BattleScene scene = SingletonObject<BattleScene>.GetInst();
        SceneContent m_loader = scene.GetSceneLoader();
        Avatar mAvatar = SingletonObject<Avatar>.GetInst();
        if (!mAvatar.AvatarDead || !mAvatar.PartnerDead || m_loader.ResurrectType == 0)
        {
            return false;
        }
        if (m_loader.ResurrectNum > 0 && ResurrectNum >= m_loader.ResurrectNum)
        {
            return false;
        }
        return true;
    }

    public delegate void JionHomeCallBack();

    public void InitHome()
    {
        SingletonObject<CHomeLoading>.GetInst().EnterScene(DEFINE.HOME_SCENE_ID);
    }

    public void InitPve(uint pveMapID, bool isEnterLoad = false)
    {
        curPveMapID = pveMapID;
        SingletonObject<CWorldMapLoading>.GetInst().EnterScene(curPveMapID, isEnterLoad);
        //CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.PVE, delegate()
        //{
        //    SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.PVE;
        //    SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(curPveMapID, isEnterLoad);
        //});

    }

    //请求进入家园
    public void RequestEnterHome()
    {
        MyLog.Log("-------------------------------RequestEnterHome----------------------------------------" + Time.time);
        C2GEnterHome msgToGame = new C2GEnterHome();
        //暂时写死
        //if (m_bornPosition == Vector3.zero)
        //{
        //    m_bornPosition = SingletonObject<HomeScene>.GetInst().GetBornPosition();
        //    msgToGame.sPosition.fPositionX = m_bornPosition.x;
        //    msgToGame.sPosition.fPositionY = m_bornPosition.y;
        //    msgToGame.sPosition.fPositionZ = m_bornPosition.z;
        //}

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_ENTER_HOME, (ushort)ProCG.GAME_ACK_CLIENT_ENTER_HOME_RESULT, msgToGame);
    }
    //请求返回选择人物界面
    public void ChangeRoleRequest()
    {
        NullStruct msgToGame = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_BACK_TO_SELECT, msgToGame);

        SingletonObject<MailMediator>.GetInst().RequsetMail = true;
        LongjingManager.GetInst().isLogin = true;

    }
    //请求玩家属性
    public void RequestPlayerAttribute(ulong playerID)
    {
        C2GRequestAttr requestMsg = new C2GRequestAttr();
        requestMsg.uiPlayerID = playerID;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_ATTR_INFO, (ushort)ProCG.GAME_ASYN_ATTR_INFO, requestMsg);
    }

    //进入家园结果
    private void EnterHomeResult(BinaryReader br)
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.LOADING)
        {
            return;
        }
        MyLog.Log("-------------------------------EnterHomeResult----------------------------------------" + Time.time);
        G2CEnterHomeResult msg = new G2CEnterHomeResult();
        msg.Read(br);
        if (m_myTrans == null)
        {

            cHomeNpc = SingletonObject<CHomeNpc>.GetInst();
            cHomeNpc.CreateHomeNpc();

            m_enterHomeResult = (EnumEnterHomeResult)msg.uiResult;

            Vector3 position = m_bornPosition == Vector3.zero ? m_bornPosition : m_position;
            SingletonObject<HomeScene>.GetInst().CreatePlayerMode(position, Quaternion.identity);
        }
    }

    private void DelayEnterHome()
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.LOADING)
        {
            return;
        }
        ClientMain.GetInst().SetGameState(eGameState.Home);

        NewBieGuidManager.GetInst().CheckHomeGuide();
        NewBieGuidManager.GetInst().SetHomeGuide();

        switch (m_enterHomeResult)
        {
            case EnumEnterHomeResult.EnumEnterHomeResult_Success:
                {
                    bool jumpTo = JumpToManager.GetInst().JumpBackTo();
                    if (!jumpTo)
                    {
                        eGameState eBeforeState = CLoadingManager.GetInst().GetBeforeState();
                        if (eBeforeState == eGameState.ArenaUI)
                        {
                            if (!SingletonObject<ChooseArenaTypeMediator>.GetInst().IsOpen)
                                SingletonObject<ChooseArenaTypeMediator>.GetInst().Open(null);
                        }
                        else if (eBeforeState == eGameState.Battle)
                        {
                            CBattleSceneLoading loading = SingletonObject<CBattleSceneLoading>.GetInst();
                            if (loading.battleType == eBattleType.ClimbTower)
                            {
                                if (!SingletonObject<TowerMediator>.GetInst().IsOpen)
                                    SingletonObject<TowerMediator>.GetInst().Open(delegate
                                    {
                                        switch (TowerManager.GetInst().TowerBattleType)
                                        {
                                            case eTowerBattleType.Single:
                                                SingletonObject<TowerSingleInfoMediator>.GetInst().Open(null);
                                                break;
                                            case eTowerBattleType.Team:
                                                SingletonObject<TowerTeamInfoMediator>.GetInst().Open(null);
                                                break;
                                        }
                                    });
                            }
                            else if (loading.battleType == eBattleType.Wasteland)
                            {
                                loading.battleType = eBattleType.None;
                                if (SingletonObject<MoorResultMediator>.GetInst().bBattleResult)
                                {
                                    OpenMoorMediator();
                                }
                                else
                                {
                                    if (BattleResultManager.GetInst().QuitBattleType != eQuitBattleType.Jump)
                                    {
                                        OpenMoorMediator();
                                    }
                                }
                            }
                            else if (loading.battleType == eBattleType.Escort || loading.battleType == eBattleType.Protect)
                            {
                                loading.battleType = eBattleType.None;
                                if (!SingletonObject<EscortMediator>.GetInst().IsOpen)
                                    SingletonObject<EscortMediator>.GetInst().Open(null);
                            }
                            else if (loading.battleType == eBattleType.Mining)
                            {
                                loading.battleType = eBattleType.None;
                                if (!SingletonObject<MiningMainMediator>.GetInst().IsOpen)
                                    SingletonObject<MiningMainMediator>.GetInst().Open(null);
                            }
                            else if (loading.battleType == eBattleType.Pvp)
                            {
                                loading.battleType = eBattleType.None;
                                if (!SingletonObject<LeaguemainMediator>.GetInst().IsOpen)
                                    SingletonObject<LeaguemainMediator>.GetInst().Open(null);
                            }
                        }

                    }
                }
                break;
            case EnumEnterHomeResult.EnumEnterHomeResult_AlreyInHome:
                {
                    if (m_myTrans == null)
                        SingletonObject<HomeScene>.GetInst().CreatePlayerMode(m_position, m_rotation);

                }
                break;
            case EnumEnterHomeResult.EnumEnterHomeResult_NoName:
                {
                    if (!NewBieGuidManager.GetInst().IsInStoryOrOpen)
                    {
                        SingletonObject<NickNameMediator>.GetInst().Open(null);//起昵称移到剧情之后
                    }
                }
                break;
        }
    }

    private void OpenMoorMediator()
    {
        if (!SingletonObject<MoorMediator>.GetInst().IsOpen)
            SingletonObject<MoorMediator>.GetInst().Open(null);
    }

    //设置昵称
    private void SetNickNameResult(BinaryReader br)
    {
        G2CSetUserNameResult msg = new G2CSetUserNameResult();
        msg.Read(br);
        switch (msg.uiResult)
        {
            case (ushort)EnumLoginResult.EnumSetUserResult_Success:
                {
                    bool isNewBie = string.IsNullOrEmpty(m_pHomeAvatarInfo.szPlayerName);
                    m_pHomeAvatarInfo.szPlayerName = msg.szUserName;
                    UpdateAvatarInfoComponent();
                    SingletonObject<HomeMainMediator>.GetInst().SetPlayerAssets();
                    if (isNewBie)
                    {
                        MaiDianManager.GetInst().SetMdUpLoad(0, MaiDianType.finishSth);
                        NewBieGuidManager.GetInst().NextGuide(eHGuideTarget.Task);
                        NewBieGuidManager.GetInst().SetHomeGuide();

                        SDKManager.GetInst().CreateRoleInfo(SingletonObject<LoginScene>.GetInst().GetCurrentLoginAvatarPlayerID().ToString(), Common.SetPlayerName(m_pHomeAvatarInfo.szPlayerName));
                    }
                    else
                    {
                        //修改昵称成功
                        string tips = Common.GetText(9100213);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.green);
                    }

                    SingletonObject<NickNameMediator>.GetInst().Close();
                }
                break;
            case (ushort)EnumLoginResult.EnumSetUserResult_Failed:
            case (ushort)EnumLoginResult.EnumSetUserResult_BeOccupied:
            case (ushort)EnumLoginResult.EnumSetUserResult_TooLong:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100013));
                }
                break;
            case (ushort)EnumLoginResult.EnumLoginResult_DiamondNotEnough:
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100015), PopFrameType.singleOkButton);
                }
                break;
        }
    }

    public void ChangeNickNameResult(BinaryReader br)
    {
        G2CAckRename msg = new G2CAckRename();
        msg.Read(br);
        switch (msg.uiResult)
        {
            case (uint)EnumLoginResult.EnumLoginResult_Succeed:
                break;
            case (uint)EnumLoginResult.EnumLoginResult_DiamondNotEnough:
                break;
        }
    }

    //战场超时
    private void BattleTimeOut(BinaryReader br)
    {
        G2CNotifyBattleTimeOut msg = new G2CNotifyBattleTimeOut();
        msg.Read(br);
        //超时处理直接退出战场

        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100140), PopFrameType.singleOkButton, delegate()
        {//必须要弹框，要不游戏暂停后直接卡死
            UIManager.GetInst().IsLockNGUIEvent(false);
            CGameConfig.GetInst().Pause = false;//
            ExitAllBattle();
        }, false);
    }

    public void ExitAllBattle()
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.Battle)
        {
            return;
        }
        if (SingletonObject<BattleScene>.GetInst().IsNewPlayer)
        {
            ExistCurrBattle();
        }
        else
        {
            OperCurBattle(Protocol.EnumBattleOper.EnumBattleOper_Exit, null);
        }
    }

    //同步玩家属性
    public void SyncPlayerAttr(BinaryReader br)
    {
        C2GRespondAttrInfo msg = new C2GRespondAttrInfo();
        msg.Read(br);

        AttrValue.GetAttrVec(ref m_playerAttr, msg.attrVec);
        m_bakPlayerAttr = m_playerAttr.Decode();

        if (m_bakPlayerAttr.nMaxHp == 0)
        {
            MyLog.LogError(" player  HP IS ZERO  ! ");
        }
        if (m_bakPlayerAttr.fMoveSpeed == 0)
        {
            MyLog.LogError(" player  MoveSpeed IS ZERO  ! ");
        }
        uint fightgs = msg.uiAttriFight + msg.uiSkillFight;
        //战力默认值的时候不弹出tips
        if (fightTotalValue > 1)
        {
            SingletonObject<GsUpTipMediator>.GetInst().ShowGsUpTip((uint)fightTotalValue, fightgs);
        }
        fightAttrValue = msg.uiAttriFight;
        fightTotalValue = fightgs;
        MyLog.LogError("" + fightTotalValue);
        //SingletonObject<PlayerBaseInforMediator>.GetInst().SetPlayerInfo();
    }



    public void SetWeaponClothesID(uint uiWeaponID, uint uiClothesID)
    {
        uint uiTmpWeapon = m_pHomeAvatarInfo.uiWeaponID;
        uint uiTmpCloth = m_pHomeAvatarInfo.uiClothesID;


        m_pHomeAvatarInfo.uiWeaponID = uiWeaponID;
        m_pHomeAvatarInfo.uiClothesID = uiClothesID;

        if (uiWeaponID / 100 != uiTmpWeapon / 100 && uiTmpWeapon != 0)
        {
            UpdateWeapon(uiWeaponID);
        }

        if (uiClothesID / 100 != uiTmpCloth / 100 && uiTmpCloth != 0)
        {
            if (m_myTrans != null)
            {
                UpdateCloth(uiClothesID, m_myTrans.position, m_myTrans.rotation);
            }

        }

        SingletonObject<LoginScene>.GetInst().UpdateWeaponOrCloth(m_pHomeAvatarInfo.uiPlayerJob, uiWeaponID, uiClothesID);

    }

    //预加载所有技能大图标
    public void PreLoadSkillIcon(bool bLoadPassSkill = true, bool bLoadInitiativeSkill = true)
    {
        _mPassivelySkillPath.Clear();
        _mPassivelySkillIcon.Clear();
        _mInitiativeSkillIcon.Clear();
        _mInitiativeSkillPath.Clear();
        List<stSkillInfo> allskill = SkillManager.GetAllSkillByJob(GetHomeAvatarInfo().uiPlayerJob);
        for (int i = 0, count = allskill.Count; i < count; i++)
        {
            SkillUpContent loader = HolderManager.m_SkillUpHolder.GetStaticInfo(allskill[i].uiSkillID);
            if (loader != null)
            {
                if (loader.SkillType == 0 && bLoadPassSkill)
                {
                    string path = DEFINE.AVATAR_SKILL_ICON_PATH + loader.SkillIcon + ".tex";
                    LoadHelp.LoadObject(path, path, ThreadPriority.Normal, OnLoadPassSkill);
                }
                else if (loader.SkillType == 1 && bLoadInitiativeSkill)
                {
                    string path = DEFINE.AVATAR_SKILL_ICON_PATH + loader.SkillIcon + ".tex";
                    LoadHelp.LoadObject(path, path, ThreadPriority.Normal, OnLoadInitiativeSkill);
                }
            }
        }
    }

    private void OnLoadPassSkill(string interim, UnityEngine.Object asset)
    {
        if (asset != null)
        {
            Texture tex = (Texture)asset;
            if (!_mPassivelySkillIcon.Contains(tex))
                _mPassivelySkillIcon.Add(tex);
            if (!_mPassivelySkillPath.Contains(interim))
                _mPassivelySkillPath.Add(interim);
        }
    }

    private void OnLoadInitiativeSkill(string interim, UnityEngine.Object asset)
    {
        if (asset != null)
        {
            Texture tex = (Texture)asset;
            if (!_mInitiativeSkillIcon.Contains(tex))
                _mInitiativeSkillIcon.Add(tex);
            if (!_mInitiativeSkillPath.Contains(interim))
                _mInitiativeSkillPath.Add(interim);
        }
    }

    /// <summary>
    /// 释放被动技能大图标:场景切换即可释放
    /// </summary>
    public void ReleasePassSkillIcon()
    {
        for (int i = 0, count = _mPassivelySkillPath.Count; i < count; i++)
        {
            if (_mPassivelySkillPath[i] != null)
                LoadHelp.RemoveObject(_mPassivelySkillPath[i]);
        }

        _mPassivelySkillIcon.Clear();
        _mPassivelySkillPath.Clear();
    }

    /// <summary>
    /// 释放主动技能图标:切换角色才释放
    /// </summary>
    public void ReleaseInitiativeSkillIcon()
    {
        for (int i = 0, count = _mInitiativeSkillPath.Count; i < count; i++)
        {
            if (_mInitiativeSkillPath[i] != null)
                LoadHelp.RemoveObject(_mInitiativeSkillPath[i]);
        }
        _mInitiativeSkillIcon.Clear();
        _mInitiativeSkillPath.Clear();
    }

    public List<Texture> InitiativeSkillIcon()
    {
        return _mInitiativeSkillIcon;
    }

    public List<Texture> PassivelySkillIcon()
    {
        return _mPassivelySkillIcon;
    }

   
    public void ResetPveCrystalId()
    {
      
        List<CrystalItemInfo> atkCryItem = LongjingManager.GetInst().GetLongJingList(eBattleType.PVE, eLongJingPos.Attack);
        List<CrystalItemInfo> defCryItem = LongjingManager.GetInst().GetLongJingList(eBattleType.PVE, eLongJingPos.Defense);

        if (null != atkCryItem && atkCryItem.Count > 0)
            m_pHomeAvatarInfo.uiAttackCrystalId = atkCryItem[0].uiCrystalId;
        else
        {
            m_pHomeAvatarInfo.uiAttackCrystalId = 0;
        }

        if (null != defCryItem && defCryItem.Count > 0)
            m_pHomeAvatarInfo.uiDefenceCrystalId = defCryItem[0].uiCrystalId;
        else
        {
            m_pHomeAvatarInfo.uiDefenceCrystalId = 0;
        }
    }

    protected override void LoadAvatarCompleted(GameObject o, params object[] args)
    {
        ResetPveCrystalId();

        base.LoadAvatarCompleted(o, args);

        InitFollowCamera(eCAMERAFOLLOW.DIRECT, true);

        //m_syncPosTimer.SetTimer(1);

        DelayEnterHome();


        CMusicManager.GetInst().FollowObj = o;



    }


    public void InitFollowCamera(eCAMERAFOLLOW type, bool resetFOV)
    {
        SceneInfoContent info = SingletonObject<HomeScene>.GetInst().SceneLoaderInfo;
        if (info != null && m_pObject != null && m_pObject.gameCObject != null)
        {
            CCamera.GetInst().SetCameraEffect((uint)info.CameraID, null, null, new object[] { m_pObject.gameCObject, type, true, resetFOV });
        }
        //else
        //{
        //    MyLog.LogError("The game has not cameraID");
        //}
    }


    public override void Update()
    {
        base.Update();

        if (Input.GetKeyUp(KeyCode.Mouse0) && !CBaseStory.IsInGameStory)
        {
            OnMouseUp();
        }

        if (m_myTrans != null)
        {
            //             if (m_syncPosTimer.IsExpired(true))
            //             {
            //                 AsynPosition(m_myTrans.position);
            //             }

            m_position = m_myTrans.position;
            m_rotation = m_myTrans.rotation;
        }

        #region 实时检测NPC距离

        foreach (KeyValuePair<uint, CHomeBaseNpc> item in CHomeNpc.GetInst().dNpcDict)
        {
            if (Common.GetHorizontalDis(item.Value.npcposition, m_position) <= DEFINE.NPC_REMAINING_DISTANCE)//检测玩家与NPC之间距离
            {
                isNearNpc = true;
                nearNpcId = (uint)item.Value.homeNpcLoader.Key;
                nearNpcPosition = item.Value.npcposition;
            }
        }

        if (isNearNpc)
        {
            //进入可点击范围，打开泡泡
            foreach (KeyValuePair<uint, NpcNameComponent> pair in CHomeNpc.GetInst().NpcNameDic)
            {
                if (pair.Key == nearNpcId)
                {
                    pair.Value.SetBubbleActive(true);
                }
                else
                {
                    pair.Value.SetBubbleActive(false);
                }
            }

            if (Common.GetHorizontalDis(nearNpcPosition, m_position) > DEFINE.NPC_REMAINING_DISTANCE) //检测玩家与NPC之间距离
            {
                foreach (KeyValuePair<uint, NpcNameComponent> pair in CHomeNpc.GetInst().NpcNameDic)
                {
                    pair.Value.SetBubbleActive(false);
                }
                isNearNpc = false;
            }
        }
        #endregion

        #region 实时检测是否点击NPC
        if (isClickNpc && ClientMain.GetInst().GetCurrentState() == eGameState.Home) //点击NPC
        {
            if (mAgentObj != null)
            {
                m_npcID = 0;
                CheckIsSelectNpc();
                if (Common.GetHorizontalDis(mAgentObj.transform.position, m_position) <= DEFINE.NPC_REMAINING_DISTANCE)   //检测玩家与NPC之间距离
                {
                    SingletonObject<SystemPromptMediator>.GetInst().Close();
                    StopNavMeshAgent();
                    EnterState(eActionState.IdelInHome);
                    isClickNpc = false;
                    CheckIsNpc(mAgentObj);
                    mAgentObj = null;
                }
            }
            else
            {
                if (m_npcID != 0)
                {
                    mAgentObj = null;
                    CheckIsSelectNpc();
                    if (CheckAbsDistance())
                    {
                        SingletonObject<SystemPromptMediator>.GetInst().Close();
                        CloseHomeInfoMediator();
                        //UIManager.GetInst().CloseAllWnd();
                        NpcUIManager mNpcUIManager = NpcUIManager.GetInst();
                        if (mNpcUIManager.IsDestPosition)
                        {
                            mNpcUIManager.ResultDestPosition(true);
                        }
                        isClickNpc = false;
                        CheckIsNpc();
                        m_npcID = 0;
                    }
                }
            }
        }
        #endregion

        #region 升级检测
        if (levelUpInbattale == false)
        {
            if (isLevelUpdata && isVigarUpdata && isMaxVigarUpdata)
            {
                ushort lastlv = SingletonObject<LevelUpMediator>.GetInst().lastLevel;
                if (m_pHomeAvatarInfo.uiPlayerLevel > 1 && m_pHomeAvatarInfo.uiPlayerLevel > lastlv)
                {
                    SingletonObject<LevelUpMediator>.GetInst().ShowLevelUp();
                    SingletonObject<EquipItemManager>.GetInst().SetEquipNewTip();
                    oldLevel = m_pHomeAvatarInfo.uiPlayerLevel;
                    oldVigar = m_playerInfo.uiCurVigor;
                    oldMaxVigar = m_playerInfo.uiMaxVigor;
                    isLevelUpdata = false;
                    isVigarUpdata = false;
                    isMaxVigarUpdata = false;
                }
            }
        }
        else
        {
            levelUpInbattale = false;
            isLevelUpdata = false;
            isVigarUpdata = false;
            isMaxVigarUpdata = false;
        }
        #endregion

        if (ClientMain.GetInst().GetCurrentState() == eGameState.Home)
        {
            mCanRefresh = CheckNeedRefreshModel();
            if (mCanRefresh)
            {
                mCanRefresh = false;
                int randomtime = UnityEngine.Random.Range(10, 70);
                if (mDelayCallBackIndex == 0) UnityCallBackManager.GetInst().RemoveCallBack(mDelayCallBackIndex);
                mDelayCallBackIndex = UnityCallBackManager.GetInst().AddCallBack(randomtime, DelayRequest);
            }
        }
    }

    private void DelayRequest(params object[] args)
    {
        RankManager.GetInst().OnRequestTopOne();
    }

    private bool CheckNeedRefreshModel()
    {
        DateTime current = System.DateTime.Now;
        if (current.Minute == 0 && current.Second == 0)
        {
            //分钟和秒钟都是0，则整点
            return true;
        }
        return false;
    }

    public void AsynPosition(Vector3 position)
    {
        return;
        //距离过近不再同步,减轻服务器压力
        if (Common.Get2DVecter3Length(m_lastSyncPosition, position) < 0.1f)
        {
            return;
        }

        m_lastSyncPosition = position;

        //向服务器同步位置 
        C2GClientAsynPos asynPos = new C2GClientAsynPos();

        asynPos.sPosition.fPositionX = position.x;
        asynPos.sPosition.fPositionY = position.y;
        asynPos.sPosition.fPositionZ = position.z;

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_ASYN_GAME_POSITION, asynPos);
    }


    private void OnMouseUp()
    {
        NpcUIManager mNpcUIManager = NpcUIManager.GetInst();
        if (mNpcUIManager.IsDestPosition)
        {
            if (mNpcUIManager.IsLock) return;
            mNpcUIManager.ResultDestPosition(false);
        }
        if (UIManager.GetInst().MouseInNGUI())
        {
            //主城当中，主角移动中触发NGUI点击事件后，人物移动停止,清除选中状态、提示等信息
            if (ClientMain.GetInst().GetCurrentState() == eGameState.Home)
            {
                StopStep();
            }
            return;
        }

        RaycastHit hit;
        Camera camera = CCamera.GetInst().GetCamera();

        Ray ray = camera.ScreenPointToRay(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));


        if (Physics.Raycast(ray, out hit, 1000, 1 << DEFINE.HOMENPC_LAYER))
        {
            Vector3 position = Common.NavSamplePosition(hit.point);
            mAgentObj = hit.transform.root.gameObject;
            NavMeshPath path = new NavMeshPath();
            m_nma.CalculatePath(position, path);
            Vector3 npcPostion = mAgentObj.transform.position;
            CheckIsSelectNpc();
            if (Common.GetHorizontalDis(npcPostion, m_position) <= DEFINE.NPC_REMAINING_DISTANCE)
            {
                EnterState(eActionState.IdelInHome);
                CheckIsNpc(mAgentObj);
                return;
            }
            else
            {
                isClickNpc = true;
                if (path.status != NavMeshPathStatus.PathPartial)
                {
                    uint value = 0;
                    uint.TryParse(mAgentObj.name, out value);
                    HomeNPCContent npcLoader = HolderManager.m_HomeNPCHolder.GetStaticInfo(value);
                    if (null != npcLoader)
                    {
                        SingletonObject<SystemPromptMediator>.GetInst().ShowPrompt(Common.GetTextS(9100143, Common.GetText(npcLoader.Name)));
                    }
                    SetDestPosition(position);
                }
            }
        }
        else
        {
            if (isClickNpc)
            {
                SingletonObject<SystemPromptMediator>.GetInst().Close();
            }
            isClickNpc = false;
            m_npcID = 0;
            mAgentObj = null;
            ReleaseSelectNpcParticle();
        }

        if (Physics.Raycast(ray, out hit, 1000, 1 << DEFINE.TERRAINLAYER) && !isClickNpc)
        {
            Vector3 position = Common.NavSamplePosition(hit.point);

            NavMeshPath path = new NavMeshPath();
            if (null != m_nma)
            {
                m_nma.CalculatePath(position, path);
            }

            if (path.status != NavMeshPathStatus.PathPartial)//能移动到该点
            {
                SetDestPosition(position);
            }
        }
    }

    public void StopStep()
    {
        mAgentObj = null;
        StopNavMeshAgent();
        ReleaseSelectNpcParticle();
        SingletonObject<SystemPromptMediator>.GetInst().Close();
        EnterState(eActionState.IdelInHome);
    }

    private string tempNpcIdStr = string.Empty;
    private bool isNearNpc = false;
    private uint nearNpcId;
    private Vector3 nearNpcPosition;
    /// <summary>
    /// 检测是否选中NPC
    /// </summary>
    private void CheckIsSelectNpc()
    {
        //存在选中NPC.
        if (m_npcSelectParticle != 0)
        {
            if (mAgentObj != null && m_npcID != 0)
            {
                int id = 0;
                HomeNPCContent npcLoader = HolderManager.m_HomeNPCHolder.GetStaticInfo(m_npcID);
                id = npcLoader.Key;
                if (mAgentObj.transform.name == id.ToString())
                {
                    //2次选择相同
                    return;
                }
            }
            if (mAgentObj != null)
            {
                if (mAgentObj.name == tempNpcIdStr)
                {
                    return;
                }
            }

            if (m_npcID.ToString() == tempNpcIdStr)
            {
                return;
            }

            CParticle cp = CParticleManager.GetInst().GetParticle(m_npcSelectParticle);
            if (cp != null)
            {
                cp.Remove();
            }
            m_npcSelectParticle = 0;
            m_bIsLoadParticle = false;
        }

        if (!m_bIsLoadParticle)
        {
            //检测其他NPC是否处于选中状态，如果是，卸载npc特效。
            m_bIsLoadParticle = true;
            if (mAgentObj != null)
            {
                tempNpcIdStr = mAgentObj.name;
                m_npcID = 0;
                LoadSelectNpcEffect(mAgentObj.transform.position);
            }
            if (m_npcID != 0)
            {
                tempNpcIdStr = m_npcID.ToString();
                mAgentObj = null;
                LoadSelectNpcEffect(m_npcPosition);
            }
        }
    }

    /// <summary>
    /// 释放NPC脚底选中特效
    /// </summary>
    public void ReleaseSelectNpcParticle()
    {
        if (m_npcSelectParticle != 0)
        {
            CParticle cp = CParticleManager.GetInst().GetParticle(m_npcSelectParticle);
            if (cp != null)
            {
                cp.Remove();
            }
            m_npcSelectParticle = 0;
            m_bIsLoadParticle = false;
        }
    }

    /// <summary>
    /// 加载选中状态（NPC）特效
    /// </summary>
    private void LoadSelectNpcEffect(Vector3 npcpos)
    {
        m_npcSelectParticle = CParticleManager.GetInst().CreateGroundEffect(DEFINE.SELECT_NPC_PARTICLEID, npcpos, Vector3.zero);
    }

    /// <summary>
    /// 检查NPC
    /// </summary>
    private void CheckIsNpc()
    {
        cHomeNpc = SingletonObject<CHomeNpc>.GetInst();
        foreach (KeyValuePair<int, HomeNPCContent> itemPair in cHomeNpc.NpcLoaderDic)
        {
            if (itemPair.Key == 0 || m_npcID == 0) return;
            if (itemPair.Key == m_npcID)
            {
                //MyLog.Log("当前NPC ID=" + m_npcID);
                //加载选中状态
                SingletonObject<NpcTaskManager>.GetInst().CheckTaskIsActive(m_npcID);
                //NpcUIManager.GetInst().OpenNpcUI(m_npcID);
            }
        }
    }
    /// <summary>
    /// 检查NPC
    /// </summary>
    private void CheckIsNpc(GameObject obj)
    {
        if (UIManager.GetInst().IsLocked)
        {
            return;
        }
        cHomeNpc = SingletonObject<CHomeNpc>.GetInst();
        foreach (KeyValuePair<int, HomeNPCContent> itemPair in cHomeNpc.NpcLoaderDic)
        {
            if (itemPair.Key == 0 || obj == null) return;
            if (itemPair.Key.ToString() == obj.name)
            {
                //MyLog.Log("当前NPC ID=" + obj.name);
                //加载选中状态
                SingletonObject<NpcTaskManager>.GetInst().CheckTaskIsActive((uint)itemPair.Key);
                //NpcUIManager.GetInst().OpenNpcUI(obj.name);

            }
        }
    }



    /// <summary>
    /// 自动寻路到NPC实时监测两点距离。
    /// </summary>
    private bool CheckAbsDistance()
    {
        if (Common.GetHorizontalDis(m_npcPosition, m_position) <= DEFINE.NPC_REMAINING_DISTANCE)
        {
            StopNavMeshAgent();
            EnterState(eActionState.IdelInHome);
            return true;
        }
        else
        {
            return false;
        }
        return false;
    }

    private void BattleRelusetControl(EnumBattleResult battleResult)
    {
        string mssageText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        PopFrameMediator popMssage = SingletonObject<PopFrameMediator>.GetInst();
        switch (battleResult)
        {
            case EnumBattleResult.EnumBattleResult_SUCCESS:         //成功
                break;
            case EnumBattleResult.EnumBattleResult_NoGetThisBattleQuest:         //战场KEY值不够
                mssageText = Common.GetText(9100117);
                break;
            case EnumBattleResult.EnumBattleResult_NotEnoughKey:         //战场KEY值不够
                mssageText = Common.GetText(9100022);
                break;
            case EnumBattleResult.EnumBattleResult_NoThisKey:           //没有这个房间
                mssageText = Common.GetText(9100023);

                break;
            case EnumBattleResult.EnumBattleResult_ServerInnerError:        //服务器内部错误
                mssageText = Common.GetText(9100024);
                break;
            case EnumBattleResult.EnumBattleResult_PlayerNotExist:          //玩家不存在
                mssageText = Common.GetText(9100025);
                break;
            case EnumBattleResult.EnumBattleResult_NOBATTLE:                //不存在这个战场
                mssageText = Common.GetText(9100026);
                break;
            case EnumBattleResult.EnumBattleResult_CHEAT:          //战场作弊
                mssageText = Common.GetText(9100080);
                break;
            case EnumBattleResult.EnumBattleResult_EXCEPTION:        //战场异常   
                mssageText = Common.GetText(9100081);
                break;
            case EnumBattleResult.EnumBattleResult_NotOpen:          //战场没有开启
                mssageText = Common.GetText(9100082);
                break;
            case EnumBattleResult.EnumBattleResult_ItemNotEnough:                //没有足够的消耗物品
                mssageText = Common.GetText(9100083);
                break;
            case EnumBattleResult.EnumBattleResult_NotFriend:       //该玩家不是你的好友
                mssageText = Common.GetText(9938034);
                FriendManager.GetInst().ResetInitFightFriend();
                break;
            case EnumBattleResult.EnumBattleResult_InCD:                //今天已经助战过
                mssageText = Common.GetText(9100131);
                break;
            case EnumBattleResult.EnumBattleResult_NotEnoughVigor:                //没有足够的体力
                mssageText = Common.GetText(9100084);
                break;
            case EnumBattleResult.EnumBattleResult_BagFull:                //没有足够的背包空间
                mssageText = Common.GetText(9922014);
                frameType = PopFrameType.singleOkButton;
                //popMssage.SetCallBack(OnNotHavePack);
                break;
            case EnumBattleResult.EnumBattleResult_LeaveBattle:
                mssageText = Common.GetText(9100133);
                break;
            case EnumBattleResult.EnumBattleResult_NotEnoughWide:
                mssageText = Common.GetText(9100134);
                break;
            case EnumBattleResult.EnumBattleResult_NotEnoughTowerTimes:
                mssageText = Common.GetText(9100135);
                break;
            case EnumBattleResult.EnumBattleResult_NotAlreadyThrough:
                mssageText = Common.GetText(9100136);
                break;
            case EnumBattleResult.EnumBattleResult_NotOpenEscort:
                mssageText = Common.GetText(9100138);
                break;
            case EnumBattleResult.EnumBattleResult_NoEnoughTimes:
                mssageText = Common.GetText(9930017);
                //popMssage.SetCallBack(SingletonObject<BattlePrewarChoseMediator>.GetInst().BuyBattleTime);
                break;
            case EnumBattleResult.EnumBattleResult_MissionModuleNotOpen:
                mssageText = Common.GetText(9100200);
                break;
            case EnumBattleResult.EnumBattleResult_ThisBattleNotOpen:
                mssageText = Common.GetText(9100199);
                break;
            case EnumBattleResult.EnumBattleResult_MercPartnerCanNotUse:
                mssageText = Common.GetText(9958114);//不能使用佣兵.
                break;
            default:
                mssageText = "can't find battle error:" + battleResult.ToString();
                break;
        }
        popMssage.SetPopFrameTips(mssageText, frameType);
    }

    /// <summary>
    /// 小伙伴图集招募过的小伙伴二进制转换
    /// </summary>
    /// <returns></returns>
    public void UpdatePartnerIndex()
    {
        int iCount = m_playerInfo.uiPartnerByte.Count;
        //string strResult = string.Empty;
        uiRecruitPartner = new int[iCount * 8];
        for (int i = 0; i < iCount; i++)
        {

            //strTemp = System.Convert.ToString((byte)m_playerInfo.uiPartnerByte[i].bByteValue, 2);
            //strTemp = strTemp.Insert(0, new string('0', 8 - strTemp.Length));
            //strResult = strResult.Insert(0, strTemp);
            byte tmp = (byte)m_playerInfo.uiPartnerByte[i].bByteValue;

            for (int j = 0, len = 8; j < len; ++j)
            {
                byte t = (byte)(Mathf.Pow(2, j));

                int result = tmp & t;
                result = result == t ? 1 : 0;
                uiRecruitPartner[i * 8 + j] = result;
            }

        }
    }

    /// <summary>
    /// 检测当前技能是否可以用金币学习
    /// </summary>
    /// <returns>true：可以用金币学习，false则不可以</returns>
    public bool CheckHasSkill()
    {
        bool bFind = false;
        List<stSkillInfo> allskill = SkillManager.GetAllSkillByJob(m_pHomeAvatarInfo.uiPlayerJob);
        List<stSkillInfo> hasSkills = SkillManager.GetInst().GetAllSkill();
        VipContent viploader = HolderManager.m_VipHolder.GetStaticInfo((uint)SingletonObject<ShopManager>.GetInst().VipLevel + 10001);
        for (int i = 0, count = allskill.Count; i < count; i++)
        {
            stSkillInfo pSkillInfo = allskill[i];
            SkillUpContent pSkillLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(pSkillInfo.uiSkillID);
            uint mostlevel = (uint)pSkillLoader.SkillMostLevel;
            uint nextlevel = (uint)pSkillLoader.NextLevel;
            uint skilllevel = 0;
            for (int j = 0, count2 = hasSkills.Count; j < count2; j++)
            {
                if (hasSkills[j].uiSkillID == pSkillInfo.uiSkillID)
                {
                    if (hasSkills[j].uiLvl > pSkillLoader.SkillMostLevel && pSkillLoader.NextLevel != 0)
                    {
                        pSkillLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(pSkillInfo.uiSkillID + 1);
                        skilllevel = 1;
                    }
                    else
                        skilllevel = hasSkills[j].uiLvl;
                }
            }
            byte curLv = SkillManager.GetInst().GetCurrentLv(pSkillLoader, skilllevel);
            uint needLevel = SkillManager.GetInst().GetNeedLevel(pSkillLoader, skilllevel);
            if (m_pHomeAvatarInfo.uiPlayerLevel >= needLevel || (pSkillInfo.uiLvl == mostlevel && nextlevel == 0))//
            {
                //可学技能:有技能点且金币足够就显示
                if (curLv == 0)
                {
                    List<int> list = pSkillLoader.NeedResource;
                    if (list[1] + list[2] * skilllevel <= m_playerInfo.uiGoldCoin && m_playerInfo.uiSkillPoint > 0)
                    {
                        bFind = true;
                        break;
                    }
                }
                if (curLv > 0 && pSkillInfo.uiLvl == mostlevel && nextlevel == 0)
                {

                }
                else
                {
                    //可升级:技能点满了且金币足够.
                    List<int> list = pSkillLoader.NeedResource;
                    if (list[1] + list[2] * skilllevel <= m_playerInfo.uiGoldCoin && m_playerInfo.uiSkillPoint >= viploader.RechargeRestorSkillPoint)
                    {
                        bFind = true;
                        break;
                    }

                }
            }
        }
        return bFind;
    }


    public void SetLearnSkillState()
    {
        if (CheckHasSkill())
        {
    
            SingletonObject<HomeMainMediator>.GetInst().NewSkillTips = true;
        }
        else
        {
        
            SingletonObject<HomeMainMediator>.GetInst().NewSkillTips = false;
        }
    }

 
    public void setEquipState()
    {
        
        if (checkCloth() || checkWeapon())
        {
            eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.Intensify);
            if (mode == eOpenMode.Acquiesce)
                SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = true;

        }
        else
        {
            //MyLog.LogError("强化false");
            SingletonObject<EquipItemManager>.GetInst().SetEquipNewTip();
            if (!SingletonObject<HomeMainMediator>.GetInst().NewEquipTips)
                SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = false;

        }
    }

    /// <summary>
    /// 检测武器是否可强化（true可强化）
    /// </summary>
    /// <returns></returns>
    public bool checkWeapon()
    {
        //当前的
        uint gold = m_playerInfo.uiGoldCoin;
        uint level = m_pHomeAvatarInfo.uiPlayerLevel;
        uint stone = getEquipStoneNum();

        uint weaponid = m_pHomeAvatarInfo.uiWeaponID;
        EquipContent equipload = HolderManager.m_EquipHolder.GetStaticInfo(weaponid);
        if (equipload == null) return false;
        uint nextID = (uint)equipload.NextEquipID;
        if (nextID == 0) return false;  //满级了
        equipload = HolderManager.m_EquipHolder.GetStaticInfo(nextID);
        if (equipload == null) return false;
        //条件
        uint needGold = (uint)equipload.IntensifyUse[0].list[1];
        uint needLV = (uint)equipload.LimitLevel;
        uint needStone = (uint)equipload.IntensifyUse[1].list[1];

        if (gold >= needGold && level >= needLV && stone >= needStone)
        {
         
            return true;
        }
        else
        {
           
            return false;
        }

    }

    public bool checkCloth()
    {
        //当前的
        uint gold = m_playerInfo.uiGoldCoin;
        uint level = m_pHomeAvatarInfo.uiPlayerLevel;
        uint stone = getEquipStoneNum();

        uint clothid = m_pHomeAvatarInfo.uiClothesID;
        EquipContent equipload = HolderManager.m_EquipHolder.GetStaticInfo(clothid);
        if (equipload == null) return false;
        uint nextID = (uint)equipload.NextEquipID;
        if (nextID == 0) return false;  //满级了
        equipload = HolderManager.m_EquipHolder.GetStaticInfo(nextID);
        if (equipload == null) return false;
        //条件
        uint needGold = (uint)equipload.IntensifyUse[0].list[1];
        uint needLV = (uint)equipload.LimitLevel;
        uint needStone = (uint)equipload.IntensifyUse[1].list[1];

        if (gold >= needGold && level >= needLV && stone >= needStone)
        {
       
            return true;
        }
        else
        {
           
            return false;
        }

    }

    /// <summary>
    /// id获取宠物口粮数量
    /// </summary>
    /// <param name="foodid"></param>
    /// <returns></returns>
    public uint petFoodNum(uint foodid)
    {
        uint num = 0;
        if (ItemManager.GetInst().GetPetFoodItemList() != null)
        {
            //MyLog.Log("ItemManager.GetInst().GetPetFoodItemList().Count =" + ItemManager.GetInst().GetPetFoodItemList().Count);
            if (ItemManager.GetInst().GetPetFoodItemList().Count > 0)
            {
                for (int i = 0; i < ItemManager.GetInst().GetPetFoodItemList().Count; i++)
                {

                    if (ItemManager.GetInst().GetPetFoodItemList()[i].uiItemId == foodid)
                    {
                        num = ItemManager.GetInst().GetPetFoodItemList()[i].uiItemNum;
                        //MyLog.Log("num =" + num);
                    }
                }
            }
        }
        return num;
    }
    /// <summary>
    /// id获取坐骑口粮数量
    /// </summary>
    /// <param name="foodid"></param>
    /// <returns></returns>
    public uint mountFoodNum(uint foodid)
    {
        uint num = 0;
        if (ItemManager.GetInst().GetMountFoodItemList() != null)
        {
            //MyLog.Log("ItemManager.GetInst().GetMountFoodItemList().Count =" + ItemManager.GetInst().GetMountFoodItemList().Count);
            if (ItemManager.GetInst().GetMountFoodItemList().Count > 0)
            {
                for (int i = 0; i < ItemManager.GetInst().GetMountFoodItemList().Count; i++)
                {

                    if (ItemManager.GetInst().GetMountFoodItemList()[i].uiItemId == foodid)
                    {
                        num = ItemManager.GetInst().GetMountFoodItemList()[i].uiItemNum;
                        //MyLog.Log("num =" + num);
                    }
                }
            }
        }
        return num;
    }

    /// <summary>
    /// 获取背包强化石数量
    /// </summary>
    public uint getEquipStoneNum()
    {
        uint num = 0;
        if (ItemManager.GetInst().GetNormalItemList() != null)
        {
            for (int i = 0; i < ItemManager.GetInst().GetNormalItemList().Count; i++)
            {

                if (ItemManager.GetInst().GetNormalItemList()[i].uiItemId == DEFINE.ITEM_EQUIPSTONE)
                {
                    num = ItemManager.GetInst().GetNormalItemList()[i].uiItemNum;
                }
            }
        }
        return num;
    }

    public void CheckHasPartnerCanUpgrade()
    {
        List<PartnerSortItem> partners = PartnerManager.GetInst().PartnerList;
        bool bCanUpgradeStar = false;
        bool bCanUpgradeQuality = false;
        bool bHasOpenPartner = false;
        uint curItemID = 0;
        int curItemMaxNum = 0;
        uint _curNum = 0;
        int curCostGold = 0;
        for (int i = 0, count = partners.Count; i < count; i++)
        {

            if (partners[i] != null)
            {
                partners[i].canUpgradeQuality = true;
                PartenrContent loader = partners[i].loader;

                List<BaseIntContent> costList = loader.StarneedItems;
                if (costList.Count == 2)
                {
                    curItemID = (uint)costList[0].list[0];
                    curItemMaxNum = (int)costList[0].list[partners[i].startlevel];
                    curCostGold = (int)costList[1].list[partners[i].startlevel];
                }
                _curNum = 0;
                List<PackItemInfo> normals = SingletonObject<SoulDiamondManager>.GetInst().GetSortList();
                if (normals != null)
                {
                    for (int j = 0, count2 = normals.Count; j < count2; j++)
                    {
                        if (normals[j].uiItemId == curItemID)
                        {
                            _curNum += normals[j].uiItemNum;
                        }
                    }
                }

                if (_curNum >= curItemMaxNum && curCostGold <= m_playerInfo.uiGoldCoin && curItemMaxNum > 0 && !partners[i].canCall)
                {
                    bCanUpgradeStar = true;
                    break;
                }
                List<BaseIntContent> qualitylist = loader.QualityneedItems;

                for (int j = 0, count2 = qualitylist.Count; j < count2; j++)
                {
                    ItemContent itemloader = HolderManager.m_ItemHolder.GetStaticInfo(qualitylist[j].list[0]);
                    if (itemloader != null)
                    {
                        if (qualitylist.Count == 1)
                            partners[i].canUpgradeQuality = false;
                        else
                        {
                            if (GetItemCurrentNumber((uint)itemloader.Key) < (int)qualitylist[j].list[1])
                                partners[i].canUpgradeQuality = false;
                        }
                    }
                    else
                        partners[i].canUpgradeQuality = false;
                }


                if (partners[i].canUpgradeQuality)
                {
                    bCanUpgradeQuality = true;
                    break;
                }

            }
        }
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.Partner);
        if (mode != eOpenMode.Hide)
            bHasOpenPartner = true;

        if (bHasOpenPartner)
        {
            if (bCanUpgradeQuality || bCanUpgradeStar)
            {
                SingletonObject<HomeMainMediator>.GetInst().NewPartnerTips = true;
            }
            else
            {
                SingletonObject<HomeMainMediator>.GetInst().NewPartnerTips = false;
            }
        }
        else
        {
            SingletonObject<HomeMainMediator>.GetInst().NewPartnerTips = false;
        }
    }

    private int GetItemCurrentNumber(uint itemid)
    {
        List<PackItemInfo> normallist = ItemManager.GetInst().GetNormalItemList();
        int number = 0;
        if (normallist != null)
        {
            for (int i = 0, count = normallist.Count; i < count; i++)
            {
                if (normallist[i].uiItemId == itemid)
                {
                    number += (int)normallist[i].uiItemNum;
                }
            }
        }
        return number;
    }

    /// <summary>
    /// 检测当前是否存在可领取的成就、每日任务
    /// </summary>
    /// <returns></returns>
    public bool CheckHasAchieve()
    {
        AchieveManager manager = AchieveManager.GetInst();
        bool bHasTarget = false;
        bool bHasAchieve = false;
        bool bHasMainTas = false;
        for (int i = 0, count = manager.GetCurrentAchieve().Count; i < count; i++)
        {
            if (manager.GetCurrentAchieve()[i].uiFlag == 1) //已经完成，未领取状态
            {
                bHasAchieve = true;
                break;
            }
        }
        for (int i = 0, count = manager.GetCurrentTarget().Count; i < count; i++)
        {
            if (manager.GetCurrentTarget()[i].uiFlag == 1)
            {
                bHasTarget = true;
                break;
            }
        }
        if (CurQuestID != 0 && CurQuestState == 1)
        {
            bHasMainTas = true;
        }
        if (bHasAchieve || bHasTarget || bHasMainTas)
        {
            return true;
        }
        return false;
    }

    /// <summary>
    /// 当主界面OPEN的时候,且购买金币后,练金术任务没有完成的情况.
    /// </summary>
    public void CheckBuyGoldCoinTask()
    {
        AchieveManager manager = AchieveManager.GetInst();
        for (int i = 0, count = manager.GetCurrentTarget().Count; i < count; i++)
        {
            stTargetInfo targetInfo = manager.GetCurrentTarget()[i];
            if (targetInfo.baseTarget.TargetType == 115) //炼金术
            {
                if (targetInfo.uiFlag == 0 && SingletonObject<HomeMainMediator>.GetInst().IsOpen)
                {
                    SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
                }
            }
        }
    }
    /// <summary>
    /// 是否可以提升熔炉等级
    /// </summary>
    /// <returns></returns>
    public bool CheckSmeltUpLevel()
    {
        Dictionary<int, ForgeContent> dict = HolderManager.m_ForgeHolder.GetDict();
        foreach (KeyValuePair<int, ForgeContent> pair in dict)
        {
            if (m_playerInfo.uiSmeltLevel < pair.Value.SmeltLevel && m_pHomeAvatarInfo.uiPlayerLevel >= pair.Value.OpenLevel)
            {
                return true;
            }
        }
        return false;
    }

    public void SetCanGetAchieve()
    {
        if (CheckHasAchieve())
        {
            SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
        }
        else
        {
            SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = false;
        }
    }

    public stPlayerInfo GetPlayerInfo()
    {
        return m_playerInfo;
    }

    public stCharacterCard GetPlayerAttr()
    {
        return m_playerAttr.Decode();
    }

    public stHomeAvatarInfo GetHomeAvatarInfo()
    {
        return m_pHomeAvatarInfo;
    }

    public void SetHomeAvatarInfo(stHomeAvatarInfo hai)
    {
        m_pHomeAvatarInfo = hai;
    }

    public void SetPartnerByte(ByteArray PartnerByte)
    {
        m_playerInfo.uiPartnerByte = PartnerByte;
    }

  

    public float GetPlayerGS()
    {
       
        return Mathf.RoundToInt(fightTotalValue);
    }

  
    public float GetPlayerAttrGS()
    {
        return Mathf.RoundToInt(fightAttrValue);
    }



    /// <summary>
    /// 检查背包加上count 是否会满
    /// </summary>
    /// <param name="count">要加入的数量</param>
    /// <returns>会满则返回true，反之则false</returns>
    public bool CheckEquipPackageBeFull(int count)
    {
        //ushort maxCount = (ushort)EnumItemBagMax.EnumItemBagRange_EquipBagMax;
        //if (ItemManager.GetInst().GetEquipItemList() != null)
        //{
        //    if (ItemManager.GetInst().GetEquipItemList().Count + count > maxCount)
        //    {
        //        return true;
        //    }
        //}
        return false;
    }

    /// <summary>
    /// 检查背包是否刚刚好满了
    /// </summary>
    /// <returns>满了则返回true，反之则false</returns>
    public bool CheckEquipPackageIsFull()
    {
        //ushort maxCount = (ushort)EnumItemBagMax.EnumItemBagRange_EquipBagMax;
        //if (ItemManager.GetInst().GetEquipItemList() != null)
        //{
        //    if (ItemManager.GetInst().GetEquipItemList().Count == maxCount)
        //    {
        //        return true;
        //    }
        //}
        return false;
    }

    /// <summary>
    /// 没有足够的背包空间是回调
    /// </summary>
    /// <returns></returns>
    private void OnNotHavePack()
    {
        SingletonObject<EquipSmeltMediator>.GetInst().Open(null);
        //SingletonObject<ClimbTowerMediator>.GetInst().Close();
        SingletonObject<PopFrameMediator>.GetInst().Close();
    }





    public BattlePVEType GetBattleType()
    {
        return (BattlePVEType)m_uiBattleType;
    }

    public uint GetBattleLoaderID()
    {
        return m_uiBattleID;
    }

    /// <summary>
    /// 关闭主城UI.
    /// </summary>
    public void CloseHomeInfoMediator()
    {
        if (SingletonObject<HomeMainMediator>.GetInst().IsOpen)
            SingletonObject<HomeMainMediator>.GetInst().Close();
        if (SingletonObject<HomeAvatarNameMediator>.GetInst().IsOpen)
            SingletonObject<HomeAvatarNameMediator>.GetInst().Close();
        if (SingletonObject<NpcMediator>.GetInst().IsOpen)
            SingletonObject<NpcMediator>.GetInst().Close();
        if (SingletonObject<TopOneMediator>.GetInst().IsOpen)
            SingletonObject<TopOneMediator>.GetInst().Close();
        if (SingletonObject<ShowActivityMediator>.GetInst().IsOpen)
        {
            SingletonObject<ShowActivityMediator>.GetInst().CloseActivity(ActivityType.system);
        }
    }

    /// <summary>
    /// 打开主城UI.
    /// </summary>
    public void OpenHomeInfoMediator()
    {
        if (!SingletonObject<HomeMainMediator>.GetInst().IsOpen)
        {
            //MyLog.LogError("!SingletonObject<HomeMainMediator>.GetInst().IsOpen");
            SingletonObject<HomeMainMediator>.GetInst().Open(null);
        }
        else
        {
            //MyLog.LogError("SingletonObject<HomeMainMediator>.GetInst().IsOpen");
        }
        if (!SingletonObject<HomeAvatarNameMediator>.GetInst().IsOpen)
        {
            //MyLog.LogError("!SingletonObject<HomeAvatarNameMediator>.GetInst().IsOpen");
            SingletonObject<HomeAvatarNameMediator>.GetInst().Open(null);
        }
        else
        {
            //MyLog.LogError("SingletonObject<HomeAvatarNameMediator>.GetInst().IsOpen");
        }
        if (!SingletonObject<NpcMediator>.GetInst().IsOpen)
        {
            //MyLog.LogError("!SingletonObject<NpcMediator>.GetInst().IsOpen");
            SingletonObject<NpcMediator>.GetInst().Open(delegate()
            {
                CHomeNpc.GetInst().InitNpcName();
            });

        }
        else
        {
            //MyLog.LogError("SingletonObject<NpcMediator>.GetInst().IsOpen");
        }

        if (!SingletonObject<TopOneMediator>.GetInst().IsOpen)
        {
            SingletonObject<TopOneMediator>.GetInst().UpdateTopOne();
        }

        if (!SingletonObject<ShowActivityMediator>.GetInst().IsOpen)
        {
            SingletonObject<ShowActivityMediator>.GetInst().ShowActivity(ActivityType.system);
        }
    }

    //小伙伴出战ID
    //public uint PartnerFightID
    //{
    //    get
    //    {
    //        return m_playerInfo.uiFightPartnerID;
    //    }
    //    set
    //    {
    //        m_playerInfo.uiFightPartnerID = value;
    //    }
    //}

    //更新装备熔炼经验
    public uint SmeltExpValue
    {
        get
        {
            return m_playerInfo.uiSmeltExp;
        }
        set
        {
            m_playerInfo.uiSmeltExp = value;
        }
    }
    /// <summary>
    /// 熔炉等级
    /// </summary>
    public ushort SmeltLevel
    {
        get
        {
            return m_playerInfo.uiSmeltLevel;
        }
        set
        {
            m_playerInfo.uiSmeltLevel = value;
        }
    }

    /// <summary>
    /// 当前任务ID
    /// </summary>
    public uint CurQuestID
    {
        get
        {
            return m_playerInfo.uiQuestID;
        }
    }

    /// <summary>
    ///当前任务状态:0为未完成，1为完成
    /// </summary>
    public byte CurQuestState
    {
        get
        {
            return m_playerInfo.uiQuestIsFinshed;
        }
    }

    /// <summary>
    /// 主角在家园中坐标
    /// </summary>
    public Vector3 avatarPosition
    {
        get { return m_position; }
    }

    /// <summary>
    /// 玩家蒙皮高度
    /// </summary>
    public float avaterBodyHeight
    {
        get { return m_fBodyHeight; }
    }

    /// <summary>
    /// 爬塔次数
    /// </summary>
    public uint towerNumber
    {
        get { return m_playerInfo.uiTowerNum; }
        set { m_playerInfo.uiTowerNum = value; }
    }

    /// <summary>
    /// 护送次数
    /// </summary>
    public uint escortNumber
    {
        get { return m_playerInfo.uiEscortNum; }
        set { m_playerInfo.uiEscortNum = value; }
    }

    /// <summary>
    /// 守卫次数
    /// </summary>
    public uint protectNumber
    {
        get { return m_playerInfo.uiProtectNum; }
        set { m_playerInfo.uiProtectNum = value; }
    }

    public uint GetBattleInstance
    {
        get
        {
            return m_uiBattleInstanceID;
        }
    }

    public void SetInfoBack(stPlayerInfo st)
    {
        m_playerInfo = st;
    }

    public void SetRecruitPartner(uint partnerID)
    {

        PartenrContent partnerInfo = HolderManager.m_PartenrHolder.GetStaticInfo(partnerID);
        if (partnerInfo == null)
        {
            return;
        }
        uint index = (uint)partnerInfo.IllustrationsID;
        uiRecruitPartner[index] = 1;

    }

    public int[] GetRecruitPartner()
    {
        return uiRecruitPartner;
    }

    public ushort SetBuyEnergyCount
    {
        set
        {
            m_playerInfo.uiSBossVigorCount = value;
        }
        get
        {
            return m_playerInfo.uiSBossVigorCount;
        }
    }

    public ulong PhoneNumber
    {
        get { return mPhoneNumber; }
    }

    //虚拟货币奖励统计
    private void onMoneyRewardRecord(BinaryReader br)
    {
        G2CMoneyRewardRecords msg = new G2CMoneyRewardRecords();
        msg.Read(br);

        if (msg.uiCount <= 0)
        {
            return;
        }

        string reason = "";
        switch (msg.uiGetWay)
        {
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_Login:
                {
                    reason = Common.GetText(9100151);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_ArenaPrize:
                {
                    reason = Common.GetText(9100152);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_Tower:
                {
                    reason = Common.GetText(9100153);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_AssistBattle:
                {
                    reason = Common.GetText(9100154);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_AchieveAward:
                {
                    reason = Common.GetText(9100155);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_MineAward:
                {
                    reason = Common.GetText(9100156);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_MineDefendWinReward:
                {
                    reason = Common.GetText(9100157);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_BossAward:
                {
                    reason = Common.GetText(9100158);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_BattleAward:
                {
                    reason = Common.GetText(9100159);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_BoxAward:
                {
                    reason = Common.GetText(9100160);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_MailAward:
                {
                    reason = Common.GetText(9100161);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_DeliveryAward:
                {
                    reason = Common.GetText(9100162);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_GMAddAward:
                {
                    reason = Common.GetText(9100163);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_Shop:
                {
                    reason = Common.GetText(9100164);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_SignAward:
                {
                    reason = Common.GetText(9100165);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_Mercenary:
                {
                    reason = Common.GetText(9100263);
                }
                break;
            case (ushort)EnumGetMoneyRewardType.EnumGetMoneyRewardType_MOBAI:
                {
                    reason = Common.GetText(9100264);
                }
                break;
        }

        string moneyType = "";
        switch (msg.uiMoneyType)
        {
            case (ushort)EnumMoneyType.EnumMoneyType_Coin:
                {
                    moneyType = Common.GetText(9972005);
                }
                break;
            case (ushort)EnumMoneyType.EnumMoneyType_Diamond:
                {
                    moneyType = Common.GetText(9972006);
                }
                break;
        }

        FLSDK.reward(msg.uiCount.ToString(), reason, moneyType);
    }

    //消费点统计
    private void onConsumeRecord(BinaryReader br)
    {
        G2CConsumeRecords msg = new G2CConsumeRecords();
        msg.Read(br);

        string moneyType = "";
        switch (msg.uiMoneyType)
        {
            case (ushort)EnumMoneyType.EnumMoneyType_Coin:
                {
                    moneyType = Common.GetText(9972005);
                }
                break;
            case (ushort)EnumMoneyType.EnumMoneyType_Diamond:
                {
                    moneyType = Common.GetText(9972006);
                }
                break;
        }

        string sConsumeType = "";
        switch (msg.uiConsumeType)
        {
            case (ushort)EnumConsumeType.EnumConsumeType_BattleRevive:
                {
                    sConsumeType = Common.GetText(9100166);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_TenBox:
                {
                    sConsumeType = Common.GetText(9100167);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_SignalBox:
                {
                    sConsumeType = Common.GetText(9100167);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_StrengEquip:
                {
                    sConsumeType = Common.GetText(9100168);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_SearchPlunder:
                {
                    sConsumeType = Common.GetText(9100169);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_PartnerStarUp:
                {
                    sConsumeType = Common.GetText(9100170);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_PartnerSkillUp:
                {
                    sConsumeType = Common.GetText(9100171);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_SummonPartner:
                {
                    sConsumeType = Common.GetText(9100172);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_SkillUp:
                {
                    sConsumeType = Common.GetText(9100173);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_BuySkillPoint:
                {
                    sConsumeType = Common.GetText(9100174);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_Shop:
                {
                    sConsumeType = Common.GetText(9100175) + ":" + msg.uiItemId.ToString();
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_ShopBuyCoin:
                {
                    sConsumeType = Common.GetText(9100176);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_BuyArenaTimes:
                {
                    sConsumeType = Common.GetText(9100177);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_ClearCD:
                {
                    sConsumeType = Common.GetText(9100178);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_WideBattle:
                {
                    sConsumeType = Common.GetText(9100179);
                }
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_BuyBattleTimes:
                {
                } sConsumeType = Common.GetText(9100180);
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_Mercenary:
                {
                } sConsumeType = Common.GetText(9100265);
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_PARTY:
                {
                } sConsumeType = Common.GetText(9100266);
                break;
            case (ushort)EnumConsumeType.EnumConsumeType_SetName:
                {
                } sConsumeType = Common.GetText(9100267);
                break;
        }

        FLSDK.purchase(sConsumeType, msg.uiCount.ToString(), msg.uiPrice.ToString(), moneyType);
    }

    //道具消耗统计
    private void onItemConsumeRecord(BinaryReader br)
    {
        G2CItemConsumeRecords msg = new G2CItemConsumeRecords();
        msg.Read(br);

        FLSDK.useItem(msg.uiItemId.ToString(), msg.uiCount.ToString());
    }
    #region Activity Times
    public bool StartActivity
    {
        set
        {
            m_bIsActiviTime = value;
        }
        get
        {
            return m_bIsActiviTime;
        }
    }

    public uint StartActivityTimes
    {
        set
        {
            m_uiIsActiviTimes = value;
        }
        get
        {
            return m_uiIsActiviTimes;
        }
    }
    #endregion

    public uint GetNeedExp()
    {
        stHomeAvatarInfo info = GetHomeAvatarInfo();
        LevelUpContent loader = HolderManager.m_LevelUpHolder.GetStaticInfo(info.uiPlayerLevel);
        if (null == loader)
        {
            return 0;
        }
        return (uint)loader.Exp;
    }

}
