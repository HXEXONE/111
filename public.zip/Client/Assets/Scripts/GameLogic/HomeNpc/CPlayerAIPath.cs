﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public struct stNpcAIInfo
{
    public Vector3 position;
    public int nMin;
    public int nMax;

    public stNpcAIInfo(int min,int max,Vector3 pos) 
    {
        position = pos;
        nMin = min;
        nMax = max;
    }

    public bool InRange(int num)
    {
        return (num >= nMin && num <= nMax);
    }

}

public class CPlayerAIPath 
{
    private static List<stNpcAIInfo> NpcWaypointList = null;
    private CBaseHomeAvatar m_pHomePlayer;
    private CPlayer m_pAvatarPlayer;

    public CPlayerAIPath(CBaseHomeAvatar player) 
    {
        m_pHomePlayer = player;
        m_pAvatarPlayer = SingletonObject<CPlayer>.GetInst();

        if ( null == NpcWaypointList )
        {
            NpcWaypointList = new List<stNpcAIInfo>();   

            Dictionary<uint,CHomeBaseNpc> npcDict = CHomeNpc.GetInst().dNpcDict; //家园里的Npc
            foreach (var npc in npcDict.Values)
            {
                if (null == npc) continue;
                if (null == npc.transform) continue;
                Vector3 position = npc.transform.position + npc.transform.forward * 1.5f;
                //NpcWaypointList.Add(position);
                stNpcAIInfo info = new stNpcAIInfo();
                switch ((eHomeNpcType)npc.homeNpcLoader.Key)
                {
                    case eHomeNpcType.Blacksmith: //铁匠
                        {
                            info = new stNpcAIInfo(0, 1, position);
                        }
                        break;
                    case eHomeNpcType.Businessman: //商人
                        {
                            info = new stNpcAIInfo(2, 5, position);
                        }
                        break;
                    case eHomeNpcType.Trials: //试炼
                        {
                            info = new stNpcAIInfo(6, 7, position);
                        }
                        break;
                    case eHomeNpcType.Housecarl: //竞技场侍卫
                        {
                            info = new stNpcAIInfo(8, 9, position);
                        }
                        break;
                    case eHomeNpcType.Tutor: //导师
                        {
                            info = new stNpcAIInfo(10, 13, position);
                        }
                        break;
                    case eHomeNpcType.Wilderness: //末日管理
                        {
                            info = new stNpcAIInfo(14, 15, position);
                        }
                        break;
                    case eHomeNpcType.Ranking: //排行榜
                        {
                            info = new stNpcAIInfo(16, 17, position);
                        }
                        break;
                    case eHomeNpcType.Treasure: //宝藏(挖矿)
                        {
                            info = new stNpcAIInfo(18, 19, position);
                        }
                        break;
                    case eHomeNpcType.Sociaty: //公会
                        {
                            info = new stNpcAIInfo(20, 22, position);
                        }
                        break;
                    default:
                        break;
                }

                NpcWaypointList.Add(info);
            }        

            //主城中几个点
            NpcWaypointList.Add(new stNpcAIInfo(23, 24, new Vector3(-9.83f, -2.40f, 19.78f)));
            NpcWaypointList.Add(new stNpcAIInfo(25, 26, new Vector3(1.37f, -2.40f, 17.45f)));
            NpcWaypointList.Add(new stNpcAIInfo(27, 28, new Vector3(4.7f, -2.40f, 1.27f)));
            NpcWaypointList.Add(new stNpcAIInfo(29, 30, new Vector3(-13.86f, -2.40f, 5.77f)));
        }

        //mode = NewBieGuidManager.GetInst().isOpenFun((eOpenFunction)m_homeNpcLoader.open);

    }

    public void SetRandomPosition() 
    {
        if (m_pHomePlayer == null || m_pAvatarPlayer == null)
        {
            return;
        }

        if (m_pHomePlayer.transform == null || m_pAvatarPlayer.transform == null)
        {
            return;
        }

        float distance = Common.GetHorizontalDis(m_pHomePlayer.transform.position, m_pAvatarPlayer.transform.position);
        Vector3 despostion = Vector3.zero;

        if (distance < 15f)
        {
            int length = 30;
            int randomNum = UnityEngine.Random.Range(0, length + 3);

            if (randomNum >= length)
            {
                return; //不动
            }
            Vector3 randomBase = new Vector3(Random.onUnitSphere.x, 0f, Random.onUnitSphere.y) * 0.5f;
            for (int i = 0, len = NpcWaypointList.Count; i < len; i++ )
            {
                stNpcAIInfo info = NpcWaypointList[i];
                if (info.InRange(randomNum))
                {
                    despostion = info.position + randomBase;
                    break;
                }
            }
            //despostion = NpcWaypointList[index].position + randomBase;
        }        
        else
        {
            Vector3 randomBase = new Vector3(Random.insideUnitSphere.x, 0f, Random.insideUnitSphere.y) * 15f;

            despostion = m_pAvatarPlayer.transform.position + randomBase;
            despostion = Common.NavSamplePosition(despostion);
        }

        m_pHomePlayer.SetDestPosition(despostion);
    }
    
}
