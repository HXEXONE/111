﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CHomeNpc : SingletonObject<CHomeNpc>
{
    public Dictionary<uint, CHomeBaseNpc> dNpcDict = new Dictionary<uint, CHomeBaseNpc>();
    public Dictionary<uint, NpcNameComponent> NpcNameDic = new Dictionary<uint, NpcNameComponent>();
    private HomeNPCContent m_homeNpcLoader;
    public HomeNpcAvatar homeNpcAvatar;
    public Dictionary<int, HomeNPCContent> NpcLoaderDic;
    private CCamera m_touchCmaera;
    private float m_animatorMinTime = 5;//动画随机最小时间
    private float m_animatorMaxTime = 10;//动画随机最大时间
    private CAnimator m_npcAnimator;

    /// <summary>
    /// 创建家园NPC
    /// </summary>

    public void CreateHomeNpc()
    {
        dNpcDict.Clear();
        m_touchCmaera = SingletonObject<CCamera>.GetInst();
        m_touchCmaera.SetEasyTouch(m_touchCmaera.GetCameraObj());
        NpcLoaderDic = HolderManager.m_HomeNPCHolder.GetDict();
        NpcMediator npcMediator = SingletonObject<NpcMediator>.GetInst();
        eOpenMode mode = eOpenMode.Hide;
        foreach (KeyValuePair<int, HomeNPCContent> cHomeNpcLoader in NpcLoaderDic)
        {
            m_homeNpcLoader = HolderManager.m_HomeNPCHolder.GetStaticInfo(cHomeNpcLoader.Key);
            homeNpcAvatar = new HomeNpcAvatar(m_homeNpcLoader);
            homeNpcAvatar.InitAvatar((uint)cHomeNpcLoader.Key);
            dNpcDict.Add((uint)cHomeNpcLoader.Key, homeNpcAvatar);
            //if (mode != eOpenMode.Hide)
            //{
                
            //}
            //else
            //{
            //    maxNpcCount--;
            //}
        }
        InitTimeTick();
    }

    public void InitNpcName()
    {
        NpcMediator nm = SingletonObject<NpcMediator>.GetInst();
        foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
        {
            nm.InitHomeNpcName(item.Value);
        }
    }

    //释放回收
    public void ReleaseHomeNpc(eObjectDestroyType type)
    {
        //回收模型
        foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
        {
            if (item.Value != null)
            {
                item.Value.Release();
            }
        }
        //清空字典
        if (dNpcDict != null)
        {
            dNpcDict.Clear();
        }

        if (NpcNameDic != null)
        {
            NpcNameDic.Clear();
        }
        //释放名字组件
        SingletonObject<NpcMediator>.GetInst().ReleaseNpcName();
    }

    /// <summary>
    /// 启动定时器
    /// </summary>
    private void InitTimeTick()
    {
        foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
        {
            float time = UnityEngine.Random.Range(m_animatorMinTime, m_animatorMaxTime);
            item.Value.animationTimer.SetTimer(time);
        }
    }


    public void Update()
    {
        if (dNpcDict == null) return;
        foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
        {
            if (item.Value.npcAnimator == null) continue;
            item.Value.npcAnimator.Update();
        }
        UpdateNpcAnimation();
    }
    private void UpdateNpcAnimation()
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.Home)
            return;

        if (dNpcDict != null)
        {
            foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
            {
                if (item.Value.npcAnimator == null) continue;
                if (!item.Value.gameObject.activeSelf) continue;
                if (item.Value.animationTimer.IsExpired(true))
                {
                    if (item.Value.animationState == eActionState.Idle)
                    {
                        item.Value.animationState = eActionState.IdelInHome;
                        string actionName = stStateData.GetActionName(item.Value.animationState);
                        object[] temp = new object[4] { item.Value.npcAnimator, eActionState.Idle, item.Value.animationTimer, dNpcDict[item.Key] };
                        item.Value.npcAnimator.PlayAction(actionName, 1, false, onPlayActionFinished,DEFINE.ANIMATOR_FADE_TIME, temp);
                        //item.Value.animationState = eActionState.Idle;
                    }
                }

            //    m_npcAnimator = item.Value.npcAnimator;
            //    if (m_npcAnimator.m_isHomeNpc)
            //    {
            //        if (m_npcAnimator.eAnimatorState == eActionState.IdelInHome)
            //        {
            //            if (m_npcAnimator.aniInfo.state.length ==0 || m_npcAnimator.aniInfo.aniSpeed == 0) return;
            //            if (m_npcAnimator.animatorLenght == 0)
            //                m_npcAnimator.animatorLenght = m_npcAnimator.aniInfo.state.length / Mathf.Abs(m_npcAnimator.aniInfo.aniSpeed);
            //            if (m_npcAnimator.startTiemr)
            //            {
            //                //MyLog.Log("m_npcAnimator:" + m_npcAnimator.GetAnimator().name + "lengh" + m_npcAnimator.animatorLenght);
            //                m_npcAnimator.onceTimer.SetTimer(m_npcAnimator.animatorLenght);
            //                m_npcAnimator.startTiemr = false;
            //            }
            //        }
            //    }

            //    if (m_npcAnimator.m_playFinished != null)
            //    {
            //        if (m_npcAnimator.onceTimer.IsExpired(true))
            //        {
            //            m_npcAnimator.m_playFinished(m_npcAnimator.Args);
            //            m_npcAnimator.m_playFinished = null;
            //            m_npcAnimator.oncePlayFinished = true;
            //            m_npcAnimator.startTiemr = true;
            //            //item.Value.animationState = eActionState.Idle;
            //        }
            //    }
            }
        }
    }

    private void onPlayActionFinished(object[] parms)
    {
        CAnimator m_animaotr = (CAnimator)parms[0];
        eActionState m_state = (eActionState)parms[1];
        Timer m_timer = (Timer)parms[2];
        CHomeBaseNpc m_npc = (CHomeBaseNpc)parms[3];
        if (!m_npc.transform.gameObject.activeSelf)
            return;
        m_npc.animationState = eActionState.Idle;
        m_animaotr.PlayAction(stStateData.GetActionName(m_state));
        float time = UnityEngine.Random.Range(m_animatorMinTime, m_animatorMaxTime);
        m_timer.SetTimer(time);
    }

    public void Show(bool bShow)
    {
        foreach (KeyValuePair<uint, CHomeBaseNpc> item in dNpcDict)
        {
            item.Value.Show(bShow);
        }
    }

}

public class HomeNpcAvatar : CHomeBaseNpc
{

    public HomeNpcAvatar(HomeNPCContent loader)
    {
        m_pNpcLoader = loader;
    }

    public void InitAvatar(uint id)
    {
        m_npcCObj = new CObject(m_pNpcLoader.ResPath);
        m_npcCObj.Name = id.ToString();
        m_npcCObj.CallBack = LoadNpcCompleted;
        m_npcCObj.IsMemoryFactory = true;
        m_npcCObj.ObjectType = eObjectType.HomeAvatar;
        m_npcCObj.BornPosition = m_pNpcLoader.Position;
        m_npcPostion = m_pNpcLoader.Position;
        //new Quaternion(m_pNpcLoader.direction.x, m_pNpcLoader.direction.y, m_pNpcLoader.direction.z, 0);
        m_npcCObj.LoadObject();
    }

    private void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if (null != o)
        {
            m_npcTrans = o.transform;
            m_npcGameObj = o;
            o.transform.eulerAngles = m_pNpcLoader.Direction;
            float size = m_pNpcLoader.Size;
            o.transform.localScale = new Vector3(size, size, size);
        }
        
        
        if (m_npcTrans != null)
        {
            //获取模型高度
            SkinnedMeshRenderer[] smrs = m_npcTrans.GetComponentsInChildren<SkinnedMeshRenderer>();
            if (m_npcTrans.name.Equals("15000008"))
            {
                //矿洞npc存在多个蒙皮,特殊处理
                if (smrs.Length > 0)
                {
                    for (int i = 0, len = smrs.Length; i < len; i++)
                    {
                        if (smrs[i].transform.name.Equals("jingjichangkuanggong"))
                        {
                            npcBodyHight = smrs[i].bounds.size.y;
                            break;
                        }
                    }
                }
            }
            else
            {
                if (smrs.Length > 0)
                {

                    npcBodyHight = smrs[0].bounds.size.y;
                }
                else
                {
                    if (m_npcTrans.name.Equals("15000012"))
                    {
                        npcBodyHight = 3f;//默认高度
                    }
                    else
                    {
                        npcBodyHight = 3.5f;//默认高度
                    }
                   
                }
            }
           
        }

        //MyLog.Log("npcBodyHight:" + npcBodyHight + "startIndex" + CHomeNpc.GetInst().startIndex + "maxCount" + CHomeNpc.GetInst().maxNpcCount);
        if (null == o)
        {
            return;
        }
        Common.SetObjectAlllayer(o, DEFINE.HOMENPC_LAYER);
        CharacterController cc = o.GetComponent<CharacterController>();


        if (cc != null)
        {
            cc.enabled = true;
            string animatorPath = m_pNpcLoader.ResPath.Replace("_model", "_ctrl");
            if (!string.IsNullOrEmpty(animatorPath) && !animatorPath.Equals("0"))
            {
                o.SetActive(false);
                LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
            }
        }
    }

    private void LoadAcnimatorCtrl(string interim, UnityEngine.Object asset)
    {

        if (null == m_npcTrans) return;
        GameObject go = (GameObject)asset;
        if (go != null)
        {
            Animator animator = go.GetComponent<Animator>();
            if (animator == null) return;
            Animator aniCtrl = m_npcTrans.GetComponent<Animator>();
            aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//             if (null == aniCtrl)
//             {
//                 aniCtrl = m_npcGameObj.AddComponent<Animator>();
//                 aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//                 aniCtrl.avatar = animator.avatar;
//                 aniCtrl.applyRootMotion = false;
//             }

            m_npcGameObj.SetActive(true);

            npcposition = m_npcTrans.position;
            
            m_animationState = eActionState.Idle;
            aniCtrl.Play(stStateData.GetActionName(m_animationState));
            m_animator = new CAnimator(aniCtrl);

            //NpcNameComponent component = null;
            //CHomeNpc.GetInst().NpcNameDic.TryGetValue(m_pNpcLoader.GetKey(), out component);
            //if (component != null)
            //{
            //    component.SetLabelActive(true);
            //}


        }
    }

}
