﻿using UnityEngine;
using System.Collections;

public class COtherPlayer : CBaseHomeAvatar
{
    private CPlayerAIPath m_pPlayerAiPath;
    private Timer m_pRandomTimer;

    private CPlayer m_pPlayer;

    public override void Init(Vector3 position, Quaternion rotation)
    {
        base.Init(position, rotation);

        m_pPlayerAiPath = new CPlayerAIPath(this);
        m_pRandomTimer = new Timer();
        m_pRandomTimer.SetTimer(RandomTime);

    }

    public override void Update()
    {
        base.Update();

        if (null != m_pPlayerAiPath && m_pRandomTimer.IsExpired(true))
        {
            m_pPlayerAiPath.SetRandomPosition();
            m_pRandomTimer.SetTimer(RandomTime);
        }
    }

    private float RandomTime
    {
        get { return UnityEngine.Random.Range(2f, 10f); }
    }

    public void SetOtherPlayerInfo(uint uiPlayerJob, uint uiPetID, ulong llAccountID, string szPlayerName, ushort level, uint uiWeaponID, uint uiClothesID, uint uiAttackCrystalId, uint uiDefenceCrystalId, uint uiGsNum, bool isvip)
    {
        m_pHomeAvatarInfo.uiPlayerJob = uiPlayerJob;
        m_pHomeAvatarInfo.uiPetID = uiPetID;
        m_pHomeAvatarInfo.szPlayerName = szPlayerName;
        m_pHomeAvatarInfo.m_llAccountID = llAccountID;
        m_pHomeAvatarInfo.uiPlayerLevel = level;
        m_pHomeAvatarInfo.uiWeaponID = uiWeaponID;
        m_pHomeAvatarInfo.uiClothesID = uiClothesID;
        m_pHomeAvatarInfo.uiAttackCrystalId = uiAttackCrystalId;
        m_pHomeAvatarInfo.uiDefenceCrystalId = uiDefenceCrystalId;
        m_pHomeAvatarInfo.uiGsNum = uiGsNum;
        m_pHomeAvatarInfo.bIsvip = isvip;
        if(!SingletonObject<TaskMediator>.GetInst().IsOpen)
            UpdateAvatarInfoComponent();
    }

    public COtherPlayer getCOtherPlayer(uint uiPlayerJob, uint uiPetID, ulong llAccountID, string szPlayerName,ushort level, uint uiWeaponID, uint uiClothesID, uint uiGsNum, bool isvip)
    {
        COtherPlayer cotherplayer = new COtherPlayer();
        cotherplayer.m_pHomeAvatarInfo.uiPlayerJob = uiPlayerJob;
        cotherplayer.m_pHomeAvatarInfo.uiPetID = uiPetID;
        cotherplayer.m_pHomeAvatarInfo.szPlayerName = szPlayerName;
        cotherplayer.m_pHomeAvatarInfo.m_llAccountID = llAccountID;
        cotherplayer.m_pHomeAvatarInfo.uiPlayerLevel = level;
        cotherplayer.m_pHomeAvatarInfo.uiWeaponID = uiWeaponID;
        cotherplayer.m_pHomeAvatarInfo.uiClothesID = uiClothesID;
        cotherplayer.m_pHomeAvatarInfo.uiGsNum = uiGsNum;
        m_pHomeAvatarInfo.bIsvip = isvip;
        return cotherplayer;
    }
}
