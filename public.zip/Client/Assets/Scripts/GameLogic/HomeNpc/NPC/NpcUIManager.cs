﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
public delegate void DestPositionCallBack(bool isBreak);
public class NpcUIManager : SingletonObject<NpcUIManager>
{

    public bool bShowDefaultDialog = false;
    private CSound npcSound;
    private uint mCurrentNpc = 0;
    public uint CurrentNpc
    {
        get { return mCurrentNpc; }
    }

    /// <summary>
    /// 打开NPC对应UI Panel
    /// </summary>
    public void OpenNpcUI(uint m_npcID)
    {
        if (SingletonObject<SystemPromptMediator>.GetInst().IsOpen)//关闭移动时提示的公告。
            SingletonObject<SystemPromptMediator>.GetInst().Close();
        bShowDefaultDialog = false;
        UIManager uiManager = UIManager.GetInst();
        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(m_npcID);
        SingletonObject<CPlayer>.GetInst().ReleaseSelectNpcParticle();
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun((eOpenFunction)load.Open);
        if (mode != eOpenMode.Hide)
        {
            mCurrentNpc = m_npcID;
            //if (15000004 == m_npcID)
            //{
            //    CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.ArenaUI, eBattleType.None, delegate()
            //    {
            //        SingletonObject<CArenaUILoading>.GetInst().EnterScene(DEFINE.ARENA_SCENE_ID);
            //    });

            //}
            if (15000003 == m_npcID)
            {
                EscortTypeManager.GetInst().requestEscortType();
            }
            else
            {
                openUi(load);
            }
        }
        else
        {
            //显示默认对白..
            TaskMediator taskMediator = SingletonObject<TaskMediator>.GetInst();
            if (!taskMediator.IsOpen)
            {
                bShowDefaultDialog = true;
                taskMediator.HasShowAward = true;
                taskMediator.Open(delegate() {
                    taskMediator.SetBottomActive(true);
                    string desc = Common.GetText(load.Desc);
                    desc = desc.Replace("#", "，");
                    desc = desc.Replace("@", "\n");

                    if (desc.Contains("%s"))
                    {
                        string chapter = "";
                        string level = "";
                        //存在开启章节提示
                        OpenContent openLoader = HolderManager.m_OpenHolder.GetStaticInfo(load.Open);
                        if (openLoader != null)
                        {
                            if (openLoader.Condition == 4)
                            {
                                BattlePVEContent pveLoader = BattlePveManager.GetInst().GetPveLoader((uint)openLoader.ConditionId);
                                if (pveLoader != null)
                                {
                                    chapter = pveLoader.Chapter.ToString();
                                    level = (pveLoader.Key % 100).ToString();
                                }
                            }
                        }
                        desc = GetFinalStr(desc, chapter, level);
                    }
                    taskMediator.InitPanel((int)load.Key, desc, Common.GetText(load.Name));
                });
                
                
            }
        }
        NpcPlaySound(m_npcID);
    }

    private string GetFinalStr(string tempstr, params object[] args)
    {
        string rlt = tempstr;
        string[] sp = new string[] { "%s" };
        string[] str = rlt.Split(sp, StringSplitOptions.None);
        for (int i = 0; i < args.Length; i++)
        {
            string reStr = args[i].ToString();

            str[i] += reStr;
        }
        rlt = string.Empty;
        for (int i = 0; i < str.Length; i++)
        {
            rlt += str[i];
        }
        return rlt;
    }

    public void NpcPlaySound(uint npcid)
    {
        if (npcid == 0) return;
        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(npcid);
        if (load == null) return;
        //随机播放一个对话音效
        List<int> sound = load.Sounds;
        if (sound != null)
        {
            if (sound.Count > 0)
            {
                if (sound.Count > 1)
                {
                    //存在多个音效随机
                    int index = UnityEngine.Random.Range(0, sound.Count);
                    if (index < sound.Count)
                    {
                        int id = sound[index];
                        if (id != 0)
                        {
                            if (npcSound != null) npcSound.Stop();
                            npcSound = CMusicManager.GetInst().CreateUISound((uint)id);
                        }
                    }
                }
                else
                {
                    int id = sound[0];
                    if (id != 0)
                    {
                        if (npcSound != null) npcSound.Stop();
                        npcSound = CMusicManager.GetInst().CreateUISound((uint)id);
                    }
                }
            }
        }
    }

    public void openUi(HomeNPCContent load)
    {
        UIManager uiManager = UIManager.GetInst();
        BaseMediator mediator = uiManager.GetMediator(load.UiName);
        if (mediator == null)
        {
            MyLog.LogError("Homenpc.xls panel name is null!");
            return;
        }
        if (mediator.PanelName == "panel_ui_openbox")
            SingletonObject<OpenBoxMediator>.GetInst().CardOpenType = eCardOpenType.DrawCard;
        else if (mediator.PanelName == "panel_ui_gsranking")
        {
            SingletonObject<RankMediator>.GetInst().SetRankState();
        }
        else if (load.Key == (int)eHomeNpcType.LongQiMic)
        {
            bool isOpen = DiscountShopManager.GetInst().isOpenShop(ShopType.longqi);
            if (!isOpen )
            {
                if (ShopManager.GetInst().VipLevel < 8)
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(8002269));
                }
                else
                {
                    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.shopingButton, Common.GetTextS(8002256, DEFINE.DIAMOND_ID + "%p" + 500), OnPopFrameCallBack);
                }
                return;
            }
        }
        SingletonObject<CPlayer>.GetInst().CloseHomeInfoMediator();
        mediator.Open(null);
    }

    private void OnPopFrameCallBack(PopFrameMediator.ClickType mClickType)
    {
        if (mClickType == PopFrameMediator.ClickType.clickOk)
        {
            if (SingletonObject<HomeMainMediator>.GetInst().CheckDiamond(500))
            {
                DiscountShopManager.GetInst().RequestOpenEver((uint)ShopType.longqi);
            }
        }
    }

    public void OpenNpcUI(string npcid)
    {
        uint id = uint.Parse(npcid);
        OpenNpcUI(id);
    }

    /// <summary>
    /// 获取NPC坐标
    /// </summary>
    public Vector3 GetNpcPosition(uint npcid)
    {
        Vector3 _temp = new Vector3();
        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(npcid);
        _temp = load.Position;
        return _temp;
    }

    /// <summary>
    /// 获取NPC朝向
    /// </summary>
    public Vector3 GetNpcRtationn(uint npcid)
    {
        Vector3 _temp = new Vector3();
        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(npcid);
        _temp = load.Direction;
        return _temp;
    }

    private DestPositionCallBack BreakOpenCallBack;

    private bool m_isDestPosition = false;
    public bool IsDestPosition
    {
        get { return m_isDestPosition; }
    }

    private bool m_isLock = false;
    public bool IsLock
    {
        get { return m_isLock; }
    }

    /// <summary>
    /// 玩家寻路到指定NPC坐标
    /// </summary>
    public void SetDestPosition(uint npcid, bool isLockMouseInput = false, DestPositionCallBack breakCallBack = null)
    {
        if (npcid == 0) return;
        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(npcid);
        if (load == null) return;
        m_isDestPosition = true;
        BreakOpenCallBack = breakCallBack;
        if (isLockMouseInput)
        {
            UIManager.GetInst().IsLockNGUIEvent(m_isLock = isLockMouseInput);
        }
        CPlayer player = SingletonObject<CPlayer>.GetInst();
        player.isClickNpc = true;
        player.m_npcID = npcid;
        player.m_npcPosition = load.Position;
        player.SetDestPosition(load.Position);
        SingletonObject<SystemPromptMediator>.GetInst().ShowPrompt(Common.GetTextS(9100143, Common.GetText(load.Name)));
    }

    public void ResultDestPosition(bool isSucceed)
    {
        if (m_isLock)
        {
            UIManager.GetInst().IsLockNGUIEvent(m_isLock = !m_isLock);
        }
        if (BreakOpenCallBack != null)
        {
            BreakOpenCallBack(isSucceed);
            BreakOpenCallBack = null;
        }
        m_isDestPosition = false;
    }
}
