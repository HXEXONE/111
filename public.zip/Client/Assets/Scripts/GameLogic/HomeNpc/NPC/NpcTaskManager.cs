﻿using System.IO;
using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;

public class NpcTaskManager : SingletonObject<NpcTaskManager>
{
    private string m_taskName = string.Empty;

    public eTaskType etaskType = eTaskType.None;
    private uint m_targetID = 0;    //目标参数
    private uint m_targetNpcID = 0; //交付任务目标
    private uint m_poltID = 0;  //剧情ID


    private CPlayer mcplayer;
    public bool isAllowSend = false;    //允许请求服务； 
    public uint currentNPCID = 0;//当前点击的NPCid
    public bool isFineshDialog = false;

    public uint levelID;//关卡任务ID；
    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_DELIVERY_QUEST_RESULT, onG2CAckDeliveryQuestResult,true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_FINISH_BATTLE_QUEST, onG2CNotifyFinishQuest,false);
    }


    #region 公开接口
    public void GoToTask(bool isLock,DestPositionCallBack callBack)
    {
        mcplayer = SingletonObject<CPlayer>.GetInst();

        //当前是否有任务
        if (mcplayer.CurQuestID != 0)
        {
            QuestContent questLoader = HolderManager.m_QuestHolder.GetStaticInfo(mcplayer.CurQuestID);
            if (questLoader != null)
            {
                etaskType = GetTaskType(questLoader.QuestType);
                switch (etaskType)
                {
                    case eTaskType.DialogueTask:
                        {
                            //对话任务
                            //if (mcplayer.CurQuestState != 1)
                            //{
                            //寻路到指定NPC完成对话人物。
							SingletonObject<AchieveMediator>.GetInst().Close();
                            SingletonObject<CPlayer>.GetInst().OpenHomeInfoMediator();
                            SingletonObject<NpcUIManager>.GetInst().SetDestPosition((uint)questLoader.TargetID, isLock, callBack);
                            //}
                        }
                        break;
                    case eTaskType.LevelCompleted:
                        {
                            if (mcplayer.CurQuestState == 1)
                            {
								SingletonObject<AchieveMediator>.GetInst().Close();
                                SingletonObject<CPlayer>.GetInst().OpenHomeInfoMediator();
                                SingletonObject<NpcUIManager>.GetInst().SetDestPosition((uint)questLoader.TargetNpcID, isLock, callBack);
                            }
                            else
                            {
                                //SingletonObject<NpcUIManager>.GetInst().SetDestPosition(15000005, isLock, callBack);
                                levelID = (uint)questLoader.TargetID;
                                CPlayer cplayer = SingletonObject<CPlayer>.GetInst();
                                //存在任务且任务状态为完成，则跳转到PVE界面
                                if ( cplayer.CurQuestID != 0 && levelID !=0)
                                {
                                    BattlePveManager.GetInst().GotoBattlePveMapID(levelID,true);
                                }
                                if (levelID == 0)
                                {
                                    MyLog.Log("the map id is 0 ,con't find mapid");
                                }
                            }
                        }
                        break;
                    case eTaskType.OperatingTask:
                        {

                        }
                        break;
                    case eTaskType.None:
                        break;
                }
            }
            else
            {
                MyLog.Log("quest loader is null.");
            }
        }
    }

    /// <summary>
    /// 关卡达人
    /// </summary>
    public void GoToLevelTask()
    {
        if (CBaseStory.IsInGameStory) return;//存在剧情模式下，无法出发进入PVE。
        SingletonObject<WorldAreaMapMediator>.GetInst().Open(null);
    }
    #endregion


    /// <summary>
    /// 根据点击的NPC检测是否有任务
    /// </summary>
    /// <param name="npcid">NPC ID</param>
    public void CheckTaskIsActive(uint npcid)
    {
        currentNPCID = npcid;
        mcplayer = SingletonObject<CPlayer>.GetInst();
       
        if (mcplayer.CurQuestID != 0)
        {
            QuestContent questLoader = HolderManager.m_QuestHolder.GetStaticInfo(mcplayer.CurQuestID);
            if (null != questLoader)
            {
                m_targetNpcID = (uint)questLoader.TargetNpcID;
            }
            if (m_targetNpcID != npcid)
            {
                //任务目标NPC非此NPC
                NpcUIManager.GetInst().OpenNpcUI(npcid);
            }
            else
            {
                if (mcplayer.CurQuestState == 1)
                {
                    LoadTaskData(mcplayer.CurQuestID); //有任务，并且已经完成
                    NpcUIManager.GetInst().NpcPlaySound(npcid);
                }
                else
                {
                    etaskType = (eTaskType)questLoader.QuestType; //有任务，当时没有完成，则触发剧情。
                    if (etaskType == eTaskType.LevelCompleted)   //关卡任务，则打开UI
                    {
                        levelID = (uint)questLoader.TargetID;
                        NpcUIManager.GetInst().OpenNpcUI(npcid);
                    }
                    else if (etaskType == eTaskType.DialogueTask)//对话任务则打开对话，并且对话完成，设置对话状态为完成
                    {
                        //设置任务状态为完成。
                        isFineshDialog = true;
                        stPlayerInfo st = mcplayer.GetPlayerInfo();
                        st.uiQuestIsFinshed =1;
                        st.uiQuestID = mcplayer.CurQuestID;//设置下一个任务ID
                        mcplayer.SetInfoBack(st);
                        //提示任务完成
                        string finishtip = Common.GetTextS(9921008, Common.GetText(questLoader.Name));
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(finishtip, Color.green);
                        LoadTaskData(mcplayer.CurQuestID);
                        NpcUIManager.GetInst().NpcPlaySound(npcid);
                    }
                    else if (etaskType == eTaskType.OperatingTask)
                    {
                       
                    }
                }
            }
        }
        else
        {
            NpcUIManager.GetInst().OpenNpcUI(npcid);                    //没有任务的情况，直接打开UI
        }
    }



    //完成任务加载...
    public void LoadTaskData(uint taskId)
    {
        QuestContent questLoader = HolderManager.m_QuestHolder.GetStaticInfo(taskId);
        if (questLoader != null)
        {
            m_poltID = (uint)questLoader.PlotID;
            int tasktype = questLoader.QuestType;
            etaskType = (eTaskType)tasktype;

            if (etaskType == eTaskType.DialogueTask)
            {
                //设置任务状态为完成。
                isFineshDialog = true;
            }
            //打开默认对白。。
            TaskMediator taskMediator = SingletonObject<TaskMediator>.GetInst();
            if (!taskMediator.IsOpen)
            {
                taskMediator.Open(delegate() {
                    taskMediator.SetBottomActive(true);
                    HomeNPCContent homenpc = HolderManager.m_HomeNPCHolder.GetStaticInfo(m_targetNpcID);
                    string desc = Common.GetText(homenpc.Desc);
                    taskMediator.InitPanel((int)m_targetNpcID, desc, Common.GetText(homenpc.Name));
                    isAllowSend = true;
                });
               
              
            }

            
        }
        else
            MyLog.LogError("Quest loader is null");
    }

    //检查准备提交任务
    public void CheckForSubmit()
    {
        uint questid = SingletonObject<CPlayer>.GetInst().CurQuestID;
        if (etaskType == eTaskType.LevelCompleted)
        {
            //发送请求。。提交任务，提交成功则加载剧情...否则，关闭界面
            OnC2GReqDeliveryQuest(questid);
        }
        else if (etaskType == eTaskType.DialogueTask)
        {
            //发送请求。。提交任务，提交成功则加载剧情...否则，关闭界面
            OnC2GReqDeliveryQuest(questid);
        }
    }

    public void PlayPoltForQuest()
    {
        if (NewBieGuidManager.GetInst().homeGuideKind == eHGuideTarget.Task)
        {
            NewBieGuidManager.GetInst().RequestSaveGuideInfo();
            stPlayerInfo st = mcplayer.GetPlayerInfo();
            MaiDianManager.GetInst().SetMdUpLoad(st.uiQuestID,MaiDianType.finishTask);
        }
        SingletonObject<TaskMediator>.GetInst().Close();
        CStoryManage.GetInst().SetInitStoryEffect(m_poltID, OnStoryFinished, CCamera.GetInst().GetCameraObj(), null);  //开始剧情
        SingletonObject<TaskMediator>.GetInst().HasShowAward = true;
    }

    private void OnStoryFinished(params object[] args)
    {
        NewBieGuidManager.GetInst().CheckHomeGuide();
        NewBieGuidManager.GetInst().SetHomeGuide();
        if (mcplayer == null) mcplayer = SingletonObject<CPlayer>.GetInst();
        if (mcplayer.GetPlayerInfo().uiQuestID > 60000002 && mcplayer.CurQuestState == 0) 
        {
            //当前任务id大于等于第二个主线任务,当前任务未完成的状态，且剧情结束后直接打开目标界面
            SingletonObject<CPlayer>.GetInst().CloseHomeInfoMediator();
            SingletonObject<AchieveMediator>.GetInst().Open(null);
        }
        
    }

    /// <summary>
    /// 获取目标类型
    /// </summary>
    public eTaskType GetTaskType(int typeindex)
    {
        switch (typeindex)
        {
            case 0:
                return eTaskType.None;
            case 1:
                return eTaskType.LevelCompleted;
            case 2:
                return eTaskType.DialogueTask;
            case 3:
                return eTaskType.OperatingTask;
            default:
                return eTaskType.None;
        }
    }

    //任务完成返回
    private void onG2CAckDeliveryQuestResult(BinaryReader br)
    {
        G2CAckDeliveryQuestResult result = new G2CAckDeliveryQuestResult();
        result.Read(br);
        if (mcplayer == null) mcplayer = SingletonObject<CPlayer>.GetInst();
        //2015年4月2日 16:46:55.收到任务返回成功或者已经完成
        if (result.uiResult == (ushort)EnumDeliveryQuest.EnumDeliveryQuest_Success || result.uiResult == (ushort)EnumDeliveryQuest.EnumDeliveryQuest_AlreadyFinish)
        {
            PlayPoltForQuest();

            stPlayerInfo st = mcplayer.GetPlayerInfo();
            FLSDK.missionSuccess(st.uiQuestID.ToString());
            st.uiQuestID = result.uiQuestID;//设置下一个任务ID
            if (st.uiQuestID != 0)
            {
                QuestContent loader = HolderManager.m_QuestHolder.GetStaticInfo(st.uiQuestID);
                etaskType = (eTaskType)loader.QuestType;
                if (etaskType == eTaskType.DialogueTask)
                {
                    st.uiQuestIsFinshed = 1;
                }
                else
                {
                    st.uiQuestIsFinshed = 0;
                }
            }

            mcplayer.SetInfoBack(st);
            
            isAllowSend = false;
            //接到任务
            QuestContent questLoader = HolderManager.m_QuestHolder.GetStaticInfo(mcplayer.CurQuestID);
            string finishtip = Common.GetTextS(9921009, Common.GetText(questLoader.Name));
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(finishtip, Color.green);
            SingletonObject<CPlayer>.GetInst().SetCanGetAchieve();
            SingletonObject<HUDAwardMediator>.GetInst().ShowTaskAward();
        }
        else
        {
            if(SingletonObject<TaskMediator>.GetInst().IsOpen)
                SingletonObject<TaskMediator>.GetInst().Close();
            string errortip = "ErrorCode:" + result.uiResult;
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(errortip, Color.red);
        }
    }



    //关卡任务完成通知
    private void onG2CNotifyFinishQuest(BinaryReader br)
    {
        G2CNotifyFinishQuest result = new G2CNotifyFinishQuest();
        result.Read(br);
        if (mcplayer == null) mcplayer = SingletonObject<CPlayer>.GetInst();
        stPlayerInfo st = mcplayer.GetPlayerInfo();
        st.uiQuestIsFinshed = 1;
        mcplayer.SetInfoBack(st);
        QuestContent questLoader = HolderManager.m_QuestHolder.GetStaticInfo(mcplayer.CurQuestID);
        string finishtip = Common.GetTextS(9921008, Common.GetText(questLoader.Name));
        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(finishtip, Color.green);
        SingletonObject<CPlayer>.GetInst().SetCanGetAchieve();
    }

    //提交任务请求...
    public void OnC2GReqDeliveryQuest(uint id)
    {
        C2GRequestDeliveryQuest msg = new C2GRequestDeliveryQuest();
        msg.uiQuestID = id;
        if (etaskType == eTaskType.DialogueTask)
        {
            if (isFineshDialog)
            {
                NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_DELIVERY_QUEST, (ushort)ProCG.GAME_ACK_CLIENT_DELIVERY_QUEST_RESULT, msg);
                isFineshDialog = false;
            }

        }
        else if (etaskType == eTaskType.LevelCompleted)
        {
            NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_DELIVERY_QUEST, (ushort)ProCG.GAME_ACK_CLIENT_DELIVERY_QUEST_RESULT, msg);
        }

    }

    #region 公开接口

    public bool CheckIsDialogQuest(uint id)
    {
        QuestContent loader = HolderManager.m_QuestHolder.GetStaticInfo(id);
        etaskType = (eTaskType)loader.QuestType;
        if (etaskType == eTaskType.DialogueTask)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// 检测携带任务情况下，是否可以挑战PVE。
    /// </summary>
    /// <param name="battlepveid">pve数据表ID</param>
    /// <returns>可以挑战则返回true，不可以挑战则返回false</returns>
    public bool CheckAllowBattle(uint battlepveid)
    {
        //CPlayer cplayer = SingletonObject<CPlayer>.GetInst();
        //if (cplayer.CurQuestID != 0)
        //{
        //    QuestContent loader = HolderManager.m_QuestHolder.GetStaticInfo(cplayer.CurQuestID);
        //    int count = loader.unlockTaskID.Count;
        //    //任务分类判断
        //    eTaskType type = (eTaskType)loader.type;
        //    if (type == eTaskType.LevelCompleted)
        //    {
        //        //如果是关卡型任务
        //        for (int i = 0; i < count; i++)
        //        {
        //            if (loader.unlockTaskID[i] != 0)
        //            {
        //                if (loader.unlockTaskID[i] < battlepveid)
        //                {
        //                    return false;
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //    return true;
        //}
        //else
        //{
        //    return true;
        //}
        return true;
    }

    #endregion
}
