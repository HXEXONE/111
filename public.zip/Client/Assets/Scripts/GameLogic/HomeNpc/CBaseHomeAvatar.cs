﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class stHomeAvatarInfo
{
    public ulong m_llAccountID;//玩家accountID
    public string szPlayerName;//玩家姓名
    public ushort uiPlayerLevel;//玩家等级
    public uint uiPlayerJob;//职业,其实也是静态表的playerID
    public uint uiWeaponID;//武器ID
    public uint uiClothesID;//衣服ID
    public uint uiPetID;//默认宠物
    public uint uiGsNum;        //战斗力
    public bool bIsvip;             //是否是vip
    public uint uiAttackCrystalId; //攻击龙晶
    public uint uiDefenceCrystalId;//防御龙晶
}

public class CBaseHomeAvatar 
{
    
    protected PlayerContent m_pPlayerLoader;
    protected stHomeAvatarInfo m_pHomeAvatarInfo = new stHomeAvatarInfo();

    protected CObject m_pObject;
    protected CObject m_pLeftWeaponObject;//左手武器
    protected CObject m_pRightWeaponObject;//右手武器
    protected CObject m_pAttackDragoncrystalObject;//攻击龙晶
    protected CObject m_pDefenceDragoncrystalObject;//防御龙晶
    protected CAnimator m_pAnimator;

    protected CPanel m_pNamePanel;//玩家信息组件
    private float m_nameOffset;//用于刷新玩家的名称
    protected float m_fBodyHeight;//身体高度
    protected string m_sPath;//模型路径
    protected string m_sAnimatorPath;//动作路径
    protected Dictionary<string,float> m_bodyHeightDic = new Dictionary<string, float>();//英雄模型高度字典。 

    protected CHomeStateManager m_stateMgr;

    protected Transform m_myTrans;
    private Vector3 m_myTranHighPos;//记录坐标

    private Vector3 m_destPosition;
    protected NavMeshAgent m_nma;//navmesh寻路

    //宠物相关
    protected CObject m_pPetObject = null;
    protected PetContent m_pPetLoader = null;//宠物数据表加载器
    protected CAnimator m_pPetAnimator = null;
    protected CPanel m_petChatBobble;
    private float m_chatTimeCountCown = 0.0f;
    private float m_chatTimeToCount = 30.0f;
    private List<string> m_chatWordsAtHomeList = new List<string>();

    

    public virtual void Init(Vector3 position,Quaternion rotation)
    {
        m_stateMgr = new CHomeStateManager(this);

        m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(m_pHomeAvatarInfo.uiPlayerJob);

        CreateNpc(position, rotation);
    }

    public ulong GetAccountID()
    {
        return m_pHomeAvatarInfo.m_llAccountID;
    }

    public void SetLevel(ushort wLevel)
    {
        m_pHomeAvatarInfo.uiPlayerLevel = wLevel;
        UpdateAvatarInfoComponent();
    }

    public void UpdateAvatarInfoComponent()
    {
        if (ClientMain.GetInst().GetCurrentState() != eGameState.Home)
        {
            return;
        }
        string accountID = m_pHomeAvatarInfo.m_llAccountID.ToString();

        if (null == m_pNamePanel || m_pNamePanel.Index != accountID)
        {
            m_pNamePanel = SingletonObject<HomeAvatarNameMediator>.GetInst().AddNameComponent(m_pHomeAvatarInfo.szPlayerName, m_pHomeAvatarInfo.uiPlayerLevel,false);
            if (null != m_pNamePanel)
            {
                m_pNamePanel.Index = accountID;
            }
            
        }
        else
        {
            SingletonObject<HomeAvatarNameMediator>.GetInst().UpdateName(m_pNamePanel, m_pHomeAvatarInfo.szPlayerName);
            SingletonObject<HomeAvatarNameMediator>.GetInst().UpdateLevel(m_pNamePanel, m_pHomeAvatarInfo.uiPlayerLevel);
        }

        if (this is CPlayer)
        {
            m_nameOffset = Random.Range(0.1f, 0.15f);
        }
        else
        {
            m_nameOffset = 0.1f;
        }
    }

    public bool IsSelfAvatar
    {
        get 
        {   
            CPlayer player = SingletonObject<CPlayer>.GetInst();

            return (m_pHomeAvatarInfo.szPlayerName == player.GetHomeAvatarInfo().szPlayerName);                  
        }
    }

    private void CreateNpc(Vector3 position, Quaternion rotation)
    {
        //模型会根据人物衣服来换
        UpdateCloth(m_pHomeAvatarInfo.uiClothesID, position, rotation,false);
       
    }

    private void ReloadPetCallback(object parm)
    {
        uint petID = 0;
        bool loadReplace = false;

        if (parm == null)
            return;

        string strArgs = (string)parm;
        string[] strParms = strArgs.Split('~');
        if (strParms == null || strParms.Length != 2)
            return;

        if (!uint.TryParse(strParms[0], out petID))
            return;

        loadReplace = strParms[1].Equals("1");


        if (petID == 0) return;
        //加载宠物信息
        m_pPetLoader = HolderManager.m_PetHolder.GetStaticInfo(petID);
        if (null != m_pPetLoader)
        {
            if (m_pPetObject != null)
            {
                m_pPetObject.DestroyGameObject(eObjectDestroyType.Memory);
                m_pPetObject = null;
                m_pPetAnimator = null;
            }

            //加载模型
            string szPath = m_pPetLoader.ModelLoader.Path;
            m_pPetObject = new CObject(szPath);
            m_pPetObject.Layer = DEFINE.PET_LAYER;
            m_pPetObject.Name = m_pHomeAvatarInfo.m_llAccountID.ToString() + "_Pet";
            m_pPetObject.Args = new object[] { loadReplace, petID };
            m_pPetObject.CallBack = LoadPetCompleted;
            m_pPetObject.IsMemoryFactory = true;
            m_pPetObject.ObjectType = loadReplace ? eObjectType.ReplaceModel : eObjectType.Pet;
            m_pPetObject.BornPosition = m_pObject.transform.position + Vector3.up * 1.5f;
            m_pPetObject.BornRotation = m_pObject.transform.rotation;
            m_pPetObject.LoadObject();


            //初始化宠物家园场景喊话数据
            m_chatWordsAtHomeList.Clear();
            foreach (uint uTexId in m_pPetLoader.ModelLoader.PetHomeWords)
            {
                m_chatWordsAtHomeList.Add(Common.GetText(uTexId));
            }

        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="petID"></param>
    /// <param name="loadReplace">替代原有的模型</param>
    public void ReLoadPet(uint petID,bool loadReplace = false)
    {
        if (petID == 0) return;

        string strParm = petID.ToString() + "~" + (loadReplace ? "1" : "0");
        //2015-5-30 策划需要触发，原因是想把3包资源移动到2包。这样资源下载太大，所以就放到了后面的包。用宠物坐骑触发下载
        bool needUpdate = false;
        if(this is CPlayer)
            needUpdate = UpdateManager.GetInst().CheckPetNeedUpdate(petID, ReloadPetCallback, strParm);
        if (needUpdate)
            return;
        else
        {
            ReloadPetCallback(strParm);
        }
    }

    protected virtual void LoadAvatarCompleted(GameObject o, params object[] args)
    {
        if ( o == null )
        {
            m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);            
            PlayerConfigContent playerConfig  = HolderManager.m_PlayerConfigHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            if (null == m_pPlayerLoader || null == playerConfig)
            {
                return;
            }           
            UpdateCloth((uint)playerConfig.Clothes, m_pObject.BornPosition,m_pObject.BornRotation,true);
            return;
        }

        bool replaceModel = (bool)args[0];
        if (replaceModel)
        {
            Common.MaterialCulling(o);
        }

        m_myTrans = o.transform;
        m_myTrans.transform.localScale = Vector3.one;
        CharacterController cc = o.GetComponent<CharacterController>();
        if (cc != null)
        {
            cc.enabled = false;
        }

        Common.ShowAvatarClothes(o, false);

        m_sAnimatorPath = Common.ReplaceHomeAniPath(m_pPlayerLoader.AmimatorPath); 

        m_nma = o.GetComponent<NavMeshAgent>();
        if (null == m_nma)
        {
            m_nma = o.AddComponent<NavMeshAgent>();
            m_nma.radius = 0;
            m_nma.height = 0;
            m_nma.speed = 7.0f;
            m_nma.acceleration = 360;
            m_nma.angularSpeed = 360;
        }
        m_nma.enabled = true;
        m_myTrans.position = Common.NavSamplePosition(m_myTrans.position);

        Transform followTrans = o.transform.Find("FollowObject");
        if (followTrans != null)
        {
            NavMeshAgent nma = followTrans.GetComponent<NavMeshAgent>();
            if (nma != null) nma.enabled = false;
        }

        //获取模型高度
        SkinnedMeshRenderer[] smrs = m_myTrans.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (smrs.Length > 0)
        {
            //m_fBodyHeight = smrs[0].bounds.size.y;
            DynamicShader.SetMaterialToVertexLight(m_myTrans.gameObject, eNpcRenderType.SkinMeshRender, Vector3.zero);
        }
        //else
        //{
        //    m_fBodyHeight = 2.0f;//默认高度
        //}
        m_fBodyHeight = playerLoader.BodyHeight;
        if (!m_bodyHeightDic.ContainsKey(m_sPath))
        {
            m_bodyHeightDic.Add(m_sPath, m_fBodyHeight);
        }
        else
        {
            m_bodyHeightDic[m_sPath] = m_fBodyHeight;
        }


        UpdateWeapon(m_pHomeAvatarInfo.uiWeaponID);



        Transform shadow = o.transform.FindChild("shadow");
        if (ClientMain.IsSupportShadowRunTime)
        {
            if (shadow)
            {
                Object.Destroy(shadow.gameObject);
            }
        }
        else
        {
            if (shadow)
                shadow.transform.localPosition = Vector3.zero;
        }

//         Animator aniCtrl = m_myTrans.GetComponent<Animator>();
//         if (null == aniCtrl)
//         {
//             o.SetActive(false);
//             LoadHelp.LoadObject("", m_sAnimatorPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
//         }
//         else
//         {
//             BuildAnimator(aniCtrl);
//         }

        Animator aniCtrl = m_myTrans.GetComponent<Animator>();
        if (null == aniCtrl)
        {
            MyLog.LogError(m_sPath + " can not find animator Component !  ");
            return;
        }

        if (null == aniCtrl.runtimeAnimatorController)
        {
            o.SetActive(false);
            LoadHelp.LoadObject("", m_sAnimatorPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
        }
        else
        {
            BuildAnimator(aniCtrl);
        }
        //加载宠物信息
        ReLoadPet(m_pHomeAvatarInfo.uiPetID);

        //龙晶初始化
        CreateDragonshard(m_pHomeAvatarInfo.uiAttackCrystalId, eDragonshardType.avatarAttack);
        CreateDragonshard(m_pHomeAvatarInfo.uiDefenceCrystalId, eDragonshardType.avatarDef);


    }

    private void CreateDragonshard(uint uiCrystalId,eDragonshardType type)
    {
        DragoncrystalContent pDragonContent = HolderManager.m_DragoncrystalHolder.GetStaticInfo(uiCrystalId);
        if (null == pDragonContent)
        {
            return;
        }

        ParticleContent pParticleContent = HolderManager.m_ParticleHolder.GetStaticInfo(pDragonContent.CrystalAndEnchantEffect[0]);
        if (null == pParticleContent)
        {
            return;
        }

        if (type == eDragonshardType.avatarAttack)
        {
            m_pAttackDragoncrystalObject = new CObject(pParticleContent.Path);
            m_pAttackDragoncrystalObject.Name = uiCrystalId.ToString();
            m_pAttackDragoncrystalObject.CallBack = LoadDragoncrystalCompleted;
            m_pAttackDragoncrystalObject.IsMemoryFactory = true;
            m_pAttackDragoncrystalObject.ObjectType = eObjectType.LongJing;
            m_pAttackDragoncrystalObject.Layer = DEFINE.AVATAR_LAYER;
            m_pAttackDragoncrystalObject.LoadObject();
        }
        else if (type == eDragonshardType.avatarDef)
        {
            m_pDefenceDragoncrystalObject = new CObject(pParticleContent.Path);
            m_pDefenceDragoncrystalObject.Name = uiCrystalId.ToString();
            m_pDefenceDragoncrystalObject.CallBack = LoadDragoncrystalCompleted;
            m_pDefenceDragoncrystalObject.IsMemoryFactory = true;
            m_pDefenceDragoncrystalObject.ObjectType = eObjectType.LongJing;
            m_pDefenceDragoncrystalObject.Layer = DEFINE.AVATAR_LAYER;
            m_pDefenceDragoncrystalObject.LoadObject();
        }



    }

    private void LoadDragoncrystalCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        o.transform.parent = m_pObject.transform;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="clothID"></param>
    /// <param name="position"></param>
    /// <param name="rotation"></param>
    /// <param name="replaceModel">替代原有的模型</param>
    public void UpdateCloth(uint clothID, Vector3 position, Quaternion rotation,bool replaceModel = false)
    {
        EquipContent pArmorLoader = HolderManager.m_EquipHolder.GetStaticInfo(clothID);
        if (null != pArmorLoader)
        {
            List<string> pathArray = pArmorLoader.ModelLoader.ModelPath ;
            if (pathArray.Count > 0 && pathArray[0] != "0")
            {
                if (m_pObject != null)
                {
                    m_pObject.DestroyGameObject(eObjectDestroyType.Memory);
                }

                m_pObject = new CObject(pathArray[0]);               
                m_sPath = m_pObject.Path;
                m_pObject.Name = m_pHomeAvatarInfo.m_llAccountID.ToString();
                m_pObject.Args = new object[] { replaceModel };
                m_pObject.CallBack = LoadAvatarCompleted;
                m_pObject.IsMemoryFactory = true;
                m_pObject.ObjectType = replaceModel ? eObjectType.ReplaceModel:  eObjectType.HomeAvatar;
                m_pObject.BornPosition = position;
                m_pObject.BornRotation = rotation;
                m_pObject.Layer = 0;
                m_pObject.LoadObject();
            }
        }
        else
        {
            MyLog.LogError("Create Home Npc error:" + m_pHomeAvatarInfo.uiClothesID);
        }
    }

    /// <summary>
    /// 更新武器
    /// </summary>
    /// <param name="weapon"></param>
    public void UpdateWeapon(uint weaponid)
    {
        EquipContent pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(weaponid);
        if (null != pWeaponLoader)
        {
            List<string> pathArray = pWeaponLoader.ModelLoader.ModelPath;
            
            if (!pathArray[0].Equals("0"))
            {
                if (m_pLeftWeaponObject != null)
                    m_pLeftWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
                m_pLeftWeaponObject = new CObject(pathArray[0]);
                m_pLeftWeaponObject.CallBack = LoadLeftWeaponCompleted;
                m_pLeftWeaponObject.IsMemoryFactory = true;
                m_pLeftWeaponObject.ObjectType = eObjectType.Weapon;
                m_pLeftWeaponObject.LoadObject();
            }

            if (!pathArray[1].Equals("0"))
            {
                if (m_pRightWeaponObject != null)
                    m_pRightWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
                m_pRightWeaponObject = new CObject(pathArray[1]);
                m_pRightWeaponObject.CallBack = LoadRightWeaponCompleted;
                m_pRightWeaponObject.IsMemoryFactory = true;
                m_pRightWeaponObject.ObjectType = eObjectType.Weapon;
                m_pRightWeaponObject.LoadObject();
            }
        }
    }

    private void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        if (m_myTrans == null)
        {
            m_pLeftWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        if (null == o)
        {
            return;
        }
        o.transform.parent = Common.GetBone(m_myTrans, "Bip01 Prop2");
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        DynamicShader.SetMaterialToVertexLight(o,eNpcRenderType.MeshRender,Vector3.zero);
    }



    private void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        if (m_myTrans == null)
        {
            m_pRightWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        if (null == o)
        {
            return;
        }
        o.transform.parent = Common.GetBone(m_myTrans, "Bip01 Prop1");
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        DynamicShader.SetMaterialToVertexLight(o,eNpcRenderType.MeshRender,Vector3.zero);
    }

    private void LoadAcnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        if (null == m_myTrans)
        {
            return;
        }
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;
        

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }
        
        Animator aniCtrl = m_myTrans.GetComponent<Animator>();
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//         if (null == aniCtrl)
//         {
//             aniCtrl = m_myTrans.gameObject.AddComponent<Animator>();
//             aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//             aniCtrl.avatar = animator.avatar;
//         }


        m_myTrans.gameObject.SetActive(true);

        BuildAnimator(aniCtrl);

//         aniCtrl.applyRootMotion = false;
//         aniCtrl.enabled = true;
// 
//         m_pAnimator = new CAnimator(aniCtrl);
// 
//         EnterState(eActionState.IdelInHome);

    }

    private void BuildAnimator(Animator animator) 
    {
        animator.applyRootMotion = false;
        animator.enabled = true;

        m_pAnimator = new CAnimator(animator);
        EnterState(eActionState.IdelInHome);

   
        PlaySound playSound = m_myTrans.GetComponent<PlaySound>();
        if (null == playSound)
        {
            playSound = m_myTrans.gameObject.AddComponent<PlaySound>();
        }
        playSound.StepHandle = OnStepHandle;
               
    }

    private void OnStepHandle(int step)
    {
        if (!IsSelfAvatar)
            return;
        uint baseId = 500; //基础id

        uint soundId = (uint)(baseId + step + (int)Common.GetJobType(m_pPlayerLoader) * 10);

        CMusicManager.GetInst().CreateSound(m_myTrans.gameObject, soundId);
    }

    //private uint m_petEffectID = 0;
    
    protected virtual void LoadPetCompleted(GameObject o, params object[] args)
    {
        if (o == null)
        {
            m_pPetLoader = HolderManager.m_PetHolder.GetStaticInfo(DEFINE.REPLACE_PET_LOADER_KEY);
            if (null == m_pPetLoader)
                return;

            ReLoadPet(DEFINE.REPLACE_PET_LOADER_KEY, true);
            return;
        }

        bool replaceModel = (bool)args[0];
        if (replaceModel)
        {
            Common.MaterialCulling(o);
        }

        //加载动画组件
        string szPath = m_pPetLoader.ModelLoader.Path;
        szPath = szPath.Replace("_model", "_ctrl");
        LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadPetAcnimatorCtrl);

        //加载拖尾特效
        //m_petEffectID =  CParticleManager.GetInst().CreateBindEffect(DEFINE.PET_TRAIL_EFFECT, m_pPetObject.gameCObject);

        //不需要controller
        CharacterController petcc = o.GetComponent<CharacterController>();
        if (petcc != null)
        {
            petcc.enabled = false;
        }

        //动作带位移
        Animator petani = o.GetComponent<Animator>();
        if (petani != null)
        {
            petani.applyRootMotion = true;
        }

        setPetParticals(o,(uint)args[1]);
    }

    private void LoadPetAcnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        if (m_pPetObject == null)
        {
            return;
        }
        if (null == m_pPetObject.gameCObject)
        {
            return;
        }
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        Animator aniCtrl = m_pPetObject.transform.GetComponent<Animator>();
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//         if (null == aniCtrl)
//         {
//             aniCtrl = m_pPetObject.gameCObject.AddComponent<Animator>();
//             aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//             aniCtrl.avatar = animator.avatar;
//         }
        aniCtrl.applyRootMotion = true;
        aniCtrl.enabled = true;

        m_pPetAnimator = new CAnimator(aniCtrl);
    }

    public void EnterState(eActionState state)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.EnterState(state);
        }
    }


    public void LeaveState(eActionState state)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.LeaveState(state);
        }
    }

    //检测当前寻路是否完毕
    public bool CheckReached()
    {
        return Common.Get2DVecter3Length(m_myTrans.position,m_destPosition) <= 0.1f;
    }

    public void PlayAction(eActionState state, float fSpeed = 1.0f, bool bRepeat = false,float fadetime = 0.05f)
    {
        if (null != m_pAnimator)
        {
            string actionName = stStateData.GetActionName(state);
            m_pAnimator.PlayAction(actionName, fSpeed, bRepeat, null, fadetime,null);
        }
    }

    public virtual void Update()
    {
        if (null == m_myTrans)
        {
            return;
        }

        if (m_stateMgr != null)
        {
            m_stateMgr.Update();
        }

        if (null != m_pAnimator)
        {
            m_pAnimator.Update();
        }

        if (m_pNamePanel != null)
        {
            if (!m_pNamePanel.IsActive() && m_myTrans.gameObject.activeSelf)
            {
                m_pNamePanel.SetActive(true);
            }
            
            m_myTranHighPos = m_myTrans.position;
            m_myTranHighPos += Vector3.up * (m_bodyHeightDic[m_sPath] + m_nameOffset);
            SingletonObject<HomeAvatarNameMediator>.GetInst().UpdatePosition(m_pNamePanel, m_myTranHighPos);
        }

        if (m_pPetObject != null && m_pPetObject.gameCObject != null && m_pPetAnimator != null)
        {
            PetUpdate();
        }
    }

    private void PetUpdate()
    {
        if (m_pPetLoader == null || m_pPetObject == null || m_pPetAnimator == null)
        {
            return;
        }

        if (m_pPetAnimator != null)
        {
            m_pPetAnimator.Update();
        }

        //喊话
        if (this is CPlayer)
        {
            m_chatTimeCountCown -= Time.deltaTime;
            if (m_chatTimeCountCown <= 0.0f)
            {
                m_chatTimeCountCown = m_chatTimeToCount;

                if (m_chatWordsAtHomeList != null)
                {
                    if (m_chatWordsAtHomeList.Count > 0)
                    {
                        string wordsToSay = m_chatWordsAtHomeList[Random.Range(0, m_chatWordsAtHomeList.Count)];
                        if (m_petChatBobble != null)
                        {
                            SingletonObject<ChatBubbleMediator>.GetInst().RemoveItem(m_petChatBobble);
                        }

                        m_petChatBobble = SingletonObject<ChatBubbleMediator>.GetInst().AddChatBobble(wordsToSay);
                    }
                }
            }
            if (m_petChatBobble != null)
            {
                SingletonObject<ChatBubbleMediator>.GetInst().UpdatePosition(m_petChatBobble, m_pPetObject.transform.position);
                //MyLog.Log("PS : " + m_pPetObject.transform.position);
            }
        }

        //运动
        if (m_pPetObject.gameCObject != null && m_myTrans != null)
        {
            Vector3 targetPosition = m_myTrans.position + m_myTrans.right.normalized * 1f + m_myTrans.forward.normalized * 1f;

            float distance = Common.Get2DVecter3Length(m_pPetObject.transform.position, targetPosition);

            //同步高度
            m_pPetObject.transform.position = new Vector3(m_pPetObject.transform.position.x, m_myTrans.position.y + 2.5f, m_pPetObject.transform.position.z);
            //m_pPetObject.transform.position = new Vector3(m_pPetObject.transform.position.x, m_pPetObject.transform.position.y + (Mathf.Pow(1.5f, distance) - 1.0f) / 8.0f, m_pPetObject.transform.position.z);

            float animateSpeed = Mathf.Clamp( Mathf.Pow(1.4f, distance) - 1.0f,0.5f,2);
            Vector3 targetDir = m_myTrans.forward;

            if (animateSpeed <= 0.5f)//停止移动
            {
                m_pPetAnimator.PlayAction("idle", 1.0f, false);
                
            }
            else if (distance <= 20.0f) //跟随移动
            {
                if (m_pPetAnimator != null)
                {
                    m_pPetAnimator.Speed = animateSpeed;
                }

                m_pPetAnimator.PlayAction("run", 1.0f, false);

                targetDir = targetPosition - m_pPetObject.transform.position;

                //旋转
                Quaternion rot = m_pPetObject.transform.rotation;
                Quaternion toTarget = Quaternion.LookRotation(targetDir);
                rot = Quaternion.Slerp(rot, toTarget, Time.deltaTime * 5.0f);
                Vector3 euler = rot.eulerAngles;
                euler.z = 0;
                euler.x = 0;
                rot = Quaternion.Euler(euler);
                m_pPetObject.transform.rotation = rot;
            }
            else//瞬间移动
            {
                m_pPetObject.transform.position = targetPosition;
            }

            
        }
    }

    public void SetDestPosition(Vector3 destPosition)
    {
        m_destPosition = destPosition;
        if (m_nma != null && m_nma.enabled && Vector3.Distance(m_destPosition,m_myTrans.position) > 0.1f)
        {
            m_nma.SetDestination(destPosition);
            EnterState(eActionState.RunInHome);
        }
    }

    public void StopNavMeshAgent()
    {
        if (m_nma != null && m_nma.enabled)
        {
            m_nma.Stop();
        }
    }

    public virtual void Release(eObjectDestroyType type)
    {
        m_pPlayerLoader = null;
        m_pAnimator = null;
        m_myTrans = null;

        if (m_pObject != null)
        {
            m_pObject.DestroyGameObject(type);
            m_pObject = null;
        }

        if (m_pLeftWeaponObject != null)
        {
            m_pLeftWeaponObject.DestroyGameObject(type);
            m_pLeftWeaponObject = null;
        }

        if (m_pRightWeaponObject != null)
        {
            m_pRightWeaponObject.DestroyGameObject(type);
            m_pRightWeaponObject = null;
        }

        if (m_pAttackDragoncrystalObject != null)
        {
            m_pAttackDragoncrystalObject.DestroyGameObject(type);
            m_pAttackDragoncrystalObject = null;
        }

        if (m_pDefenceDragoncrystalObject != null)
        {
            m_pDefenceDragoncrystalObject.DestroyGameObject(type);
            m_pDefenceDragoncrystalObject = null;
        }

        if (m_pNamePanel != null)
        {
            SingletonObject<HomeAvatarNameMediator>.GetInst().RemoveItem(m_pNamePanel);
            m_pNamePanel = null;
        }

        if (m_pPetObject != null)
        {
            m_pPetObject.DestroyGameObject(type);
            m_pPetObject = null;
            m_pPetAnimator = null;
        }

        //卸载宠物特效
        //if (m_petEffectID != 0)
        //{
        //    CParticleManager.GetInst().AddDestroyParticle(m_petEffectID);
        //    m_petEffectID = 0;
        //}

        if (m_petChatBobble != null)
        {
            SingletonObject<ChatBubbleMediator>.GetInst().RemoveItem(m_petChatBobble);
            m_petChatBobble = null;
        }
    }

    public stHomeAvatarInfo GetHomeAvatarInfo()
    {
        return m_pHomeAvatarInfo;
    }

    public PlayerContent playerLoader
    {
        get
        {
            return m_pPlayerLoader;
        }
    }


    /// <summary>
    /// 家园玩家gameobject
    /// </summary>
    public GameObject gameObject
    {
        get
        {
            return m_pObject.gameCObject;
        }
    }

    public Transform transform
    {
        get
        {
            return m_myTrans;
        }
    }

    public CPanel cPanel
    {
        get
        {
            return m_pNamePanel;
        }
        set
        {
            m_pNamePanel = value;
        }
    }

    public string ModelPath
    {
        get
        {
            return m_sPath;
        }
    }

    public string AnimatorPath
    {
        get
        {
            return m_sAnimatorPath;
        }
    }


    public void EnableAnimator(bool bEnable)
    {
        if (m_pAnimator != null)
        {
            m_pAnimator.Enabled = bEnable;
        }
        if (m_pPetAnimator != null)
        {
            m_pPetAnimator.Enabled = bEnable;
        }
    }

    /// <summary>
    /// 显示宠物的分阶特效
    /// </summary>
    /// <param name="pet"></param>
    /// <param name="id"></param>
    public static void setPetParticals(GameObject pet, uint id)
    {
        /*
        PetContent petload = HolderManager.m_PetHolder.GetStaticInfo(id);
        if (petload == null)
        {
            return;
        }
        int index = petload.PetLevel;

        List<string> effectList = petload.M_EffectId;

        Component[] mtran = pet.GetComponentsInChildren(typeof(Transform), true);

        List<Transform> tranList = new List<Transform>();
        foreach (Transform tran in mtran)
        {
            if (tran.name.EndsWith("_1"))
            {
                tranList.Add(tran);
            }
        }

        if (CParticleManager.IsOpen)
        {
            for (int j = 0; j < tranList.Count; j++)
            {
                if (effectList.Contains(tranList[j].name))
                {

                    //显示特效
                    tranList[j].gameObject.SetActive(true);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == false)
                    {
                        ps.renderer.enabled = true;
                    }
                }
                else
                {
                    //隐藏特效
                    tranList[j].gameObject.SetActive(false);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == true)
                    {
                        ps.renderer.enabled = false;
                    }
                }
            }
        }
        */

        PetContent petload = HolderManager.m_PetHolder.GetStaticInfo(id);
        if (petload == null)
        {
            return;
        }
        PetParticleRoot ppr = pet.GetComponent<PetParticleRoot>();
        if (ppr == null)
        {
            return;
        }

        List<string> effectList = petload.M_EffectId;

        List<Transform> tranList = ppr.particleList;
        if (tranList == null)
        {
            return;
        }

        if (CParticleManager.IsOpen)
        {
            for (int j = 0; j < tranList.Count; j++)
            {
                if (effectList.Contains(tranList[j].name))
                {
                    if (tranList[j] == null)
                    {
                        continue;
                    }
                    //显示特效
                    tranList[j].gameObject.SetActive(true);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == false)
                    {
                        ps.renderer.enabled = true;
                    }
                }
                else
                {
                    //隐藏特效
                    tranList[j].gameObject.SetActive(false);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == true)
                    {
                        ps.renderer.enabled = false;
                    }
                }
            }
        }

    }

    /// <summary>
    /// 显示坐骑的分阶特效
    /// </summary>
    /// <param name="pet"></param>
    /// <param name="id"></param>
    public static void setMountParticals(GameObject pet, uint id)
    {

        MountsContent petload = HolderManager.m_MountsHolder.GetStaticInfo(id);
        if (petload == null)
        {
            return;
        }

        PetParticleRoot ppr = pet.GetComponent<PetParticleRoot>();
        if (ppr == null)
        {
            return;
        }

        List<string> effectList = petload.M_EffectId;

        List<Transform> tranList = ppr.particleList;
        if (tranList == null)
        {
            return;
        }

        if (CParticleManager.IsOpen)
        {
            for (int j = 0; j < tranList.Count; j++)
            {
                if (tranList[j] == null)
                {
                    continue;
                }
                if (effectList.Contains(tranList[j].name))
                {
                    //显示特效
                    tranList[j].gameObject.SetActive(true);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == false)
                    {
                        ps.renderer.enabled = true;
                    }
                }
                else
                {
                    //隐藏特效
                    tranList[j].gameObject.SetActive(false);
                    ParticleSystem ps = tranList[j].GetComponent<ParticleSystem>();
                    if (ps == null)
                    {
                        continue;
                    }
                    if (ps.renderer.enabled == true)
                    {
                        ps.renderer.enabled = false;
                    }
                }
            }
        }
        int curlevel = petload.MountsLevel;

        int starS = petload.MountsStar;

        if (curlevel == starS)
        {
            int matTrCount = ppr.materialTr.Count;
            int matCount = ppr.materiallist.Count;
            //Debug.LogError(" 可替换材质数=  " + matTrCount + " / " + matCount);
            for (int i = 0; i < matTrCount; i++)
            {
                if (ppr.materiallist[i] != null)
                {
                    ppr.materialTr[i].gameObject.renderer.material = ppr.materiallist[i];
                }
            }
        }
        

    }


    public void CloseAllParticles()
    {
        ParticleSystem[] particles;
        int count;

        if (m_myTrans) //如果没有找到说明在loading，内存池会消灭掉，不用在这消灭
        {
            particles = m_myTrans.GetComponentsInChildren<ParticleSystem>(); //active 为 false 的说明已经被干掉了，无需再干
            if (particles != null)
            {
                count = particles.Length;
                for (int i = 0; i < count; i++)
                {
                    particles[i].Stop();
                    particles[i].gameObject.SetActive(false);
                }
            }
        }

        if (m_pPetObject != null && m_pPetObject.transform != null)
        {
            particles = m_pPetObject.transform.GetComponentsInChildren<ParticleSystem>(); //active 为 false 的说明已经被干掉了，无需再干
            if (particles != null)
            {
                count = particles.Length;
                for (int i = 0; i < count; i++)
                {
                    particles[i].Stop();
                    particles[i].gameObject.SetActive(false);
                }
            }
        }
    }
}
