﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class NpcEvent:MonoBehaviour
{

    void Start()
    {
    }

    void OnEnable()
    {
        EasyTouch.On_TouchStart = On_TouchStart;
    }

    private void On_TouchStart(Gesture gesture)
    {
        if (gesture == null) return;
        Dictionary<int,HomeNPCContent> dict = SingletonObject<CHomeNpc>.GetInst().NpcLoaderDic;
        foreach (KeyValuePair<int, HomeNPCContent> itemPair in dict)
        {
            if(itemPair.Key == 0 || gesture.pickObject == null) return;
            if(itemPair.Key.ToString() == gesture.pickObject.name)
                MyLog.Log(gesture.pickObject.name);
        }
        
    }

    void OnDisable()
    {
        UnsubscribeEvent();
    }

    void OnDestroy()
    {
        UnsubscribeEvent();
    }

    void UnsubscribeEvent()
    {
        EasyTouch.On_TouchStart = null; 
    }

}
