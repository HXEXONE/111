﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CHomeStateManager
{
    private CBaseHomeAvatar m_pHomeAvatar;
    private CBaseHomeState m_currState;
    private eActionState m_actState;

    private Dictionary<eActionState, CBaseHomeState> m_stateDict = new Dictionary<eActionState, CBaseHomeState>();

    public CHomeStateManager(CBaseHomeAvatar pAvatar)
    {
        m_pHomeAvatar = pAvatar;        
        Reuse();
        RegisterState(new CHomeRunState(pAvatar));
        RegisterState(new CHomeNormalState(pAvatar));
    }

    private void RegisterState(CBaseHomeState pState)
    {
        eActionState eState = pState.GetState();
        if (!m_stateDict.ContainsKey(eState))
        {
            m_stateDict.Add(eState, pState);
        }
    }

    public void EnterState( eActionState state)
    {
        CBaseHomeState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            m_currState = pState;
            pState.EnterState();
        }
    }

    public void LeaveState( eActionState state )
    {
        CBaseHomeState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            if (m_currState != null && m_currState == pState)
            {
                pState.LeaveState();

                if (m_currState == pState && state != eActionState.IdelInHome)
                {
                    m_pHomeAvatar.EnterState(eActionState.IdelInHome);
                }
             }
        }
    }

    public void Reuse() 
    {
        m_currState = null;
    }

    public void Update()
    {
        if (m_currState != null)
        {
            m_currState.Update();
        }
    }
}
