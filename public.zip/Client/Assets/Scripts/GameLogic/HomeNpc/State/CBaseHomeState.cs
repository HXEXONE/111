﻿using UnityEngine;
using System.Collections;

public class CBaseHomeState 
{
    protected CBaseHomeAvatar m_pHomeAvatar;
    protected eActionState m_state;

    public CBaseHomeState(CBaseHomeAvatar pAvatar, eActionState state)
    {
        m_pHomeAvatar = pAvatar;
        m_state = state;
    }

    public virtual void EnterState() 
    {
        
    }

    public virtual void LeaveState()
    {
    }

    public virtual void Update()
    {
              
    }


    public eActionState GetState() { return m_state; }
}
