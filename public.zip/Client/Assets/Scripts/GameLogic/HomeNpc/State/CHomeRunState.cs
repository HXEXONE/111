﻿using UnityEngine;
using System.Collections;

public class CHomeRunState : CBaseHomeState
{
    public CHomeRunState(CBaseHomeAvatar pAvatar) :
        base(pAvatar, eActionState.RunInHome)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pHomeAvatar.PlayAction(m_state, 1, false);
    }

    public override void Update()
    {
        base.Update();

        if (m_pHomeAvatar.CheckReached())
        {
            m_pHomeAvatar.LeaveState(m_state);
        }
    }
}
