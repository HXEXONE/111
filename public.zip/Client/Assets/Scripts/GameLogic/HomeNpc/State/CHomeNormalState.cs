﻿using UnityEngine;
using System.Collections;

public class CHomeNormalState : CBaseHomeState
{
    public CHomeNormalState(CBaseHomeAvatar pAvatar) :
        base(pAvatar, eActionState.IdelInHome)
    {
    }
    

    

    public override void EnterState()
    {
        base.EnterState();

        m_pHomeAvatar.PlayAction(m_state, 1, false,0.2f);

        m_pHomeAvatar.StopNavMeshAgent();
    }

}
