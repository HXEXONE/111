﻿using UnityEngine;
using System.Collections.Generic;

public class DropGoldEx{

    private List<int> m_recordCount;
    private List<Vector3> m_recordPosition;

    private DropParticleEmitEx m_dropEmitEx;
    private CObject m_goldEmitObject;

    private Transform m_followTransform;
    private GameObject m_parentGameObject;
    private Transform m_parent;

    private float m_radius;

    private int m_collectCount;
    private int m_group;

    private bool m_open;
    private bool m_isLoading;

    public DropGoldEx(int group,Transform parent)
    {
        m_group = group;
        m_parent = parent;
        m_isLoading = false;
        m_parentGameObject = SingletonObject<Avatar>.GetInst().GetPlayerTransform().gameObject;
        m_followTransform = Common.GetBone(m_parentGameObject.transform, "BP_Spine");
	}

	public void Update ()
    {
        if (!m_open || m_dropEmitEx == null)
            return;

        m_dropEmitEx.Update();
	}

    public void Release()
    {
        if (m_dropEmitEx != null)
        {
            m_dropEmitEx.Release();
            m_dropEmitEx = null;
        }
        if (m_goldEmitObject != null)
        {
            m_goldEmitObject.DestroyGameObject(eObjectDestroyType.Memory);
            m_goldEmitObject = null;
        }

        if (m_recordCount != null)
        {
            m_recordCount.Clear();
            m_recordCount = null;
        }
        if (m_recordPosition != null)
        {
            m_recordPosition.Clear();
            m_recordPosition = null;
        }

        m_parentGameObject = null;
        m_followTransform = null;

        m_open = false;
        m_isLoading = false;
    }

    public void CreateGold(uint uiItemID, int num, Vector3 position)
    {
        if (!m_open && m_followTransform != null)
        {
            if (m_recordCount == null)
                m_recordCount = new List<int>();
            m_recordCount.Add(num);

            if (m_recordPosition == null)
                m_recordPosition = new List<Vector3>();
            m_recordPosition.Add(position);

            if (!m_isLoading)
            {
                ItemContent loader = HolderManager.m_ItemHolder.GetStaticInfo(uiItemID);
                if (loader != null)
                {
                    DropObjectContent dropObjectContent = HolderManager.m_DropObjectHolder.GetStaticInfo(loader.ColletID);
                    if (dropObjectContent != null)
                    {
                        m_isLoading = true;
                        m_radius = dropObjectContent.Radius;
                        m_goldEmitObject = new CObject(loader.m_path[0]);
                        m_goldEmitObject.Name = "DropGoldEx";
                        m_goldEmitObject.IsMemoryFactory = true;
                        m_goldEmitObject.Layer = DEFINE.DROPOBJECT_LAYER;
                        m_goldEmitObject.ObjectType = eObjectType.DropObject;
                        m_goldEmitObject.CallBack = LoadCompleted;
                        m_goldEmitObject.LoadObject();
                    }
                }
            }
        }
        else
        {
            int countGroup = num / m_group;
            int numMOD = num % m_group;

            if (countGroup > 0)
                AddGold(position, countGroup, m_group);  //先喷发整数部分
            AddGold(position, 1, numMOD); //再喷发余数部分
        }
    }

    private void AddGold(Vector3 position,int count,int num)
    {
        if (m_dropEmitEx != null)
            m_dropEmitEx.AddGold(position, count, num);
    }

    private void LoadCompleted(GameObject o, params object[] args)
    {
        if (o != null)
        {
            o.transform.parent = m_parent;
            ParticleSystem particleSystem = o.particleSystem;
            if (particleSystem != null && m_followTransform != null)
            {
                UnityCallBackManager.GetInst().AddCallBack(0.01f, DelayAddGold, particleSystem);
            }
            else
            {
                m_goldEmitObject.DestroyGameObject(eObjectDestroyType.Memory);
                m_goldEmitObject = null;
            }
        }
    }

    private void DelayAddGold(params object[] args)
    {
        if (m_dropEmitEx != null)
            m_dropEmitEx.Release();

        //int digitNumber = 1;
        //for (int i = m_goldMultiple / 10; i > 0; i = i / 10)
        //{
        //    digitNumber++;
        //}
        int digitNumber = 2;
        m_dropEmitEx = new DropParticleEmitEx(m_followTransform, (ParticleSystem)args[0], digitNumber, m_radius, 3, 50, 50);
        m_dropEmitEx.AddEvent(onCollectEvent);

        m_open = true;

        if (m_recordCount != null && m_recordPosition != null)
        {
            int recordCount = m_recordCount.Count;
            for (int i = 0, count = m_recordPosition.Count; (i < count && i < recordCount); i++)
            {
                int countGroup = m_recordCount[i] / m_group;
                int numMOD = m_recordCount[i] % m_group;

                if (countGroup > 0)
                    AddGold(m_recordPosition[i], countGroup, m_group);  //先喷发整数部分
                AddGold(m_recordPosition[i], 1, numMOD); //再喷发余数部分
            }
            m_recordCount.Clear();
            m_recordCount = null;
            m_recordPosition.Clear();
            m_recordPosition = null;
        }
    }

    private void onCollectEvent(int count)
    {
        if (m_followTransform != null && m_parentGameObject != null)
        {
            SingletonObject<FlywordMediator>.GetInst().CreateGetGold(m_followTransform.position, (uint)count, FlyWordType.GoldItem);
            CParticleManager.GetInst().CreateBindEffect(DEFINE.AVATAR_PICKUP_GOLD_ID, m_parentGameObject, true);
        }
    }
}
