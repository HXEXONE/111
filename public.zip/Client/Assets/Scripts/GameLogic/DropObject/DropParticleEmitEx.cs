﻿using UnityEngine;
using System.Collections.Generic;

public class DropParticleEmitEx {

    private Dictionary<string,CollectHandler> m_eventList;

    private event CollectHandler CollectEvent;

    private ParticleSystem.Particle[] m_particlesTemplate;
    private ParticleSystem.Particle[] m_particles;
    private ParticleSystem.Particle m_currentParticle;

    private Transform m_followTransform;
    private ParticleSystem m_particleSystem;

    private Vector3 m_folowPosition;
    private Vector3 m_particlePoaition;
    private Vector3 m_velocity;
    private Vector3 m_displacement;
    private Vector3 m_calculateVector;

    private Vector3 m_params;

    private float m_size;
    private float m_startLifeTime;

    private float m_speed;
    private float m_acceleration;
    private float m_accelerationHalf;//加速度的一半，为的是用加速度计算位移时避免用除法

    private float m_gravity;
    private float m_multForce;
    private float m_collectDistanceSqr;
    private float m_collectStartTime;    //开始收集的时间，喷发出来后几秒开始收集
    private float m_collectTimeOut; //喷发出来后多久未收集则步入死亡（不能再收集）
    private float m_collectTime;//用于死亡的延迟，如果收集到则延时生效（防止还没到达就死亡），超时则直接死亡

    private float m_detlaTime;
    private float m_arriveDistanceSqr;

    private float m_lifeTime;
    private uint m_randomSeed;

    private int m_maxParticles;
    private int m_particlesCount;
    private int m_particlesTemplateCount;
    private int m_currentParticlesTemplate;
    private int m_collectCount;

    private bool m_close;

    public DropParticleEmitEx(Transform transform, ParticleSystem particleSystem, int size, float radius, float startTime, float TimeOut, float collectTime)
    {
        m_eventList = new Dictionary<string, CollectHandler>();
        m_close = false;
        m_size = 0.0015f * size;
        m_gravity = m_size * 400;
        m_multForce = m_gravity * 2;
        m_collectCount = 0;

        m_acceleration = 30;

        m_collectDistanceSqr = radius * radius;
        m_accelerationHalf = m_acceleration / 2;

        m_startLifeTime = startTime + TimeOut + collectTime + 5;
        m_collectStartTime = m_startLifeTime - startTime;
        m_collectTimeOut = m_collectStartTime - TimeOut;
        m_collectTime = m_collectTimeOut - collectTime;

        m_followTransform = transform;
        m_particleSystem = particleSystem;

        m_particleSystem.gravityModifier = m_gravity;

        m_maxParticles = m_particleSystem.maxParticles;
        m_particles = new ParticleSystem.Particle[m_maxParticles];

        m_particlesTemplateCount = 50;
        m_currentParticlesTemplate = 0;
        m_particlesTemplate = new ParticleSystem.Particle[m_particlesTemplateCount];

        for (int i = 0; i < m_particlesTemplateCount; i++)
        {
            m_particlesTemplate[i] = new ParticleSystem.Particle();
            m_particlesTemplate[i].velocity = (Random.insideUnitSphere * 2f + Vector3.up * 5f) * m_multForce;
            m_particlesTemplate[i].angularVelocity = 0;  //借用方向偏移  替换意义为当前速度
            m_particlesTemplate[i].size = m_size;
            m_particlesTemplate[i].startLifetime = m_startLifeTime;
            m_particlesTemplate[i].lifetime = m_startLifeTime;
            m_particlesTemplate[i].color = Color.white;
            m_particlesTemplate[i].randomSeed = 1; //借用随机数 1代表刚喷发，2代表收集，3代表超时未收集
        }

        m_params = Vector3.zero;
    }

    public void Update()
    {
        if (m_close)
            return;

        if (m_particleSystem == null || m_followTransform == null)
        {
            Release();
            return;
        }

        if (m_particleSystem.particleCount <= 0)
            return;

        m_particlesCount = m_particleSystem.GetParticles(m_particles);

        m_folowPosition = m_followTransform.position;

        for (int i = 0; i < m_particlesCount; i++)
        {
            m_lifeTime = m_particles[i].lifetime;
            m_randomSeed = m_particles[i].randomSeed;
            if (m_randomSeed == 1)
            {
                if (m_lifeTime < m_collectTimeOut)
                {
                    m_particles[i].lifetime = -1;
                }
                else if (m_lifeTime < m_collectStartTime)
                {
                    if (DistanceSqr(m_folowPosition, m_particles[i].position) <= m_collectDistanceSqr)
                    {
                        m_particles[i].randomSeed = 2;
                        m_particles[i].angularVelocity = 0;
                    }
                }
            }
            else if (m_randomSeed == 2)
            {
                if (m_lifeTime < m_collectTime)
                {
                    m_particles[i].lifetime = -1;
                    m_collectCount += (int)m_particles[i].axisOfRotation.x;
                }
                else
                {
                    m_particlePoaition = m_particles[i].position;
                    m_velocity = (m_folowPosition - m_particlePoaition).normalized;

                    m_speed = m_particles[i].angularVelocity;
                    m_speed += m_acceleration * Time.deltaTime;
                    m_particles[i].angularVelocity = m_speed;

                    m_detlaTime = Time.deltaTime;
                    m_displacement = (m_speed * m_detlaTime + m_accelerationHalf * m_detlaTime * m_detlaTime) * m_velocity;

                    m_particles[i].position += m_displacement;

                    m_arriveDistanceSqr = Mathf.Max(m_displacement.sqrMagnitude, 0.0625f);

                    if (DistanceSqr(m_folowPosition, m_particles[i].position) <= m_arriveDistanceSqr)
                    {
                        m_particles[i].lifetime = -1;
                        m_collectCount += (int)m_particles[i].axisOfRotation.x;
                    }
                }
            }
        }
        m_particleSystem.SetParticles(m_particles, m_particlesCount);

        if (m_collectCount > 0)
        {
            DoEvent(m_collectCount);
            m_collectCount = 0;
        }
    }

    public void AddGold(Vector3 position,int count,int num)
    {
        if (m_close || m_particleSystem == null)
        {
            MyLog.LogError("DropParticleEmit instance is close");
            return;
        }
        for (int i = 0; i < count; i++)
        {
            m_currentParticlesTemplate++;
            if (m_currentParticlesTemplate >= m_particlesTemplateCount)
            {
                m_currentParticlesTemplate = 0;
            }

            m_currentParticle = m_particlesTemplate[m_currentParticlesTemplate];
            m_currentParticle.position = position;
            m_params.x = num;
            m_currentParticle.axisOfRotation = m_params;
            m_particleSystem.Emit(m_currentParticle);
        }
    }

    public void AddEvent(CollectHandler handler)
    {
        if (m_close)
        {
            MyLog.LogError("DropParticleEmit instance is close");
            return;
        }
        string name = handler.Method.Name;
        if (m_eventList.ContainsKey(name))
        {
            CollectEvent -= m_eventList[name];
            m_eventList.Remove(name);
        }
        CollectEvent += handler;
        m_eventList.Add(name, handler);
    }

    public void RemoveEvent(CollectHandler handler)
    {
        if (m_close)
        {
            MyLog.LogError("DropParticleEmit instance is close");
            return;
        }
        string name = handler.Method.Name;
        if (m_eventList.ContainsKey(name) && m_eventList[name] != null)
        {
            CollectEvent -= m_eventList[name];
            m_eventList.Remove(name);
        }
    }

    public void Release()
    {
        m_close = true;
        m_followTransform = null;
        if (m_particleSystem != null)
        {
            m_particleSystem.Clear();
            m_particleSystem = null;
        }

        m_particlesTemplate = null;
        m_particles = null;

        foreach (KeyValuePair<string, CollectHandler> handler in m_eventList)
        {
            if (handler.Value != null)
                CollectEvent -= handler.Value;
        }
        CollectEvent = null;
        m_eventList.Clear();
        m_eventList = null;
    }

    private void DoEvent(int count)
    {
        if (CollectEvent != null)
        {
            CollectEvent(count);
        }
    }

    private float DistanceSqr(Vector3 a, Vector3 b)
    {
        m_calculateVector = a - b;
        return m_calculateVector.x * m_calculateVector.x + m_calculateVector.z * m_calculateVector.z;
    }
}
