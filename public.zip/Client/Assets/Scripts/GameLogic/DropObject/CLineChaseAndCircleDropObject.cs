﻿using UnityEngine;
using System.Collections;

public class CLineChaseAndCircleDropObject : CBaseDropObject
{
    private float m_height;
    private float m_speed;
    private Vector3 m_velocity;

    private Timer m_liveTimer = new Timer();
    private float acceleration = 20;//加速度

    
    public override void Init(int nIndex, uint uiItemID,uint num, Vector3 position,float height)
    {
        base.Init(nIndex, uiItemID, num, position, height);
        m_height = 0;
        m_speed = 0;
        m_velocity = Vector3.zero;

       
    }

    public override void LoadCompleted(GameObject o, params object[] args)
    {
        base.LoadCompleted(o, args);
        if (null == o)
        {
            return;
        }
        //特效类必须先设置为false
        o.SetActive(false);
        o.SetActive(true);
    }

    public override void Update()
    {
        if (null == m_pDropObjectloader)
        {
            return;
        }

        if(m_obj == null || m_obj.gameCObject == null)
        {
            return;
        }

        if (null == m_avatarSpineTrans)
        {
            return;
        }
        switch (m_state)
        {
            case eDropObjectState.Created:
                {
                    m_state = eDropObjectState.Rise;
                    
                }
                break;
            case eDropObjectState.Rise:
                {
                    float deltaHeight = 1.2f * Time.deltaTime;
                    m_height += deltaHeight;
                    m_obj.Position += new Vector3(0, deltaHeight, 0);
                    if (m_height >= 1.5f)
                    {
                        m_state = eDropObjectState.Wait;
                    }
                }
                break;
            case eDropObjectState.Wait:
                {
                    if (Common.Get2DVecter3Length(m_obj.Position, m_avatarSpineTrans.position) <= m_pDropObjectloader.Radius)
                    {
                        m_state = eDropObjectState.CircleFly;
                        m_liveTimer.SetTimer(3);//3秒后直接飞向玩家
                    }
                }
                break;
            case eDropObjectState.CircleFly:
                {
                    float t = Time.deltaTime;
                    m_speed += t * 2;
                    Vector3 targetPosition = m_avatarSpineTrans.position ;

                    m_velocity = Vector3.Lerp(m_velocity, (targetPosition - m_obj.Position).normalized, 0.06f);

                    Vector3 delta = m_velocity * t * 15 * m_speed;
                    m_obj.Position += delta;

                    if (Common.Get2DVecter3Length(m_obj.Position, targetPosition) <= 0.5f)
                    {
                        m_state = eDropObjectState.Dead;
                    }
                    else if (m_liveTimer.IsExpired(false))
                    {
                        m_state = eDropObjectState.LineFly;
                    }
                }
                break;
            case eDropObjectState.LineFly:
                {
                    Vector3 targetPosition = m_avatarSpineTrans.position ;
                    Vector3 direction = (targetPosition - m_obj.Position).normalized;

                    m_speed = m_speed + acceleration * Time.deltaTime;

                    float t = Time.deltaTime;
                    Vector3 delta = (m_speed * t + acceleration * t * t / 2.0f) * direction;

                    m_obj.Position += delta;

                    float max = Mathf.Max(delta.magnitude, 1);

                    if (Common.Get2DVecter3Length(m_obj.Position, targetPosition) <= max)
                    {
                        m_state = eDropObjectState.Dead;
                    }

                }
                break;
            case eDropObjectState.Dead:
                {
                    Dead();
                    m_state = eDropObjectState.None;
                }
                break;
        }
    }
}
