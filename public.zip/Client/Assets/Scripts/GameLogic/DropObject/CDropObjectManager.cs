using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Protocol;

public class CDropObjectManager : SingletonObject<CDropObjectManager>
{
    private Dictionary<int, CBaseDropObject> m_Dict = new Dictionary<int, CBaseDropObject>();
    private List<int> m_deleteList = new List<int>();

    #region ������ӵ����һ��
    //private int m_digitNumber = 4;
    //private DropGold[] m_dropGolds; //0����ǧλ��������1������λ��������2����ʮλ��������3������λ������
    //private int[] m_multipleSort; //0����ǧλ��������1������λ��������2����ʮλ��������3������λ������
    //private int[] m_multiples;
    #endregion

    #region ������ӵ���ڶ���
    private DropGoldEx m_dropGoldEx;
    private int m_groupCount = 300;
    #endregion

    #region 2014��8��1��10:45:51���������޸�
    //����ʤ����ʶ
    private byte m_climbtowerIsSuc = 0;//0��ʾʤ����1��ʾ����

    //����ʤ����ʾ
    private byte m_escortIsSuc = 0;//0��ʾʧ�ܣ�1��ʤ��   

    #endregion

    private int m_nIndex = 0;

    public List<CDropObjectInfo> m_dropItemList = new List<CDropObjectInfo>();

    public void Init()
    {
        ItemContent loader = HolderManager.m_ItemHolder.GetStaticInfo(DEFINE.ITEM_GOLD);
        if (loader != null)
        {
            DropObjectContent dropObjectContent = HolderManager.m_DropObjectHolder.GetStaticInfo(loader.ColletID);
            if (dropObjectContent != null)
            {
                LoadHelp.LoadObject("", loader.m_path[0], ThreadPriority.Normal, null);
            }
        }
    }

    public int GetEmptyIndex()
    {
        m_nIndex++;
        return m_nIndex;
    }

    /// <summary>
    /// ���ؾ���center radius��Χ�������һ�������û�ҵ��򷵻�null
    /// </summary>
    /// <param name="center"></param>
    /// <param name="radius"></param>
    /// <returns></returns>
    public CBaseDropObject PickDropObjectInRange(Vector3 center, float radius)
    {
        if (m_Dict.Count > 0)
        {
            foreach (KeyValuePair<int, CBaseDropObject> pdobj in m_Dict)
            {
                CObject co = pdobj.Value.Obj;
                if (null == co)
                {
                    continue;
                }
                if (null == co.transform)
                {
                    continue;
                }
                if (Common.Get2DVecter3Length(center, co.transform.position) <= radius)
                {
                    if (pdobj.Value.CollectID != DEFINE.ITEM_EXP/* && pdobj.Value.CollectID != DEFINE.ITEM_GOLD*/)
                    {
                        return pdobj.Value;
                    }
                }
            }
        }


        return null;
    }

    public void CreateDropObject(uint uiItemID, uint num, Vector3 position)
    {
        int nIndex = GetEmptyIndex();

        int colletID = 0;

        if (uiItemID / 10000000 == 3)
        {
            EquipContent content = HolderManager.m_EquipHolder.GetStaticInfo(uiItemID);
            if (content != null) colletID = content.ColletID;

            CDropObjectInfo dropInfo = new CDropObjectInfo(uiItemID, num);
            m_dropItemList.Add(dropInfo);
        }
        else if (uiItemID / 10000000 == 4)
        {
            ItemContent content = HolderManager.m_ItemHolder.GetStaticInfo(uiItemID);
            if (content != null) colletID = content.ColletID;

            
            if (content.Sort != (byte)eItemType.SneceItem)
            {
                CDropObjectInfo dropInfo = new CDropObjectInfo(uiItemID, num);

                m_dropItemList.Add(dropInfo);
            }
        }

        DropObjectContent pDropObjectLoader = HolderManager.m_DropObjectHolder.GetStaticInfo(colletID);
        if (null == pDropObjectLoader)
        {
            return;
        }

        switch ((eDropObjectAdsorbMode)pDropObjectLoader.AdsorbMode)
        {
            case eDropObjectAdsorbMode.LineChase:
                {
                    if (uiItemID == DEFINE.ITEM_GOLD)
                    {
                        #region ������ӵ����һ��
                        //CalculateSort((int)num);

                        //if (m_dropGolds == null)
                        //{
                        //    m_dropGolds = new DropGold[m_digitNumber];
                        //}
                        //for (int i = 0; i < m_digitNumber; i++)
                        //{
                        //    if (m_multipleSort[i] == 0)
                        //        continue;
                        //    if (m_dropGolds[i] == null)
                        //    {
                        //        m_dropGolds[i] = new DropGold(m_multiples[i], CBaseDropObject.Parent);
                        //    }
                        //    m_dropGolds[i].CreateGold(uiItemID, m_multipleSort[i], position + Vector3.up * 2);
                        //}
                        #endregion

                        #region ������ӵ���ڶ���
                        if (m_dropGoldEx == null)
                            m_dropGoldEx = new DropGoldEx(m_groupCount, CBaseDropObject.Parent);
                        m_dropGoldEx.CreateGold(uiItemID, (int)num, position + Vector3.up * 2);
                        #endregion
                    }
                    else
                    {
                        CLineChaseDropObject pDropObject = new CLineChaseDropObject();
                        pDropObject.Init(nIndex, uiItemID, num, position, 2);
                        m_Dict.Add(nIndex, pDropObject);
                    }
                }
                break;
            case eDropObjectAdsorbMode.LineChaseAndCircle:
                {
                    CLineChaseAndCircleDropObject pDropObject = new CLineChaseAndCircleDropObject();
                    pDropObject.Init(nIndex, uiItemID, num, position, 1);
                    m_Dict.Add(nIndex, pDropObject);
                }
                break;
        }


    }


    public void AddDeleteList(int nIndex)
    {
        m_deleteList.Add(nIndex);
    }

    public void AddBooty(CDropObjectInfo info)
    {
        BattleGetItemMediiator getItem = SingletonObject<BattleGetItemMediiator>.GetInst();
        getItem.AddItemList(info);
    }

    //�����������������
    public void SendDropListToServer()
    {
        //Ĭ�Ϸ�0��������PVEս������
        SendDropListToServer(0);
    }

    public void SendDropListToServer(int layer)
    {
        CBattleDataVec dropList = new CBattleDataVec();
        CBattleSceneLoading scene = SingletonObject<CBattleSceneLoading>.GetInst();

        switch (scene.battleType)
        {
            case eBattleType.ClimbTower:
                {
                    //����һ���������
                    CBattleData data = new CBattleData();
                    data.uiKey = 1;
                    data.uiValue = (ulong)layer;
                    data.uiValue1 = (uint)ClimbtowerIsSuc;//0��ʾӮ�ˣ�1��ʾ����
                    dropList.Add(data);
                    SingletonObject<CPlayer>.GetInst().OperCurBattle(EnumBattleOper.EnumBattleOper_TowerReport, dropList);
                }
                break;
            case eBattleType.PVE:
                SingletonObject<CPlayer>.GetInst().OperCurBattle(EnumBattleOper.EnumBattleOper_CompleteReport, dropList);
                break;
            case eBattleType.Escort:
            case eBattleType.Protect:
                {
                    //ʤ���ı�ʾ
                    CBattleData dataEscort = new CBattleData();
                    dataEscort.uiKey = 0;
                    dataEscort.uiValue = (uint)EscortIsSuc;       //0ʧ�ܣ�1ʤ��
                    dataEscort.uiValue1 = 0;
                    dropList.Add(dataEscort);
                    //if (scene.battleType == eBattleType.Escort)
                    //{
                    //    SingletonObject<CPlayer>.GetInst().OperCurBattle(EnumBattleOper.EnumBattleOper_Escort, DropList);
                    //}
                    //else if (scene.battleType == eBattleType.Protect)
                    //{
                        SingletonObject<CPlayer>.GetInst().OperCurBattle(EnumBattleOper.EnumBattleOper_Escort, dropList);
                    //}
                    
                }
                break;
        }
    }

    public CObject GetRadiusDrop(Vector3 srcPosition, float radius)
    {
        if (m_Dict.Count > 0)
        {
            CObject obj;
            foreach (KeyValuePair<int, CBaseDropObject> kvp in m_Dict)
            {
                if (kvp.Value.GetType().ToString().Equals("CLineChaseAndCircleDropObject"))
                {
                    continue;
                }
                obj = kvp.Value.Obj;
                if (obj != null && obj.transform != null && Common.Get2DVecter3Length(obj.transform.position, srcPosition) <= radius)
                {
                    return obj;
                }
            }
        }

        return null;
    }

    //public void SendDropListToServer()
    //{
    //    int condusionType;
    //    int itemValue1;
    //    int itemValue2;
    //    int numValue1;
    //    int numValue2;

    //    for (int i = 0, count = m_bootyList.Count; i < count; ++i)
    //    {
    //        condusionType = Random.Range(1, 4);
    //        itemValue1 = 0;
    //        itemValue2 = 0;

    //        ItemBaseContent pItemLoader = m_bootyList[i].m_pItemBaseLoader;
    //        int num = m_bootyList[i].m_nNum;

    //        int range = Random.Range(0, (int)pItemLoader.GetKey());
    //        int range2 = Random.Range(0, num);

    //        switch ((EnumDropObjectConfusion)condusionType)
    //        {
    //            case EnumDropObjectConfusion.EnumDropObjectConfusion_Add:
    //                {
    //                    itemValue1 = (int)(pItemLoader.GetKey() - range);
    //                    itemValue2 = range;

    //                    numValue1 = num - range2;
    //                    numValue2 = range2;
    //                }
    //                break;
    //            case EnumDropObjectConfusion.EnumDropObjectConfusion_Minus:
    //                {
    //                    itemValue1 = (int)(pItemLoader.GetKey() + range);
    //                    itemValue2 = range;

    //                    numValue1 = num + range2;
    //                    numValue2 = range2;
    //                }
    //                break;
    //            case EnumDropObjectConfusion.EnumDropObjectConfusion_ExclusiveOr:
    //                {
    //                    itemValue1 = (int)(pItemLoader.GetKey() ^ range);
    //                    itemValue2 = range;

    //                    numValue1 = num ^ range2;
    //                    numValue2 = range2;
    //                }
    //                break;
    //        }
    //    }
    //}

    public void Update()
    {
        int count = m_deleteList.Count;
        for (int i = 0; i < count; i++)
        {
            int index = m_deleteList[i];
            if (m_Dict.ContainsKey(index))
            {
                m_Dict[index].Release(eObjectDestroyType.Memory);
                m_Dict.Remove(index);
            }
        }

        if (count > 0)
        {
            m_deleteList.Clear();
        }

        if (m_Dict.Count > 0)
        {
            foreach (KeyValuePair<int, CBaseDropObject> kvp in m_Dict)
            {
                kvp.Value.Update();
            }
        }

        #region ������ӵ����һ��
        //if (m_dropGolds != null)
        //{
        //    for (int i = 0; i < m_digitNumber; i++)
        //    {
        //        if (m_dropGolds[i] != null)
        //            m_dropGolds[i].Update();
        //    }
        //}
        #endregion

        #region ������ӵ���ڶ���
        if (m_dropGoldEx != null)
            m_dropGoldEx.Update();
        #endregion
    }

    public void Release()
    {
        if (m_Dict.Count > 0)
        {
            foreach (KeyValuePair<int, CBaseDropObject> kvp in m_Dict)
            {
                kvp.Value.Release(eObjectDestroyType.Memory);
            }
        }

        m_Dict.Clear();
        m_dropItemList.Clear();

        m_nIndex = 0;

        #region ������ӵ����һ��
        //if (m_dropGolds != null)
        //{
        //    for (int i = 0; i < m_digitNumber; i++)
        //    {
        //        if (m_dropGolds[i] != null)
        //        {
        //            m_dropGolds[i].Release();
        //            m_dropGolds[i] = null;
        //        }
        //    }
        //}
        #endregion

        #region ������ӵ���ڶ���
        if (m_dropGoldEx != null)
        {
            m_dropGoldEx.Release();
            m_dropGoldEx = null;
        }
        #endregion
    }

    //����ս��Ʒ
    //public List<CDropObjectInfo> TowerDropObjectInfos
    //{
    //    get
    //    {
    //        return m_climbtowerDropList;
    //    }
    //    set
    //    {
    //        m_climbtowerDropList = value;
    //    }
    //}

    //public Dictionary<uint, CDropObjectInfo> TowerDropObjectInfoDic
    //{
    //    get
    //    {
    //        return m_climbTowerDropDic;
    //    }
    //}

    /// <summary>
    /// ����ʤ����ʶ
    /// </summary>
    public byte ClimbtowerIsSuc
    {
        get
        {
            return m_climbtowerIsSuc;
        }
        set
        {
            m_climbtowerIsSuc = value;
        }
    }

    public byte EscortIsSuc
    {
        get
        {
            return m_escortIsSuc;
        }
        set
        {
            m_escortIsSuc = value;
        }
 
    }

    #region ������ӵ����һ��
    //private void CalculateSort(int number)
    //{
    //    if (m_multipleSort == null)
    //        m_multipleSort = new int[m_digitNumber];
    //    if (m_multiples == null)
    //    {
    //        m_multiples = new int[m_digitNumber];
    //        int mult = 1;
    //        for (int i = m_digitNumber - 1; i >= 0 ; i--)
    //        {
    //            m_multiples[i] = mult;
    //            mult *= 10;
    //        }
    //    }
    //    for (int i = 0; i < m_digitNumber; i++)
    //    {
    //        m_multipleSort[i] = number / m_multiples[i];
    //        number = number % m_multiples[i];
    //    }
    //}
    #endregion

}
