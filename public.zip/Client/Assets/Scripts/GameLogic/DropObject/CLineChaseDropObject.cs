﻿using UnityEngine;
using System.Collections;

public class CLineChaseDropObject : CBaseDropObject
{
    protected float m_speed;

    private float acceleration = 30;//加速度
    private float initspeed = 10;//初速度

    private Vector3 m_npcPosition;

    private float m_gravity = 20;
    private float m_velocityHorizontal;//水平速度
    private float m_velocityVerical;//垂直速度
    private float m_origionVericalSpeed;//初始垂直速度

    private Vector3 m_direction;//方向

    private Timer m_riseTimer = new Timer();


    private Rigidbody m_rigidbody;

    public override void Init(int nIndex, uint uiItemID,uint num, Vector3 position,float height)
    {
        base.Init(nIndex, uiItemID, num, position, height);

        m_speed = initspeed;

        m_npcPosition = position;

    }

    public override void LoadCompleted(GameObject o, params object[] args)
    {
        base.LoadCompleted(o, args);
        if (null == o)
        {
            return;
        }
        m_rigidbody = o.GetComponent<Rigidbody>();
        if (m_rigidbody != null)
        {
            m_rigidbody.useGravity = true;
        }

        o.SetActive(true);
    }

    public override void Update()
    {
        if (null == m_pDropObjectloader)
        {
            return;
        }
        if (null == m_avatarSpineTrans)
        {
            return;
        }
        switch (m_state)
        {
            case eDropObjectState.Created:
                {
                    m_state = eDropObjectState.Rise;

                    if (null != m_obj && null != m_obj.transform)
                    {
                        m_obj.transform.rotation = Quaternion.Euler(Random.Range(0, 360), Random.Range(0, 360), Random.Range(0, 360));

                        Rigidbody rb = m_obj.gameCObject.GetComponent<Rigidbody>();
                        rb.AddForce(new Vector3(Random.Range(-1, 1), 5, Random.Range(-1, 1)) * 100);
                    }
                    

                    m_riseTimer.SetTimer(Random.Range(1.5f, 2.5f));

                }
                break;
            case eDropObjectState.Rise:
                {
                    if (m_riseTimer.IsExpired(false))
                    {
                        if (m_rigidbody != null)
                        {
                            m_rigidbody.useGravity = false;
                        }
                        m_state = eDropObjectState.Wait;
                    }
                    
                }
                break;
            case eDropObjectState.Wait:
                {
                    if (null == m_obj || null == m_obj.GetObj())
                    {
                        m_state = eDropObjectState.LineFly;
                    }
                    else if (Common.Get2DVecter3Length(m_obj.Position, m_avatarSpineTrans.position) <= m_pDropObjectloader.Radius)
                    {
                        m_state = eDropObjectState.LineFly;
                    }
                }
                break;
            case eDropObjectState.LineFly:
                {
                    if (null == m_obj || null == m_obj.GetObj())
                    {
                        m_state = eDropObjectState.Dead;
                    }
                    else
                    {
                        Vector3 targetPosition = m_avatarSpineTrans.position;
                        Vector3 direction = (targetPosition - m_obj.Position).normalized;

                        m_speed = m_speed + acceleration * Time.deltaTime;

                        float t = Time.deltaTime;
                        Vector3 delta = (m_speed * t + acceleration * t * t / 2.0f) * direction;

                        m_obj.Position += delta;

                        float max = Mathf.Max(delta.magnitude, 0.25f);

                        if (Common.Get2DVecter3Length(m_obj.Position, targetPosition) <= max)
                        {
                            m_state = eDropObjectState.Dead;
                        }
                    }
                }
                break;
            case eDropObjectState.Dead:
                {
                    Dead();
                    m_state = eDropObjectState.None;
                }
                break;
        }
    }
}
