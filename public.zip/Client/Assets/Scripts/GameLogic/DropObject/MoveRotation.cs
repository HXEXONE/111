﻿//using UnityEngine;
//using System.Collections;

//public class MoveRotation : MonoBehaviour
//{
//    public Transform target;
//    public float targetSpeed;
//    public float targetRadius;

//    public Vector3 axis;

//    private float radius;
//    private float speed = 0;

//    private float radian;
//    private float x;
//    private float y;
//    private float z;

//    private Quaternion worldToAxisQuater;
//    private float rotatMax;
//    public float timeToAxis;

//    void Awake()
//    {
//        if (axis != Vector3.zero)
//        {
//            Vector3 pointToTarget = transform.position - target.position;

//            pointToTarget.Normalize();
//            radian = Mathf.Acos(Vector3.Dot(target.TransformDirection(Vector3.right), pointToTarget));
//            if (pointToTarget.z < 0)
//                radian = 2 * Mathf.PI - radian;

//            y = target.InverseTransformPoint(transform.position).y;

//            axis.Normalize();
//            worldToAxisQuater = Quaternion.FromToRotation(Vector3.up,axis);

//            float angle = Quaternion.Angle(target.rotation, worldToAxisQuater);
//            rotatMax = angle / timeToAxis;
//        }
//    }

//    void Update()
//    {
//        if (axis != Vector3.zero)
//        {
//            radius = Vector3.Distance(transform.position, target.position);

//            if (targetRadius != radius)
//            {
//                radius = Mathf.Lerp(radius, targetRadius, 0.05f);
//            }

//            if (targetSpeed != speed)
//            {
//                speed = Mathf.Lerp(speed, targetSpeed, 0.02f);
//            }

//            radian += speed * Time.deltaTime;

//            if (radian > Mathf.PI * 2)
//                radian = radian - Mathf.PI * 2;

//            x = Mathf.Cos(radian) * radius;
//            z = Mathf.Sin(radian) * radius;
//            y = Mathf.Lerp(y, 0, Time.deltaTime);
//            Vector3 newPos = new Vector3(x, y, z);
//            newPos = target.TransformPoint(newPos);
//            transform.position = newPos;

//            if (target.rotation != worldToAxisQuater)
//                target.rotation = Quaternion.RotateTowards(target.rotation, worldToAxisQuater, rotatMax * Time.deltaTime);

//        }
//    }
//}
