﻿using UnityEngine;
using System.Collections;

public class CDropObjectInfo
{
    public uint m_uiItemID;//物品表还是装备表的ID
    public uint m_nNum;

    public CDropObjectInfo(uint uiItemID,uint num)
    {
        m_uiItemID = uiItemID;
        m_nNum = num;
    }
}

public class CBaseDropObject
{
    protected CObject m_obj;
    public CObject Obj
    {
        get { return m_obj; }
    }
    protected DropObjectContent m_pDropObjectloader;


    protected Transform m_avatarSpineTrans;

    public uint CollectID
    {
        get
        {
            return m_DropObjectInfo.m_uiItemID;
        }
    }

    protected int m_nIndex;//动态ID
    protected eDropObjectState m_state;
    public eDropObjectState State
    {
        get { return m_state; }
    }
    protected CDropObjectInfo m_DropObjectInfo;

    private static GameObject m_parent;
    public static Transform Parent { 
        get {
            if (m_parent == null)
                m_parent = new GameObject("DropObjects");
            return m_parent.transform;
         } 
    }


    public virtual void Init(int nIndex,uint uiItemID,uint num, Vector3 position,float height)
    {
        m_nIndex = nIndex;
        m_DropObjectInfo = new CDropObjectInfo(uiItemID, num);

        m_state = eDropObjectState.None;

        System.Collections.Generic.List<string> path = null;
        if (uiItemID / 10000000 == 3)
        {
            EquipContent loader = HolderManager.m_EquipHolder.GetStaticInfo(uiItemID);
            if (loader != null)
            {
                m_pDropObjectloader = HolderManager.m_DropObjectHolder.GetStaticInfo(loader.ColletID);
                path = loader.ModelLoader.ModelPath;
            }
        }
        else if (uiItemID / 10000000 == 4)
        {
            ItemContent loader = HolderManager.m_ItemHolder.GetStaticInfo(uiItemID);
            if (loader != null)
            {
                m_pDropObjectloader = HolderManager.m_DropObjectHolder.GetStaticInfo(loader.ColletID);
                path = loader.m_path;
            }
        }

        if (m_pDropObjectloader == null)
        {
            return;
        }
        m_obj = new CObject(path[0]);
        m_obj.BornPosition = Common.NavSamplePosition(position) + Vector3.up * height;
        m_obj.Name = nIndex.ToString();
        m_obj.IsMemoryFactory = true;
        m_obj.Layer = DEFINE.DROPOBJECT_LAYER;
        m_obj.ObjectType = eObjectType.DropObject;
        m_obj.CallBack = LoadCompleted;
        m_obj.LoadObject();

        Avatar pAvatar = SingletonObject<Avatar>.GetInst();
        m_avatarSpineTrans = Common.GetBone(pAvatar.GetPlayerTransform(), "BP_Spine");
    }

    public virtual void LoadCompleted(GameObject o, params object[] args)
    {
        m_state = eDropObjectState.Created;

        //if (null == m_parent)
        //{
        //    m_parent = new GameObject("DropObjects");
        //}
        if (null == o) { MyLog.LogError(""); return; }
        DynamicShader.ReplaceUnSupportShader(o);

        o.transform.parent = Parent;


    }

    public virtual void Update()
    {
        
    }

    protected void Dead()
    {
        uint uiScriptID = (uint)m_pDropObjectloader.DeadScript;
        ScriptManager.RequestScript(uiScriptID, SingletonObject<Avatar>.GetInst());
        CDropObjectManager.GetInst().AddDeleteList(m_nIndex);

        if (uiScriptID == 0)
        {
            CDropObjectManager.GetInst().AddBooty(m_DropObjectInfo);
        }

        IsGold();
    }

    private void IsGold()
    {
        if (null == m_DropObjectInfo)
        {
            return ;
        }
        ItemContent loader = HolderManager.m_ItemHolder.GetStaticInfo(m_DropObjectInfo.m_uiItemID);
        if (null == loader)
        {
            return ;
        }
        if (loader.Key == DEFINE.ITEM_GOLD && null != m_obj && null != m_obj.GetObj())
        {
            SingletonObject<FlywordMediator>.GetInst().CreateGetGold(m_obj.transform.position, m_DropObjectInfo.m_nNum, FlyWordType.GoldItem);
            CParticleManager.GetInst().CreateBindEffect(DEFINE.AVATAR_PICKUP_GOLD_ID, SingletonObject<Avatar>.GetInst().GetPlayerTransform().gameObject, true);
        }

        

    }

    public void Release(eObjectDestroyType type)
    {
        if (m_obj != null)
        {
            m_obj.DestroyGameObject(type);
            m_obj = null;
        }
    }
}

