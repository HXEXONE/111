﻿using UnityEngine;
using System.Collections;


public class EffectBase : EffectGrapgics
{
    private static RenderTexture m_currentRenderer;
    private static Material m_blendMaterial;

    public RenderTexture m_sceneRenderTexture;

    public RenderTexture m_destination;
    public RenderTexture m_source;

    //private Texture2D m_source2D;
    //private Texture2D m_destination2D;

    private float m_renderTextureSize = 0.01f;
    public float RenderTextureSize
    {
        get { return m_renderTextureSize; }
        set { 
            m_renderTextureSize = value;
            //if (this is FastBlur)
            //    OnTextureSizeChange(false, ref m_quad, ref m_materialQuad, "FastBlurQuad");
            //else
            //    OnTextureSizeChange(false, ref m_quad1, ref m_materialQuad1, "OtherBlurQuad");
        }
    }

    public bool _useRenderCamera;
    public float _renderCameraDepth;

    private static Texture2D m_textureFisheye;
    private CObject m_fisheyeObject;

    private static GameObject m_quad = null;
    private static GameObject m_quad1 = null;
    private static Material m_materialQuad1;
    private static Material m_materialQuad;
    private Camera m_camera;

    private bool m_render = false;

    public int m_layer = DEFINE.NGUI3D_LAYER;

    private Camera m_sceneCamera;
    public Camera SceneCamera
    {
        get { return m_sceneCamera; }
        set { m_sceneCamera = value; }
    }

    private CameraClearFlags m_clearFlags;

    private Camera m_renderCamera;

    private OtherCameraEffect m_otherCameraEffect;

    private bool m_isActice;

    private Color m_color = Color.white;

    private float m_alpha = 1;
    private float m_speed = 0;
    private float m_time = 0.25f;
    private int m_startAlpha = 0;  //0为刚创建 1为可以开始渐变 2为渐变完成;
    private bool m_rendererTextureDispose = true;

    private bool m_addAlpha = true;
    private bool m_dispose = false;
    private bool m_lateUpdateFinsh = false;

    void OnEnable()
    {
        if (this is DepthOfField)
            CheckResources(true);
        else
            CheckResources(false);

        //if (!m_render)
        //    OnTextureSizeChange();
    }

    void OnDisable()
    {
        if (m_source != null)
        {
            if (m_camera != null)
            {
                m_camera.clearFlags = m_clearFlags;
                m_camera.targetTexture = null;
            }

            m_source.Release();
            Object.Destroy(m_source);
            //m_source = null;
            m_rendererTextureDispose = true;
        }
        Clear(); 
    }

    //void OnDestroy()
    //{
    //    Release();
    //}

    void LateUpdate()
    {
        if (m_sceneCamera == null && m_camera != null)
            return;

        if (m_render)
        {
            m_isActice = m_sceneCamera.transform.root.gameObject.activeSelf;
            if (!m_isActice)
            {
                m_sceneCamera.transform.root.gameObject.SetActive(true);
            }
            m_lateUpdateFinsh = true;
        }

        if (m_startAlpha != 1)
        {
            if (m_dispose)
            {
                if (m_startAlpha == 2)
                    Object.Destroy(this);
                else
                    CallRelease();
            }
            return;
        }

        if ((m_addAlpha && m_alpha == 1) || m_speed <= 0)
        {
            //this.enabled = false;
            return;
        }
        if ((!m_addAlpha && m_alpha == 0) || m_speed <= 0)
        {
            //this.enabled = false;
            return;
        }
        UpdateMaterialAlpha(m_addAlpha);
    }

    void OnPreCull()
    {
        if (m_lateUpdateFinsh && m_camera != null && m_render)
        {
            m_camera.clearFlags = CameraClearFlags.SolidColor;
            m_camera.targetTexture = m_source;
        }
    }

    void OnPostRender()
    {
        if (!m_lateUpdateFinsh || !m_render)
            return;

        if (m_otherCameraEffect != null)
        {
            m_sceneRenderTexture = m_otherCameraEffect.TargetTexture;
        }
        else
        {
            m_sceneRenderTexture = ImageEffectManager.GetInst().GetEffectTexture(eImageEffect.FogOfWar);
        }

        RenderImage(m_source, m_destination, ref m_sceneRenderTexture);

        if (_useRenderCamera)
        {
            m_renderCamera.enabled = true;
        }
        m_render = false;
        
        if (m_camera != null)
        {
            m_camera.clearFlags = m_clearFlags;
            m_camera.targetTexture = null;
        }

        DestoryOtherCameraEffect();
//#if !UNITY_EDITOR
        //RenderTexture temp = BlendShadow(m_destination);
        //if (temp != null)
        //{
        //    Graphics.Blit(temp, (RenderTexture)null);
        //    RenderTexture.ReleaseTemporary(temp);
        //}
        //else
        //bool useCurrenrRender;
        if (m_currentRenderer != null)
        {
            if (m_blendMaterial == null)
            {
                Shader s = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_EFFECT_BLUR);
                m_blendMaterial = new Material(s);
            }
            m_blendMaterial.SetTexture("_Scene", m_currentRenderer);
            RenderTexture temp = RenderTexture.GetTemporary(m_source.width, m_source.height);
            Graphics.Blit(m_source, temp, m_blendMaterial, 4);

            Graphics.Blit(temp, (RenderTexture)null);
            Graphics.Blit(temp, m_currentRenderer);
            RenderTexture.ReleaseTemporary(temp);

            //useCurrenrRender = true;
        }
        else
        {
            Graphics.Blit(m_sceneRenderTexture, (RenderTexture)null);
            //useCurrenrRender = false;
        }
//#endif

        UpdateMaterialAlpha(true,0);

        if (this is FastBlur)
        {
            //if (useCurrenrRender)
            //    ShowQuad(m_quad, m_currentRenderer);
            //else
                ShowQuad(m_quad, m_sceneRenderTexture);
        }
        else
        {
            //if (useCurrenrRender)
            //    ShowQuad(m_quad1, m_currentRenderer);
            //else
                ShowQuad(m_quad1, m_sceneRenderTexture);
        }

        ImageEffectManager.GetInst().UseFogOfWarDestin(false);

        if (!m_isActice)
        {
            m_sceneCamera.transform.root.gameObject.SetActive(false);
        }
        ImageEffectManager.GetInst().AddCallback(Callback);
        m_startAlpha = 1;
        m_addAlpha = true;
    }

    //void OnRenderImage(RenderTexture source, RenderTexture destination)
    //{
    //    if (!m_render)
    //        return;
    //    RenderImage(source, m_destination);
    //    RenderTextureToTexture2D(m_destination,m_destination2D);
    //    m_quad.renderer.material.mainTexture = m_destination2D;
    //    m_render = false;
    //    //m_camera.enabled = m_render;
    //    m_quad.layer = m_layer;
    //    this.enabled = false;
    //}

    void OnTextureSizeChange(bool refresh,ref GameObject q,ref Material material,string name)
    {
        //Release();
        bool isUseCameraRendererTexture = false;
        if (!refresh)
        {
            if (m_sceneCamera == null)
            {
                m_sceneCamera = SingletonObject<HomeScene>.GetInst().UISceneCamera();
                if (m_sceneCamera == null || !m_sceneCamera.transform.gameObject.activeInHierarchy)
                {
                    m_sceneCamera = CCamera.GetInst().GetCamera();
                    isUseCameraRendererTexture = true;
                }
            }
            else
            {
                isUseCameraRendererTexture = true;
            }
        }
        if (m_sceneCamera != null)
        {
            if (!(ImageEffectManager.GetInst().IsEffectActive(eImageEffect.FogOfWar) && isUseCameraRendererTexture))
            {
                m_otherCameraEffect = m_sceneCamera.gameObject.AddComponent<OtherCameraEffect>();
                m_otherCameraEffect.RenderFrame = 1;
            }
        }

        m_camera = camera;
        m_clearFlags = m_camera.clearFlags;
        int sw = (int)m_camera.pixelWidth;
        int sh = (int)m_camera.pixelHeight;
        int w = (int)(m_camera.pixelWidth * m_renderTextureSize);
        int h = (int)(m_camera.pixelHeight * m_renderTextureSize);

        m_source = new RenderTexture(sw, sh, 16, RenderTextureFormat.ARGB32);
        m_source.filterMode = FilterMode.Bilinear;
        m_source.generateMips = true;
        m_source.isCubemap = false;
        m_source.isPowerOfTwo = false;
        m_source.wrapMode = TextureWrapMode.Clamp;
        m_rendererTextureDispose = false;

        m_destination = new RenderTexture(w, h, 0, RenderTextureFormat.Default);
        m_destination.filterMode = FilterMode.Bilinear;
        m_destination.generateMips = true;
        m_destination.isCubemap = false;
        m_destination.isPowerOfTwo = false;
        m_destination.wrapMode = TextureWrapMode.Clamp;

        //m_destination2D = new Texture2D(w, h);

        if (q == null)
        {
            q = GameObject.CreatePrimitive(PrimitiveType.Quad);
            q.name = name;
            Collider coll = q.GetComponent<Collider>();
            if (coll != null)
            {
                DestroyImmediate(coll);
            }
            if (material == null)
            {
                Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_FULL_SCREEN_TWO);
                material = new Material(shader);
                //material.renderQueue = 3200;
                material.color = Color.white;
                if(m_textureFisheye != null)
                    material.SetTexture("_Fisheye", m_textureFisheye);
            }
            q.renderer.material = material;
            material = q.renderer.material;
            q.layer = 0;
            q.SetActive(false);
        }
        else
        {
            material.renderQueue = 3500;
            material.color = Color.white;
        }
        if (m_textureFisheye == null)
            LoadFisheyeTexture(q);

        if (m_camera.isOrthoGraphic)
        {
            if (m_camera.aspect > 1)
            {
                AnchorCamera anchorCamera = m_camera.GetComponent<AnchorCamera>();
                if (anchorCamera != null)
                    q.transform.localScale = anchorCamera.GetFullScreenScale();
                else
                    q.transform.localScale = Vector3.one * m_camera.orthographicSize * m_camera.aspect * 2 + Vector3.one;
            }
            else
            {
                q.transform.localScale = Vector3.one * m_camera.orthographicSize * 2 + Vector3.one;
            }
        }
        else
        {
            if (m_camera.aspect > 1)
                q.transform.localScale = Vector3.one * 3 * m_camera.aspect;
            else
                q.transform.localScale = Vector3.one * 3;
        }

        if (_useRenderCamera)
        {
            if (m_renderCamera == null)
            {
                GameObject renderCamera = new GameObject("RenderCameraEffect");
                m_renderCamera = renderCamera.AddComponent<Camera>();
            }
            m_renderCamera.enabled = false;
            m_renderCamera.CopyFrom(m_camera);
            m_renderCamera.transform.Rotate(m_renderCamera.transform.up, 180);
            m_renderCamera.clearFlags = CameraClearFlags.Skybox;
            m_renderCamera.cullingMask = 1 << m_layer;
            m_renderCamera.depth = _renderCameraDepth;
            q.transform.parent = m_renderCamera.transform;
        }
        else
            q.transform.parent = transform.parent;
        q.transform.localPosition = Vector3.zero;
        if(_useRenderCamera)
            q.transform.position += m_renderCamera.transform.forward * (1 + m_camera.nearClipPlane);
        else
            q.transform.position += m_camera.transform.forward * (1 + m_camera.nearClipPlane);
        q.transform.localRotation = Quaternion.identity;

        m_speed = 1 / m_time;

        CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW, null);

        m_render = true;
    }

    protected virtual void RenderImage(RenderTexture source, RenderTexture destination,ref RenderTexture sceneRender)
    {

    }

    public void Open(float size,Camera sceneCamera = null)
    {
        m_sceneCamera = sceneCamera;
        m_renderTextureSize = size;
        if (this is FastBlur)
            OnTextureSizeChange(false, ref m_quad, ref m_materialQuad, "FastBlurQuad");
        else
            OnTextureSizeChange(false, ref m_quad1, ref m_materialQuad1, "OtherBlurQuad");
    }

    public override void Release(bool needTexture = false)
    {
        if (!needTexture)
        {
            if (m_currentRenderer != null)
            {
                RenderTexture.ReleaseTemporary(m_currentRenderer);
                m_currentRenderer = null;
            }
        }
        //else
        //{
        //    if (m_currentRenderer != null)
        //        RenderTexture.ReleaseTemporary(m_currentRenderer);
        //    m_currentRenderer = RenderTexture.GetTemporary(m_destination.width, m_destination.height);
        //    Graphics.Blit(m_destination, m_currentRenderer);
        //}

        if (m_destination)
        {
            m_destination.Release();
            Object.DestroyImmediate(m_destination);
            m_destination = null;
        }

        if (m_camera != null)
        {
            m_camera.clearFlags = m_clearFlags;
            m_camera.targetTexture = null;
        }

        if (!m_rendererTextureDispose && m_source)
        {
            m_source.Release();
            Object.DestroyImmediate(m_source);
            m_source = null;
            m_rendererTextureDispose = true;
        }

        //if (m_materialQuad)
        //{
        //    DestroyImmediate(m_materialQuad);
        //}
        if (this is FastBlur)
        {
            HideQuad(m_quad);
        }
        else
        {
            HideQuad(m_quad1);
        }

        //if (m_destination2D != null)
        //    Object.Destroy(m_destination2D);

        DestoryOtherCameraEffect();

        if (m_sceneRenderTexture != null)
        {
            if (!ImageEffectManager.GetInst().IsEffectActive(eImageEffect.FogOfWar))
            {
                m_sceneRenderTexture.Release();
                Object.DestroyImmediate(m_sceneRenderTexture);
                m_sceneRenderTexture = null;
            }
        }

        if (m_renderCamera)
            Object.Destroy(m_renderCamera.gameObject);
        Clear();

        m_startAlpha = 2;

        SingletonObject<CPlayer>.GetInst().InitFollowCamera(eCAMERAFOLLOW.SMOOTH, false);
    }

    public override void Close()
    {
        m_dispose = true;
        m_addAlpha = false;
        //if(this is FastBlur)
        //    m_quad.renderer.material.SetTexture("_SceneTex", m_sceneRenderTexture);
        //else
        //    m_quad1.renderer.material.SetTexture("_SceneTex", m_sceneRenderTexture);
    }

    protected virtual void Clear()
    { 
    }

    public override void Refresh()
    {
        this.enabled = true;
        if (this is FastBlur)
            OnTextureSizeChange(true, ref m_quad, ref m_materialQuad, "FastBlurQuad");
        else
            OnTextureSizeChange(true, ref m_quad1, ref m_materialQuad1, "OtherBlurQuad");
    }

    public void SetColor(Color color)
    {
        m_color = color;
        if (this is FastBlur)
        {
            if (m_materialQuad)
                m_materialQuad.SetColor("_Color", m_color);
        }
        else
        {
            if (m_materialQuad1)
                m_materialQuad1.SetColor("_Color", m_color);
        }
    }

    private void DestoryOtherCameraEffect()
    {
        if (m_otherCameraEffect != null)
        {
            m_otherCameraEffect.camera.targetTexture = null;
            Object.DestroyImmediate(m_otherCameraEffect);
        }
    }

    private void LoadFisheyeTexture(GameObject q)
    {
        m_fisheyeObject = new CObject(DEFINE.ASSETBUNDLE_PATH_CAMERA_EFFECT_SHELTER);
        m_fisheyeObject.IsMemoryFactory = true;
        m_fisheyeObject.ObjectType = eObjectType.Particle;
        m_fisheyeObject.CallBack = LoadComplete;
        m_fisheyeObject.Args = new object[] { q };
        m_fisheyeObject.LoadObject();
    }

    private void LoadComplete(GameObject o, params object[] args)
    {
        if (o == null)
        {
            MyLog.DebugLogException("EffectBase LoadComplete failure");
            return;
        }

        if (args == null)
        {
            MyLog.DebugLogException("EffectBase LoadComplete args == null");
            return;
        }

        GameObject q = args[0] as GameObject; 

        m_textureFisheye = o.renderer.sharedMaterial.mainTexture as Texture2D;
        o.SetActive(false);
        m_fisheyeObject.DestroyGameObject(eObjectDestroyType.Memory);
        if (q != null)
        {
            if (m_materialQuad != null)
                m_materialQuad.SetTexture("_Fisheye", m_textureFisheye);

            if (m_materialQuad1 != null)
                m_materialQuad1.SetTexture("_Fisheye", m_textureFisheye);

            if (m_blendMaterial == null)
            {
                Shader s = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_EFFECT_BLUR);
                m_blendMaterial = new Material(s);
            }
            m_blendMaterial.SetTexture("_Eye", m_textureFisheye);
        }
    }

    private void HideQuad(GameObject q)
    {
        if (q)
        {
            q.renderer.material.mainTexture = null;
            q.transform.parent = null;
            q.SetActive(false);
        }
    }

    private void ShowQuad(GameObject q,RenderTexture sceneRender)
    {
        q.renderer.material.mainTexture = m_destination;
        q.renderer.material.SetTexture("_SceneTex", sceneRender);
        q.layer = m_layer;
        q.SetActive(true);
    }

    private RenderTexture BlendShadow(RenderTexture source,Material material)
    {
        if (material != null)
        {
            Material mat = new Material(material);
            mat.CopyPropertiesFromMaterial(material);
            RenderTexture temp = RenderTexture.GetTemporary(source.width, source.height);
            mat.SetFloat("_oppose", -1f);
            Graphics.Blit(source, temp, mat);
            Object.Destroy(mat);
            return temp;
        }
        else
            return null;
    }

    private void SetMaterialAlpha(Material material)
    {
        if (material != null)
            material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
    }

    private void UpdateMaterialAlpha(bool add,float alpha = -1)
    {
        if (alpha >= 0)
            m_alpha = alpha;
        else
        {
            if (add)
                m_alpha += m_speed * (Time.deltaTime / Common.TimeScale);
            else
                m_alpha -= m_speed * (Time.deltaTime / Common.TimeScale);
        }
        m_alpha = Mathf.Clamp01(m_alpha);

        if (this is FastBlur)
            SetMaterialAlpha(m_materialQuad);
        else
            SetMaterialAlpha(m_materialQuad1);

        if (m_dispose && m_alpha == 0)
        {
            CallRelease();
        }
    }

    private void CallRelease()
    {
        ImageEffectManager.GetInst().Release(m_type, m_camera, LoackObject);
    }
}
