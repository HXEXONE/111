﻿using UnityEngine;
using System.Collections.Generic;

public delegate void ImageEffectCallback(params object[] args);

public struct sImageEffectCallbackStruct
{
    public ImageEffectCallback _callBack;
    public object[] _args;

    public sImageEffectCallbackStruct(ImageEffectCallback callBack,object[] args)
    {
        _callBack = callBack;
        _args = args;
    }
}

public abstract class ImageEffectParam
{
    protected eImageEffect _type;
    public eImageEffect Type{get { return _type; }}

    public bool _newCameraRender = false;
    
    public Camera _camera;

    public float _depth = 0;

    public sImageEffectCallbackStruct Callback;
}

public class ImageEffectParamFastBlur : ImageEffectParam
{
    public int _downsample;
    public float _blurSize;
    public float _textureSize;

    private Camera _cameraBaclGrundTexture;
    public Camera CameraBaclGrundTexture
    {
        get { return _cameraBaclGrundTexture; }
        set { _cameraBaclGrundTexture = value; }
    }

    public ImageEffectParamFastBlur(Camera camera, int downsample, float blurSize, float textureSize,bool renderCamera = false,float depth = 0,ImageEffectCallback callback = null,object[] args = null)
    {
        _cameraBaclGrundTexture = null;
        _camera = camera;
        _downsample = downsample;
        _blurSize = blurSize;
        _textureSize = textureSize;
        _type = eImageEffect.FastBlur;
        _newCameraRender = renderCamera;
        _depth = depth;
        Callback = new sImageEffectCallbackStruct(callback,args);
    }
}

public class ImageEffectParamDepthOfField : ImageEffectParam
{
    public float _focalPoint;   //聚焦点（只有当_objectFocus 为空的时候才有效）
    public float _focalSize;    //焦点大小
    public float _smoothness;   //景深平滑值
    public float _maxBlurSpread;//模糊程度
    public float _textureSize;  //图片大小（为节省性能一般用0.5或者0.25，大多数情况下是0.5）
    public Transform _objectFocus;//聚焦对象

    public ImageEffectParamDepthOfField(Camera camera, float focalPoint, float focalSize, float smoothness, float maxBlurSpread, float textureSize, Transform objectFocus, bool renderCamera = false, float depth = 0, ImageEffectCallback callback = null, object[] args = null)
    {
        _camera = camera;
        _focalPoint = focalPoint;
        _focalSize = focalSize;
        _smoothness = smoothness;
        _maxBlurSpread = maxBlurSpread;
        _textureSize = textureSize;
        _objectFocus = objectFocus;
        _type = eImageEffect.DepthOfField;

        _newCameraRender = renderCamera;
        _depth = depth;
        Callback = new sImageEffectCallbackStruct(callback,args);
    }
}

public class ImageEffectParamTiltShiftHdr : ImageEffectParam
{
    public float _iteration;
    public float _textureSize;

    public ImageEffectParamTiltShiftHdr(Camera camera, float Iteration, float textureSize, ImageEffectCallback callback = null, object[] args = null)
    {
        _camera = camera;
        _iteration = Iteration;
        _textureSize = textureSize;
        _type = eImageEffect.TiltShiftHdr;
        Callback = new sImageEffectCallbackStruct(callback,args);
    }
}

public class ImageEffectParamFogOfWar : ImageEffectParam
{
    public Vector3 _worldPos;
    public ImageEffectParamFogOfWar(Camera camera, Vector3 worldPos, ImageEffectCallback callback = null, object[] args = null)
    {
        _camera = camera;
        _worldPos = worldPos;
        _type = eImageEffect.FogOfWar;
        Callback = new sImageEffectCallbackStruct(callback,args);
    }
}

public class ImageEffectParamGrayEffect : ImageEffectParam
{
    public float _grayValue;
    public ImageEffectParamGrayEffect(Camera camera, float grayVal, float depth = 0, ImageEffectCallback callback = null, object[] args = null)
    {
        _camera = camera;
        _grayValue = Mathf.Clamp01(grayVal);
        _type = eImageEffect.GrayEffect;
        _depth = depth;
        Callback = new sImageEffectCallbackStruct(callback,args);
    }
}



public class ImageEffectManager : SingletonObject<ImageEffectManager>
{
    private class EffectCarrier
    {
        public EffectGrapgics _effect;
        public GameObject _object;
        public Camera _camera;
    }

    private class MulitipleEffectCarrier : EffectCarrier
    {
        public Dictionary<Camera, EffectCarrier> _effectInstanceList = new Dictionary<Camera, EffectCarrier>();
    }

    private Dictionary<eImageEffect, EffectCarrier> m_effecrDictionary = new Dictionary<eImageEffect, EffectCarrier>();
    private Queue<sImageEffectCallbackStruct> m_callbackQueue = new Queue<sImageEffectCallbackStruct>();

    private EffectCarrier m_tempEffectCarrier;
    private MulitipleEffectCarrier m_tempMulitipleEffectCarrier;

    private object m_lockReleastObject = null;
    private bool m_active = true;

    public ImageEffectManager()
    {
        m_effecrDictionary.Add(eImageEffect.FastBlur, new EffectCarrier());
        m_effecrDictionary.Add(eImageEffect.FogOfWar, new EffectCarrier());
        m_effecrDictionary.Add(eImageEffect.GrayEffect, new MulitipleEffectCarrier());
        m_effecrDictionary.Add(eImageEffect.DepthOfField, new EffectCarrier());

        m_lockReleastObject = EffectGrapgics.LoackObject;
    }

    public void CreateImageEffect(ImageEffectParam effectParam,int layer = 0)
    {
        if (!m_active && effectParam.Type == eImageEffect.FogOfWar)
            return;
        Camera cam = effectParam._camera;
        if (cam == null)
        {
            MyLog.LogError("ImageEffectManager CreateImageEffect param is null");
            return;
        }
        eImageEffect type = effectParam.Type;
        //effectParam._newCameraRender = true;
        //effectParam._depth = effectParam._camera.depth;

        if (!m_effecrDictionary.ContainsKey(type))
            return;

        if (m_effecrDictionary[type] != null)
        {
            Release(type, cam, m_lockReleastObject, true);
            if (type == eImageEffect.GrayEffect)
                m_tempMulitipleEffectCarrier = m_effecrDictionary[type] as MulitipleEffectCarrier;
            else
                m_tempEffectCarrier = m_effecrDictionary[type];
        }
        else
        {
            m_tempEffectCarrier = new EffectCarrier();
            m_effecrDictionary[type] = m_tempEffectCarrier;
        }
        if (type == eImageEffect.GrayEffect)
        {
            if (m_tempMulitipleEffectCarrier._effectInstanceList.ContainsKey(cam))
            {
                MyLog.LogError("ImageEffectManager CreateImageEffect GrayEffect must release " + effectParam._camera.name);
                return;
            }
            EffectCarrier ec = new EffectCarrier();
            ec._object = cam.gameObject;
            ec._camera = cam;
            m_tempMulitipleEffectCarrier._effectInstanceList.Add(cam, ec);
        }
        else
        {
            if (m_tempEffectCarrier._object == null)
            {
                m_tempEffectCarrier._camera = cam;
                m_tempEffectCarrier._object = cam.gameObject;
            }
        }

        switch (effectParam.Type)
        {
            case eImageEffect.FastBlur: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.GetComponent<FastBlur>(); break;
            case eImageEffect.DepthOfField: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.GetComponent<DepthOfField>(); break;
            case eImageEffect.TiltShiftHdr: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.GetComponent<TiltShiftHdrNew>(); break;
            case eImageEffect.FogOfWar: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.GetComponent<FogOfWarStatic>(); break;
            case eImageEffect.GrayEffect: m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect = m_tempMulitipleEffectCarrier._effectInstanceList[cam]._object.GetComponent<GrayEffect>(); break;
            default: break;
        }

        if ((m_tempEffectCarrier._effect == null && type != eImageEffect.GrayEffect) ||
            (m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect == null && type == eImageEffect.GrayEffect))
        {
            switch (type)
            {
                case eImageEffect.FastBlur: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.AddComponent<FastBlur>(); break;
                case eImageEffect.DepthOfField: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.AddComponent<DepthOfField>(); break;
                case eImageEffect.TiltShiftHdr: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.AddComponent<TiltShiftHdrNew>(); break;
                case eImageEffect.FogOfWar: m_tempEffectCarrier._effect = m_tempEffectCarrier._object.AddComponent<FogOfWarStatic>(); break;
                case eImageEffect.GrayEffect: m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect = m_tempMulitipleEffectCarrier._effectInstanceList[cam]._object.AddComponent<GrayEffectQuad>(); break;
                default: break;
            }
        }
        else
        {
            if (type != eImageEffect.GrayEffect)
                m_tempEffectCarrier._effect.enabled = true;
            else
                m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect.enabled = true;
        }

        if (layer != 0 && m_tempEffectCarrier._effect != null && effectParam.Type < eImageEffect.FogOfWar)
            ((EffectBase)m_tempEffectCarrier._effect).m_layer = layer;

        if ((m_tempEffectCarrier._effect != null && type != eImageEffect.GrayEffect) ||
            (m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect != null && type == eImageEffect.GrayEffect))
        {
            switch (effectParam.Type)
            {
                case eImageEffect.FastBlur: SetFastBlurParam(effectParam as ImageEffectParamFastBlur); break;
                case eImageEffect.DepthOfField: SetDepthOfFieldParam(effectParam as ImageEffectParamDepthOfField); break;
                case eImageEffect.TiltShiftHdr: SetTiltShiftHdrNewParam(effectParam as ImageEffectParamTiltShiftHdr); break;
                case eImageEffect.FogOfWar: SetFogOfWarParam(effectParam as ImageEffectParamFogOfWar); break;
                case eImageEffect.GrayEffect: SetGrayEffectParam(effectParam as ImageEffectParamGrayEffect); break;
                default: break;
            }
            if (type != eImageEffect.GrayEffect)
                m_tempEffectCarrier._effect.Callback = effectParam.Callback;
            else
                m_tempMulitipleEffectCarrier._effectInstanceList[cam]._effect.Callback = effectParam.Callback;
        }
        if (type != eImageEffect.FogOfWar)
            UseFogOfWarDestin(true);
        //Common.TimeScale = 0.00001f;
    }

    public void Refresh(eImageEffect effectType)
    {
        if (!m_effecrDictionary.ContainsKey(effectType))
            return;
        if (m_effecrDictionary[effectType] == null)
            return;
        if (m_effecrDictionary[effectType]._effect == null || effectType == eImageEffect.FogOfWar)
            return;

        m_effecrDictionary[effectType]._effect.Refresh();
    }

    public void SetColor32(Color32 color32, eImageEffect effectType, Camera cam = null)
    {
        Color color = Color.white;
        color.r = color32.r / 255f;
        color.g = color32.g / 255f;
        color.b = color32.b / 255f;
        SetColor(color, effectType);
    }

    public void SetColor(Color color, eImageEffect effectType,Camera cam = null)
    {
        if (!m_effecrDictionary.ContainsKey(effectType))
            return;
        if (m_effecrDictionary[effectType] == null)
            return;
        if (effectType != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[effectType]._effect && effectType != eImageEffect.FogOfWar)
            {
                ((EffectBase)m_effecrDictionary[effectType]._effect).SetColor(color);
            }
        }
        else
        {
            if (cam == null)
                return;
            if (!(m_effecrDictionary[effectType] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
                return;
            if ((m_effecrDictionary[effectType] as MulitipleEffectCarrier)._effectInstanceList[cam] != null)
                ((GrayEffect)m_effecrDictionary[effectType]._effect).SetGray(color.a);
            else
            {
                (m_effecrDictionary[effectType] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
            }
        }
    }

    public void CloseEffect(eImageEffect type, Camera cam = null, bool immediately = false)
    {
        if (immediately)
        {
            Release(type, cam, m_lockReleastObject, false);
            return;
        }
        if (!m_effecrDictionary.ContainsKey(type))
            return;
        if (m_effecrDictionary[type] == null)
            return;
        if (type != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[type]._effect == null)
                return;
            m_effecrDictionary[type]._effect.Close();
        }
        else
        {
            if (cam == null)
            {
                MyLog.LogError("ImageEffectManager CloseEffect Camera can not be null");
                return;
            }
            if (!(m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
                return;
            if ((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect == null)
            {
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
                return;
            }
            (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect.Close();
        }
    }

    public void Release(eImageEffect type, Camera cam = null,object lockObject = null,bool needTexture = false)
    {
        if (m_lockReleastObject != null)
        {
            if (lockObject == null || !m_lockReleastObject.Equals(lockObject))
                return;
        }

        if (!m_effecrDictionary.ContainsKey(type))
            return;
        if (m_effecrDictionary[type] == null)
            return;
        if (type != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[type]._effect == null)
                return;
            m_effecrDictionary[type]._effect.Release(needTexture);
            Clear(type);
        }
        else
        {
            if (cam == null)
            {
                MyLog.LogError("ImageEffectManager Release Camera can not be null");
                return;
            }
            if (!(m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
                return;
            if ((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect == null)
            {
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
                return;
            }
            (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect.Release(needTexture);
            Clear(type, cam);
        }

        //Common.TimeScale = 1;
    }

    public bool IsEffectActive(eImageEffect type,Camera cam = null)
    {
        if (!m_effecrDictionary.ContainsKey(type))
            return false;
        if (m_effecrDictionary[type] == null)
            return false;
        if (type != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[type]._effect == null)
                return false;

            if (type < eImageEffect.FogOfWar)
                return true;
            return m_effecrDictionary[type]._effect.enabled;
        }
        else
        {
            if (cam == null)
                return false;
            if (!(m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
            {
                return false;
            }
            if ((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect != null)
                return true;
            else
            {
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
                return false;
            }
        }
    }

    public RenderTexture GetEffectTexture(eImageEffect type)
    {
        if (!m_effecrDictionary.ContainsKey(type))
            return null;
        if (m_effecrDictionary[type] == null)
            return null;
        if (m_effecrDictionary[type]._effect == null)
            return null;

        if (type == eImageEffect.FogOfWar)
            return (m_effecrDictionary[type]._effect as FogOfWarStatic).Destination;
        else
            return null;
    }

    public void UseFogOfWarDestin(bool use)
    {
        if (!IsEffectActive(eImageEffect.FogOfWar))
            return;
        (m_effecrDictionary[eImageEffect.FogOfWar]._effect as FogOfWarStatic).UseDestinTexture(use);
    }

    public Camera GetCamera(eImageEffect type)
    {
        if (!IsEffectActive(type))
            return null;
        return m_effecrDictionary[type]._camera;
    }

    public void AddCallback(sImageEffectCallbackStruct Callback)
    {
        m_callbackQueue.Enqueue(Callback);
    }

    public void Update()
    {
        while (m_callbackQueue.Count > 0)
        {
            sImageEffectCallbackStruct callback = m_callbackQueue.Dequeue();
            if (callback._callBack != null)
                callback._callBack(callback._args);
        }
    }

    public void SetCameraDepth(eImageEffect type, float depth, Camera cam)
    {
        if (!m_effecrDictionary.ContainsKey(type))
            return;
        if (m_effecrDictionary[type] == null)
            return;
        if (type != eImageEffect.GrayEffect)
        {
            if (type == eImageEffect.FastBlur)
            {
                if (m_effecrDictionary[type]._effect != null && (m_effecrDictionary[type]._effect as EffectBase)._useRenderCamera)
                    m_effecrDictionary[type]._camera.depth = depth;
            }
        }
        else
        {
            if (cam == null)
                return;
            if (!(m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
            {
                return;
            }
            GrayEffectQuad  eff = (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect as GrayEffectQuad;
            if (eff != null)
            {
                if (eff.Effect != null)
                {
                    if (eff.Effect.CopyCamera != null)
                    {
                        eff.Effect.CopyCamera.depth = depth;
                    }
                }
            }
        }
    }

    public void SetActive(bool active)
    {
        m_active = active;
    }

    private void SetDepthOfFieldParam(ImageEffectParamDepthOfField effectParam)
    {
        if(!m_effecrDictionary.ContainsKey(effectParam.Type))
            return;
        DepthOfField effect = m_effecrDictionary[effectParam.Type]._effect as DepthOfField;
        if (effect == null)
            return;

        effect._useRenderCamera = effectParam._newCameraRender;
        effect._renderCameraDepth = effectParam._depth;
        effect.maxBlurSpread = effectParam._maxBlurSpread;
        //effect.RenderTextureSize = effectParam._textureSize;
        effect.Open(effectParam._textureSize);
        effect.focalPoint = effectParam._focalPoint;
        effect.smoothness = effectParam._smoothness;
        effect.objectFocus = effectParam._objectFocus;
        effect.focalSize = effectParam._focalSize;
    }

    private void SetFastBlurParam(ImageEffectParamFastBlur effectParam)
    {
        if(!m_effecrDictionary.ContainsKey(effectParam.Type))
            return;
        FastBlur effect = m_effecrDictionary[effectParam.Type]._effect as FastBlur;
        if (effect == null)
            return;

        effect._useRenderCamera = effectParam._newCameraRender;
        effect._renderCameraDepth = effectParam._depth;
        effect.downsample = effectParam._downsample;
        effect.blurSize = effectParam._blurSize;
        //effect.RenderTextureSize = effectParam._textureSize;
        effect.Open(effectParam._textureSize, effectParam.CameraBaclGrundTexture);
    }

    private void SetTiltShiftHdrNewParam(ImageEffectParamTiltShiftHdr effectParam)
    {
        if(!m_effecrDictionary.ContainsKey(effectParam.Type))
            return;
        TiltShiftHdrNew effect = m_effecrDictionary[effectParam.Type]._effect as TiltShiftHdrNew;
        if (effect == null)
            return;

        effect._useRenderCamera = effectParam._newCameraRender;
        effect._renderCameraDepth = effectParam._depth;
        effect.Iteration = effectParam._iteration;
        //effect.RenderTextureSize = effectParam._textureSize;
        effect.Open(effectParam._textureSize);
    }

    private void SetFogOfWarParam(ImageEffectParamFogOfWar effectParam)
    {
        if(!m_effecrDictionary.ContainsKey(effectParam.Type))
            return;
        FogOfWarStatic effect = m_effecrDictionary[effectParam.Type]._effect as FogOfWarStatic;
        if (effect == null)
            return;

        effect.Init(effectParam._worldPos);
    }

    private void SetGrayEffectParam(ImageEffectParamGrayEffect effectParam)
    {
        if (!m_effecrDictionary.ContainsKey(effectParam.Type))
            return;
        MulitipleEffectCarrier mulitipleEffectCarrier = m_effecrDictionary[effectParam.Type] as MulitipleEffectCarrier;
        if (!mulitipleEffectCarrier._effectInstanceList.ContainsKey(effectParam._camera))
            return;
        GrayEffect effect = mulitipleEffectCarrier._effectInstanceList[effectParam._camera]._effect as GrayEffect;
        if (effect == null)
            return;

        effect.Init(effectParam._grayValue, effectParam._depth);
    }

    //public void OpenEffect()
    //{
    //    EffectControl(true);
    //}

    //private void Release(eImageEffect type,Camera cam = null)
    //{
    //    if (!m_effecrDictionary.ContainsKey(type))
    //        return;
    //    if (m_effecrDictionary[type] == null)
    //        return;
    //    if (type != eImageEffect.GrayEffect)
    //    {
    //        if (m_effecrDictionary[type]._effect == null)
    //            return;
    //        m_effecrDictionary[type]._effect.Release();
    //        Clear(type);
    //    }
    //    else
    //    {
    //        if (cam == null)
    //        {
    //            MyLog.LogError("ImageEffectManager Release Camera can not be null");
    //            return;
    //        }
    //        if (!(m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam))
    //            return;
    //        if ((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect == null)
    //        {
    //            (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
    //            return;
    //        }
    //        (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect.Release();
    //        Clear(type, cam);
    //    }
    //}

    private void EffectControl(bool active,eImageEffect type)
    {
        if (!m_effecrDictionary.ContainsKey(type))
            return;
        if (m_effecrDictionary[type] == null)
            return;
        if (type != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[type]._effect != null)
                m_effecrDictionary[type]._effect.enabled = active;
            else
            {
                Clear(type);
            }
        }
    }

    private void Clear(eImageEffect type, Camera cam = null)
    {
        if (!m_effecrDictionary.ContainsKey(type))
            return;
        if (m_effecrDictionary[type] == null)
            return;
        if (type != eImageEffect.GrayEffect)
        {
            if (m_effecrDictionary[type]._effect != null)
            {
                Object.DestroyImmediate(m_effecrDictionary[type]._effect);
                m_effecrDictionary[type]._effect = null;
            }

            m_effecrDictionary[type]._camera = null;
            m_effecrDictionary[type]._object = null;
        }
        else
        {
            if (cam == null)
            {
                MyLog.LogError("ImageEffectManager Clear Camera can not be null");
                return;
            }
            if ((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.ContainsKey(cam) != null)
            {
                Object.DestroyImmediate((m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect);
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._effect = null;

                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._camera = null;
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList[cam]._object = null;
                (m_effecrDictionary[type] as MulitipleEffectCarrier)._effectInstanceList.Remove(cam);
            }
        }
    }
}
