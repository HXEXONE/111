﻿using UnityEngine;
using System.Collections;

public class DepthOfField : EffectBase
{
    private static float BOKEH_EXTRA_BLUR = 2.0f;

    public float focalPoint = 1.0f;
    public float smoothness = 0.5f;

    private float focalStartCurve = 2.0f;
    private float focalEndCurve = 2.0f;
    private float focalDistance01 = 0.1f;

    public Transform objectFocus = null;
    public float focalSize = 0.0f;

    public float maxBlurSpread = 1.75f;

	private Shader dofBlurShader;
    private Material dofBlurMaterial = null;

	private Shader dofShader;
    private Material dofMaterial = null;

    private Shader blurShader;
    private Material blurMaterial = null;

    private float widthOverHeight = 1.25f;
    private float oneOverBaseSize = 1.0f / 512.0f;

    private bool bokeh = false;
    public Texture2D bokehTexture;
    private float bokehScale = 2.4f;
    private float bokehIntensity = 0.15f;
    private int bokehDownsample = 1;

    private float m_nearClipPlane = 0.3f, m_farClipPlane = 1000;
    private Transform m_transformSelf;
    private Camera m_cameraSelf;
    
    private void Init()
    {
        if (dofBlurShader == null)
		{
            dofBlurShader = DynamicShader.GetShader("MyMobile/DOF/SeparableWeightedBlurDepthOfField");
		}

        if (dofShader == null)
		{
            dofShader = DynamicShader.GetShader("MyMobile/DOF/DepthOfField");
		}

        if (blurShader == null)
        {
            blurShader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_EFFECT_BLUR);
        }

        m_nearClipPlane = camera.nearClipPlane;
        m_farClipPlane = camera.farClipPlane;

        m_transformSelf = transform;
        m_cameraSelf = camera;
    }

    protected override bool CheckResources(bool needDepth)
    {
        if (camera == null)
        {
            this.enabled = false;
            return false;
        }

		Init();

        bool supps = CheckSupport(true);

        bool findShader = true;
        if (dofBlurShader == null)
        {
			MyLog.LogError("Camera Effect Depth Of Field Shader dofBlurShader is null");
            findShader = false;
        }

        if (dofShader == null)
        {
			MyLog.LogError("Camera Effect Depth Of Field Shader dofShader is null");
            findShader = false;
        }

        if (blurShader == null)
        {
            MyLog.LogError("Camera Effect Depth Of Field Shader dofShader is null");
            findShader = false;
        }

        if (!findShader)
        {
            return false;
        }

        dofBlurMaterial = CheckShaderAndCreateMaterial(dofBlurShader, dofBlurMaterial);
        dofMaterial = CheckShaderAndCreateMaterial(dofShader, dofMaterial);
        blurMaterial = CheckShaderAndCreateMaterial(blurShader, blurMaterial);

        if (!isSupported)
            ReportAutoDisable();
		else
			camera.depthTextureMode |= DepthTextureMode.Depth;
        return isSupported;
    }

    protected override void Clear()
    {
        Quads.Cleanup();
    }

    private float FocalDistance01(float worldDist)
    {
        return m_cameraSelf.WorldToViewportPoint((worldDist - m_nearClipPlane) * m_transformSelf.forward + m_transformSelf.position).z / (m_farClipPlane - m_nearClipPlane);
    }

    private RenderTexture foregroundTexture = null;
    private RenderTexture mediumRezWorkTexture = null;
    private RenderTexture finalDefocus = null;
    private RenderTexture lowRezWorkTexture = null;
    private RenderTexture bokehSource = null;
    private RenderTexture bokehSource2 = null;

    protected override void RenderImage(RenderTexture source, RenderTexture destination, ref RenderTexture sceneRender)
    {
        if (!isSupported || m_cameraSelf == null)
        {
            if (m_cameraSelf == null)
                MyLog.LogError("DepthOfField OnRenderImage Camera is null");

            this.enabled = false;
            //Graphics.Blit(source, destination);
            return;
        }
        RenderTexture bs = RenderTexture.GetTemporary(source.width, source.height, 0, source.format);
        if (sceneRender != null)
        {
            bs.filterMode = FilterMode.Bilinear;
            blurMaterial.SetTexture("_Scene", sceneRender);
            Graphics.Blit(source, bs, blurMaterial, 3);
            source = bs;
        }

        if (smoothness < 0.1f)
            smoothness = 0.1f;

        float bokehBlurAmplifier = bokeh ? BOKEH_EXTRA_BLUR : 1.0f;

        float focal01Size = focalSize / (m_farClipPlane - m_nearClipPlane);

        focalDistance01 = objectFocus ? (m_cameraSelf.WorldToViewportPoint(objectFocus.position)).z / (m_farClipPlane) : FocalDistance01(focalPoint);
        focalStartCurve = focalDistance01 * smoothness;
        focalEndCurve = focalStartCurve;

        widthOverHeight = (1.0f * source.width) / (1.0f * source.height);
        oneOverBaseSize = 1.0f / 512.0f;

        Vector4 CurveParams = new Vector4(1.0f / focalStartCurve, 1.0f / focalEndCurve, focal01Size * 0.5f, focalDistance01);
        dofMaterial.SetVector("_CurveParams", CurveParams);
        dofMaterial.SetVector("_InvRenderTargetSize", new Vector4(1.0f / (1.0f * source.width), 1.0f / (1.0f * source.height), 0.0f, 0.0f));

        int divider = 2;
        int lowTexDivider = divider * 2;

        AllocateTextures(false, source, divider, lowTexDivider);

        source.MarkRestoreExpected();
        Graphics.Blit(source, source, dofMaterial, 1);

        Downsample(source, mediumRezWorkTexture);
 	     
        Blur(mediumRezWorkTexture, mediumRezWorkTexture, 2, maxBlurSpread);

        if (bokeh)
        {
            bokehSource2.MarkRestoreExpected();
            Graphics.Blit(mediumRezWorkTexture, bokehSource2, dofMaterial, 4);

            Graphics.Blit(mediumRezWorkTexture, lowRezWorkTexture);

            Blur(lowRezWorkTexture, lowRezWorkTexture, 0, maxBlurSpread * bokehBlurAmplifier);
        }
        else
        {
            Downsample(mediumRezWorkTexture, lowRezWorkTexture);
            Blur(lowRezWorkTexture, lowRezWorkTexture, 0, maxBlurSpread);
        }

        dofBlurMaterial.SetTexture("_TapLow", lowRezWorkTexture);
        dofBlurMaterial.SetTexture("_TapMedium", mediumRezWorkTexture);
        Graphics.Blit(null, finalDefocus, dofBlurMaterial, 1);

        if (bokeh)
            AddBokeh(bokehSource2, bokehSource, finalDefocus);

		dofMaterial.SetTexture("_TapLowBackground", finalDefocus);

        Graphics.Blit(source, destination, dofMaterial, 0);

        ReleaseTextures();
        RenderTexture.ReleaseTemporary(bs);
    }

    private void Blur(RenderTexture from, RenderTexture to, int blurPass, float spread)
    {
        RenderTexture tmp = RenderTexture.GetTemporary(to.width, to.height);

        dofBlurMaterial.SetVector("offsets", new Vector4(0.0f, spread * oneOverBaseSize, 0.0f, 0.0f));
        Graphics.Blit(from, tmp, dofBlurMaterial, blurPass);
        dofBlurMaterial.SetVector("offsets", new Vector4(spread / widthOverHeight * oneOverBaseSize, 0.0f, 0.0f, 0.0f));
        to.MarkRestoreExpected();
        Graphics.Blit(tmp, to, dofBlurMaterial, blurPass);
        RenderTexture.ReleaseTemporary(tmp);
    }

    private void Downsample(RenderTexture from, RenderTexture to)
    {
        dofMaterial.SetVector("_InvRenderTargetSize", new Vector4(1.0f / (1.0f * to.width), 1.0f / (1.0f * to.height), 0.0f, 0.0f));
        to.MarkRestoreExpected();
        Graphics.Blit(from, to, dofMaterial, 2);
    }

    private void AddBokeh(RenderTexture bokehInfo, RenderTexture tempTex, RenderTexture finalTarget)
    {
        Mesh[] meshes = Quads.GetMeshes(tempTex.width, tempTex.height);	// quads: exchanging more triangles with less overdraw			

        RenderTexture.active = tempTex;
        GL.Clear(false, true, new Color(0.0f, 0.0f, 0.0f, 0.0f));

        GL.PushMatrix();
        GL.LoadIdentity();

        bokehInfo.filterMode = FilterMode.Point;

        float arW = (bokehInfo.width * 1.0f) / (bokehInfo.height * 1.0f);
        float sc = 2.0f / (1.0f * bokehInfo.width);
        sc += bokehScale * maxBlurSpread * BOKEH_EXTRA_BLUR * oneOverBaseSize;

        int meshCount = meshes.Length;
        for (int i = 0; i < meshCount; i++)
            Graphics.DrawMeshNow(meshes[i], Matrix4x4.identity);

        GL.PopMatrix();
        finalTarget.MarkRestoreExpected();
        Graphics.Blit(tempTex, finalTarget, dofMaterial, 3);

        bokehInfo.filterMode = FilterMode.Bilinear;
    }

    private void ReleaseTextures()
    {
        if (foregroundTexture) RenderTexture.ReleaseTemporary(foregroundTexture);
        if (finalDefocus) RenderTexture.ReleaseTemporary(finalDefocus);
        if (mediumRezWorkTexture) RenderTexture.ReleaseTemporary(mediumRezWorkTexture);
        if (lowRezWorkTexture) RenderTexture.ReleaseTemporary(lowRezWorkTexture);
        if (bokehSource) RenderTexture.ReleaseTemporary(bokehSource);
        if (bokehSource2) RenderTexture.ReleaseTemporary(bokehSource2);
    }

    private void AllocateTextures(bool blurForeground, RenderTexture source, int divider, int lowTexDivider)
    {
        foregroundTexture = null;
        if (blurForeground)
            foregroundTexture = RenderTexture.GetTemporary(source.width, source.height, 0);
        mediumRezWorkTexture = RenderTexture.GetTemporary(source.width / divider, source.height / divider, 0);
        finalDefocus = RenderTexture.GetTemporary(source.width / divider, source.height / divider, 0);
        lowRezWorkTexture = RenderTexture.GetTemporary(source.width / lowTexDivider, source.height / lowTexDivider, 0);
        bokehSource = null;
        bokehSource2 = null;
        if (bokeh)
        {
            bokehSource = RenderTexture.GetTemporary(source.width / (lowTexDivider * bokehDownsample), source.height / (lowTexDivider * bokehDownsample), 0, RenderTextureFormat.ARGBHalf);
            bokehSource2 = RenderTexture.GetTemporary(source.width / (lowTexDivider * bokehDownsample), source.height / (lowTexDivider * bokehDownsample), 0, RenderTextureFormat.ARGBHalf);
            bokehSource.filterMode = FilterMode.Bilinear;
            bokehSource2.filterMode = FilterMode.Bilinear;
            RenderTexture.active = bokehSource2;
            GL.Clear(false, true, new Color(0.0f, 0.0f, 0.0f, 0.0f));
        }

        // to make sure: always use bilinear filter setting

        source.filterMode = FilterMode.Bilinear;
        finalDefocus.filterMode = FilterMode.Bilinear;
        mediumRezWorkTexture.filterMode = FilterMode.Bilinear;
        lowRezWorkTexture.filterMode = FilterMode.Bilinear;
        if (foregroundTexture)
            foregroundTexture.filterMode = FilterMode.Bilinear;
    }


    protected override void onAwake()
    {
        m_type = eImageEffect.DepthOfField;
    }
}
