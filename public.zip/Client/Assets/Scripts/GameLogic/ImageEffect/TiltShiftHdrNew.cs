﻿using UnityEngine;
using System.Collections;

public class TiltShiftHdrNew : EffectBase {

    public float Iteration = 0.5f;

	private Shader tiltShiftShader;
	private Material tiltShiftMaterial = null;

    protected override void onAwake()
    {
        m_type = eImageEffect.TiltShiftHdr;
    }

    protected override bool CheckResources(bool needDepth)
    {
        if (tiltShiftShader == null)
            tiltShiftShader = DynamicShader.GetShader("MyMobile/TiltShiftHdrLensBlur");

        if (tiltShiftShader == null)
        {
            MyLog.LogError("TiltShiftHdrNew CheckResources can not load shader MyMobile/TiltShiftHdrLensBlur");
        }

        CheckSupport(needDepth);	
	
		tiltShiftMaterial = CheckShaderAndCreateMaterial (tiltShiftShader, tiltShiftMaterial);
		
		if(!isSupported)
			ReportAutoDisable ();
		return isSupported;				
	}

    protected override void RenderImage(RenderTexture source, RenderTexture destination,ref RenderTexture sceneRender)
    {
        if (!isSupported)
        {
			return;
		}

        tiltShiftMaterial.SetFloat("_Iteration", Iteration);
		source.filterMode = FilterMode.Bilinear;
		
		RenderTexture rt = destination;

        Graphics.Blit(source, rt, tiltShiftMaterial);

		if (rt != destination)
			RenderTexture.ReleaseTemporary (rt);
	}
}
