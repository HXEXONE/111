﻿using UnityEngine;
using System.Collections;

public class OtherCameraEffect : MonoBehaviour {

    [SerializeField]
    private RenderTexture m_targetTexture;
    public RenderTexture TargetTexture
    {
        get { return m_targetTexture; }
    }

    private int m_renderFrame = -1;
    public int RenderFrame { get { return m_renderFrame; } set { m_renderFrame = value; } }

    void OnEnable()
    {
        if (m_targetTexture == null)
        {
            m_targetTexture = new RenderTexture((int)camera.pixelWidth, (int)camera.pixelHeight, 16, RenderTextureFormat.ARGB32);
            m_targetTexture.generateMips = true;
            m_targetTexture.filterMode = FilterMode.Bilinear;
            m_targetTexture.isCubemap = false;
            m_targetTexture.isPowerOfTwo = false;
            m_targetTexture.wrapMode = TextureWrapMode.Clamp;
        }
    }

    //void OnDisalbe()
    //{
    //    if (!ImageEffectManager.GetInst().IsEffectActive(eImageEffect.FogOfWar))
    //        camera.targetTexture = null;
    //}

    void OnDestory()
    {
        if (m_targetTexture != null)
        {
            m_targetTexture.Release();
            Object.DestroyImmediate(m_targetTexture);
            m_targetTexture = null;
        }
    }

    void OnPreCull()
    {
        if (m_targetTexture != null)
        {
            camera.targetTexture = m_targetTexture;
        }
    }

    void OnPostRender()
    {
        if (m_renderFrame > 0)
        {
            m_renderFrame--;
        }
        if (m_renderFrame == 0)
            this.enabled = false;
    }
}
