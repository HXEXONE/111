﻿using UnityEngine;
using System.Collections;

public class GrayEffectQuad : GrayEffect
{
    private GameObject m_cameraObject;
    private GrayEffectRender effect;
    public GrayEffectRender Effect{get { return effect; }}

    public override void Init(float grayval, float depth)
    {
        base.Init(grayval,depth);

        m_grayShader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_GRAY_TRANSPARENT_FULLSCREEN);
        m_materialGray = CheckShaderAndCreateMaterial(m_grayShader, m_materialGray);
        if (m_materialGray)
            m_materialGray.SetFloat("_Gray", m_grayValue);

        m_materialGray.mainTexture = m_source;

        m_cameraObject = new GameObject("CopyCamera",typeof(Camera));
        GrayEffectRender effect = m_cameraObject.AddComponent<GrayEffectRender>();
        effect.Init(m_camera, depth);
    }

    public override void Release(bool needTexture = false)
    {
        base.Release(needTexture);
        if (m_cameraObject != null)
            Destroy(m_cameraObject);
    }
}
