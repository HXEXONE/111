﻿using UnityEngine;
using System.Collections;

public class GrayEffect : EffectGrapgics
{
    protected Shader m_grayShader;
    protected Material m_materialGray;

    public RenderTexture m_source;

    private CameraClearFlags m_clearFlags;

    protected Camera m_camera;
    protected bool m_startEffect = false;
    protected float m_grayValue = 1;

    protected override void onAwake()
    {
        m_type = eImageEffect.GrayEffect;
    }

    void OnDisable()
    {
        Release();
    }

    void OnDestory()
    {
        Release();
    }

    void OnEnable()
    {
        //Init(1);
    }


    public virtual void Init(float grayVal,float depth)
    {
        m_camera = this.camera;

        m_source = new RenderTexture((int)m_camera.pixelWidth, (int)m_camera.pixelHeight, 16, RenderTextureFormat.ARGB32);
        m_source.filterMode = FilterMode.Bilinear;
        m_source.generateMips = true;
        m_source.isCubemap = false;
        m_source.isPowerOfTwo = false;
        m_source.useMipMap = false;

        m_clearFlags = m_camera.clearFlags;
        m_camera.clearFlags = CameraClearFlags.SolidColor;
        m_camera.targetTexture = m_source;

        m_startEffect = true;
    }

    public override void Release(bool needTexture = false)
    {
        if (m_source != null)
        {
            m_source.Release();
            Object.Destroy(m_source);
            m_source = null;
        }
        if (m_camera != null)
        {
            m_camera.clearFlags = m_clearFlags;
            m_camera.targetTexture = null;
            m_camera = null;
        }
        if (m_materialGray != null)
        {
            m_grayShader = null;
            DestroyImmediate(m_materialGray);
        }

        m_startEffect = false;
    }

    public void SetGray(float gray)
    {
        if (!m_materialGray)
            return;
        m_materialGray.SetFloat("_Gray", gray);
    }
}
