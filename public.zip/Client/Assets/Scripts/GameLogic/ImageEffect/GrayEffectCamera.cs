﻿using UnityEngine;
using System.Collections;

public class GrayEffectCamera : GrayEffect
{
    //void OnPostRender()
    //{
    //    if (!m_startEffect || m_camera == null)
    //        return;
    //    StartCoroutine(RenderGray());
    //}

    //public override void Init(float grayval, float depth)
    //{
    //    base.Init(grayval,depth);
    //    m_grayShader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_GRAY_TRANSPARENT);
    //    m_materialGray = CheckShaderAndCreateMaterial(m_grayShader, m_materialGray);
    //    if (m_materialGray)
    //        m_materialGray.SetFloat("_Gray", m_grayValue);
    //}

    //IEnumerator RenderGray()
    //{
    //    yield return new WaitForEndOfFrame();
    //    Graphics.Blit(m_source, (RenderTexture)null, m_materialGray);
    //}
}
