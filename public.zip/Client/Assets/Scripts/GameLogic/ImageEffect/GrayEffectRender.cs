﻿using UnityEngine;
using System.Collections;

public class GrayEffectRender : EffectGrapgics {

    private Camera m_copyCamera;
    public Camera CopyCamera{get { return m_copyCamera; }}

    private GameObject m_quad;

    private Shader m_renderShader;
    private Shader m_grayShader;

    private Material m_materialGray;

    private int m_defaultLayer = 1 << 0;

    void OnPreCull()
    {
        if (m_copyCamera == null)
            return;
        m_copyCamera.SetReplacementShader(m_renderShader, "EffectTag");
    }

    public void Init(Camera cam,float depth)
    {
        m_copyCamera = camera;
        m_quad = GameObject.CreatePrimitive(PrimitiveType.Quad);
        Collider cill = m_quad.GetComponent<Collider>();
        if (cill != null)
            DestroyImmediate(cill);

        if (m_copyCamera.isOrthoGraphic)
        {
            if (m_copyCamera.aspect > 1)
            {
                m_quad.transform.localScale = Vector3.one * m_copyCamera.orthographicSize * m_copyCamera.aspect * 2 + Vector3.one;
            }
            else
            {
                m_quad.transform.localScale = Vector3.one * m_copyCamera.orthographicSize * 2 + Vector3.one;
            }
        }
        else
        {
            if (m_copyCamera.aspect > 1)
                m_quad.transform.localScale = Vector3.one * 3 * m_copyCamera.aspect;
            else
                m_quad.transform.localScale = Vector3.one * 3;
        }

        m_quad.transform.parent = transform.parent;
        m_quad.transform.localPosition = Vector3.zero;
        m_quad.transform.position += m_quad.transform.forward * (1 + m_copyCamera.nearClipPlane);
        m_quad.transform.localRotation = Quaternion.identity;
        m_quad.transform.parent = this.transform;

        m_grayShader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_GRAY_TRANSPARENT_FULLSCREEN);
        m_materialGray = CheckShaderAndCreateMaterial(m_grayShader, m_materialGray);
        if (m_materialGray)
            m_materialGray.SetFloat("_Gray", 1);

        m_copyCamera.CopyFrom(cam);
        if (depth != 0)
            m_copyCamera.depth = depth;
        m_copyCamera.targetTexture = null;
        m_copyCamera.cullingMask = m_defaultLayer;
        m_copyCamera.clearFlags = CameraClearFlags.Depth;

        m_materialGray.mainTexture = cam.targetTexture;
        m_quad.renderer.material = m_materialGray;

        m_quad.layer = 0;
    }

    void OnDestory()
    {
        Release();
    }

    public override void Release(bool needTexture = false)
    {
        if (m_quad)
            Destroy(m_quad);

        if (m_materialGray != null)
            DestroyImmediate(m_materialGray);

        m_renderShader = null;
        m_grayShader = null;
    }
}
