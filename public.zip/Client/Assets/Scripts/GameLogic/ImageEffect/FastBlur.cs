﻿using UnityEngine;
using System.Collections;

public class FastBlur : EffectBase {

	public int downsample = 1;//1-2

	public float blurSize = 3.0f;//0-10
	
	private int blurIterations = 2;//1-4

	private Shader blurShader;
	private Material blurMaterial = null;

    protected override bool CheckResources(bool needDepth)
    {

        if (blurShader == null)
        {
            blurShader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_EFFECT_BLUR);
        }

		CheckSupport (false);	
	
		blurMaterial = CheckShaderAndCreateMaterial (blurShader, blurMaterial);
		
		if(!isSupported)
			ReportAutoDisable ();
		return isSupported;				
	}

    protected override void RenderImage(RenderTexture source, RenderTexture destination,ref RenderTexture sceneRender)
    {	
		if(!isSupported) {
            Graphics.Blit(source, destination);
			return;
		}

		float widthMod = 1.0f / (1.0f * (1<<downsample));

		blurMaterial.SetVector ("_Parameter",new Vector4 (blurSize * widthMod, -blurSize * widthMod, 0.0f, 0.0f));
		source.filterMode = FilterMode.Bilinear;

		int rtW = source.width >> downsample;
		int rtH = source.height >> downsample;

		// downsample
		RenderTexture rt = RenderTexture.GetTemporary (rtW, rtH, 0, source.format);
        rt.filterMode = FilterMode.Bilinear;

        if (sceneRender != null)
        {
            RenderTexture bs = RenderTexture.GetTemporary(rtW, rtH, 0, source.format);
            bs.filterMode = FilterMode.Bilinear;
            blurMaterial.SetTexture("_Scene", sceneRender);

            Graphics.Blit(source, bs, blurMaterial, 3);
            sceneRender.MarkRestoreExpected();
            Graphics.Blit(bs, sceneRender);
            Graphics.Blit(bs, rt, blurMaterial, 0);
            RenderTexture.ReleaseTemporary(bs);
        }
        else
            Graphics.Blit(source, rt, blurMaterial, 0);

		for(int i = 0; i < blurIterations; i++) {
			float iterationOffs = (i*1.0f);
			blurMaterial.SetVector ("_Parameter",new Vector4 (blurSize * widthMod + iterationOffs, -blurSize * widthMod - iterationOffs, 0.0f, 0.0f));

            RenderTexture rt2 = RenderTexture.GetTemporary(rtW, rtH, 0, source.format);
			rt2.filterMode = FilterMode.Bilinear;
			Graphics.Blit (rt, rt2, blurMaterial, 1);
			RenderTexture.ReleaseTemporary (rt);
			rt = rt2;

			rt2 = RenderTexture.GetTemporary (rtW, rtH, 0, source.format);
			rt2.filterMode = FilterMode.Bilinear;
			Graphics.Blit (rt, rt2, blurMaterial, 2);
			RenderTexture.ReleaseTemporary (rt);
			rt = rt2;
		}
		
		Graphics.Blit (rt, destination);

		RenderTexture.ReleaseTemporary (rt);
	}

    //protected override void SetMaterialColor(Color color)
    //{
    //    if (blurMaterial != null && blurMaterial.HasProperty("_Color"))
    //        blurMaterial.SetColor("_Color", color);
    //}

    protected override void onAwake()
    {
        m_type = eImageEffect.FastBlur;
    }
}
