﻿using UnityEngine;
using System.Collections;
//using System.IO;

public class EffectGrapgics : MonoBehaviour {

    public static object LoackObject = new object();

    protected bool supportHDRTextures = true;
    protected bool isSupported = true;

    protected eImageEffect m_type;

    protected Material CheckShaderAndCreateMaterial(Shader s, Material m2Create)
    {
        if (!s)
        {
            MyLog.Log("Missing shader in " + this.ToString());
            enabled = false;
            return null;
        }

        if (s.isSupported && m2Create && m2Create.shader == s)
            return m2Create;

        if (!s.isSupported)
        {
            NotSupported();
            MyLog.Log("The shader " + s.ToString() + " on effect " + this.ToString() + " is not supported on this platform!");
            return null;
        }
        else
        {
            m2Create = new Material(s);
            m2Create.hideFlags = HideFlags.DontSave;
            if (m2Create)
                return m2Create;
            else return null;
        }
    }

    private void NotSupported()
    {
        enabled = false;
        isSupported = false;
        return;
    }

    public sImageEffectCallbackStruct Callback;

    protected virtual bool CheckResources(bool needDepth)
    {
        return false;
    }

    protected bool CheckSupport(bool needDepth)
    {
        isSupported = true;
        supportHDRTextures = SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBHalf);

        if (!SystemInfo.supportsImageEffects || !SystemInfo.supportsRenderTextures)
        {
            if (!SystemInfo.supportsImageEffects)
                MyLog.LogError("This is nor supports ImageEffects    ");
            else
                MyLog.LogError("This is nor supports RenderTextures    ");
            NotSupported();
            return false;
        }

        if (needDepth && !SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.Depth))
        {
            MyLog.LogError("This is nor supports RenderTextureFormat.Depth    ");
            NotSupported();
            return false;
        }

        if (needDepth)
            camera.depthTextureMode |= DepthTextureMode.Depth;

        return true;
    }

    protected void ReportAutoDisable()
    {
        MyLog.LogError("The image effect " + this.ToString() + " has been disabled as it's not supported on the current platform.    " + (int)Time.time);
    }

    public virtual void Release(bool needTexture = false)
    { 
    }

    public virtual void Close()
    { }

    public virtual void Refresh()
    {
 
    }

    protected virtual void onAwake()
    { 
    }

    void Awake()
    {
        onAwake();
    }

    //protected void RenderTextureToTexture2D(RenderTexture renderTexture, Texture2D texture2D)
    //{
    //    RenderTexture.active = renderTexture;
    //    texture2D.ReadPixels(new Rect(0, 0, texture2D.width, texture2D.height), 0, 0);
    //    texture2D.Apply();
    //    RenderTexture.active = null;
    //}

    //protected void WriteTexture(Texture2D tex, string name)
    //{
    //    byte[] bufs = tex.EncodeToPNG();
    //    string path = Common.persistentDataPath + "/" + name + ".png";
    //    MyLog.Log(path);
    //    if (!Directory.Exists(Common.persistentDataPath))
    //        Directory.CreateDirectory(Common.persistentDataPath);
    //    File.WriteAllBytes(path, bufs);
    //    MyLog.Log(path + "!!!!!!!!!!!!!!!!!");
    //}

    //protected void WritrTexture(RenderTexture renderTexture, string name)
    //{
    //    Texture2D t = new Texture2D(renderTexture.width, renderTexture.height);
    //    RenderTextureToTexture2D(renderTexture, t);
    //    WriteTexture(t, name);
    //}
}
