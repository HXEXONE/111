﻿using UnityEngine;
using System.Collections;
using System.IO;

public class FogOfWarStatic : EffectGrapgics {

    private CObject m_textureFog;
    private CObject m_texturePass;

    private RenderTexture m_source;
    private RenderTexture m_destination;
    public RenderTexture Destination{ get { return m_destination; }}
    private Camera m_camera;

    private Vector3 m_positionWorld;
    private Vector3 m_positionOrigin;

    private Material m_material;
    private Shader m_shader;

    private bool m_startEffect = false;
    private bool m_useDestination = false;

    private int m_intWorldSize = 300;
    private float m_invWorldSize;

    private Matrix4x4 m_matrix;

    private Vector4 m_params;
    private Vector4 m_camPos;

    private BattlePveMediator m_pve;

    private string m_passTextureName = "worldmapfogpass_";
    private string m_highmapTextureName = "worldhighmap_";

    private string m_nameWorldMap;
    private string m_nameFogTexture;
    private string m_pathFogTexture;
    private Vector4 m_pass;

    private float m_alpha = 0.9f;

    private float m_startH = 1;
    private float m_lenght = 1;

    protected override void onAwake()
    {
        m_type = eImageEffect.FogOfWar;
    }

    void LateUpdate()
    {
        if (!(m_startEffect && m_camera))
            return;

        m_material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, GetAlpha() * m_alpha);
        if (m_camera.targetTexture == null)
        {
            m_camera.targetTexture = m_source;
        }
        
    }

    void OnPostRender()
    {
        if (!(m_startEffect && m_camera))
            return;

        m_matrix = (m_camera.projectionMatrix * m_camera.worldToCameraMatrix).inverse;
        m_material.SetMatrix("_Inverse", m_matrix);
        m_params = new Vector4(-m_positionOrigin.x * m_invWorldSize, -m_positionOrigin.z * m_invWorldSize, m_invWorldSize, 0);
        m_material.SetVector("_Params", m_params);
        m_camPos = transform.position;
        m_material.SetVector("_Pos", m_camPos);

        if (m_useDestination)
        {
            m_destination.MarkRestoreExpected();
            Graphics.Blit(m_source, m_destination, m_material);
            Graphics.Blit(m_destination, (RenderTexture)null);
        }
        else
        {
            Graphics.Blit(m_source, (RenderTexture)null, m_material);
        }
    }

    void OnDisable()
    {
        Release();
    }

    void OnDestory()
    {
        Release();
    }

    public void Init(Vector3 worldPos)
    {
        Initialize(worldPos);
    }

    private void Initialize(Vector3 worldPos)
    {
        if (!CheckSupport(true))
        {
            this.enabled = false;
            m_startEffect = false;
            return;
        }

        m_camera = this.camera;

        m_positionWorld = worldPos;
        float half = m_intWorldSize / 2;
        m_positionOrigin = m_positionWorld - new Vector3(half, 0, half);

        m_invWorldSize = 1f / (float)m_intWorldSize;

        #region  shader 外部加载
        //LoadHelp.LoadObject("", "shader/mymobile fogofwar diffuse.shader", ThreadPriority.Normal, LoadShaderCompleted);
        #endregion

        #region
        m_shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_EFFECT_FOW);
        m_material = CheckShaderAndCreateMaterial(m_shader, m_material);

        if (m_material == null || m_camera == null)
        {
            this.enabled = false;
            MyLog.LogError("Material = " + m_material + "\tShader = " + m_shader + "\tCamera = " + m_camera);
            m_startEffect = false;
            return;
        }

        m_pve = SingletonObject<BattlePveMediator>.GetInst();

        m_source = new RenderTexture((int)m_camera.pixelWidth, (int)m_camera.pixelHeight, 32, RenderTextureFormat.ARGB32);
        m_source.filterMode = FilterMode.Bilinear;
        m_source.generateMips = true;
        m_source.isCubemap = false;
        m_source.isPowerOfTwo = false;
        m_source.useMipMap = false;

        m_destination = new RenderTexture(m_source.width, m_source.height, 0, RenderTextureFormat.Default);
        //m_destination.filterMode = FilterMode.Bilinear;
        //m_destination.generateMips = false;
        //m_destination.isCubemap = false;
        //m_destination.isPowerOfTwo = false;
        //m_destination.useMipMap = false;

        m_textureFog = new CObject(DEFINE.ASSETBUNDLE_PATH_FOG);
        m_textureFog.IsMemoryFactory = true;
        m_textureFog.ObjectType = eObjectType.Texture;
        m_textureFog.CallBack = LoadTextureCompleteed;
        m_textureFog.LoadObject();
        #endregion
    }

    private void LoadShaderCompleted(string interim, UnityEngine.Object asset)
    {
        m_shader = asset as Shader;

        m_material = CheckShaderAndCreateMaterial(m_shader, m_material);

        if (m_material == null || m_camera == null)
        {
            this.enabled = false;
            MyLog.LogError("Material = " + m_material + "\tShader = " + m_shader + "\tCamera = " + m_camera);
            m_startEffect = false;
            return;
        }

        m_pve = SingletonObject<BattlePveMediator>.GetInst();

        m_source = new RenderTexture((int)m_camera.pixelWidth, (int)m_camera.pixelHeight, 16, RenderTextureFormat.ARGB32);
        m_source.filterMode = FilterMode.Bilinear;
        m_source.generateMips = false;
        m_source.isCubemap = false;
        m_source.isPowerOfTwo = false;
        m_source.useMipMap = false;

        m_destination = new RenderTexture(m_source.width, m_source.height,0,RenderTextureFormat.Default);
        //m_destination.filterMode = FilterMode.Bilinear;
        //m_destination.generateMips = false;
        //m_destination.isCubemap = false;
        //m_destination.isPowerOfTwo = false;
        //m_destination.useMipMap = false;

        m_textureFog = new CObject(DEFINE.ASSETBUNDLE_PATH_FOG);
        m_textureFog.IsMemoryFactory = true;
        m_textureFog.ObjectType = eObjectType.Texture;
        m_textureFog.CallBack = LoadTextureCompleteed;
        m_textureFog.LoadObject();
    }

    private void LoadTextureCompleteed(GameObject o, params object[] args)
    {
        string path = GetTextureLoadPath(m_passTextureName,out m_pass);

        m_texturePass = new CObject(path);
        m_texturePass.IsMemoryFactory = true;
        m_texturePass.ObjectType = eObjectType.Texture;
        m_texturePass.CallBack = LoadTexturePassComplete;
        m_texturePass.LoadObject();
    }

    private void LoadTexturePassComplete(GameObject o, params object[] args)
    {
        m_material.SetVector("_Pass", m_pass);
        m_material.SetTexture("_PassTex", m_texturePass.PTexture2D);
        m_material.SetTexture("_FogTex", m_textureFog.PTexture2D);

        m_camera.targetTexture = m_source;
        m_camera.nearClipPlane = 20;
        m_startEffect = true;

        if (m_pve != null)
        {
            m_startH = m_pve.StartHeight;
            m_lenght = m_pve.Height;
        }
    }

    private float GetAlpha()
    {
        if (m_pve == null)
            return 1;

        float alpha = (m_startH - transform.position.y) / m_lenght;
        return Mathf.Clamp01(alpha);
    }

    private string GetTextureLoadPath(string name,out Vector4 pass)
    {
        m_nameWorldMap = transform.root.name;
        m_nameWorldMap = m_nameWorldMap.Trim();
        int len = m_nameWorldMap.Length;

        string temp = m_nameWorldMap.Substring(len - 2, 2);

        pass = Vector4.zero;
        int n;
        if (!int.TryParse(temp, out n))
        {
            MyLog.LogError("FogOfWarStatic Cam not ToInt32 string = " + temp);
            return string.Empty;
        }
        int tens_digit = (n - 1) / 4;
        int single_digit = n % 4;

        switch (single_digit)
        {
            case 1: pass = new Vector4(1, 0, 0, 0); break;
            case 2: pass = new Vector4(0, 1, 0, 0); break;
            case 3: pass = new Vector4(0, 0, 1, 0); break;
            case 0: pass = new Vector4(0, 0, 0, 1); break;
        }
        m_nameFogTexture = name + tens_digit.ToString() + ".tex";
        m_pathFogTexture = DEFINE.ASSETBUNDLE_PATH_FOG_PASS + m_nameFogTexture;
        return m_pathFogTexture;
    }

    public override void Release(bool needTexture = false)
    {
        if (m_textureFog != null)
        {
            m_textureFog.DestroyGameObject(eObjectDestroyType.Memory);
            m_textureFog = null;
        }
        if (m_source != null)
        {
            m_source.Release();
            Object.Destroy(m_source);
            m_source = null;
        }
        if (m_destination != null)
        {
            m_destination.Release();
            Object.Destroy(m_destination);
            m_destination = null;
        }
        if (m_camera != null)
        {
            m_camera.targetTexture = null;
            m_camera.nearClipPlane = 0.3f;
            m_camera = null;
        }
        if (m_material != null)
        {
            m_shader = null;
            DestroyImmediate(m_material);
        }

        m_startEffect = false;
    }

    public void UseDestinTexture(bool use)
    {
        m_useDestination = use;
    }
}
