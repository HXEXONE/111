﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CLoginStateManager {
    private LoginAvatar m_pLoginAvatar;
    private CBaseLoginState m_currState;
    private Dictionary<eloginActionState, CBaseLoginState> m_stateDict = new Dictionary<eloginActionState, CBaseLoginState>();
    
    public CLoginStateManager(LoginAvatar avatar)
    {
        m_pLoginAvatar = avatar;
        Reuse();
        RegisterState(new CLoginNormalState(avatar));
        RegisterState(new CLoginPoseState(avatar));
        RegisterState(new CLoginSelectedState(avatar));
        RegisterState(new CLoginUnselectState(avatar));    
    }

    private void RegisterState(CBaseLoginState pState)
    {
        eloginActionState eState = pState.GetState();
        if (!m_stateDict.ContainsKey(eState))
        {
            m_stateDict.Add(eState, pState);
        }
    }

    public void EnterState(eloginActionState state)
    {
        CBaseLoginState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            if (m_currState != null)
            {
                m_currState.LeaveState();
            }
            m_currState = pState;
            pState.EnterState();
        }
    }

    public void LeaveState(eloginActionState state)
    {
        CBaseLoginState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            if (m_currState != null && m_currState == pState)
            {
                pState.LeaveState();

                if (m_currState == pState && state == eloginActionState.dengLu_Pos)
                {
                    m_pLoginAvatar.EnterState(eloginActionState.dengLu_PoseIdle);
                }
                else if (m_currState == pState && state == eloginActionState.degnlu_HuiWei)
                {
                    m_pLoginAvatar.EnterState(eloginActionState.dengLu_Idle);
                }
            }
        }
    }

    public void Reuse()
    {
        m_currState = null;
    }

    public void Release()
    {
        m_pLoginAvatar = null;
        m_currState = null;
        m_stateDict.Clear();
        m_stateDict = null;
    }

    public void Update()
    {
        if (m_currState != null)
        {
            m_currState.Update();
        }
    }
}
