﻿using UnityEngine;
using System.Collections;

public class CKickout : CBaseConnectState
{
    public CKickout()
        : base(ConnectState.kickOut)
    {
 
    }
}
