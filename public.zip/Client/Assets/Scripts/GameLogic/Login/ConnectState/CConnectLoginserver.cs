﻿using UnityEngine;
using System.Collections;

public class CConnectLoginserver : CBaseConnectState
{
    public CConnectLoginserver()
        : base(ConnectState.connectLoginServer)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        if (operate == PlayerOperate.clickScreen)
        {
            SingletonObject<LoginScene>.GetInst().ConnectLoginServer();
        }
    }
}
