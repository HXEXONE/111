﻿using UnityEngine;
using System.Collections;

public class CEnterGame : CBaseConnectState {

    public CEnterGame()
        : base(ConnectState.enterGame)
    {
 
    }
}
