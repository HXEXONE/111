﻿using UnityEngine;
using System.Collections;

public class CCheckLogin : CBaseConnectState {

    public CCheckLogin()
        : base(ConnectState.checkLogin)
    {
 
    }

    //public override void DoExecute(PlayerOperate operate)
    //{
    //    base.DoExecute(operate);
    //    if (operate == PlayerOperate.clickScreen)
    //    {
    //        SingletonObject<LoginScene>.GetInst().LoginByPassword("", "", true);
    //    }
    //}
}
