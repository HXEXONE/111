﻿using UnityEngine;
using System.Collections;

public class CNologin : CBaseConnectState
{

    public CNologin()
        : base(ConnectState.noLogin)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        if (operate == PlayerOperate.clickScreen)
        {
            SingletonObject<LoginScene>.GetInst().ConnectLoginServer();
        }
    }
}
