﻿using UnityEngine;
using System.Collections;

public class CBaseConnectState {

    protected ConnectState m_state;
    protected bool isExecute = false;

    public CBaseConnectState(ConnectState state)
    {
        m_state = state;
    }

    public virtual void EnterState()
    {
 
    }

    public virtual void LeaveState()
    {
 
    }

    public virtual void DoExecute(PlayerOperate operate)
    {
        
    }


    public void ResetExecute()
    {
        isExecute = false;
        
    }
    public ConnectState GetState() { return m_state; }
}
