﻿using UnityEngine;
using System.Collections;

public class CRelogin : CBaseConnectState {

    public CRelogin()
        : base(ConnectState.relogin)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        if (operate == PlayerOperate.clickScreen)
        {
            SingletonObject<LoginScene>.GetInst().ConnectLoginServer();
        }
    }
}
