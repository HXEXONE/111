﻿using UnityEngine;
using System.Collections;

public class CReadyEnterGame : CBaseConnectState
{

    public CReadyEnterGame()
        : base(ConnectState.readyEnterGame)
    {

    }
}
