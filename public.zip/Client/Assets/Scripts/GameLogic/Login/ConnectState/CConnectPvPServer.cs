﻿using UnityEngine;
using System.Collections;


//PVP 战场服的链接状态

//链接pvp战场服状态
public class CConnectPvPServer : CBaseConnectState {

    public CConnectPvPServer()
        : base(ConnectState.connectPVPServer)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        //if (operate == PlayerOperate.)
        //{
        //    SingletonObject<LoginScene>.GetInst().ConnectGameServer();
        //}
    }
}

//链接成功准备进入pvp战场服
public class CReadyEnterPVP : CBaseConnectState
{

    public CReadyEnterPVP()
        : base(ConnectState.readyEnterPVP)
    {

    }
}
//进入pvp战场服，可以开打
public class CEnteringPVP : CBaseConnectState
{

    public CEnteringPVP()
        : base(ConnectState.enteringPVP)
    {

    }
}
//战斗结束准备重连game服
public class CDisconnectPVPServer : CBaseConnectState
{

    public CDisconnectPVPServer()
        : base(ConnectState.disconnectPVPServer)
    {

    }
}