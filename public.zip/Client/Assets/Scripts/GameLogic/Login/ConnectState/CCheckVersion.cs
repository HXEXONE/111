﻿using UnityEngine;
using System.Collections;

public class CCheckVersion : CBaseConnectState {

    public CCheckVersion()
        : base(ConnectState.checkVersion)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        //SingletonObject<LoginScene>.GetInst().CheckVersion();
    } 
}
