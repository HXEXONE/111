﻿using UnityEngine;
using System.Collections;

public class CConnectGameserver : CBaseConnectState {

    public CConnectGameserver()
        : base(ConnectState.connectGameServer)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        if (operate == PlayerOperate.clickScreen)
        {
            SingletonObject<LoginScene>.GetInst().ConnectGameServer();
        }
    }
}
