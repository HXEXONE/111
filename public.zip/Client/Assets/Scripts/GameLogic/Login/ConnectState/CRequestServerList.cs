﻿using UnityEngine;
using System.Collections;

public class CRequestServerList : CBaseConnectState {

    public CRequestServerList():base(ConnectState.requestServerList)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
        if (operate == PlayerOperate.clickScreen)
        {
            SingletonObject<LoginScene>.GetInst().ConnectLoginServer();
        }
    }
}
