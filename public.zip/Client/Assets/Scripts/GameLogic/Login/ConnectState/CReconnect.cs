﻿using UnityEngine;
using System.Collections;

public class CReconnect : CBaseConnectState {

    public CReconnect()
        : base(ConnectState.reconnect)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
    }
}
