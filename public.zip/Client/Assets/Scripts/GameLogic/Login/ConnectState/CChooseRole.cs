﻿using UnityEngine;
using System.Collections;

public class CChooseRole : CBaseConnectState {

    public CChooseRole():base(ConnectState.chooseRole)
    {
 
    }

    public override void DoExecute(PlayerOperate operate)
    {
        base.DoExecute(operate);
    }
}
