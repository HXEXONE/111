﻿using UnityEngine;
using System.Collections;

public class CBaseLoginState {

    protected LoginAvatar m_avatar;
    protected eloginActionState m_state;

    public CBaseLoginState(LoginAvatar avatar, eloginActionState state)
    {
        m_avatar = avatar;
        m_state = state;
    }

    protected float GetActionTime()
    {
        return m_avatar.PlayActionTime;
        //CAnimatorStateInfo info = m_avatar.GetPlayAniState();

        //if (null == info || !info.bStartPlay)
        //{
            //MyLog.LogError(" _______ action state : " + m_state + " info.bStartPlay : " + info.bStartPlay);
            //return -1;
        //}
        //return info.state.length / info.aniSpeed;
    }

    public virtual void EnterState()
    {
        if (m_avatar != null)
        {
            m_avatar.PlayAction(m_state, 1, false);
            m_avatar.PlayParticle(m_state);
        }
    }

    public virtual void LeaveState()
    {
        if (m_avatar != null)
        {
            m_avatar.StopParticle(m_state);
        }
    }

    public virtual void Update()
    {

    }

    public eloginActionState GetState() { return m_state; }
}
