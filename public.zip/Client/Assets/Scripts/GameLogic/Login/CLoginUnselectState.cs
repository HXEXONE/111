﻿using UnityEngine;
using System.Collections;

public class CLoginUnselectState : CLoginTimerState
{

    public CLoginUnselectState(LoginAvatar avatar)
        : base(avatar, eloginActionState.degnlu_HuiWei)
    {
 
    }

    public override void EnterState()
    {
        base.EnterState();
        m_avatar.StopPoseMusic(); //此处再把音效停止 
    }

    public override void LeaveState()
    {
        base.LeaveState();
    }

    public override void Update()
    {
        base.Update();

        if (m_pTimer.IsExpired(false))
        {
            m_avatar.LeaveState(eloginActionState.degnlu_HuiWei);
        }
        if (m_eCheckState == eCheckActState.StartCheck)
        {
            float fActionTime = GetActionTime();
            //MyLog.LogError(" CLoginUnselectState fActionTime: " + fActionTime);
            if (fActionTime != -1)
            {
                m_pTimer.SetTimer(fActionTime);
                m_eCheckState = eCheckActState.CheckOver;
            }
        } 
    }
}
