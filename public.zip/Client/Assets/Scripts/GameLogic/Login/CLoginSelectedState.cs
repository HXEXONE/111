﻿using UnityEngine;
using System.Collections;

public class CLoginSelectedState : CLoginTimerState
{
    public CLoginSelectedState(LoginAvatar avatar)
        : base(avatar, eloginActionState.dengLu_Pos)
    {
 
    }

    public override void EnterState()
    {
        m_avatar.PlayerPoseMusic();
        base.EnterState();
    }

    public override void LeaveState()
    {
        //m_avatar.StopPoseMusic();
        base.LeaveState();
    }

    public override void Update()
    {
        base.Update();

        if (m_pTimer.IsExpired(false))
        {
            m_avatar.LeaveState(eloginActionState.dengLu_Pos);
        }
        if (m_eCheckState == eCheckActState.StartCheck)
        {
            float fActionTime = GetActionTime();
            //MyLog.LogError(" CLoginSelectedState fActionTime: " + fActionTime);
            if (fActionTime != -1)
            {
                m_pTimer.SetTimer(fActionTime);
                m_eCheckState = eCheckActState.CheckOver;
            }
        } 
    }
}
