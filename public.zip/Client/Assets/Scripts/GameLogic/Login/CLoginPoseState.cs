﻿using UnityEngine;
using System.Collections;

public class CLoginPoseState : CBaseLoginState {

    public CLoginPoseState(LoginAvatar avatar)
        : base(avatar, eloginActionState.dengLu_PoseIdle)
    {
        
    }

    public override void EnterState()
    {
        base.EnterState();
    }

    public override void LeaveState()
    {
        base.LeaveState();
    }

    public override void Update()
    {
        base.Update();
    }
}
