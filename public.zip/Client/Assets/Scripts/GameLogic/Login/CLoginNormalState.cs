﻿using UnityEngine;
using System.Collections;

public class CLoginNormalState : CBaseLoginState {

    public CLoginNormalState(LoginAvatar avatar)
        : base(avatar, eloginActionState.dengLu_Idle)
    {
 
    }
}
