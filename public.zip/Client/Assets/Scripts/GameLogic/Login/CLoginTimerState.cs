﻿using UnityEngine;
using System.Collections;

public class CLoginTimerState : CBaseLoginState {

    protected eCheckActState m_eCheckState;
    protected Timer m_pTimer = new Timer();
    public CLoginTimerState(LoginAvatar avatar, eloginActionState state)
        : base(avatar, state)
    {
 
    }

    public override void EnterState()
    {
        base.EnterState();
        m_eCheckState = eCheckActState.StartCheck;
        m_pTimer.Release();
    }

    public override void LeaveState()
    {
        base.LeaveState();
    }

    public override void Update()
    {
        base.Update();
    }
}
