﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LoginAvatar
{
    private PlayerConfigContent m_pPlayerLoader;
    private CCharacterInfo m_pRoleInfo;
    private CAnimator m_pAnimator;
    private CObject m_pNpcObj;
    private CObject m_pLeftWeaponObject;//左手武器
    private CObject m_pRightWeaponObject;//右手武器
    private Vector3 localPosition_;
    private Quaternion localRotation_;
    private Vector3 locaScale_;
    private Transform m_myTrans;
    private Transform parent_;
    private string amimatorPath_;
    private CharacterJob m_job;
    private CLoginStateManager m_stateMgr;
    private Material[] m_materials;
    private Material[] m_LeftWeapons;
    private Material[] m_RightWeapon;

    //private bool IsTweenColor = false;
    //private float speed = 1.2f;
    //private float m_alpha = 0f;
    private List<LoginStateParticle> m_LoginStateParticle = new List<LoginStateParticle>();

    private const string DENGLU_IDLE = "denglu_idle";
    private const string DENGLU_POSE = "denglu_pose";
    private const string DENGLU_POSEIDLE = "denglu_poseidle";
    private const string DENGLU_HUIWEI = "denglu_huiwei";

    private List<int> mSoundId = new List<int>();
    private List<CSound> mCSound = new List<CSound>();

    public class LoginStateParticle
    {
        public uint Id = 0;
        public uint m_uiParticleIndex = 0;
        public eloginActionState m_CreatInState;
        public eloginActionState m_RemoveInState;
    }

    public void Creat(CCharacterInfo character, Transform parent)
    {
        m_pRoleInfo = character;
        parent_ = parent;
        m_pPlayerLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(character.uiPlayerJob);
        EquipContent clothes = null;
        PlayerContent m_ctrl = HolderManager.m_PlayerHolder.GetStaticInfo(character.uiPlayerJob);
        if (character.uiClothesId != 0)
            clothes = HolderManager.m_EquipHolder.GetStaticInfo(character.uiClothesId);
        else
        {
            clothes = HolderManager.m_EquipHolder.GetStaticInfo(m_pPlayerLoader.Clothes);
        }
        if (clothes == null || m_ctrl == null)
        {
            return;
        }
        List<string> PathList_ = clothes.ModelLoader.ModelPath;
        string avatarPath = PathList_[0];

        //string tempPath = m_ctrl.GetAmimatorPath();
        //int findIndex = tempPath.LastIndexOf("_ctrl");
        //amimatorPath_ = tempPath.Insert(findIndex, "_home"); 
        amimatorPath_ = Common.ReplaceHomeAniPath(m_ctrl.AmimatorPath);

        if (PathList_ == null || PathList_.Count <= 0 || PathList_[0] == "0")
        {
            return;
        }
        mSoundId = m_ctrl.PoseSound;
        string objName = null;
        LoginStateParticle lsp = null;
        switch (character.uiPlayerJob)
        {
            case DEFINE.JOB_ID_CHIKE:
                localPosition_ = new Vector3(-0.2103041f, -0.6710575f, 0.0101409f);
                localRotation_ = Quaternion.Euler(new Vector3(0, 270f, 0));
                locaScale_ = new Vector3(0.1415802f, 0.1415802f, 0.1415802f);
                objName = "cike_1_model";
                m_job = CharacterJob.chiKe;

                if (character.uiWeaponId % 10000 / 100 == 1)
                {
                    lsp = new LoginStateParticle();
                    m_LoginStateParticle.Add(lsp);
                    lsp.Id = DEFINE.LOGIN_CK_L_WEA;
                    lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                    lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;

                    lsp = new LoginStateParticle();
                    m_LoginStateParticle.Add(lsp);
                    lsp.Id = DEFINE.LOGIN_CK_R_WEA;
                    lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                    lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;
                }
               

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_CK_STP;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_Pos;

                break;
            case DEFINE.JOB_ID_FASHI:
                localPosition_ = new Vector3(0.2040154f, -0.6736083f, 0.009831115f);
                localRotation_ = Quaternion.Euler(new Vector3(0, 90f, 0));
                locaScale_ = new Vector3(0.1415802f, 0.1415802f, 0.1415802f);
                objName = "fashi_1_model";
                m_job = CharacterJob.faShi;

                if (character.uiWeaponId % 10000 / 100 == 1)
                {
                    lsp = new LoginStateParticle();
                    m_LoginStateParticle.Add(lsp);
                    lsp.Id = DEFINE.LOGIN_FS_R_WEA;
                    lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                    lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;
                }
               

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_FS_STP_T;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_FS_STP_O;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_Pos;

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_FS_HAND;
                lsp.m_CreatInState = eloginActionState.dengLu_PoseIdle;
                lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;
                break;
            case DEFINE.JOB_ID_KUANGZHANSHI:
                localPosition_ = new Vector3(-0.01661836f, -0.6687105f, 0.2197629f);
                localRotation_ = Quaternion.Euler(new Vector3(0, 0, 0));
                locaScale_ = new Vector3(0.1415802f, 0.1415802f, 0.1415802f);
                objName = "kuangzhanshi_1_model";
                m_job = CharacterJob.kuangzhanshi;

                if (character.uiWeaponId % 10000 / 100 == 1)
                {
                    lsp = new LoginStateParticle();
                    m_LoginStateParticle.Add(lsp);
                    lsp.Id = DEFINE.LOGIN_KZS_R_WEA;
                    lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                    lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;
                }
               

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_KZS_STP;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_Pos;
                break;
            case DEFINE.JOB_ID_SHENGWUSHI:
                localPosition_ = new Vector3(-0.008833623f, -0.6615733f, -0.1969482f);
                localRotation_ = Quaternion.Euler(new Vector3(0, 180, 0));
                locaScale_ = new Vector3(0.1415802f, 0.1415802f, 0.1415802f);
                objName = "shengwushi_1_model";
                m_job = CharacterJob.shengwushi;

                if (character.uiWeaponId % 10000 / 100 == 1)
                {
                    lsp = new LoginStateParticle();
                    m_LoginStateParticle.Add(lsp);
                    lsp.Id = DEFINE.LOGIN_SWS_R_WEA;
                    lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                    lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;
                }
                

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_SWS_STP_O;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_PoseIdle;

                lsp = new LoginStateParticle();
                m_LoginStateParticle.Add(lsp);
                lsp.Id = DEFINE.LOGIN_SWS_STP_T;
                lsp.m_CreatInState = eloginActionState.dengLu_Pos;
                lsp.m_RemoveInState = eloginActionState.dengLu_Pos;
                break;
            default:
                MyLog.LogError("have no this job id");
                return;
        }

        m_stateMgr = new CLoginStateManager(this);
        m_pNpcObj = new CObject(avatarPath);
        m_pNpcObj.Name = objName;
        m_pNpcObj.CallBack = RoleRoadCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = eObjectType.HomeAvatar;
        m_pNpcObj.Layer = DEFINE.AVATAR_LAYER;
        m_pNpcObj.LoadObject();
    }

    private void RoleRoadCompleted(GameObject o, params object[] args)
    {
        if (null == o) { MyLog.LogError("Error "); return; }
        m_myTrans = o.transform;
        m_myTrans.parent = parent_;
        m_myTrans.localPosition = localPosition_;
        m_myTrans.localRotation = localRotation_;
        m_myTrans.localScale = locaScale_;

        Common.ShowAvatarClothes(o, false);

        CharacterController character = o.GetComponent<CharacterController>();
        if (character != null) character.enabled = false;
        EquipContent pWeaponLoader = null;
        if (m_pRoleInfo != null && m_pRoleInfo.uiWeaponId != 0)
        {
            pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(m_pRoleInfo.uiWeaponId);
        }
        else
        {
            pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(m_pPlayerLoader.Weapon);
        }
        if (null != pWeaponLoader)
        {
            List<string> pathArray = pWeaponLoader.ModelLoader.ModelPath;
            if (!(pathArray[0] == "0"))
            {
                m_pLeftWeaponObject = new CObject(pathArray[0]);
                m_pLeftWeaponObject.CallBack = LoadLeftWeaponCompleted;
                m_pLeftWeaponObject.IsMemoryFactory = true;
                m_pLeftWeaponObject.ObjectType = eObjectType.Weapon;
                m_pLeftWeaponObject.Layer = DEFINE.AVATAR_LAYER;
                m_pLeftWeaponObject.LoadObject();
            }
            if (!(pathArray[1] == "0"))
            {
                m_pRightWeaponObject = new CObject(pathArray[1]);
                m_pRightWeaponObject.CallBack = LoadRightWeaponCompleted;
                m_pRightWeaponObject.IsMemoryFactory = true;
                m_pRightWeaponObject.ObjectType = eObjectType.Weapon;
                m_pRightWeaponObject.Layer = DEFINE.AVATAR_LAYER;
                m_pRightWeaponObject.LoadObject();
            }
        }
    }

    private void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        if (null == o) { MyLog.LogError("Error"); return; }
        o.transform.parent = Common.GetBone(m_myTrans, "Bip01 Prop2");
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        MeshRenderer[] m_mr = o.GetComponentsInChildren<MeshRenderer>();
        if (m_mr != null && m_mr[0] != null)
        {
            m_LeftWeapons = m_mr[0].sharedMaterials;
        }
        if (m_LeftWeapons != null && m_LeftWeapons.Length > 0 && m_LeftWeapons[0] != null)
        {
            m_LeftWeapons[0].shader = DynamicShader.GetShader("MyMobile/Illumin/Diffuse");//Mobile/Unlit(Supports Lightmap) MobileLightmapUnlit
            m_LeftWeapons[0].SetFloat("_AlphaCon", 0f);
        }
    }

    private void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        if (null == o) { MyLog.LogError("Error ："); return; }
        o.transform.parent = Common.GetBone(m_myTrans, "Bip01 Prop1");
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        MeshRenderer[] m_mr = o.GetComponentsInChildren<MeshRenderer>();
        if (m_mr != null && m_mr[0] != null)
        {
            m_RightWeapon = m_mr[0].sharedMaterials;
        }
        if (m_RightWeapon != null && m_RightWeapon.Length > 0 && m_RightWeapon[0] != null)
        {
            m_RightWeapon[0].shader = DynamicShader.GetShader("MyMobile/Illumin/Diffuse");//Mobile/Unlit(Supports Lightmap)
            m_RightWeapon[0].SetFloat("_AlphaCon", 0f);
        }
        LoadAcnimatorCtrl();
    }

    private void LoadAcnimatorCtrl()
    {
        SkinnedMeshRenderer[] smrrenderer = m_myTrans.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (smrrenderer != null)
        {
            for (int i = 0; i < smrrenderer.Length; i++)
            {
                if (!smrrenderer[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_materials = smrrenderer[i].sharedMaterials;
                    m_materials[0].shader = DynamicShader.GetShader("MyMobile/Illumin/Diffuse");
                    m_materials[0].SetFloat("_AlphaCon", 0f);
                    break;
                }
            }
        }

        if (amimatorPath_ != null)
        {
            Animator aniCtrl = m_myTrans.GetComponent<Animator>();
            if (null == aniCtrl)
            {
                MyLog.LogError(amimatorPath_ + " can not find animator Component !  ");
                return;                
            }

            if (null == aniCtrl.runtimeAnimatorController)
            {
                LoadHelp.LoadObject("", amimatorPath_, ThreadPriority.Normal, LoadAcnimatorCtrlCompleted);
            }
            else
            {
                BuildAnimator(aniCtrl);
            }
        }      
    }

    private void LoadAcnimatorCtrlCompleted(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        Animator aniCtrl = m_myTrans.GetComponent<Animator>();
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//         if (null == aniCtrl)
//         {
//             aniCtrl = m_myTrans.gameObject.AddComponent<Animator>();
//             aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//             aniCtrl.avatar = animator.avatar;
//             aniCtrl.applyRootMotion = false;
//         }
        //aniCtrl.enabled = true;
        //m_pAnimator = new CAnimator(aniCtrl);

        //LoginScene scene = SingletonObject<LoginScene>.GetInst();
        //if (scene.GetCurrentSelectJob() == m_job)
        //{
        //    //上次登录的界面不要了
        //    //if (scene.GetCurrentState() == LoginScene.loginStage.chooseJob)
        //        EnterState(eloginActionState.dengLu_Pos);
        //    //else
        //    //{
        //    //    EnterState(eloginActionState.dengLu_Idle);
        //    //    PlayParticle(DEFINE.LOGIN_GROUD);
        //    //}
        //}
        //else
        //{
        //    EnterState(eloginActionState.dengLu_Idle);
        //}

        ////IsTweenColor = true;
        //SetShadow(false);
        BuildAnimator(aniCtrl);
    }

    private void BuildAnimator(Animator animator) 
    {
        animator.enabled = true;
        m_pAnimator = new CAnimator(animator);

        LoginScene scene = SingletonObject<LoginScene>.GetInst();
        if (scene.GetCurrentSelectJob() == m_job)
        {
            //上次登录的界面不要了
            //if (scene.GetCurrentState() == LoginScene.loginStage.chooseJob)
            EnterState(eloginActionState.dengLu_Pos);
            //else
            //{
            //    EnterState(eloginActionState.dengLu_Idle);
            //    PlayParticle(DEFINE.LOGIN_GROUD);
            //}
        }
        else
        {
            EnterState(eloginActionState.dengLu_Idle);
        }

        //IsTweenColor = true;
        SetShadow(false);
    }

    public void SetShadow(bool show)
    {
        if (m_pNpcObj == null) return;
        GameObject obj = m_pNpcObj.GetObj();
        if (null == obj) return;
        Transform tf = obj.transform;
        tf = tf.FindChild("shadow");
        if (tf != null)
        {
            tf.gameObject.SetActive(show);
        }
    }

    public uint GetJobId()
    {
        switch (m_job)
        {
            case CharacterJob.chiKe:
                return DEFINE.JOB_ID_CHIKE;
            case CharacterJob.faShi:
                return DEFINE.JOB_ID_FASHI;
            case CharacterJob.kuangzhanshi:
                return DEFINE.JOB_ID_KUANGZHANSHI;
            case CharacterJob.shengwushi:
                return DEFINE.JOB_ID_SHENGWUSHI;
        }
        MyLog.LogError("m_job: " + "have no this job id");
        return 0;
    }

    public CharacterJob GetLoginAvatarjob()
    {
        return m_job;
    }

//     public CAnimatorStateInfo GetPlayAniState()
//     {
//         if (null == m_pAnimator) return null;
// 
//         return m_pAnimator.GetAnimatorInfo();
//     }

    public float PlayActionTime
    {
        get
        {
            if (null == m_pAnimator) return -1f;

            return m_pAnimator.ActionTime;
        }
    }

    public void PlayAction(eloginActionState state, float fSpeed = 1.0f, bool bRepeat = true)
    {
        if (null != m_pAnimator)
        {
            string actionName = GetActionName(state);
            if (actionName != null)
            m_pAnimator.PlayAction(actionName, fSpeed, bRepeat);
        }
    }

    private string GetActionName(eloginActionState state)
    {
        switch (state)
        {
            case eloginActionState.dengLu_Idle:
                return DENGLU_IDLE;
            case eloginActionState.dengLu_Pos:
                return DENGLU_POSE;
            case eloginActionState.dengLu_PoseIdle:
                return DENGLU_POSEIDLE;
            case eloginActionState.degnlu_HuiWei:
                return DENGLU_HUIWEI;
        }
        return null;
    }

    public void EnterState(eloginActionState state)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.EnterState(state);
        }
    }

    public void LeaveState(eloginActionState state)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.LeaveState(state);
        }
    }

    public void SetShow(bool show)
    {
        if (m_pNpcObj == null) return;
        m_pNpcObj.GetObj().SetActive(show);
        if (m_pLeftWeaponObject != null)
        {
            m_pLeftWeaponObject.GetObj().SetActive(show);
        }
        if (m_pRightWeaponObject != null)
        {
            m_pRightWeaponObject.GetObj().SetActive(show);
        }
    }

    public string GetJobName()
    {
         PlayerContent loader = null;
        if (m_pPlayerLoader != null)
        {
            loader = HolderManager.m_PlayerHolder.GetStaticInfo(m_pPlayerLoader.Key);
        }
        if (loader != null)
        {
           return Common.GetText(loader.NpcName);
        }
        return null;
    }

    public string GetJobInfo()
    {
        PlayerContent loader = null;
        if (m_pPlayerLoader != null)
        {
            loader = HolderManager.m_PlayerHolder.GetStaticInfo(m_pPlayerLoader.Key);
        }
        if (loader != null)
        {
            return Common.GetText(loader.Describe);
        }
        return null;
    }

    public uint GetLevel()
    {
        if (m_pRoleInfo != null)
        {
            return m_pRoleInfo.uiPlayerLevel;
        }
        return 1;
    }

    //public void SetRoleInfo(CCharacterInfo info)
    //{
    //    m_pRoleInfo = info;
    //}

    public CCharacterInfo GetRoleInfo()
    {
        return m_pRoleInfo;
    }

    public GameObject GetAvatarObj()
    {
        if (m_pNpcObj != null)
            return m_pNpcObj.GetObj();
        return null;
    }

    public void Release(eObjectDestroyType type)
    {
        m_pPlayerLoader = null;
        m_pRoleInfo = null;
        m_pAnimator = null;
        m_myTrans = null;
        parent_ = null;
        amimatorPath_ = null;
        if (null != m_stateMgr)
        {
            m_stateMgr.Release();
            m_stateMgr = null;
        }
        m_materials = null;
        m_LeftWeapons = null;
        m_RightWeapon = null;

        SetShadow(true);
        if (null != m_pNpcObj)
        {
            m_pNpcObj.DestroyGameObject(type);
            m_pNpcObj = null;
        }
        
        if (m_pLeftWeaponObject != null)
        {
            m_pLeftWeaponObject.DestroyGameObject(type);
            m_pLeftWeaponObject = null;
        }
        if (m_pRightWeaponObject != null)
        {
            m_pRightWeaponObject.DestroyGameObject(type);
            m_pRightWeaponObject = null;
        }
        m_LoginStateParticle.Clear();
    }

    //private void TweenAlpha()
    //{
    //    m_alpha += speed * Time.deltaTime;
    //    if (m_materials != null && m_materials[0] != null)
    //    {
    //        m_materials[0].SetFloat("_AlphaCon", m_alpha);
    //    }
    //    if (m_LeftWeapons != null && m_LeftWeapons[0] != null)
    //    {
    //        m_LeftWeapons[0].SetFloat("_AlphaCon", m_alpha);
    //    }
    //    if (m_RightWeapon != null && m_RightWeapon[0] != null)
    //    {
    //        m_RightWeapon[0].SetFloat("_AlphaCon", m_alpha);
    //    }
    //    if (m_alpha >= 1)
    //    {
    //        IsTweenColor = false;
    //        if (m_materials != null && m_materials[0] != null)
    //        {
    //            m_materials[0].SetFloat("_AlphaCon", 1f);
    //        }
    //        if (m_LeftWeapons != null && m_LeftWeapons[0] != null)
    //        {
    //            m_LeftWeapons[0].SetFloat("_AlphaCon", 1f);
    //        }
    //        if (m_RightWeapon != null && m_RightWeapon[0] != null)
    //        {
    //            m_RightWeapon[0].SetFloat("_AlphaCon", 1f);
    //        }
    //    }
    //}

    public void PlayParticle(eloginActionState state)
    {
        GameObject obj = GetAvatarObj();
        if (null == obj)
        {
            return;
        }
        foreach (LoginStateParticle m_lsp in m_LoginStateParticle)
        {
            if ((uint)state > (uint)m_lsp.m_RemoveInState && m_lsp.m_uiParticleIndex != 0)
            {
                CParticleManager.GetInst().AddDestroyParticle(m_lsp.m_uiParticleIndex);
                m_lsp.m_uiParticleIndex = 0;
            }
            if (m_lsp.m_CreatInState == state)
            {
                m_lsp.m_uiParticleIndex = CParticleManager.GetInst().CreateBindEffect(m_lsp.Id, obj);
            }
        }
    }

    public void PlayParticle(uint id)
    {
        GameObject obj = GetAvatarObj();
        if (null == obj)
        {
            return;
        }
        LoginStateParticle m_lsp = new LoginStateParticle();
        m_lsp.Id = id;
        m_lsp.m_CreatInState = eloginActionState.dengLu_null;
        m_lsp.m_RemoveInState = eloginActionState.dengLu_null;
        m_lsp.m_uiParticleIndex = CParticleManager.GetInst().CreateBindEffect(id, obj);
        m_LoginStateParticle.Add(m_lsp);
    }

    public void StopParticle(eloginActionState state)
    {
        foreach (LoginStateParticle m_lsp in m_LoginStateParticle)
        {
            if (m_lsp.m_RemoveInState == state && m_lsp.m_uiParticleIndex != 0)
            {
                CParticleManager.GetInst().AddDestroyParticle(m_lsp.m_uiParticleIndex);
                m_lsp.m_uiParticleIndex = 0;
            }
        }
    }

    public void StopParticle(uint id)
    {
        foreach (LoginStateParticle m_lsp in m_LoginStateParticle)
        {
            if (m_lsp.Id == id)
            {
                CParticleManager.GetInst().AddDestroyParticle(m_lsp.m_uiParticleIndex);
                m_LoginStateParticle.Remove(m_lsp);
                break;
            }
        }
    }

    public void PlayerPoseMusic()
    {
        if (null == m_myTrans)
        {
            return;
        }
        mCSound.Clear();
        for (int i = 0, len = mSoundId.Count; i < len; i++ )
        {
            CSound sound = CMusicManager.GetInst().CreateSound(m_myTrans.gameObject, (uint)mSoundId[i]);
            mCSound.Add(sound);
        }       
    }

    public void StopPoseMusic()
    {
        for (int i = 0, len = mCSound.Count; i < len; i++)
        {
            if ( null != mCSound[i])
            {
                mCSound[i].Stop(true);
            }
        }
        mCSound.Clear();
    }

    public void Updata()
    {
        if (null == m_myTrans)
        {
            return;
        }

        if (m_stateMgr != null)
        {
            m_stateMgr.Update();
        }
        if (m_pAnimator != null)
        {
            m_pAnimator.Update();
        }
        //if (IsTweenColor)
        //{
        //    TweenAlpha();
        //}
    }
}
