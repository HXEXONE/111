﻿using UnityEngine;
using System.Collections;
using Protocol;
using System.IO;
using Network;

public class TestLogin : SingletonObject<TestLogin>
{
    public void Init()
    {
        NetworkClient.GetNetworkClient().AddOnMessageHandler((ushort)ProCL.LOGIN_ACK_CLIENT_CHECK, LoginResult,false);

        NetworkClient.GetNetworkClient().AddOnMessageHandler((ushort)NetworkClient.MessageID_Connected, ConnectSuccess,false);
        NetworkClient.GetNetworkClient().AddOnMessageHandler((ushort)NetworkClient.MessageID_Disconnect, Disconnect,false);
        NetworkClient.GetNetworkClient().AddOnMessageHandler((ushort)NetworkClient.MessageID_ConnectFailed, ConnectFailed,false);
    }

    private void ConnectSuccess(BinaryReader br)
    {
        MyLog.Log("connect success");
    }

    private void Disconnect(BinaryReader br)
    {
        MyLog.Log("Disconnect");
    }

    private void ConnectFailed(BinaryReader br)
    {
        MyLog.Log("connect failed");
    }

    public void Requestlogin()
    {
        //C2LAccountLogin login = new C2LAccountLogin();
        //login.name = "test";
        //login.password = "111";
        //Network.NetworkClient.GetNetworkClient().SendMessage((ushort)ProCL.CLIENT_REQUEST_LOGIN_CHECK, login);
    }

    private void LoginResult(BinaryReader br)
    {
        //MyLog.Log("rev  LoginResult !!!!!!!!!");
        //L2CAccountLoginResult msg = new L2CAccountLoginResult();
        //msg.Read(br);

        //MyLog.Log("result ===" + msg.result);
        //MyLog.Log("accountId ===" + msg.accountId);
        //MyLog.Log("accessCode ===" + msg.accessCode);
    }
}
