﻿using UnityEngine;
using System.Collections;

public class CNpcLoaderStory : CBaseStory {

    private uint m_npcMapID;
    private uint m_npcID = 0;
    private ushort m_level;
    private Vector3 m_position;

    private int m_monsterType; //0  Monster, 1 HomeMonster, 2 HomeMonsterWithoutGravity. if battle scene default 0, if home scene default 1

    public CNpcLoaderStory()
    {
        m_type = eCameraStoryType.NPC_LOAD;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        m_npcMapID = MyConvert_Convert.ToUInt32(m_list[0]);

        SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(m_npcMapID);
        if (npcmap != null)
            m_npcID = GetCurrentJobNpcID(npcmap);
        m_level = MyConvert_Convert.ToUInt16(m_list[1]);
        m_position = info.PointDirect;

        if (CInitStory.curState != eGameState.Home)
            m_monsterType = 0;
        else
        {
            m_monsterType = 1;
            if (m_list.Count == 3)
                m_monsterType = MyConvert_Convert.ToInt32(m_list[2]);
        }
    }

    protected override void Enter()
    {
        base.Enter();
        Quaternion rotation = Quaternion.identity;
        if (m_lookAt != null)
        {
            Vector3 dir = m_lookAt.transform.position.normalized;
            rotation = Quaternion.FromToRotation(Vector3.forward, dir);
        }
        if (CInitStory.curState != eGameState.Home)
            SingletonObject<BattleScene>.GetInst().CreateMonster(m_npcID, m_level, m_position, rotation, "");
        else
        {
            MonsterContent info = HolderManager.m_MonsterHolder.GetStaticInfo(m_npcID);
            if (info != null)
            {
                uint modelID = (uint)info.ModelLoaderKey;
                SingletonObject<HomeScene>.GetInst().CreateHomeMonster(m_monsterType ,m_npcID, modelID, m_position, rotation);
            }
        }

        m_currentCreate.Add(m_npcID);
    }

    //protected override void Leave()
    //{
    //    base.Leave();
    //    CBaseNpc npc = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_npcID);
    //    if (npc != null)
    //    {
    //        if (m_lookAt != null)
    //        {
    //            Vector3 point = m_lookAt.transform.position;
    //            point.y = npc.GetTransform().position.y;
    //            npc.GetTransform().LookAt(point);
    //        }
    //    }
    //}
}
