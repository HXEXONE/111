﻿using UnityEngine;
using System.Collections;

public class CTextureStory : CBaseStory {

    private string m_path = "";
    private string m_m_previousPath = "";

    private float m_fadeTime = 0;

    private Texture2D m_tex;
    private bool m_loadComplete = false;

    public CTextureStory()
    {
        //m_type = eCameraStoryType.TEXTURE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        m_loadComplete = false;

        m_path = m_list[0];
        
        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_fadeTime = info.LastTime;
        if (m_path == "0" || string.IsNullOrEmpty(m_path))
        {
            m_loadComplete = true;
            SingletonObject<TaskMediator>.GetInst().PlotBgAlphaTo(null, m_fadeTime);
            return;
        }

        m_path = DEFINE.ASSETBUNDLE_PATH_TEXTURE + m_path;

        LoadHelp.LoadObject("", m_path, ThreadPriority.Normal, LoadComplete);
    }

    protected override void Wait()
    {
        if (m_loadComplete)
            base.Wait();
    }

    protected override void Enter()
    {
        base.Enter();
        SingletonObject<TaskMediator>.GetInst().PlotBgAlphaTo(m_tex, m_fadeTime);
    }

    protected override void Leave()
    {
        base.Leave();
        LoadHelp.RemoveObject(m_m_previousPath);
        m_m_previousPath = m_path;
        m_loadComplete = false;
        m_path = "";
    }

    private void LoadComplete(string interim, UnityEngine.Object asset)
    {
        m_loadComplete = true;
        m_tex = asset as Texture2D;
    }
}
