﻿using UnityEngine;
using System.Collections;

public class CNpcUnloaderStory : CBaseStory {

    private uint m_npcMapID;
    private uint m_npcID = 0;
    private CBaseNpc m_npc;

    private BattleScene m_bs;

    private bool m_directRemove = true;

    public CNpcUnloaderStory()
    {
        m_type = eCameraStoryType.NPC_UNLOAD;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
        m_npcMapID = MyConvert_Convert.ToUInt32(m_list[0]);
        SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(m_npcMapID);
        if (npcmap != null)
            m_npcID = GetCurrentJobNpcID(npcmap);

        if (CInitStory.curState != eGameState.Home)
        {
            int temp = MyConvert_Convert.ToInt32(m_list[1]);
            m_directRemove = MyConvert_Convert.ToBoolean(temp);
            m_bs = SingletonObject<BattleScene>.GetInst();
            m_npc = m_bs.GetNpcTrans(m_npcID);
        }
    }

    protected override void Enter()
    {
        base.Enter();
        if (CInitStory.curState != eGameState.Home)
        {
            if (m_npc != null)
            {
                float lastTime = m_info.LastTime;
                if (lastTime > 0)
                    m_npc.SetAlphaVertexColorOff(lastTime);
            }
        }
        
    }

    protected override void Leave()
    {
        if (CInitStory.curState != eGameState.Home)
        {
            if (m_npc != null)
            {
                if (m_directRemove)
                {
                    m_bs.RemoveMonsterIndex(m_npc.Index, m_npc);
                }
                else
                {
                    m_npc.NpcDead(true);
                }
                m_npc = null;
            }
            else
            {
                MyLog.LogWarning("can not find Npc : " + m_npcID.ToString());
            }
        }
        else
        {
            SingletonObject<HomeScene>.GetInst().RemoveHomeMonster(m_npcID);
        }

        if (m_currentCreate.Contains(m_npcID))
        {
            m_currentCreate.Remove(m_npcID);
        }
        else
        {
            MyLog.LogWarning("The NpcID : " + m_npcID.ToString() + " not Contains in list.");
        }

        base.Leave();
    }
}
