﻿using UnityEngine;
using System.Collections;

public class CAvatarMoveStory : CBaseStory {

    private Vector3 m_moveToPosition;   //Get info
    private Avatar m_avatar;
    private CPlayer m_homeAvatar;
    private Pet pet;
    private bool m_arrive = false;

    private bool m_camFollow;
    private Transform m_camRarent;
    private bool m_directMove = false;

    private uint m_behave = 0;   //行为  1 移动   2 旋转

    private float m_rotationSpeed;
    private Quaternion m_rotation;

    private Animator m_animator;

    public CAvatarMoveStory()
    {
        m_type = eCameraStoryType.AVATAR_MOVE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState != eGameState.Home)
        {
            m_avatar = SingletonObject<Avatar>.GetInst();
            pet = m_avatar.MyPet;
        }
        else
        {
            m_homeAvatar = SingletonObject<CPlayer>.GetInst();
        }

        m_moveToPosition = info.PointDirect;
        m_camFollow = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));
        m_camFollow = true;
        m_behave = MyConvert_Convert.ToUInt32(m_list[1]);

        m_camRarent = m_sceneCamObj.transform.parent;
        m_arrive = false;
        //SetContinueTimeToNull();
        float lastTime = info.LastTime;

        m_directMove = (lastTime == 0);

        if (CInitStory.curState == eGameState.Home)
        {
            if (m_homeAvatar == null)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }

            if (m_behave == 2)
            {
                m_moveToPosition.y = m_homeAvatar.transform.position.y;
                m_rotation = Quaternion.LookRotation(m_moveToPosition - m_homeAvatar.transform.position);
                float angle = Quaternion.Angle(m_rotation, m_homeAvatar.transform.rotation);
                m_rotationSpeed = angle / Mathf.Max(0.001f, lastTime - 0.1f);

                Animator[] anis = m_homeAvatar.transform.GetComponentsInChildren<Animator>();
                if (anis != null && anis.Length > 0)
                    m_animator = anis[0];
            }
        }
        else
        {
            if (m_avatar == null)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            if (m_behave == 2 && null != m_avatar.GetTransform())
            {
                m_moveToPosition.y = m_avatar.GetTransform().position.y;
                m_rotation = Quaternion.LookRotation(m_moveToPosition - m_avatar.GetTransform().position);
                float angle = Quaternion.Angle(m_rotation, m_avatar.GetTransform().rotation);
                m_rotationSpeed = angle / Mathf.Max(0.001f, lastTime - 0.1f);

                Animator[] anis = m_avatar.GetTransform().GetComponentsInChildren<Animator>();
                if (anis != null && anis.Length > 0)
                    m_animator = anis[0];
            }
        }

        if (!m_camFollow)
            m_sceneCamObj.transform.parent = null;

        if (m_jump || m_directMove)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
    }

    protected override void Enter()
    {
        base.Enter();

        if (CInitStory.curState != eGameState.Home)
        {
            //m_avatar.PauseNpc(false);
            m_avatar.PauseMoveBehave(false,true);
            if (pet != null)
            {
                //pet.PauseNpc(false);
                pet.PauseMoveBehave(false,true);
            }

            if (m_behave == 1)
                m_avatar.Command(eCommandType.RunTo, new RunToCommandArg(m_moveToPosition, true, true));

            if (m_behave == 2 && m_animator != null)
            {
                m_animator.CrossFade("walk", 0.1f, 0);
            }
        }
        else
        {
            if (m_behave == 1)
                m_homeAvatar.SetDestPosition(m_moveToPosition);
        }
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        if (CInitStory.curState != eGameState.Home)
        {
            if (m_arrive && m_behave == 1)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                m_arrive = false;
            }

            if (m_behave != 2)
                return;
            Transform trans = null;
            if (null != m_avatar && (trans = m_avatar.GetTransform()) != null)
            {
                trans.rotation = Quaternion.RotateTowards(trans.rotation, m_rotation, m_rotationSpeed * Time.deltaTime);
            }
        }
        else
        {
            if (m_arrive && m_behave == 1)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                m_arrive = false;
            }

            if (m_behave != 2)
                return;

            m_avatar.GetTransform().rotation = Quaternion.RotateTowards(m_avatar.GetTransform().rotation, m_rotation, m_rotationSpeed * Time.deltaTime);
        }
    }

    protected override void Leave()
    {
        if (CInitStory.curState != eGameState.Home)
        {
            if (m_avatar != null)
            {
                //m_avatar.PauseNpc(true);
                m_avatar.PauseMoveBehave(true,true);
            }

            if ((m_jump || m_directMove) && m_avatar != null && m_avatar.GetTransform() != null)
            {
                if (m_behave == 1)
                {
                    m_avatar.GetTransform().position = m_moveToPosition;
                    uint cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
                    CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, m_avatar.GetTransform().gameObject, eCAMERAFOLLOW.DIRECT, false, false);
                }
                else if (m_behave == 2)
                    m_avatar.GetTransform().rotation = m_rotation;
            }
            else if (m_avatar != null && m_animator != null && m_behave == 2)
            {
                //m_animator.Play("idle");
                m_animator.CrossFade("idle", 0.1f, 0);
            }

            if (pet != null && pet.IsValid)
            {
                pet.Refresh();
                //pet.PauseNpc(true);
                pet.PauseMoveBehave(true,true);
            }

            //m_sceneCamObj.transform.parent = m_camRarent;
        }
        else
        {
            if ((m_jump || m_directMove) && m_homeAvatar != null)
            {
                if (m_behave == 1)
                {
                    m_homeAvatar.transform.position = m_moveToPosition;
                    uint cameraID = SingletonObject<HomeScene>.GetInst().CameraID;
                    CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, m_homeAvatar.transform.gameObject, eCAMERAFOLLOW.DIRECT, false, false);
                }
                else if (m_behave == 2)
                    m_homeAvatar.transform.rotation = m_rotation;
            }
            else if (m_homeAvatar != null && m_behave == 2)
            {
            }
        }
        
        base.Leave();
    }

    public override void DoSomeThing()
    {
        if (m_info.LastTime < 0)
            m_arrive = true;
    }
}
