﻿using UnityEngine;
using System.Collections;

public class CRotationMotionStory : CBaseStory {

    private Transform m_trans;
    private Transform m_target;

    private float m_targetSpeed;       //Get form info
    private float m_targetRadius;      //Get form info
    private float m_speed = 0;
    private float m_radius;

    private float m_radian = 0;
    private Vector3 m_axis;            //Get form info
    private float m_y;

    private Quaternion m_worldToAxisQuater;
    private float m_timeToAxis = 0.5f;
    private float m_rotatMax;

    private float m_maxOffset;        //Get form info

    private bool m_selfLeave = false;

    


    public CRotationMotionStory()
    {
        //m_type = eCameraStoryType.ROTATEMOTION;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_trans = camObj.transform;

        CreateTarget(ref m_target);

        if (m_trans != null && m_target != null)
        {
            Vector3 pointSelf = m_trans.position - m_target.position;
            pointSelf.Normalize();
            m_radian = Mathf.Acos(Vector3.Dot(m_target.TransformDirection(Vector3.right), pointSelf));

            if(pointSelf.z < 0)
                m_radian = 2 * Mathf.PI - m_radian;

            m_y = m_target.InverseTransformPoint(m_trans.position).y;

            m_axis = m_info.PointDirect;
            if (m_axis == Vector3.zero)
            {
                m_axis = Vector3.up;
            }
            m_axis.Normalize();
            m_worldToAxisQuater = Quaternion.FromToRotation(Vector3.up, m_axis);
            float angle = Quaternion.Angle(m_target.rotation, m_worldToAxisQuater);
            m_rotatMax = angle / m_timeToAxis;

            m_targetSpeed = MyConvert_Convert.ToSingle(m_list[0]) * Mathf.Deg2Rad;
            m_targetRadius = MyConvert_Convert.ToSingle(m_list[1]);
            m_maxOffset = MyConvert_Convert.ToSingle(m_list[2]) * Mathf.Deg2Rad;

            m_maxOffset += m_radian;

            float lastTime = m_info.LastTime;
            if (lastTime >= 0)
                m_selfLeave = false;
            else
                m_selfLeave = true;
        }
    }

    protected override void ForUpdate()
    {
        if (m_axis != Vector3.zero && m_trans != null && m_target != null)
        {
            m_radius = Vector3.Distance(m_trans.position, m_target.position);

            if (m_targetRadius != m_radius)
            {
                m_radius = Mathf.Lerp(m_radius, m_targetRadius, 0.05f);
            }

            if (m_targetSpeed != m_speed)
            {
                m_speed = Mathf.Lerp(m_speed, m_targetSpeed, 0.02f);
            }

            m_radian += m_speed * Time.deltaTime;

            if (!m_selfLeave)
            {
                if (m_radian > m_maxOffset)
                    m_radian = m_maxOffset;
            }

            float x = Mathf.Cos(m_radian) * m_radius;
            float z = Mathf.Sin(m_radian) * m_radius;
            Vector3 newPos = new Vector3(x, m_y, z);
            m_trans.position = m_target.TransformPoint(newPos);

            if (m_target.rotation != m_worldToAxisQuater)
                m_target.rotation = Quaternion.RotateTowards(m_target.rotation, m_worldToAxisQuater, m_rotatMax * Time.deltaTime);

            if (m_selfLeave && m_radian >= m_maxOffset)
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
        else
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
    }

    protected override void Leave()
    {
        DestoryTarget();
        base.Leave();
    }

    private void CreateTarget(ref Transform tran)
    {
        GameObject target = new GameObject("RotationMotionStory");
        tran = target.transform;
        tran.rotation = Quaternion.identity;
        tran.localScale = Vector3.one;
        tran.parent = SingletonObject<Avatar>.GetInst().GetTransform();
        tran.localPosition = Vector3.zero;
    }

    private void DestoryTarget()
    {
        if (m_target != null)
            Object.Destroy(m_target.gameObject);
    }
}
