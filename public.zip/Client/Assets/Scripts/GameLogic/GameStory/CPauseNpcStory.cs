﻿using UnityEngine;
using System.Collections;

public class CPauseNpcStory : CBaseStory {

    private bool m_pause;      //1 pause  0 unpause;
    private string m_pauseType;  //1 avatar  2 BattlePlayer  3 monster , 4 all and expcept Avatar, 5 all and expcept BattlePlayer, 6 all and expcept Monster ,7 All
    private uint m_monsterID; //only monster ;


    public CPauseNpcStory()
        : base()
    {
        m_type = eCameraStoryType.PAUSE_NPC;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_pause = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));

        m_pauseType = m_list[1].Trim();
        if (m_pauseType.Equals("3"))
        {
            uint npcMapID = MyConvert_Convert.ToUInt32(m_list[2]);

            SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(npcMapID);
            if (npcmap != null)
                m_monsterID = GetCurrentJobNpcID(npcmap);
            else
            {
                MyLog.LogError("CPauseNpcStory Init npcmap is null m_npcMapID = " + npcMapID.ToString() + "\tCurrent Story ID = " + info.Key);
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
        }
        Enter();
    }

    protected override void Enter()
    {
        base.Enter();
        switch (m_pauseType)
        {
            case "1":
                {
                    Avatar avatar = SingletonObject<Avatar>.GetInst();
                    if (avatar == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter Avatar is null ,current story id = " + m_info.Key);
                        return;
                    }
                    avatar.Pause(m_pause);
                }
                break;
            case "2":
                {
                    if (m_pBattlePlayer == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter m_pBattlePlayer is null ,current story id = " + m_info.Key);
                        return;
                    }
                    m_pBattlePlayer.Pause(m_pause);
                }
                break;
            case "3":
                {
                    BattleScene bs = SingletonObject<BattleScene>.GetInst();
                    if (bs == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter BattleScene is null ,current story id = " + m_info.Key);
                        return;
                    }
                    CBaseNpc monster = bs.GetNpcTrans(m_monsterID);
                    if (monster == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter monster is null ,monster id = " + m_monsterID.ToString() + "\t,current story id = " + m_info.Key);
                        return;
                    }
                    monster.Pause(m_pause);
                }
                break;
            case "4":
                {
                    BattleScene bs = SingletonObject<BattleScene>.GetInst();
                    if (bs == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter BattleScene is null ,current story id = " + m_info.Key);
                        return;
                    }
                    //CBaseNpc monster = bs.GetNpcTrans(m_monsterID);
                    //if (monster == null)
                    //{
                    //    MyLog.LogError("CPauseNpcStory Enter monster is null ,monster id = " + m_monsterID.ToString() + "\t,current story id = " + m_info.GetID());
                    //    return;
                    //}
                    //monster.PauseNpc(m_pause);
                    bs.PauseContainGameStory(m_pause, true);
                }
                break;
            case "5":
                {
                    BattleScene bs = SingletonObject<BattleScene>.GetInst();
                    if (bs == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter BattleScene is null ,current story id = " + m_info.Key);
                        return;
                    }
                    //CBaseNpc monster = bs.GetNpcTrans(m_monsterID);
                    //if (monster == null)
                    //{
                    //    MyLog.LogError("CPauseNpcStory Enter monster is null ,monster id = " + m_monsterID.ToString() + "\t,current story id = " + m_info.GetID());
                    //    return;
                    //}
                    //monster.PauseNpc(m_pause);
                    bs.PauseContainGameStory(m_pause, false);
                    if (m_pBattlePlayer == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter m_pBattlePlayer is null ,current story id = " + m_info.Key);
                        return;
                    }
                    m_pBattlePlayer.Pause(false);
                }
                break;
            case "6":
                {
                    BattleScene bs = SingletonObject<BattleScene>.GetInst();
                    if (bs == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter BattleScene is null ,current story id = " + m_info.Key);
                        return;
                    }
                    CBaseNpc monster = bs.GetNpcTrans(m_monsterID);
                    if (monster == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter monster is null ,monster id = " + m_monsterID.ToString() + "\t,current story id = " + m_info.Key);
                        return;
                    }
                    bs.PauseContainGameStory(m_pause, false);
                    monster.Pause(false);
                }
                break;
            case "7":
                {
                    BattleScene bs = SingletonObject<BattleScene>.GetInst();
                    if (bs == null)
                    {
                        MyLog.LogError("CPauseNpcStory Enter BattleScene is null ,current story id = " + m_info.Key);
                        return;
                    }
                    //CBaseNpc monster = bs.GetNpcTrans(m_monsterID);
                    //if (monster == null)
                    //{
                    //    MyLog.LogError("CPauseNpcStory Enter monster is null ,monster id = " + m_monsterID.ToString() + "\t,current story id = " + m_info.GetID());
                    //    return;
                    //}
                    //monster.PauseNpc(m_pause);
                    bs.PauseContainGameStory(m_pause,false);
                }
                break;
            default: MyLog.LogError("CPauseNpcStory Enter m_pauseType is not read ,m_pauseType = " + m_pauseType + "\t,current story id = " + m_info.Key); break;
        }
    }
}
