﻿using UnityEngine;
using System.Collections.Generic;

public class CBattlePlayerSkillStory : CBaseStory {

    uint m_npcIDtarget;
    uint m_skillID;
    uint m_skillOrTarget; //1 攻击目标ID  2 技能ID

    List<CBaseNpc> m_targetList = new List<CBaseNpc>();

    public CBattlePlayerSkillStory()
    {
        m_type = eCameraStoryType.BATTLE_PLAYER_SKILL;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_skillOrTarget = MyConvert_Convert.ToUInt32(m_list[0]);
        if (m_skillOrTarget == 1)
            m_npcIDtarget = MyConvert_Convert.ToUInt32(m_list[1]);
        else
        {
            uint skillidMap = MyConvert_Convert.ToUInt32(m_list[1]);
            SceneStoryNpcContent skillmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(skillidMap);
            if (skillmap == null)
            {
                MyLog.LogError("CBattlePlayerSkillStory Init can not find skillidMap = " + skillidMap.ToString() + "\t current story id = " + info.Key);
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            m_skillID = GetCurrentJobNpcID(skillmap);

            m_targetList.Clear();
            int argsCount = m_list.Count;
            for (int i = 2; i < argsCount; i++)
            {
                uint npcID = MyConvert_Convert.ToUInt32(m_list[i]);
                CBaseNpc npc = SingletonObject<BattleScene>.GetInst().GetNpcTrans(npcID);
                if (npc != null)
                    m_targetList.Add(npc);
                else
                    MyLog.LogError("CBattlePlayerSkillStory Init can not find CBaseNpc npcID = " + npcID.ToString() + "\t current story id = " + info.Key);
            }
        }
        
        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }


    protected override void Enter()
    {
        base.Enter();
        PlayNPCSkill();
    }


    private void PlayNPCSkill()
    {
        if (m_pBattlePlayer == null)
        {
            MyLog.LogError("CBattlePlayerSkillStory PlayNPCSkill not find m_pBattlePlayer");
            return;
        }

        if (m_skillOrTarget == 1)
        {
            CBaseNpc target = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_npcIDtarget);
            m_pBattlePlayer.CurrTarget = target;
            m_pBattlePlayer.PauseNpc(false,true);
        }
        else
        {
            m_pBattlePlayer.CurrTarget = null;
            m_pBattlePlayer.PauseCheckBehave(false);
            //m_pBattlePlayer.PauseMoveBehave(false);
            HitResultCallback callback = null;
            if (m_continueTime == -1)
                callback = BattlePlayerHitResultCallback;
            m_pBattlePlayer.HitResultCallback = callback;
            m_pBattlePlayer.Command(eCommandType.UseSkill, new UseSkillCommandArg(m_skillID, null, false, null));
        }
    }

    private void BattlePlayerHitResultCallback()
    {
        Leave();
    }

    //protected override void Leave()
    //{
    //    base.Leave();
    //    if(m_skillOrTarget != 1 && m_pBattlePlayer != null)
    //        m_pBattlePlayer.PauseNpc(true);

    //}
}
