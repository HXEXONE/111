﻿using UnityEngine;
using System.Collections;

public class CShowUIStory : CBaseStory {

    public CShowUIStory()
        :base()
    {
        m_type = eCameraStoryType.SHOW_UI;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        MyLog.Log("Show UI Story");
    }
}
