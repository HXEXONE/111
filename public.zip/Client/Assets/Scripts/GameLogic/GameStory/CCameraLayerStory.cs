﻿using UnityEngine;
using System.Collections;

public class CCameraLayerStory : CBaseStory {

    private int m_maskLayers = 0;

    public CCameraLayerStory()
    {
        //m_type = eCameraStoryType.CAMERA_LAYER;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_list == null)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
        int count = m_list.Count;
        if (count < 1)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        bool back = MyConvert_Convert.ToInt32(m_list[0]) != 0;
        if (back)
        {
            m_maskLayers = DEFINE.CAMERA_FOLLOW_ORIGINAL_CULLING_MASK;
        }
        else
        {
            int layer;
            for (int i = 1; i < count; i++)
            {
                layer = MyConvert_Convert.ToInt32(m_list[i]);
                m_maskLayers |= 1 << layer;
            }
        }
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_maskLayers != 0)
            m_sceneCam.cullingMask = m_maskLayers;
    }
}
