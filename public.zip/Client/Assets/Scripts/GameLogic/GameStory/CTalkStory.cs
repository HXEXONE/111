﻿using UnityEngine;
using System.Collections;

public class CTalkStory : CBaseStory {

    private uint m_startID;
    private uint m_endID;
    private uint m_currentID;
    private string m_talkText;
    private int m_npcID;
    private string m_npcName;

    private bool m_isTouch;
    private bool m_nextText;
    private float m_touchTime;
    private float m_lapseTime;

    private int m_dialogSyle;

    public CTalkStory()
    {
        m_type = eCameraStoryType.TALK;
        m_lapseTime = 0.02f;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }

        m_startID = MyConvert_Convert.ToUInt32(m_list[0]);
        m_endID = MyConvert_Convert.ToUInt32(m_list[1]);
        m_dialogSyle = MyConvert_Convert.ToInt32(m_list[2]);
        m_currentID = m_startID;
    }

    protected override void Enter()
    {
        base.Enter();
        //SingletonObject<TaskMediator>.GetInst().SetBottomActive(true);
        ShowText(m_startID);
        m_nextText = false;
        m_isTouch = false;
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        GetTouchAndText();
    }

    protected override void Leave()
    {
        SingletonObject<TaskMediator>.GetInst().SetBottomActive(false);
        base.Leave();
    }

    private void GetTouchAndText()
    {
        float timeNow = Time.time;

        if(CGameConfig.GetInst().Pause)
            return;
        if (!CPlayer.isInputEnable) return;
#if UNITY_EDITOR
        if (Input.GetMouseButtonDown(0) && !m_isTouch)
        {
            m_touchTime = timeNow;
            m_isTouch = true;
        }

        if (Input.GetMouseButtonUp(0))
        {
            m_nextText = false;
            m_isTouch = false;
        }
#else
        if (Input.touchCount > 0)
        {
            m_touchTime = 0;
            m_isTouch = true;
        }
        else
        {
            if (!m_isTouch)
                return;
            m_touchTime += Time.deltaTime;
            m_isTouch = m_touchTime < m_lapseTime;
            m_nextText = m_isTouch;
            return;
        }
#endif
        if (m_isTouch && !m_nextText)
        {
            m_nextText = true;
            m_currentID++;
            if (m_currentID > m_endID)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            ShowText(m_currentID);
        }
    }

    private void ShowText(uint ID)
    {
        TalkContent info = HolderManager.m_TalkHolder.GetStaticInfo((int)ID);
        if (info == null)
        {
            MyLog.LogError("CTalkStory can not find TalkContentHolder ID : " + ID.ToString() + ". Current story ID : " + m_info.Key.ToString());
            return;
        }
        int mapID = info.NpcID;
        if (mapID > 1000)
        {
            uint npcMapID = (uint)mapID;
            SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(npcMapID);
            if (npcmap == null)
            {
                MyLog.LogError("CTalkStory can not find SceneStoryNpcContent npcMapID : " + npcMapID.ToString() + ". Current story ID : " + m_info.Key.ToString());
                return;
            }
            m_npcID = (int)GetCurrentJobNpcID(npcmap);
        }
        else
            m_npcID = mapID;
        m_npcName = Common.GetText(info.Remark);
        m_talkText = Common.GetText(info.TalkText);

        TaskMediator task = SingletonObject<TaskMediator>.GetInst();
        if (task != null)
        {
            task.InitPanel(m_npcID, m_talkText, m_npcName, (eDialogType)m_dialogSyle, (eNpcNameType)info.NameType);
        }
        else
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);

    }
}
