﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 此类和 CModeRideStory 互斥, 此类是CModeRideStory行为的分解,与CBattlePlayerCreateStory CBattlePlayerMoveStory 共同协作
/// </summary>
public class CBattlePlayerRideStory : CBaseStory {

    private uint m_mountID;
    private bool m_ride;  //true 上马 false 下马

    private float m_waitOutTime = 10f;
    private float m_currentOutTime = 0;

    private float m_privateLast;

    public CBattlePlayerRideStory()
        : base()
    {
        m_type = eCameraStoryType.RIDE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        int rtemp = MyConvert_Convert.ToInt32(m_list[0]);
        m_ride = MyConvert_Convert.ToBoolean(rtemp);
        if (m_list.Count >= 2)
            m_mountID = MyConvert_Convert.ToUInt32(m_list[1]);

        if (m_ride && m_pBattlePlayer != null)
        {
            m_pBattlePlayer.Mount_ID = m_mountID;
            m_pBattlePlayer.LoadMount();
        }
    }

    protected override void Wait()
    {
        base.Wait();
        if (m_ride && m_pBattlePlayer != null && !m_pBattlePlayer.BMountLoadCompleted)
        {
            m_currentOutTime += Time.deltaTime;
            if (m_currentOutTime > m_waitOutTime)
            {
                MyLog.LogError("Cam not Load Mount ID = " + m_mountID.ToString() + ". Current story ID : " + m_info.Key.ToString());
                SetState(eBaseEffectState.EFFECT_STATE_ENTER);
                return;
            }
            else
            {
                MyLog.Log("Wait create Mount");
                SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                return;
            }
        }
        m_daletTime = 0;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_pBattlePlayer != null)
        {
            if (m_ride)
                m_pBattlePlayer.BeginRide(true, m_mountID);
            else
                m_pBattlePlayer.EndRide(false);
        }
        else
            MyLog.LogError("CBattlePlayerRideStory Enter not BaseBattlePlayer");
    }
}
