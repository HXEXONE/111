﻿using UnityEngine;
using System.Collections;


public class CShakeStory : CBaseStory {

    private Vector3 m_direct;
    private float m_time;
    


    public CShakeStory()
    {
        m_type = eCameraStoryType.SHAKE;
        m_direct = Vector3.zero;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }

        m_direct = m_info.PointDirect;

        float lastTime = info.LastTime;
        if (lastTime > 0)
        {
            m_time = lastTime - 0.1f;
            if (m_time < 0)
                m_time = 0.001f;
        }
        else
            m_time = Mathf.Abs(lastTime);
    }

    protected override void Enter()
    {
        base.Enter();
        iTween.ShakePosition(m_sceneCamObj, iTween.Hash("amount", m_direct, "time", m_time, "looptype", iTween.LoopType.none, "space", Space.Self, "oncomplete", (OnCallBack)OnComplete));
    }

    private void OnComplete(params object[] args)
    {
        float lastTime = m_info.LastTime;
        if (lastTime < 0)
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
    }

    protected override void Leave()
    {
        if (m_jump)
        {
            iTween.Stop(m_sceneCamObj, "shake");
        }
        base.Leave();
    }

    protected override bool ForceNextStoryEvent()
    {
        bool suc = base.ForceNextStoryEvent();

        if (suc)
        {
            iTween.Stop(m_sceneCamObj, "shake");
        }
        return suc;
    }
}
