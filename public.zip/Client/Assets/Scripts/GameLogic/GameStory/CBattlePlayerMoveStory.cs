﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 此类和 CModeRideStory 互斥, 此类是CModeRideStory行为的分解,与CBattlePlayerRideStory CBattlePlayerCreateStory 共同协作
/// </summary>
public class CBattlePlayerMoveStory : CBaseStory {

    private Vector3 m_position;
    private float m_continueTime;

    private int m_behave = 0;   //行为  1 移动   2 旋转
    private float m_rotationSpeed;
    private Quaternion m_rotation;

    private Animator m_animator;
    private Transform m_battlePlayerTrans;

    public CBattlePlayerMoveStory()
        : base()
    {
        m_type = eCameraStoryType.BATTLE_PLAYER_MOVE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_continueTime = info.LastTime;
        m_position = info.PointDirect;

        if (m_list != null && m_list.Count > 0 && !m_list[0].Equals("0"))
        {
            m_behave = MyConvert_Convert.ToInt32(m_list[0]);
        }
        else
            m_behave = 1;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_pBattlePlayer == null)
        {
            MyLog.LogError("CBattlePlayerMoveStory Enter BattlePlayer is null, please load before call it");
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        if (m_behave == 1)
            m_pBattlePlayer.Command(eCommandType.RunTo, new RunToCommandArg(m_position, true, true));
        else
        {
            m_battlePlayerTrans = m_pBattlePlayer.GetTransform();

            m_position.y = m_battlePlayerTrans.position.y;
            m_rotation = Quaternion.LookRotation(m_position - m_battlePlayerTrans.position);
            float angle = Quaternion.Angle(m_rotation, m_battlePlayerTrans.rotation);
            m_rotationSpeed = angle / Mathf.Max(0.001f, m_continueTime - 0.1f);

            Animator[] anis = m_battlePlayerTrans.GetComponentsInChildren<Animator>();
            if (anis != null && anis.Length > 0)
            {
                m_animator = anis[0];
                m_animator.CrossFade("walk", 0.1f, 0);
            }
        }
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        if (m_pBattlePlayer == null)
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);

        if (m_behave == 2 && m_battlePlayerTrans != null)
        {
            m_battlePlayerTrans.rotation = Quaternion.RotateTowards(m_battlePlayerTrans.rotation, m_rotation, m_rotationSpeed * Time.deltaTime);
        }
    }

    public override void DoSomeThing()
    {
        if (m_continueTime < 0)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }
}
