﻿using UnityEngine;
using System.Collections;

public class CRotationStory : CBaseStory {

    private float m_time;
    private Quaternion m_rotation;

    private float m_angle;
    private float m_rotatMax;

    private bool m_return;

    private bool m_directRotate = false;

    public CRotationStory()
    {
        m_type = eCameraStoryType.ROTATE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        m_return = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));
        
        if (!m_return)
        {
            Vector3 euler = m_info.PointDirect;
            m_rotation = Quaternion.Euler(euler);
        }
        else
        {
            m_rotation = m_sceneCamObj.transform.parent.rotation;
        }

        float lastTime = info.LastTime;

        m_directRotate = (lastTime == 0);

        if (lastTime > 0)
        {
            m_time = lastTime - 0.1f;
            if (m_time < 0)
                m_time = 0.001f;
        }
        else
            m_time = Mathf.Abs(lastTime);

        m_angle = Quaternion.Angle(camObj.transform.rotation, m_rotation);
        m_rotatMax = m_angle / m_time;


        if (m_jump || m_directRotate)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        m_sceneCamObj.transform.rotation = Quaternion.RotateTowards(m_sceneCamObj.transform.rotation, m_rotation, m_rotatMax * Time.deltaTime);
    }

    protected override void Leave()
    {
        if (m_jump || m_directRotate)
        {
            m_sceneCamObj.transform.rotation = m_rotation;
        }
        base.Leave();
    }
}
