﻿using UnityEngine;
using System.Collections;


//这个状态用于加载剧情所用到的所有资源 和初始化 以后状态所用到的变量

public class CInitStory : CBaseStory {

    private uint m_musicID = 0;
    public static uint m_oldMusicID = 0;
    public static eGameState curState;
    public CInitStory()
    {
        m_type = eCameraStoryType.INIT;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        m_isInGameStory = true;
        m_musicID = 0;
        m_oldMusicID = 0;
        m_sceneCamObj = camObj == null ? CCamera.GetInst().GetCameraObj() : camObj;
        base.Init(info, m_sceneCamObj, callback, args);
        m_musicID = MyConvert_Convert.ToUInt32(m_list[0]);

        curState = SingletonBehaviour<ClientMain>.GetInstance().GetCurrentState();

        if (m_musicID != 0)
        {
            if (curState == eGameState.Battle)
            {
                SceneInfoContent mapinfo = SingletonObject<BattleScene>.GetInst().SceneLoaderInfo;
                if (mapinfo != null)
                    m_oldMusicID = (uint)mapinfo.MusicTypeID;
                //m_oldMusicID = SingletonObject<BattleScene>.GetInst().GetSceneLoader().GetMusicTypeID();
            }
            else if (curState == eGameState.Home)
            {
                //m_oldMusicID = SingletonObject<HomeScene>.GetInst().GetSceneLoader().GetMusicTypeID();

                SceneInfoContent mapinfo = SingletonObject<HomeScene>.GetInst().SceneLoaderInfo;
                if (mapinfo != null)
                    m_oldMusicID = (uint)mapinfo.MusicTypeID;
            }
        }

        m_jump = false;

        CCamera.GetInst().Lock(m_lockObject);

    }

    protected override void Enter()
    {
        if (curState == eGameState.Battle)
            SingletonObject<BattleScene>.GetInst().PauseAllNpc(true,true);
        else if (curState == eGameState.Home)
            SingletonObject<CPlayer>.GetInst().CloseHomeInfoMediator();
        Avatar.m_OffHandelClick = true;
        //SingletonObject<UIManager>.GetInst().CloseAllWnd();
        SingletonObject<UIManager>.GetInst().CloseAllWnd();
     //   SingletonObject<UIManager>.GetInst().OpenWnd(SingletonObject<TaskMediator>.GetInst());
        SingletonObject<TaskMediator>.GetInst().Open(delegate() {
            SingletonObject<TaskMediator>.GetInst().SetBtnPassActive(true);
            SingletonObject<TaskMediator>.GetInst().SetBottomActive(false);
        });
       
        SingletonObject<FlywordMediator>.GetInst().ShowFlyWord = false;
        base.Enter();

        if (m_musicID != 0)
        {
            if (curState == eGameState.Battle || curState == eGameState.Home)
            {
                SingletonObject<CMusicManager>.GetInst().CreateMusic(m_musicID);
            }
        }

        if (curState == eGameState.Battle)
        {
            Avatar pAvatar = SingletonObject<Avatar>.GetInst();
            if (SingletonObject<BattleScene>.GetInst().IsGameOver())
            {
                if (pAvatar.IsInFly())
                    pAvatar.EndFly(m_lockObject);
                if (pAvatar.IsInRide())
                    pAvatar.EndRide(true);

                if (pAvatar.PartnerState != ePartnerState.Avatar)
                    pAvatar.CallPartner(true);
            }

            pAvatar.SetFootEffectForGameStory(false);
        }


        TriggerManager.GetInst().PauseAlltrigger(true);
    }


    protected override void Leave()
    {
        base.Leave();
        //SingletonObject<TaskMediator>.GetInst().btnPass.SetActive(true);
    }
}
