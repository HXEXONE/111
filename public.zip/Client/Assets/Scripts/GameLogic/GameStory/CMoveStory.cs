﻿using UnityEngine;
using System.Collections;


public class CMoveStory : CBaseStory {

    private Vector3[] m_path;
    private string m_pathName;
    private iTween.EaseType m_easeType;
    private float m_itweenSpeed;

    private float m_lookTime;

    private bool m_return;

    private Vector3 m_camDir;

    private bool m_directMove = false;

    private GameObject m_moveObject;

    private AddAnimation m_moveAnimation;

    public CMoveStory()
    {
        m_type = eCameraStoryType.MOVE;
        m_lookTime = 0.6f;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        m_return = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));
        m_easeType = (iTween.EaseType)MyConvert_Convert.ToInt32(m_list[1]);
        m_camDir = m_info.PointDirect;

        m_moveObject = m_sceneCamObj.transform.parent.gameObject;

        if (m_return)
        {
            //m_path = new Vector3[2];
            //m_path[0] = m_sceneCamObj.transform.position;
            //m_path[1] = m_sceneCamObj.transform.parent.position;
        }
        else
        {
            m_path = new Vector3[2];
            m_path[0] = m_moveObject.transform.position;
            m_path[1] = m_camDir;
            CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW,m_lockObject);
        }
        
        float lastTime = info.LastTime;

        m_directMove = (lastTime == 0);

        if (lastTime > 0)
        {
            m_itweenSpeed = lastTime - 0.1f;
            if (m_itweenSpeed <= 0)
                m_itweenSpeed = 0.001f;
        }
        else
            m_itweenSpeed = Mathf.Abs(lastTime);

        if (lastTime == 0 || m_jump)
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);

        CMusicManager.EVNSoundEnabled = false;
    }

    protected override void Wait()
    {
        base.Wait();
        m_moveAnimation = m_moveObject.GetComponent<AddAnimation>();
        if (m_moveAnimation == null)
            m_moveAnimation = m_moveObject.AddComponent<AddAnimation>();
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_return)
        {
            uint cameraID;
            GameObject followObj = null;
            if (CInitStory.curState != eGameState.Home)
            {
                cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
                Avatar avatar = SingletonObject<Avatar>.GetInst();
                if(avatar.IsInRide())
                    followObj = avatar.BakTrans.gameObject;
                else
                    followObj = avatar.GetTransform().gameObject;
            }
            else
            {
                cameraID = SingletonObject<HomeScene>.GetInst().CameraID;
                CPlayer homeAvatar = SingletonObject<CPlayer>.GetInst();
                followObj = homeAvatar.transform.gameObject;
            }

            CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, followObj, eCAMERAFOLLOW.ROTATE, false, false);

            //iTween.MoveTo(m_moveObject, iTween.Hash("path", m_path, "time", m_itweenSpeed, "delay", 0.0f, "loopType", iTween.LoopType.none, "easetype", m_easeType, "oncomplete", (OnCallBack)OnComplete));
        }
        else
        {
            //iTween.MoveTo(m_moveObject, iTween.Hash("path", m_path, "time", m_itweenSpeed, "delay", 0.0f, "loopType", iTween.LoopType.none, "easetype", m_easeType, "oncomplete", (OnCallBack)OnComplete));
            if (m_moveAnimation != null)
                m_moveAnimation.PlayAnimation(m_camDir, m_itweenSpeed, "moveStory",0.5f, OnComplete,null);
        }
        //iTween.MoveTo(m_sceneCamObj, iTween.Hash("path", m_path, "time", m_itweenSpeed, "delay", 0.0f,"looktarget",m_camDir,"looktime",m_lookTime, "loopType", iTween.LoopType.none, "easetype", m_easeType, "oncomplete", (OnCallBack)OnComplete));
    }

    protected override void Leave()
    {
        if (m_jump || m_directMove)
        {
            if (m_return)
            {
                uint cameraID;
                if (CInitStory.curState != eGameState.Home)
                {
                    cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
                    Avatar avatar = SingletonObject<Avatar>.GetInst();
                    Transform tran = null;
                    if (avatar.IsInRide())
                        tran = avatar.BakTrans;
                    else
                        tran = avatar.GetTransform();
                    if (tran != null)
                        CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, tran.gameObject, eCAMERAFOLLOW.DIRECT, false, false);
                    else
                        MyLog.LogError("CMoveStory Leave Avatar Object is null");
                }
                else
                {
                    cameraID = SingletonObject<HomeScene>.GetInst().CameraID;
                    CPlayer avatar = SingletonObject<CPlayer>.GetInst();
                    Transform tran = avatar.transform;
                    if (tran != null)
                        CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, tran.gameObject, eCAMERAFOLLOW.DIRECT, false, false);
                    else
                        MyLog.LogError("CMoveStory Leave Avatar Object is null");
                }
            }
            else
            {
                m_moveObject.transform.position = m_camDir;
            }
        }

        if (m_moveAnimation != null)
        {
            m_moveAnimation.Stop();
            //Object.DestroyImmediate(m_moveAnimation);
            m_moveAnimation = null;
        }

        base.Leave();
    }

    void OnComplete(params object[] args)
    {
        float lastTime = m_info.LastTime;
        if (lastTime < 0)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }

    protected override bool ForceNextStoryEvent()
    {
        bool suc = base.ForceNextStoryEvent();

        if (suc)
        {
            //iTween.Stop(m_moveObject, "move");
            m_moveAnimation.Stop();
        }
        return suc;
    }
}
