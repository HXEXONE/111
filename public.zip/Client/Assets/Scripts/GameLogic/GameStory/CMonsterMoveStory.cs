﻿using UnityEngine;
using System.Collections;

public class CMonsterMoveStory : CBaseStory {

    private Vector3 m_moveToPosition;   //Get info
    private uint m_npcID = 0;               //Get info

    private CBaseNpc m_monster;

    private BaseHomeMonster m_homeMonster;

    private Transform m_tran;

    private bool m_arrive = false;
    private bool m_directMove;

    private uint m_behave = 0;   //行为  1 移动   2 旋转

    private float m_rotationSpeed;
    private Quaternion m_rotation;

    private Animator m_animator;

    private float m_waitOutTime = 3f;
    private float m_currentOutTime = 0;

    private float m_privateLast;

    public CMonsterMoveStory()
    {
        m_type = eCameraStoryType.MONSTER_MOVE;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        uint npcMapID = MyConvert_Convert.ToUInt32(m_list[0]);

        SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(npcMapID);
        if (npcmap != null)
            m_npcID = GetCurrentJobNpcID(npcmap);

        m_behave = MyConvert_Convert.ToUInt32(m_list[1]);
		m_privateLast = info.LastTime;
		m_moveToPosition = info.PointDirect;
		m_arrive = false;

		m_directMove = (m_privateLast == 0);

        if (CInitStory.curState != eGameState.Home)
        {
            m_monster = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_npcID);
            //m_createdNpc.TryGetValue(m_npcID,out m_monster);
            if (m_monster == null)
            {
                MyLog.LogError("CMonsterMoveStory can not find monsterID : " + m_npcID.ToString() + ". Current story ID : " + info.Key.ToString());
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }

            if (m_monster.GetTransform() == null)
            {
                m_daletTime = 1f;
                m_currentOutTime = 0;
                SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                return;
            }
        }
        else
        {
            m_homeMonster = SingletonObject<HomeScene>.GetInst().GetHomeMonster(m_npcID);
            if (m_homeMonster == null)
            {
                MyLog.LogError("CMonsterMoveStory can not find monsterID : " + m_npcID.ToString() + ". Current story ID : " + info.Key.ToString());
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }

            if (m_homeMonster.GetTransform() == null)
            {
                m_daletTime = 1f;
                m_currentOutTime = 0;
                SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                return;
            }
        }

        m_tran = CInitStory.curState == eGameState.Home ? m_homeMonster.GetTransform() : m_monster.GetTransform();

        Initialize(m_tran);
    }

    protected override void Wait()
    {
        base.Wait();

        if (CInitStory.curState != eGameState.Home)
        {
            if (m_monster.GetTransform() == null)
            {
                m_currentOutTime += Time.deltaTime;
                if (m_currentOutTime > m_waitOutTime)
                {
                    MyLog.LogError("Cam not Load Npc ID = " + m_npcID.ToString() + ". Current story ID : " + m_info.Key.ToString());
                    SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                    return;
                }
                else
                {
                    SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                    return;
                }
            }
        }
        else
        {
            if (m_homeMonster.GetTransform() == null)
            {
                m_currentOutTime += Time.deltaTime;
                if (m_currentOutTime > m_waitOutTime)
                {
                    MyLog.LogError("Cam not Load Npc ID = " + m_npcID.ToString() + ". Current story ID : " + m_info.Key.ToString());
                    SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                    return;
                }
                else
                {
                    SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                    return;
                }
            }
        }

        m_daletTime = 0;
        m_tran = CInitStory.curState == eGameState.Home ? m_homeMonster.GetTransform() : m_monster.GetTransform();
        Initialize(m_tran);
    }

    protected override void Enter()
    {
        base.Enter();

        if (CInitStory.curState != eGameState.Home)
        {
            if (m_behave == 1)
            {
                m_monster.Command(eCommandType.RunTo, new RunToCommandArg(m_moveToPosition, true, true));
            }

            if (m_behave == 2 && m_animator != null)
            {
                m_animator.CrossFade("run", 0.1f, 0);
            }
        }
        else
        {
            if (m_behave == 1)
            {
                float speed = 7;
                if (m_homeMonster is HomeMonsterWithoutGravity)
                {
                    float l = ((HomeMonsterWithoutGravity)m_homeMonster).GetDistance(m_moveToPosition);
                    float lastTime = m_info.LastTime;
                    if (lastTime > 0)
                    {
                        float useTime = Mathf.Max(0.00001f, lastTime - 0.1f);
                        speed = l / useTime;
                    }
                }
                m_homeMonster.MoveTo(m_moveToPosition, speed);
            }

            if (m_behave == 2 && m_animator != null)
            {
                m_homeMonster.ChangeToTurnState();
            }
        }
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        if (m_arrive)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            m_arrive = false;
        }

        if (m_behave != 2)
            return;

        m_tran.rotation = Quaternion.RotateTowards(m_tran.rotation, m_rotation, m_rotationSpeed * Time.deltaTime);
    }

    protected override void Leave()
    {
        if (CInitStory.curState != eGameState.Home)
        {
            if (m_monster == null || m_tran == null)
            {
                base.Leave();
                return;
            }
            if (m_jump || m_directMove)
            {
                if (m_behave == 1)
                    m_tran.position = m_moveToPosition;
                else if (m_behave == 2)
                {
                    m_tran.rotation = m_rotation;
                }
            }
            else
            {
                if (m_animator != null && m_behave == 2)
                    m_animator.CrossFade("idle", 0.1f, 0);
            }
        }
        else
        {
            if (m_homeMonster == null || m_tran == null)
            {
                base.Leave();
                return;
            }
            if (m_jump || m_directMove)
            {
                if (m_behave == 1)
                    m_tran.position = m_moveToPosition;
                else if (m_behave == 2)
                {
                    m_tran.rotation = m_rotation;
                }
            }
            else
            {
                m_homeMonster.ChangeToIdelState();
            }
        }

        base.Leave();
    }

    public override void DoSomeThing()
    {
        if (m_info.LastTime < 0)
            m_arrive = true;
    }

    private void Initialize(Transform tran)
    {
        if (m_behave == 2)
        {
            m_moveToPosition.y = tran.position.y;
            m_rotation = Quaternion.LookRotation(m_moveToPosition - tran.position);
            float angle = Quaternion.Angle(m_rotation, tran.rotation);
            m_rotationSpeed = angle / Mathf.Max(0.001f, m_privateLast - 0.1f);

            Animator[] anis = tran.GetComponentsInChildren<Animator>();
            if (anis != null && anis.Length > 0)
            {
                m_animator = anis[0];
            }

            if (CInitStory.curState != eGameState.Home)
            {
                m_monster.CurrTarget = null;
            }
        }

        if (m_directMove)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
    }
}
