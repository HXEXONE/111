﻿using UnityEngine;
using System.Collections;

public class CEffectStory : CBaseStory {

    private uint m_particleID;
    private Vector3 m_position;
    private Vector3 m_eulerAngle;

    private GameObject m_tempObject;

    public CEffectStory()
    {
        m_type = eCameraStoryType.SKILL_EFFECT;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
        if (m_tempObject == null)
        {
            m_tempObject = new GameObject();
            m_tempObject.hideFlags = HideFlags.HideAndDontSave;
        }
        m_particleID = MyConvert_Convert.ToUInt32(m_list[0]);

        if (m_list.Count == 4)
        {
            m_position.x = MyConvert_Convert.ToUInt32(m_list[1]);
            m_position.y = MyConvert_Convert.ToUInt32(m_list[2]);
            m_position.z = MyConvert_Convert.ToUInt32(m_list[3]);
        }
        else
        {
            m_position = Vector3.zero;
        }

        m_eulerAngle = info.PointDirect;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_tempObject != null)
        {
            m_tempObject.transform.position = m_position;
            m_tempObject.transform.rotation = Quaternion.Euler(m_eulerAngle);
            //CParticleManager.GetInst().CreateGroundEffect(m_particleID, m_position, m_tempObject.transform.forward);
            CParticleManager.GetInst().CreateBindEffect(m_particleID, m_tempObject);
        }
        else
        {
            MyLog.LogError("CCreateParticle Enter m_tempObject == null");
        }
    }
}
