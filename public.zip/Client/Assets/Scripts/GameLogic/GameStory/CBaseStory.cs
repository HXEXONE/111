﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CBaseStory {

    public static Dictionary<SceneStoryContent, CBaseStory> m_currentState = new Dictionary<SceneStoryContent, CBaseStory>();
    public static Dictionary<SceneStoryContent, CBaseStory> m_previousState = new Dictionary<SceneStoryContent, CBaseStory>();
    public static Dictionary<SceneStoryContent, CBaseStory> m_nextState = new Dictionary<SceneStoryContent, CBaseStory>();
    //public static Dictionary<uint, CBaseNpc> m_createdNpc = new Dictionary<uint, CBaseNpc>();
    public static List<uint> m_currentCreate = new List<uint>();
    public static GameObject m_lookAt = null;

    public static BattlePlayer m_pBattlePlayer;
    public static Pet m_pet;

    protected static bool m_jump = false;
    protected static bool m_isInGameStory = false;
    public static bool IsInGameStory
    {
        get { return m_isInGameStory; }
    }

    private eBaseEffectState m_state;
    public eBaseEffectState State
    {
        get { return m_state; }
        set { m_state = value; }
    }
    protected eCameraStoryType m_type;
    protected Camera m_sceneCam;   //场景相机
    protected GameObject m_sceneCamObj;  //场景相机物体

    protected SceneStoryContent m_info;
    protected RegisterEvent m_callback;
    protected object[] m_args;

    protected List<int> m_nextStory = new List<int>();
    protected List<string> m_list = new List<string>();
    private List<int> m_trigger = new List<int>();
    protected float m_daletTime;
    protected float m_continueTime;
    protected float m_leaveTime = -1;
    private bool m_endStory;

    public bool EndStory
    {
        get { return m_endStory; }
    }
    private float m_startTime;

    private uint m_npcID = 0;
    private uint m_skillID = 0;

    private static RegisterEvent m_otherCallback;
    public static RegisterEvent OtherCallback
    {
        get { return CBaseStory.m_otherCallback; }
        set { CBaseStory.m_otherCallback = value; }
    }
    private static object[] m_otherCallbackArgs;

    public static object[] OtherCallbackArgs
    {
        get { return CBaseStory.m_otherCallbackArgs; }
        set { CBaseStory.m_otherCallbackArgs = value; }
    }

    protected static object m_lockObject = new object();

    public virtual void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        m_sceneCamObj = camObj;
        if (camObj != null)
            m_sceneCam = camObj.camera;

        m_info = info;
        m_callback = callback;
        m_args = args;
        m_list = info.ExtraArgToSingleList;
        m_daletTime = info.DelayTime;
        m_continueTime = info.LastTime;
        m_endStory = info.EndStory;
        m_nextStory = info.NextStoryEffect;

        m_trigger = info.Triggers;

        ChangeCurrentState();
        ChangeNextState();
        SetState(eBaseEffectState.EFFECT_STATE_WAIT);
        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
    }

    protected virtual void Wait()
    {
        if (Time.time - m_daletTime >= m_startTime)
            SetState(eBaseEffectState.EFFECT_STATE_ENTER);
    }

    protected virtual void Enter()
    {
        TriggerManager.GetInst().ActiveTriggers(m_trigger);

        SetState(eBaseEffectState.EFFECT_STATE_UPDATE);
    }

    protected virtual void ForUpdate()
    {
        if (Time.time - m_continueTime >= m_startTime && m_continueTime >= 0)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }

    protected virtual void Leave()      
    {
        if (!m_isInGameStory)  //防止剧情结束后还有代码在跑
            return;
        if (Time.time - m_leaveTime >= m_startTime)
        {
            ChangePreviousState();

            SetState(eBaseEffectState.EFFECT_STATE_NONE);

            if (m_endStory)
            {
                //foreach (KeyValuePair<uint, CBaseNpc> val in CBaseStory.m_createdNpc)
                //{
                //    SingletonObject<BattleScene>.GetInst().AddNpc(val.Value);
                //}
                //CBaseStory.m_createdNpc.Clear();

                eGameState curState = SingletonBehaviour<ClientMain>.GetInstance().GetCurrentState();
                if (curState == eGameState.Battle)
                {
                    SingletonObject<BattleScene>.GetInst().PauseAllNpc(false,true);
                    m_sceneCamObj.transform.localPosition = Vector3.zero;
                    m_sceneCamObj.transform.localRotation = Quaternion.identity;
                    m_sceneCamObj.transform.localScale = Vector3.one;


                    uint cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
                    Avatar avatar = SingletonObject<Avatar>.GetInst();
                    Transform tran = null;
                    if (avatar.IsInRide() || avatar.IsInFly())
                        tran = avatar.BakTrans;
                    else
                        tran = avatar.GetTransform();
                    if (tran != null)
                        CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, new object[] { tran.gameObject, eCAMERAFOLLOW.DIRECT, false, false });
                    else
                        MyLog.LogError("CBaseStory Leave Avatar Object is null");


                    avatar.SetFootEffectForGameStory(true);

                    TriggerManager.GetInst().PauseAlltrigger(false);
                    Avatar.m_OffHandelClick = false;
                }
                else
                {
                    uint cameraID = SingletonObject<HomeScene>.GetInst().CameraID;
                    CPlayer avatar = SingletonObject<CPlayer>.GetInst();
                    Transform tran = avatar.transform;
                    if (tran != null)
                        CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, new object[] { tran.gameObject, eCAMERAFOLLOW.DIRECT, false, false });
                    else
                        MyLog.LogError("CBaseStory Leave Avatar Object is null");

                    SingletonObject<CPlayer>.GetInst().OpenHomeInfoMediator();
                }
                CCamera.GetInst().Unlock();


                SingletonObject<UIManager>.GetInst().CloseWnd(SingletonObject<TaskMediator>.GetInst());
                SingletonObject<TaskMediator>.GetInst().Close();
                SingletonObject<UIManager>.GetInst().OpenCurrentWnd();
                SingletonObject<FlywordMediator>.GetInst().ShowFlyWord = true;
                m_previousState.Clear();
                m_currentState.Clear();
                m_nextState.Clear();


                m_currentCreate.Clear();
                if (CInitStory.m_oldMusicID != 0)
                    SingletonObject<CMusicManager>.GetInst().CreateMusic(CInitStory.m_oldMusicID);

                if (SingletonObject<TaskMediator>.GetInst().IsOpen)
                    SingletonObject<TaskMediator>.GetInst().Close();

                m_isInGameStory = false;

                if (m_callback != null)
                    m_callback(m_args);

                if (m_otherCallback != null)
                {
                    m_otherCallback(m_otherCallbackArgs);
                    m_otherCallback = null;
                    m_otherCallbackArgs = null;
                }
            }
            else
            {
                foreach (uint val in m_nextStory)
                {
                    CStoryManage.GetInst().NextStory(val, m_sceneCamObj, m_callback, null);
                    //MyLog.Log("Next Story ID  :  " + val.ToString());
                }
            }
        }
    }

    public bool Update()
    {
        if (m_sceneCamObj == null)
        {
            return false;
        }

        switch (m_state)
        {
            case eBaseEffectState.EFFECT_STATE_WAIT:
                {
                    Wait();
                    break;
                }
            case eBaseEffectState.EFFECT_STATE_ENTER:
                {
                    Enter();
                    break;
                }
            case eBaseEffectState.EFFECT_STATE_UPDATE:
                {
                    ForUpdate();
                    break;
                }
            case eBaseEffectState.EFFECT_STATE_LEAVE:
                {
                    Leave();
                    break;
                }
        }

        return true;
    }

    public eCameraStoryType GetStoryType()
    {
        return m_type;
    }

    public void SetState(eBaseEffectState state)
    {
        m_state = state;
        m_startTime = Time.time;
    }

    public void ForceNextStory()    //强制执行下一个状态
    {
        ForceNextStoryEvent();
    }

    protected virtual bool ForceNextStoryEvent()
    {
        if (m_type != eCameraStoryType.ANIMATION && m_type != eCameraStoryType.NONE)
        {
            if (m_state > eBaseEffectState.EFFECT_STATE_NONE && m_state < eBaseEffectState.EFFECT_STATE_LEAVE)
            {
                m_state = eBaseEffectState.EFFECT_STATE_LEAVE;
                Update();
                m_leaveTime = -1;
                return true;
            }
            else
                return false;
        }
        return false;
    }

    private void ChangePreviousState()
    {
        if (!m_previousState.ContainsKey(m_info))
            m_previousState.Add(m_info, this);
        if (m_currentState.ContainsKey(m_info))
            m_currentState.Remove(m_info);
    }

    private void ChangeCurrentState()
    {
        if (!m_currentState.ContainsKey(m_info))
            m_currentState.Add(m_info, this);
        if (m_nextState.ContainsKey(m_info))
            m_nextState.Remove(m_info);
    }

    private void ChangeNextState()
    {
        SceneStoryContent info;
        CBaseStory story;
        foreach (uint val in m_nextStory)
        {
            info = HolderManager.m_SceneStoryHolder.GetStaticInfo(val);
            if (info != null)
                story = CStoryManage.GetInst().GetExistStory((eCameraStoryType)info.StoryType);
            else
                return;

            if (story != null)
            {
                if (!m_nextState.ContainsKey(info))
                    m_nextState.Add(info, story);
            }
        }
    }

    public virtual void DoSomeThing()
    {

    }

    //protected void SetContinueTimeToNull()
    //{
    //    m_continueTime = -1;
    //}

    public static void Jump()
    {
        m_jump = true;
    }

    public static void ResetInGameStory()
    {
        m_isInGameStory = false;
        m_pBattlePlayer = null;
        m_pet = null;
        m_currentState.Clear();
        m_previousState.Clear();
        m_nextState.Clear();
    }



    public uint GetCurrentJobNpcID(SceneStoryNpcContent loader)
    {
        int id = 0;
        stHomeAvatarInfo info = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        if (info == null)
            return (uint)id;
        switch (info.uiPlayerJob)
        {
            case DEFINE.JOB_ID_CHIKE: id = loader.Job1; break;
            case DEFINE.JOB_ID_KUANGZHANSHI: id = loader.Job2; break;
            case DEFINE.JOB_ID_FASHI: id = loader.Job3; break;
            case DEFINE.JOB_ID_SHENGWUSHI: id = loader.Job4; break;
        }
        return (uint)id;
    }
}
