﻿using UnityEngine;
using System.Collections;

public class CPlayerSoundStory : CBaseStory {

    private static GameObject m_storySoundSource;
    private CSound m_sound;
    private uint m_soundID;
    private float m_playerTime; //持续时间，如果为0则不停止音效跳转到下一个剧情，如果为正数则持续时间到了停止音效就进入下一个剧情


    public CPlayerSoundStory()
    {
        m_type = eCameraStoryType.PLAYER_SOUND;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_storySoundSource == null)
        {
            m_storySoundSource = new GameObject("StorySource");
            m_storySoundSource.transform.position = Vector3.zero;
        }

        m_soundID = MyConvert_Convert.ToUInt32(m_list[0]);
    }

    protected override void Enter()
    {
        base.Enter();
        m_sound = CMusicManager.GetInst().CreateSound(m_storySoundSource, m_soundID, null);
    }

    protected override void Leave()
    {
        base.Leave();
        if (m_continueTime > 0)
        {
            m_sound.Stop(true);
            m_sound.Release();
        }
    }
}
