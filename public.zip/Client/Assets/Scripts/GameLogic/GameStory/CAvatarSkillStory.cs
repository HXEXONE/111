﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CAvatarSkillStory : CBaseStory {

    uint m_skillID = 0;
    bool m_isHit = false;

    public CAvatarSkillStory()
    {
        m_type = eCameraStoryType.AVATAR_SKILL;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        uint npcID = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo().uiPlayerJob;

        switch (npcID)
        {
            case 11000001: m_skillID = MyConvert_Convert.ToUInt32(m_list[0]); break;
            case 11000002: m_skillID = MyConvert_Convert.ToUInt32(m_list[1]); break;
            case 11000003: m_skillID = MyConvert_Convert.ToUInt32(m_list[2]); break;
            case 11000004: m_skillID = MyConvert_Convert.ToUInt32(m_list[3]); break;
        }

        if (m_list.Count >= 5)
        {
            m_isHit = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[3]));
        }
        else
        {
            m_isHit = false;
        }

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }


    protected override void Enter()
    {
        base.Enter();
        PlayNPCSkill();
    }


    private void PlayNPCSkill()
    {
        CBaseNpc npc = SingletonObject<Avatar>.GetInst();

        if (npc == null)
        {
            MyLog.LogError("CAvatarSkillStory cam not find Avater" + "; Current story ID : " + m_info.Key.ToString());
            return;
        }
        if (m_isHit)
        {
            npc.PauseCheckBehave(false);
            npc.Command(eCommandType.UseSkill, new UseSkillCommandArg(m_skillID, null, false, null));
        }
        else
        {
            npc.UseSkillNotHit(m_skillID);
        }
    }

    protected override void Leave()
    {
        base.Leave();
        CBaseNpc npc = SingletonObject<Avatar>.GetInst();
        if (npc == null)
        {
            MyLog.LogError("Leave CAvatarSkillStory cam not find Avater" + "; Current story ID : " + m_info.Key.ToString());
            return;
        }
        npc.PauseCheckBehave(true);
    }
}
