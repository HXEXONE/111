﻿using UnityEngine;
using System.Collections;

public class CFishEyeStory : CBaseStory {
    private float m_alphaSpeed;
    private float m_alphaTime;
    private bool m_alphaAdd;
    private bool m_direct;

    private float m_currentVal;
    private float m_targetValue;

    private GameObject m_alphaObj;
    private Material m_mat;
    private float m_distance;

    private Texture2D m_fisheyeTexture = null;
    private CObject m_fisheyeObject;
    private float m_waitOutTime = 10f;
    private float m_currentOutTime = 0;

    public CFishEyeStory()
    {
        m_type = eCameraStoryType.FISH_EYE;
        m_distance = 0.6f;
        LoadFisheyeTexture();  //预加载
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }


        m_alphaAdd = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));

        m_targetValue = MyConvert_Convert.ToSingle(m_list[1]);


        if (m_alphaObj == null)
        {
            Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_FULL_SCREEN_VERTIL);
            if (!shader)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            m_mat = new Material(shader);
            m_alphaObj = WeatherCommon.GetInst().CreateUnityObject(PrimitiveType.Quad, m_mat, Vector3.zero, Quaternion.identity, new Vector3(1.5f, 1, 1));
            m_alphaObj.name = "FishEyeAnimationStoryObject";
            m_alphaObj.transform.parent = m_sceneCamObj.transform;
            m_alphaObj.SetActive(false);
            m_alphaObj.transform.localPosition = new Vector3(0, 0, m_distance);
            m_alphaObj.transform.localRotation = Quaternion.identity;
        }

        float lastTime = info.LastTime;
        if (lastTime > 0)
        {
            m_alphaTime = lastTime - 0.1f;
            if (m_alphaTime < 0)
                m_alphaTime = 0.001f;
        }
        else
            m_alphaTime = Mathf.Abs(lastTime);

        if (m_fisheyeTexture == null)
            LoadFisheyeTexture();
        else
            m_mat.mainTexture = m_fisheyeTexture;

        m_alphaSpeed = (1 - m_targetValue) / m_alphaTime;
        if (m_alphaAdd)
        {
            m_currentVal = 1;
        }
        else
        {
            m_currentVal = m_targetValue;
        }
        m_alphaSpeed *= -1;

        m_direct = lastTime == 0;
        if (m_direct)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            Leave();
        }
    }

    protected override void Wait()
    {
        base.Wait();

        if (m_fisheyeTexture == null)
        {
            m_currentOutTime += Time.deltaTime;
            if (m_currentOutTime > m_waitOutTime)
            {
                MyLog.LogError("Cam not Load Texture Path =  " + DEFINE.ASSETBUNDLE_PATH_CAMERA_EFFECT_SHELTER + ". Current story ID : " + m_info.Key.ToString());
                SetState(eBaseEffectState.EFFECT_STATE_ENTER);
                return;
            }
            else
            {
                SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                return;
            }
        }
        m_mat.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_currentVal);
        m_daletTime = 0;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_alphaAdd && m_alphaObj != null)
            m_alphaObj.SetActive(true);
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        if (m_alphaObj != null)
        {
            if (m_alphaAdd)
            {
                m_currentVal += m_alphaSpeed * Time.deltaTime;
            }
            else
            {
                m_currentVal -= m_alphaSpeed * Time.deltaTime;
            }
            m_currentVal = Mathf.Clamp01(m_currentVal);

            m_mat.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_currentVal);
        }
    }

    protected override void Leave()
    {
        if (!m_alphaAdd && m_alphaObj != null)
            m_alphaObj.SetActive(false);

        if (m_jump || m_direct)
        {
            if(m_alphaAdd)
                m_mat.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_targetValue);
            else
                m_mat.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, 1);
        }
        base.Leave();
    }

    private void LoadFisheyeTexture()
    {
        m_fisheyeObject = new CObject(DEFINE.ASSETBUNDLE_PATH_CAMERA_EFFECT_SHELTER);
        m_fisheyeObject.IsMemoryFactory = true;
        m_fisheyeObject.ObjectType = eObjectType.Particle;
        m_fisheyeObject.CallBack = LoadComplete;
        m_fisheyeObject.Args = null;
        m_fisheyeObject.LoadObject();
    }

    private void LoadComplete(GameObject o, params object[] args)
    {
        if (o == null)
        {
            MyLog.DebugLogException("EffectBase LoadComplete failure");
            return;
        }
        m_fisheyeTexture = o.renderer.sharedMaterial.mainTexture as Texture2D;
        o.SetActive(false);
        m_fisheyeObject.DestroyGameObject(eObjectDestroyType.Memory);

        if (m_mat != null)
            m_mat.mainTexture = m_fisheyeTexture;
    }
}
