﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CStoryManage : SingletonObject<CStoryManage>{


    private Dictionary<eCameraStoryType, CBaseStory> m_CameraStoryDict = new Dictionary<eCameraStoryType, CBaseStory>();
    private Dictionary<int, SceneStoryContent> m_dirct = new Dictionary<int, SceneStoryContent>();
    //private List<CBaseStory> m_curuentStory = new  List<CBaseStory>();

    private bool m_isJump = false;

    private GameObject m_screenAnimationObj;
    private Material m_mat;
    private float m_alpha;
    private float m_speed = 1;
    private bool m_addAlpha;
    private Color m_color = new Color(0, 0, 0, 0);

    public void Init()
    {
        RegisteStory(new CInitStory());
        RegisteStory(new CMoveStory());
        RegisteStory(new CShakeStory());
        RegisteStory(new CRotationStory());
        RegisteStory(new CAnimatonStory());
        RegisteStory(new CTalkStory());
        RegisteStory(new CAvatarMoveStory());
        RegisteStory(new CAvatarSkillStory());
        RegisteStory(new CMonsterMoveStory());
        RegisteStory(new CMonsterSkillStory());
        RegisteStory(new CNpcLoaderStory());
        RegisteStory(new CNpcUnloaderStory());
        RegisteStory(new CEffectStory());
        //RegisteStory(new CLookatStory());
        RegisteStory(new CPlayAnimationStory());
        //RegisteStory(new CTextureStory());
        //RegisteStory(new CCameraLayerStory());
        RegisteStory(new CBattlePlayerCreateStory());
        RegisteStory(new CBattlePlayerRideStory());
        RegisteStory(new CBattlePlayerFlyStory());
        RegisteStory(new CBattlePlayerMoveStory());
        RegisteStory(new CBattlePlayerSkillStory());
        RegisteStory(new CPauseNpcStory());
        RegisteStory(new CShowUIStory());
        RegisteStory(new CFishEyeStory());
        RegisteStory(new CPlayerSoundStory());
    }

    public void LoadSources()
    {
        m_dirct = HolderManager.m_SceneStoryHolder.GetDict();

        foreach (KeyValuePair<int, SceneStoryContent> val in m_dirct)
        {
            string path = val.Value.PathSource;
            if (!string.IsNullOrEmpty(path))
            {
                LoadHelp.LoadObject("", path, ThreadPriority.Normal, null);
            }
        }
    }

    private void RegisteStory(CBaseStory story)
    {
        eCameraStoryType type = story.GetStoryType();
        if (!m_CameraStoryDict.ContainsKey(type))
        {
            m_CameraStoryDict.Add(type, story);
        }
    }

    public void SetInitStoryEffect(uint initStoryID, RegisterEvent callback,GameObject camObj, params object[] args)    //执行的总是第一个状态（初始状态）
    {
        if (initStoryID == 0)
            return;
        if (IsInStory())
        {
            MyLog.LogError("CStoryManage SetInitStoryEffect fail : story is runing. Be in story is : " + initStoryID.ToString());
            return;
        }

        SceneStoryContent info = HolderManager.m_SceneStoryHolder.GetStaticInfo(initStoryID);
        if (null == info)
        {
            MyLog.LogError("CStoryManage SetInitStoryEffect SceneStoryContent is null , current loading story ID = " + initStoryID);
            return;
        }

        CBaseStory story = GetExistStory((eCameraStoryType)info.StoryType);
        if (story != null)
        {
            story.Init(info, camObj, callback, args);
        }
        else
        {
            MyLog.LogError("CStoryManage SetInitStoryEffect can not find CBaseStory in registe list. current loading story ID = " + initStoryID);
        }
    }


    public void NextStory(uint dwEffectID, GameObject camObj, RegisterEvent callback, params object[] args)  //状态执行完毕执行下一个状态
    {
        if (dwEffectID == 0)
            return;
        SceneStoryContent info = HolderManager.m_SceneStoryHolder.GetStaticInfo(dwEffectID);
        if (null == info)
        {
            MyLog.LogError("CStoryManage NextStory SceneStoryContent is null , current loading story ID = " + dwEffectID);
            return;
        }
        CBaseStory story = GetExistStory((eCameraStoryType)info.StoryType);
        if (story != null)
        {
            story.Init(info, camObj, callback, args);
        }
        else
        {
            MyLog.LogError("CStoryManage NextStory can not find CBaseStory in registe list. current loading story ID = " + dwEffectID);
        }
    }

    public void ForceNextStoryState()   //强制执行下一个状态
    {
        foreach (KeyValuePair<SceneStoryContent, CBaseStory> val in CBaseStory.m_currentState)
        {
            val.Value.ForceNextStory();
        }
    }

    public CBaseStory GetExistStory(eCameraStoryType type)
    {
        CBaseStory story = null;
        m_CameraStoryDict.TryGetValue(type, out story);

        return story;
    }

    public void Update()
    {
        if (m_isJump)
        {
            JumpScreenAnimation();
        }

        if (!CBaseStory.IsInGameStory)
            return;

        if (m_CameraStoryDict.Count > 0)
        {
            foreach (KeyValuePair<eCameraStoryType, CBaseStory> kvp in m_CameraStoryDict)
            {
                kvp.Value.Update();
            }
        }

        if (CInitStory.curState == eGameState.Home && CBaseStory.m_pBattlePlayer != null)
        {
            CBaseStory.m_pBattlePlayer.Update();
            if (CBaseStory.m_pet != null)
                CBaseStory.m_pet.Update();
        }
        
        //m_curuentStory = new List<CBaseStory>(CBaseStory.m_currentState.Values);
        //for (int i = 0 ;i < m_curuentStory.Count;i++)
        //{
        //    m_curuentStory[i].Update();
        //}
    }

    public void Jump()
    {
        m_isJump = true;
        if (m_screenAnimationObj == null)
        {
            CreateQuad();
        }
        else
        {
            m_mat.color = new Color(0, 0, 0, 0);
            m_alpha = 0;
            m_screenAnimationObj.SetActive(true);
            m_addAlpha = true;
        }
        SingletonObject<TaskMediator>.GetInst().m_btnPass.SetActive(false);
    }

    private void JumpStory()
    {
        CBaseStory.Jump();
        ForceNextStoryState();
    }

    private void JumpScreenAnimation()
    {
        if (!m_screenAnimationObj)
        {
            JumpStory();
            m_isJump = false;
        }

        if (m_addAlpha)
        {
            m_alpha += Time.deltaTime * m_speed;
            m_alpha = Mathf.Clamp01(m_alpha);
            m_color.a = m_alpha;
            m_mat.color = m_color;

            if (m_alpha >= 1)
            {
                m_addAlpha = false;
                JumpStory();
            }
        }
        else
        {
            m_alpha -= Time.deltaTime * m_speed;
            m_alpha = Mathf.Clamp01(m_alpha);
            m_color.a = m_alpha;
            m_mat.color = m_color;

            if (m_alpha <= 0)
            {
                m_addAlpha = true;
                m_isJump = false;
                m_screenAnimationObj.SetActive(false);
            }
        }
    }

    private void CreateQuad()
    {
        Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_SCREEN_BLEND_LATE_3100);
        if(!shader)
            return;
        m_mat = new Material(shader);
        m_mat.color = new Color(0,0,0,0);
        m_screenAnimationObj = WeatherCommon.GetInst().CreateUnityObject(PrimitiveType.Quad, m_mat, Vector3.zero, Quaternion.identity, new Vector3(1.5f, 1, 1));
        m_screenAnimationObj.name = "GameStoryJumpAnimationQuad";
        m_alpha = 0;
        m_addAlpha = true;

        m_screenAnimationObj.transform.parent = CCamera.GetInst().GetCameraObj().transform;
        m_screenAnimationObj.transform.localPosition = new Vector3(0, 0, 0.45f);
        m_screenAnimationObj.transform.localRotation = Quaternion.identity;
    }

    public void CheckState()
    {
        CBaseStory.ResetInGameStory();
        //JumpStory();
        eBaseEffectState state;
        foreach (KeyValuePair<eCameraStoryType, CBaseStory> val in m_CameraStoryDict)
        {
            state = val.Value.State;
            if (state != eBaseEffectState.EFFECT_STATE_NONE)
            {
                MyLog.LogError(val.Key.ToString() + " story has in state " + state.ToString());
                if (val.Value.EndStory)
                    val.Value.ForceNextStory();
                else
                    val.Value.SetState(eBaseEffectState.EFFECT_STATE_NONE);
            }
        }
        SingletonObject<FlywordMediator>.GetInst().ShowFlyWord = true;
    }

    public bool IsInStory()
    {
        bool instory = CBaseStory.m_previousState.Count > 0;
        if (!instory)
            instory = CBaseStory.m_currentState.Count > 0;
        if (!instory)
            instory = CBaseStory.m_nextState.Count > 0;
        return instory;
    }
}
