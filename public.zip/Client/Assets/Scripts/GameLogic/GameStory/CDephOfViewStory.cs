﻿using UnityEngine;
using System.Collections;

public class CDephOfViewStory : CBaseStory {

    public CDephOfViewStory()
    {
 
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
    }

}
