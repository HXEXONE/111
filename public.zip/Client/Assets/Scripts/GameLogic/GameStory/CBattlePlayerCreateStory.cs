﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 此类和 CModeRideStory 互斥, 此类是CModeRideStory行为的分解,与CBattlePlayerRideStory CBattlePlayerMoveStory 共同协作
/// </summary>
public class CBattlePlayerCreateStory : CBaseStory {

    private bool m_bCreate;

    private uint m_clothID;
    private uint m_jobID;
    private uint m_weaponID;
    private Vector3 m_position;

    private uint m_iAIID;

    private uint[] m_iSkillID = new uint[4]{0,0,0,0};

    private int m_nAttack;

    private float m_waitOutTime = 10f;
    private float m_currentOutTime = 0;

    private float m_privateLast;

    public CBattlePlayerCreateStory()
    {
        m_type = eCameraStoryType.CREATE_BATTLE_PLAYER;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_currentOutTime = 0;

        int bt = MyConvert_Convert.ToInt32(m_list[0]);
        m_bCreate = MyConvert_Convert.ToBoolean(bt);
        if (!m_bCreate)
            return;
        uint npcMapID = MyConvert_Convert.ToUInt32(m_list[1]);

        SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(npcMapID);
        if (npcmap != null)
            m_clothID = GetCurrentJobNpcID(npcmap);
        else
        {
            MyLog.LogError("CBattlePlayerCreateStory Init SceneStoryNpcContent is null m_npcMapID = " + npcMapID.ToString());
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        uint weaponMapID = MyConvert_Convert.ToUInt32(m_list[2]);
        SceneStoryNpcContent weaponmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(weaponMapID);
        if (weaponmap != null)
            m_weaponID = GetCurrentJobNpcID(weaponmap);
        else
        {
            MyLog.LogError("CBattlePlayerCreateStory Init SceneStoryNpcContent is null m_weaponMapID = " + weaponMapID.ToString());
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        stHomeAvatarInfo jobInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        if (jobInfo != null)
            m_jobID = jobInfo.uiPlayerJob;
        else
        {
            MyLog.LogError("CBattlePlayerCreateStory current job id can not find");
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_iAIID = MyConvert_Convert.ToUInt32(m_list[3]);

        m_nAttack = MyConvert_Convert.ToInt32(m_list[4]);

        SceneStoryNpcContent skillmap;
        uint skillid = 0;
        m_iSkillID = new uint[4] { 0, 0, 0, 0 };
        int count = m_list.Count - 5;
        for (int i = 0; i < count; i++)
        {
            skillid = MyConvert_Convert.ToUInt32(m_list[i + 5]);
            if (skillid == 0)
                continue;
            skillmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(skillid);
            if (skillmap == null)
                continue;
            m_iSkillID[i] = GetCurrentJobNpcID(skillmap);
        }

        m_position = info.PointDirect;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_bCreate)
        {
            Quaternion rotation = Quaternion.identity;
            if (m_pBattlePlayer == null)
                m_pBattlePlayer = SingletonObject<BattleScene>.GetInst().CreateBattlePlayer(m_position, rotation, m_nAttack, m_jobID, m_weaponID, m_clothID, m_iAIID, m_iSkillID);
            else
                MyLog.LogWarning("CBattlePlayerCreateStory Enter create BattlePlayer, BattlePlayer is exist");
        }
        else
        {
            if (m_pBattlePlayer == null)
                MyLog.LogError("CBattlePlayerCreateStory Enter Destory BattlePlayer, BattlePlayer is null");
            else
            {
                BattleScene bs = SingletonObject<BattleScene>.GetInst();
                if (bs != null)
                {
                    bs.RemoveMonsterIndex(m_pBattlePlayer.Index, m_pBattlePlayer);
                    m_pBattlePlayer = null;
                }
                else
                {
                    MyLog.LogError("CBattlePlayerCreateStory Enter Destory BattlePlayer Fail, BattleScene is null");
                }
            }
        }
    }

    protected override void ForUpdate()
    {
        if (m_bCreate)
        {
            if (m_pBattlePlayer != null && m_pBattlePlayer.GetTransform() == null)
            {
                m_currentOutTime += Time.deltaTime;
                if (m_currentOutTime < m_waitOutTime)
                {
                    MyLog.Log("Wait create BattlePlayer");
                    return;
                }
            }
        }
        base.ForUpdate();
    }
}
