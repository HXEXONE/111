﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 此类和 CModeRideStory 互斥, 此类是CModeRideStory行为的分解,与CBattlePlayerCreateStory CBattlePlayerMoveStory 共同协作
/// </summary>
public class CBattlePlayerFlyStory : CBaseStory {

    private uint m_petID;
    private bool m_fly;  //true 上马 false 下马

    private float m_waitOutTime = 10f;
    private float m_currentOutTime = 0;

    private float m_privateLast;

    public CBattlePlayerFlyStory()
        : base()
    {
        m_type = eCameraStoryType.Fly;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        int rtemp = MyConvert_Convert.ToInt32(m_list[0]);
        m_fly = MyConvert_Convert.ToBoolean(rtemp);
        if (m_list.Count >= 2)
            m_petID = MyConvert_Convert.ToUInt32(m_list[1]);

        if (m_fly && m_pBattlePlayer != null)
        {
            m_pBattlePlayer.LoadPet(m_petID);
        }
    }

    protected override void Wait()
    {
        base.Wait();
        if (m_fly && m_pBattlePlayer != null)
        {
            if (!m_pBattlePlayer.BPetLoadCompleted)
            {
                m_currentOutTime += Time.deltaTime;
                if (m_currentOutTime > m_waitOutTime)
                {
                    MyLog.LogError("Cam not Load Pet ID = " + m_petID.ToString() + ". Current story ID : " + m_info.Key.ToString());
                    SetState(eBaseEffectState.EFFECT_STATE_ENTER);
                    return;
                }
                else
                {
                    MyLog.Log("Wait create Mount");
                    SetState(eBaseEffectState.EFFECT_STATE_WAIT);
                    return;
                }
            }
            else
            {
                Transform trans = m_pBattlePlayer.GetTransform();
                Vector3 pos = trans == null ? Vector3.zero : trans.position;
                pos = pos + new Vector3(Random.Range(3, 8), 0, Random.Range(3, 8));
                BattleScene batlescene = SingletonObject<BattleScene>.GetInst();
                if(m_pet == null)
                    m_pet = batlescene.CreateGameStoryPet(m_petID, pos);
                if (m_pet != null)
                    m_pBattlePlayer.BindPet(m_pet);
                else
                    MyLog.LogError("CBattlePlayerFlyStory Wait Can not find petID = " + m_petID.ToString());
            }
        }

        m_daletTime = 0;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_pBattlePlayer != null)
        {
            if (m_fly)
                m_pBattlePlayer.BeginFly(true);
            else
            {
                m_pBattlePlayer.EndFly();
                UnityCallBackManager.GetInst().AddCallBack(1, DelayRemovePet,null);
            }
        }
        else
            MyLog.LogError("CBattlePlayerFlyStory Enter not BaseBattlePlayer");
    }

    private void DelayRemovePet(params object[] args)
    {
        if (m_pet != null)
        {
            BattleScene ba = SingletonObject<BattleScene>.GetInst();
            ba.RemoveMonsterIndex(m_pet.Index, m_pet);
            m_pet = null;
        }
    }
}
