﻿using UnityEngine;
using System.Collections;

public class CAnimatonStory : CBaseStory {

    private float m_alphaSpeed;
    private float m_alphaTime;
    private bool m_alphaAdd;

    private Color m_color;

    private GameObject m_alphaObj;
    private Material m_mat;
    private float m_distance;

    private Vector3 m_colorDir;

    public CAnimatonStory()
    {
        m_type = eCameraStoryType.ANIMATION;
        m_distance = 0.5f;
        m_color = new Color(0, 0, 0, 0);
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_alphaAdd = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(m_list[0]));

        if (m_alphaObj == null)
        {
            Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_SCREEN_BLEND_LATE_3100);
            if(!shader)
            {
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            m_mat = new Material(shader);
            m_mat.color = new Color(0, 0, 0, 0);
            m_alphaObj = WeatherCommon.GetInst().CreateUnityObject(PrimitiveType.Quad, m_mat, Vector3.zero, Quaternion.identity, new Vector3(1.5f, 1, 1));
            m_alphaObj.name = "AnimationStoryObject";
            m_alphaObj.transform.parent = m_sceneCamObj.transform;
            m_alphaObj.SetActive(false);
            m_alphaObj.transform.localPosition = new Vector3(0, 0, m_distance);
            m_alphaObj.transform.localRotation = Quaternion.identity;
        }

        float lastTime = info.LastTime;
        if (lastTime > 0)
        {
            m_alphaTime = lastTime - 0.1f;
            if (m_alphaTime < 0)
                m_alphaTime = 0.001f;
        }
        else
            m_alphaTime = Mathf.Abs(lastTime);

        m_alphaSpeed = 1 / m_alphaTime;

        m_colorDir = info.PointDirect;
        m_color = new Color(m_colorDir.x, m_colorDir.y, m_colorDir.z,0);
        if (m_alphaAdd)
        {
            m_color.a = 0;
        }
        else
        {
            m_color.a = 1;
        }
        m_mat.color = m_color;
    }

    protected override void Enter()
    {
        base.Enter();
        if (m_alphaAdd && m_alphaObj != null)
            m_alphaObj.SetActive(true);
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        if (m_alphaObj != null)
        {
            if (m_alphaAdd)
            {
                m_color.a += m_alphaSpeed * Time.deltaTime;
            }
            else
            {
                m_color.a -= m_alphaSpeed * Time.deltaTime;
            }
            m_color.a = Mathf.Clamp01(m_color.a);
            m_mat.color = m_color;
        }
    }

    protected override void Leave()
    {
        if (!m_alphaAdd && m_alphaObj != null)
            m_alphaObj.SetActive(false);

        if (m_jump)
        {
            if (m_alphaObj)
                m_alphaObj.SetActive(false);
            m_color.a = 0;
            if (m_mat)
                m_mat.color = m_color;
        }

        base.Leave();
    }
}
