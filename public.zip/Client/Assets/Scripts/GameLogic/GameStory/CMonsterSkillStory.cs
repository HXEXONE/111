﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CMonsterSkillStory : CBaseStory {

    //uint m_skillID = 0;
    uint m_npcID = 0;
    uint m_npcIDtarget;
    uint m_skillID;
    uint m_skillOrTarget; //1 攻击目标ID  2 技能ID

    public CMonsterSkillStory()
    {
        m_type = eCameraStoryType.MONSTER_SKILL;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        uint npcMapID = MyConvert_Convert.ToUInt32(m_list[0]);

        SceneStoryNpcContent npcmap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(npcMapID);
        if (npcmap != null)
            m_npcID = GetCurrentJobNpcID(npcmap);
        else
        {
            MyLog.LogError("CMonsterSkillStory Init npcmap is null m_npcMapID = " + npcMapID.ToString() + "\tCurrent Story ID = " + info.Key);
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_skillOrTarget = MyConvert_Convert.ToUInt32(m_list[1]);
        uint skillortargetID = MyConvert_Convert.ToUInt32(m_list[2]);
        if (m_skillOrTarget == 1)
        {
            SceneStoryNpcContent skillIDMap = HolderManager.m_SceneStoryNpcHolder.GetStaticInfo(skillortargetID);
            if (skillIDMap == null)
            {
                MyLog.LogError("CMonsterSkillStory Init skillIDMap is null npcMapID = " + skillortargetID.ToString() + "\tCurrent Story ID = " + info.Key);
                SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                return;
            }
            m_npcIDtarget = GetCurrentJobNpcID(skillIDMap);
        }
        else
            m_skillID = skillortargetID;
        
        if (m_jump)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
        }
    }


    protected override void Enter()
    {
        base.Enter();
        PlayNPCSkill();
    }

    private void PlayNPCSkill()
    {
        CBaseNpc npc = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_npcID);
        //CBaseNpc npc = null;
        //CBaseStory.m_createdNpc.TryGetValue(m_npcID,out npc);
        if (npc == null)
        {
            MonsterHitResultCallback();
            MyLog.LogError("CMonsterSkillStory cam not find npc ID : " + m_npcID.ToString() + ". Current story ID : " + m_info.Key.ToString());
            return;
        }

        if (m_skillOrTarget == 1)
        {
            CBaseNpc target = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_npcIDtarget);
            if (target == null)
            {
                MyLog.LogWarning("CMonsterSkillStory PlayNPCSkill can not find CBaseNpc m_npcIDtarget = " + m_npcIDtarget.ToString() + "\tCurrent Story ID = " + m_info.Key);
            }
            npc.CurrTarget = target;
            npc.PauseNpc(false,true);
        }
        else
        {
            npc.CurrTarget = null;
            npc.PauseNpc(true,true);

            if (m_continueTime == -1)
            {
                npc.HitResultCallback = MonsterHitResultCallback;
                npc.Command(eCommandType.UseSkill, new UseSkillCommandArg(m_skillID, null, false, null));
            }
            else
                npc.UseSkillNotHit(m_skillID);
        }
    }

    private void MonsterHitResultCallback()
    {
        Leave();
    }



}
