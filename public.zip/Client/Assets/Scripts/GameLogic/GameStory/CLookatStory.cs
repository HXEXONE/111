﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CLookatStory : CBaseStory {


    private int m_lookType;
    private Vector3 m_position;
    private float m_moveSpeed;
    private Vector3 m_direct;

    private CBaseNpc m_curNpc;
    private ModelAnimation m_homeMonster;

    public CLookatStory()
    {
        //m_type = eCameraStoryType.LOOKAT;
    }


    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        m_lookType = MyConvert_Convert.ToInt32(m_list[0]);
        m_position = info.PointDirect;

    }

    protected override void Enter()
    {
        base.Enter();

        switch (m_lookType)
        {
            case 0:
                {
                    m_lookAt = new GameObject("GameStoryLookAt");
                    m_lookAt.transform.position = m_position;


                    for (int i = 0; i < m_currentCreate.Count; i++)
                    {
                        if (CInitStory.curState != eGameState.Home)
                        {
                            m_curNpc = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_currentCreate[i]);
                            if (m_curNpc != null)
                            {
                                Vector3 pos = m_position;
                                pos.y = m_curNpc.GetTransform().position.y;
                                m_curNpc.GetTransform().LookAt(pos);
                            }
                        }
                        else
                        {
                            m_homeMonster = SingletonObject<HomeScene>.GetInst().GetHomeMonster(m_currentCreate[i]);
                            if (m_homeMonster != null)
                            {
                                Vector3 pos = m_position;
                                pos.y = m_homeMonster.GetTransform().position.y;
                                m_homeMonster.GetTransform().LookAt(pos);
                            }
                        }
                    }
                    //foreach (KeyValuePair<uint, CBaseNpc> val in CBaseStory.m_createdNpc)
                    //{
                    //    m_curNpc = val.Value;
                    //    Vector3 pos = m_position;
                    //    pos.y = m_curNpc.GetTransform().position.y;
                    //    m_curNpc.GetTransform().LookAt(pos);
                    //}

                    SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                    break;
                }
            case 1:
                {
                    float lastTime = m_info.LastTime;
                    float completeTime = 0;
                    if (lastTime >= 0)
                    {
                        completeTime = lastTime - 0.1f;
                        if (completeTime <= 0)
                            completeTime = 0.001f;
                    }
                    else
                    {
                        completeTime = lastTime;
                    }
                    float distance = Vector3.Distance(m_lookAt.transform.position, m_position);
                    m_moveSpeed = distance / completeTime;

                    m_direct = m_position - m_lookAt.transform.position;
                    m_direct.Normalize();
                    break;
                }
            case 2:
                {
                    if (m_lookAt != null)
                        Object.Destroy(m_lookAt);

                    SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
                    break;
                }
        }
    }

    protected override void ForUpdate()
    {
        base.ForUpdate();
        m_lookAt.transform.Translate(m_direct * m_moveSpeed * Time.deltaTime);
        for (int i = 0; i < m_currentCreate.Count; i++)
        {
            if (CInitStory.curState != eGameState.Home)
            {
                m_curNpc = SingletonObject<BattleScene>.GetInst().GetNpcTrans(m_currentCreate[i]);
                if (m_curNpc != null)
                {
                    Vector3 pos = m_position;
                    pos.y = m_curNpc.GetTransform().position.y;
                    m_curNpc.GetTransform().LookAt(pos);
                }
            }
            else
            {
                m_homeMonster = SingletonObject<HomeScene>.GetInst().GetHomeMonster(m_currentCreate[i]);
                if (m_homeMonster != null)
                {
                    Vector3 pos = m_position;
                    pos.y = m_homeMonster.GetTransform().position.y;
                    m_homeMonster.GetTransform().LookAt(pos);
                }
            }
        }

        //foreach (KeyValuePair<uint, CBaseNpc> val in CBaseStory.m_createdNpc)
        //{
        //    m_curNpc = val.Value;
        //    Vector3 pos = m_position;
        //    pos.y = m_curNpc.GetTransform().position.y;
        //    m_curNpc.GetTransform().LookAt(pos);
        //}
    }
}
