﻿using UnityEngine;
using System.Collections;

public class CPlayAnimationStory : CBaseStory {

    private Animation[] m_animation;
    private string m_objectScenePath = "DynamicObject/GUT/";
    private string m_sceneName;
    private string m_animationName;

    public CPlayAnimationStory()
    {
        m_type = eCameraStoryType.PLAY_ANIMATUIN;
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);

        if (CInitStory.curState == eGameState.Home)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
        //string objName = m_list[0];
        //string animationName = m_list[1];

        m_animationName = m_list[0];
        GameObject sceneObject = SingletonObject<BattleScene>.GetInst().GetSceneObj();
        if (sceneObject == null)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }
        Transform sceneTran = sceneObject.transform;
        m_sceneName = sceneTran.name;
        string scenePath = m_objectScenePath + m_animationName;

        Transform obj = sceneTran.Find(scenePath);
        
        if (obj == null)
        {
            MyLog.LogWarning("Can not find GameObject : " + scenePath + "  will find : " + scenePath + "(Clone)");
            scenePath += "(Clone)";
            obj = sceneTran.Find(scenePath);
        }

        if (obj == null)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            MyLog.LogError("Can not find GameObject : " + scenePath);
            return;
        }

        m_animation = obj.GetComponentsInChildren<Animation>();
        if (m_animation == null || m_animation.Length <= 0)
        {
            SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
            return;
        }

        m_animation[0].Play();
        SetState(eBaseEffectState.EFFECT_STATE_LEAVE);
    }

}
