﻿using UnityEngine;
using System.Collections;

public class CCreateNPCStory : CBaseStory {

    public CCreateNPCStory()
    {
 
    }

    public override void Init(SceneStoryContent info, GameObject camObj, RegisterEvent callback, params object[] args)
    {
        base.Init(info, camObj, callback, args);
    }

}
