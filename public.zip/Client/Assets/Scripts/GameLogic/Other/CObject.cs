using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

//GameObject�ķ�װ��,�κλᴴ��GameObject�ĵط����滻ΪCObject�������Ժ�����չ

public delegate void ObjectCallback(GameObject o, params object[] args);

//ɾ��ģʽ
public enum eObjectDestroyType
{
    Memory,//ɾ���ڴ��
    Normal,//ֻɾ������
    UnloadAll,//����(����Assetbundle)�ͷ�
}


public enum eObjectType
{
    None,
    Component,//NGUI���
    Npc,//npc
    DropObject,//�����������,��ҵ�
    Scene,//����
    HomeAvatar,//��԰���
    Weapon,//����
    Pet,//����
    ReplaceModel, //���ģ��
    Stage,//����avatar������̨
    Mount,//����
    PYX,//ʥ��
    Partner,    //С���
    Particle,   //����
    UIParticle,//UI��Ч
    CameraEffect,//��ͷЧ��:
    UiScene,//ui����
    Guide,  //����ָ��
    Texture,  //����
    Card,//����ϵͳ�õĿ���
    LongJing,  //����
}


public class CObject
{
    private GameObject m_pObject;//������ɵ�ģ��
    private Texture2D m_pTexture2D;
    public Texture2D PTexture2D
    {
        get { return m_pTexture2D; }
    }

    private bool m_bCreateObjCompleted = false;//�ж�ģ���Ƿ���ȫ�������

    private Vector3 m_BornPosition = new Vector3(0, 0, 0);
    private Quaternion m_BornRotation = new Quaternion();

    private int m_nLayer;//���,NPC,���εȵ�

    private ObjectCallback m_pCallback;//�ص�����

    private object[] m_args = null;

    private string m_path;

    public string Path
    {
        get { return m_path; }
    }

    private string m_sName;

    private bool m_bMemoryFactory;//�Ƿ�Ҫ���ڴ��
    private eObjectType m_ObjectType;

    private bool m_bDeleted = false;//����Ƿ�ɾ��

    private bool m_formMemory = false;
    public bool FormMemory
    {
        get { return m_formMemory; }
    }

    private bool m_bParticleActive = true;
    public bool BParticleActive
    {
        get { return m_bParticleActive; }
        set { m_bParticleActive = value; }
    }

    public CObject(string path)
    {
        m_BornPosition = new Vector3(0, 0, 0);
        m_BornRotation = new Quaternion();
        m_nLayer = 0;
        m_pCallback = null;
        m_args = null;
        m_path = path;
        m_bMemoryFactory = false;
        m_ObjectType = eObjectType.None;
        m_sName = "";
    }

    public Vector3 BornPosition
    {
        get { return m_BornPosition; }
        set
        {
            m_BornPosition = value;
        }
    }

    public Quaternion BornRotation
    {
        get { return m_BornRotation; }
        set
        {
            m_BornRotation = value;
        }
    }

    public Vector3 Position
    {
        get
        {
            return m_pObject.transform.position;
        }
        set
        {
            m_pObject.transform.position = value;
        }
    }

    public int Layer
    {
        set
        {
            m_nLayer = value;
        }
        get
        {
            return m_nLayer;
        }
    }

    public string Name
    {
        set
        {
            m_sName = value;
        }
        get
        {
            return m_sName;
        }
    }

    public ObjectCallback CallBack
    {
        set
        {
            m_pCallback = value;
        }
    }

    public object[] Args
    {
        get { return m_args; }
        set
        {
            m_args = value;
        }
    }

    public bool IsMemoryFactory
    {
        set
        {
            m_bMemoryFactory = value;
        }
    }

    public eObjectType ObjectType
    {
        set
        {
            m_ObjectType = value;
        }
    }


    public void LoadObject()
    {
        if (m_bMemoryFactory)
        {
            switch (m_ObjectType)
            {
                case eObjectType.Npc:
                    {
                        SingletonObject<NpcFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.DropObject:
                    {
                        SingletonObject<DropObjectFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.HomeAvatar:
                    {
                        SingletonObject<HomeAvatarFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Weapon:
                    {
                        SingletonObject<WeaponFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Pet:
                    {
                        SingletonObject<PetFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.ReplaceModel:
                    {
                        SingletonObject<ReplaceModelFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Stage:
                    {
                        SingletonObject<StageFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Mount:
                    {
                        SingletonObject<MountFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.PYX:
                    {
                        SingletonObject<PYXFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Partner:
                    {
                        SingletonObject<PartnerFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Particle:
                    {
                        SingletonObject<ParticleSystemFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.UIParticle:
                    {
                        SingletonObject<UIParticleSystemFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.CameraEffect:
                    {
                        SingletonObject<CameraEffectFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.UiScene:
                    {
                        SingletonObject<UiSceneFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Guide:
                    {
                        SingletonObject<GuideFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Texture:
                    {
                        SingletonObject<TextureFactory>.GetInst().GetMemoryTexture(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.Card:
                    {
                        SingletonObject<CardFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
                case eObjectType.LongJing:
                    {
                        SingletonObject<LongjingFactory>.GetInst().GetMemoryObj(m_path, LoadMemoryObjectCompleted);
                    }
                    break;
            }

        }
        else
        {
            string interim = "";
            LoadHelp.LoadObject(interim, m_path, ThreadPriority.Normal, LoadObjectCompleted);
        }


    }

    private void LoadMemoryObjectCompleted(string interim, UnityEngine.Object asset)
    {
        if (m_ObjectType != eObjectType.Texture)
        {
            m_pObject = (GameObject)asset;
            if (m_bDeleted)
            {
                if (m_pObject == null)
                    return;
                MyLog.Log("CObject Gameobject is deleted : " + m_pObject.name);
                if (m_ObjectType == eObjectType.Particle)
                    m_pObject.SetActive(false);
                DestroyGameObject(eObjectDestroyType.Memory);
                m_pCallback = null;
                return;
            }
            m_formMemory = bool.Parse(interim);
        }
        else
        {
            m_pTexture2D = asset as Texture2D;
            if (m_bDeleted)
            {
                m_pCallback = null;
            }
        }

        InitObject();
    }

    private void LoadObjectCompleted(string interim, UnityEngine.Object asset)
    {
        if (m_ObjectType != eObjectType.Scene)
        {
            m_pObject = (GameObject)UnityEngine.Object.Instantiate(asset);
        }
        else
        {
            m_pObject = (GameObject)asset;
        }

        InitObject();
    }

    private void InitObject()
    {
        if (m_ObjectType != eObjectType.Texture)
        {
            if (null == m_pObject)
            {
                if (m_pCallback != null)
                {
                    MyLog.Log("  m_pCallback null  : " + m_path);
                    m_pCallback(null, false);//��Ϊ��ʱҲ���лص������ڻص�����������������
                }
                return;
            }

            //ui��Ч��Ϊ�漰����Ⱦ�㼶,�������ﲻ��ʾ
            if (m_ObjectType != eObjectType.UIParticle)
            {
                m_pObject.SetActive(true);
            }

            ParticleSystem[] pss = m_pObject.GetComponentsInChildren<ParticleSystem>(true);
            if (pss != null)
            {
                int cot = pss.Length;
                for (int i = 0; i < cot; i++)
                {
                    pss[i].gameObject.SetActive(false);
                }
            }

            TrailRenderer[] trs = m_pObject.GetComponentsInChildren<TrailRenderer>(true);
            foreach (TrailRenderer tr in trs)
            {
                TrailRenderCleanTrail trct = tr.GetComponent<TrailRenderCleanTrail>();
                if (trct == null) trct = tr.gameObject.AddComponent<TrailRenderCleanTrail>();
            }

            m_pObject.transform.position = m_BornPosition;
            m_pObject.transform.rotation = m_BornRotation;
            m_pObject.transform.localScale = Vector3.one;

            //m_pObject.SetActive(true);

            if (m_sName != "")
            {
                m_pObject.name = m_sName;
            }

            if (m_nLayer != 0)
            {
                Common.SetObjectAlllayer(m_pObject, m_nLayer);
            }

            if (m_pCallback != null)
            {
                m_pCallback(m_pObject, m_args);//�ص�����
            }

            //ui��Ч��Ϊ�漰����Ⱦ�㼶,�������ﲻ��ʾ
            //if (m_ObjectType == eObjectType.UIParticle)
            //{
            //    if (m_pObject != null)
            //        m_pObject.SetActive(true);
            //}

            if (CParticleManager.IsOpen && m_bParticleActive)
            {
                int cot = pss.Length;
                for (int i = 0; i < cot; i++)
                {
                    pss[i].gameObject.SetActive(true);
                }
            }


        }
        else
        {
            if (m_pCallback != null)
            {
                m_pCallback(null, m_args);//�ص�����
            }
        }
        m_bCreateObjCompleted = true;
    }

    public GameObject GetObj()
    {
        return m_pObject;
    }
    public Transform transform
    {
        get
        {
            if (null == m_pObject)
            {
                return null;
            }
            return m_pObject.transform;
        }
    }
    public GameObject gameCObject
    {
        get { return m_pObject; }
    }

    public void DestroyGameObject(eObjectDestroyType type)
    {
        switch (type)
        {
            case eObjectDestroyType.Memory:
                {
                    if (m_bMemoryFactory)
                    {
                        switch (m_ObjectType)
                        {
                            case eObjectType.Npc:
                                {
                                    SingletonObject<NpcFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.ReplaceModel:
                                {
                                    SingletonObject<ReplaceModelFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.DropObject:
                                {
                                    SingletonObject<DropObjectFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.HomeAvatar:
                                {
                                    SingletonObject<HomeAvatarFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Weapon:
                                {
                                    SingletonObject<WeaponFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Pet:
                                {
                                    SingletonObject<PetFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Stage:
                                {
                                    SingletonObject<StageFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Mount:
                                {
                                    SingletonObject<MountFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.PYX:
                                {
                                    SingletonObject<PYXFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Particle:
                                {
                                    if (m_pObject != null)
                                        m_pObject.SetActive(false);
                                    SingletonObject<ParticleSystemFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.UIParticle:
                                {
                                    if (m_pObject != null)
                                        m_pObject.SetActive(false);
                                    SingletonObject<UIParticleSystemFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Partner:
                                {
                                    SingletonObject<PartnerFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.CameraEffect:
                                {
                                    SingletonObject<CameraEffectFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.UiScene:
                                {
                                    SingletonObject<UiSceneFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Guide:
                                {
                                    SingletonObject<GuideFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.Card:
                                {
                                    SingletonObject<CardFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                            case eObjectType.LongJing:
                                {
                                    SingletonObject<LongjingFactory>.GetInst().RemoveMemoryObj(m_pObject);
                                }
                                break;
                        }
                    }
                }
                break;
            case eObjectDestroyType.Normal:
                {
                    UnityEngine.Object.Destroy(m_pObject);
                }
                break;
            case eObjectDestroyType.UnloadAll:
                {
                    if (m_ObjectType != eObjectType.Texture)
                        UnityEngine.Object.Destroy(m_pObject);
                    else
                        UnityEngine.Object.DestroyImmediate(m_pTexture2D);
                    LoadHelp.RemoveObject(m_path, false);
                }
                break;
        }
        m_bDeleted = true;

        Release();
    }

    public bool IsLoadCompleted()
    {
        return m_bCreateObjCompleted;
    }

    private void Release()
    {
        m_pObject = null;
        m_pCallback = null;
        m_args = null;
        m_path = string.Empty;
        m_sName = string.Empty;
        m_pTexture2D = null;
    }

}


