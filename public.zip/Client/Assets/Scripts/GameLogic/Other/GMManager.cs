﻿using System;
using System.Collections.Generic;
using System.IO;
using Protocol;
using Network;
using UnityEngine;

public class GMManager:SingletonObject<GMManager>
{
    public string m_lastGmCommad;//上一条GM命令
    public void RegisteMessages(NetworkClient pClient)
    {

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_GM_CMD, onGameAckGMCMD, false);//GM命令返回
    }

    private void onGameAckGMCMD(BinaryReader br)
    {
        G2CAckGmCmd msg = new G2CAckGmCmd();
        msg.Read(br);
        if (msg.uiRet == 1)
        {
            ShowGMResult("Use GM Command Success!", true);
            if (m_lastGmCommad.Contains("/wd"))
            {
                SingletonObject<Avatar>.GetInst().m_bGMInvincible = true;
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip("Invincible open!", Color.green);
            }
        }
        else
        {
            ShowGMResult("Error:Wrong GM Command or args!", false);
        }
    }

    public void ShowGMResult(string tipstr, bool bsuc)
    {
        if (bsuc)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tipstr, Color.green);
        }
        else
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tipstr, Color.red);
        }

    }
}
