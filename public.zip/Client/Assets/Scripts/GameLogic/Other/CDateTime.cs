using UnityEngine;
using System.Collections;
using System;

public class CDateTime
{
	public static int GetWeek(int year,int month,int day)
	{
		DateTime dt = new DateTime(year,month,day);
		return (int)dt.DayOfWeek;
	}
	
	private static DateTime TransToDateTime(string sDate)
	{
		string[] strs = sDate.Split(':');
		if(strs.Length < 6)//年月日时分秒
		{
			return new DateTime();
		}
		int year = MyConvert_Convert.ToInt32(strs[0]);
		int month = MyConvert_Convert.ToInt32(strs[1]);
		int day = MyConvert_Convert.ToInt32(strs[2]);
		int hour = MyConvert_Convert.ToInt32(strs[3]);
		int minite = MyConvert_Convert.ToInt32(strs[4]);
		int second = MyConvert_Convert.ToInt32(strs[5]);
		
		return new DateTime(year,month,day,hour,minite,second);
	}
	
    //private static String TransToString(DateTime dt)
    //{
    //    string result = "";
    //    result += MyConvert_Convert.ToString(dt.Year);
    //    result += ":";
    //    result += MyConvert_Convert.ToString(dt.Month);
    //    result += ":";
    //    result += MyConvert_Convert.ToString(dt.Day);
    //    result += ":";
    //    result += MyConvert_Convert.ToString(dt.Hour);
    //    result += ":";
    //    result += MyConvert_Convert.ToString(dt.Minute);
    //    result += ":";
    //    result += MyConvert_Convert.ToString(dt.Second);
		
    //    return result;
    //}
    private static String TransToString(DateTime dt)   //2014年1月21日string 改成 StringBuilder
    {
        System.Text.StringBuilder result = new System.Text.StringBuilder();

        result.Append(MyConvert_Convert.ToString(dt.Year));
        result.Append(":");
        result.Append(MyConvert_Convert.ToString(dt.Month));
        result.Append(":");
        result.Append(MyConvert_Convert.ToString(dt.Day));
        result.Append(":");
        result.Append(MyConvert_Convert.ToString(dt.Hour));
        result.Append(":");
        result.Append(MyConvert_Convert.ToString(dt.Minute));
        result.Append(":");
        result.Append(MyConvert_Convert.ToString(dt.Second));

        return result.ToString();
    }

	
	public static string AddHour(string StartDate,int addHour)
	{
		DateTime dt = TransToDateTime(StartDate);
		
		DateTime resultDt = dt.AddHours((double)addHour);
		
		
		return TransToString(resultDt);
	}
	
	public static string AddMinite(string StartDate,int addMinite)
	{
		DateTime dt = TransToDateTime(StartDate);
		
		DateTime resultDt = dt.AddMinutes((double)addMinite);
		
		
		return TransToString(resultDt);
	}
	
	public static string AddSecond(string StartDate,int addSecond)
	{
		DateTime dt = TransToDateTime(StartDate);
		
		DateTime resultDt = dt.AddSeconds((double)addSecond);
		
		
		return TransToString(resultDt);
	}
	
	public static string AddMillisecond(string StartDate,int addMilliSecond)
	{
		DateTime dt = TransToDateTime(StartDate);
		
		DateTime resultDt = dt.AddMilliseconds((double)addMilliSecond);
		
		
		return TransToString(resultDt);
	}
    public static DateTime UnixTimeStampToDateTime(uint unixTimeStamp)
    {
        // Unix timestamp is seconds past epoch
        DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
        dtDateTime = dtDateTime.AddSeconds((double)unixTimeStamp).ToLocalTime();
        return dtDateTime;
    }
    public static string CaculateLeftTime()
    {
        string lefttime = null;
        return lefttime;
    }
    public static int DateTimeToStamp(System.DateTime time)
    {
        DateTime startTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
        return (int)(time - startTime).TotalSeconds;
    }
}

