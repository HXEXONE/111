﻿using UnityEngine;
using System.Collections;

public class MemoryCheck : MonoBehaviour {

    string serchObjectName ="";

#if UNITY_EDITOR
    void OnGUI()
    {


        serchObjectName = GUI.TextField(new Rect(400, 400, 500, 40), serchObjectName);
        if (GUI.Button(new Rect(900, 400, 150, 40), ""))
        {
            UnityEngine.Object[] os = Resources.FindObjectsOfTypeAll<UnityEngine.Object>();
            int sum = 0;
            foreach (UnityEngine.Object o in os)
            {
                if (o.name == serchObjectName)
                {
                    sum++;
                }
            }
            MyLog.Log("serch Object name:" + serchObjectName + "...num:" + sum);

            sum = 0;
            GameObject[] gos = Resources.FindObjectsOfTypeAll<GameObject>();
            foreach (GameObject go in gos)
            {
                if (go.name == serchObjectName)
                {
                    sum++;
                }
            }

            MyLog.Log("serch GameObject name:" + serchObjectName + "...num:" + sum);
        }

        if (GUI.Button(new Rect(1050, 400, 60, 40), ""))
        {
            Resources.UnloadUnusedAssets();
            System.GC.Collect();
        }
    }
#endif
}
