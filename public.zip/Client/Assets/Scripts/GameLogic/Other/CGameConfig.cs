using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

//��Ϸ���������

public class CGameConfig : SingletonObject<CGameConfig>
{
    private float m_fMusicVolume = 0.4f;
    private float m_fSoundVolume = 1f;

    private bool m_bPause;//�Ƿ���Ϸ��ͣ
    private float m_fLastTimeScale;//�ϴε�ʱ������

    private string m_strGameQuality = "GameQuality";

    private float m_fMaxDateTime = 0.067f;
    private float m_fPrecent = 0.7f;
    private int m_iRangeTime = 10;

    private eLanguageType m_languageType = eLanguageType.SimpleChinese;//��������
    public eLanguageType LanguageType
    {
        get
        {
            return m_languageType;
        }
        set { m_languageType = value; }
    }
    

    public void ChangeLanguage(eLanguageType nextlanguage)
    {
        m_languageType = nextlanguage;
        UIManager.GetInst().ClearFont();

        SingletonObject<LoginScene>.GetInst().BackToAccountScene();
    }

    public void Init()
    {
        QualitySettings.SetQualityLevel(0,true);
        m_fLastTimeScale = 1;
        m_bPause = false;
        //QualitySettings.currentLevel = QualityLevel.Fast;
#if UNITY_EDITOR
        SetGameQuality(eGameQuality.High);
#endif
        GetCurrentQuality();

        //if (File.Exists(Common.persistentDataPath + "/dipei.txt"))
        //{
        //    string parm = File.ReadAllText(Common.persistentDataPath + "/dipei.txt", System.Text.Encoding.UTF8);
        //    string[] parms = parm.Split('$');
        //    if (parms != null && parms.Length == 3)
        //    {
        //        int frame = 0;
        //        if (!int.TryParse(parms[0], out frame))
        //        {
        //            m_fMaxDateTime = 0.083f;
        //            MyLog.DebugLogException("CGameConfig Init float.TryParse m_fMaxDateTime Fail");
        //        }
        //        else
        //        {
        //            m_fMaxDateTime = 1f / (float)frame;
        //        }
        //        if (!float.TryParse(parms[1], out m_fPrecent))
        //        {
        //            m_fPrecent = 0.7f;
        //            MyLog.DebugLogException("CGameConfig Init float.TryParse m_fPrecent Fail");
        //        }
        //        if (!int.TryParse(parms[2], out m_iRangeTime))
        //        {
        //            m_iRangeTime = 20;
        //            MyLog.DebugLogException("CGameConfig Init int.TryParse m_iRangeTime Fail");
        //        }
        //    }
        //    else
        //    {
        //        MyLog.DebugLogException("CGameConfig Init Get Parms Fail");
        //    }
        //}
        //else
        //{
        //    string parm = ((int)(1f / m_fMaxDateTime)).ToString() + "$" + m_fPrecent.ToString("f2") + "$" + m_iRangeTime.ToString();
        //    File.WriteAllText(Common.persistentDataPath + "/dipei.txt", parm);
        //}
    }

    public float GetMaxMusicVolume()
    {
        return m_fMusicVolume;
    }

    public void SetMaxMusicVolume(float value) 
    {
        m_fMusicVolume = value;
    }

    public float GetMaxSoundVolume()
    {
        return m_fSoundVolume;
    }


    public bool Pause
    {
        set
        {
            if (m_bPause == value)
            {
                return;
            }
            m_bPause = value;
            if (m_bPause)
            {
                m_fLastTimeScale = Common.TimeScale;
                Common.TimeScale = DEFINE.FLOAT_PAUSE_TIMESCALE;
            }
            else
            {
                Common.TimeScale = m_fLastTimeScale;
            }
        }
        get
        {
            return m_bPause;
        }
    }


    private int m_checkInterval = 100;
    private int m_currentInterval = 0;
    private int m_currentQuality = -1;
    private bool m_showBox = false;
    private List<float> m_checkQueue = new List<float>();
    private List<float> m_dateTimeQueue = new List<float>();

    private bool m_bOpenMonsterFade = true;
    public bool OpenMonsterFade { get { return m_bOpenMonsterFade; } }

    public bool OpenExploder()
    {
        return m_currentQuality > 0;
    }

    public eGameQuality QualtiyLevel
    {
        get { return (eGameQuality)m_currentQuality; }
    }

    public void GetCurrentQuality()
    {
        if (PlayerPrefs.HasKey(m_strGameQuality))
        {
            m_currentQuality = PlayerPrefs.GetInt(m_strGameQuality);
        }
        else
        {
            m_currentQuality = 2;
            PlayerPrefs.SetInt(m_strGameQuality, m_currentQuality);
            PlayerPrefs.Save();
        }
        SetGameQuality((eGameQuality)m_currentQuality);
    }

    public void CheckFrame()
    {
        if (m_showBox || m_currentQuality == 0)
            return;

        if ((Time.deltaTime / Common.TimeScale) > m_fMaxDateTime)  //С��12֡ʱ������ϷƷ��
        {
            m_checkQueue.Add(Time.time);
        }
        m_dateTimeQueue.Add(Time.time);

        if (LowFps())
        {
            m_showBox = true;
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.okCancelButton, Common.GetText(9100247), SetQualityToLow,false);
        }

        DequeOuttimeQueue();
    }

    public void ClearOuttimeQueue()
    {
        m_dateTimeQueue.Clear();
        m_checkQueue.Clear();
    }

    private void DequeOuttimeQueue()
    {
        int count = m_checkQueue.Count;
        float start, end;
        if (count > 0)
        {
            end = m_checkQueue[count - 1];
            for (int i = 0; i < count; i++)
            {
                start = m_checkQueue[0];
                if ((end - start) > m_iRangeTime)
                {
                    m_checkQueue.RemoveAt(0);
                    i--;
                    count--;
                }
                else
                    break;
            }
        }

        count = m_dateTimeQueue.Count;
        end = m_dateTimeQueue[count - 1];
        for (int i = 0; i < count; i++)
        {
            start = m_dateTimeQueue[0];
            if ((end - start) > m_iRangeTime)
            {
                m_dateTimeQueue.RemoveAt(0);
                i--;
                count--;
            }
            else
                break;
        }
    }

    float startTime,endTime;

    private bool LowFps()
    {
        if (m_dateTimeQueue.Count < 5)
            return false;

        startTime = m_dateTimeQueue[0];
        endTime = m_dateTimeQueue[m_dateTimeQueue.Count - 1];
        if ((endTime - startTime) >= m_iRangeTime)
            return ((float)m_checkQueue.Count / (float)m_dateTimeQueue.Count) > m_fPrecent;
        else
            return false;
        //int count = m_checkQueue.Count;
        //if (count > 10)
        //{
        //    float start = m_checkQueue[0];
        //    float end = m_checkQueue[count - 1];
        //    float subTime = end - start;
        //    if (subTime > m_checkRange)
        //    {
        //        if ((count / (subTime)) > 10)
        //            return false;
        //        else
        //            return true;
        //    }
        //    else
        //        return false;
        //}
        //else
        //    return false;
    }

    private void SetQualityToLow(PopFrameMediator.ClickType mClickType)
    {
        if (mClickType == PopFrameMediator.ClickType.clickOk)
        {
            SetGameQuality(eGameQuality.Low);
        }
    }

    public void SetGameQuality(eGameQuality quality)
    {
        switch (quality)
        {
            case eGameQuality.Low:
                {
                    //QualitySettings.masterTextureLimit = 2;
                    //QualitySettings.blendWeights = BlendWeights.OneBone;
                    QualitySettings.lodBias = 0.5f;
                    CExploderManage.GetInst().CloseExploder();
                    CParticleManager.SetParticleActive(false);
                    if (ClientMain.GetInst().GetCurrentState() == eGameState.Battle)
                    {
                        SingletonObject<BattleScene>.GetInst().SetParticleAndChangeMaterial(false);
                    }
                    else if (ClientMain.GetInst().GetCurrentState() == eGameState.Home)
                    {
                        SingletonObject<HomeScene>.GetInst().SetParticleAndChangeMaterial(false);
                    }
                    m_bOpenMonsterFade = false;
                    //TrailManange.SetActive(false);
                    ImageEffectManager.GetInst().SetActive(false);
                }
                break;
            case eGameQuality.Middle:
                {
                    //QualitySettings.masterTextureLimit = 1;
                    //QualitySettings.blendWeights = BlendWeights.TwoBones;
                    QualitySettings.lodBias = 0.4f;
                    CExploderManage.GetInst().OpenExploder();
                    CParticleManager.SetParticleActive(false);
                    if (ClientMain.GetInst().GetCurrentState() == eGameState.Battle)
                    {
                        SingletonObject<BattleScene>.GetInst().SetParticleAndChangeMaterial(false);
                    }
                    else if (ClientMain.GetInst().GetCurrentState() == eGameState.Home)
                    {
                        SingletonObject<HomeScene>.GetInst().SetParticleAndChangeMaterial(false);
                    }
                    m_bOpenMonsterFade = false;
                    //TrailManange.SetActive(false);
                    ImageEffectManager.GetInst().SetActive(true);
                }
                break;
            case eGameQuality.High:
                {
                    //QualitySettings.masterTextureLimit = 0;
                    //QualitySettings.blendWeights = BlendWeights.FourBones;
                    QualitySettings.lodBias = 0.3f;
                    CExploderManage.GetInst().OpenExploder();
                    CParticleManager.SetParticleActive(true);
                    m_bOpenMonsterFade = true;
                    //TrailManange.SetActive(true);
                    ImageEffectManager.GetInst().SetActive(true);
                }
                break;
        }

        m_currentQuality = (int)quality;
        PlayerPrefs.SetInt(m_strGameQuality, m_currentQuality);
        PlayerPrefs.Save();
    }

}
