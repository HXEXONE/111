﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class LocalConfig 
{
    private static string OldPath = Application.persistentDataPath ;
#if UNITY_ANDROID
    private static string LocalPath = Application.persistentDataPath + "Config";
#elif UNITY_IPHONE
    private static string LocalPath = Application.persistentDataPath;
#endif
    private static bool bCreated = false;

    private static void CreatePath(string path)
    {
        if (!bCreated)
        {
            Common.CreatePath(path);
            bCreated = true;
        }
    }

    public static void SaveConfig(string name, List<string> info)
    {
        CreatePath(LocalPath);
        MobileTextStream.CreateFile(LocalPath, name, info);
    }

    public static void SaveConfig(string name, string info, bool createNew = true)
    {
        CreatePath(LocalPath);
        MobileTextStream.CreateFile(LocalPath, name, info, createNew);
    }

    public static void DeleteConfig(string name)
    {
        CreatePath(LocalPath);
        MobileTextStream.DeleteFile(LocalPath, name);
    }

    public static ArrayList LoadConfig(string name)
    {
        CreatePath(LocalPath);

        ArrayList list;
        list = MobileTextStream.LoadFile(LocalPath, name);
        if (list != null) return list;
        list = MobileTextStream.LoadFile(OldPath, name);

        if (list != null)
        {
            File.Copy(OldPath + "/" + name, LocalPath + "/" + name);
            File.Delete(OldPath + "/" + name);
        }
        return list;
    }
}
