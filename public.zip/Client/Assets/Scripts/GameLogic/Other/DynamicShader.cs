﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DynamicShader
{
    private static Dictionary<string, Shader> m_shaderDict = new Dictionary<string, Shader>();

    private static Dictionary<int, Material> m_materialsDirect = new Dictionary<int, Material>();

    private static List<Material> m_materialsList = new List<Material>();

    private static string[] m_materialName = new string[] { "resources/effect/effectmaterials/materials_skill_lieyanxingtai.x", 
                                                            "resources/effect/effectmaterials/materials_debuff_dongjie.x" ,
                                                            "resources/effect/effectmaterials/materials_skill_sishenhuiwu.x",
                                                            "resources/effect/effectmaterials/materials_monster_shixiangguai.x",};

    public static void LoadMaterialsObj(int index)
    {
        int len = m_materialName.Length;
        if (index >= len)
        {
            MyLog.LogError("Load index out of Range");
            return;
        }
        LoadHelp.LoadObject(index.ToString() + "$" + m_materialName[index], m_materialName[index], ThreadPriority.Normal, LoadComplate);
    }

    public static void LoadAllMaterials()
    {
        int len = m_materialName.Length;
        for (int i = 0; i < len; i++)
        {
            LoadMaterialsObj(i);
        }
    }

    private static void LoadComplate(string interim, UnityEngine.Object asset)
    {
        Material material = asset as Material;
        if (material == null)
            return;
#if UNITY_EDITOR
        string name = material.shader.name;
        material.shader = GetShader(name);
#endif
        material.hideFlags = HideFlags.HideAndDontSave;
        string[] args = interim.Split('$');
        int index = MyConvert_Convert.ToInt32(args[0]);
        material.name = args[1];
        if (!m_materialsDirect.ContainsKey(index))
        {
            m_materialsDirect.Add(index, material);
            m_materialsList.Add(material);
        }
    }

    public static void Release()
    {
        //int len = m_materials.Count;
        //for (int i = 0; i < len; i++)
        //{
        //    Object.Destroy(m_materials[i]);
        //}
        m_materialsDirect.Clear();
    }

    public static Shader GetShader(string shaderName)
    {
        if (m_shaderDict.ContainsKey(shaderName))
        {
            return m_shaderDict[shaderName];
        }

        Shader shader = Shader.Find(shaderName);

        if (shader != null)
        {
            m_shaderDict.Add(shaderName, shader);
        }

        return shader;
    }

    public static void AddShader(Shader shader)
    {
        string shaderName = shader.name;
        if (!m_shaderDict.ContainsKey(shaderName))
        {
            m_shaderDict.Add(shaderName, shader);
        }
    }

    public static Color GetMonsterSpecialMaterialColor(int index)
    {
        Color color = Color.white;
        switch (index)
        {
            case 1: color = DEFINE.MATERIAL_COLOR_HARD_GOLD; break;
            case 2: color = DEFINE.MATERIAL_COLOR_HARD_BLUE; break;
            default: color = Color.white; break;
        }
        return color;
    }


    //替换编辑器不支持的shader,这是unity4.3.X版本的一个BUG,在编辑器下会不支持部分shader,在真机上测试通过
    public static void ReplaceUnSupportShader(GameObject o)
    {
#if UNITY_EDITOR

        string[] shaderNames = new string[]{ 
            "MyMobile/Dissolve/Add",
            "MyMobile/Dissolve/Blend",
            "MyMobile/Dissolve/Blend(Depth)",
            "MyMobile/Dissolve/Blend(Depth)3041",
            "MyMobile/Dissolve/BlendUp",
            "MyMobile/Dissolve/BlendDown",
            "MyMobile/Particles/ParticleAdd",
            "MyMobile/Particles/ParticleAdd Diff",
            "MyMobile/Particles/ParticleBlend",
            "MyMobile/Particles/ParticleBlend_SingleFace",
            "MyMobile/Particles/AdditiveShot",
            "MyMobile/Particles/AddNoMask",
            "MyMobile/Particles/AddNoMask-Diff",
            "MyMobile/HeatDistortAndDissolve",
            "MyMobile/Illumin/Diffuse",
            "MyMobile/Transparent/Diffuse",
            "MyMobile/Transparent/Forward",
            "MyMobile/Transparent/Depht",
            "MyMobile/Transparent/Depht01",
            "MyMobile/Transparent/Cutout/Diffuse",
            "MyMobile/Gloss/Diffuse",
            "MyMobile/Diffuse",
            "MyMobile/Diffuse-DFace",
            "MyMobile/Diffuse(late)",
            "MyMobile/Stroning/StroningLerp",
            "MyMobile/Stroning/StroningAdd",
            "MyMobile/Texture/TextureAdd",   
            "MyMobile/Texture/Ainma",
            "MyMobile/FX/Rain",
            "MyMobile/FX/Snow",
            "MyMobile/FX/RainSplash",
            "T4MShaders/ShaderModel2/Diffuse/T4M 2 Textures",
            "T4MShaders/ShaderModel2/Diffuse/T4M 3 Textures",
            "T4MShaders/ShaderModel2/Diffuse/T4M 4 Textures",
            "T4MShaders/ShaderModel2/Diffuse/T4M 5 Textures",
            "T4MShaders/ShaderModel2/Diffuse/T4M 6 Textures",
            "MyMobile/Multiply/Vert_Forward",
            "MyMobile/Unity/Wind_Lightmap",
            "MyMobile/UV/Sine_Blend",
            "MyMobile/UV/Sine_Add",
            "MyMobile/Particle/Grow",
            "MyMobile/Transparent/VertexDF",
            "MyMobile/Screen/Full",            "MyMobile/Cloud/Diffuse",
            "MyMobile/Water/Diffuse_Bump",
            "MyMobile/Water/Diffuse",
            "MyMobile/Water/HighMap",
            "MyMobile/Screen/UI",
            "MyMobile/Color/Blend_Alpha",
            "MyMobile/Cloud/Diffuse",
            "MyMobile/Cloud/GrayscaleToAlpha",
            "MyMobile/Cloud/Blend_Mask",
            "MyMobile/Sky/GrayscaleToAlpha",
            "MyMobile/VertexLit/Diffuse",
            "MyMobile/VertexLit/Diffuse(late)",
            "MyMobile/VertexLit/Diffuse_DFace",
            "MyMobile/VertexLit/DirectLight",
            "MyMobile/Stroning/Cut_Blend_UV",
            "MyMobile/Particles/ParticleAdd Diff_SingleFace",
            "MyMobile/UI/Scall",
            "MyMobile/Stroning/Cut_Blend_UV_Mask",
            "MyMobile/VertexLit_Color",
            "MyMobile/VertexLit/Diffuse_NOFOG",
            "MyMobile/Transparent/TwoTextureAdd_NOFOG",
            "MyMobile/Texture/DiffuseBlend_UV",
            "MyMobile/Stroning/Cut_Blend_UV_4Tex"};

        //Shader[] shaders = new Shader[shaderNames.Length];
        //for (int i = 0, count = shaderNames.Length; i < count; ++i)
        //{
        //    shaders[i] = GetShader(shaderNames[i]);
        //}

        Renderer[] rs = o.GetComponentsInChildren<Renderer>(true);

        foreach (Renderer r in rs)
        {
            foreach (Material m in r.sharedMaterials)
            {
                if (m == null)
                {
                    continue;
                }
                if (m.shader == null)
                {
                    continue;
                }
                {
                    string name = m.shader.name;
                    for (int i = 0, count = shaderNames.Length; i < count; ++i)
                    {
                        if (name == shaderNames[i])
                        {
                            m.shader = GetShader(shaderNames[i]);
                            break;
                        }
                    }
                }

            }

        }

#endif
    }

    public static Material GetMaterials(int index)
    {
        if (!m_materialsDirect.ContainsKey(index))
        {
            MyLog.LogError("index out of range");
            return null;
        }
#if UNITY_IPHONE
        if (m_materialsDirect[index] != null)
        {
            if(m_materialsDirect[index].shader != null)
                Debug.Log("Shader = " + m_materialsDirect[index].shader + "\t + Supppose = " + m_materialsDirect[index].shader.isSupported);
            else
                Debug.Log("Shader = NULL");
        }
#endif
        return m_materialsDirect[index];
    }

    public static Material GetMaterials(string name)
    {
        int count = m_materialsList.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_materialsList[i].name.Equals(name))
                return m_materialsList[i];
        }
        return null;
    }

    public static void SetMaterialToVertexLight(GameObject o, eNpcRenderType type, Vector3 viewDirect)
    {
        Renderer renderer = null;


        if (type == eNpcRenderType.SkinMeshRender)
        {
            SkinnedMeshRenderer[] smrs = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            if (smrs.Length > 0)
            {
                for (int i = 0; i < smrs.Length; i++)
                {
                    if (!smrs[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    {
                        renderer = smrs[i];
                        break;
                    }
                }
            }
        }
        else if (type == eNpcRenderType.MeshRender)
        {
            renderer = o.renderer;
        }
        if (renderer == null)
            return;


        Material material = renderer.material;
        if (material == null)
            return;

        Vector4 lightDirect = new Vector4(1, 1, 0, 0);
        if (viewDirect == Vector3.zero)
        {
            lightDirect = CCamera.GetInst().Vector;
        }
        else
        {
            lightDirect = viewDirect - 2 * Vector3.Dot(viewDirect, Vector3.up) * Vector3.up;
        }

        material.shader = GetShader(DEFINE.SHADER_VERTLIT_DIRECTLIGHT);
        material.SetVector(DEFINE.SHADER_PROPERTY_LIGHTPOSITION, lightDirect);
        material.SetColor(DEFINE.SHADER_PROPERTY_LIGHTCOLOR, new Color(0.64f, 0.64f, 0.52f, 0));
        material.SetFloat(DEFINE.SHADER_PROPERTY_INTENSITY, 3);
    }

    public static void SetMaterialToVertex(GameObject o,eNpcRenderType type)
    {
        Renderer renderer = null;

        if (type == eNpcRenderType.SkinMeshRender)
        {
            SkinnedMeshRenderer[] smrs = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            if (smrs.Length > 0)
            {
                for (int i = 0, count = smrs.Length; i < count; i++)
                {
                    if (!smrs[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    {
                        renderer = smrs[i];
                        break;
                    }
                }
            }
        }
        else if (type == eNpcRenderType.MeshRender)
        {
            renderer = o.renderer;
        }
        if (renderer == null)
            return;


        Material material = renderer.sharedMaterial;
        if (material == null)
            return;

        material.shader = GetShader(DEFINE.SHADER_VERTLIT);
        material.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
    }
}
