﻿using System.IO;
using UnityEngine;
using System.Collections;
using Protocol;
using Network;

public class GMCommand : MonoBehaviour
{
    private bool m_bShowPanel = false;
    private string m_sCommand = "";
    private string m_sError = "";

    public bool enableTimeScale = false;
    public float TimeScale = 1.0f;



#if UNITY_EDITOR
    void OnGUI()
    {
        if (GUI.Button(new Rect(Screen.width / 2 - 80, 200, 80, 60), "hide/show"))
        {
            m_bShowPanel = !m_bShowPanel;
        }

        if (m_bShowPanel)
        {
            m_sCommand = GUI.TextField(new Rect(Screen.width / 2, 200, 340, 60), m_sCommand);

            if (GUI.Button(new Rect(Screen.width / 2 + 340, 200, 60, 60), "send"))
            {
                SendGMCommand();
            }
            //GUI.Label(new Rect(Screen.width / 2 , 260, 340, 60), m_sError);
            //
        }
    }
#endif

    /// <summary>
    /// 时间：2014年10月25日17:11:31
    /// 迭代一版GM指令，不处理字符串，
    /// 直接发送到服务端，让服务端处理字符串，
    /// 处理协议返回
    /// </summary>
    void SendGMCommand()
    {
        if (m_sCommand.Contains("/monster"))
        {
            string[] strs = m_sCommand.Split(' ');
            if (strs.Length <= 0)
            {
                return;
            }

            string[] args = new string[strs.Length - 1];
            for (int i = 1, len = strs.Length; i < len; ++i)
            {
                args[i - 1] = strs[i];
            }

            if (strs[0].Equals("/monster"))
            {
                CreateMonster(args);
            }
        }
        else if (m_sCommand.Contains("/changelanguage"))
        {
            string[] strs = m_sCommand.Split(' ');
            if (strs.Length <= 1)
            {
                return;
            }
            int languageID = MyConvert_Convert.ToInt32(strs[1]);
            CGameConfig.GetInst().ChangeLanguage((eLanguageType)languageID);

        }
        else if (m_sCommand.Contains("jumpguide"))
        {
            ClientMain.GetInst().IsGuide = false;
        }
        else if (m_sCommand.Contains("/hp"))
        {
            if (ClientMain.GetInst().GetCurrentState() == eGameState.Battle)
                SingletonObject<Avatar>.GetInst().AddHp(100000);
        }
        else if (m_sCommand.Contains("/clearfile"))
        {
            //if (UpdateManager.GetInst().AssetManager != null)
            //    UpdateManager.GetInst().AssetManager.DeletedAllFile();
        }
        else if (m_sCommand.Contains("/auto"))
        {
            ClientMain.GetInst().AutoBattleForever = true;
        }
        else if (m_sCommand.Contains("/switch"))
        {
            string[] strs = m_sCommand.Split(' ');
            if (strs.Length <= 1)
            {
                return;
            }

            int platid = MyConvert_Convert.ToInt32(strs[1]);
            ClientMain.GetInst().PlatformType = platid;
            ChannelContent cc = HolderManager.m_ChannelHolder.GetStaticInfo(platid);
            if (cc != null)
            {
                SDKManager.GetInst().SdkType = (eSdkType)cc.SdkType;
            }
        }
        else if (m_sCommand.Contains("/e "))
        {
            string[] strs = m_sCommand.Split(' ');
            if (strs.Length <= 1)
            {
                return;
            }
            SingletonObject<ShowActivityMediator>.GetInst().ClearSystemNotice();
            SingletonObject<ShowActivityMediator>.GetInst().AddSystemNotice(strs[1]);
        }
        else
        {
            SingletonObject<GMManager>.GetInst().m_lastGmCommad = m_sCommand;

            C2GReqGmCmd msg = new C2GReqGmCmd();
            msg.szGmCmd = m_sCommand;
            NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GM_CMD, (ushort)ProCG.GAME_ACK_GM_CMD, msg);
        }
    }

    public void CreateMonster(string[] args)//创建怪物
    {
        if (args == null)
        {
            return;
        }

        if (args.Length != 2)
        {
            return;
        }
        uint uiMonsterID = MyConvert_Convert.ToUInt32(args[0]);
        ushort wLevel = MyConvert_Convert.ToUInt16(args[1]);

        SingletonObject<BattleScene>.GetInst().CreateMonster(uiMonsterID, wLevel, SingletonObject<Avatar>.GetInst().GetPosition(), Quaternion.identity, "");
    }
}
