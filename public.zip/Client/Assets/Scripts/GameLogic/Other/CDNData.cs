﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using LitJson;
using System;
using System.Net;
using System.IO;

public class CDNData : MonoBehaviour
{
    //public delegate void RequestDelegate(WWW www);
    public delegate void RequestDelegate(byte[] bytes);

    private string mPidUrl = "http://android-lqzg-cdn.feiliu.com/";
    private string mPidUrl_backup = "";
    private string mSrvFileName = "ServerList/";
    private string mNoticeFileName = "Notice/";

    private static string mNoticeText = string.Empty;

    private static string mServerListText = string.Empty;

    private readonly string mNoticeKey = "[Notice]";

    private readonly string mSrvListKey = "[ServerList]";

    private bool mSrvAckFlag = false;
    private bool mNoticeAckFlag = false;
    private bool mOurFlag = false;

    private bool mSetSrvFlag = false;

    private byte[] mSrvBytes;
    private byte[] mNoticeBytes;

    private static CDNData sInst = null;

    private static GameObject mObj = null;

    private static Timer m_serverListTimer = new Timer();

    void Awake()
    {
        sInst = this;
        mObj = gameObject;

#if !UNITY_EDITOR
        if (ClientMain.GetInst().UseUpdateAsset && LoadingScript.Instance != null)
            mPidUrl = LoadingScript.Instance.Url;
#else
        mPidUrl = "file:///" + Application.dataPath + "/Resources/";
#endif
    }

    public static CDNData GetInst()
    {
        if (null == sInst)
        {
            if (null == mObj)
            {
                mObj = new GameObject("CDNData");
            }
            sInst = mObj.AddComponent<CDNData>();
        }
        return sInst;
    }

    /// <summary>
    /// 请求cdn上面的pid文件,里面包含公告和服务器列表
    /// </summary>
    public void RequestSrvList(bool setSrvFlag, bool ourFlag)
    {
        mOurFlag = ourFlag;
        mSetSrvFlag = setSrvFlag;
        mSrvAckFlag = false;
        Request(mPidUrl + mSrvFileName + ClientMain.GetInst().ResourcePlatformType + ".txt", mSrvFileName);
    }

    public void RequestNotice()
    {
        mNoticeAckFlag = false;
        Request(mPidUrl + mNoticeFileName + ClientMain.GetInst().ResourcePlatformType + ".txt", mNoticeFileName);
    }

    public static string GetNotice()
    {
        return mNoticeText;
    }

    

    public static void RequestServerList()
    {
        GetInst().RequestSrvList(true, false);
        m_serverListTimer.SetTimer(5);
    }

    void OnDestory()
    {
        sInst = null;
        if (null != mObj)
        {
            Destroy(mObj);
            mObj = null;
        }
    }

    private void RequestCDNPidCallBack(byte[] bytes)
    {
        try
        {
           string text = Encoding.UTF8.GetString(bytes);
           
            {
                text = text.Trim();
              
                if (text.Contains(mSrvListKey))
                {
                    int startIndex = text.LastIndexOf(mSrvListKey) + mSrvListKey.Length;
                    mServerListText = text.Substring(startIndex);
                    mServerListText = mServerListText.TrimStart('\n', '\r').TrimEnd('\n', '\r');
                    string[] str = mServerListText.Split('\n');
                    if (null != str)
                    {
                        mServerListText = "[";
                        for (int i = 0, icount = str.Length; i < icount; ++i)
                        {
                            string tmp = str[i].TrimStart('\r').TrimEnd('\r');
                            mServerListText += ToJsonString(tmp);
                            if (i != icount - 1)
                            {
                                mServerListText += ",";
                            }
                        }
                        mServerListText += "]";
                        if (mSetSrvFlag)
                        {
                            SingletonObject<LoginScene>.GetInst().getServerList(mServerListText, mOurFlag);
                        }
                    }

                }
                //else
                //{//无服务器列表
                //    SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100004));
                //}
            }
        }
        catch (System.Exception ex)
        {
        	
        }
        
    }

    private void RequestNoticeCallBack(byte[] bytes)
    {
        try
        {
            //string error = www.error;
            //Encoding gb = Encoding.UTF8;
            string text = Encoding.UTF8.GetString(bytes);
            /*if (null != error)
            {
                SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(9100004));
                MyLog.LogError(error);
            }
            else*/
            {
                text = text.Trim();
                /* Encoding gb2312 = Encoding.GetEncoding("gb2312");
                 byte[] bytes = gb2312.GetBytes(text);
                 if (null != bytes)
                 {
                     text = Encoding.UTF8.GetString(bytes);
                 }*/
                mNoticeText = text;
                SingletonObject<SystemNoticeMediator>.GetInst().UpdateNotice(mNoticeText);
            }
        }
        catch (System.Exception ex)
        {
        	
        }
        
    }

    private string ToJsonString(string text)
    {
        if (string.IsNullOrEmpty(text))
        {
            return string.Empty;
        }
        string outText = string.Empty;
        string[] str = text.Split(';');
        if (null != str)
        {
            JsonWriter writer = new JsonWriter();
            writer.WriteObjectStart();
            for (int i = 0, icount = str.Length; i < icount; ++i)
            {
                if (!string.IsNullOrEmpty(str[i]) && str[i].Contains(":"))
                {
                    int index = str[i].IndexOf(":");
                    string key = str[i].Substring(0,index);
                    string value = str[i].Substring(index + 1);
                    writer.WritePropertyName(key);
                    int num = 0;
                    if (int.TryParse(value, out num))
                    {
                        writer.Write(num);
                    }
                    else
                    {
                        writer.Write(value);
                    }
                }
            }
            writer.WriteObjectEnd();
            outText = writer.ToString();
        }
        return outText;
    }

    /// <summary>
    /// 请求
    /// </summary>
    /// <param name="url"></param>
    /// <param name="callBack"></param>
    /// <returns></returns>
    bool Request(string url,string fileName)
    {
        try
        {
            var request = WebRequest.Create(url);
            //FtpWebRequest request = (FtpWebRequest)FtpWebRequest.Create(url);
            //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            //request.Credentials = new NetworkCredential("moloong", "lirDFio3afy5mTZhHJr2");
            request.Timeout = 30 * 1000;
            //request.KeepAlive = false;
            //request.Method = WebRequestMethods.Ftp.DownloadFile;
            FtpData fdata = new FtpData();
            fdata.request = request;
            fdata.fileName = fileName;
            request.BeginGetResponse(new AsyncCallback(EndGetRequest), fdata);
        }
        catch (System.Exception ex)
        {
           return false;
        }
        return true;
    }

    void Update()
    {
        if (mSrvAckFlag)
        {
            if (null != mSrvBytes)
            {
                RequestCDNPidCallBack(mSrvBytes);
            }
            mSrvAckFlag = false;
        }
        if (mNoticeAckFlag)
        {
            if (null != mNoticeBytes)
            {
                RequestNoticeCallBack(mNoticeBytes);
            }
            mNoticeAckFlag = false;
        }

        if (ClientMain.GetInst().GetCurrentState() == eGameState.Login && m_serverListTimer.IsExpired(true))
        {
            RequestServerList();
        }
    }

    void EndGetRequest(IAsyncResult ar)
    {
        FtpData ftpData = (FtpData)ar.AsyncState;
        if (null == ftpData)
        {
            return;
        }
        WebRequest request = ftpData.request;
        if (null != request)
        {
            try
            {
                Stream stream = null;// request.EndGetRequestStream(ar);
                WebResponse wr = request.EndGetResponse(ar);
                if (null != wr)
                {
                    stream = wr.GetResponseStream();
                }
                if (null != stream)
                {
                    MemoryStream stmMemory = new MemoryStream();
                    byte[] bytes = new byte[1024 * 64];
                    int i;
                    while ((i = stream.Read(bytes, 0, bytes.Length)) > 0)
                    {
                        stmMemory.Write(bytes, 0, i);
                    }
                    if (ftpData.fileName.Equals(mSrvFileName))
                    {
                        mSrvBytes = stmMemory.ToArray();
                        mSrvAckFlag = true;
                    }
                    else if (ftpData.fileName.Equals(mNoticeFileName))
                    {
                        mNoticeBytes = stmMemory.ToArray();
                        mNoticeAckFlag = true;
                    }
                    
                    stmMemory.Close();
                    stream.Close();
                    request.Abort();

                    //RequestCDNPidCallBack(arraryByte);
                }
            }
            catch (System.Exception ex)
            {
                //if (request.Address.ToString().Contains(mPidUrl) && mPidUrl_backup != "")
                //{
                //    string newUrl = request.Address.ToString().Replace(mPidUrl, mPidUrl_backup);

                //    if (ftpData.fileName.Equals(mSrvFileName))
                //    {
                //        mSrvAckFlag = false;
                //        Request(newUrl, mSrvFileName);
                //    }

                //    if (ftpData.fileName.Equals(mNoticeFileName))
                //    {
                //        mNoticeAckFlag = false;
                //        Request(newUrl, mNoticeFileName);
                //    }
                    
                //}
            }
            
        }
    }

}

public class FtpData
{
    public WebRequest request;
    public string fileName;
    public FtpData()
    {
        request = null;
        fileName = string.Empty;
    }
}
