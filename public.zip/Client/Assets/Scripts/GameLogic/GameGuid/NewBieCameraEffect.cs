﻿using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// 新手引导镜头效果
/// </summary>
public class NewBieCameraEffect
{
    private GameObject m_cameraEffectObj; //镜头效果obj
    private CObject m_cameraLouKou; //镂空镜头效果
    private string m_cameraLouKouPath = "resources/effect/camera/camera_loukong.x";

    private Color m_effectColor;
    private Vector2 m_effectScale;
    private Vector2 m_effectOffset;
    private Vector3 m_uiEffectPos;//UI对应的坐标
    private CButton m_uiEffectParent;
    private Camera m_uicamera;

    public NewBieCameraEffect(Camera uicamera, Vector2 scale, Vector2 offset, Color color, CButton button)
    {
        m_effectColor = color;
        m_effectOffset = offset;
        m_effectScale = scale;
        m_uiEffectParent = button;
        m_uicamera = uicamera;

        m_cameraLouKou = new CObject(m_cameraLouKouPath);
        m_cameraLouKou.ObjectType = eObjectType.CameraEffect;
        m_cameraLouKou.Name = "CameraEffect_Loukong";
        m_cameraLouKou.CallBack = LoadCameraEffectCompleted;
        m_cameraLouKou.IsMemoryFactory = true;
        m_cameraLouKou.Layer = DEFINE.NGUI_LAYER_ONE;
        m_cameraLouKou.LoadObject();
    }

    private void LoadCameraEffectCompleted(GameObject o, params object[] args)
    {
        if (null == o) {; return; }
        m_cameraEffectObj = o;

        Vector3 tempPos = new Vector3(0, 0, 0.4f);
        Quaternion tempQuaternion = new Quaternion();
        tempQuaternion.eulerAngles = new Vector3(0, 0, 0);

        m_cameraEffectObj.transform.parent = m_uicamera.transform;
        m_cameraEffectObj.transform.localPosition = tempPos;
        m_cameraEffectObj.transform.localRotation = tempQuaternion;
        m_cameraEffectObj.transform.localScale = new Vector3(Screen.width, Screen.height, 1);
        DynamicShader.ReplaceUnSupportShader(m_cameraEffectObj);

        Material material = m_cameraEffectObj.GetComponent<MeshRenderer>().sharedMaterial;
        if (material != null)
        {
            material.color = m_effectColor;
            material.mainTextureOffset = m_effectOffset;
            material.mainTextureScale = m_effectScale;
        }

        CalcUVPosition();
    }

    //计算UV坐标
    private void CalcUVPosition()
    {
        m_uiEffectPos = m_uiEffectParent.ElementObj.transform.position - m_uicamera.transform.position;

        Vector2 cameraPoa = new Vector2((m_uiEffectPos.x / m_uicamera.aspect * m_uicamera.orthographicSize), m_uiEffectPos.y / m_uicamera.orthographicSize) * -1;

        Material material = m_cameraEffectObj.GetComponent<MeshRenderer>().sharedMaterial;

        if (material != null)
        {
            material.mainTextureOffset = cameraPoa * 0.5f;
        }
    }

    public void Release()
    {
        if (m_cameraLouKou != null)
        {
            m_cameraLouKou.DestroyGameObject(eObjectDestroyType.Memory);
            m_cameraLouKou = null;
        }
        if (m_cameraEffectObj != null)
            m_cameraEffectObj = null;
    }

    #region 属性

    public GameObject cameraEffectObj
    {
        get { return m_cameraEffectObj; }
    }

    public CObject cameraEffectCObj
    {
        get { return m_cameraLouKou; }
    }

    public Transform transform
    {
        get { return m_cameraEffectObj.transform; }
    }



    #endregion
}