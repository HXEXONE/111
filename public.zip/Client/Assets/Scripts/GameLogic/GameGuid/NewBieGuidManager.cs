﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;

public enum HGuideReset
{
    noreset = 0,
    reset = 1,
}

/// <summary>
/// 新手引导管理类
/// </summary>
public class NewBieGuidManager : SingletonObject<NewBieGuidManager>
{
    private HomeGuideContent m_uiGuideLoader = null;

    private HomeGuideContent uiGuideLoader
    {
        get {
            if (null == m_uiGuideLoader) return null;
            if (m_uiGuideLoader.Key < mGuideData)
            {
                HomeGuideContent mLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(mGuideData);
                if (null == mLoader)
                {
                    return null;
                }
                if (m_uiGuideLoader.GuidTarget == mLoader.GuidTarget) return m_uiGuideLoader;
                CPlayer mPlayer = SingletonObject<CPlayer>.GetInst();
                stHomeAvatarInfo info = mPlayer.GetHomeAvatarInfo();
                List<sBattleInfo> mBattleInfo = BattlePveManager.GetInst().GetBattleInfoList();
                if (mBattleInfo == null || mBattleInfo.Count <= 0) return null;
                uint pveId = (uint)mBattleInfo[mBattleInfo.Count - 1].uiKey;
                if (mLoader.Condition > 0 && mLoader.Condition == pveId)
                {
                    m_uiGuideLoader = mLoader;
                }
            }
            return m_uiGuideLoader; 
        }
        set
        {
            m_uiGuideLoader = value;
        }
    }

    private GuidContent m_battleGuideLoader = null;
    public uint BattleGuideId
    {
        get {
            if (null == m_battleGuideLoader)
            {
                return 0;
            }
            return (uint)m_battleGuideLoader.Key;
        }
    }

    private uint mGuideData = 0;
    public uint GuideData
    {
        get { return mGuideData; }
    }

    private List<ModuleInfo> openList = new List<ModuleInfo>();

    private const uint ENDID = 1000000;

    private bool isDelayShow = false;

    private uint unityCallBackIndex = 0;

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_GUIDE_DATA, SetGuideInfo, false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_SAVE_GUIDE_DATA,SaveGuideInfoResult,true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_MODULE_INFO,SetOpenInfo,false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_MODULE_NEW_OPEN,newFunOpen,false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_SET_MODULE_GUIDE_FLAG,SetOpenFunResult,false);
    }

    private void SetGuideInfo(BinaryReader br)
    {
        G2CNotifyGuideData msg = new G2CNotifyGuideData();
        msg.Read(br);
        mGuideData = msg.uiData;
        //Debug.LogError("SetGuideInfo " + mGuideData);
        //RequestSaveGuideInfo(1000000);
    }

    private void SetOpenInfo(BinaryReader br)
    {
        G2CNotifyModuleInfo msg = new G2CNotifyModuleInfo();
        msg.Read(br);
        openList.Clear();
        for (int i = 0, j = msg.vecModuleInfo.Count; i < j; i++)
        {
            openList.Add(msg.vecModuleInfo[i]);
            //Debug.LogError(msg.vecModuleInfo[i].uiModuleID + " // " + msg.vecModuleInfo[i].uiIsOpen);
        }
        SingletonObject<CPlayer>.GetInst().CheckHasPartnerCanUpgrade();
    }

    private void newFunOpen(BinaryReader br)
    {
        G2CNotifyModuleNewOpen msg = new G2CNotifyModuleNewOpen();
        msg.Read(br);
        for (int i = 0, j = openList.Count; i < j; i++)
        {
            if (openList[i].uiModuleID == msg.uiModuleID)
            {
                openList[i].uiIsOpen = 1;
                break;
            }
        }
        SingletonObject<CPlayer>.GetInst().CheckHasPartnerCanUpgrade();
    }

    private void SetOpenFunResult(BinaryReader br)
    {
        G2CSetModuleGuideFlag msg = new G2CSetModuleGuideFlag();
        msg.Read(br);
        for (int i = 0, j = openList.Count; i < j; i++)
        {
            if (openList[i].uiModuleID == msg.uiModuleID)
            {
                openList[i].uiGuideFlag = msg.uiFlag;
                break;
            }
        }
    }

    public eOpenMode isOpenFun(eOpenFunction open)
    {
        if ( ClientMain.GetInst().EnterTestScene )
        {
            return eOpenMode.Acquiesce;
        }

        bool isOpen = false;
        for (int i = 0, j = openList.Count; i < j; i++)
        {
            if (openList[i] != null && openList[i].uiModuleID == (uint)open)
            {
                isOpen = openList[i].uiIsOpen == 1 ? true : false;
                break;
            }
        }
        OpenContent mLoader = HolderManager.m_OpenHolder.GetStaticInfo((uint)open);
        if (mLoader != null)
        {
            if (!isOpen)
            {
                return (eOpenMode)mLoader.OpenMode;
            }
            else
            {
                return eOpenMode.Acquiesce;
            }
        }
        return eOpenMode.Hide;
    }

    public bool isGuideOpenFun(eOpenFunction open)
    {
#if UNITY_EDITOR
        if (!ClientMain.GetInst().IsGuide) return true;
#endif
        CBattleSceneLoading bsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (bsl.battleType == eBattleType.Pvp || bsl.battleType == eBattleType.MultiPve) return true;
        for (int i = 0, j = openList.Count; i < j; i++)
        {
            if (openList[i].uiModuleID == (uint)open)
            {
                return openList[i].uiGuideFlag == 1 ? true : false;
            }
        }
        MyLog.LogError("Error:open function error");
        return false;
    }

    private void SaveGuideInfoResult(BinaryReader br)
    {
        G2CSaveGuideData msg = new G2CSaveGuideData();
        msg.Read(br);
        if (msg.uiResult != (uint)EnumProtocolResult.EnumProtocolResult_Success)
        {
            MyLog.LogError("Error : save guide data fail,code is " + msg.uiResult);
        }
    }

    public void RequestSaveGuideInfo()
    {
        HomeGuideContent mLoader = uiGuideLoader;
        while (true)
        {
            if (null == mLoader) break;
            if (mLoader.SaveToServer > 0)
            {
                RequestSaveGuideInfo((uint)mLoader.SaveToServer);
                break;
            }
            if (mLoader.GuidFinishNode == 1) break;
            mLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(mLoader.Key + 1);
        }
    }

    public void RequestSaveGuideInfo(uint guideId)
    {
        C2GSaveGuideData msg = new C2GSaveGuideData();
        msg.uiData = guideId;
        mGuideData = guideId;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_SAVE_GUIDE_DATA, (ushort)ProCG.GAME_ACK_SAVE_GUIDE_DATA, msg);
    }

    public void RequestChangeGuideFlag(eOpenFunction open)
    {
        C2GReqSetModuleGuideFlag msg = new C2GReqSetModuleGuideFlag();
        SetFunOpen(open);
        msg.uiModuleID = (uint)open;
        msg.uiFlag = 1;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_SET_MODULE_GUIDE_FLAG, msg);
    }

    public void SetFunOpen(eOpenFunction open)
    {
        for (int i = 0, j = openList.Count; i < j; i++)
        {
            if (openList[i].uiModuleID == (uint)open)
            {
                openList[i].uiIsOpen = 1;
                break;
            }
        }
    }

    public void InitNewBieGuid()
    {
        uint mapId = SingletonObject<CBattleSceneLoading>.GetInst().mapSceneID;
        if (mapId > 10011003) return;
        if (mapId / 1000000 == 10)//普通关卡
        {
            uint pveCount = BattlePveManager.GetInst().GetCurBattleInfo(mapId);
            if (pveCount == 0)
            {
                SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
            }
        }
    }

    /// <summary>
    /// 切入新手引导
    /// </summary>
    public void StartBattleGuid(uint id = 0)
    {
        if (null != m_battleGuideLoader) ExitNewGuid();
        if (id > 0)
        {
            m_battleGuideLoader = HolderManager.m_GuidHolder.GetStaticInfo(id);
        }
        if (m_battleGuideLoader == null) return;
        MaiDianManager.GetInst().SetMdUpLoad(id, MaiDianType.triggerBGuide);
        UnityCallBackManager mCallBack = UnityCallBackManager.GetInst();
        switch ((eGuidTarget)m_battleGuideLoader.GuidTarget)
        {
            case eGuidTarget.Move:
                CBaseStory.OtherCallback = StoryCallBack;
                break;
            case eGuidTarget.MoveAgain:
                unityCallBackIndex = mCallBack.AddCallBack(0.5f, delegate(object[] args)
                {
                    mCallBack.RemoveCallBack(unityCallBackIndex);
                    EnterNewBieGuid();
                }, null);
                break;
            case eGuidTarget.Goto:
                CBaseStory.OtherCallback = StoryCallBack;
                break;
            case eGuidTarget.GotoFinish:
                SingletonObject<NewBieGuidMediator>.GetInst().ReleaseParticle();
                ExitNewGuid(true);
                break;
            case eGuidTarget.Attack:
                unityCallBackIndex = mCallBack.AddCallBack(2.5f, delegate(object[] args)
                {
                    mCallBack.RemoveCallBack(unityCallBackIndex);
                    EnterNewBieGuid();
                }, null);
                break;
            case eGuidTarget.ClickSkill:
                EnterNewBieGuid();
                break;
            case eGuidTarget.Dodge:
                CBaseStory.OtherCallback = StoryCallBack;
                break;
            case eGuidTarget.DodgeAgain:
                SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                break;
            case eGuidTarget.MoveToCrawl:
                EnterNewBieGuid();
                break;
            case eGuidTarget.Crawl:
                SingletonObject<NewBieGuidMediator>.GetInst().ReleaseParticle();
                CBaseStory.OtherCallback = StoryCallBack;
                break;
            case eGuidTarget.InitCrawl:
                {
                    SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                }
                break;
            case eGuidTarget.CrawlAgain:
                UIManager.GetInst().IsLockNGUIEvent(true);
                unityCallBackIndex = mCallBack.AddCallBack(2f, delegate(object[] args)
                {
                    mCallBack.RemoveCallBack(unityCallBackIndex);
                    EnterNewBieGuid();
                }, null);
                break;
            case eGuidTarget.MoveToCharge:
                EnterNewBieGuid();
                break;
            case eGuidTarget.Charge:
                SingletonObject<NewBieGuidMediator>.GetInst().ReleaseParticle();
                CBaseStory.OtherCallback = StoryCallBack;
                break;
            case eGuidTarget.ChargeInit:
                {
                    SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                }
                break;
            case eGuidTarget.ChargeAgain:
                unityCallBackIndex = mCallBack.AddCallBack(0.2f, delegate(object[] arg)
                {
                    mCallBack.RemoveCallBack(unityCallBackIndex);
                    EnterNewBieGuid();
                }, null);
                break;
        }
    }

    private void StoryCallBack(params object[] args)
    {
        if (null == m_battleGuideLoader) return;
        UnityCallBackManager mCallBack = UnityCallBackManager.GetInst();
        switch ((eGuidTarget)m_battleGuideLoader.GuidTarget)
        {
            case eGuidTarget.Move:
                {
                    EnterNewBieGuid();
                }
                break;
            case eGuidTarget.Goto:
                {
                    EnterNewBieGuid();
                }
                break;
            case eGuidTarget.Dodge:
                {
                    SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                }
                break;
            case eGuidTarget.Crawl:
                {
                    SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                    unityCallBackIndex = mCallBack.AddCallBack(1f, delegate(object[] arg)
                    {
                        mCallBack.RemoveCallBack(unityCallBackIndex);
                        EnterNewBieGuid();
                    }, null);
                }
                break;
            case eGuidTarget.Charge:
                {
                    SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                    EnterNewBieGuid();
                }
                break;
            //case eGuidTarget.ChargeAgain:
            //    {
                    //SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Wait;
                    //unityCallBackIndex = mCallBack.AddCallBack(2f, delegate(object[] arg)
                    //{
                    //    mCallBack.RemoveCallBack(unityCallBackIndex);
                    //    EnterNewBieGuid();
                    //}, null);
                //}
                //break;
        }
    }

    public void ActivateGuide(eGuidTarget target)
    {
        if (null == m_battleGuideLoader) return;
        if (CBaseStory.IsInGameStory) return;
        if ((eGuidTarget)m_battleGuideLoader.GuidTarget == target)
        {
            EnterNewBieGuid();
        }
    }

    private void EnterNewBieGuid()
    {
        if (null == m_battleGuideLoader) return;
        eGuidType guidType = (eGuidType)m_battleGuideLoader.GuidKind;
        switch (guidType)
        {
            case eGuidType.Lock:
                eGuidTarget guidTarget = CheckTargetType();
                bool igonreAvatar = (guidTarget == eGuidTarget.Charge || guidTarget == eGuidTarget.ChargeAgain ? true : false);
                SingletonObject<BattleGuide>.GetInst().Pause(guidTarget, true, igonreAvatar);//暂停avatar行为
                UIManager.GetInst().IsLockNGUIEvent(true);//锁住ngui层次，不接受事件
                SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Lock;
                break;
            case eGuidType.UnLock:
                SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Free;
                UIManager.GetInst().IsLockNGUIEvent(false);
                break;
        }
        SingletonObject<NewBieGuidMediator>.GetInst().Open(null);
    }

    //退出新手还原设置。
    public void ExitNewGuid(bool isRemove = true)
    {
        UIManager.GetInst().IsLockNGUIEvent(false);
        SingletonObject<NewBieGuidMediator>.GetInst().Close(null);
        if (isRemove)
        {
            m_battleGuideLoader = null;
        }
    }

    #region 属性

    public HomeGuideContent homeGuideLoader
    {
        get {
            return uiGuideLoader;
        }
    }

    public eHGuideTarget homeGuideKind
    {
        get
        {
            if (uiGuideLoader != null)
            {
                return (eHGuideTarget)uiGuideLoader.GuidTarget;
            }
            return eHGuideTarget.Null;
        }
    }

    public HGuideReset isReset
    {
        get
        {
            if (uiGuideLoader != null)
            {
                return (HGuideReset)uiGuideLoader.Reset;
            }
            return HGuideReset.noreset;
        }
    }

    #endregion

    #region 状态

    public bool IsInStoryOrOpen
    {
        get {
            if (uiGuideLoader == null)
            {
                return false;
            }
            if (uiGuideLoader.StoryID > 0)
            {
                return true;
            }
            if (uiGuideLoader.OpenID > 0)
            {
                return true;
            }
            if (uiGuideLoader.GuidTarget == (byte)eHGuideTarget.Task)
            {
                return true;
            }
            return false;
        }
    }

    public void ClearHomeGuide()
    {
        if (IsInStoryOrOpen) return;
        uiGuideLoader = null;
    }
    #endregion


    #region 公开接口

    public void CheckHomeGuide()
    {
#if UNITY_EDITOR
        if (!ClientMain.GetInst().IsGuide) return;
#endif
        //RequestSaveGuideInfo(1024000);
        List<sBattleInfo> mBattleInfo = BattlePveManager.GetInst().GetBattleInfoList();
        uint uiGuideId = 0;
        uint pveId = 0;
        uiGuideLoader = null;
        isDelayShow = false;
        if (mBattleInfo.Count > 0)
        {
            pveId = (uint)mBattleInfo[mBattleInfo.Count - 1].uiKey;
            BattlePVEContent battlePve = HolderManager.m_BattlePVEHolder.GetStaticInfo(pveId);
            uint guidePveId = 0;
            //mGuideData = 2011000;
            if (mGuideData != 0)
            {
                if (mGuideData == ENDID) return;
                if (mGuideData == 1009001)
                {
                    stHeroBattleInfo heroPve = BattlePveManager.GetInst().HeroBattleInfoID(200101);
                    if (null != heroPve && heroPve.uiStar > 0)
                    {
                        return;
                    }
                }
                HomeGuideContent mLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(mGuideData);
                if (mLoader != null && mLoader.Condition > 0)
                {
                    guidePveId = (uint)mLoader.Condition;
                }
                if (pveId == guidePveId)
                {
                    uiGuideId = mGuideData;
                }
                else if (pveId > guidePveId)
                {
                    if (battlePve == null) return;
                    if (battlePve.GuideId != 0)
                    {
                        uiGuideId = (uint)battlePve.GuideId;
                    }
                    else
                    {
                        uiGuideId = mGuideData;
                    }
                }
            }
        }
        else
        {
            if (mGuideData == 0)
            {
                uiGuideId = 1000001;
            }
            else
            {
                uiGuideId = mGuideData;
            }
        }
        if (uiGuideId != 0)
        {
            uiGuideLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(uiGuideId);
        }
    }

    private void OnHomeStoryFinished(params object[] args)
    {
        stHomeAvatarInfo homeAvtar = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();

        if (string.IsNullOrEmpty(homeAvtar.szPlayerName))
        {
            SingletonObject<NickNameMediator>.GetInst().Open(null);
        }
        else
        {
            NextGuide(homeGuideKind);
            SetHomeGuide();
        }
    }

    private void OnOpenFinish(params object[] args)
    {
        NextGuide(homeGuideKind);
        SetHomeGuide();
    }

    public void SetDelayGuide()
    {
        if (isDelayShow)
        {
            isDelayShow = false;
            SetHomeGuide();
        }
        else if (isReset == HGuideReset.reset)
        {
            CheckHomeGuide();
            SetHomeGuide();
        }
    }

    public void SetHomeGuide()
    {
        if (uiGuideLoader == null) return;
        if (JumpToManager.GetInst().OpenFrom != eOpenFrom.None)
        {
            isDelayShow = true;
            return;
        }
        if (uiGuideLoader.StoryID != 0)
        {
            CStoryManage.GetInst().SetInitStoryEffect((uint)uiGuideLoader.StoryID, OnHomeStoryFinished, CCamera.GetInst().GetCameraObj(), null);
        }
        else if (uiGuideLoader.OpenID != 0)
        {
            SingletonObject<SystemOpenMediator>.GetInst().ShowOpen((uint)uiGuideLoader.OpenID, OnOpenFinish);
        }
        else
        {
            SingletonObject<HomeMainMediator>.GetInst().EnterGuide();
        }
    }

    public void SetHomeGuide(uint id)
    {
        uiGuideLoader = null;
        isDelayShow = false;
        uiGuideLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(id);
    }

    public void NextGuide(eHGuideTarget target)
    {
        if (uiGuideLoader != null)
        {
            if (homeGuideKind != target) return;
            HomeGuideContent mLoader = uiGuideLoader;
            if (mLoader.SaveToServer > 0) RequestSaveGuideInfo((uint)mLoader.SaveToServer);
            if (mLoader.GuidNextId > 0)
            {
                uiGuideLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(mLoader.GuidNextId);
            }
            else
            {
                ClearHomeGuide();
            }
        }
    }

    public void ResetGuide(eHGuideTarget target,bool cut = true, bool isHome = false)
    {
        HomeGuideContent mLoader = uiGuideLoader;
        if (null != mLoader && mLoader.GuidTarget == (byte)target)
        {
            int id = 0;
            if (cut)
            {
                id = mLoader.Key - mLoader.ResetNode;
            }
            else
            {
                id = mLoader.Key + mLoader.ResetNode;
            }
            HomeGuideContent resetLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo(id);
            if (null != resetLoader)
            {
                uiGuideLoader = resetLoader;
            }
            if (isHome)
            {
                SetHomeGuide();
            }
        }
    }

    public void SetNode(int id)
    {
        if (uiGuideLoader != null)
        {
            id = (int)uiGuideLoader.Key + id;
            if (id < 0) return;
            HomeGuideContent mLoader = HolderManager.m_HomeGuideHolder.GetStaticInfo((uint)id);
            if (mLoader != null)
            {
                uiGuideLoader = mLoader;
            }
        }
    }

    /// <summary>
    /// 检查是否该触发   战斗引导    :首先判断引导ID是否存在，其次匹配该战斗场景是否与引导所填map id 匹配，同时检测是否第一次打该关卡。
    /// </summary>
    public bool CheckTriggerGuideByID()
    {
        if (m_battleGuideLoader == null) return false;
        return true;
    }

    /// <summary>
    /// 获取操作类型
    /// </summary>
    public eGuidTarget CheckTargetType()
    {
        if (m_battleGuideLoader == null) return eGuidTarget.Null;
        eGuidTarget target = (eGuidTarget)m_battleGuideLoader.GuidTarget;
        return target;
    }

    #endregion

}
