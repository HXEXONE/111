﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;
using System.Text;

public enum MaiDianType
{
    none            = 0,
    enterLoading    = 1,//进入loading界面
    enterScene      = 2,//进入场景
    triggerBGuide   = 3,//触发战场新手引导
    leaveBGuide     = 4,//完成战场新手引导
    battleResult    = 5,//战斗结算
    finishSth       = 6,//某功能完成
    triggerHGuide   = 7,//触发家园新手引导
    leaveHGuide     = 8,//完成家园新手引导
    finishTask      = 9,//完成任务
    openFunction    = 10,//解锁功能
    openPanel       = 11,//打开ui界面
    closePanel      = 12,//关闭界面
    openButton      = 13,//开启按钮
    clickButton     = 14,//点击按钮
    choosePve       = 15,//打开pve选择界面
}

public enum FixPrarm
{
    start       = 1000,
    login       = 1001,
    creatRole   = 1002,
    selectRole  = 1003,
    enterGame   = 1004,
}

public class MaiDianManager : SingletonObject<MaiDianManager> {

    private int m_currentMD;
    private Dictionary<int, MaiDianContent> maidianDic;

    private string urlMaidian = "http://112.74.95.125/api/point.php";
    private string key = "7ecc6aa3f6d28";

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_MAIDIAN, SetNotifyMaiDian, false);
    }

    private void SetNotifyMaiDian(BinaryReader br)
    {
        G2CNotifyMaiDian msg = new G2CNotifyMaiDian();
        msg.Read(br);
        m_currentMD = (int)msg.uiPoint;
        maidianDic = HolderManager.m_MaiDianHolder.GetDict();
    }

    private void SetUpdateMaiDian(int id)
    {
        if (id <= m_currentMD) return;
        m_currentMD = id;
        C2GReqUpdateMaiDian msg = new C2GReqUpdateMaiDian();
        msg.uiPoint = (uint)id;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_UPDATE_MAIDIAN,msg);
        Debug.LogError("SetUpdateMaiDian " + id);
    }

    private MaiDianContent GetMaiDian(MaiDianType type,int mId)
    {
        MaiDianContent mLoader = null;
        if (null == HolderManager.m_MaiDianHolder) return mLoader;
        if (null == maidianDic)
        {
            maidianDic = HolderManager.m_MaiDianHolder.GetDict();
        }
        if (null == maidianDic)
        {
            return null;
        }
        if (!maidianDic.ContainsKey(mId + 1)) return mLoader;
        mLoader = maidianDic[mId + 1];
        if (mLoader.TriggerType != (byte)type)
        {
            for (int i = mId + 1, j = mId + 5; i < j; i++)
            {
                if (i >= maidianDic.Count) break;
                mLoader = maidianDic[i];
                if (mLoader.TriggerType == (byte)type) break;
            }
        }
        return mLoader;
    }

    public void SetMdUpLoad(uint guideId,MaiDianType mType)
    {
        MaiDianContent mLoader = GetMaiDian(mType, m_currentMD);
        if (mLoader == null || mLoader.TriggerType != (byte)mType) return;
        uint mId = 0;
        uint.TryParse(mLoader.TriggerArgs, out mId);
        if (guideId != mId) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetLoadingMD(eGameState state)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.enterLoading, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.enterLoading) return;
        uint mId = 0;
        uint checkId = 0;
        uint.TryParse(mLoader.TriggerArgs,out mId);
        switch (state)
        {
            case eGameState.Battle:
                {
                    checkId = SingletonObject<CBattleSceneLoading>.GetInst().mapSceneID;
                }
                break;
            case eGameState.Home:
                {
                    checkId = DEFINE.HOME_SCENE_ID;
                }
                break;
            case eGameState.WorldMap:
                {
                    checkId = DEFINE.WORLD_MAP_ID;
                }
                break;
        }
        if (checkId != mId) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetEnterScene(eGameState mState)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.enterScene, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.enterScene) return;
        uint mId = 0;
        uint checkId = 0;
        uint.TryParse(mLoader.TriggerArgs, out mId);
        switch(mState)
        {
            case eGameState.Battle:
                checkId = SingletonObject<CBattleSceneLoading>.GetInst().mapSceneID;
                break;
            case eGameState.Home:
                checkId = (uint)SingletonObject<CHomeLoading>.GetInst().SceneLoader.Key;
                break;
            case eGameState.WorldMap:
                checkId = (uint)SingletonObject<CWorldMapLoading>.GetInst().SceneLoader.Key;
                break;
        }
        if (checkId != mId) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetOpenPanelMD(string panelName)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.openPanel, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.openPanel) return;
        if (mLoader.TriggerArgs != panelName) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetClosePanelMD(string panelName)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.closePanel, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.closePanel) return;
        if (mLoader.TriggerArgs != panelName) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetOpenButtonMD(eOpenFunction openId)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.openButton, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.openButton) return;
        uint mId = 0;
        uint.TryParse(mLoader.TriggerArgs, out mId);
        if (mId != (uint)openId) return;
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetClickButtonMD(string buttonName)
    {
        MaiDianContent mLoader = GetMaiDian(MaiDianType.clickButton, m_currentMD);
        if (null == mLoader || mLoader.TriggerType != (byte)MaiDianType.clickButton) return;
        if (mLoader.TriggerArgs != buttonName)
        {
            return;
        }
        if (mLoader.Key > m_currentMD)
        {
            SetUpdateMaiDian(mLoader.Key);
        }
    }

    public void SetMaidianByHttp(FixPrarm prarm)
    {
        int maidian = (int)FixPrarm.start;
        string str = "SetMaidianByHttp";
        if (PlayerPrefs.HasKey(str))
        {
            maidian = PlayerPrefs.GetInt(str);
        }

        if ((int)prarm <= maidian) return;
        maidian = (int)prarm;

        PlayerPrefs.SetInt(str, maidian);

        ulong playerId = SingletonObject<LoginScene>.GetInst().GetCurrentLoginAvatarPlayerID();
        ulong useId = SingletonObject<LoginScene>.GetInst().GetCurrentLoginAvatarAccountID();
        stHomeAvatarInfo hInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
        System.DateTime mDateTime = System.DateTime.Now;
        string mac = PCInfo.GetMacAddressByNetworkInformation();
        if (string.IsNullOrEmpty(mac))
        {
            mac = "0";
        }

        StringBuilder strB = new StringBuilder();
        strB.Append("0");//游戏事件
        strB.Append("|");
        strB.Append("0");//游戏大区
        strB.Append("|");
        strB.Append(useId.ToString());//用户id
        strB.Append("|");
        strB.Append(mDateTime.ToString("yyyy-MM-dd H:m:s"));//时间
        strB.Append("|");
        strB.Append(playerId.ToString());//角色id
        strB.Append("|");
        strB.Append(hInfo.uiPlayerJob.ToString());//角色职业
        strB.Append("|");
        strB.Append(maidian.ToString());//埋点id
        strB.Append("|");
        strB.Append("0");//登录渠道
        strB.Append("|");
        strB.Append(mac);//客户端mac地址
        strB.Append("|");
        strB.Append("0");//客户端设备唯一标识
        strB.Append("|");
        strB.Append("0");//客户端设备型号信息

        string poin = strB.ToString();
        strB.Append(key);
        string md5 = strB.ToString();
        string sign = FQAManager.instance.getMd5(md5);
        //Debug.LogError("poin: " + poin);
        //Debug.LogError("sign: " + sign);
        WWWForm form = new WWWForm();
        form.AddField("point", poin);
        form.AddField("sign", sign);
        FQAManager.instance.getWww(form, urlMaidian, "posMaiDian");
    }
}
