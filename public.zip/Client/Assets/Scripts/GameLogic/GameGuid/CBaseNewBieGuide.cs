﻿using UnityEngine;
using System.Collections.Generic;

public class CBaseNewBieGuide
{
    protected eGuidState m_guidestate;
    protected eGuidTarget m_target;

    public CBaseNewBieGuide(eGuidState state, eGuidTarget guidetype)
    {
        m_guidestate = state;
        m_target = guidetype;
    }

    public virtual void InitState()
    {

    }
    public virtual void EnterState()
    {
        
    }

    public virtual void Update()
    {

    }

    public virtual void LeaveState()
    {
        m_guidestate = eGuidState.None;
    }

    public virtual void Release()
    {

    }


    #region 公开属性
    public eGuidState guideState { get { return m_guidestate; } }
    public eGuidTarget guideTarget { get { return m_target; } }
    #endregion
}
