﻿using System;
using System.Collections.Generic;

public class CMoveGuideState : CBaseNewBieGuide
{
    public CMoveGuideState():base(eGuidState.None,eGuidTarget.Move)
    {
        
    }
}
