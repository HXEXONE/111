﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;

//public class ProjectorDecals{

//    private GameObject m_go;                       //储存在内存当中的projector对象
//    private Projector m_projector;                 //projector实例
//    private Transform m_projectorTrans;            //正在使用的projector对象变换
//    private Vector3 m_position;                    //初始位置
//    private Quaternion m_rotation;                 //初始旋转

//    private Vector3 m_hitPosition;                 
//    /// <summary>
//    /// 碰撞点，如果碰撞点为0则表示没有碰撞
//    /// </summary>
//    public Vector3 HitPosition
//    {
//        get { return m_hitPosition; }
//        set { m_hitPosition = value; }
//    }

//    private float m_nearClipPlane;
//    /// <summary>
//    /// projector属性值，近裁平面
//    /// </summary>
//    public float NearClipPlane
//    {
//        get { return m_nearClipPlane; }
//        set { 
//            m_nearClipPlane = value;
//            m_projector.nearClipPlane = m_nearClipPlane;
//        }
//    }

//    private float m_farClipPlane;
//    /// <summary>
//    /// projector属性值，远裁平面
//    /// </summary>
//    public float FarClipPlane
//    {
//        get { return m_farClipPlane; }
//        set {
//            m_farClipPlane = value;
//            m_projector.farClipPlane = m_farClipPlane;
//        }
//    }

//    private float m_fieldOfView;
//    /// <summary>
//    /// projector属性值，透视模式下的视角
//    /// </summary>
//    public float FieldOfView
//    {
//        get { return m_fieldOfView; }
//        set {
//            m_fieldOfView = value;
//            m_projector.fieldOfView = m_fieldOfView;
//        }
//    }

//    private float m_aspectRotio;
//    /// <summary>
//    /// projector属性值，长：宽的值
//    /// </summary>
//    public float AspectRotio
//    {
//        get { return m_aspectRotio; }
//        set {
//            m_aspectRotio = value;
//            m_projector.aspectRatio = m_aspectRotio;
//        }
//    }

//    private bool m_orthographic;
//    /// <summary>
//    /// projector属性值，是否为正焦模式
//    /// </summary>
//    public bool Orthographic
//    {
//        get { return m_orthographic; }
//        set { 
//            m_orthographic = value;
//            m_projector.orthographic = m_orthographic;
//        }
//    }

//    private float m_orthographicSize;
//    /// <summary>
//    /// projector属性值，在正交模式下投射的一半尺寸(半径)。用plane替换后此值变为plane的长宽。默认为3
//    /// </summary>
//    public float OrthographicSize
//    {
//        get { return m_orthographicSize; }
//        set {
//            m_orthographicSize = value;
//            m_projector.orthoGraphicSize = m_orthographicSize;
//        }
//    }

//    private float m_projectorHight;
//    /// <summary>
//    /// 射线碰撞点理地面的高度，默认为5米
//    /// </summary>
//    public float ProjectorHight
//    {
//        get { return m_projectorHight; }
//        set { m_projectorHight = value; }
//    }

//    private bool m_rotatSelf;
//    /// <summary>
//    /// 是否启用自身旋转，默认为真
//    /// </summary>
//    public bool RotatSelf
//    {
//        get { return m_rotatSelf; }
//        set { m_rotatSelf = value; }
//    }

//    private bool m_rotatRight;
//    /// <summary>
//    /// 如果RotatSelf为真，当前值为真时左转，否则右转。默认为真
//    /// </summary>
//    public bool RotatRight
//    {
//        get { return m_rotatRight; }
//        set { m_rotatRight = value; }
//    }

//    private float m_rotatSpeed;
//    /// <summary>
//    /// 旋转速度默认为30度每秒
//    /// </summary>
//    public float RotatSpeed
//    {
//        get { return m_rotatSpeed; }
//        set { m_rotatSpeed = value; }
//    }

//    private bool m_isLoad;                   //控制是否启用对象
//    private bool m_contral;                  //控制对象是否为空，当为空时内存中也没有该对象

//    private Ray m_ray;
//    private RaycastHit m_rayHit;
//    private float m_rayDistance;
//    private Camera m_camrea;
//    public Camera Camrea
//    {
//        get { return m_camrea; }
//        set { m_camrea = value; }
//    }

//    private LayerMask m_lay;                //层级关系


//    public ProjectorDecals()
//    {
//        m_camrea = CCamera.GetInst().GetCamera();
//        m_nearClipPlane = 0.1f;
//        m_farClipPlane = 10;
//        m_fieldOfView = 30;
//        m_aspectRotio = 1;
//        m_orthographic = true;
//        m_orthographicSize = 3f;
//        m_projectorHight = 5f;
//        m_isLoad = false;
//        m_position = Vector3.zero;
//        m_rotation = Quaternion.Euler(new Vector3(0, 0, 0));
//        m_rayDistance = 50;
//        m_hitPosition = Vector3.zero;
//        m_contral = false;

//        m_rotatSelf = true;
//        m_rotatRight = true;
//        m_rotatSpeed = 30f;

//        #region
//        /*  20131211修改  用下面的替换
//        m_go = new GameObject("Projector", typeof(Projector));  
//        m_go.transform.position = m_position;
//        m_go.transform.rotation = m_rotation;

//        m_material = new Material(Shader.Find("Projector/Light"));
//        LoadHelp.LoadObject("", "resources/texture/falloff.tex", ThreadPriority.Normal, LoadFalloffTexture);

//        InitProjector();
//        */
//        #endregion
//        //projector 改为 plane##########20131211
//     //   m_material = new Material(Shader.Find("Mobile/Particles/Alpha Blended"));
//        LoadHelp.LoadObject("", "resources/other/decal.x", ThreadPriority.Normal, LoadQuad);
//        //##############################20131211
        
//    }
//    //20131211新加回调函数
//    private void LoadQuad(string interim, Object asset)
//    {
//        m_go = Object.Instantiate(asset, m_position, m_rotation) as GameObject;
//        Object.DontDestroyOnLoad(m_go);
//        m_go.layer = DEFINE.PROJECTOR;
//        m_go.transform.localScale = new Vector3(m_orthographicSize, m_orthographicSize, m_orthographicSize);
//        if (m_camrea.enabled)
//            m_contral = true;
//    }
//    /*
//    private void InitProjector()
//    {
//        if (m_go != null)
//        {
//            m_projector = m_go.GetComponent<Projector>();
//            if (m_projector != null)
//            {
//             //   m_projector.material = m_material;
//                m_projector.nearClipPlane = m_nearClipPlane;
//                m_projector.farClipPlane = m_farClipPlane;
//                m_projector.fieldOfView = m_fieldOfView;
//                m_projector.aspectRatio = m_aspectRotio;
//                m_projector.isOrthoGraphic = m_orthographic;
//                m_projector.orthoGraphicSize = m_orthographicSize;
//                m_contral = true;
//            }
//        }
//    }
//    */
//    public void ForUpdate()
//    {
//        if (m_contral)
//        {
//            m_hitPosition = ProjectorMove();
//            ProjectorRoation();
//        }
//    }

//    /// <summary>
//    /// 启用对象，如果内存中有保留值的话从内存中取得，否则加载
//    /// </summary>
//    /// <param name="path"></param>
//    public void LoadProject()
//    {
//        if (m_contral && !m_isLoad)
//        {
//            m_isLoad = true;
//            m_go.SetActive(m_isLoad);
//            m_projectorTrans = m_go.transform;
//        }
//    }

//    /// <summary>
//    /// 使对象不可用，但没有从内存中删除
//    /// </summary>
//    public void UnloadProjector()
//    {
//        if (m_isLoad)
//        {
//            m_projectorTrans.rotation = m_rotation;
//            m_projectorTrans.position = m_position;
//            m_projectorTrans = null;
//            m_isLoad = false;
//            m_go.SetActive(m_isLoad);
//        }
//    }

//    private Vector3 ProjectorMove()
//    {
//        if (m_isLoad)
//        {
//            Vector3 point = GetRayPoint();
//            if (point != Vector3.zero)
//            {
//                /* 20131211改动为Plane
//                Vector3 temp = point + Vector3.up * m_projectorHight;
//                m_projectorTrans.position = temp;
//                 */
//                Vector3 temp = point + m_ray.direction * m_projectorHight * -1;
//                m_projectorTrans.position = temp;
//            }
//            return point;
//        }
//        return Vector3.zero;
//    }

//    private void ProjectorRoation()
//    {
//        if (m_isLoad && m_rotatSelf)
//        {
//            if (m_rotatRight)
//                m_projectorTrans.Rotate(Vector3.up, m_rotatSpeed * Time.deltaTime);
//            else
//                m_projectorTrans.Rotate(Vector3.up, -1 * m_rotatSpeed * Time.deltaTime);
//        }
//    }

//    private Vector3 GetRayPoint()
//    {
//        if (m_camrea == null)
//            m_camrea = Camera.main;

//        m_ray = m_camrea.ScreenPointToRay(Input.mousePosition);

//        MyLog.DrawRay(m_ray.origin, m_ray.direction * m_rayDistance);

//        if (Physics.Raycast(m_ray, out m_rayHit, m_rayDistance, 1 << DEFINE.TERRAINLAYER))
//        {
//            Vector3 upNom = Vector3.up;
//            if (Mathf.Abs(Vector3.Dot(upNom, m_rayHit.normal)) > 0.2f)
//            {
//                return m_rayHit.point;
//            }

//            return Vector3.zero;
//        }

//        return Vector3.zero;
//    }


//    /// <summary>
//    /// 销毁内存当中的值
//    /// </summary>
//    public void Release()
//    {
//        m_contral = false;
//        m_projector = null;
//        UnloadProjector();
//        Object.Destroy(m_go);
//        m_go = null;
//    }

//    private void LoadFalloffTexture(string interim, Object asset)
//    {
//        Texture tex = Object.Instantiate(asset) as Texture;
//    }
//}
