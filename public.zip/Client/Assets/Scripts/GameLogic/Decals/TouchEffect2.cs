﻿using UnityEngine;
using System.Collections;

public class TouchEffect2 : SingletonObject<TouchEffect2>
{
    private GameObject m_touchCam;
    private GameObject m_touchEffect;
    private Transform m_touchEffectTrans;
    private float m_distanceToCam;

    private ParticleSystem m_particle;
    private bool m_control;
    private bool m_able;
    private bool m_loop;
    private Camera m_cam;

    private uint m_callbackIndex;

    public void Init()
    {
        m_callbackIndex = 0;
        LoadHelp.LoadObject("", "resources/effect/other/toucheffect.x", ThreadPriority.Normal, InitCallBack,false,false);
    }

    private void InitCallBack(string interim, UnityEngine.Object org)
    {
        if (null == org) { MyLog.LogError("" + interim); return; }
        m_touchEffect = Object.Instantiate(org) as GameObject;
        m_touchEffect.SetActive(true);
        Object.DontDestroyOnLoad(m_touchEffect);
        if (m_touchEffect != null)
        {
            m_touchEffect.layer = DEFINE.TOUCHEFFECT;
            m_touchCam = new GameObject("touchcam", typeof(Camera));
            Object.DontDestroyOnLoad(m_touchCam);
            m_touchCam.transform.position = Vector3.zero;
            m_particle = m_touchEffect.GetComponent<ParticleSystem>();
            m_touchEffectTrans = m_touchEffect.transform;
            if (m_cam == null)
            {
                m_distanceToCam = 2f;
                m_cam = m_touchCam.camera;
                m_cam.depth = 100;
                m_cam.fieldOfView = 40;
                m_cam.clearFlags = CameraClearFlags.Depth;
                m_cam.cullingMask = (1 << DEFINE.TOUCHEFFECT);
                m_cam.farClipPlane = m_distanceToCam + 1;
            }


            if (m_particle != null && m_touchEffectTrans != null && m_cam != null)
            {
                m_control = true;
                m_loop = false;
                m_able = false;
            }
        }
        DynamicShader.ReplaceUnSupportShader(m_touchEffect);
    }

    private Vector3 GetPoint()
    {
        Vector3 pos = Input.mousePosition;
        pos = m_cam.ScreenToWorldPoint(new Vector3(pos.x, pos.y, m_distanceToCam));
        return pos;
    }

    private void Load()
    {
        if (m_control)
        {
            m_able = true;
            m_cam.enabled = true;
            m_touchEffect.SetActive(true);

            if (m_callbackIndex != 0)
            {
                UnityCallBackManager.GetInst().RemoveCallBack(m_callbackIndex);
            }
        }
    }

    private void Unload()
    {
        if (m_control)
        {
            m_able = false;
            m_callbackIndex = UnityCallBackManager.GetInst().AddCallBack(1, DelayClose, null);
        }
    }

    private void DelayClose(params object[] args)
    {
        m_cam.enabled = false;
        m_touchEffect.SetActive(false);
        m_callbackIndex = 0;
    }

    private void ActiveMoveMoment()
    {
        if (m_able)
        {
            m_touchEffectTrans.position = GetPoint();
        }

        if (m_loop != m_able)
        {
            m_loop = m_able;
            m_particle.loop = m_loop;
            if (m_loop)
            {
                m_particle.Play();
            }
        }
    }

    public void ForUpdate()
    {
        if (m_control)
        {
            if (Input.GetMouseButtonDown(0))
                Load();

            if (Input.GetMouseButtonUp(0))
                Unload();

            ActiveMoveMoment();
        }
    }

}
