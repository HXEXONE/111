﻿using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;

public class AchieveManager : SingletonObject<AchieveManager>
{
    private AchieveList achieveList = new AchieveList();    //成就列表
    private AchieveList targetList = new AchieveList();    //目标列表
    private uint achieveCount = 0;                          //当前达成的成就数
    private uint maxAchieveCount = 0;                       //最大成就类型数
    private List<stAchieveInfo> CurAchieveList = new List<stAchieveInfo>();    //成就列表
    private List<stTargetInfo> CurTargetList = new List<stTargetInfo>();    //成就列表
    private string targetId;
    private eAchieveType achieveType = eAchieveType.None;
    private G2CSendPetInfo petInfo = new G2CSendPetInfo();

    public G2CSendPetInfo PetInfo
    {
        get { return petInfo; }
    }
    private G2CSendMountsInfo mountInfo = new G2CSendMountsInfo();
    public G2CSendMountsInfo MountInfo { get { return mountInfo; } }
    public delegate void OnRequestFinished();

    public OnRequestFinished onRequestFinished;

    public bool bShowUnLocakEffect { get; set; }
    public void RegisteMassage(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_ACHIEVE_LIST, ReturnAchieveList, true);      //返回成就列表结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_GET_ACHIEVE_AWARD, ReturnGetAchieve, true);      //返回领取成就结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_REACH_ACHIEVE, ReturnNewAchieve, false);      //服务端通知新成就达成
        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_ACHIEVE_NUM, RefreshNewAchieve, false);      //服务端通知成就达成个数
        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_REACH_GOAL, ReturnNewTarget, false);      //服务端通知成就达成个数
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_ACHIEVE_FINISH, OnG2CNotifyAchieveFinish, false);      //通知显示红点

    }

    private void OnG2CNotifyAchieveFinish(BinaryReader br)
    {
        G2CNotifyAchieveFinish msg = new G2CNotifyAchieveFinish();
        msg.Read(br);
        SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
    }

    #region 请求服务端消息
    public void RequestAchieveList(eAchieveType type)//请求成就列表
    {
        achieveType = type;
        NullStruct requsetMsg = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_ACHIEVE_LIST, (ushort)ProCG.GAME_SEND_ACHIEVE_LIST, requsetMsg);
    }
    public void RequestGetAchieve(uint achieveID)//请求领取成就奖励
    {
        C2GReqGetAchieveAward requsetMsg = new C2GReqGetAchieveAward();
        requsetMsg.uiAchieveID = achieveID;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GET_ACHIEVE_AWARD, (ushort)ProCG.GAME_ACK_GET_ACHIEVE_AWARD, requsetMsg);
    }
    public void RequestGetTarget(uint targetType)//请求领取成就奖励
    {
        C2GrequestGoalAward requsetMsg = new C2GrequestGoalAward();
        requsetMsg.uiGoalType = (ushort)targetType;
        targetId = targetType.ToString();
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GET_GOAL_AWARD, (ushort)ProCG.GAME_ACK_GET_ACHIEVE_AWARD, requsetMsg);
    }
    #endregion

    #region 服务端返回成就消息
    private void ReturnAchieveList(BinaryReader br)//服务端返回成就列表
    {
        G2CSendAchieveList resultMsg = new G2CSendAchieveList();
        resultMsg.Read(br);

        achieveList = resultMsg.achieveList;
        targetList = resultMsg.goalList;
        petInfo = resultMsg.cPet;
        mountInfo = resultMsg.cMount;
        UpdataAchieve();
        SingletonObject<CPlayer>.GetInst().SetCanGetAchieve();
        AchieveMediator achieve = SingletonObject<AchieveMediator>.GetInst();
        switch (achieveType)
        {
            case eAchieveType.Open:
                achieve.SetStartState();
                break;
        }
        if (achieve.IsOpen)
        {
            achieve.bGetData = true;
            achieve.ReSetDelayCreate();
            achieve.m_bCreatCard = true;
            achieve.UpdateAchieveComponent();
        }
    }
    private void ReturnGetAchieve(BinaryReader br)//服务端返回领取成就奖励
    {
        G2CAckGetAchieveAward resultMsg = new G2CAckGetAchieveAward();
        resultMsg.Read(br);
        EnumAchieveAward type = (EnumAchieveAward)resultMsg.uiResult;
        //MyLog.LogError(".....................................ReturnGetAchieve....." + type);
        if (type == EnumAchieveAward.EnumAchieveAward_Success)
        {
            SingletonObject<CPlayer>.GetInst().SetCanGetAchieve();
            RequestAchieveList(eAchieveType.Open);
            FLSDK.missionSuccess(targetId);
            if (onRequestFinished != null)
            {
                onRequestFinished();
                onRequestFinished = null;
            }
        }
        else
        {
            ResultControl(type);
        }

    }
    private void ReturnNewAchieve(BinaryReader br)//服务端返回新成就达成
    {
        G2CNotifyReachAchieve resultMsg = new G2CNotifyReachAchieve();
        resultMsg.Read(br);
        achieveCount++;
        SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
        SingletonObject<AchieveUnLockMediator>.GetInst().UnLockAchievement(resultMsg.uiAchieveID);
    }
    private void RefreshNewAchieve(BinaryReader br)//服务端返回新成就达成个数
    {
        G2CNotifyAchieveNum resultMsg = new G2CNotifyAchieveNum();
        resultMsg.Read(br);
        SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
    }
    private void ReturnNewTarget(BinaryReader br)//服务端返回通知有目标达成
    {
        G2CNotifyReachGoal resultMsg = new G2CNotifyReachGoal();
        resultMsg.Read(br);
        SingletonObject<HomeMainMediator>.GetInst().NewAchieveTips = true;
    }
    #endregion

    public void UpdataAchieve()
    {
        //Dictionary<uint, AchieveContent> achieveDict = CStaticDownload<AchieveContent>.GetInst().GetDict();
        AchieveContent achieveInfo = null;
        int _achieveCount = achieveList.Count;
        CurAchieveList.Clear();
        for (int i = 0; i < _achieveCount; i++)
        {
            stAchieveInfo stAchieve = new stAchieveInfo();
            Achieve achieve = achieveList[i];
            achieveInfo = HolderManager.m_AchieveHolder.GetStaticInfo(achieve.uiAchieveID);
            if (achieveInfo != null)
            {
                if (achieve.uiFlag > 2)
                {
                    //最后一个成就
                    //if (achieveInfo.NextAchieveID == 0)
                    //{

                    //} 
                    stAchieve.uiFlag = 2;
                }
                else
                {
                    stAchieve.uiFlag = achieve.uiFlag;
                }
                stAchieve.baseAchieve = achieveInfo;
                stAchieve.uiType = achieve.uiType;
                stAchieve.uiParam = achieve.uiParam;
                CurAchieveList.Add(stAchieve);
            }
        }
        //MyLog.Log("===========================");
        UpdateTarget();
    }

    public void UpdateTarget()
    {
        //MyLog.LogError("===========================");
        EverydayTargetContent targetInfo = null;
        CurTargetList.Clear();
        for (int i = 0, iCount = targetList.Count; i < iCount; i++)
        {
            stTargetInfo stTarget = new stTargetInfo();
            Achieve achieve = targetList[i];
            targetInfo = HolderManager.m_EverydayTargetHolder.GetStaticInfo(achieve.uiAchieveID);
            if (targetInfo != null)
            {
                if (achieve.uiFlag > 2)
                {
                    stTarget.uiFlag = 2;
                }
                else
                {
                    stTarget.uiFlag = achieve.uiFlag;
                }
            }
            stTarget.baseTarget = targetInfo;
            stTarget.uiType = achieve.uiType;
            stTarget.uiParam = achieve.uiParam;
            CurTargetList.Add(stTarget);
        }
    }

    /// <summary>
    /// 檢測是否存在成就解説彈窗
    /// </summary>
    public void Update()
    {
        bool bHasFind = false;
        if (SingletonObject<AchieveUnLockMediator>.GetInst().unLockList.Count > 0)
        {
            if (ClientMain.GetInst().GetCurrentState() == eGameState.LOADING) return;
            if (ClientMain.GetInst().GetCurrentState() == eGameState.Battle)
            {
                if (ClientMain.GetInst().GetCurrentState() == eGameState.ArenaUI)
                {
                    if (SingletonObject<ArenaResultMediator>.GetInst().bShowResult)
                    {
                        bHasFind = true;
                    }
                }
                else
                {
                    if (SingletonObject<BattleScene>.GetInst().IsGameOver() && bShowUnLocakEffect)
                    {
                        //战斗、爬塔、竞技场等解锁成就框在战斗结束弹出
                        bHasFind = true;
                    }
                }
            }
            else if (ClientMain.GetInst().GetCurrentState() == eGameState.Home)
            {
                bHasFind = true;
            }
            if (bHasFind)
            {
                if (!SingletonObject<AchieveUnLockMediator>.GetInst().IsOpen)
                    SingletonObject<AchieveUnLockMediator>.GetInst().Open(null);
            }
        }
    }

    public void ResultControl(EnumAchieveAward type)
    {
        string mssageText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        PopFrameMediator popMssage = SingletonObject<PopFrameMediator>.GetInst();
        switch (type)
        {
            case EnumAchieveAward.EnumAchieveAward_Success:             //成功
                mssageText = "Eorr Code:" + type;
                break;
            case EnumAchieveAward.EnumAchieveAward_IDError:     //ID错误
                mssageText = Common.GetText(9100098);
                break;
            case EnumAchieveAward.EnumAchieveAward_NoReach:     //成就未达成
                mssageText = Common.GetText(9100099);
                break;
            case EnumAchieveAward.EnumAchieveAward_AlreadyDelivery:     //已经领取过
                mssageText = Common.GetText(9100100);
                break;
            case EnumAchieveAward.EnumAchieveAward_BagFull:     //已经领取过
                mssageText = Common.GetText(9100100);
                break;
        }
        popMssage.SetPopFrameTips(mssageText, frameType);
    }

    #region get and set

    public List<stAchieveInfo> GetCurrentAchieve()
    {
        List<stAchieveInfo> tempcouldget = new List<stAchieveInfo>();
        List<stAchieveInfo> tempunlock = new List<stAchieveInfo>();
        List<stAchieveInfo> tempfinish = new List<stAchieveInfo>();
        for (int i = 0, count = CurAchieveList.Count; i < count; i++)
        {
            if (CurAchieveList[i].uiFlag == 1)
                tempcouldget.Add(CurAchieveList[i]);
            else if (CurAchieveList[i].uiFlag == 0)
                tempunlock.Add(CurAchieveList[i]);
            else
                tempfinish.Add(CurAchieveList[i]);
        }
        if (tempcouldget != null)
            tempcouldget.Sort(OnCompareByIDWithIncrease);
        if (tempunlock != null)
            tempunlock.Sort(OnCompareByIDWithIncrease);
        if (tempfinish != null)
            tempfinish.Sort(OnCompareByIDWithIncrease);
        List<stAchieveInfo> result = new List<stAchieveInfo>();
        for (int i = 0, count = tempcouldget.Count; i < count; i++)
        {
            result.Add(tempcouldget[i]);
        }
        for (int i = 0, count = tempunlock.Count; i < count; i++)
        {
            result.Add(tempunlock[i]);
        }
        for (int i = 0, count = tempfinish.Count; i < count; i++)
        {
            result.Add(tempfinish[i]);
        }
        CurAchieveList = result;
        return CurAchieveList;
    }

    /// <summary>
    /// 增序比较器
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <returns></returns>
    private int OnCompareByIDWithIncrease(stAchieveInfo x, stAchieveInfo y)
    {
        return x.baseAchieve.SortIndex.CompareTo(y.baseAchieve.SortIndex);
    }

    public List<stTargetInfo> GetCurrentTarget()
    {
        return CurTargetList;
    }
    #endregion

}

public struct stAchieveInfo
{
    public AchieveContent baseAchieve;
    public byte uiType;
    public ushort uiParam;
    public byte uiFlag;
}

public struct stTargetInfo
{
    public EverydayTargetContent baseTarget;            //goal 数据表
    public byte uiType;
    public ushort uiParam;
    public byte uiFlag;
    public int sortindex;//排序索引
    public QuestContent questLoader;//主线任务
    public G2CSendPetInfo petInfo;
    public G2CSendMountsInfo mountInfo;
    public eTargetGotoType targetGotoType;
}