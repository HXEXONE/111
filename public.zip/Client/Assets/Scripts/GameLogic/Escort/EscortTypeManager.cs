﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;

public class EscortTypeManager : SingletonObject<EscortTypeManager>
{
    public UInt32Array idList = new UInt32Array();

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_SHILIAN_ACTIVITY, escortResult, true);
    }

    public void requestEscortType()
    {
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_SHILIAN_ACTIVITY, (ushort)ProCG.GAME_ACK_SHILIAN_ACTIVITY, null);
    }

    private void escortResult(BinaryReader br)
    {
        G2CAckShiLianActivity cdkeyResult = new G2CAckShiLianActivity();
        cdkeyResult.Read(br);
        idList = cdkeyResult.vActivityID;
        MyLog.LogError("");

        HomeNPCContent load = HolderManager.m_HomeNPCHolder.GetStaticInfo(15000003);
        NpcUIManager.GetInst().openUi(load);
    }
}
