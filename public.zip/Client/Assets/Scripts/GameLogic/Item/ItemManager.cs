﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;
using System;

public class ItemManager :SingletonObject<ItemManager>
{
    public delegate void AddItemDelegata();
    public AddItemDelegata OnAddItemDelegate;

    private uint m_uiWeaponID;
    private uint m_uiClothesID;

    //private PackItemInfoVec packItemList =new PackItemInfoVec();
    //private List<PackItemInfo> allItemList = new List<PackItemInfo>();
    private Dictionary<uint, List<ushort>> allItemList = new Dictionary<uint, List<ushort>>();
    //private Dictionary<ushort, uint> allItemForIndex = new Dictionary<ushort, uint>();

    private List<PackItemInfo> currentItemList = new List<PackItemInfo>();
    private List<PackItemInfo> allEquipList = new List<PackItemInfo>();

    public List<int> SEVEN_DISCOUNT_GOLDBOX_ID = new List<int>();//七日活动黑货打折卡
    public List<int> PARTNER_STAR_SOULCARD_ID = new List<int>();//七日活动伙伴升星战魂
    public List<int> ITEM_DOUBLE_BUFF_ID = new List<int>();   //运营双倍活动物品

    //private List<PackItemInfo> roleEquipList = new List<PackItemInfo>();                            //玩家身上装备列表
    //private EquipItemManager equipItemInfo ;                            //玩家装备列表
    //private NormalItemManager normalItemInfo ;                            //普通物品列表
    //private PetFoodItemManager petFoodInfo ;                          //宠物口粮列表
    //private MountFoodItemManager mountFoodInfo ;                         //坐骑口粮列表
    //private PartnerCardManager partnerCardInfo ;                         //小伙伴卡片列表
    //private PYXItemManager PYXItemInfo ;                              //圣器物品列表

    private stEquipBoxInfo equipBoxInfo;
    private string attriName = string.Empty;
    private string attriValue = "0";

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_CLIENT_ITEMINFO, GetItemInfo,false);//获得物品数据
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_ADD_ITEM, AddItemInfo,false);//客户端增加物品
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_USE_ITEM_RESULT, UseItemResult, true);//客户端使用物品

        SingletonObject<RoleEquipManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<EquipItemManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<NormalItemManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<PetFoodItemManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<MountFoodItemManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<PartnerCardManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<PYXItemManager>.GetInst().RegisteMessages(pClient);
        SingletonObject<SoulDiamondManager>.GetInst().RegisteMessages(pClient);

        equipBoxInfo = new stEquipBoxInfo();
    }

    public void RequstUseItem(ushort uiIndex)
    {
        C2GReqUseItem msg = new C2GReqUseItem();
        msg.uiPackIndex = uiIndex;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_USE_ITEM, (ushort)ProCG.GAME_ACK_CLIENT_USE_ITEM_RESULT, msg, true);
    }


    //获得物品数据
    private void GetItemInfo(BinaryReader br)
    {
        G2CSendItemInfo msg = new G2CSendItemInfo();
        msg.Read(br);
        allItemList.Clear();
        ClearAllList();
        List<PackItemInfo> packItemList = msg.sItemInfoVec;
        eChaarcterEquipType equipType = eChaarcterEquipType.Weapon;
        for (int i = 0, count = packItemList.Count; i < count; ++i)
        {
            equipType = (eChaarcterEquipType)packItemList[i].uiIndex;
            switch (equipType)
            {
                case eChaarcterEquipType.Weapon:
                    m_uiWeaponID = packItemList[i].uiItemId;
                    break;
                case eChaarcterEquipType.Clothes:
                    m_uiClothesID = packItemList[i].uiItemId;
                    break;
                case eChaarcterEquipType.Headwear:

                    break;
                case eChaarcterEquipType.Shoe:

                    break;
                case eChaarcterEquipType.Ring:

                    break;
                case eChaarcterEquipType.Necklace:
                    
                    break;
               default:
                    break;
            }
            FitrateItem(packItemList[i]);

        }
        SingletonObject<EquipItemManager>.GetInst().SetEquipNewTip();
        SingletonObject<CPlayer>.GetInst().SetWeaponClothesID(m_uiWeaponID, m_uiClothesID);
        SingletonObject<CPlayer>.GetInst().CheckHasPartnerCanUpgrade();
        InitLocalItemData();
    }
    //初始化一些本地一类的数据，入战魂，黑货打折卡，运营双倍活动物品
    private void InitLocalItemData()
    {
        Dictionary<int, ItemContent> itemLocal = HolderManager.m_ItemHolder.GetDict();
        SEVEN_DISCOUNT_GOLDBOX_ID.Clear();
        PARTNER_STAR_SOULCARD_ID.Clear();//七日活动伙伴升星战魂
        ITEM_DOUBLE_BUFF_ID.Clear();    
        eItemUseType useType =eItemUseType.None;

        foreach (KeyValuePair<int, ItemContent> kvp in itemLocal)
        {

            if (kvp.Value !=null)
            {
                useType = (eItemUseType)kvp.Value.ScriptID;
            }
            switch (useType)
            {
            case eItemUseType.GoldBoxDiscountItem:

                    SEVEN_DISCOUNT_GOLDBOX_ID.Add(kvp.Key);
                    break;
                case eItemUseType.PartnerZhanHunItem:

                    PARTNER_STAR_SOULCARD_ID.Add(kvp.Key);
                    break;
                case eItemUseType.PveDoubleItem:

                    ITEM_DOUBLE_BUFF_ID.Add(kvp.Key);
                    break;
            }
        }
    }

    //增加物品,G2CNotifyAddItem
    private void AddItemInfo(BinaryReader br)
    {
        G2CNotifyAddItem msg = new G2CNotifyAddItem();
        msg.Read(br);
        PackItemInfoVec item = msg.sItemInfoVec;
        
        for (int i = 0, count = item.Count; i < count; ++i)
        {
            FitrateAddItem(item[i], item[i].uiIndex);
            SingletonObject<PackMediator>.GetInst().SetItem(item[i].uiIndex, item[i]);
        }
        if (OnAddItemDelegate !=null)
        {
            OnAddItemDelegate();
            OnAddItemDelegate = null;
        }
        SingletonObject<EquipItemManager>.GetInst().SetEquipNewTip();
        SingletonObject<CPlayer>.GetInst().CheckHasPartnerCanUpgrade();
        
    }

    private void UseItemResult(BinaryReader br)
    {
        G2CUseItemResult msg = new G2CUseItemResult();
        msg.Read(br);
        if (msg.uiResult == (ushort)EnumItemErr.ItemErr_Success)
        {
            List<HUDAwardItem> dict = new List<HUDAwardItem>();

             string tip = String.Empty;
             ItemContent itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(msg.uiUseItemID);
            eItemUseType useType =eItemUseType.None;

            if (itemInfo!=null)
            {
                tip = ItemManager.GetItemName(itemInfo);
                useType = (eItemUseType)itemInfo.ScriptID;
            }
            switch (useType)
            {
                case eItemUseType.AddPetWishAndExp:
                    tip = Common.GetTextS(9910822, tip);
                    if (msg.vGainList.Count > 1)
                    {
                        tip += Common.GetText(9910847) + msg.vGainList[0].uiInt32Value;
                        //tip += Common.GetText(9910837) + msg.vGainList[1].uiInt32Value;
                    }
                    else if (msg.vGainList.Count > 0)
                    {
                        tip += Common.GetText(9910847) + msg.vGainList[0].uiInt32Value;
                    }
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.AddMountWishAndExp:

                    tip = Common.GetTextS(9910822, tip);
                    if (msg.vGainList.Count > 1)
                    {
                        tip += Common.GetText(9910848) + msg.vGainList[0].uiInt32Value;

                        //tip += Common.GetText(9910837) + msg.vGainList[1].uiInt32Value;
                    }
                    else if (msg.vGainList.Count > 0)
                    {
                        tip += Common.GetText(9910848) + msg.vGainList[0].uiInt32Value;
                    }
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);

                    break;
                case eItemUseType.PetBuffItemID:
                    tip = Common.GetTextS(9910898, tip);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);

                    break;
                case eItemUseType.MountBuffItemID:
                    tip = Common.GetTextS(9910898, tip);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.AddSkillPoint:
                    tip = Common.GetTextS(9910822, tip);
                    tip += Common.GetText(9910859);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.AddWeaponLevel:
                    tip = Common.GetTextS(9910898, tip);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.AddClothLevel:
                    tip = Common.GetTextS(9910898, tip);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.PetUpgradeItem:
                    tip = Common.GetTextS(9910822, tip);
                    tip += Common.GetTextS(9910863, msg.uiParam1);

                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.MountUpgradeItem:
                    tip = Common.GetTextS(9910822, tip);
                    tip += Common.GetTextS(9910864, msg.uiParam1);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.MountUpgradeStarItem:
                    tip = Common.GetTextS(9910822, tip);
                    tip += Common.GetTextS(9910868, msg.uiParam1, msg.uiParam2);

                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.PetUpgradeStarItem:
                    tip = Common.GetTextS(9910822, tip);
                    tip += Common.GetTextS(9910867, msg.uiParam1, msg.uiParam2);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.PveDoubleItem:
                    tip = Common.GetTextS(9910898, tip);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    BattlePveManager.GetInst().RequestOtherTipInfo();
                    break;
                case eItemUseType.UpgradePlayerAttribute:
                    tip = Common.GetTextS(9910898, tip) + "," + Common.GetText(9910869);
                    attriName = string.Empty;
                    attriValue = "0";

                    if (itemInfo !=null)
                    {
                        if (itemInfo.ScriptArg.Count > 0)
                        {

                            if (itemInfo.ScriptArg[0].list.Count > 1)
                            {
                                switch (itemInfo.ScriptArg[0].list[0])
                                {
                                    case 1:                     //生命
                                        attriName = Common.GetText(9968002);
                                        break;
                                    case 2:                      //攻击
                                        attriName = Common.GetText(9968003);
                                        break;
                                    case 3:                     //防御
                                        attriName = Common.GetText(9968004);

                                        break;
                                    case 4:                     //命中
                                        attriName = Common.GetText(9968005);
                                        break;
                                    case 5:                     //闪避
                                        attriName = Common.GetText(9968006);
                                        break;
                                    case 6:                     //暴击
                                        attriName = Common.GetText(9968007);

                                        break;
                                    case 7:                     //暴击伤害
                                        attriName = Common.GetText(9968008);

                                        break;
                                    case 8:                     //移动
                                        attriName = Common.GetText(9968009);
                                        break;
                                    default:
                                        attriName = "error attribute";
                                        break;
                                }
                                if (itemInfo.ScriptArg[0].list[0] >=7)
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1]/100f +"%";

                                }
                                else
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1].ToString();

                                }

                            }
                        }
                    }
                    tip += (attriName + attriValue);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.UpgradePetAttribute:

                    tip = Common.GetTextS(9910898, tip) + "\n" + Common.GetText(9910870);
                    attriName = string.Empty;
                    attriValue = "0";

                    if (itemInfo != null)
                    {
                        if (itemInfo.ScriptArg.Count > 0)
                        {

                            if (itemInfo.ScriptArg[0].list.Count > 1)
                            {
                                switch (itemInfo.ScriptArg[0].list[0])
                                {
                                    case 1:                     //生命
                                        attriName = Common.GetText(9968002);
                                        break;
                                    case 2:                      //攻击
                                        attriName = Common.GetText(9968003);
                                        break;
                                    case 3:                     //防御
                                        attriName = Common.GetText(9968004);

                                        break;
                                    case 4:                     //命中
                                        attriName = Common.GetText(9968005);
                                        break;
                                    case 5:                     //闪避
                                        attriName = Common.GetText(9968006);
                                        break;
                                    case 6:                     //暴击
                                        attriName = Common.GetText(9968007);

                                        break;
                                    case 7:                     //暴击伤害
                                        attriName = Common.GetText(9968008);

                                        break;
                                    case 8:                     //移动
                                        attriName = Common.GetText(9968009);
                                        break;
                                    default:
                                        attriName = "error attribute";
                                        break;
                                }
                                if (itemInfo.ScriptArg[0].list[0] >= 7)
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1] / 100f + "%";

                                }
                                else
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1].ToString();

                                }

                            }
                        }
                    }
                    tip += (attriName + attriValue);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.UpgradeMountAttribute:

                    tip = Common.GetTextS(9910898, tip) + "\n" + Common.GetText(9910871);
                    attriName = string.Empty;
                    attriValue = "0";

                    if (itemInfo != null)
                    {
                        if (itemInfo.ScriptArg.Count > 0)
                        {

                            if (itemInfo.ScriptArg[0].list.Count > 1)
                            {
                                switch (itemInfo.ScriptArg[0].list[0])
                                {
                                    case 1:                     //生命
                                        attriName = Common.GetText(9968002);
                                        break;
                                    case 2:                      //攻击
                                        attriName = Common.GetText(9968003);
                                        break;
                                    case 3:                     //防御
                                        attriName = Common.GetText(9968004);

                                        break;
                                    case 4:                     //命中
                                        attriName = Common.GetText(9968005);
                                        break;
                                    case 5:                     //闪避
                                        attriName = Common.GetText(9968006);
                                        break;
                                    case 6:                     //暴击
                                        attriName = Common.GetText(9968007);

                                        break;
                                    case 7:                     //暴击伤害
                                        attriName = Common.GetText(9968008);

                                        break;
                                    case 8:                     //移动
                                        attriName = Common.GetText(9968009);
                                        break;
                                    default:
                                        attriName = "error attribute";
                                        break;
                                }
                                if (itemInfo.ScriptArg[0].list[0] >= 7)
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1] / 100f + "%";

                                }
                                else
                                {
                                    attriValue = "+" + itemInfo.ScriptArg[0].list[1].ToString();

                                }

                            }
                        }
                    }
                    tip += (attriName + attriValue);
                    SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    break;
                case eItemUseType.UpgradePetAppointLevelStar:
                    if (msg.sItemInfoVec.Count>0)
                    {
                        foreach (PackItemInfo packItemInfo in msg.sItemInfoVec)
                        {
                            HUDAwardItem item = new HUDAwardItem();
                            item.id = packItemInfo.uiItemId;
                            item.number = packItemInfo.uiItemNum;
                            dict.Add(item);
                        }
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);
                    }
                    else
                    {
                        tip = Common.GetTextS(9910822, tip);
                        tip += Common.GetTextS(9910867, msg.uiParam1, msg.uiParam2);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    }
                    
                    break;
                case eItemUseType.UpgradeMountAppointLevelStar:
                    if (msg.sItemInfoVec.Count>0)
                    {
                        foreach (PackItemInfo packItemInfo in msg.sItemInfoVec)
                        {
                            HUDAwardItem item = new HUDAwardItem();
                            item.id = packItemInfo.uiItemId;
                            item.number = packItemInfo.uiItemNum;
                            dict.Add(item);
                        }
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);
                    }
                    else
                    {
                        tip = Common.GetTextS(9910822, tip);
                        tip += Common.GetTextS(9910868, msg.uiParam1, msg.uiParam2);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                        
                    }
                    break;
                case eItemUseType.UpgradePetLevelStarCard:
                    if (msg.sItemInfoVec.Count > 0)
                    {
                        foreach (PackItemInfo packItemInfo in msg.sItemInfoVec)
                        {
                            HUDAwardItem item = new HUDAwardItem();
                            item.id = packItemInfo.uiItemId;
                            item.number = packItemInfo.uiItemNum;
                            dict.Add(item);
                        }
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);
                    }
                    else
                    {
                        tip = Common.GetTextS(9910822, tip);
                        tip += Common.GetTextS(9910867, msg.uiParam1, msg.uiParam2);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    }
                    break;
                case eItemUseType.GoldBoxDiscountItem:
                   SingletonObject<HUDAwardMediator>.GetInst().ShowAward(msg.uiUseItemID,-1);
                    break;
                case eItemUseType.PartnerZhanHunItem:
                    SingletonObject<HUDAwardMediator>.GetInst().ShowAward(msg.uiUseItemID, -1);
                    break;
                case eItemUseType.UpgradeMountLevelStarCard:
                    if (msg.sItemInfoVec.Count > 0)
                    {
                        foreach (PackItemInfo packItemInfo in msg.sItemInfoVec)
                        {
                            HUDAwardItem item = new HUDAwardItem();
                            item.id = packItemInfo.uiItemId;
                            item.number = packItemInfo.uiItemNum;
                            dict.Add(item);
                        }
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);
                    }
                    else
                    {
                        tip = Common.GetTextS(9910822, tip);
                        tip += Common.GetTextS(9910868, msg.uiParam1, msg.uiParam2);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);
                    }
                    break;
                default:
                    if (msg.sItemInfoVec.Count <= 0)
                    {
                        tip = Common.GetTextS(9910822, tip);
                        SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tip, Color.green);

                    }
                    else
                    {

                        foreach (PackItemInfo packItemInfo in msg.sItemInfoVec)
                        {
                            HUDAwardItem item = new HUDAwardItem();
                            item.id = packItemInfo.uiItemId;
                            item.number = packItemInfo.uiItemNum;
                            dict.Add(item);

                            //itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(packItemInfo.uiItemId);
                            //if (itemInfo != null)
                            //{
                            //    tip = ItemManager.GetItemName(itemInfo);
                            //}
                        }
                        SingletonObject<HUDAwardMediator>.GetInst().ShowAward(dict);
                    }
                    break;
            }
             

             

             
             SingletonObject<ItemSimpleInfoMediator>.GetInst().CallItemUse();
        }
        else
        {
            OperItemResult((EnumItemErr)msg.uiResult, msg.uiParam1.ToString());
        }

        
        
    }

    public void OperItemResult(EnumItemErr result,string args ="")
    {
        string text = null;
        switch (result)
        {
            case EnumItemErr.ItemErr_Success:
                {

                }
                break;
            case EnumItemErr.ItemErr_ItemNotExist:
                {
                    text = Common.GetText(9958105);
                    
                }
                break;
            case EnumItemErr.ItemErr_ErrItemIndex:
                {
                    text = Common.GetText(9100037);
                }
                break;
            case EnumItemErr.ItemErr_Full:
                {
                    text = Common.GetText(9922015);
                }
                break;
            case EnumItemErr.ItemErr_BossVigorEnough:
                {
                    text = Common.GetText(9100139);
                }
                break;
            case EnumItemErr.ItemErr_NotEnoughDiamond:
                {
                    text = Common.GetText(9100056);
                }
                break;
            case EnumItemErr.ItemErr_BuyVigorCountNotEnough:
                {
                    text = Common.GetText(9937018);
                }
                break;
            case EnumItemErr.ItemErr_BuyGoldCountNotEnough:
                {
                    text = Common.GetText(9937019);
                }
                break;
            case EnumItemErr.ItemErr_ItemJumpLevelButLimit:
                {
                    text = Common.GetText(9100257);
                }
                break;
            case EnumItemErr.ItemErr_ItemJumpLevelButLower:
                {
                    text = Common.GetText(9100258);
                }
                break;
            case EnumItemErr.ItemErr_ItemJumpLevelButUpper:
                {
                    text = Common.GetText(9100259);
                }
                break;
            case EnumItemErr.ItemErr_ItemNotEnough: //物品数量不足
                {
                    text = Common.GetText(9910821);
                }
                break;
            case EnumItemErr.ItemErr_ErrScriptId :     //错误的scriptId
                {
                    text = Common.GetText(9910823);
                }
                break;
            case EnumItemErr.ItemErr_MountAlreadyMaxLevel:    //坐骑已经最高级了
                {
                    text = Common.GetText(9910824);
                }
                break;
            case EnumItemErr.ItemErr_PetAlreadyMaxLevel :    //宠物已经最高级了
                {
                    text = Common.GetText(9910825);
                }
                break;
                case EnumItemErr.ItemErr_PetRankNotEnough :   //宠物阶数还没达到
                {
                    text = Common.GetText(9910828);
                }
                break;
                case EnumItemErr.ItemErr_MountRankNotEnough :   //坐骑阶数还没达到
                {
                    text = Common.GetText(9910829);
                }
                break;
                case EnumItemErr.ItemErr_SkillPointEnough :    //技能点已充足
                {
                    text = Common.GetText(9910875);
                }
                break;
            case EnumItemErr.ItemErr_PetAvatarLevelLimit :     //当前升级宠物有角色等级限制
                {
                    text = Common.GetText(9910876);
                }
                break;
            case EnumItemErr.ItemErr_PetPveProgressLimit :    //当前升级宠物有关卡进度限制
                {
                    text = Common.GetText(9910877);
                }
                break;
            case EnumItemErr.ItemErr_MountAvatarLevelLimit :     //当前升级坐骑有角色等级限制
                {
                    text = Common.GetText(9910878);
                }
                break;
            case EnumItemErr.ItemErr_MountPveProgressLimit:     //当前升级坐骑有关卡进度限制
                {
                    text = Common.GetText(9910879);
                }
                break;

            case EnumItemErr.ItemErr_MoudleNotOpen:     //模块未开启
                {
                    text = Common.GetText(9910882);
                }
                break;
            case EnumItemErr.ItemErr_AlreadyUsePetFeedbackItem:     //已经使用宠物鼓励之书
                {
                    text = Common.GetText(9910883);
                }
                break;
            case EnumItemErr.ItemErr_AlreadyUseMountFeedbackItem:     //已经使用坐骑鼓励之书
                {
                    text = Common.GetText(9910884);
                }
                break;
            case EnumItemErr.ItemErr_StrengthenTopLevel:     ////已经是强化满级了
                {
                    text = Common.GetText(9910885);
                }
                break;
            case EnumItemErr.ItemErr_StrenthenLevelNotEnough :     //强化等级不足
                {
                    text = Common.GetText(9910886);
                }
                break;
            case EnumItemErr.ItemErr_PetAddRankNotEnough :    //宠物达到4阶及以上时可使用
                {
                    text = Common.GetText(9910887);
                }
                break;
            case EnumItemErr.ItemErr_MountAddRankNotEnough :    //1112,     //坐骑达到4阶及以上时可使用
                {
                    text = Common.GetText(9910888);
                }
                break;
            case EnumItemErr.ItemErr_PetRankMax:    //宠物已经到达最大阶
                {
                    text = Common.GetText(9910889);
                }
                break;
            case EnumItemErr.ItemErr_MountRankMax:        //坐骑已经到达最大阶
                {
                    text = Common.GetText(9910890);
                }
                break;
            case EnumItemErr.ItemErr_UnknownErr:        ////未知错误
                {
                    text = Common.GetText(9910891);
                }
                break;
            case EnumItemErr.ItemErr_PetNotOpen:         //宠物功能未开启
                {
                    text = Common.GetText(9910892);
                }
                break;
            case EnumItemErr.ItemErr_MountNotOpen:        //坐骑功能未开启
                {
                    text = Common.GetText(9910893);
                }
                break;
            case EnumItemErr.ItemErr_PlayerLevelNotEnough:        //坐骑功能未开启
                {
                    text = Common.GetText(9910899);
                }
                break;
            case EnumItemErr.ItemErr_UsePetJumRankItem_RankNotEnough: //= 1118,     //宠物等级不足，请升至X阶再使用
                {
                    text = Common.GetTextS(9968010,args);
                }
                break;
            case EnumItemErr.ItemErr_UseMountJumRankItem_RankNotEnough: //= 1119,     //坐骑等级不足，请升至X阶再使用
                {
                    text = Common.GetTextS(9968011,args);
                }
                break;
            case EnumItemErr.ItemErr_TimeInvalid: //= 1120,     //物品过期
                {
                    text = Common.GetTextS(9968000);
                }
                break;
            default:
                {
                    text = "Error Code:"+ result;
                }
                break;
        }

        if (text != null)
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(text,Color.red);
        }

    }

    private BaseItem GetManager(ushort uiIndex)
    {
        BaseItem inst = null;
        if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_ArtifactBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_ArtifactBegin + (ushort)EnumItemBagMax.EnumItemBagRange_ArtifactMax))          //圣器（神器）碎片物品
        {
            inst = SingletonObject<PYXItemManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_PartnerBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_PartnerBegin + (ushort)EnumItemBagMax.EnumItemBagRange_PartnerMax))      //小伙伴卡
        {
            inst = SingletonObject<PartnerCardManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_MountsConsumeBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_MountsConsumeBegin + (ushort)EnumItemBagMax.EnumItemBagRange_MountsConsumeMax))     //坐骑口粮
        {
            inst = SingletonObject<MountFoodItemManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_PetConsumeBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_PetConsumeBegin + (ushort)EnumItemBagMax.EnumItemBagRange_PetConsumeMax))     //宠物口粮
        {
            inst = SingletonObject<PetFoodItemManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_HunShiBegin &&
        uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_HunShiBegin + (ushort)EnumItemBagMax.EnumItemBagRange_HunShiMax))       //灵魂石
        {
            inst = SingletonObject<SoulDiamondManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_MaterialBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_MaterialBegin + (ushort)EnumItemBagMax.EnumItemBagRange_MaterialMax))       //普通物品
        {
            inst = SingletonObject<NormalItemManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipBagBegin &&
            uiIndex < ((ushort)EnumItemBagRange.EnumItemBagRange_EquipBagBegin + (ushort)EnumItemBagMax.EnumItemBagRange_EquipBagMax))        //基本装备背包
        {
            inst = SingletonObject<EquipItemManager>.GetInst();
        }
        else if (uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipOnBegin && uiIndex < (ushort)EnumItemBagMax.EnumItemBagRange_EquipOnMax)         //身上装备
        {
            inst = SingletonObject<RoleEquipManager>.GetInst();
        }
        return inst;
    }

    //物品分类存放
    private void FitrateItem(PackItemInfo item)
    {
        BaseItem manager = GetManager(item.uiIndex);
        if (null != manager)
        {
            manager.RepleaceItem(item);
        }
        else
        {
           
        }
        
    }
    //添加物品分类存放
    private void FitrateAddItem(PackItemInfo item ,ushort uiIndex)
    {
        BaseItem manager = GetManager(uiIndex);
        if (null != manager)
        {
            Type type = manager.GetType();
            if (type == typeof(PartnerCardManager) || type == typeof(RoleEquipManager))
            {
                manager.RepleaceItem(item, false);
            }
            else
            {
                manager.RepleaceItem(item, true);
            }
        }
        else
        {
           
        }
    }

    public void UpdatePackInfo(PackItemInfo item, ushort uiIndex)
    {
        BaseItem manager = GetManager(uiIndex);
        if (null != manager)
        {
            bool bAdd = true;
            if (manager is PartnerCardManager || manager is RoleEquipManager)
            {
                bAdd = false;
            }
            manager.RepleaceItem(item, bAdd);
            /*if (manager is EquipItemManager)
            {
                ((EquipItemManager)manager).SetEquipNewTip();
            }*/
        }
        else
        {
          
        }
    }

    private void ClearAllList()
    {
        SingletonObject<RoleEquipManager>.GetInst().Clear();                         //玩家身上装备列表
        SingletonObject<EquipItemManager>.GetInst().Clear();                           //玩家装备列表
        SingletonObject<NormalItemManager>.GetInst().Clear();                         //普通物品列表
        SingletonObject<PetFoodItemManager>.GetInst().Clear();                         //宠物坐骑口粮列表
        SingletonObject<MountFoodItemManager>.GetInst().Clear();                         //宠物坐骑口粮列表
        SingletonObject<PartnerCardManager>.GetInst().Clear();                        //小伙伴卡片列表
        SingletonObject<PYXItemManager>.GetInst().Clear();
        SingletonObject<SoulDiamondManager>.GetInst().Clear(); 

    }
    #region get and set
    //玩家总共的item信息
    /*public PackItemInfoVec GetPackItemList()
    {
        return packItemList;
    }*/
    public void Update(PackItemInfo item, uint oldItemID)
    {
        /*if (allItemForIndex.ContainsKey(item.uiIndex))
        {
            uint oldId = allItemForIndex[item.uiIndex];
            if (oldId != item.uiItemId)
            {
                if (allItemList.ContainsKey(oldId))
                {
                    allItemList[oldId].Remove(item.uiIndex);
                }
            }
            allItemForIndex[item.uiIndex] = item.uiItemId;
        }
        else
        {
            allItemForIndex.Add(item.uiIndex, item.uiItemId);
        }*/
        if (oldItemID != item.uiItemId)
        {//删除掉老的
            if (allItemList.ContainsKey(oldItemID))
            {
                allItemList[oldItemID].Remove(item.uiIndex);
            }
        }
        if (allItemList.ContainsKey(item.uiItemId))
        {
            if (!allItemList[item.uiItemId].Contains(item.uiIndex))
            {
                allItemList[item.uiItemId].Add(item.uiIndex);
            }
        }
        else
        {
            List<ushort> list = new List<ushort>();
            list.Add(item.uiIndex);
            allItemList.Add(item.uiItemId, list);
        }
    }
    public void Remove(PackItemInfo item, uint oldItemID)
    {
        if (allItemList.ContainsKey(oldItemID) && allItemList[oldItemID].Contains(item.uiIndex))
        {
            allItemList[oldItemID].Remove(item.uiIndex);
        }
    }
    //玩家装备的装备信息
    public List<PackItemInfo> GetRoleEquipList()
    {
        RoleEquipManager roleEquip = SingletonObject<RoleEquipManager>.GetInst();
        if (roleEquip == null)
        {
            return null;
        }
        if (roleEquip.GetItemList().Count <= 0 || roleEquip.GetItemList() == null)
        {
            return null;
        }
        return roleEquip.GetItemList();
    }
    //玩家的装备item信息
    public List<PackItemInfo> GetEquipItemList(bool isAll =false)
    {
        EquipItemManager equipItem = SingletonObject<EquipItemManager>.GetInst();
        if (equipItem == null)
        {
            return null;
        }
        if (equipItem.GetItemList().Count <= 0 || equipItem.GetItemList() == null)
         {
             return null;
         }
        if (!isAll)
        {
            return equipItem.GetItemList();
        }
        else
        {
            allEquipList.Clear();
            allEquipList.AddRange(GetRoleEquipList());
            allEquipList.AddRange(equipItem.GetItemList());
            return allEquipList;
        }
    }

    
    //玩家的普通item信息
    public List<PackItemInfo> GetNormalItemList()
    {
        NormalItemManager normalItem = SingletonObject<NormalItemManager>.GetInst();
        if (normalItem == null)
        {
            return null;
        }
        if (normalItem.GetItemList().Count <= 0 || normalItem.GetItemList() == null)
        {
            return null;
        }
        return normalItem.GetItemList();
    }
    //玩家的宠物口粮item信息
    public List<PackItemInfo> GetPetFoodItemList()
    {
        PetFoodItemManager petFoodItem = SingletonObject<PetFoodItemManager>.GetInst();
        if (petFoodItem == null)
        {
            return null;
        }
        if (petFoodItem.GetItemList().Count <= 0 || petFoodItem.GetItemList() == null)
        {
            return null;
        }
        return petFoodItem.GetItemList();

    }
    public List<PackItemInfo> GetMountFoodItemList()
    {
        MountFoodItemManager mountFoodItem = SingletonObject<MountFoodItemManager>.GetInst();
        if (mountFoodItem == null)
        {
            return null;
        }
        if (mountFoodItem.GetItemList().Count <= 0 || mountFoodItem.GetItemList() == null)
        {
            return null;
        }
        return mountFoodItem.GetItemList();
    }
   
    public List<PackItemInfo> GetPartnerCardList()
    {
        PartnerCardManager partnerCard = SingletonObject<PartnerCardManager>.GetInst();
        if (partnerCard == null)
        {
            return null;
        }
        if (partnerCard.GetItemList().Count <= 0 || partnerCard.GetItemList() == null)
        {
            return null;
        }
        return partnerCard.GetItemList();
    }
    
    //玩家的圣器item信息
    public List<PackItemInfo> GetPYXItemList()
    {
        PYXItemManager PYXItem = SingletonObject<PYXItemManager>.GetInst();
        if (PYXItem == null)
        {
            return null;
        }
        if (PYXItem.GetItemList().Count <= 0 || PYXItem.GetItemList() == null)
        {
            return null;
        }
        return PYXItem.GetItemList();
    }

    //玩家的所有item信息
    public List<PackItemInfo> GetAllItemList()
    {
        List<PackItemInfo> list = new List<PackItemInfo>();
        /*foreach (KeyValuePair<ushort, uint> pair in allItemForIndex)
        {
            BaseItem inst = GetManager(pair.Key);
            if (null != inst)
            {
                PackItemInfo tmp = inst.GetItemInfo(pair.Key);
                if (null != tmp)
                {
                    list.Add(tmp);
                }
            }
        }*/
        foreach (KeyValuePair<uint, List<ushort>> pair in allItemList)
        {
            for (int i = 0, icount = pair.Value.Count; i < icount; ++i)
            {
                BaseItem inst = GetManager(pair.Value[i]);
                if (null != inst)
                {
                    PackItemInfo tmp = inst.GetItemInfo(pair.Value[i]);
                    if (null != tmp)
                    {
                        list.Add(tmp);
                    }
                }
            }
        }
        return list;
    }
    /// <summary>
    /// 通过道具id获取道具所占格子数
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public List<ushort> GetAllItemIndexForID(uint id)
    {
        List<ushort> list = new List<ushort>();
        if (allItemList.ContainsKey(id))
        {
            for (int i = 0, icount = allItemList[id].Count; i < icount; ++i)
            {
                list.Add(allItemList[id][i]);
            }
        }
        return list;
    }
    public List<PackItemInfo> GetAllItemListID(uint id, bool overdue = true)
    {
        List<PackItemInfo> packItem = new List<PackItemInfo>();
        if (allItemList.ContainsKey(id))
        {
            for (int i = 0, icount = allItemList[id].Count; i < icount; ++i)
            {
                BaseItem inst = GetManager(allItemList[id][i]);
                if (null != inst)
                {
                    PackItemInfo tmp = inst.GetItemInfo(allItemList[id][i]);
                    if (null != tmp)
                    {
                        packItem.Add(tmp);
                    }
                }
            }
        }
        /*for (int i = 0, iCout = allItemList.Count; i < iCout; i++)
        {
            if (allItemList[i].uiItemId == id)
            {
                packItem.Add(allItemList[i]);
            }
        }*/
        return packItem;
    }
    public List<PackItemInfo> GetAllItemListItem(PackItemInfo item, bool overdue =true)
    {
        List<PackItemInfo> packItem = new List<PackItemInfo>();

        packItem= GetAllItemListID(item.uiItemId);
        return packItem;
    }

    //判断物品是否过期
    public bool Overdue(PackItemInfo itemInfo)
    {
        if (itemInfo.iStartTime != 0)
        {
            DateTime startTime = new DateTime(1970, 1, 1).AddSeconds(itemInfo.iStartTime).ToLocalTime();
            DateTime endTime = new DateTime(1970, 1, 1).AddSeconds(itemInfo.iEndTime).ToLocalTime();

            double useTime = (DateTime.Now - PollManager.GetInst().getServerTime).TotalSeconds;
            uint serverTime = (uint)(PollManager.GetInst().serverTime + useTime);
            DateTime myTime = new DateTime(1970, 1, 1).AddSeconds(serverTime).ToLocalTime();

            if (myTime < startTime)
            {
                return true;
            }
            else if (myTime >= startTime && myTime <= endTime)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return true;
    }


    //判断物品是否限时
    public bool LimitTime(PackItemInfo itemInfo)
    {
        if (itemInfo.iStartTime == 0 && itemInfo.iEndTime ==0 )
        {
            return false;
        }
        return true;
    }

    public uint GetWeaponID()
    {
        return m_uiWeaponID;
    }

    public uint GetClothesID()
    {
        return m_uiClothesID;
    }

    public int GetPackEquipExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return PackEquipExtend;
            }
            //else
            {
                return 0;
            }
            
        }
    }
    public int GetNormalExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return NormalExtend;
            }
            //else
            {
                return 0;
            }

        }
    }
    public int GetPetFoodExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return PetFoodExtend;
            }
            //else
            {
                return 0;
            }

        }
    }
    public int GetMountFoodExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return MountFoodExtend;
            }
            //else
            {
                return 0;
            }

        }
    }
   
    public int GetPartnerCardExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return PartnerCardExtend;
            }
            //else
            {
                return 0;
            }
            
        }
    }
    public int GetPYXItemExtend
    {
        get
        {
            //if ()此处预留玩家是否付费(vip)
            {
                return PYXItemExtend;
            }
            //else
            {
                return 0;
            }
        }
    }

    /// <summary>
    /// 根据物品的ID，获取物品在列表中的序列
    /// </summary>
    /// <param name="itemID  物品ID"></param>
    /// <param name="isAll  是否从总列表中获取索引，默认为true"></param>
    /// <returns></returns>
    public ushort GetItemIndex(uint itemID,bool isAll =true)
    {
        ushort uIndex = 0;
        if (isAll)
        {
            if (allItemList.ContainsKey(itemID) && allItemList[itemID].Count > 0)
            {
                uIndex = allItemList[itemID][0];
            }
            /*for (int i = 0, count = packItemList.Count; i < count; i++)
            {
                if (packItemList[i].uiItemId == itemID)
                {
                    uIndex = packItemList[i].uiIndex;
                    break;
                }
            }*/
        }
        else
        {
            //这个根据ID获取分类物品的索引.扩展
        }

        return uIndex;
    }

    public PackItemInfo GetItem(ushort wIndex)
    {
        BaseItem inst = GetManager(wIndex);
        if (null != inst)
        {
            return inst.GetItemInfo(wIndex);
        }
        return null;
    }

    public stEquipBoxInfo EquipBoxInfo
    {
        get
        {
            return equipBoxInfo;
        }
        set
        {
            equipBoxInfo = value;
        }
    }

#endregion

    public const int RoleEquip = 6;                        //玩家身上装备数
    public const int PackEquip = 40;                       //玩家基本装备背包大小
    public const int NormalItem = 20;                      //玩家普通物品大小
    public const int PetFood = 3;                           //玩家宠物口粮大小
    public const int MountFood = 3;                         //玩家坐骑口粮大小
  
    public const int PartnerCard = 40;                     //玩家小伙伴卡大小
    public const int PYXItem = 10;                         //玩家圣器（神器）碎片物品大小

    private const ushort PackEquipExtend = 20;                 //玩家装备背包可扩充大小(普通玩家不可见,VIP可见)
    private const ushort NormalExtend = 0;                     //玩家普通物品可扩充大小(普通玩家不可见,VIP可见)
    private const ushort PetFoodExtend = 0;                     //玩家宠物坐骑口粮可扩充大小(普通玩家不可见,VIP可见)
    private const ushort MountFoodExtend = 0;                   //玩家宠物坐骑口粮可扩充大小(普通玩家不可见,VIP可见)
   
    private const ushort PartnerCardExtend = 0;                //玩家小伙伴卡大小可扩充大小(普通玩家不可见,VIP可见)
    private const ushort PYXItemExtend = 0;                    //玩家圣器（神器）物品可扩充大小(普通玩家不可见,VIP可见)


    private static Dictionary<string, ItemContent> m_itemDictByStr = new Dictionary<string, ItemContent>();
    public static ItemContent GetLoaderByID(string itemid)
    {
        int id = MyConvert_Convert.ToInt32(itemid);
        return HolderManager.m_ItemHolder.GetStaticInfo(id);
    }

    public List<int> GetDropLevelList(ItemContent content)
    {
        List<int> tempList = new List<int>();
        if (content.DropLevel1[0] != 0)
        {
            if (!tempList.Contains(content.DropLevel1[0]))
                tempList.Add(content.DropLevel1[0]);
        }
        if (content.DropLevel2 != 0)
        {
            if (!tempList.Contains(content.DropLevel2))
                tempList.Add(content.DropLevel2);
        }
        if (content.DropLevel3 != 0)
        {
            if (!tempList.Contains(content.DropLevel3))
                tempList.Add(content.DropLevel3);
        }
        return tempList;
    }

    public static string GetItemName(EquipContent content)
    {
        string name = Common.GetText(content.Name);
        string[] names = null;
        if (name.Contains("("))
        {
            names = name.Split('(');
        }
        else
        {
            names = name.Split('（');
        }
        if (names == null || names.Length < 1)
        {
            return string.Empty;
        }

        return names[0];
    }

    public static string GetItemName(ItemContent content)
    {
        string name = Common.GetText(content.Name);

        string[] names = null;
        if (name.Contains("("))
        {
            names = name.Split('(');
        }
        else
        {
            names = name.Split('（');
        }
        if (names == null || names.Length < 1)
        {
            return string.Empty;
        }

        return names[0];
    }
}
