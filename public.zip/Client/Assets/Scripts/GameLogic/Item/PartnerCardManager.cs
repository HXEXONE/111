﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;


public class PartnerCardManager : BaseItem {

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
    }

    public override void UpdataList(PackItemInfo itemInfo)
    {
        base.UpdataList(itemInfo);
    }

        #region 请求消息的数据处理

        #endregion


        #region 注册返回消息的回调处理

        #endregion
}
