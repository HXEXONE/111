﻿using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;
using System;
using UnityEngine;

public class EquipItemManager : BaseItem
{
    private IComparerPackItem comparerEquip;
    private IComparerGS m_icgscomparerEquip;
    private float m_delayTime = 2;                          //延迟时间

    private OpenBoxMediator cardAnimationMediator;        //招募过程实例
    public List<uint> equipIDList = new List<uint>();//装备列表ID
    public uint FreeRemainTimes;//剩余免费次数
    public ulong FreeRemainTime;//免费cd

    private static float sCheckFuMoOpenTime = 0;
    private static bool sFuMoOpenFlag = false;

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_EQUIP_ON, InstallEquipResult, true);      //使用装备结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_UNEQUIP_RESULT, UninstallEquipResult, true);    //卸载装备结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_SMELT_EQUIP, SmeltEquipResult, true);    //装备熔炼结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_UPGRADE_SMELT_LEVEL, SmeltUpLevelResult, true);//熔炉升级结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_STRENGTHEN_EQUIP, StrengthenEquipResult, true);    //装备强化结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_GET_SMELT_EQUIP_RESULT, GetSmeltEquipResult, true);    //装备熔炼获得结果
        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_OPEN_EQUIPBOX, GetOpenEquipBox,true);    //开装备宝箱结果
        //pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_OPEN_TEN_BOX_RESULT, onG2CAckOpenTenBoxResult,true);    //开装备宝箱结果
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_BATCH_SMELT_EQUIP, SmeltWasteResult, true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_STRENGTHEN_EQUIP, notifyEquipResult, false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_FUMO_EQUIP, EquipEnchantResult, true);//装备附魔结果
    }

    #region 请求消息的数据处理
    //使用装备请求
    public void InstallEquipRequest(ushort packIndex)
    {
        C2GReqEquipOn msgRequest = new C2GReqEquipOn();
        msgRequest.uiPackIndex = packIndex;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_EQUIP_ON, (ushort)ProCG.GAME_ACK_CLIENT_EQUIP_ON, msgRequest);
    }
    //使用卸载装备请求
    public void UninstallEquipRequest(ushort equipIndex)
    {
        C2GReqUnEquip msgRequest = new C2GReqUnEquip();
        msgRequest.uiEquipIndex = equipIndex;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_UNEQUIP, (ushort)ProCG.GAME_ACK_CLIENT_UNEQUIP_RESULT, msgRequest);
    }
    //发送熔炼装备请求
    public void SmeltEquipRequese(ushort equipIndex, ushort num)
    {
        C2GReqSmeltEquip msgRequest = new C2GReqSmeltEquip();
        msgRequest.uiItemIndex = equipIndex;
        msgRequest.uiNum = num;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_SMELT_EQUIP, (ushort)ProCG.GAME_ACK_CLIENT_SMELT_EQUIP, msgRequest);
    }
    //请求一键熔炼装备
    public void SmeltWasteRequese(List<PackItemInfo> equips)
    {
        C2GBatchSmeltEquip msgRequest = new C2GBatchSmeltEquip();
        PackItemInfoVec array = new PackItemInfoVec();
        for (int i = 0, count = equips.Count; i < count; i++)
        {
            array.Add(equips[i]);
        }
        msgRequest.vEquips = array;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_BATCH_SMELT_EQUIP, (ushort)ProCG.GAME_ACK_CLIENT_BATCH_SMELT_EQUIP, msgRequest);
    }
    //请求熔炉升级
    public void SmeltUpLevel()
    {
        NullStruct msgRequest = new NullStruct();
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_UPGRADE_SMELT_LEVEL, (ushort)ProCG.GAME_ACK_UPGRADE_SMELT_LEVEL, msgRequest);
    }

    //发送强化装备请求
    public void StrengthenEquipRequese(ushort equipIndex)
    {

        C2GReqStrengthenEquip msgRequest = new C2GReqStrengthenEquip();
        msgRequest.uiEquipPos = equipIndex;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_STRENGTHEN_EQUIP, (ushort)ProCG.GAME_ACK_CLIENT_STRENGTHEN_EQUIP, msgRequest);
    }

    //请求获得熔炼装备
    public void GetSmeltEquipRequese()
    {
        //C2GReqGetSmeltEquip msgRequest = new C2GReqGetSmeltEquip();
        //CPlayer playerInfo = SingletonObject<CPlayer>.GetInst();
        //if (playerInfo == null)
        //{
        //    return;
        //}
        if (CheckUseDiscount())
        {
            //存在该道具
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.okCancelButton, Common.GetText(9917018), OkDiscount);
        }
        else
        {
            SmeltEquip(0);
        }
    }

    private void SmeltEquip(ushort type)
    {
        C2GReqGetSmeltEquip msgRequest = new C2GReqGetSmeltEquip();
        msgRequest.uiUseBaiJinPaper = type;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_GAME_GET_SMELT_EQUIP, (ushort)ProCG.GAME_ACK_CLIENT_GET_SMELT_EQUIP_RESULT, msgRequest);
    }

    private void OkDiscount(PopFrameMediator.ClickType mClickType)
    {
        if (mClickType == PopFrameMediator.ClickType.clickOk)
        {
            SmeltEquip(1);
        }
        else if (mClickType == PopFrameMediator.ClickType.clickCancel)
        {
            SmeltEquip(0);
        }
        else if (mClickType == PopFrameMediator.ClickType.None)
        {
            SingletonObject<EquipSmeltMediator>.GetInst().bCanClick = true;
            SingletonObject<EquipSmeltMediator>.GetInst().isFirstClick = true;
        }
    }

    private bool CheckUseDiscount()
    {
        List<PackItemInfo> itemList = SingletonObject<NormalItemManager>.GetInst().GetItemList();
        bool haveDiscount = false;
        for (int i = 0; i < itemList.Count; i++)
        {
            if (itemList[i].uiItemId == DEFINE.SMELT_EQUIP_ITEM_ID)
            {
                haveDiscount = true;
                break;
            }
        }
        return haveDiscount;
    }

    /// <summary>
    /// 装备附魔
    /// </summary>
    public void EquipEnchant(uint targetIndex, Dictionary<ushort, uint> dict, uint lendExp)
    {
        C2GReqFuMoEquip msgRequest = new C2GReqFuMoEquip();
        msgRequest.uiTargetIndex = targetIndex;
        foreach (KeyValuePair<ushort, uint> pair in dict)
        {
            FuMoCost cost = new FuMoCost();
            cost.uiIndex = pair.Key;
            cost.uiNum = pair.Value;
            msgRequest.aCost.Add(cost);
        }
        msgRequest.uiExpSum = lendExp;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_FUMO_EQUIP, (ushort)ProCG.GAME_ACK_FUMO_EQUIP, msgRequest);
    }

    #endregion

    #region 注册返回消息的回调处理
    //使用装备结果处理
    private void InstallEquipResult(BinaryReader br)
    {
        G2CAckEquipOnResult msgResult = new G2CAckEquipOnResult();
        msgResult.Read(br);
        PackItemInfoVec list = msgResult.sItemInfoVec;


        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        //MyLog.LogError("------------------" + result);

        if (result == EnumItemErr.ItemErr_Success)
        {
            for (int i = 0, count = msgResult.sItemInfoVec.Count; i < count; i++)
            {
                //MyLog.LogError("---------  " + msgResult.sItemInfoVec[i].uiIndex + "..........." + msgResult.sItemInfoVec[i].uiItemId + "===========" + msgResult.sItemInfoVec[i].uiItemNum);
                if (msgResult.sItemInfoVec[i].uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipBagBegin)
                {
                    UpdataList(msgResult.sItemInfoVec[i]);
                }
                else if (msgResult.sItemInfoVec[i].uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipOnBegin)
                {
                    SingletonObject<RoleEquipManager>.GetInst().UpdataList(msgResult.sItemInfoVec[i]);
                }
            }
            SingletonObject<ChooseEquipMediator>.GetInst().UpdateEquipInfo();
            //if (m_bIsClick)
            //{
            //     SingletonObject<ChooseEquipMediator>.GetInst().InitClick();
            //}
            //else
            //{
            SingletonObject<ChooseEquipMediator>.GetInst().PlayEquipDownPosition();

            //}
            SetEquipNewTip();
        }

    }

    //卸载装备结果处理PopFrameMediator
    private void UninstallEquipResult(BinaryReader br)
    {
        G2CAckUnEuipResult msgResult = new G2CAckUnEuipResult();
        msgResult.Read(br);
        PackItemInfoVec list = msgResult.sItemInfoVec;


        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        if (result == EnumItemErr.ItemErr_Success)
        {
            for (int i = 0, count = msgResult.sItemInfoVec.Count; i < count; i++)
            {
                //MyLog.LogError("--------------" + msgResult.sItemInfoVec[i].uiIndex + "-------" + msgResult.sItemInfoVec[i].uiItemId + "-------" + msgResult.sItemInfoVec[i].uiItemNum);
                if (msgResult.sItemInfoVec[i].uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipBagBegin)
                {
                    UpdataList(msgResult.sItemInfoVec[i]);
                }
                else if (msgResult.sItemInfoVec[i].uiIndex >= (ushort)EnumItemBagRange.EnumItemBagRange_EquipOnBegin)
                {
                    SingletonObject<RoleEquipManager>.GetInst().UpdataList(msgResult.sItemInfoVec[i]);
                }
            }
            SingletonObject<ChooseEquipMediator>.GetInst().Initial(null, SingletonObject<ChooseEquipMediator>.GetInst().m_byPretype - 1);
            SingletonObject<ChooseEquipMediator>.GetInst().EnableCollider(true);
            SingletonObject<ChooseEquipMediator>.GetInst().ReSet();
            //SingletonObject<EquipMediator>.GetInst().InitPanel();
            MyLog.LogError("1");
            SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = true;
        }
        //MyLog.LogError("------------------" + result);
    }
    //装备熔炼结果
    public void SmeltEquipResult(BinaryReader br)
    {
        G2CSmeltEquipResult msgResult = new G2CSmeltEquipResult();
        msgResult.Read(br);
        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        if (result == EnumItemErr.ItemErr_Success)
        {
            RepleaceItem(msgResult.itemInfo, true);
            CPlayer playerInfo = SingletonObject<CPlayer>.GetInst();
            if (playerInfo == null)
            {
                return;
            }
            playerInfo.SmeltExpValue = msgResult.uiSumSmeltExp;
            Dictionary<int, float> items = new Dictionary<int, float>();
            for (int i = 0; i < msgResult.vFuMoItems.Count; i++)
            {
                if (!items.ContainsKey((int)msgResult.vFuMoItems[i].uiItemId))
                {
                    items.Add((int)msgResult.vFuMoItems[i].uiItemId, msgResult.vFuMoItems[i].uiItemNum);
                }
                else
                {
                    items[(int)msgResult.vFuMoItems[i].uiItemId] += msgResult.vFuMoItems[i].uiItemNum;
                }
            }
            SingletonObject<HUDAwardMediator>.GetInst().ShowAward(items);
            SingletonObject<EquipSmeltMediator>.GetInst().SetSmeltInfo();

        }

    }
    //熔炉升级结果
    public void SmeltUpLevelResult(BinaryReader br)
    {
        G2CAckUpgradeSmeltLevel msgResult = new G2CAckUpgradeSmeltLevel();
        msgResult.Read(br);
        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        if (EnumItemErr.ItemErr_Success == result)
        {
            CPlayer playerInfo = SingletonObject<CPlayer>.GetInst();
            if (null != playerInfo)
            {
                playerInfo.SmeltLevel = msgResult.uiSmeltLevel;
            }
            SingletonObject<EquipSmeltMediator>.GetInst().SmeltUpLevelUpdate();
        }
        else
        {
            SingletonObject<EquipSmeltMediator>.GetInst().SmeltUpLevelError(result);
        }
    }
    /// <summary>
    /// 装备附魔结果
    /// </summary>
    /// <param name="br"></param>
    public void EquipEnchantResult(BinaryReader br)
    {
        G2CAckFuMoEquip msgAck = new G2CAckFuMoEquip();
        msgAck.Read(br);
        EnumProtocolResult result = (EnumProtocolResult)msgAck.uiResult;
        if (EnumProtocolResult.EnumProtocolResult_Success == result)
        {
            SingletonObject<EnchantEquipMediator>.GetInst().EnchantSuccess(msgAck.cEquip);
        }
        else
        {
            SingletonObject<EnchantEquipMediator>.GetInst().EnchantError(result);
        }
    }

    //熔炼多余装备结果
    public void SmeltWasteResult(BinaryReader br)
    {
        G2CBatchSmeltEquipResult msgResult = new G2CBatchSmeltEquipResult();
        msgResult.Read(br);
        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        if (result == EnumItemErr.ItemErr_Success)
        {
            for (int i = 0, j = msgResult.sPackItemList.Count; i < j; i++)
            {
                UpdataList(msgResult.sPackItemList[i]);
            }
            CPlayer playerInfo = SingletonObject<CPlayer>.GetInst();
            Dictionary<int, float> items = new Dictionary<int, float>();
            for (int i = 0; i < msgResult.vFuMoItems.Count; i++)
            {
                if (!items.ContainsKey((int)msgResult.vFuMoItems[i].uiItemId))
                {
                    items.Add((int)msgResult.vFuMoItems[i].uiItemId, msgResult.vFuMoItems[i].uiItemNum);
                }
                else
                {
                    items[(int)msgResult.vFuMoItems[i].uiItemId] += msgResult.vFuMoItems[i].uiItemNum;
                }
            }
            SingletonObject<HUDAwardMediator>.GetInst().ShowAward(items);
            playerInfo.SmeltExpValue = msgResult.uiSumSmeltExp;
            SingletonObject<EquipSmeltMediator>.GetInst().SmeltWasteUpdata();
        }
        else
        {
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip("Error Code:" + msgResult.uiResult);
        }
    }

    //装备强化结果
    public void StrengthenEquipResult(BinaryReader br)
    {

        G2CStrengthenEquipResult msgResult = new G2CStrengthenEquipResult();
        msgResult.Read(br);

        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        MyLog.LogError("result :" + result);
        if (result == EnumItemErr.ItemErr_Success)
        {
            SingletonObject<RoleEquipManager>.GetInst().UpdataList(msgResult.sItemInfo);
            CPlayer player = SingletonObject<CPlayer>.GetInst();
            if (player == null)
            {
                return;
            }
            MyLog.LogError("............................." + msgResult.sItemInfo.uiItemId);
            if (msgResult.sItemInfo.uiIndex == 0)       //武器
            {
                player.SetWeaponClothesID(msgResult.sItemInfo.uiItemId, player.GetHomeAvatarInfo().uiClothesID);
            }

            else if (msgResult.sItemInfo.uiIndex == 1)
            {
                player.SetWeaponClothesID(player.GetHomeAvatarInfo().uiWeaponID, msgResult.sItemInfo.uiItemId);
            }
            //SingletonObject<SmithyMainMediator>.GetInst().SetStrengthenInfo();
            SingletonObject<IntensifyMediator>.GetInst().SetIntensifyEquip(msgResult.sItemInfo.uiIndex);
            SingletonObject<RoleEquipManager>.GetInst().UpdataList(msgResult.sItemInfo);
            SingletonObject<CPlayer>.GetInst().setEquipState();
        }
        else
        {
            MyLog.LogError("强化失败 :" + result);
            string tips = "ErrorCode:" + result;                                                           
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.red);
        }
    }

    private void notifyEquipResult(BinaryReader br)
    {
        G2CNotifyStrengthenEquip msgResult = new G2CNotifyStrengthenEquip();
        msgResult.Read(br);
        MyLog.LogError(msgResult.sItemInfo.uiIndex + "  -------------------" + msgResult.sItemInfo.uiItemId);
        CPlayer player = SingletonObject<CPlayer>.GetInst();
        if (msgResult.sItemInfo.uiIndex == 0)       //武器
        {
            player.SetWeaponClothesID(msgResult.sItemInfo.uiItemId, player.GetHomeAvatarInfo().uiClothesID);
        }

        else if (msgResult.sItemInfo.uiIndex == 1)
        {
            player.SetWeaponClothesID(player.GetHomeAvatarInfo().uiWeaponID, msgResult.sItemInfo.uiItemId);
        }
    }

    //获得熔炼装备结果
    public void GetSmeltEquipResult(BinaryReader br)
    {
        G2CAckGetSmeltEquip msgResult = new G2CAckGetSmeltEquip();
        msgResult.Read(br);
        EnumItemErr result = (EnumItemErr)msgResult.uiResult;
        ResultControl(result);
        EquipSmeltMediator equipMediator = SingletonObject<EquipSmeltMediator>.GetInst();
        if (result == EnumItemErr.ItemErr_Success)
        {
            RepleaceItem(msgResult.ItemInfo, true);
            CPlayer playerInfo = SingletonObject<CPlayer>.GetInst();
            if (playerInfo == null)
            {
                return;
            }
            cardAnimationMediator = SingletonObject<OpenBoxMediator>.GetInst();
            if (!cardAnimationMediator.IsOpen)
            {
                cardAnimationMediator.boxItemsList.Clear();
                DrawItem item = new DrawItem();
                item.mKind = DrawItemKind.box;
                item.uiItemId = msgResult.ItemInfo.uiItemId;
                item.uiItemType = 1;
                item.uiItemCount = msgResult.ItemInfo.uiItemNum;
                cardAnimationMediator.boxItemsList.Add(item);
                cardAnimationMediator.TempItemId = msgResult.uiEquipId;
                cardAnimationMediator.uiUseBaiJinPaper = msgResult.uiUseBaiJinPaper;
                cardAnimationMediator.uiIsBaiJinEquip = msgResult.uiIsBaiJinEquip;
                cardAnimationMediator.OnCardMoveCenterFinish(); //打开滚动动画
                //SingletonObject<CardAnimationMediator>.GetInst().onSmeltFinished = onAllEventFinish;//不用刷新了，装备熔炼都已经关闭了再打开会自动刷新，要不会出错
            }
            playerInfo.SmeltExpValue = msgResult.uiRemainExp;

            equipMediator.bCanClick = true;
            equipMediator.OnRefreshEquipSmelt();//刷新装备熔炼界面
            //RepleaceItem(msgResult.ItemInfo,true);
            //SingletonObject<EquipSmeltMediator>.GetInst().SetSmeltExpBar();
        }
        else
        {
            equipMediator.bCanClick = true;
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText("Error Code:" + msgResult.uiResult.ToString(), PopFrameType.singleOkButton, null);
        }
    }

    #endregion

    ////强化成功结果处理
    //private void StrengthenEquipHand(G2CStrengthenEquipResult msgResult)
    //{
    //    PackItemInfo itemInfo = GetPackItemToID(msgResult.sItemInfo.uiItemId);
    //    if (itemInfo == null)
    //    {
    //        //找不到 出现异常处理
    //    }
    //    else
    //    {
    //        UpdataList(itemInfo);
    //    }

    //}

    private void ResultControl(EnumItemErr result)
    {
        string tipText = string.Empty;
        PopFrameType frameType = PopFrameType.singleOkButton;
        switch (result)
        {
            case EnumItemErr.ItemErr_Success:            //成功
                {

                }
                break;
            case EnumItemErr.ItemErr_Full:              //要加的物品装不下了
                {

                }
                break;
            case EnumItemErr.ItemErr_ItemNotExist:     //物品不存在
                {

                }
                break;
            case EnumItemErr.ItemErr_ItemNotEnough:            //物品数量不足
                {

                }
                break;
            case EnumItemErr.ItemErr_NotEnoughGold:
                {
                    //tipText = Common.GetText(9100070);
                }
                break;
            case EnumItemErr.ItemErr_CanNotEquip:     //不能装备
                {
                    tipText = Common.GetText(9100050);
                    SingletonObject<PopFrameMediator>.GetInst().SetCallBack(OnSmeltExpNotEnough);
                }
                break;
            case EnumItemErr.ItemErr_SmeltExpNotEnough:     //熔炼经验不足
                {
                    //float oweValue = EquipSmeltMediator.maxSmeltValue - SingletonObject<CPlayer>.GetInst().SmeltExpValue;
                    //tipText = Common.GetTextS(9100059,oweValue.ToString("f0"));
                    //SingletonObject<PopFrameMediator>.GetInst().SetCallBack(OnSmeltExpNotEnough);
                }
                break;
            case EnumItemErr.ItemErr_CanNotOpenBoxFree:     //不能免费开箱子
                tipText = Common.GetText(9100058);
                break;
            case EnumItemErr.ItemErr_LevelNotEnough:     //等级不足9100046
                tipText = Common.GetText(9100046);
                break;
        }
        if (result == EnumItemErr.ItemErr_Success)
        {
        }
        else
        {
            if (!string.IsNullOrEmpty(tipText))
                SingletonObject<PopFrameMediator>.GetInst().SetPopFrameTips(tipText, frameType);
        }

    }

    public void OnSmeltExpNotEnough()
    {
    }

    public uint GetMaxSmeltExp(uint smeltLevel)
    {
        Dictionary<int, ForgeContent> dict = HolderManager.m_ForgeHolder.GetDict();
        int key = 1;
        foreach (KeyValuePair<int, ForgeContent> pair in dict)
        {
            if (smeltLevel >= pair.Value.SmeltLevel)
            {
                key = pair.Key;
            }
            else
            {
                break;
            }
        }
        return (uint)dict[key].NeedExp;
    }

    public uint GetSmeltNextLevel(uint smeltLevel)
    {
        Dictionary<int, ForgeContent> dict = HolderManager.m_ForgeHolder.GetDict();
        int key = 1;
        foreach (KeyValuePair<int, ForgeContent> pair in dict)
        {
            if (smeltLevel < pair.Value.SmeltLevel)
            {
                key = pair.Key;
                break;
            }
            else if (smeltLevel == pair.Value.SmeltLevel)
            {
                key = pair.Key;
            }
        }
        return (uint)dict[key].SmeltLevel;

    }

    public List<int> GetUpLevelUse(uint nowLevel)
    {
        Dictionary<int, ForgeContent> dict = HolderManager.m_ForgeHolder.GetDict();
        int key = 1;
        foreach (KeyValuePair<int, ForgeContent> pair in dict)
        {
            /*if (nowLevel < pair.Value.SmeltLevel)
            {
                key = pair.Key;
                break;
            }
            else */
            if (nowLevel == pair.Value.SmeltLevel/* && dict[key].SmeltLevel < pair.Value.SmeltLevel*/)
            {
                key = pair.Key;
            }
        }
        return dict[key].UpLevelUse;
    }

    public int CheckEquipEnchant(PackItemInfo info)
    {
        EquipContent equip = HolderManager.m_EquipHolder.GetStaticInfo(info.uiItemId);
        if (null == equip)
        {
            return -2;
        }
        if (info.uiFuMoLevel >= GetFuMoMaxLevel(equip))
        {
            return -1;
        }
        return 0;
    }

    public List<PackItemInfo> GetSortList()
    {
        if (comparerEquip == null)
        {
            comparerEquip = new IComparerPackItem();
        }
        ItemList.Sort(comparerEquip);
        return ItemList;
    }


    public List<PackItemInfo> GetTypeList(byte Type)
    {
        List<PackItemInfo> packlist = ItemList;
        List<PackItemInfo> needlist = new List<PackItemInfo>();
        for (int i = 0; i < packlist.Count; i++)
        {
            EquipContent equipInfo =
                       HolderManager.m_EquipHolder.GetStaticInfo(packlist[i].uiItemId);
            if (equipInfo == null)
            {
              
                continue;
            }
            if (Type == equipInfo.EquipType)
                needlist.Add(packlist[i]);
        }
        if (m_icgscomparerEquip == null)
        {
            m_icgscomparerEquip = new IComparerGS();
        }
        needlist.Sort(m_icgscomparerEquip);
        PackItemInfo prepack = new PackItemInfo();
        List<PackItemInfo> roleEquip = ItemManager.GetInst().GetRoleEquipList();
        if (roleEquip == null)
        {
          
            return needlist;
        }
        int type = 0;
        for (int i = 0; i < roleEquip.Count; i++)
        {
            type = roleEquip[i].uiIndex;
            if (type == Type)
            {
                prepack = roleEquip[i];
            }
        }

        for (int i = 0; i < needlist.Count; i++)
        {
            if (needlist[i].uiItemId == prepack.uiItemId && needlist[i].uiFuMoLevel == prepack.uiFuMoLevel && needlist[i].uiFuMoExp == prepack.uiFuMoExp)
            {
                needlist.Remove(needlist[i]);
                continue;
            }
            if (needlist.Count > 0 && i > 0)
            {
                if (needlist[i].uiItemId == needlist[i - 1].uiItemId && needlist[i].uiFuMoLevel == needlist[i - 1].uiFuMoLevel && needlist[i].uiFuMoExp == needlist[i - 1].uiFuMoExp)
                {
                    needlist.Remove(needlist[i]);
                    i--;
                }
            }
        }

        return needlist;
    }

    public bool AppearNewicon(byte x)
    {
        int count = 0;
        PackItemInfo packinfo = new PackItemInfo();
        CPlayer player = SingletonObject<CPlayer>.GetInst();
        if (player == null)
            return false;
        stPlayerInfo playerInfo = player.GetPlayerInfo();
        stHomeAvatarInfo avatarInfo = player.GetHomeAvatarInfo();
        List<PackItemInfo> prelist = GetTypeList(x);
        if (prelist == null)
            return false;
        if (prelist.Count > 0)                   //找可装备的战斗力最高的
        {
            for (int i = 0; i < prelist.Count; i++)
            {
                EquipContent equipInfo =
                   HolderManager.m_EquipHolder.GetStaticInfo((uint)prelist[i].uiItemId);
                if (equipInfo.UseLevel > avatarInfo.uiPlayerLevel)
                {
                    count++;
                    continue;
                }
                packinfo = prelist[i];
                break;
            }
        }
        else
            return false;
        List<PackItemInfo> roleEquip = ItemManager.GetInst().GetRoleEquipList();
        PackItemInfo equip = null;
        for (int i = 0; i < roleEquip.Count; i++)
        {
            if (roleEquip[i].uiIndex == (ushort)x)
            {
                equip = roleEquip[i];
                break;
            }
        }
        if (equip != null)
        {
            EquipContent equipInfo =
                   HolderManager.m_EquipHolder.GetStaticInfo((uint)equip.uiItemId);
            TechContent techInfo =
                   HolderManager.m_TechHolder.GetStaticInfo(equipInfo.TextID);
            EquipContent equipInfo1 =
                   HolderManager.m_EquipHolder.GetStaticInfo((uint)packinfo.uiItemId);
            if (equipInfo1 == null)
                return false;
            TechContent techInfo1 =
                 HolderManager.m_TechHolder.GetStaticInfo(equipInfo1.TextID);
            if (Common.GetGSValue(techInfo1) > Common.GetGSValue(techInfo))
            {
                SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = true;
                return true;
            }
            return false;
        }
        else
        {
            if (prelist.Count - count > 0)
            {
                SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = true;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    public void SetEquipNewTip()
    {
        CPlayer player = SingletonObject<CPlayer>.GetInst();
        if (player == null)
        {
            return;
        }
        bool newFlag = false;
        List<PackItemInfo> roleEquip = ItemManager.GetInst().GetRoleEquipList();
        int[] roleEquipGs = new int[] { 0, 0, 0, 0 };
        byte startType = 2;
        byte endType = 5;
        if (null != roleEquip)
        {//获取身上装备的战斗力
            for (int i = 0, icount = roleEquip.Count; i < icount; ++i)
            {
                EquipContent equipLoader = HolderManager.m_EquipHolder.GetStaticInfo(roleEquip[i].uiItemId);
                if (null == equipLoader)
                {
                    continue;
                }
                if (equipLoader.EquipType >= startType && equipLoader.EquipType <= endType)
                {
                    roleEquipGs[equipLoader.EquipType - startType] = GetGsValue(roleEquip[i]);
                }
            }
        }
        stHomeAvatarInfo avatarInfo = player.GetHomeAvatarInfo();
        for (int i = 0, icount = ItemList.Count; i < icount; i++)
        {//这里面会有角色穿的装备
            EquipContent equipInfo = HolderManager.m_EquipHolder.GetStaticInfo(ItemList[i].uiItemId);
            if (equipInfo == null)
            {
                continue;
            }
            if (equipInfo.UseLevel > avatarInfo.uiPlayerLevel)
            {
                continue;
            }
            if (equipInfo.EquipType >= startType && equipInfo.EquipType <= endType)
            {
                int tmpGs = GetGsValue(ItemList[i]);
                if (tmpGs > roleEquipGs[equipInfo.EquipType - startType])
                {//战力比自身的高
                    newFlag = true;
                    break;
                }
            }

        }
        SingletonObject<HomeMainMediator>.GetInst().NewEquipTips = newFlag;
    }

    /// <summary>
    /// 获取装备的战斗力
    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    public static int GetGsValue(PackItemInfo info)
    {
        if (null == info)
        {
           
            return 0;
        }
        EquipContent equipLoader = HolderManager.m_EquipHolder.GetStaticInfo(info.uiItemId);
        if (null == equipLoader)
        {
            MyLog.LogError("装备表不存在装备id:" + info.uiItemId);
            return 0;
        }
        TechContent techInfo = HolderManager.m_TechHolder.GetStaticInfo(equipLoader.TextID);
        if (null == techInfo)
        {
          
            return 0;
        }
        float gsValue = Common.GetGSValue(techInfo);
        TechContent enchantLoader = HolderManager.m_TechHolder.GetStaticInfo(SingletonObject<EquipItemManager>.GetInst().GetEnchantProperetyID(equipLoader,(int)info.uiFuMoLevel));
        if (null != enchantLoader)
        {
            gsValue += Common.GetGSValue(enchantLoader);
        }
        return (int)gsValue;
    }
    /// <summary>
    /// 获取道具提供的经验
    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    public static uint GetPackItemLendExp(PackItemInfo info)
    {
        uint ufirst = info.uiItemId / 10000000;
        uint lendExp = 0;
        if (3 == ufirst)        //装备
        {
            EquipContent content = HolderManager.m_EquipHolder.GetStaticInfo(info.uiItemId);
            lendExp = (uint)SingletonObject<EquipItemManager>.GetInst().GetLendEnchantExp(content, info.uiFuMoLevel, (int)info.uiFuMoExp);
        }
        else
        {

            ItemContent content = HolderManager.m_ItemHolder.GetStaticInfo(info.uiItemId);
            if (content != null)
            {

                if (content.ScriptArg.Count > 0)
                {

                    if (content.ScriptArg[0].list.Count > 0)
                    {

                        lendExp =(uint) content.ScriptArg[0].list[0];

                    }
                    else
                    {
                        MyLog.LogError("道具提供的附魔经验配置有问题 ID:" + info.uiItemId);
                    }
                }
                else
                {
                    MyLog.LogError("道具提供的附魔经验配置有问题 ID:" + info.uiItemId);
                }
            }
        }
        return lendExp;
    }
    /// <summary>
    /// 判断附魔是否开启
    /// </summary>
    /// <returns></returns>
    public static bool IsFuMoOpen(bool showTips = false)
    {
        if (Time.time - sCheckFuMoOpenTime > 2)
        {
            OpenContent open = HolderManager.m_OpenHolder.GetStaticInfo(20510);
            if (null != open)
            {
                sCheckFuMoOpenTime = Time.time;
                if (BattlePveManager.GetInst().CheckAllowBattlePveMap((uint)open.ConditionId, showTips))
                {
                    sFuMoOpenFlag = true;
                }
                else
                {
                    sFuMoOpenFlag = false;
                }
            }
            else
            {
                sFuMoOpenFlag = true;
            }
        }
        return sFuMoOpenFlag;
    }
    private static float CalculateAttributeValue(PackItemInfo equipInfo, PropretyType proprety, EquipContent equipLoader, TechContent techInfo, TechContent enchantLoader)
    {
        if (null == equipInfo)
        {
         
            return 0;
        }
        if (null == equipLoader)
        {
            equipLoader = HolderManager.m_EquipHolder.GetStaticInfo(equipInfo.uiItemId);
            if (null == equipLoader)
            {
                MyLog.LogError("装备表不存在装备id:" + equipInfo.uiItemId);
                return 0;
            }
        }
        if (null == techInfo)
        {
            techInfo = HolderManager.m_TechHolder.GetStaticInfo(equipLoader.TextID);
            if (null == techInfo)
            {
              
                return 0;
            }
        }
        if (null == enchantLoader)
        {
            enchantLoader = HolderManager.m_TechHolder.GetStaticInfo(SingletonObject<EquipItemManager>.GetInst().GetEnchantProperetyID(equipLoader,(int)equipInfo.uiFuMoLevel));
        }
        float value = 0;
        switch (proprety)
        {
            case PropretyType.Proprety_Type_Live:
                value = Common.CalculateAttributeValue(techInfo.Livevaluemax);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Livevaluemax);
                }
                break;
            case PropretyType.Proprety_Type_Jinli:
                value = Common.CalculateAttributeValue(techInfo.Jinlivaluemax);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Jinlivaluemax);
                }
                break;
            case PropretyType.Proprety_Type_Attack:
                value = Common.CalculateAttributeValue(techInfo.Attackvaluemax);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Attackvaluemax);
                }
                break;
            case PropretyType.Proprety_Type_Fangyu:
                value = Common.CalculateAttributeValue(techInfo.Fangyuvalue);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Fangyuvalue);
                }
                break;
            case PropretyType.Proprety_Type_Mingzhong:
                value = Common.CalculateAttributeValue(techInfo.Mingzhongvalue);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Mingzhongvalue);
                }
                break;
            case PropretyType.Proprety_Type_Shanbi:
                value = Common.CalculateAttributeValue(techInfo.Shanbivalue);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Shanbivalue);
                }
                break;
            case PropretyType.Proprety_Type_Baoji:
                value = Common.CalculateAttributeValue(techInfo.Baoji);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Baoji);
                }
                break;
            case PropretyType.Proprety_Type_Movespeed:
                value = Common.CalculateAttributeValue(techInfo.Movespeed);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Movespeed);
                }
                break;
            case PropretyType.Proprety_Type_Shengminghuifu:
                value = Common.CalculateAttributeValue(techInfo.Shengminghuifu);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Shengminghuifu);
                }
                break;
            case PropretyType.Proprety_Type_Baojishanghai:
                value = Common.CalculateAttributeValue(techInfo.Baojishanghai);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Baojishanghai);
                }
                break;
            case PropretyType.Proprety_Type_Shanghaijianmian:
                value = Common.CalculateAttributeValue(techInfo.Shanghaijianmian);
                if (null != enchantLoader)
                {
                    value += Common.CalculateAttributeValue(enchantLoader.Shanghaijianmian);
                }
                break;
        }
        return value;
    }
    /// <summary>
    /// 获得装备的某条属性具体的值
    /// </summary>
    /// <param name="equipInfo"></param>
    /// <param name="proprety"></param>
    /// <returns></returns>
    public static float CalculateAttributeValue(PackItemInfo equipInfo, PropretyType proprety)
    {
        return CalculateAttributeValue(equipInfo, proprety, null, null, null);
    }
    /// <summary>
    /// 获取一件装备的所有属性
    /// </summary>
    /// <param name="equipInfo"></param>
    /// <returns></returns>
    public static EquipProprety GetAllAttributeValue(PackItemInfo equipInfo)
    {
        EquipProprety proprety = new EquipProprety();
        if (null == equipInfo)
        {
           
            return proprety;
        }
        EquipContent equipLoader = HolderManager.m_EquipHolder.GetStaticInfo(equipInfo.uiItemId);
        if (null == equipLoader)
        {
            MyLog.LogError("装备表不存在装备id:" + equipInfo.uiItemId);
            return proprety;
        }
        TechContent techInfo = HolderManager.m_TechHolder.GetStaticInfo(equipLoader.TextID);
        if (null == techInfo)
        {
           
            return proprety;
        }
        TechContent enchantLoader = HolderManager.m_TechHolder.GetStaticInfo(SingletonObject<EquipItemManager>.GetInst().GetEnchantProperetyID(equipLoader,(int)equipInfo.uiFuMoLevel));

        for (int i = (int)PropretyType.Proprety_Type_Live, size = (int)PropretyType.Proprety_Type_End; i < size; ++i)
        {
            PropretyType key = (PropretyType)i;
            proprety.Add(key, CalculateAttributeValue(equipInfo, key, equipLoader, techInfo, enchantLoader));
        }
        return proprety;
    }
    

    public int GetFuMoMaxLevel(EquipContent content)
    {
        if (content.EnchantProprety.Count == 0)
        {
            return 0;
        }
        return content.EnchantProprety.Count - 1;
    }

    /// <summary>
    /// 返回值为当前等级升级所需经验和属性id
    /// </summary>
    /// <param name="level"></param>
    /// <returns></returns>
    public List<int> GetEquipEnchantProprety(EquipContent equipInfo, int level)
    {
        List<int> ptylist = new List<int>();
        if (level < 0 || level >= equipInfo.EnchantProprety.Count)
        {
            ptylist.Add(0);
            ptylist.Add(0);
            ptylist.Add(0);
        }
        else
        {
            for (int i = 0, size = equipInfo.EnchantProprety[level].list.Count; i < size; ++i)
            {
                ptylist.Add(equipInfo.EnchantProprety[level].list[i]);
            }
            for (int i = ptylist.Count; i < 3; ++i)
            {
                ptylist.Add(0);
            }
        }
        return ptylist;
    }
    //获取该等级升级所需经验
    public int GetEnchantNeedExp(EquipContent equipInfo,int level)
    {
        return GetEquipEnchantProprety(equipInfo,level)[1];
    }
    //获取该等级的附魔属性id
    public int GetEnchantProperetyID(EquipContent equipInfo,int level)
    {
        return GetEquipEnchantProprety(equipInfo,level)[2];
    }

    public int GetLendEnchantExp(EquipContent content, uint level, int fumoExp)
    {
        for (int i = 0; i < level; ++i)
        {
            fumoExp += GetEnchantNeedExp(content,i);
        }
        return content.LendEnchantExp + (int)(fumoExp * 0.25f);
    }
    /// <summary>
    /// 判断装备是否能到满级
    /// </summary>
    /// <param name="level">等级</param>
    /// <param name="addExp">自身经验加上材料提供经验</param>
    /// <returns>true表示最高等级</returns>
    public bool IsMaxLevel(EquipContent content, int level, int addExp, ref int needExp)
    {
        int maxLevel = GetFuMoMaxLevel(content);
        if (level >= maxLevel)
        {
            return true;
        }
        needExp = 0;
        for (int i = (int)level; i < maxLevel; ++i)
        {
            needExp += GetEnchantNeedExp(content,i);
        }
        if (needExp <= addExp)
        {
            return true;
        }
        return false;
    }
    public bool IsMaxLevel(EquipContent content, int level, int addExp = 0)
    {
        int needExp = 0;
        return IsMaxLevel(content,level, addExp, ref needExp);
    }
    /// <summary>
    /// 获取可以达到的等级
    /// </summary>
    /// <param name="level"></param>
    /// <param name="addExp"></param>
    /// <returns></returns>
    public int GetToLevel(EquipContent content,int level, int addExp, ref int laveExp)
    {
        int maxLevel = GetFuMoMaxLevel(content);
        if (level >= maxLevel)
        {
            return maxLevel;
        }
        for (int i = (int)level; i < maxLevel; ++i)
        {
            if (addExp >= GetEnchantNeedExp(content,i))
            {
                ++level;
                if (level < maxLevel)
                {
                    addExp -= GetEnchantNeedExp(content,i);
                }
                else
                {
                    --level;
                    break;
                }
            }
            else
            {
                break;
            }
        }
        laveExp = addExp;
        return level;
    }


    private static Dictionary<string, EquipContent> m_dropEquipDict = new Dictionary<string, EquipContent>();

    public static EquipContent GetLoaderByID(string sName)
    {
        int id = MyConvert_Convert.ToInt32(sName);
        return HolderManager.m_EquipHolder.GetStaticInfo(id);
        
    }

    //获取装备类型背景精灵名，（暂时先放这里好统一用）
    public string QualityBGName(EquipContent content)
    {
        string name = string.Empty;

        switch (content.Quality)
        {
            case 1:
                name = "frames_green";
                break;
            case 2:
                name = "frames_white";
                break;
            case 3:
                name = "frames_purple";
                break;
            case 4:
                name = "frames_orange";
                break;
        }
        return name;
    }

    //获取装备品质名称，（暂时先放这里好统一用）
    public string QualityLevelName(EquipContent content)
    {
        string name = string.Empty;
        int textID = 9910812;
        name = Common.GetText((uint)(textID + content.Quality));
        return name;
    }
    //获取装备品质名称的颜色值，（暂时先放这里好统一用）
    public Color GetEquipQualityColor(EquipContent content)
    {
        Color cQuality = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        switch (content.Quality)
        {
            case 1:
                cQuality = new Color(144.0f, 236.0f, 62.0f, 1.0f);
                break;
            case 2:
                cQuality = new Color(86.0f, 221.0f, 255.0f, 1.0f);
                break;
            case 3:
                cQuality = new Color(254.0f, 240.0f, 10.0f, 1.0f);
                break;
            case 4:
                cQuality = new Color(255.0f, 126.0f, 0.0f, 1.0f);
                break;
        }
        return cQuality;
    }


   
}

public class IComparerPackItem : IComparer<PackItemInfo>
{
    private EquipContent equip1;
    private EquipContent equip2;
    private TechContent techInfo1;
    private TechContent techInfo2;
    private byte equipType1;
    private byte equipType2;

    public int Compare(PackItemInfo item1, PackItemInfo item2)
    {
        equip1 = HolderManager.m_EquipHolder.GetStaticInfo(item1.uiItemId);
        equip2 = HolderManager.m_EquipHolder.GetStaticInfo(item2.uiItemId);
        if (equip1 == null || equip2 == null)
        {
            return 0;
        }
        //equipType1 = TransformEquipType((eChaarcterEquipType)equip1.GetEquipType());
        //equipType2 = TransformEquipType((eChaarcterEquipType)equip2.GetEquipType());
        //if (equip1.GetQuality() < equip2.GetQuality())
        //{
        //    return 1;
        //}
        //else if (equip1.GetQuality() == equip2.GetQuality())
        {
            techInfo1 = HolderManager.m_TechHolder.GetStaticInfo(equip1.TextID);
            techInfo2 = HolderManager.m_TechHolder.GetStaticInfo(equip2.TextID);
            if (Common.GetGSValue(techInfo1) < Common.GetGSValue(techInfo2))
            {
                return 1;
            }
            else if (Common.GetGSValue(techInfo1) == Common.GetGSValue(techInfo2))
            {
                if (equipType1 > equipType2)
                {
                    return 1;
                }
                else if (equipType1 == equipType2)
                {
                    if (equip1.Key > equip2.Key)
                    {
                        return 1;
                    }
                    else if (equip1.Key == equip2.Key)
                    {
                        if (item1.uiItemNum < item2.uiItemNum)
                        {
                            return 1;
                        }
                        else if (item1.uiItemNum == item2.uiItemNum)
                        {
                            return 0;
                        }
                        else
                        {
                            return -1;
                        }
                    }

                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                //if (isfirst == 0)
                return -1;
                //return isfirst;
            }
        }
        //else
        //{
        //    return -1;
        //}
    }

    public byte TransformEquipType(eChaarcterEquipType type)
    {
        if (type == eChaarcterEquipType.Headwear)
        {
            return (byte)SortEquipType.HeadwearType;
        }
        else if (type == eChaarcterEquipType.Necklace)
        {
            return (byte)SortEquipType.NecklaceType;
        }
        else if (type == eChaarcterEquipType.Ring)
        {
            return (byte)SortEquipType.RingType;
        }
        else
        {
            return (byte)SortEquipType.ShoeType;
        }
    }

    private enum SortEquipType
    {
        HeadwearType,                                   //头饰
        NecklaceType,                                   //项链
        RingType,                                       //戒指
        ShoeType,                                       //鞋子
    }
}

public class IComparerGS : IComparer<PackItemInfo>
{
    private EquipContent equip1;
    private EquipContent equip2;
    private EquipContent equip3;
    private TechContent techInfo1;
    private TechContent techInfo2;
    private TechContent techInfo3;
    private float GSnum;
    public int Compare(PackItemInfo item1, PackItemInfo item2)
    {
        equip1 = HolderManager.m_EquipHolder.GetStaticInfo(item1.uiItemId);
        equip2 = HolderManager.m_EquipHolder.GetStaticInfo(item2.uiItemId);
        uint equipId = 0;
        if (null != SingletonObject<ChooseEquipMediator>.GetInst().PreEquipInfo)
        {
            equipId = SingletonObject<ChooseEquipMediator>.GetInst().PreEquipInfo.uiItemId;
        }
        if (equipId == 0)
        {
            GSnum = 0;
        }
        else
        {
            uint equipId1 = 0;
            if (null != SingletonObject<ChooseEquipMediator>.GetInst().PreEquipInfo)
            {
                equipId1 = SingletonObject<ChooseEquipMediator>.GetInst().PreEquipInfo.uiItemId;
            }
            equip3 = HolderManager.m_EquipHolder.GetStaticInfo(equipId1);
            techInfo3 = HolderManager.m_TechHolder.GetStaticInfo(equip3.TextID);
            GSnum = Common.GetGSValue(techInfo3);
        }
        techInfo1 = HolderManager.m_TechHolder.GetStaticInfo(equip1.TextID);
        techInfo2 = HolderManager.m_TechHolder.GetStaticInfo(equip2.TextID);
        float fumo1Gs = 0;
        float fumo2Gs = 0;
        TechContent fumo1 = HolderManager.m_TechHolder.GetStaticInfo(SingletonObject<EquipItemManager>.GetInst().GetEnchantProperetyID(equip1, (int)item1.uiFuMoLevel));
        if (fumo1 != null)
        {
            fumo1Gs = Common.GetGSValue(fumo1);
            
        }
        TechContent fumo2 = HolderManager.m_TechHolder.GetStaticInfo(SingletonObject<EquipItemManager>.GetInst().GetEnchantProperetyID(equip2, (int)item2.uiFuMoLevel));
        if (fumo2 != null)
        {
            
            fumo2Gs = Common.GetGSValue(fumo2);
        }
       
        CPlayer player = SingletonObject<CPlayer>.GetInst();
        if (player == null)
        {
          
        }
        stPlayerInfo playerInfo = player.GetPlayerInfo();
        stHomeAvatarInfo avatarInfo = player.GetHomeAvatarInfo();
        //int isfirst;
        if (equip1 == null || equip2 == null)
        {
            return 0;
        }
        

        if (equip1.UseLevel > avatarInfo.uiPlayerLevel && equip2.UseLevel <= avatarInfo.uiPlayerLevel &&
            Common.GetGSValue(techInfo2)+fumo2Gs > GSnum)
        {
            return 1;
        }
        if (equip2.UseLevel > avatarInfo.uiPlayerLevel && equip1.UseLevel <= avatarInfo.uiPlayerLevel &&
            Common.GetGSValue(techInfo1) + fumo1Gs > GSnum)
        {
            return -1;
        }

        //if (equip1.GetQuality() < equip2.GetQuality())
        //{
        //    isfirst = 1;
        //}
        //else if (equip1.GetQuality() == equip2.GetQuality())
        //{

        //    isfirst = 0;
        //}
        //else
        //{
        //    isfirst = -1;
        //}
        if (Common.GetGSValue(techInfo1) +fumo1Gs < Common.GetGSValue(techInfo2)+fumo2Gs)
        {
            //if (isfirst == 0)
            return 1;
            //return isfirst;
        }
        else if (Common.GetGSValue(techInfo1) + fumo1Gs == Common.GetGSValue(techInfo2) + fumo2Gs)
        {
            //if (isfirst==0)
            return 0;
            //return isfirst;
        }
        else
        {
            //if (isfirst == 0)
            return -1;
            //return isfirst;
        }
    }
}