﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;

public class RoleEquipManager : BaseItem {

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
    }

    public bool IsSameEquip(PackItemInfo itemInfo)
    {
        bool isSame = false;
        for (int i = 0; i < ItemList.Count;i++ )
        {

            if (itemInfo.uiItemId == ItemList[i].uiItemId && itemInfo.uiFuMoLevel == ItemList[i].uiFuMoLevel&&itemInfo.uiFuMoExp == ItemList[i].uiFuMoExp)
            {
                    isSame = true;
            }
        }
        return isSame;
    }

    public override void UpdataList(PackItemInfo itemInfo)
    {
        //玩家身上的装备不走普通刷新流程
        base.UpdataList(itemInfo);
    }

    public bool CompareGSUpgrade(uint equipId)
    {
        bool upgrade = false;
        EquipContent equipInfo = HolderManager.m_EquipHolder.GetStaticInfo(equipId);
        
        if (equipInfo !=null)
        {
            //职业限制，只针对 衣服武器，不可装备，所以不做比较
            if (equipInfo.JobLimit ==0)
            {
                TechContent techInfo =HolderManager.m_TechHolder.GetStaticInfo(equipInfo.TextID);
                if (techInfo == null)
                {
                    return upgrade;
                }
                float gsEquipValue = (int)Common.GetGSValue(techInfo);
                byte type = equipInfo.EquipType;
                if (type == 0 || type == 1)
                {
                    return upgrade;
                }
                else
                {
                    int index =0;
                    bool bHave =CheckHaveEquip(type,out index);
                    EquipContent roleEquip = HolderManager.m_EquipHolder.GetStaticInfo(ItemList[index].uiItemId);
                    
                    if (roleEquip == null)
                    {
                        upgrade = false;
                        return upgrade;
                    }
                    stHomeAvatarInfo playerInfo = SingletonObject<CPlayer>.GetInst().GetHomeAvatarInfo();
                    ushort playerLevel = playerInfo.uiPlayerLevel;
                    if (!bHave) //还无装备
                    {
                        upgrade = true;
                        return upgrade;

                    }
                    else
                    {
                        

                        TechContent roleTechInfo = HolderManager.m_TechHolder.GetStaticInfo(roleEquip.TextID);
                        if (roleTechInfo == null)
                        {
                           return upgrade =false;
                        }
                        float gsRoleValue = (int)Common.GetGSValue(roleTechInfo);
                        if (gsEquipValue >gsRoleValue)
                        {

                            upgrade = true;
                            return upgrade;

                        }
                    }

                }

            }
        }
        return upgrade;
    }

    private bool CheckHaveEquip(byte type,out int index)
    {
        bool have = false;
        index = 0;
        for (int i = 0;i< ItemList.Count;i++ )
        {
            if (ItemList[i].uiIndex ==type)
            {
                index = i;
                have = true;
                break;
            }
        }
        return have;
    }
        #region 请求消息的数据处理

        #endregion


        #region 注册返回消息的回调处理

        #endregion
}
