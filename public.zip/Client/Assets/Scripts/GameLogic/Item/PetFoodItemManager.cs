﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;

public class PetFoodItemManager : BaseItem {

    PetFoodComparison foodComparison;

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
    }
    public override void UpdataList(PackItemInfo itemInfo)
    {
        base.UpdataList(itemInfo);
    }
        #region 请求消息的数据处理

        #endregion


        #region 注册返回消息的回调处理

        #endregion

    public List<PackItemInfo> GetSortList()
    {
        List<PackItemInfo> foodlist = ItemList;
        if (foodComparison == null)
        {
            foodComparison = new PetFoodComparison();
        }
        foodlist.Sort(foodComparison);

        //foodlist.Sort(delegate(PackItemInfo a, PackItemInfo b) { return b.uiItemId.CompareTo(a.uiItemId); });
        return foodlist;

    }
}


public class PetFoodComparison: IComparer<PackItemInfo>
{
    private ItemContent food1;
    private ItemContent food2;

    private int foodTime1 = 0;
    private int foodTime2 = 0;

    public int Compare(PackItemInfo item1, PackItemInfo item2)
    {

        if (item1 == null || item2 == null)
        {
            return 0;
        }
        foodTime1 = item1.iStartTime -item1.iEndTime ;
        foodTime2 =item2.iStartTime  -item2.iEndTime;

        if (foodTime1>foodTime2)
        {
            return 1;
        }
        else if (foodTime1 == foodTime2)
        {
            if (item1.uiItemId > item2.uiItemId)
            {
                return 1;
            }
            else if (item1.uiItemId == item2.uiItemId)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
        /*
        if (item1.iStartTime == 0 && item1.iEndTime ==0)
        {
            if (item2.iStartTime == 0 && item2.iEndTime == 0)
            {
                if (item1.uiItemId > item2.uiItemId)
                {
                    return -1;
                }
                else if (item1.uiItemId == item2.uiItemId)
                {
                    return 0;
                }
                else 
                {
                    return 1;
                }
            }
            else
            {
                return 1;

            }
        }
        else
        {
            if (item2.iStartTime == 0 && item2.iEndTime == 0)
            {
                return -1;
            }
            else
            {
                if (item1.iEndTime >item2.iEndTime)
                {
                    return 1;
                }
                else if (item1.iEndTime == item2.iEndTime)
                {
                    if (item1.uiItemId >item2.uiItemId)
                    {
                        return 1;
                    }
                    else if (item1.uiItemId ==item2.uiItemId)
                    {
                        return 0;
                    }
                    else 
                    {
                        return -1;
                    }
                }
                else 
                {
                    if (item1.uiItemId > item2.uiItemId)
                    {
                        return 1;
                    }
                    else if (item1.uiItemId == item2.uiItemId)
                    {
                        return 0;
                    }
                    else 
                    {
                        return -1;
                    }
                }

            }
        }

        if (item2.iStartTime == 0 && item2.iEndTime == 0)
        {
            if (item1.iStartTime == 0 && item1.iEndTime == 0)
            {
                if (item1.uiItemId > item2.uiItemId)
                {
                    return 1;
                }
                else if (item1.uiItemId == item2.uiItemId)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                return -1;

            }
        }
        else
        {
            if (item1.iStartTime == 0 && item1.iEndTime == 0)
            {
                return 1;
            }
            else
            {
                if (item1.iEndTime > item2.iEndTime)
                {
                    return 1;
                }
                else if (item1.iEndTime == item2.iEndTime)
                {
                    if (item1.uiItemId > item2.uiItemId)
                    {
                        return 1;
                    }
                    else if (item1.uiItemId == item2.uiItemId)
                    {
                        return 0;
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    if (item1.uiItemId > item2.uiItemId)
                    {
                        return 1;
                    }
                    else if (item1.uiItemId == item2.uiItemId)
                    {
                        return 0;
                    }
                    else
                    {
                        return -1;
                    }
                }

            }
        }
        */
    }
}