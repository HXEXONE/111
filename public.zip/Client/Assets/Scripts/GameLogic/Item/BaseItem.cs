﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;


public class BaseItem  {

    protected List<PackItemInfo> ItemList = new List<PackItemInfo>();
    protected Dictionary<ushort, PackItemInfo> ItemIndex = new Dictionary<ushort, PackItemInfo>();

    private PackMediator packMediator;

    public virtual void RegisteMessages(NetworkClient pClient)
    {
        if (packMediator == null)
        {
            packMediator = SingletonObject<PackMediator>.GetInst();
        }
    }


    protected void Remove(PackItemInfo item)
    {
        if (item.uiIndex == 0 && item.uiItemId == 0)
        {
            return;
        }
        uint oldItemId = item.uiItemId;
        if (ItemIndex.ContainsKey(item.uiIndex))
        {
            oldItemId = ItemIndex[item.uiIndex].uiItemId;
            ItemList.Remove(ItemIndex[item.uiIndex]);
            ItemIndex.Remove(item.uiIndex);
        }
        ItemManager.GetInst().Remove(item, oldItemId);
    }
    /// <summary>
    /// 更新或者增加道具
    /// </summary>
    /// <param name="item"></param>
    protected void Update(PackItemInfo item)
    {
        if (item.uiIndex == 0 && item.uiItemId == 0)
        {
            return;
        }
        uint oldItemId = item.uiItemId;
        if (ItemIndex.ContainsKey(item.uiIndex))
        {
            oldItemId = ItemIndex[item.uiIndex].uiItemId;
            int index = ItemList.IndexOf(ItemIndex[item.uiIndex]);
            ItemIndex[item.uiIndex] = item;
            ItemList[index] = item;
        }
        else
        {
            ItemList.Add(item);
            ItemIndex.Add(item.uiIndex, item);
        }
        ItemManager.GetInst().Update(item, oldItemId);
    }


    public void RepleaceItem(PackItemInfo item ,bool bAdd =false)
    {
        bool isNew = true;
        if (item.uiIndex == 0 && item.uiItemId == 0)
        {
            return;
        }
        if (!bAdd)
        {
            isNew = false;
        }
        else
        {
            List<ushort> indexList = ItemManager.GetInst().GetAllItemIndexForID(item.uiItemId);
            for (int i = 0, icount = indexList.Count; i < icount; ++i)
            {
                ushort indexOf = indexList[i];
                if (ItemIndex.ContainsKey(indexOf))
                {
                    if (ItemIndex[indexOf].uiFuMoLevel == item.uiFuMoLevel && ItemIndex[indexOf].uiFuMoExp == item.uiFuMoExp)
                    {
                        isNew = false;
                        break;
                    }
                }
            }
        }

        
        if (isNew)
        {
            if (!packMediator.newItemDict.ContainsKey(item.uiItemId))
            {
                packMediator.newItemDict.Add(item.uiItemId, isNew);
            }
        }

        UpdataList(item);
    }

    public void Clear()
    {
        ItemList.Clear();
        ItemIndex.Clear();
    }
    /// <summary>
    /// 通过格子号获取物品信息
    /// </summary>
    /// <param name="uiIndex"></param>
    /// <returns></returns>
    public PackItemInfo GetItemInfo(ushort uiIndex)
    {
        if (ItemIndex.ContainsKey(uiIndex))
        {
            return ItemIndex[uiIndex];
        }
        return null;
    }

    public ushort GetIndex(uint itemID,uint fumolevel   =   0,uint fumoExp =0)
    {
        ushort uIndex = 0;
        List<ushort> list = ItemManager.GetInst().GetAllItemIndexForID(itemID);
        for (int i = 0, count = list.Count; i < count; i++)
        {
            if (ItemIndex.ContainsKey(list[i]))
            {
                PackItemInfo item = ItemIndex[list[i]];
                if (item.uiItemId == itemID && item.uiFuMoLevel == fumolevel && item.uiFuMoExp == fumoExp)
                {
                    uIndex = ItemIndex[list[i]].uiIndex;
                    break;
                }
            }
        }
        return uIndex;
    }

    public PackItemInfo GetPackItemToID(uint itemID, uint fumolevel = 0, uint fumoExp = 0)
    {
        PackItemInfo itemInfo =null;
        List<ushort> list = ItemManager.GetInst().GetAllItemIndexForID(itemID);
        for (int i = 0, count = list.Count; i < count; i++)
        {
            if (ItemIndex.ContainsKey(list[i]))
            {
                PackItemInfo item = ItemIndex[list[i]];
                if (item.uiItemId == itemID && item.uiFuMoLevel == fumolevel && item.uiFuMoExp == fumoExp)
                {
                    itemInfo = ItemIndex[list[i]];
                    break;
                }
            }
        }
        return itemInfo;
    }


    //public PackItemInfo GetPackItemToIndex(ushort itemIndex)
    //{
    //    PackItemInfo itemInfo = null;
    //    for (int i = 0, count = ItemList.Count; i < count; i++)
    //    {
    //        if (ItemList[i].uiItemId == itemIndex)
    //        {
    //            itemInfo = ItemList[i];
    //            break;
    //        }
    //    }
    //    return itemInfo;
    //}

    public virtual void UpdataList(PackItemInfo itemInfo)
    {
        if (itemInfo.uiIndex == 0 && itemInfo.uiItemId == 0)
        {
            return;
        }
        
        if (ItemIndex.ContainsKey(itemInfo.uiIndex))
        {
            if (itemInfo.uiItemId == 0 || itemInfo.uiItemNum == 0)
            {
                Remove(itemInfo);
            }
            else
            {
                Update(itemInfo);
            }
        }
        else
        {
            if (itemInfo.uiItemId != DEFINE.ITEM_GOLD && itemInfo.uiItemId != DEFINE.PLUNDER_ID )
            {
                Update(itemInfo);
            }
        }
    }


    public virtual void UpdateList(List<PackItemInfo> itemInfo)
    {

    }

    public List<PackItemInfo> GetItemList()
    {
        return ItemList;
    }

}
