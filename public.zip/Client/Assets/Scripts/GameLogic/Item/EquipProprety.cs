﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EquipProprety
{
    private Dictionary<PropretyType, float> mPropretyDict = null;

    public EquipProprety()
    {
        mPropretyDict = new Dictionary<PropretyType, float>();
    }

    public float this[PropretyType key]
    {
        get 
        { 
            if (mPropretyDict.ContainsKey(key))
            {
                return mPropretyDict[key];
            }
            return 0;
        }
        set 
        { 
            if (mPropretyDict.ContainsKey(key))
            {
                mPropretyDict[key] = value;
            }
            else
            {
                mPropretyDict.Add(key, value);
            }
        }
    }

    public void Add(PropretyType key, float value)
    {
        if (mPropretyDict.ContainsKey(key))
        {
            mPropretyDict[key] += value;
        }
        else
        {
            mPropretyDict.Add(key, value);
        }
    }

    public bool Remove(PropretyType key)
    {
        return mPropretyDict.Remove(key);
    }

    public void Add(params EquipProprety[] proprety)
    {
        if (null != proprety)
        {
            for (int i = 0, size = proprety.Length; i < size; ++i)
            {
                for (int j = (int)PropretyType.Proprety_Type_Live, size1 = (int)PropretyType.Proprety_Type_End; j < size1; ++j)
                {
                    PropretyType key = (PropretyType)j;
                    Add(key, proprety[i][key]);
                }
            }
        }
    }

}