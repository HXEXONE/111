﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;


public class MountFoodItemManager : BaseItem {

    PetFoodComparison foodComparison;

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
    }
    public override void UpdataList(PackItemInfo itemInfo)
    {
        base.UpdataList(itemInfo);
    }
        #region 请求消息的数据处理

        #endregion


        #region 注册返回消息的回调处理

        #endregion


    public List<PackItemInfo> GetSortList()
    {
        List<PackItemInfo> foodlist = ItemList;
        if (foodComparison == null)
        {
            foodComparison = new PetFoodComparison();
        }
        foodlist.Sort(foodComparison);

        //foodlist.Sort(delegate(PackItemInfo a, PackItemInfo b) { return b.uiItemId.CompareTo(a.uiItemId); });
        return foodlist;

    }
}
