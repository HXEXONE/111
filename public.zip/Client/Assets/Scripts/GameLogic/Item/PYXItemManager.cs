﻿using UnityEngine;
using System.Collections;
using Network;
using Protocol;
using System.IO;
using System.Collections.Generic;

public class CReliceHoleInfo
{
    public ushort uiType;      //宝石孔类型
    public ushort uiLevel;    //当前宝石孔等级
    public uint uiCurExp;    //经验
}

public class CReliceInfo
{
    public uint uiReliceId;                                           //圣器Id
    public List<CReliceHoleInfo> holeList = new List<CReliceHoleInfo>();    //已经开启的宝石孔
    public byte bActiveAttr;                                          //是否激活隐藏属性

    public CReliceInfo Clone()
    {
        CReliceInfo mCReliceInfo = new CReliceInfo();
        mCReliceInfo.uiReliceId = this.uiReliceId;
        mCReliceInfo.bActiveAttr = this.bActiveAttr;
        mCReliceInfo.holeList = new List<CReliceHoleInfo>();
        for (int i = 0, j = this.holeList.Count; i < j; i++)
        {
            CReliceHoleInfo mCReliceHoleInfo = new CReliceHoleInfo();
            mCReliceHoleInfo.uiType = this.holeList[i].uiType;
            mCReliceHoleInfo.uiLevel = this.holeList[i].uiLevel;
            mCReliceHoleInfo.uiCurExp = this.holeList[i].uiCurExp;
            mCReliceInfo.holeList.Add(mCReliceHoleInfo);
        }
        return mCReliceInfo;
    }
}

public class PYXItemManager : BaseItem {

    private Dictionary<uint, CReliceInfo> myReliveInfo = new Dictionary<uint, CReliceInfo>();

    public const uint BuleGemId = 44000201;
    public const uint GreenGemId = 44000301;
    public const uint RedGemId = 44000101;

    private List<uint> canUpLevelList = new List<uint>();

    public override void RegisteMessages(NetworkClient pClient)
    {
        base.RegisteMessages(pClient);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_CLIENT_RELICE_INFO, ReceiveReliceInfo,false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_UPGRADE_RELICE_RESULT, ResultUpRelice,true);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_CLIENT_OPEN_NEWRELICE, OpenNewRelice,false);
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_GET_RELICE_INFO, OnGetReliceInfo, false);
    }

    public void OnRequestReliceInfo()
    {
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQ_GET_RELICE_INFO, (ushort)ProCG.GAME_ACK_GET_RELICE_INFO, null);
    }

    private void OnGetReliceInfo(BinaryReader br)
    {
        G2CAckGetReliceInfo msg = new G2CAckGetReliceInfo();
        msg.Read(br);
        RelicseCount = msg.uiReliceCount;
        AddFight = msg.uiAddFight;
        SingletonObject<RelicsMediator>.GetInst().InitRelicsInfo();
    }

    public bool isCanUpLevel(uint id)
    {
        if (null != canUpLevelList && canUpLevelList.Contains(id))
            return true;
        return false;
    }

    public override void UpdataList(PackItemInfo itemInfo)
    {
        base.UpdataList(itemInfo);
        CheckIsUpLevel();
    }

    /// <summary>
    /// 检查是否有哪个圣器的哪个洞拥有足够宝石升级
    /// </summary>
    /// <returns></returns>
    private void CheckIsUpLevel()
    {
        uint redNum = 0;
        uint blueNum = 0;
        uint greenNum = 0;
        PackItemInfo mItem = GetPackItemToID(PYXItemManager.RedGemId);
        if (null != mItem) redNum = mItem.uiItemNum;
        mItem = GetPackItemToID(PYXItemManager.BuleGemId);
        if (null != mItem) blueNum = mItem.uiItemNum;
        mItem = GetPackItemToID(PYXItemManager.GreenGemId);
        if (null != mItem) greenNum = mItem.uiItemNum;
        canUpLevelList.Clear();
        foreach (KeyValuePair<uint, CReliceInfo> kv in myReliveInfo)
        {
            if (null == kv.Value || null == kv.Value.holeList) continue;
            bool isUpLevel = false;
            ReliceContent mLoader = null;
            List<BaseIntContent> mUse = null;
            List<BaseIntContent> mTech = null;
            List<CReliceHoleInfo> hInfo = kv.Value.holeList;
            mLoader = HolderManager.m_ReliceHolder.GetStaticInfo(kv.Key);
            if (null == mLoader) continue;
            for (int i = 0, j = hInfo.Count; i < j; i++)
            {
                int mExp = 0;
                int mGem = 0;
                switch (hInfo[i].uiType)
                {
                    case (ushort)EnumGemHoleType.GemHoleType_1:
                        {
                            mTech = mLoader.Hole1Tech;
                            mUse = mLoader.Hole1Item;
                        }
                        break;
                    case (ushort)EnumGemHoleType.GemHoleType_2:
                        {
                            mTech = mLoader.Hole2Tech;
                            mUse = mLoader.Hole2Item;
                        }
                        break;
                    case (ushort)EnumGemHoleType.GemHoleType_3:
                        {
                            mTech = mLoader.Hole3Tech;
                            mUse = mLoader.Hole3Item;
                        }
                        break;
                }
                if(null == mTech || null == mUse)return;
                for (int h = 0, k = mTech.Count; h < k; h++)
                {
                    if (null != mTech[h].list && hInfo[i].uiLevel == mTech[h].list[0])
                    {
                        mExp = (int)(mTech[h].list[1] - hInfo[i].uiCurExp);
                        break;
                    }
                }
                for (int h = 0, k = mUse.Count; h < k; h++)
                {
                    List<int> uList = mUse[h].list;
                    if (null == uList ||uList.Count != 2) continue;
                    if (uList[0] == PYXItemManager.RedGemId)
                    {
                        mGem += (int)(redNum * uList[1]);
                    }
                    else if (uList[0] == PYXItemManager.BuleGemId)
                    {
                        mGem += (int)(blueNum * uList[1]);
                    }
                    else if (uList[0] == PYXItemManager.GreenGemId)
                    {
                        mGem += (int)(greenNum * uList[1]);
                    }
                }
                if (mExp > 0 && mGem >= mExp)
                {
                    isUpLevel = true;
                    break;
                }
            }
            if (isUpLevel)
            {
                canUpLevelList.Add(kv.Key);
            }
        }
        if (canUpLevelList.Count > 0)
            SingletonObject<HomeMainMediator>.GetInst().NewTreasureTips = true;
        else
            SingletonObject<HomeMainMediator>.GetInst().NewTreasureTips = false;
    }

#region 注册返回消息的回调处理

    public uint RelicseCount;
    public uint AddFight;
    private void ReceiveReliceInfo(BinaryReader br)
    {
        G2CSendReliceInfo msg = new G2CSendReliceInfo();
        msg.Read(br);
        RelicseCount = msg.uiReliceCount;
        AddFight = msg.uiAddFight;
        SingletonObject<RelicsMediator>.GetInst().InitRelicsInfo();
        myReliveInfo.Clear();
        //MyLog.LogError("msg.sReliceList.Count: " + msg.sReliceList.Count);
        for (int i = 0, j = msg.sReliceList.Count; i < j; i++)
        {
            CReliceInfo roi = new CReliceInfo();
            roi.uiReliceId = msg.sReliceList[i].uiReliceId;
            roi.bActiveAttr = msg.sReliceList[i].bActiveAttr;
            for (int k = 0, h = msg.sReliceList[i].sGemHoleList.Count; k < h; k++)
            {
                CReliceHoleInfo rhi = new CReliceHoleInfo();
                rhi.uiType = msg.sReliceList[i].sGemHoleList[k].uiType;
                rhi.uiLevel = msg.sReliceList[i].sGemHoleList[k].uiLevel;
                rhi.uiCurExp = msg.sReliceList[i].sGemHoleList[k].uiCurExp;
                roi.holeList.Add(rhi);
            }
            myReliveInfo.Add(roi.uiReliceId, roi);
         
        }
        SingletonObject<RelicsMediator>.GetInst().center = -1;
        CheckIsUpLevel();
        
    }

    private void ResultUpRelice(BinaryReader br)
    {
        G2CUpgradeGemResult msg = new G2CUpgradeGemResult();
        msg.Read(br);
        switch(msg.uiResult)
        {
            case (ushort)EnumReliceErr.ReliceErr_Success:
                {
                    CReliceInfo info = null;
                    foreach (KeyValuePair<uint, CReliceInfo> kv in myReliveInfo)
                    {
                        info = kv.Value;
                        if (info.uiReliceId == msg.uiReliceId)
                        {
                            for (int i = 0, j = info.holeList.Count; i < j; i++)
                            {
                                if (info.holeList[i].uiType == msg.sGemHoleInfo.uiType)
                                {
                                    info.holeList[i].uiLevel = msg.sGemHoleInfo.uiLevel;
                                    info.holeList[i].uiCurExp = msg.sGemHoleInfo.uiCurExp;
                                    //MyLog.LogError(info.holeList[i].uiLevel + "=====" + info.holeList[i].uiCurExp);
                                    break;
                                }
                            }
                            info.bActiveAttr = msg.bActiveAttr;
                            if (msg.vecNewOpenGemHole != null)
                            {
                                CReliceHoleInfo hold = null;
                                for (int i = 0, j = msg.vecNewOpenGemHole.Count; i < j; i++)
                                {
                                    hold = new CReliceHoleInfo();
                                    hold.uiType = msg.vecNewOpenGemHole[i].uiType;
                                    hold.uiLevel = msg.vecNewOpenGemHole[i].uiLevel;
                                    hold.uiCurExp = msg.vecNewOpenGemHole[i].uiCurExp;
                                    info.holeList.Add(hold);
                                }
                            }
                            break;
                        }
                    }

                    for (int i = 0, j = msg.sPackItemList.Count; i < j; i++)
                    {
                        UpdataList(msg.sPackItemList[i]);
                    }

                    SingletonObject<RelicsUpLevelMediator>.GetInst().UpdataRelicsInfo();
                }
                break;
            case (ushort)EnumReliceErr.ReliceErr_NotOpenRelice:
                break;
            case (ushort)EnumReliceErr.ReliceErr_NotOpenGemHole:
                break;
            case (ushort)EnumReliceErr.ReliceErr_ReliceNotExist:
                break;
            case (ushort)EnumReliceErr.ReliceErr_GemHoleNotExist:
                break;
            case (ushort)EnumReliceErr.ReliceErr_NotSuitForHole:
                break;
            case (ushort)EnumReliceErr.ReliceErr_TopLevel:
                break;
            case (ushort)EnumReliceErr.ReliceErr_HaveNoRelice:
                break;
            case (ushort)EnumReliceErr.ReliceErr_QuerryFailed:
                break;
        }
    }

    private void OpenNewRelice(BinaryReader br)
    {
        G2CNotifyOpenNewRelice msg = new G2CNotifyOpenNewRelice();
        msg.Read(br);
        if(myReliveInfo.ContainsKey(msg.sNewRelice.uiReliceId))
        {
            return;
        }
        //MyLog.LogError("OpenNewRelice: " + msg.sNewRelice.uiReliceId);
        CReliceInfo mReliceInfo = new CReliceInfo();
        mReliceInfo.uiReliceId = msg.sNewRelice.uiReliceId;
        mReliceInfo.bActiveAttr = msg.sNewRelice.bActiveAttr;
        for(int i =0,j = msg.sNewRelice.sGemHoleList.Count;i<j;i++)
        {
            CReliceHoleInfo mHoleInfo = new CReliceHoleInfo();
            mHoleInfo.uiType = msg.sNewRelice.sGemHoleList[i].uiType;
            mHoleInfo.uiLevel = msg.sNewRelice.sGemHoleList[i].uiLevel;
            mHoleInfo.uiCurExp = msg.sNewRelice.sGemHoleList[i].uiCurExp;
            mReliceInfo.holeList.Add(mHoleInfo);
        }

        myReliveInfo.Add(mReliceInfo.uiReliceId,mReliceInfo);
    }

#endregion

#region 请求消息的数据处理
    public void RequestUpRelice(uint uiReliceId, ushort uiGemHoleType, stGemConsumeList sGemConsumeList)
    {
        C2GReqUpgradeGem msg = new C2GReqUpgradeGem();
        msg.uiReliceId = uiReliceId;
        msg.uiGemHoleType = uiGemHoleType;
        msg.sGemConsumeList = sGemConsumeList;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_UPGRADE_RELICE, (ushort)ProCG.GAME_ACK_CLIENT_UPGRADE_RELICE_RESULT, msg);
    }
#endregion

    public bool IsOpenRelics(uint id)
    {
        if (myReliveInfo.ContainsKey(id))
        {
            return true;
        }

        return false;
    }

    public bool IsActiveAttribute(uint id)
    {
        if (!myReliveInfo.ContainsKey(id))
        {
            return false;
        }
        return myReliveInfo[id].bActiveAttr == 1 ? true : false;
    }

    public int GetReliveInfoCount()
    {
        if (null != myReliveInfo)
        {
            return myReliveInfo.Count;
        }
        return 0;
    }

    public float GetLevelExp(CReliceInfo info)
    {
        if (null == info || null == info.holeList) return 0;
        float exp = 0;
        ReliceContent loader = HolderManager.m_ReliceHolder.GetStaticInfo(info.uiReliceId);
        if (null == loader) return 0;
        List<BaseIntContent> hole1 = loader.Hole1Tech;
        List<BaseIntContent> hole2 = loader.Hole2Tech;
        List<BaseIntContent> hole3 = loader.Hole3Tech;
        List<BaseIntContent> techList = null;
        for (int i = 0, j = info.holeList.Count; i < j; i++)
        {
            exp += info.holeList[i].uiLevel - 1;
            switch (info.holeList[i].uiType)
            {
                case (ushort)EnumGemHoleType.GemHoleType_1:
                    {
                        techList = hole1;
                    }
                    break;
                case (ushort)EnumGemHoleType.GemHoleType_2:
                    {
                        techList = hole2;
                    }
                    break;
                case (ushort)EnumGemHoleType.GemHoleType_3:
                    {
                        techList = hole3;
                    }
                    break;
            }
            if (null == techList) return 0;
            for (int k = 0, h = techList.Count; k < h; k++)
            {
                if (null != techList[k].list && techList[k].list[0] == 0) continue;
                if (techList[k].list[0] == info.holeList[i].uiLevel)
                {
                    if (techList[k].list[1] > 0)
                    {
                        exp += ((float)info.holeList[i].uiCurExp / techList[k].list[1]);
                    }
                    break;
                }
            }
        }
        return exp;
    }

    public float GetLevelExp(uint id)
    {
        if (null != myReliveInfo && myReliveInfo.ContainsKey(id))
        {
            CReliceInfo reliceInfo = myReliveInfo[id];
            if (null == reliceInfo) return 0;
            return GetLevelExp(reliceInfo);
        }
        return 0;
    }

    //public uint GetCurrentExp(uint id)
    //{
    //    if (null != myReliveInfo && myReliveInfo.ContainsKey(id))
    //    {
    //        CReliceInfo reliceInfo = myReliveInfo[id];
    //        ReliceContent loader = HolderManager.m_ReliceHolder.GetStaticInfo(id);
    //        if (null == reliceInfo || null == reliceInfo.holeList || null == loader) return 0;
    //        List<BaseIntContent> hole1 = loader.Hole1Tech;
    //        List<BaseIntContent> hole2 = loader.Hole2Tech;
    //        List<BaseIntContent> hole3 = loader.Hole3Tech;
    //        List<BaseIntContent> techList = null;
    //        int exp = 0;
    //        for (int i = 0, j = reliceInfo.holeList.Count; i < j; i++)
    //        {
    //            switch (reliceInfo.holeList[i].uiType)
    //            {
    //                case (ushort)EnumGemHoleType.GemHoleType_1:
    //                    {
    //                        techList = hole1;
    //                    }
    //                    break;
    //                case (ushort)EnumGemHoleType.GemHoleType_2:
    //                    {
    //                        techList = hole2;
    //                    }
    //                    break;
    //                case (ushort)EnumGemHoleType.GemHoleType_3:
    //                    {
    //                        techList = hole3;
    //                    }
    //                    break;
    //            }
    //            if (null == techList) continue;
    //            for(int k = 0,h = techList.Count;k < h;k++)
    //            {
    //                if (null == techList[k].list && techList[k].list[0] == 0) continue;
    //                if (techList[k].list[0] < reliceInfo.holeList[i].uiLevel)
    //                {
    //                    exp += techList[k].list[1];
    //                }
    //                else
    //                {
    //                    break;
    //                }
    //            }
    //            exp += (int)reliceInfo.holeList[i].uiCurExp;
    //        }
    //        return (uint)exp;
    //    }
    //    return 0;
    //}

    public CReliceInfo GetReliceInfo(uint id)
    {
        if (myReliveInfo.ContainsKey(id))
        {
            return myReliveInfo[id];
        }
        return null;
    }


    public List<PackItemInfo> GetSortList()
    {
        List<PackItemInfo> PYXlist = ItemList;
        if (null != PYXlist && PYXlist.Count > 0)
        {
            PYXlist.Sort(delegate(PackItemInfo a, PackItemInfo b) { return a.uiItemId.CompareTo(b.uiItemId); });
        }
        return PYXlist;

    }
}
