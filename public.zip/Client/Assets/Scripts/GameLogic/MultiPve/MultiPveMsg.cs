﻿using Network;
using Protocol;
using System.IO;
using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//多人PVE消息
public class MultiPveMsg
{
    private static MultiPveManager PveMgr = null;
    private static BattleScene _BattleScene = null;
    private static Avatar _Avatar;

    public static uint Timestamp = 0; //时间戳
    public static bool LockStep = false;
    public static byte Seed = 0; //随机种子
    public static int AssetsMapKey = 0;//

    private static List<uint> m_triggerList = new List<uint>();

    private static DateTime MarkSendTime = new DateTime();
    private static DateTime UpdateMarkTime = DateTime.MaxValue;
    private static float UpdateMarkRealTime = float.MaxValue;

    public static void RegisteMesasge(NetworkClient pClient)
    {
        PveMgr = MultiPveManager.GetInst();
        _BattleScene = SingletonObject<BattleScene>.GetInst();
        m_triggerList.Clear();

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_START, onG2CNotifyPveStart, false); //服务端通知开始,G2CNofityPveStart

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_LOADING_FINISH, onG2CAckLoading, false); //服务端回复LOADING结束, G2CLoadingFinish
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_BOTH_LOADING_FINISH, onG2CNotifyBothLoading, false); //服务端通知双方都loading结束,G2CNotifyBothLoadingFinish
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PROOFREAD_TIME, OnProofreadTime, false); //服务端回复校对的时间,G2CProofreadTime

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_MOVE, onG2CAckMove, false); //服务端回复移动,G2CPveMove
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_OTHER_MOVE, onG2CNotifyOtherMove, false); //服务端通知玩家敌人移动了,G2CNotifyPveOtherMove

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_MONSTER_MOVE, onG2CAckMonsterMove, false); //服务端回复移动,G2CPveMonsterMove
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_OTHER_MONSTER_MOVE, onG2CNotifyMonsterMove, false); //服务端回复移动,G2CNotifyPveOtherMonsterMove

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_DO_ATTACK, onG2CAckAttack, false); //服务端回复发起攻击,G2CPveDoAttack
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_BEING_ATTACK, onG2CNoltifyAttack, false); //服务端通知其他玩家人攻击,G2CNotifyPveBeingAttack

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_SELF_DATA_CHANGE, onG2CAckDataChange, false); //服务端回复自己的数据发生变化,G2CPveDataChange
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_DATA_CHANGE, onG2CNotifyDataChange, false); //服务端通知某人的数据变化,G2CNotifyPveDataChange

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_CREATE_MONSTER, onG2CAckCreateMonster, false); //服务端回复刷怪,G2CCreateMonster
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_CREATE_MONSTER, onG2CNotifyCreateMonster, false); //服务端通知玩家刷怪,G2CNotifyCreateMonster

        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_PVE_BLINK_EVENT, onG2CBlinkEvent, false); //服务端回复瞬移事件(电梯、传送等),G2CPveBlink
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_NOTIFY_PVE_BLINK_EVENT, onG2CNotifyBlinkEvent, false); //服务端通知瞬移事件(电梯、传送等),G2CNotifyPveBlink

    }

    public static void IgnoreLayerCollision(bool state)
    {
        Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.MONSTER_LAYER, state);
        Physics.IgnoreLayerCollision(DEFINE.MONSTER_LAYER, DEFINE.MONSTER_LAYER, state);
        Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.AVATAR_LAYER, state);
    }

    private static void onG2CNotifyPveStart(BinaryReader br)
    {
        G2CNofityPveStart msg = new G2CNofityPveStart();
        msg.Read(br);

        UnityEngine.Random.seed = msg.iSeed;
        Seed = msg.iSeed;

        PveMgr.SelfInfo.playerInfo = msg.sMyObj;
        PveMgr.SelfInfo.parterInfo = new PartnerSortItem(msg.sMyObj.partner);

        PveMgr.EnemyPlayerDict.Clear();
        for (int i = 0, len = msg.lEnemyObjList.Count; i < len; i++)
        {
            PveMgr.AddOtherPlayer(eCreatePvpType.enemy, msg.lEnemyObjList[i]);
        }

        Timestamp = 0;
        LockStep = false;

        _Avatar = SingletonObject<Avatar>.GetInst();
        //操作上锁
        _Avatar.MsgLock = eMsgLockType.Lock;

        IgnoreLayerCollision(true);

        CLoadingManager.GetInst().JumpTo(eGameState.Home, eGameState.Battle, eBattleType.MultiPve, delegate()
        {
            SingletonObject<CBattleSceneLoading>.GetInst().battleType = eBattleType.MultiPve;
            SingletonObject<CBattleSceneLoading>.GetInst().EnterScene(11000001);
        });

    }

    private static void onG2CAckLoading(BinaryReader br)
    {
        G2CLoadingFinish msg = new G2CLoadingFinish();
        msg.Read(br);
    }

    private static void onG2CNotifyBothLoading(BinaryReader br)
    {
        G2CNotifyBothLoadingFinish msg = new G2CNotifyBothLoadingFinish();
        msg.Read(br);
        AssetsMapKey = msg.iAssetKey;
        //操作解锁
        _Avatar.MsgLock = eMsgLockType.Unlock;

        //校对时间戳
        SendProofreadTimeMsg();
    }

    public static void SendProofreadTimeMsg()
    {
        NullStruct msgRequest = new NullStruct();
        MarkSendTime = DateTime.Now;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PROOFREAD_TIME, msgRequest);
    }

    private static void OnProofreadTime(BinaryReader br)
    {
        G2CProofreadTime msg = new G2CProofreadTime();
        msg.Read(br);

        TimeSpan span = DateTime.Now - MarkSendTime;

        UpdateMarkTime = DateTime.MaxValue;
        UpdateMarkRealTime = float.MaxValue;

        Timestamp = (uint)(msg.uiTimestamp + span.TotalMilliseconds / 2);

    }

    //player move
    private static void onG2CAckMove(BinaryReader br)
    {
        G2CPveMove msg = new G2CPveMove();
        msg.Read(br);

        //         if (LockStep)
        //         {
        //             LockStep = false; ;
        //         }

        _Avatar.RecvMove(msg);
    }

    private static void onG2CNotifyOtherMove(BinaryReader br)
    {
        G2CNotifyPveOtherMove msg = new G2CNotifyPveOtherMove();
        msg.Read(br);

        OnlineAvatar otherPlayer = PveMgr.GetEnemyPlayer();
        if (null != otherPlayer)
        {
            otherPlayer.RecvMove(msg);
        }
    }

    private static void onG2CAckMonsterMove(BinaryReader br)
    {
        G2CPveMonsterMove msg = new G2CPveMonsterMove();
        msg.Read(br);

        //         if (LockStep)
        //         {
        //             LockStep = false; ;
        //         }

        //Debug.LogError(" onG2CAckMonsterMove :  " + msg.monsterIndex);

        Monster monster = _BattleScene.GetNpc(msg.monsterIndex) as Monster;
        if (null != monster)
        {
            monster.RecvMonsterMove(msg, true);
        }

    }

    private static void onG2CNotifyMonsterMove(BinaryReader br)
    {
        G2CNotifyPveOtherMonsterMove msg = new G2CNotifyPveOtherMonsterMove();
        msg.Read(br);

        Monster monster = _BattleScene.GetNpc(msg.monsterIndex) as Monster;
        if (null != monster)
        {
            monster.RecvMonsterMove(msg, false);
        }
    }

    private static void onG2CAckAttack(BinaryReader br)
    {
        G2CPveDoAttack msg = new G2CPveDoAttack();
        msg.Read(br);

        if (LockStep)
        {
            LockStep = false;
        }

        //Debug.LogError(" onG2CAckAttack :  " + msg.uiUserType);
        //区分是monster还是player/pet
        if (msg.uiUserType == (byte)eSyncAttack.Player ||
            msg.uiUserType == (byte)eSyncAttack.Pet)
        {
            //player or pet
            _Avatar.RecvAttack(msg);
        }
        else
        {
            //monster
            Monster monster = _BattleScene.GetNpc(msg.uiUserType) as Monster;
            if (null != monster)
            {
                monster.RecvAttack(msg, true);
            }
        }

    }

    private static void onG2CNoltifyAttack(BinaryReader br)
    {
        G2CNotifyPveBeingAttack msg = new G2CNotifyPveBeingAttack();
        msg.Read(br);

        //Debug.LogError(" onG2CNoltifyAttack :  " + msg.uiUserType);

        //区分是monster还是player/pet
        if (msg.uiUserType == (byte)eSyncAttack.Player ||
            msg.uiUserType == (byte)eSyncAttack.Pet)
        {
            //player or pet
            OnlineAvatar otherPlayer = PveMgr.GetEnemyPlayer();
            if (null != otherPlayer)
            {
                otherPlayer.RecvAttack(msg);
            }
        }
        else
        {
            //monster
            Monster monster = _BattleScene.GetNpc(msg.uiUserType) as Monster;
            if (null != monster)
            {
                monster.RecvAttack(msg, false);
            }
        }
    }

    private static void onG2CAckDataChange(BinaryReader br)
    {
        G2CPveDataChange msg = new G2CPveDataChange();
        msg.Read(br);
/*        Debug.LogError(" onG2CAckDataChange : " );*/

        //npcdead..
        //if (msg.lChangeDataList.Count > 0)
        //{
        //    PvpChangeData data = msg.lChangeDataList[0];

        //    if (data.uiDataType == (byte)ePvpDataType.AvatarHp)
        //    {
        //        _Avatar.AddHp(-_Avatar.GetHp());
        //    }               
        //    else
        //    {
        //        //monster
        //        CBaseNpc monster =  _BattleScene.GetNpc(data.uiDataType);
        //        if ( null != monster )
        //        {
        //            monster.AddHp(-monster.GetHp());
        //        }
        //    }
        //}

    }

    private static void onG2CNotifyDataChange(BinaryReader br)
    {
        G2CPveDataChange msg = new G2CPveDataChange();
        msg.Read(br);



        if (msg.lChangeDataList.Count > 0)
        {
            PvpChangeData data = msg.lChangeDataList[0];
            //Debug.LogError(" onG2CNotifyDataChange : " + data);
            if (data.uiDataType == (byte)ePvpDataType.AvatarHp)
            {
                OnlineAvatar onlineAvatar = PveMgr.GetEnemyPlayer();
                if (null != onlineAvatar && !onlineAvatar.IsDead())
                {
                    onlineAvatar.AddHp(-onlineAvatar.GetHp(), false, null, true);
                }
            }
            else
            {
                //monster
                CBaseNpc monster = _BattleScene.GetNpc(data.uiDataType);
                if (null != monster && !monster.IsDead())
                {
                    //Debug.LogError(" onG2CNotifyDataChange : " + data.uiDataType);
                    monster.AddHp(-monster.GetHp(), false, null, true);
                }
            }
        }
    }

    private static void onG2CAckCreateMonster(BinaryReader br)
    {
        G2CCreateMonster msg = new G2CCreateMonster();
        msg.Read(br);

        //Debug.LogError(" onG2CAckCreateMonster : " );
        LockStep = false;

        //触发过了就不能再触发了
        if (m_triggerList.Contains(msg.uiTriggerID) == false)
        {
            BaseTrigger trigger = TriggerManager.GetInst().GetTrigger(msg.uiTriggerID);
            if (null != trigger)
            {
                //Debug.LogError(" Trigger ID : " + msg.uiTriggerID);
                trigger.DoEvent();
                m_triggerList.Add(msg.uiTriggerID);
            }
        }

    }

    private static void onG2CNotifyCreateMonster(BinaryReader br)
    {
        G2CNotifyCreateMonster msg = new G2CNotifyCreateMonster();
        msg.Read(br);

        //触发过了就不能再触发了
        if (m_triggerList.Contains(msg.uiTriggerID) == false)
        {
            BaseTrigger trigger = TriggerManager.GetInst().GetTrigger(msg.uiTriggerID);
            if (null != trigger)
            {
                trigger.DoEvent();
            }
            m_triggerList.Add(msg.uiTriggerID);
        }
    }

    private static void onG2CBlinkEvent(BinaryReader br)
    {
        G2CPveBlink msg = new G2CPveBlink();
        msg.Read(br);

        _Avatar.SendRequestEnter(msg.index);
    }

    private static void onG2CNotifyBlinkEvent(BinaryReader br)
    {

        G2CNotifyPveBlink msg = new G2CNotifyPveBlink();
        msg.Read(br);

        OnlineAvatar onlineAvatar = PveMgr.GetEnemyPlayer();
        if (null != onlineAvatar)
        {
            onlineAvatar.SendRequestEnter(msg.index);
        }
    }


    //请求怪物移动
    public static void ReqMonsterMove(uint targetIndex, CBaseNpc mover)
    {
        C2GPveMonsterMove msg = new C2GPveMonsterMove();
        msg.uiTimestamp = Timestamp;
        msg.fMoverPosX = mover.GetPosition().x;
        msg.fMoverPosY = mover.GetPosition().z;
        msg.monsterIndex = (byte)mover.Index;
        msg.targetIndex = (byte)targetIndex;
        msg.uiSyncType = 0;

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PVE_MONSTER_MOVE, msg);

        //Debug.LogError(" ReqMonsterMove :  " + mover.Index);
    }

    //请角色物移动
    public static void ReqPlayerMove(RealAvatar realAvatar, Vector3 hitPos, eSyncMove syncType)
    {
        C2GPveMove msg = new C2GPveMove();
        msg.fDesPosX = hitPos.x;
        msg.fDesPosY = hitPos.z;
        msg.fMoverPosX = realAvatar.GetPosition().x;
        msg.fMoverPosY = realAvatar.GetPosition().z;
        msg.uiTimestamp = Timestamp;
        msg.uiSyncType = (byte)syncType;

        //Debug.LogError(" send timestamp : " + Timestamp);

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PVE_MOVE, msg);
    }

    //请求攻击(角色、怪物通用)
    public static void ReqDoAttack(uint uiSkillId, float eulerY, uint Index, Transform trans)
    {
        //暂不对位置
        if (LockStep)
        {
            return;
        }

        C2GPveDoAttack msg = new C2GPveDoAttack();
        msg.fEulerY = eulerY;
        msg.uiSkillID = uiSkillId;
        msg.uiUserType = (byte)Index;
        msg.uiTimestamp = Timestamp;
        msg.sLocationList = new PvpLocationInfoList();

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PVE_DO_ATTACK, msg);

        //Debug.LogError(" ReqDoAttack :  " + uiSkillId);
        LockStep = true;
    }

    public static void ReqCreateMonster(uint triggerID)
    {
        if (LockStep)
        {
            return;
        }

        //Debug.LogError(" ReqCreateMonster :  ");
        LockStep = true;
        //主机才刷怪
        //if (AvatarOnlineInfo.IsHost)
        {
            C2GPveCreateMonster msg = new C2GPveCreateMonster();
            msg.uiTriggerID = triggerID;

            NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PVE_CREATE_MONSTER, msg);
            //Debug.Log();
        }

    }

    public static void ReqDataChange(List<PvpChangeData> dataList)
    {
        //暂时只发死亡的 npc
        //PvpChangeData data = new PvpChangeData();
        //data.uiDataType = (byte)index;
        //data.iNewValue = (float)hp;
        //PvpChangeDataList hpInfoList = new PvpChangeDataList();
        //hpInfoList.Add(data);

        C2GPveReportSelfDataChange msg = new C2GPveReportSelfDataChange();
        for (int i = 0, len = dataList.Count; i < len; i++)
        {
            msg.lChangeDataList.Add(dataList[i]);
        }

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REPORT_PVE_SELF_DATA_CHANGE, msg);
    }

    public static void RequestLoadingSecenFinish()
    {
        //Debug.Log(" RequestLoadingSecenFinish .. "); ;
        C2CLoadingFinish msgRequest = new C2CLoadingFinish();
        AssetsMapContent assetsMapContent = UpdateManager.GetInst().GetMaxAssetMap();
        if (null != assetsMapContent)
        {
            msgRequest.iAssetKey = assetsMapContent.Key;
        }
        else
        {
            msgRequest.iAssetKey = 0;
        }
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REPORT_LOADING_FINISH, msgRequest);
    }


    public static void RequestBlink(C2GPveBlink info)
    {
        C2GPveBlink msg = new C2GPveBlink();
        msg.index = info.index;
        msg.type = info.type;
        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQ_PVE_BLINK_EVENT, msg);
    }


    public static void Update()
    {
        CBattleSceneLoading bsl = SingletonObject<CBattleSceneLoading>.GetInst();

        if (bsl.battleType == eBattleType.MultiPve)
        {
            TimeSpan span = System.DateTime.Now - UpdateMarkTime;
            uint realSpan = (uint)((Time.realtimeSinceStartup - UpdateMarkRealTime) * 1000u); //毫秒数
            if (UpdateMarkTime == DateTime.MaxValue)
            {
                Timestamp += (uint)(Time.deltaTime * 1000u);
            }
            else
            {
                uint spanTime = (uint)span.TotalMilliseconds >= realSpan ? (uint)span.TotalMilliseconds : realSpan;
                Timestamp += spanTime;
            }
            UpdateMarkTime = System.DateTime.Now;
            UpdateMarkRealTime = Time.realtimeSinceStartup;
        }

    }

    public static bool IsLogicTurn
    {
        get { return (Timestamp / PvpDefine.FrameTime) % PvpDefine.IntervalFrame == 0; }
    }

    public static void Release()
    {
        Timestamp = 0;
    }
}
