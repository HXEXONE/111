﻿using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BaseMultiMgr 
{

    protected PvpBattleInfo m_pSelfInfo = new PvpBattleInfo();
    public PvpBattleInfo SelfInfo
    {
        set { m_pSelfInfo = value; }
        get { return m_pSelfInfo; }
    }

    protected Dictionary<ulong, OnlineAvatar> m_enemyPlayerDict = new Dictionary<ulong, OnlineAvatar>();
    public Dictionary<ulong, OnlineAvatar> EnemyPlayerDict
    {
        get { return m_enemyPlayerDict; }
    }

    protected OnlineAvatar m_pPvpOtherAvatar;
    public OnlineAvatar GetEnemyPlayer()
    {
        return m_pPvpOtherAvatar;
    }

    public OnlineAvatar GetEnemyPlayer(ulong playerId)
    {
        if (!m_enemyPlayerDict.ContainsKey(playerId))
        {
            return null;
        }
        return m_enemyPlayerDict[playerId];
    }


    public void AddOtherPlayer(eCreatePvpType type, WildMatcherInfo playerInfo)
    {
        uint jobId = DEFINE.JOB_START_ID + uint.Parse(playerInfo.uiPlayerID.ToString().Substring(playerInfo.uiPlayerID.ToString().Length - 1, 1));

        playerInfo.uiClothesId = CheckResource(playerInfo.uiClothesId, jobId, eAssetMapCheckType.Cloth);
        playerInfo.uiWeaponId = CheckResource(playerInfo.uiWeaponId, jobId, eAssetMapCheckType.Weapon);
        playerInfo.uiMountId = CheckResource((uint)playerInfo.uiMountId, jobId, eAssetMapCheckType.Mount);
        playerInfo.uiPetID = CheckResource((uint)playerInfo.uiPetID, jobId, eAssetMapCheckType.Pet);

        PvpBattleInfo battleInfo = new PvpBattleInfo();
        battleInfo.playerInfo = playerInfo;
        battleInfo.jobId = jobId;
        battleInfo.parterInfo = new PartnerSortItem(playerInfo.partner);

        switch (type)
        {
            case eCreatePvpType.enemy:
                {
                    if (!m_enemyPlayerDict.ContainsKey(playerInfo.uiPlayerID))
                    {
                        OnlineAvatar pta = new OnlineAvatar(battleInfo);
                        m_enemyPlayerDict.Add(playerInfo.uiPlayerID, pta);
                        m_pPvpOtherAvatar = pta;
                    }
                }
                break;
            case eCreatePvpType.ally:
                {
                 
                }
                break;
            default:
                break;
        }
    }

    private static uint CheckResource(uint id, uint jobid, eAssetMapCheckType type)
    {
        return UIManager.GetInst().CheckResourc(id, jobid, type);
    }



}
