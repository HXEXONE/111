﻿using System.Collections;

public enum eBlinkType
{
    Lift         = 1,//电梯
    Transmit    = 2,//传送
}


