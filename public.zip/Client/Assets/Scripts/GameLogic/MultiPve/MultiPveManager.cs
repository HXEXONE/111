﻿using UnityEngine;
using System.Collections;

public class MultiPveManager : BaseMultiMgr
{
    private static MultiPveManager m_singleton;
    public static MultiPveManager GetInst()
    {
        if (null == m_singleton)
        {
            m_singleton = new MultiPveManager();
        }

        return m_singleton;
    }


    /// <summary>
    /// 找到出生地点
    /// </summary>
    /// <param name="player">如果是敌方玩家就传敌方玩家对象</param>
    /// <returns></returns>
    public string FindBornTrigger(OnlineAvatar player = null)
    {
        string trigger = string.Empty;
        ushort mapPos = 1;
        if (null == player)
        {
            mapPos = SelfInfo.playerInfo.uiMapPos;
        }
        else
        {
            mapPos = player.BattleInfo.playerInfo.uiMapPos;
        }

        trigger = mapPos == 1 ? "born2" : "born1";
        return trigger;
    }
}
