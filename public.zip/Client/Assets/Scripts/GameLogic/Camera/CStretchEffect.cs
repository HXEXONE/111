﻿using UnityEngine;
using System.Collections;

public class CStretchEffect : CCameraBase
{

    private float m_stretchTimes;
    private eCameraStretch m_camStretch;
    private float m_vague;
    private float m_min;
    private float m_max;
    private System.Collections.Generic.List<string> m_list;

    private Camera m_camera;

    private float m_fieldOfView;

    public CStretchEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_DRAG;
        m_stretchTimes = -1;
        m_max = -1;
        m_min = -1;
        m_vague = 0.1f;
        m_list = new System.Collections.Generic.List<string>();
        m_camStretch = eCameraStretch.NONE;
        m_bSpecialEffect = false;

        m_ignoreTimeScale = true;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);
        m_camera = cameraObj.camera;

        m_list = m_pCameraInfo.ExtraArgToSingleList;

        m_stretchTimes = MyConvert_Convert.ToSingle(m_list[0]);

        m_min = MyConvert_Convert.ToSingle(m_list[1]);

        m_max = MyConvert_Convert.ToSingle(m_list[2]);
    }

    protected override void UpdateMovement()
    {
        if (m_camStretch != eCameraStretch.NONE)
        {
            ChangeFildOfView();
        }
    }

    protected override void Enter()
    {
        if (m_camStretch == eCameraStretch.NONE)
        {
            base.Enter();
            m_fieldOfView = m_camera.fieldOfView;
            m_camStretch = eCameraStretch.DRGA;

            CCameraBase baseEffect = CCamera.GetInst().GetExistEffect(eCAMERATYPE.CAMERA_TYPE_DRAG_BACK);
            if (baseEffect.IsForward())
                CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_DRAG_BACK, null);
        }
    }

    protected override void Leave()
    {
        m_camStretch = eCameraStretch.NONE;
        if (m_camera != null)
        {
            m_camera.fieldOfView = m_min;
        }
        else
            MyLog.LogError("CStretchEffect Leave m_camera is null");
        base.Leave();
    }


    private void ChangeFildOfView()
    {
        if (m_camera == null)
        {
            MyLog.LogError("CStretchEffect ChangeFildOfView m_camera is null");
            SetState(eCameraState.CAMERA_STATE_LEAVE);
            return;
        }

        m_fieldOfView -= Time.deltaTime * Timer.GetTimeForDateTime((m_max - m_min) / m_stretchTimes);// (m_max - m_min) / m_stretchTimes;

        m_fieldOfView = Mathf.Max(m_min, m_fieldOfView);

        m_camera.fieldOfView = m_fieldOfView;

        if (m_camera.fieldOfView <= m_min)
        {
            SetState(eCameraState.CAMERA_STATE_LEAVE);
        }
    }
}
