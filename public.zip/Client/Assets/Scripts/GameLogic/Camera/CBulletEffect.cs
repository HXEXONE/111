﻿using UnityEngine;

public class CBulletEffect : CCameraBase
{
    private float m_fStartBulletTime;//开始子弹时间

    private float m_fBulletTime = 0;//因为子弹时间效果损失的时间

    public CBulletEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_BULLET_TIME;
        base.m_bSpecialEffect = false;

        m_ignoreTimeScale = true;
    }

    public float GetBulletTime()
    {
        return m_fBulletTime;
    }

    protected override void Enter()
    {
        base.Enter();

        float fBulletTime =MyConvert_Convert.ToSingle(m_pCameraInfo.ExtraArgToSingleList[0]);
        Common.TimeScale = fBulletTime;
        //m_fLastTime *= fBulletTime;

        //CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_BIG_SHAKE);
        //CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_SMALL_SHAKE);
    }

    protected override void Leave()
    {
        Common.TimeScale = 1;
        base.Leave();
    }

}