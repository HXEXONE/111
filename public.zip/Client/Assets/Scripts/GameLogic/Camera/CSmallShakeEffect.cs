//using UnityEngine;
//using System.Collections;

//public class CSmallShakeEffect : CCameraBase
//{
//    private Timer m_pTimer;

//    public CSmallShakeEffect()
//        : base()
//    {
//        m_CameraType = eCAMERATYPE.CAMERA_TYPE_SMALL_SHAKE;
//        base.m_bSpecialEffect = false;

//        m_pTimer = new Timer();
//    }

//    protected override void Enter()
//    {
//        //int range = Random.Range(0, 6);
//        //Vector3 offsetVec = Vector3.zero;
//        //float fOffset = 0.2f;
//        //switch (range)
//        //{
//        //    case 0: offsetVec = new Vector3(fOffset, 0, 0); break;
//        //    case 1: offsetVec = new Vector3(-fOffset, 0, 0); break;
//        //    case 2: offsetVec = new Vector3(0, fOffset, 0); break;
//        //    case 3: offsetVec = new Vector3(0, -fOffset, 0); break;
//        //    case 4: offsetVec = new Vector3(0, 0, fOffset); break;
//        //    case 5: offsetVec = new Vector3(0, 0, -fOffset); break;
//        //}

//        //Vector3 newPos = m_pCameraObj.transform.position + offsetVec;
//        //iTween.MoveFrom(m_pCameraObj, newPos, 0.05f);

//        m_pTimer.SetTimer(0.05f);
//    }

//    protected override void UpdateMovement()
//    {
//        return;
//        if (m_pTimer.IsExpired(false))
//        {
//            SetState(eCameraState.CAMERA_STATE_LEAVE);
//        //    iTween.Stop();
//            m_pTimer.Release();
//        }
//    }
//}
