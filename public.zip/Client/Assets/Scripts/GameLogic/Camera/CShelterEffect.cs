﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//场景灰暗,人物怪物高亮效果
public class CShelterEffect : CCameraBase
{
    private CObject m_shelterParticleObject;
    private GameObject m_shelterObj = null;
    private Camera m_shelterCamera;
    private Material m_shelterMaterial;
    private float m_fTime = -1;//几秒内场景灰暗到极致
    private float m_resultAlphaFormXlsx = -1;
    private float m_resultAlpha = -1;//最终alpha

    private float m_waitTime;//等待淡出时间
    private float m_speed;
    private float m_lastTime;
    private List<string> m_list = new List<string>();

    private bool m_useOld = true;
    private float m_curSubtractVal;
    private float m_targetSubtract;



    private eCameraEffectType m_mode = eCameraEffectType.None;

    public CShelterEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_SHELTER;
        base.m_bSpecialEffect = false;

        GameObject o = new GameObject("ShelterCamera");
        m_shelterCamera = o.AddComponent<Camera>();
        m_shelterCamera.enabled = false;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);


        m_list = m_pCameraInfo.ExtraArgToSingleList;


        m_resultAlphaFormXlsx = MyConvert_Convert.ToSingle(m_list[0]);

        m_fTime = MyConvert_Convert.ToSingle(m_list[1]);

        m_waitTime = MyConvert_Convert.ToSingle(m_list[2]);

        m_targetSubtract = MyConvert_Convert.ToSingle(m_list[3]);

        m_resultAlpha = m_resultAlphaFormXlsx / 255f;


        if (m_shelterObj == null)
        {
            m_shelterParticleObject = new CObject(DEFINE.ASSETBUNDLE_PATH_CAMERA_EFFECT_SHELTER);
            m_shelterParticleObject.IsMemoryFactory = true;
            m_shelterParticleObject.ObjectType = eObjectType.Particle;
            m_shelterParticleObject.CallBack = LoadComplete;
            m_shelterParticleObject.LoadObject();
        }
    }

    protected override void Enter()
    {
        base.Enter();

        if (m_shelterCamera == null)
        {
            GameObject o = new GameObject("ShelterCamera");
            m_shelterCamera = o.AddComponent<Camera>();
            m_shelterCamera.fieldOfView = m_pCameraObj.camera.fieldOfView;
            m_shelterCamera.enabled = false;
        }

        Camera fatherCamera = m_pCameraObj.GetComponent<Camera>();

        m_shelterCamera.clearFlags = CameraClearFlags.Depth;
        m_shelterCamera.cullingMask =
            (1 << DEFINE.AVATAR_LAYER |
            1 << DEFINE.MONSTER_LAYER |
            1 << DEFINE.ALLY_LAYER |
            1 << DEFINE.EFFECT_LAYER |
            1 << DEFINE.PET_LAYER |
            1 << DEFINE.PROJECTOR);
        m_shelterCamera.fieldOfView = fatherCamera.fieldOfView;
        m_shelterCamera.depth = 1;

        m_shelterCamera.enabled = true;

        m_shelterCamera.gameObject.transform.parent = m_pCameraObj.transform;
        m_shelterCamera.gameObject.transform.localPosition = Vector3.zero;
        m_shelterCamera.gameObject.transform.localRotation = Quaternion.identity;

        fatherCamera.cullingMask = ~(m_shelterCamera.cullingMask | 
            1 << DEFINE.NGUI_LAYER_ONE |
             1 << DEFINE.NGUI_LAYER_TWO |
             1 << DEFINE.NGUI_LAYER_THREE |
              1 << DEFINE.NGUI3D_LAYER_TWO | 
            1 << DEFINE.NGUI3D_LAYER | 
            1 << DEFINE.TOUCHEFFECT);

        if (null == m_shelterObj)
        {
            Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_SCREEN_BLEND_3000);
            m_shelterMaterial = new Material(shader);
            m_shelterObj = WeatherCommon.GetInst().CreateUnityObject(PrimitiveType.Quad, m_shelterMaterial, Vector3.zero, Quaternion.identity, new Vector3(1.5f,1,1));
            m_shelterObj.name = "CameraEffect_ShelterObject";
        }

        InitShelterObj();

        m_mode = eCameraEffectType.Enter;
        
    }

    //private void LoadShelterCompleted(string interim, UnityEngine.Object asset)
    //{
    //    m_shelterObj = (GameObject)UnityEngine.Object.Instantiate(asset);
    //    InitShelterObj();
    //}

    private void InitShelterObj()
    {
        if (m_useOld)
        {
            m_shelterObj.SetActive(true);

            m_shelterObj.transform.parent = m_pCameraObj.transform;
            m_shelterObj.transform.localPosition = Vector3.zero + new Vector3(0, 0, 0.4f);
            m_shelterObj.transform.localRotation = Quaternion.identity;

            Color color = new Color(0, 0, 0, 0);
            m_shelterMaterial.color = color;

            m_speed = (m_resultAlpha) / m_fTime;
        }
        else
        {
            m_shelterObj.renderer.enabled = true;
            m_shelterObj.transform.parent = m_pCameraObj.transform;
            m_shelterObj.transform.localPosition = Vector3.zero + new Vector3(0, 0, 0.4f);
            m_shelterObj.transform.localRotation = Quaternion.identity;

            m_curSubtractVal = 1;
            m_shelterMaterial.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_curSubtractVal);

            m_speed = (1 - m_targetSubtract) / m_fTime;
        }
    }

    protected override void Leave()
    {
        base.Leave();
        if (null != m_shelterObj)
        {
            m_shelterCamera.enabled = false;

            Camera fatherCamera = m_pCameraObj.GetComponent<Camera>();
            //fatherCamera.cullingMask = ~(1 << DEFINE.NGUI_LAYER_ONE |
            //    1 << DEFINE.NGUI_LAYER_TWO |
            //    1 << DEFINE.NGUI_LAYER_THREE |
            //    1 << DEFINE.NGUI3D_LAYER |
            //    1 << DEFINE.TOUCHEFFECT);
            fatherCamera.cullingMask = DEFINE.CAMERA_FOLLOW_ORIGINAL_CULLING_MASK;
         //   fatherCamera.transform.DetachChildren();

            if (m_useOld)
                m_shelterObj.SetActive(false);
            else
            {
                m_shelterObj.SetActive(false);
                m_shelterObj = null;
                m_shelterParticleObject.DestroyGameObject(eObjectDestroyType.Memory);
            }
        }
        
    }

    protected override void Wait()
    {
        if (m_shelterObj == null)
            return;
        base.Wait();
    }

    protected override void UpdateMovement()
    {
        base.UpdateMovement();
        if (null == m_shelterMaterial)
        {
            return;
        }

        switch (m_mode)
        {
            case eCameraEffectType.Enter: ForUpdateEnter(); break;
            case eCameraEffectType.Wait: ForUpdateWait(); break;
            case eCameraEffectType.Back: ForUpdateBack(); break;
        }

        m_shelterCamera.fieldOfView = m_pCameraObj.camera.fieldOfView;
    }

    private void ForUpdateEnter()
    {
        if (m_useOld)
        {
            Color color = m_shelterMaterial.color;
            color.a += m_speed * Time.deltaTime;
            color.a = Mathf.Clamp01(color.a);
            if (color.a >= m_resultAlpha)
            {
                m_mode = eCameraEffectType.Wait;
                m_lastTime = Time.time;
            }
            m_shelterMaterial.color = color;
        }
        else
        {
            m_curSubtractVal -= m_speed * Time.deltaTime;
            m_curSubtractVal = Mathf.Max(m_targetSubtract, m_curSubtractVal);
            m_shelterMaterial.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_curSubtractVal);
            if (m_curSubtractVal <= m_targetSubtract)
            {
                m_mode = eCameraEffectType.Wait;
                m_lastTime = Time.time;
            }
        }
    }

    private void ForUpdateWait()
    {
        if (Time.time - m_lastTime >= m_waitTime)
        {
            m_mode = eCameraEffectType.Back;
        }
    }

    private void ForUpdateBack()
    {
        if (m_useOld)
        {
            Color color = m_shelterMaterial.color;
            color.a -= m_speed * Time.deltaTime;
            color.a = Mathf.Clamp01(color.a);
            if (color.a <= 0)
            {
                m_mode = eCameraEffectType.None;
                SetState(eCameraState.CAMERA_STATE_LEAVE);
            }
            m_shelterMaterial.color = color;
        }
        else
        {
            m_curSubtractVal += m_speed * Time.deltaTime;
            m_curSubtractVal = Mathf.Min(1, m_curSubtractVal);
            m_shelterMaterial.SetFloat(DEFINE.SHADER_PROPERTY_SUBTRACTS, m_curSubtractVal);
            if (m_curSubtractVal >= 1)
            {
                m_mode = eCameraEffectType.None;
                SetState(eCameraState.CAMERA_STATE_LEAVE);
            }
        }
    }

    private void LoadComplete(GameObject o, params object[] args)
    {
        if (o == null)
        {
            MyLog.DebugLogException("Camera effect m_shelterObj is null");
            return;
        }
        m_shelterObj = o;
        m_shelterObj.SetActive(true);
        m_useOld = m_shelterObj == null;

        if (!m_useOld)
        {
            DynamicShader.ReplaceUnSupportShader(m_shelterObj);
            m_shelterMaterial = m_shelterObj.renderer.sharedMaterial;
            m_shelterObj.transform.localScale = new Vector3(1.5f, 1, 1);
        }
        m_shelterObj.renderer.enabled = false;
    }
}
