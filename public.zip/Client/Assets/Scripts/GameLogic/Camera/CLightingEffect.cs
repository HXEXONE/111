﻿using UnityEngine;
using System.Collections;

public class CLightingEffect : CCameraBase
{

    private System.Collections.Generic.List<string> m_list;
    private Color m_color;

    private GameObject m_cube;
    private Material m_cubeMat;
    private float m_alpha;
    private float m_speed;



    public CLightingEffect()
        : base()
    {
        m_list = new System.Collections.Generic.List<string>();

        m_alpha = 0;
        m_color = Color.white;
        m_color.a = 0;
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_LIGHTING;
        base.m_bSpecialEffect = false;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);

        m_list = m_pCameraInfo.ExtraArgToSingleList;

        m_alpha = MyConvert_Convert.ToSingle(m_list[0]);

        m_color = new Color(MyConvert_Convert.ToSingle(m_list[1]) / 255, MyConvert_Convert.ToSingle(m_list[2]) / 255, MyConvert_Convert.ToSingle(m_list[3]) / 255, MyConvert_Convert.ToSingle(m_list[4]) / 255);

        m_alpha = m_color.a;

        m_speed = 1 / m_fLastTime - 0.05f;

        if (m_speed <= 0)
            m_speed = 5;

        if (!m_cube)
            CreateCameraCoverPlane();
    }

    protected override void Enter()
    {
        base.Enter();
        if (!m_cube || !m_cubeMat)
        {
            SetState(eCameraState.CAMERA_STATE_LEAVE);
            return;
        }
        m_cube.renderer.enabled = true;
        m_color.a = m_alpha;
        m_cubeMat.color = m_color;
    }

    protected override void UpdateMovement()
    {
        base.UpdateMovement();
        if (!m_cube || !m_cubeMat)
        {
            SetState(eCameraState.CAMERA_STATE_LEAVE);
            return;
        }

        m_alpha = Mathf.Clamp01(m_alpha - Time.deltaTime * m_speed);
        m_color.a = m_alpha;
        m_cubeMat.color = m_color;
    }

    protected override void Leave()
    {
        base.Leave();
        //if (null != m_pCameraObj)
        //{
        //    MobileBloom1 mb = m_pCameraObj.GetComponent<MobileBloom1>();s
        //    if (null != mb)
        //    {
        //        MyLog.Log("mb != null");
        //        mb.enabled = false;
        //    }
        //    else
        //    {
        //        MyLog.Log("mb != null");
        //    }
        //}
        if (!m_cube || !m_cubeMat)
        {
            if (m_alpha != 0)
            {
                m_alpha = 0;
                m_color.a = m_alpha;
                m_cubeMat.color = m_color;
            }
            m_cube.renderer.enabled = false;
        }
    }


    private void CreateCameraCoverPlane()
    {
        if (!m_cubeMat)
        {
            Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_SCREEN_ADD_3000);
            if (!shader)
                return;
            m_cubeMat = new Material(shader);
        }
        m_color.a = 0;
        m_cubeMat.color = m_color;
        Transform parent = CCamera.GetInst().GetCameraObj().transform;
        m_cube = WeatherCommon.GetInst().CreateUnityObject(PrimitiveType.Cube, m_cubeMat, new Vector3(0, 0, 1.55f), Quaternion.Euler(0, 0, 180), new Vector3(1.5f * 1.6f, 1.5f, 1.5f), parent, Space.Self);
        m_cube.renderer.enabled = false;
    }
}
