﻿using UnityEngine;
using System.Collections;

public class CShakeEffect : CCameraBase
{

    private float m_time;
    private Vector3 m_direct;
    private iTween.LoopType m_looptype;
    private GameObject m_shakeTarget;

    private bool m_canShake;

    private System.Collections.Generic.List<string> m_list;

    public CShakeEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPR_SHAKE;
        m_time = -1f;
        m_direct = Vector3.zero;
        m_looptype = iTween.LoopType.none;

        m_canShake = true;
        m_list = new System.Collections.Generic.List<string>();
        m_bSpecialEffect = false;

        CanReset = true;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        if (IsOperate() && m_fLastTime == -1)
            return;
        base.Init(pInfo, cameraObj, callback, args);

        m_list = m_pCameraInfo.ExtraArgToSingleList;

        m_time = MyConvert_Convert.ToSingle(m_list[0]);

        m_direct = new Vector3(MyConvert_Convert.ToSingle(m_list[1]), MyConvert_Convert.ToSingle(m_list[2]), MyConvert_Convert.ToSingle(m_list[3]));

        m_shakeTarget = m_pCameraObj;

    }

    protected override void Enter()
    {
        if (m_canShake)
        {
            CanReset = false;
            ShakeMe();
        }
        else
        {
            iTween.Stop(m_shakeTarget, "shake");
            ShakeMe();
        }
    }

    protected override void Leave()
    {
        m_canShake = true;
        if (m_shakeTarget != null)
        {
            iTween.Stop(m_shakeTarget, "shake");
            m_shakeTarget.transform.localPosition = Vector3.zero;
        }
        else
        {
            MyLog.LogError("CShakeEffect Leave m_shakeTarget is null");
        }
        base.Leave();
    }

    public void ShakeMe()
    {
        ReSet(m_shakeTarget.transform);
        m_canShake = false;
        if (m_shakeTarget != null)
        {
            //iTween.Init(m_shakeTarget);
            iTween.ShakePosition(m_shakeTarget, iTween.Hash("amount", m_direct, "time", m_time, "looptype", m_looptype, "space", Space.Self, "oncomplete", (OnCallBack)OnComplete));
        }
        else
        {
            MyLog.LogError("CShakeEffect ShakeMe m_shakeTarget is null");
        }
    }

    void OnComplete(params object[] args)
    {
        CanReset = true;
        if (m_fLastTime == -1)
            SetState(eCameraState.CAMERA_STATE_LEAVE);
    }
}
