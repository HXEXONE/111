using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class CCamera : SingletonObject<CCamera>
{
    private Dictionary<eCAMERATYPE, CCameraBase> m_CameraEffectDict = new Dictionary<eCAMERATYPE, CCameraBase>();

    private GameObject m_NormalCameraObj = null;//��ͨ�����
    private GameObject m_SceneCameraObj = null;//������������������ĸ����壩
    private GameObject m_CameraObj = null; //�������������
    private GameObject m_easyTouchObj = null;
    private EasyTouch m_easyTouch = null;
    private Vector4 m_vector = Vector4.zero;
    public Vector4 Vector { get { return m_vector; } }

    private bool m_pauseAllNpc = false;
    public bool PauseAllNpc
    {
        get { return m_pauseAllNpc; }
        set { m_pauseAllNpc = value; }
    }

    private bool m_pauseCameraEffect = false;

    private object m_lockObject = null;


    public void Init()
    {
        m_NormalCameraObj = GameObject.Find("Main Camera");
        UnityEngine.Object.DontDestroyOnLoad(m_NormalCameraObj);
        Camera FatherCamera = m_NormalCameraObj.GetComponent<Camera>();

        if (FatherCamera != null)
        {
            FatherCamera.cullingMask = ~(1 << DEFINE.NGUI3D_LAYER | 
                1 << DEFINE.NGUI_LAYER_ONE |
                1 << DEFINE.NGUI_LAYER_TWO |
                1 << DEFINE.NGUI_LAYER_THREE |
                1 << DEFINE.NGUI3D_LAYER_TWO | 
                1 << DEFINE.TOUCHEFFECT);
        }

        RegisteCamera(new CFollowEffect());
        RegisteCamera(new CBulletEffect());
        //RegisteCamera(new CBigShakeEffect());
        //RegisteCamera(new CSmallShakeEffect());
        RegisteCamera(new CShelterEffect());
        //RegisteCamera(new CLightingEffect());
        RegisteCamera(new CStretchEffect());
        RegisteCamera(new CShakeEffect());
        RegisteCamera(new CSpDescribeEffect());
        RegisteCamera(new CDrakEffect());
        RegisteCamera(new CPauseFollowEffect());

        //create easyTouch game object
        m_easyTouchObj = new GameObject("EasyTouch");
        m_easyTouch = m_easyTouchObj.AddComponent<EasyTouch>();
        UnityEngine.GameObject.DontDestroyOnLoad(m_easyTouchObj);
        EasyTouch.SetEnabled(false);
    }

    public void EnterScene(GameObject cameraObj,uint cameraID)
    {
        m_CameraObj = new GameObject("SceneCamera");
        m_SceneCameraObj = cameraObj;

        m_CameraObj.transform.parent = m_SceneCameraObj.transform.parent;
        m_CameraObj.transform.position = m_SceneCameraObj.transform.position;
        m_CameraObj.transform.rotation = m_SceneCameraObj.transform.rotation;
        m_SceneCameraObj.transform.parent = m_CameraObj.transform;
        m_SceneCameraObj.transform.localScale =Vector3.one;

     //   m_SceneCameraObj = cameraObj;
        

        Camera camera = cameraObj.GetComponent<Camera>();
        if (camera != null)
        {

            camera.cullingMask = ~(1 << DEFINE.NGUI3D_LAYER 
                | 1 << DEFINE.NGUI_LAYER_ONE
                | 1 << DEFINE.NGUI_LAYER_TWO
                | 1 << DEFINE.NGUI_LAYER_THREE
                | 1 << DEFINE.NGUI3D_LAYER_TWO 
                | 1 << DEFINE.TOUCHEFFECT
                );
            camera.useOcclusionCulling = false;
            camera.fieldOfView = 40;
            camera.backgroundColor = new Color(0.39f, 0.39f, 0.39f);
        }

        AudioListener audiolistener = cameraObj.GetComponent<AudioListener>();
        if (audiolistener != null)
        {
            UnityEngine.Object.Destroy(audiolistener);
        }

        m_NormalCameraObj.name = "HideCamera";
        m_NormalCameraObj.SetActive(false);

        ResetVector(cameraID);
    //    TouchEffect.GetInst().Init(camera);
    }
	
	public void LeaveScene()
	{
        Unlock();
        PauseAllCameraEffect(null);

        m_NormalCameraObj.name = "Main Camera";
        m_NormalCameraObj.SetActive(true);
	}

    public void RegisteCamera(CCameraBase CameraEffect)
    {
        eCAMERATYPE type = CameraEffect.GetCameraType();
        if (!m_CameraEffectDict.ContainsKey(type))
        {
            m_CameraEffectDict.Add(type, CameraEffect);
        }
    }

    public void PauseCameraEffect(bool pause)
    {
        m_pauseCameraEffect = pause;
    }

    public GameObject GetCameraObj()
    {
        if (m_NormalCameraObj != null && m_NormalCameraObj.activeSelf)
        {
            return m_NormalCameraObj;
        }
        else if (m_SceneCameraObj != null && m_SceneCameraObj.activeSelf)
        {
            return m_SceneCameraObj;
        }

        return Camera.main.gameObject;
    }

    public Camera GetCamera()
    {
        GameObject cameraObj = GetCameraObj();
        Camera camera = cameraObj.camera;
        return camera;
    }

    public void SetCameraEffect( uint dwEffectID,object lockObject,RegisterEvent callback,params object[] args)
    {
        if (m_SceneCameraObj == null)
        {
            MyLog.DebugLogException("CCamera SetCameraEffect Main Camera is null");
            return;
        }
        if (dwEffectID == 0)
            return;

        if (m_lockObject != null && !m_lockObject.Equals(lockObject))
        {
            MyLog.Log("CCamera is lock,but a script try to call it!!!!!!!!!!");
            return;
        }

        if (m_pauseCameraEffect)
        {
            if (callback != null)
                callback(args);
            return;
        }

        CameraContent info = HolderManager.m_CameraHolder.GetStaticInfo(dwEffectID);
        if (null == info)
        {
            return;
        }

        CCameraBase effect = GetExistEffect((eCAMERATYPE)info.CameraType);
        if (effect != null)
        {
            if (effect.IsOperate() && info.CameraType != (byte)eCAMERATYPE.CAMERA_TYPR_SHAKE)
                effect.SetState(eCameraState.CAMERA_STATE_LEAVE);
            effect.Init(info, m_SceneCameraObj, callback,args);           
        }
    }

    public CCameraBase GetExistEffect(eCAMERATYPE type)
    {
        CCameraBase effect = null;
        m_CameraEffectDict.TryGetValue(type, out effect);

        return effect;
    }

    public EasyTouch GetEasyTouch()
    {
        if (m_easyTouch !=null)
        {
            return m_easyTouch;
        }
        else
        {
            MyLog.LogError("this EasyTouch is null please initialization");
            return null;
        }
    }

    //�˳�����ʱ��ͣ����Ч��
    public void PauseAllCameraEffect(object lockObject)
    {
        if (m_lockObject != null && !m_lockObject.Equals(lockObject))
        {
            MyLog.Log("CCamera PauseAllCameraEffect() fails.The CCamera is lock,please call Unlock() CCamera before");
            return;
        }

        foreach (KeyValuePair<eCAMERATYPE, CCameraBase> kvp in m_CameraEffectDict)
        {
            kvp.Value.SetState(eCameraState.CAMERA_STATE_LEAVE);
        }
    }

    public void PauseOtherCameraEffect(eCAMERATYPE type,object lockObject)   //��������Լ��͸���Ч�����������Ч��
    {
        if (m_lockObject != null && !m_lockObject.Equals(lockObject))
        {
            MyLog.Log("CCamera PauseOtherCameraEffect(eCAMERATYPE type) fails.The CCamera is lock,please call Unlock() CCamera before");
            return;
        }

        CCameraBase CameraEffect = GetExistEffect(type);
        if (null == CameraEffect)
        {
            return;
        }

        foreach (KeyValuePair<eCAMERATYPE, CCameraBase> kvp in m_CameraEffectDict)
        {
            if (kvp.Key == type || kvp.Key == eCAMERATYPE.CAMERA_TYPE_FOLLOW)
            {
                continue;
            }

            kvp.Value.SetState(eCameraState.CAMERA_STATE_LEAVE);
        }
    }

    //dwExceptID,���������������
    public void PauseOtherCameraEffect(eCAMERATYPE type , bool spice,object lockObject)//��������������λ��Ч��
    {
        if (m_lockObject != null && !m_lockObject.Equals(lockObject))
        {
            MyLog.Log("CCamera PauseOtherCameraEffect(eCAMERATYPE type , bool spice) fails.The CCamera is lock,please call Unlock() CCamera before");
            return;
        }

        CCameraBase CameraEffect = GetExistEffect(type);
        if (null == CameraEffect)
        {
            return;
        }

        foreach (KeyValuePair<eCAMERATYPE, CCameraBase> kvp in m_CameraEffectDict)
        {
            if (!spice)
            {
                if (kvp.Value.isSpecialEffect())
                {
                    continue;
                }
            }

            if (kvp.Key == type)
            {
                continue;
            }

            kvp.Value.SetState(eCameraState.CAMERA_STATE_LEAVE);
        }
    }


    //ǿ����ͣĳ�������Ч��
    public void ForcePauseCameraEffect(eCAMERATYPE type,object lockObject)
    {
        if (m_lockObject != null && !m_lockObject.Equals(lockObject))
        {
            MyLog.Log("CCamera PauseOtherCameraEffect(eCAMERATYPE type , bool spice) fails.The CCamera is lock,please call Unlock() CCamera before");
            return;
        }

        CCameraBase CameraEffect = GetExistEffect(type);
        if (null == CameraEffect)
        {
            return;
        }

        CameraEffect.SetState(eCameraState.CAMERA_STATE_LEAVE);
    }

    public void SetEasyTouch(GameObject cameraObj)
    {
        if (m_easyTouch!=null)
        {
            m_easyTouch.easyTouchCamera = cameraObj.GetComponent<Camera>();
            m_easyTouch.autoSelect = true;
            m_easyTouch.pickableLayers = ~0;
        }
    }

    public void Update()
    {
     
        foreach (KeyValuePair<eCAMERATYPE, CCameraBase> kvp in m_CameraEffectDict)
        {
            kvp.Value.Update();
        }

    }

    public bool Lock(object lockObject)
    {
        if (m_lockObject != null)
        {
            MyLog.Log("CCamera Lock() is fails. It is locked by other Object");
            return false;
        }
        m_lockObject = lockObject;
        return true;
    }

    public void Unlock()
    {
        m_lockObject = null;
    }

    public bool IsLock
    {
        get { return m_lockObject != null; }
    }

    private void ResetVector(uint cameraID)
    {
        CameraContent cameraLoader = HolderManager.m_CameraHolder.GetStaticInfo(cameraID);

        if (cameraLoader == null)
        {
            return;
        }

        List<string> args = cameraLoader.ExtraArgToSingleList;

        float rotatOffset = MyConvert_Convert.ToSingle(args[0]);
        float height = MyConvert_Convert.ToSingle(args[2]);
        float distance = MyConvert_Convert.ToSingle(args[3]);

        Quaternion currentRotation = Quaternion.Euler(0, rotatOffset, 0);
        Vector3 pos = currentRotation * -Vector3.forward * distance;
        pos.y = height;

        pos = -pos;

        Vector3 direct = pos - 2 * Vector3.Dot(pos, Vector3.up) * Vector3.up;
        m_vector = direct;
    }
}
