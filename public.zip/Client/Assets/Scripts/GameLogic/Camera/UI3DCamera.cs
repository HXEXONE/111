﻿//using UnityEngine;
//using System.Collections;

//public class UI3DCamera  {

//    private GameObject uiRoot3D;
//    private Camera camera3D;
//    private UICamera uiCamera;
//    private Transform myTransform;
//    private GameObject anchorObj;
//    private UIAnchor anchor;

//    public UI3DCamera()
//    {
//        uiRoot3D = new GameObject();
//        uiRoot3D.name = "UI Root 3D";
//        uiRoot3D.transform.localPosition = Vector3.zero;
//        //uiRoot3D.transform.localPosition = new Vector3(800.0f,800.0f,800.0f);
//        uiRoot3D.transform.localScale = Vector3.one;
//        myTransform = uiRoot3D.transform;
//        uiRoot3D.layer = DEFINE.NGUI3D_LAYER;

//        UIRoot root = uiRoot3D.AddComponent<UIRoot>();
//        root.scalingStyle = UIRoot.Scaling.PixelPerfect;
//        root.manualHeight = 768;
//        root.minimumHeight = 320;
//        root.manualHeight = 1536;

//        CreateCamera();

//        UnityEngine.GameObject.DontDestroyOnLoad(uiRoot3D);
        
//    }

//    private void CreateCamera()
//    {
//        GameObject cameraObj = new GameObject("Camera 3D");
//        cameraObj.transform.parent = uiRoot3D.transform;
//        cameraObj.transform.localPosition = Vector3.zero;
//        cameraObj.layer = DEFINE.NGUI3D_LAYER;

//        //add camera component
//        camera3D = cameraObj.AddComponent<Camera>();
//        camera3D.cullingMask = 1 << DEFINE.NGUI3D_LAYER;
//        camera3D.clearFlags = CameraClearFlags.Depth;
//        camera3D.orthographic = false;
//        camera3D.depth = DEFINE.NGUI3D_DEPTH;                                 //这个深度到时候根据DEFINE 的变量控制，根据相机多少
//        camera3D.nearClipPlane = 0.1f;
//        camera3D.farClipPlane = 100.0f;
//        camera3D.fieldOfView = 60.0f;

//        //add uiCamera
//        uiCamera = cameraObj.AddComponent<UICamera>();
//        uiCamera.eventReceiverMask = 1 << DEFINE.NGUI3D_LAYER;
//        uiCamera.allowMultiTouch = false;

//        anchorObj = new GameObject("AnchorCenter");
//        anchorObj.transform.parent = cameraObj.transform;
//        anchorObj.transform.localPosition = new Vector3(0,0,660);
//        anchor = anchorObj.AddComponent<UIAnchor>();
//        anchor.uiCamera = camera3D;
//        anchor.side = UIAnchor.Side.Center;
//        anchorObj.layer = DEFINE.NGUI3D_LAYER;

        

//    }

//    public void CreatePanel(CPanel panel)
//    {
//        panel.ParentObj = anchorObj;
//        //这里可以做一些初始的其他事情
//    }

//    #region get and set

//    public UICamera GetUI3DCamera()
//    {
//        return uiCamera;
//    }

//    public GameObject GetUIRoot3D
//    {
//        get
//        {
//            if (uiRoot3D != null) return uiRoot3D;
//            else {
//                MyLog.LogError("could not find the UI Root 3D object ,please check code ");
//                return null; 
//            }
//        }
//    }

//    public Camera GetCamera3D
//    {
//        get
//        {
//            if (camera3D != null) return camera3D;
//            else
//            {
//                MyLog.LogError("could not find the 3D camera ,please check code ");
//                return null;
//            }
//        }
//    }

//    public Transform GetTransform
//    {
//        get
//        {
//            return myTransform;
//        }
//        set
//        {
//            myTransform = value;
//            uiRoot3D.transform.localPosition = myTransform.position;
//            uiRoot3D.transform.localScale = myTransform.localScale;
//            uiRoot3D.transform.localRotation = myTransform.rotation;
//        }
//    }

//    public Vector3 GetPostion
//    {
//        get
//        {
//            return uiRoot3D.transform.position; 
//        }
//        set {
//            uiRoot3D.transform.localPosition = value;
//        }
//    }

//    public void SetRect(Rect viewRect)
//    {

//        if (camera3D != null)
//        {
//            camera3D.rect = viewRect;
//        }

//    }

//    public float Depth
//    {
//        set
//        {
//            GetCamera3D.depth = value;
//        }
//    }

//    public bool AllowMultiTouch
//    {
//        get
//        {
//            if (uiCamera != null)
//            {
//                return uiCamera.allowMultiTouch;
//            }
//            else
//            {
//                return false;
//            }
//        }
//        set
//        {
//            if (uiCamera !=null)
//            {
//                uiCamera.allowMultiTouch = value;
//            }
//        }
//    }

//    #endregion

//}
