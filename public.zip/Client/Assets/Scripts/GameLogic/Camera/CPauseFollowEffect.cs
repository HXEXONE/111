﻿using UnityEngine;
using System.Collections;

public class CPauseFollowEffect : CCameraBase
{
    private uint m_cameaID;
    private GameObject m_currectFollowObject;
    private CCameraBase m_followEffect;
    private bool m_directEnter;

    public bool IsPauseFollow { get { return m_state != eCameraState.CAMERA_STATE_LEAVE; } }

    public CPauseFollowEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_PAUSE_FOLLOW;
        m_followEffect = CCamera.GetInst().GetExistEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW);
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);

        m_directEnter = m_fDelayTime == 0;

        if (m_followEffect == null)
        {
            m_followEffect = CCamera.GetInst().GetExistEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW);
        }

        if (m_followEffect == null)
        {
            SetState(eCameraState.CAMERA_STATE_LEAVE);
            return;
        }
        if (m_directEnter)
        {
            CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW, null);
        }
    }

    protected override void Enter()
    {
        base.Enter();
        if (!m_directEnter)
        {
            CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW, null);
        }

        CMusicManager.EVNSoundEnabled = false;
    }

    protected override void Leave()
    {
        base.Leave();
        if (m_followEffect != null)
        {
            CCamera.GetInst().SetCameraEffect(m_cameaID, null, null, new object[] { m_currectFollowObject, eCAMERAFOLLOW.SMOOTH, false ,false});
        }
    }

    public void SetParam(uint id, GameObject follow)
    {
        m_cameaID = id;
        m_currectFollowObject = follow;
    }
	
}
