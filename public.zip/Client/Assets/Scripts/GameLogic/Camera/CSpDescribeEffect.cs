﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CSpDescribeEffect : CCameraBase
{
    private CBaseNpc m_npc;
    private Transform m_boss;
    private Transform m_sceneCamTran;

    private Vector3 m_distance = new Vector3(0,7,10);

    private bool m_isBack;   //是过去还是回到英雄身边

    private object m_lockObject;

    public CSpDescribeEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_SPECIAL_DESRIBE;
        m_bSpecialEffect = false;
        CanReset = true;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);
        m_sceneCamTran = cameraObj.transform.parent;

        List<string> list = pInfo.ExtraArgToSingleList;
        m_isBack = MyConvert_Convert.ToBoolean(MyConvert_Convert.ToInt32(list[0]));


        if (!m_isBack)
        {
            m_npc = args[1] as Monster;
            if (m_npc == null)
            {
                SetState(eCameraState.CAMERA_STATE_LEAVE);
                return;
            }
            m_boss = m_npc.GetTransform();
            if (m_boss == null)
                SetState(eCameraState.CAMERA_STATE_LEAVE);

            m_lockObject = args[2];
        }
        else
            m_lockObject = args[1];
    }

    protected override void Enter()
    {
        if (m_isBack)
        {
            uint cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
            Avatar avatar = SingletonObject<Avatar>.GetInst();
            if (avatar.IsInRide())
            {
                CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, avatar.BakTrans.gameObject, eCAMERAFOLLOW.DIRECT, false,false);
            }
            else
            {
                CCamera.GetInst().SetCameraEffect(cameraID, m_lockObject, null, avatar.GetTransform().gameObject, eCAMERAFOLLOW.DIRECT, false,false);
            }
        }
        else
        {
            Vector3 pos = m_boss.position;

            SkinnedMeshRenderer[] smrs = m_boss.GetComponentsInChildren<SkinnedMeshRenderer>();

            if (smrs != null && smrs.Length > 0)
            {
                float modelHeight = m_npc.FBodyHeight;
                pos.y += modelHeight * 0.5f;
                m_distance.z = Common.GetCameraDistance(30, modelHeight * 1.7f);
                m_sceneCamTran.position = m_boss.forward * m_distance.z + pos;
                m_sceneCamTran.LookAt(pos);
            }
            else
            {
                pos.y += m_distance.y;
                m_sceneCamTran.position = m_boss.forward * m_distance.z + pos;
                m_sceneCamTran.LookAt(m_boss);
            }
        }
        SetState(eCameraState.CAMERA_STATE_LEAVE);
    }
}
