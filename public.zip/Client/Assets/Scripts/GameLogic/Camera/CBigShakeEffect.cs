﻿//using UnityEngine;

//public class CBigShakeEffect : CCameraBase
//{
//    /********************摄像机震动***********************/
//    private bool m_bShakeDirection;//前后震动
//    private float m_fCurrShakeDistance;//当前振动值
//    private float m_fLastShakeDistance;//上次振动值
//    private float m_fUpdateTime;//震动更新时间

//    private Transform m_shakeTransf;
//    /********************摄像机震动***********************/

//    private SceneContent m_sceneLoad;

//    public CBigShakeEffect() : base()
//    {
//        m_CameraType = eCAMERATYPE.CAMERA_TYPE_BIG_SHAKE;
//        base.m_bSpecialEffect = false;
//        m_fCurrShakeDistance = -1;
//        m_sceneLoad = null;
//    }

//    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
//    {
//        base.Init(pInfo, cameraObj, callback, args);
//        m_fCurrShakeDistance = MyConvert_Convert.ToSingle(m_pCameraInfo.GetExtraArgToSingleList()[0]);//摄像机震动初始距离

//        m_sceneLoad = SingletonObject<BattleScene>.GetInst().GetSceneLoader();

//    }

//    protected override void Enter()
//    {
//        m_bShakeDirection = true;
//        m_shakeTransf = m_pCameraObj.transform.parent;
//        m_fLastShakeDistance = 0;
//        m_fUpdateTime = Time.time;
//    //    ReSet(m_shakeTransf);
//    }

//    //protected override void Leave()
//    //{
//    //    base.Leave();
//    // //   CCamera.GetInst().SetCameraEffect(DEFINE.NORMAL_CAMERA_EFFECT);

//    //    if (m_sceneLoad == null)
//    //    {
//    //        m_sceneLoad = SingletonObject<BattleScene>.GetInst().GetSceneLoader();
//    //    //    ReSet(m_shakeTransf);
//    //    }
//    //    Transform trans =SingletonObject<Avatar>.GetInst().GetTransform();
//    //    GameObject o = trans.gameObject;
//    //    CCamera.GetInst().SetCameraEffect(m_sceneLoad.GetCameraID(),null,new object[]{o});
//    //}

//    protected override void UpdateMovement()
//    {
//        if (Time.time - m_fUpdateTime < 0.05f)
//        {
//            return;
//        }

//        m_fUpdateTime = Time.time;

//        if (m_bShakeDirection)
//        {
//            m_shakeTransf.Translate(0, 0, -m_fCurrShakeDistance - m_fLastShakeDistance, Space.Self);

//            m_fLastShakeDistance = m_fCurrShakeDistance;
//        }
//        else
//        {
//            m_shakeTransf.Translate(0, 0, m_fCurrShakeDistance + m_fLastShakeDistance, Space.Self);

//            m_fLastShakeDistance = m_fCurrShakeDistance;

//            m_fCurrShakeDistance -= 0.1F;//每次右震动后震动削弱
//        }

//        m_bShakeDirection = !m_bShakeDirection;

//        if (m_fCurrShakeDistance < 0)
//        {
//            SetState(eCameraState.CAMERA_STATE_LEAVE);
//        }
//    }
//}