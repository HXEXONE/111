using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CFollowEffect : CCameraBase
{
    private GameObject m_followObj;
    private float Fy;//������ĸ߶Ȳ���
    private float Fz;//������ľ������
    private float LookYOffset;//������Ŀ�������Ĳ���

    private Vector3 m_velocity = Vector3.zero;

    public Vector3 Velocity
    {
        get { return m_velocity; }
        set { m_velocity = value; }
    }

    private List<string> m_list;

    private Transform m_moveTrans;
    private Transform m_followTran;

    private float m_rotateOffset = 0;

    private bool m_smoothStep = false;
    private float m_speed = 5;   //�ٶȣ��������Һ�������ÿ����ٶ�
    private bool m_effectTimeScale;  //�ƶ��Ƿ����ӵ�ʱ��Ӱ��

    private float m_sinVal;
    private float m_distance;

    private Vector3 m_disparity;

    private eCAMERAFOLLOW m_followType;

    private CPauseFollowEffect m_pauseFollowEffect;

    private bool m_bSetFOV = false;

    public CFollowEffect()
        : base()
    {
        m_CameraType = eCAMERATYPE.CAMERA_TYPE_FOLLOW;
        base.m_bSpecialEffect = true;//����Ǹ��澵ͷ,���ᱻ������������

        m_pauseFollowEffect = CCamera.GetInst().GetExistEffect(eCAMERATYPE.CAMERA_TYPE_PAUSE_FOLLOW) as CPauseFollowEffect;
    }

    public override void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        base.Init(pInfo, cameraObj, callback, args);
        m_followObj = (GameObject)args[0];
        m_followType = (eCAMERAFOLLOW)args[1];
        m_effectTimeScale = (bool)args[2];
        if (args.Length > 3)
            m_bSetFOV = (bool)args[3];
        else
            m_bSetFOV = true;

        if (m_followObj)
        {
            MyLog.LogError("---------------  " + m_followObj.name + "  --------------");
            m_followTran = m_followObj.transform;
        }

//         if (CMusicManager.GetInst().SoundEnabled)
//         {
//             CMusicManager.EVNSoundEnabled = true;
//         }

//         if (CMusicManager.GetInst().SoundEnabled)
//         {
//             bool followAvatar = false;
// 
//             CPlayer player = SingletonObject<CPlayer>.GetInst();
//             if (null != player.gameObject)
//             {
//                 followAvatar = m_followObj == player.gameObject;
//             }
//             else
//             {
//                 Avatar avatar = SingletonObject<Avatar>.GetInst();
//                 if (null != avatar.GetObject())
//                 {
//                     GameObject avatarGo = avatar.GetObject().gameCObject;
//                     if (null != avatarGo)
//                     {
//                         float distance = Vector3.Distance(avatarGo.transform.position, m_followObj.transform.position);
//                         followAvatar = distance < 5f;
//                     }
//                 }
//             }
// 
//             AudioSource[] audios = CBaseSceneLoading.EVNAudios;
//             if (null != audios)
//             {
//                 for (int i = 0, len = audios.Length; i < len; i++)
//                 {
//                     audios[i].enabled = followAvatar;//����������avatar�����Ч��
//                 }
//             }     
//         }
        

   

        m_list = m_pCameraInfo.ExtraArgToSingleList;
        //m_velocity.x = MyConvert_Convert.ToSingle(m_list[0]);
        //m_velocity.y = MyConvert_Convert.ToSingle(m_list[1]);
        //m_velocity.z = MyConvert_Convert.ToSingle(m_list[2]);
        //s_fildOfView = MyConvert_Convert.ToSingle(m_list[3]);

        m_rotateOffset = MyConvert_Convert.ToSingle(m_list[0]);
        s_fildOfView = MyConvert_Convert.ToSingle(m_list[1]);
        Fy = MyConvert_Convert.ToSingle(m_list[2]);
        Fz = MyConvert_Convert.ToSingle(m_list[3]);
        LookYOffset = MyConvert_Convert.ToSingle(m_list[4]);
        m_speed = MyConvert_Convert.ToSingle(m_list[5]);

        m_disparity = Vector3.zero;

        if (m_pauseFollowEffect == null)
        {
            m_pauseFollowEffect = CCamera.GetInst().GetExistEffect(eCAMERATYPE.CAMERA_TYPE_PAUSE_FOLLOW) as CPauseFollowEffect;
        }
        if (m_pauseFollowEffect != null)
        {
            m_pauseFollowEffect.SetParam((uint)pInfo.Key, m_followObj);
        }

        Enter();
    }


    protected override void Enter()
    {
        //     Vector3 position = m_pAvatarTrans.position + new Vector3(0, Fy, -Fz);
        //Vector3 position = m_followObj.transform.position + m_velocity;
        m_moveTrans = m_pCameraObj.transform.parent;
        //m_moveTrans.position = position;
        //m_moveTrans.LookAt(m_followObj.transform.position);

        if (m_followType != eCAMERAFOLLOW.SMOOTH)
            m_pCameraObj.transform.localRotation = Quaternion.identity;

        //RotateCam();

        if (CMusicManager.GetInst().SoundEnabled)
        {
            CMusicManager.EVNSoundEnabled = true;
        }

        CMusicManager.GetInst().FollowObj = m_followObj;

        ResetParam(m_rotateOffset, Fy, Fz, m_followType, m_speed);

        SetState(eCameraState.CAMERA_STATE_UPDATE);
    }

    protected override void UpdateMovement()
    {
        if (null == m_followTran)
        {
            return;
        }
        //Vector3 position = m_pAvatarTrans.position + new Vector3(0, Fy, -Fz);

        Vector3 position = m_followTran.position + m_velocity;

        if (m_followType == eCAMERAFOLLOW.ROTATE)
        {
            if (m_distance == 0f || m_sinVal == 90)
            {
                m_followType = eCAMERAFOLLOW.SMOOTH;
                m_sinVal = 0;
                return;
            }
            if (m_effectTimeScale)
                m_sinVal += Time.deltaTime * m_speed;
            else
                m_sinVal += Time.deltaTime * m_speed / Common.TimeScale;
            m_sinVal = Mathf.Min(90, m_sinVal);

            float sinVal = Mathf.Sin(Mathf.Deg2Rad * m_sinVal);

            m_moveTrans.position = Vector3.Lerp(m_moveTrans.position, position, sinVal);
            m_moveTrans.LookAt(m_followTran.position + new Vector3(0, LookYOffset, 0) + m_disparity);

            m_disparity = Vector3.Lerp(m_disparity, Vector3.zero, sinVal);
            m_distance = Vector3.Distance(m_moveTrans.position, position);

            if (m_distance <= 0.01f)
                m_sinVal = 90;

            if (m_bSetFOV)
                m_pCameraObj.camera.fieldOfView = s_fildOfView;
        }
        else if (m_followType == eCAMERAFOLLOW.SMOOTH)
        {
            if (m_effectTimeScale)
                m_moveTrans.position = Vector3.Lerp(m_moveTrans.position, position, Time.deltaTime * 5);
            else
                m_moveTrans.position = Vector3.Lerp(m_moveTrans.position, position, Time.deltaTime * 5 / Common.TimeScale);
            m_disparity = m_moveTrans.position - position;

            if (m_bSetFOV)
                m_pCameraObj.camera.fieldOfView = Mathf.Lerp(m_pCameraObj.camera.fieldOfView, s_fildOfView, Time.deltaTime * 5); ;
        }
        else if (m_followType == eCAMERAFOLLOW.SMOOTH)
        {
            if (m_effectTimeScale)
                m_moveTrans.position = Vector3.Lerp(m_moveTrans.position, position, Time.deltaTime * 2.5f);
            else
                m_moveTrans.position = Vector3.Lerp(m_moveTrans.position, position, Time.deltaTime * 2.5f / Common.TimeScale);
            m_disparity = m_moveTrans.position - position;

            if (m_bSetFOV)
                m_pCameraObj.camera.fieldOfView = Mathf.Lerp(m_pCameraObj.camera.fieldOfView, s_fildOfView, Time.deltaTime * 2.5f); ;
        }
        else
        {
            m_moveTrans.position = position;
        }
    }


    private void RotateCam()
    {
        Quaternion currentRotation = Quaternion.Euler(0, m_rotateOffset, 0);
        Vector3 pos = m_followTran.position - currentRotation * Vector3.forward * Fz;
        pos.y = m_followTran.position.y + Fy;
        m_moveTrans.position = pos;
        
        m_velocity = pos - m_followTran.position;

        m_moveTrans.LookAt(m_followTran.position + new Vector3(0, LookYOffset, 0));
    }

    public void ResetParam(float rotatOffset, float height, float distance, eCAMERAFOLLOW followType, float speed)
    {
        m_followType = followType;
        if (m_followType == eCAMERAFOLLOW.SMOOTH)
            return;

        Quaternion currentRotation = Quaternion.Euler(0, rotatOffset, 0);
        Vector3 pos = m_followTran.position - currentRotation * Vector3.forward * distance;
        pos.y = m_followTran.position.y + height;
        m_velocity = pos - m_followTran.position;

        if (m_followType == eCAMERAFOLLOW.DIRECT)
        {
            m_moveTrans.position = pos;
            m_moveTrans.LookAt(m_followTran.position + new Vector3(0, LookYOffset, 0));
            m_followType = eCAMERAFOLLOW.SMOOTH;


            if (ClientMain.IsSupportShadowRunTime)
            {
                if (ShadowManagerEx.GetInst())
                    ShadowManagerEx.GetInst().ChangeFollowTransform(m_pCameraObj.camera, m_moveTrans, m_followTran, pos);
            }
        }
        else
        {
            m_speed = speed;
            m_sinVal = 0;
            m_distance = 1;
        }
    }

    public void ResetParam(eCAMERAFOLLOW followType, float speed)
    {
        ResetParam(m_rotateOffset, Fy, Fz, followType, speed);
    }
}
