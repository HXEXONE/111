﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;


public class CCameraBase
{
    protected eCAMERATYPE     m_CameraType;

    protected float m_fDelayTime;//延时时间
    protected float m_fLastTime = 0;//持续时间

    protected float m_fStartTime;//开始计时时间

    protected GameObject m_pCameraObj;//摄像机

    protected CameraContent m_pCameraInfo;

    protected RegisterEvent m_callback;//回调函数
    protected object[] m_args;//回调函数的参数

    protected eCameraState m_state;

    protected bool m_bSpecialEffect;

    private bool m_canReset;

    public static float s_fildOfView = 40;

    public bool CanReset
    {
        get { return m_canReset; }
        set { m_canReset = value; }
    }

    protected bool m_ignoreTimeScale = false;

    public CCameraBase()
    {
        m_state = eCameraState.CAMERA_STATE_LEAVE;
    }

    public virtual void Init(CameraContent pInfo, GameObject cameraObj, RegisterEvent callback, params object[] args)
    {
        if ( null == pInfo)
        {
            MyLog.Log("null == pInfo");
            return;
        }
        m_pCameraInfo = pInfo;
        m_fDelayTime = pInfo.DelayTime;
        m_fLastTime = pInfo.LastTime;
        m_args = args;
        m_callback = callback;

        m_pCameraObj = cameraObj;

        //m_fStartTime = Time.time;
        m_fStartTime = 0;
        m_state = eCameraState.CAMERA_STATE_WAIT;
    }

    public virtual eCAMERATYPE GetCameraType()
    {
        return m_CameraType;
    }

    public virtual bool isSpecialEffect()
    {
        return m_bSpecialEffect;
    }

    //是否正在运转
    public bool IsOperate()
    {
        return m_state != eCameraState.CAMERA_STATE_LEAVE;
    }

    public bool IsForward()
    {
        return m_state == eCameraState.CAMERA_STATE_UPDATE;
    }

    public void SetState(eCameraState state)
    {
        //m_fStartTime = Time.time;
        m_fStartTime = 0;
        if (m_state == state)
        {
            return;
        }
        m_state = state;

        switch (state)
        {
            case eCameraState.CAMERA_STATE_ENTER:
                {
                    Enter();
                }
                break;
            case eCameraState.CAMERA_STATE_LEAVE:
                {
                    Leave();
                }
                break;
        }
    }

    //只会进入一次
    protected virtual void Enter()
    {
    }

    //只会进入一次
    protected virtual void Leave()
    {
        if (m_callback != null)
        {
            m_callback(m_args);
        }
    }
    protected virtual void Wait()
    {
        if (UpdateStartTime(true) >= m_fDelayTime)//延时播放
        {
            SetState(eCameraState.CAMERA_STATE_ENTER);
        }
    }

    public bool Update()
    {
        if (m_pCameraObj == null)
        {
            return false;
        }

        switch (m_state)
        {
            case eCameraState.CAMERA_STATE_WAIT:
                {
                    Wait();
                }
                break;
            case eCameraState.CAMERA_STATE_ENTER:
                {
                    //如果是非特殊摄像机效果的话停止其他一些非特殊摄像机效果
                    if (!isSpecialEffect())
                    {
                        //CCamera.GetInst().PauseOtherCameraEffect(m_CameraType, false);
                    }

                    SetState(eCameraState.CAMERA_STATE_UPDATE);
                }
                break;
            case eCameraState.CAMERA_STATE_UPDATE:
                {
                    UpdateMovement();

                    if (m_fLastTime > 0 && UpdateStartTime() >= m_fLastTime)//持续时间
                    {
                        SetState(eCameraState.CAMERA_STATE_LEAVE);
                    }

                }
                break;
        }

        return true;

    }

    //更新时时运动的状态
    protected virtual void UpdateMovement()
    {

    }

    protected void ReSet(Transform tran)
    {
        tran.localPosition = Vector3.zero;
        tran.localRotation = Quaternion.identity;
        //Transform pAvatarTrans = SingletonObject<Avatar>.GetInst().GetTransform();
        //tran.parent.LookAt(pAvatarTrans);
    }

    private float UpdateStartTime(bool error = false)
    {
        if (error)
            m_fStartTime += Time.deltaTime;
        else
            m_fStartTime += m_ignoreTimeScale ? Time.deltaTime / Common.TimeScale : Time.deltaTime;
         return m_fStartTime;
    }
}