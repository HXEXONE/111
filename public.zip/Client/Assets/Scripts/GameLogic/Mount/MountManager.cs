﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;
using System;

public class MountManager : SingletonObject<MountManager>   
{
    public uint CurMountID = 0;
    public uint CurMountExp = 0;
    private uint m_foodID;
    private int noneValueFlag = 0;            //tech表的list是0标识
    private int normalValueFlag = 1;       //普通属性值标识
    private int percentValueFlag = 2;      //百分比值标识

#region 新界面
    public uint curMountWish;      //祝福值
    public uint clearTime;         //清空时间
    public bool isAuto;
    public uint mountBuffLeftSeconds;    //坐骑口粮喂食BUFF剩余秒数,没有BUFF时是0

    public List<long> endTimeList = new List<long>();
    private ItemAddAttriInfo addInfo;

#endregion


    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_SEND_CLIENT_MOUNTSINFO, GetMountInfo,false);            //false服务端主动推送，true请求返回的消息
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_UPGRADE_MOUNTS, MountUpgradeAck,true);
    }

    private void MountUpgradeAck(BinaryReader br)
    {
        G2CUpgradeMountsResult msg = new G2CUpgradeMountsResult();
        msg.Read(br);

        switch (msg.uiResult)
        {
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_Success:
                //CurExpStr = msgPetResult.PetInfo.uiPetExp;
                CurMountID = msg.MountsInfo.uiMountsID;
                curMountWish = msg.MountsInfo.uiWishValue;               //祝福值
                clearTime = msg.MountsInfo.uiEmptyRemainTime;           //清空时间  
                mountBuffLeftSeconds = msg.MountsInfo.uiMountBuffLeftSeconds;

                MyLog.Log("ID:" + CurMountID + " clearTime" + clearTime);
                if (SingletonObject<MountNewMediator>.GetInst().IsOpen)
                {
                    ////刷新数据
                    isAuto = true;
                    SingletonObject<MountNewMediator>.GetInst().upDataAvatar(CurMountID, false);
                    SingletonObject<MountNewMediator>.GetInst().initFoodNum(CurMountID);
                }

                //SingletonObject<CPlayer>.GetInst().ReLoadPet(CurMountID);
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_NoPlayer:
                string str = Common.GetText(9950011);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_NoItemID:
                str = Common.GetText(9950012);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_NotEnought:
                str = Common.GetText(9950013);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumInsertPetData_LevelLimilt:
                str = Common.GetText(9950014);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_MapLimilt:
                str = Common.GetText(9950015);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_ConsumeItemFaild:
                str = Common.GetText(9950016);
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_DiamondNotEnough:
                SingletonObject<MountNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                SingletonObject<MountNewMediator>.GetInst().gotoShop();
                break;
            case (ushort)EnumUpgradePetResult.EnumUpgradePetResult_ModuleNotOpen:
                SingletonObject<PetNewMediator>.GetInst().isAutoJj = false;
                SingletonObject<MountNewMediator>.GetInst().setAutoState();
                str = Common.GetText(9100087);      //还未开启
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(str);
                break;
        }
        
    }

    private void GetMountInfo(BinaryReader br)
    {
        G2CSendMountsInfo msg = new G2CSendMountsInfo();
        msg.Read(br);
        CurMountID = msg.uiMountsID;
        curMountWish = msg.uiWishValue;
        clearTime = msg.uiEmptyRemainTime;
        mountBuffLeftSeconds = msg.uiMountBuffLeftSeconds;
        addInfo = msg.sItemAddAttriInfo;
        MyLog.Log(CurMountID + "   " + curMountWish + "   " + clearTime);

        if (SingletonObject<MountNewMediator>.GetInst().IsOpen)
        {

            if (SingletonObject<MountNewMediator>.GetInst().isFirstOp)
            {
                SingletonObject<MountNewMediator>.GetInst().isFirstOp = false;
                SingletonObject<MountNewMediator>.GetInst().openDate();
            } 
            else
            {
                SingletonObject<MountNewMediator>.GetInst().onClearTime();
            }
        }
    }

    /// <summary>
    /// 请求升级
    /// </summary>
    /// <param name="upgradeinfo"></param>
    public void MountUpgradeReq(C2GUpgradeMounts mount)
    {
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_UPGRADE_MOUNTS, (ushort)ProCG.GAME_ACK_CLIENT_UPGRADE_MOUNTS, mount);
    }

    /// <summary>
    /// 每次打开界面时请求基本数据
    /// </summary>
    public void mountInfo()
    {
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_MOUNTINFO, (ushort)ProCG.GAME_SEND_CLIENT_MOUNTSINFO, null);
    }


    /// <summary>
    /// 计算战力
    /// </summary>
    public int GetMountGS(uint mountid, ItemAddAttriInfo addinfo)
    {
        if (mountid == 0)
        {
            MyLog.LogError("Partner id is "+mountid+"please check");
            return 0;
        }
        MountsContent mountloader = HolderManager.m_MountsHolder.GetStaticInfo(mountid);
        TechContent loader = HolderManager.m_TechHolder.GetStaticInfo(mountloader.MountsPropertyID);
        float live = 0;
        float gongji = 0;
        float fangyu = 0;
        float minzhong = 0;
        float shanbi = 0;
        float baoji = 0;
        float baojishanghai = 0;
        //float wupindiaoluo = 0;
        float speed = 0;
        if (loader.Livevaluemax[0] == normalValueFlag)
            live = (float)loader.Livevaluemax[1] + addinfo.fHp;
        if (loader.Attackvaluemax[0] == normalValueFlag)
            gongji = (float)loader.Attackvaluemax[1] + addinfo.fAttack;
        if (loader.Fangyuvalue[0] == normalValueFlag)
            fangyu = (float)loader.Fangyuvalue[1] + addinfo.fDefense;
        if (loader.Mingzhongvalue[0] == normalValueFlag)
            minzhong = (float)loader.Mingzhongvalue[1] + addinfo.fHit;
        if (loader.Shanbivalue[0] == normalValueFlag)
            shanbi = (float)loader.Shanbivalue[1] + addinfo.fDodge;
        if (loader.Baoji[0] == normalValueFlag)
            baoji = (float)loader.Baoji[1] + addinfo.fCrit;
        if (loader.Baojishanghai[0] == normalValueFlag)
            baojishanghai = (float)loader.Baojishanghai[1] / 10000.0f + addinfo.fCritHurt;
        else if (loader.Baojishanghai[0] == percentValueFlag)
        {
            baojishanghai = (float)loader.Baojishanghai[1] / 10000.0f + addinfo.fCritHurt;
        }
        if (loader.Movespeed[0] == normalValueFlag)
            speed = (float)loader.Movespeed[1] + addinfo.fSpeed;
        else if (loader.Movespeed[0] == percentValueFlag)
        {
            speed = ((float)loader.Movespeed[1] + addinfo.fSpeed) / 10000f;
        }
        //float gs = live * 0.4f + gongji + fangyu + minzhong * 4.8f + shanbi * 4.8f + baoji * 4.8f + baojishanghai * 4000 + speed * 40000;
        float gs = Common.GetGs(live, gongji, fangyu, minzhong, shanbi, baoji, baojishanghai, speed);
        return (int)gs;
    }


    public uint InitFoodData(uint foodid)
    {
        ItemContent loader = HolderManager.m_ItemHolder.GetStaticInfo(foodid);
        uint num = 0;
        long curTime = timeStamp();
        List<PackItemInfo> itemList = ItemManager.GetInst().GetMountFoodItemList();
       // MyLog.LogError("itemList.count =" + itemList.Count);
        if (itemList != null)
        {
            if (itemList.Count > 0)
            {
                for (int i = 0; i < itemList.Count; i++)
                {
                    if (itemList[i].uiItemId == foodid)
                    {
                        if (itemList[i].iStartTime == 0 && itemList[i].iEndTime == 0)
                        {
                            num += itemList[i].uiItemNum;
                        }
                        else
                        {
                            if (curTime >= itemList[i].iStartTime && curTime < itemList[i].iEndTime)
                            {
                                
                                num += itemList[i].uiItemNum;
                                endTimeList.Add(itemList[i].iEndTime);
                                //MyLog.LogError(itemList[i].iStartTime + "   " + itemList[i].iEndTime + "  endTimeList.Count " + endTimeList.Count);
                            }
                            else
                            {
                                num = 0;
                            }
                        }
                    }
                }
            }
        }
        return num;
    }
    /// <summary>
    /// 时间戳
    /// </summary>
    /// <returns></returns>
    private long timeStamp()
    {
        return (DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
    }

    public string nearTime()
    {
        //Debug.Log(endTimeList.Count + " endTimeList.Count " );
        if (endTimeList == null || endTimeList.Count <= 0)
        {
            return " ";
        }
        endTimeList.Sort();
        
        string time = FQAManager.instance.UnixTimestampToDateTime(endTimeList[0].ToString());
        //Debug.Log(endTimeList.Count + " endTimeList.Count " + time);
        return time;
    }

    public ItemAddAttriInfo getAddInfo()
    {
        return addInfo;
    }
}
