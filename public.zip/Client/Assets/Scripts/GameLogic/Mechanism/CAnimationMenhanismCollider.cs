﻿using UnityEngine;
using System.Collections;

public class CAnimationMenhanismCollider : MonoBehaviour {

    public CAnimationMechanism m_animationMechanism;


    void OnTriggerEnter(Collider other)
    {
        if (!other.isTrigger || m_animationMechanism == null)
        {
            Common.IgnoreCollision(this.collider, other, true);
            return;
        }

        if (!other.gameObject.name.Equals("TriggerObject"))
        {
            Common.IgnoreCollision(this.collider, other, true);
            return;
        }

        int layer = other.transform.root.gameObject.layer;
        layer = 1 << layer;
        if ((layer & m_animationMechanism.Layers) > 0)
        {
            m_animationMechanism.Trigger(other, m_animationMechanism);
            return;
        }
        else
        {
            Common.IgnoreCollision(this.collider, other, true);
        }
    }
}
