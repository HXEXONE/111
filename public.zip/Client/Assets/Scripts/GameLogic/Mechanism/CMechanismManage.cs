﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CMechanismManage : SingletonObject<CMechanismManage> {

    private Dictionary<uint, CBaseMechanism> m_mechanismDirect = new Dictionary<uint, CBaseMechanism>();
    //private List<uint> m_mechanismTempList = new List<uint>();
    //private Dictionary<string, Transform> m_swapMechanismTempDirect = new Dictionary<string, Transform>();
    //private List<string> m_deleteList = new List<string>();
    private Dictionary<uint, string[]> m_tempArgsDirect = new Dictionary<uint, string[]>();
    private Transform m_modeObject;
    private Transform m_mechanismObject;
    private Dictionary<string, Transform> m_mechanismList = new Dictionary<string,Transform>();

    //private int m_mechanismCount = 0;
    private int m_loadCount = 0;
    private int m_layers;

    private int m_navMeshLayers = 0;
    public int NavMeshLayers
    {
        get { return m_navMeshLayers; }
    }

    //private eMechanismState m_state = eMechanismState.None;

    private void AddMechanism(uint ID,CBaseMechanism mechanism)
    {
        if (m_mechanismDirect.ContainsKey(ID))
        {
            MyLog.LogError("CMechanismManage AddMechanism has same Key ID : " + ID.ToString());
            Object.Destroy(mechanism.gameObject);
            return;
        }
        m_mechanismDirect.Add(ID,mechanism);

        MechanismContent info = HolderManager.m_MechanismHolder.GetStaticInfo(ID);

        List<string> args = info.Args;
        string[] argsArry = new string[args.Count];
        args.CopyTo(argsArry);

        eMechanism type = (eMechanism)info.MechanismType;
        switch (type)
        {
            case eMechanism.DropOut: mechanism.Layers = 1 << DEFINE.TERRAINLAYER; break;
            default: mechanism.Layers = m_layers; break;
        }
        mechanism.ScriotID = info.Script;
        mechanism.Callback = OnTriggerCallback;
        mechanism.TriggerCount = info.TriggerCount;
        mechanism.TriggerSpaceTime = info.SpaceTime;
        mechanism.CompletedHide = info.CompletedHide;

        string layerName = info.NavMeshLayerName;

        int layer = 1 << NavMesh.GetNavMeshLayerFromName(layerName);
        m_navMeshLayers |= layer;

        OpenOrCloseNavMeshLayersMask(null,layer, false);

        m_loadCount++;

        m_tempArgsDirect.Add(ID, argsArry);

        //if (m_loadCount >= m_mechanismCount)
        //{
        //    StartMechanism();
        //}
    }

    private void StartMechanism()
    {
        CBaseMechanism temp;
        foreach(KeyValuePair<uint,CBaseMechanism> val in m_mechanismDirect)
        {
            temp = val.Value;
            uint id;
            if (temp is CTriggerMechanism)
            {
                id = MyConvert_Convert.ToUInt32(m_tempArgsDirect[val.Key][0]);
                ((CTriggerMechanism)temp).m_caMechanism = m_mechanismDirect[id];
            }
            temp.Init(m_tempArgsDirect[val.Key]);
        }
        m_tempArgsDirect.Clear();
    }

    public void Init(Transform modeTran,Transform mechanismObject,int layers)  //不需要sceneTran名字
    {
        CBaseMechanism.m_debug = false;

        m_layers = layers;

        m_modeObject = modeTran;
        m_mechanismObject = mechanismObject;

        if (m_modeObject == null || m_mechanismObject == null)
        {
            Release(true);
            return;
        }

        int childCount = m_mechanismObject.childCount;
        if (childCount <= 0)
        {
            Release(true);
            return;
        }

        Transform child;
        string childName;
        for (int i = 0; i < childCount; i++)
        {
            child = m_mechanismObject.GetChild(i);
            if (child == null)
            {
                MyLog.LogError("CMechanismManage Init GetChild is null. Index = " + i.ToString());
                continue;
            }
            childName = child.name;
            if (childName.Length > 7 && childName.Contains("Clone"))
                childName = childName.Remove(childName.Length - 7);


            child.gameObject.SetActive(false);
            if (m_mechanismList.ContainsKey(childName))
            {
                MyLog.LogError("CMechanismManage Init has same ID : " + childName);
                continue;
            }
            m_mechanismList.Add(childName,child);
        }

        childCount = m_modeObject.childCount;
        //m_mechanismCount = 0;
        Transform temp;
        uint id;
        string[] names;
        for (int i = 0; i < childCount; i++)
        {
            temp = m_modeObject.GetChild(i);
            string name = temp.name;
            if (!name.Contains("mechanism"))
                continue;

            names = name.Split('_');
            if (names.Length != 2)
                continue;

            if (m_mechanismList.ContainsKey(name))
            {
                id = MyConvert_Convert.ToUInt32(names[1]);
                InitMechanism(m_mechanismList[name].gameObject, id);
            }
            //if (m_swapMechanismTempDirect.ContainsKey(names[1]))
            //{
            //    MyLog.LogError("CMechanismManage Init has same ID : " + name);
            //    continue;
            //}
            //m_swapMechanismTempDirect.Add(names[1], temp);
        }

        StartMechanism();


        //m_mechanismCount = m_swapMechanismTempDirect.Count;

        //foreach (KeyValuePair<string, Transform> val in m_swapMechanismTempDirect)
        //{
        //    id = MyConvert_Convert.ToUInt32(val.Key);
        //    CreateMechanism(id);
        //}
    }

    private void InitMechanism(GameObject mechanism, uint id)
    {
        Transform mecTran = mechanism.transform;

        CBaseMechanism mechanismSp = null;
        if (mecTran.childCount > 0)
            mechanismSp = mecTran.GetChild(0).GetComponent<CBaseMechanism>();
        else
            mechanismSp = mecTran.GetComponent<CBaseMechanism>();

        if (mechanismSp == null)
        {
            MechanismContent ml = HolderManager.m_MechanismHolder.GetStaticInfo(id);
            if (ml != null)
            {
                switch ((eMechanism)ml.MechanismType)
                {
                    case eMechanism.AnimationMechanism: mechanismSp = mechanism.AddComponent<CAnimationMechanism>(); break;
                    case eMechanism.TriggerMechanism: mechanismSp = mechanism.AddComponent<CTriggerMechanism>(); break;
                    case eMechanism.ColliderMechanism: mechanismSp = mechanism.AddComponent<CColliderMechanism>(); break;
                    case eMechanism.DropOut: mechanismSp = mechanism.AddComponent<CDropOutMechanism>(); break;
                    case eMechanism.MagicPortal: mechanismSp = mechanism.AddComponent<CMagicPortal>(); break;
                    default: break;
                }

                if (mechanismSp == null)
                {
                    MyLog.LogError("CMechanismManage LoadCompleted Can not find type : " + ml.GetType());
                    return;
                }
            }
        }
        mechanism.SetActive(true);
        AddMechanism(id, mechanismSp);
    }

    //private void CreateMechanism(uint ID)   //for one frame
    //{
    //    MechanismContent info = HolderManager.m_MechanismHolder.GetStaticInfo(ID);
    //    if (info == null)
    //    {
    //        MyLog.LogError("CMechanismManage CreateMechanism can not find Mechanism, ID : " + ID.ToString());
    //        return;
    //    }
    //    //LoadHelp.LoadObject(ID.ToString(), info.Path, ThreadPriority.Normal, LoadCompleted);
    //}

    //private void CreateMechanism()   //for Update
    //{
    //    if (m_mechanismTempList.Count <= 0)
    //    {
    //        //m_state = eMechanismState.None;
    //        return;
    //    }
    //    uint ID = m_mechanismTempList[0];
    //    m_mechanismTempList.RemoveAt(0);
    //    MechanismContent info = HolderManager.m_MechanismHolder.GetStaticInfo(ID);
    //    if (info == null)
    //    {
    //        MyLog.LogError("CMechanismManage CreateMechanism can not find Mechanism, ID : " + ID.ToString());
    //        return;
    //    }

    //    LoadHelp.LoadObject(ID.ToString(), info.Path, ThreadPriority.Normal, LoadCompleted);
    //}

    //private void LoadCompleted(string msg, UnityEngine.Object asset)
    //{
    //    if (null == asset) { MyLog.LogError("" + msg); return; }
    //    GameObject mechanism = Object.Instantiate(asset) as GameObject;

    //    mechanism.SetActive(true);

    //    DynamicShader.ReplaceUnSupportShader(mechanism);

    //    InitLoadMechanism(mechanism, msg);
    //}

    //private void InitLoadMechanism(GameObject mechanism,string MSG_ID )
    //{
    //    Transform temp = m_swapMechanismTempDirect[MSG_ID];
    //    Transform mecTran = mechanism.transform;
    //    mecTran.parent = temp.parent;
    //    mecTran.localPosition = temp.localPosition;
    //    mecTran.localRotation = temp.localRotation;
    //    mecTran.localScale = temp.localScale;

    //    mechanism.name = temp.name;

    //    CBaseMechanism mechanismSp = null;
    //    if (mecTran.childCount > 0)
    //        mechanismSp = mecTran.GetChild(0).GetComponent<CBaseMechanism>();
    //    else
    //        mechanismSp = mecTran.GetComponent<CBaseMechanism>();

    //    uint id = MyConvert_Convert.ToUInt32(MSG_ID);
    //    if (mechanismSp == null)
    //    {
    //        MechanismContent ml = HolderManager.m_MechanismHolder.GetStaticInfo(id);
    //        if (ml != null)
    //        {
    //            switch ((eMechanism)ml.MechanismType)
    //            {
    //                case eMechanism.AnimationMechanism: mechanismSp = mechanism.AddComponent<CAnimationMechanism>(); break;
    //                case eMechanism.MoveMechanism: mechanismSp = mechanism.AddComponent<CMoveMechanism>(); break;
    //                case eMechanism.PrickMechanism: mechanismSp = mechanism.AddComponent<CPrickMechanism>(); break;
    //                case eMechanism.TriggerMechanism: mechanismSp = mechanism.AddComponent<CTriggerMechanism>(); break;
    //                case eMechanism.ColliderMechanism: mechanismSp = mechanism.AddComponent<CColliderMechanism>(); break;
    //                case eMechanism.DropOut: mechanismSp = mechanism.AddComponent<CDropOutMechanism>(); break;
    //                default: break;
    //            }

    //            if (mechanismSp == null)
    //            {
    //                MyLog.LogError("CMechanismManage LoadCompleted Can not find type : " + ml.GetType());
    //                return;
    //            }
    //        }
    //    }

    //    AddMechanism(id, mechanismSp);
    //    Object.Destroy(temp.gameObject);
    //}

    private void OnTriggerCallback(Collider other,CBaseMechanism mechanism, MechanismRevertCallback callback)
    {
        uint npcIndex = MyConvert_Convert.ToUInt32(other.transform.root.name);
        CBaseNpc npc = SingletonObject<BattleScene>.GetInst().GetNpc(npcIndex);
        if (npc != null && !npc.IsDead())
        {
            int count = mechanism.ScriotID.Count;

            int[] scriptIDList = new int[count];
            mechanism.ScriotID.CopyTo(scriptIDList);

            for (int i = 0; i < count; i++)
            {
                ScriptManager.RequestScript((uint)scriptIDList[i], npc);
            }
        }

        if (callback != null)
        {
            callback();
        }
    }

    public void Release(bool delete)
    {
        if (delete)
        {
            foreach (KeyValuePair<uint, CBaseMechanism> val in m_mechanismDirect)
            {
                if (val.Value != null)
                    Object.Destroy(val.Value.gameObject);
            }
        }

        m_mechanismDirect.Clear();
        //m_mechanismTempList.Clear();
        //m_swapMechanismTempDirect.Clear();
        m_tempArgsDirect.Clear();
        //m_mechanismCount = 0;
        m_loadCount = 0;
        m_layers = 0;
        m_modeObject = null;
        m_mechanismObject = null;
        m_mechanismList.Clear();
    }

    public void TriggerMechanism(params string[] param)
    {
        if (param == null || param.Length != 2)
            return;
        uint id = MyConvert_Convert.ToUInt32(param[0]);
        if (m_mechanismDirect.ContainsKey(id))
        {
            MechanismContent info = HolderManager.m_MechanismHolder.GetStaticInfo(id);
            float animationSpeed = info.AnimationSpeed;
            int layer = 1 << NavMesh.GetNavMeshLayerFromName(info.NavMeshLayerName);
            OpenOrCloseNavMeshLayersMask(null,layer, true);
            if (info.MoveCamera)
            {
                Transform tran = m_mechanismDirect[id].transform;
                Animation[] anis = tran.GetComponentsInChildren<Animation>();
                float delayTime = 0;
                float parkTime = 0;
                if (anis != null && anis.Length > 0)
                {
                    AnimationState state = anis[0][param[1]];
                    if (state != null)
                    {
                        delayTime = state.length / animationSpeed;
                        state.speed = animationSpeed;

                        parkTime = info.ParkTime;

                        delayTime += parkTime;
                    }
                }
                MoveCamera(tran, info.CameraOffSet, delayTime);
            }
            m_mechanismDirect[id].TriggerOther(param);
            uint nextMechanism = (uint)info.NextMechanismID;
            if (m_mechanismDirect.ContainsKey(nextMechanism))
                m_mechanismDirect[nextMechanism].TriggerOther(null);
        }
    }

    public void RemoveMechanism(uint index)
    {
        m_mechanismDirect.Remove(index);
    }

    public void OpenOrCloseNavMeshLayersMask(GameObject o, int layers, bool open)
    {
        if (o != null)
        {
            OpenOrCloseObjectNavMeshLayersMask(o, layers, open);
            return;
        }
        GameObject[] objs = GameObject.FindGameObjectsWithTag(DEFINE.AVATAR_OBJECT_TAG);

        int count = objs.Length;
        for (int i = 0; i < count; i++)
        {
            OpenOrCloseObjectNavMeshLayersMask(objs[i],layers, open);
        }
    }

    private void OpenOrCloseObjectNavMeshLayersMask(GameObject o,int layers,bool open)
    {
        NavMeshAgent[] nmas = o.GetComponentsInChildren<NavMeshAgent>();
        int count = nmas.Length;
        for (int i = 0; i < count; i++)
        {
            if (open)
            {
                nmas[i].walkableMask |= layers;
            }
            else
            {
                nmas[i].walkableMask &= ~layers;
            }
        }
    }

    private void MoveCamera(Transform tran,Vector3 offset,float delay)
    {
        if(CCamera.GetInst().IsLock)
            return;

        object lockObj = new object();
        CCamera.GetInst().Lock(lockObj);
        CCamera.GetInst().PauseAllCameraEffect(lockObj);

        SingletonObject<BattleScene>.GetInst().PauseAllNpc(true,true);

        Avatar.m_OffHandelClick = true;
        SingletonObject<Avatar>.GetInst().EnterState(eActionState.Idle);

        Transform cameraParentTran = CCamera.GetInst().GetCameraObj().transform.parent;
        cameraParentTran.position = tran.position + offset;
        cameraParentTran.LookAt(tran);

        UnityCallBackManager.GetInst().AddCallBack(delay, MoveCameraCallback, lockObj);
    }

    void MoveCameraCallback(params object[] args)
    {
        object lockObj = args[0];
        CCamera.GetInst().Unlock();
        SingletonObject<BattleScene>.GetInst().PauseAllNpc(false,true);
        uint cameraID = SingletonObject<BattleScene>.GetInst().CameraID;
        Avatar avatar = SingletonObject<Avatar>.GetInst();
        if (avatar.IsInRide() || avatar.IsInFly())
        {
            CCamera.GetInst().SetCameraEffect(cameraID, null, null, avatar.BakTrans.gameObject, eCAMERAFOLLOW.DIRECT, false,true);
        }
        else
        {
            CCamera.GetInst().SetCameraEffect(cameraID, null, null, avatar.GetTransform().gameObject, eCAMERAFOLLOW.DIRECT, false, true);
        }
        Avatar.m_OffHandelClick = false;
    }
}
