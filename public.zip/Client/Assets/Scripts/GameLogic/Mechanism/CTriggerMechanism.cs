﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(BoxCollider))]
public class CTriggerMechanism : CBaseMechanism {

    public CBaseMechanism m_caMechanism;

    void Awake()
    {
        m_type = 4;
    }

    public override void Init(string[] args)
    {
        base.Init(args);
        BoxCollider coll = GetComponent<BoxCollider>();
        if (coll == null)
        {
            coll = gameObject.AddComponent<BoxCollider>();
        }
        float size = 1;
        if(m_args.Length >= 3)
            size = MyConvert_Convert.ToSingle(m_args[2]);
        coll.size = Vector3.one * size + Vector3.up * 10;
        coll.center = new Vector3(0, coll.size.y / 2f - 1, 0);
        coll.isTrigger = true;

        CapsuleCollider capCollider = GetComponent<CapsuleCollider>();
        if (capCollider == null)
        {
            capCollider = gameObject.AddComponent<CapsuleCollider>();
        }
        capCollider.center = Vector3.up * 2.5f;
        capCollider.radius = 0.6f;
        capCollider.height = 5;
        capCollider.direction = 1;
        capCollider.isTrigger = false;
    }

    protected override bool OnTrigger(Collider other, CBaseMechanism mechanism)
    {
        if (!base.OnTrigger(other, mechanism))
            return false;
        if (!m_caMechanism.TriggerOther(m_args))
        {
			if(m_completedHide)
				this.enabled = false;
            return false;
        }

        return true;
    }
}
