﻿using UnityEngine;
using System.Collections;
using System;

public class CAnimationMechanism : CBaseMechanism {

    public bool m_triggerForSelf = true;
    public bool m_loop;
    public bool m_playOnAwake = true;

    void Awake()
    {
        m_type = 3;
    }

    protected override void onStart()
    {
        base.onStart();
        if (m_debug && m_animation != null)
        {
            foreach (AnimationState state in m_animation)
            {
                if (!m_triggerForSelf)
                {
                    state.wrapMode = WrapMode.Default;
                }
                else
                {
                    state.wrapMode = WrapMode.Loop;
                }
            }

            if (m_playOnAwake)
                m_animation.Play();
        }

        if (m_triggerForSelf && gameObject.collider == null)
        {
            Collider[] colls = GetComponentsInChildren<Collider>();
            int len = colls.Length;
            for (int i = 0; i < len; i++)
            {
                colls[i].isTrigger = true;
                CAnimationMenhanismCollider cscript = colls[i].gameObject.AddComponent<CAnimationMenhanismCollider>();
                cscript.m_animationMechanism = this;
            }
        }
    }

    public override void Init(string[] args)
    {
        if (args.Length != 3)
        {
            MyLog.LogError("CAnimationMechanism Init params count not equals 3");
            return;
        }
        m_triggerForSelf = Convert.ToBoolean(Convert.ToInt32(args[0]));
        m_loop = Convert.ToBoolean(Convert.ToInt32(args[1]));
        m_playOnAwake = Convert.ToBoolean(Convert.ToInt32(args[2]));

        base.Init(args);

        if (m_animation != null)
        {
            foreach (AnimationState state in m_animation)
            {
                if (m_loop)
                    m_animation.wrapMode = WrapMode.Loop;
                else
                    m_animation.wrapMode = WrapMode.ClampForever;
            }
            if (m_playOnAwake)
                m_animation.Play();
        }
    }

    public override bool TriggerOther(string[] param)
    {
        if (!m_triggerForSelf)
        {
            if (m_triggerCount == 0)
            {
				if(m_completedHide)
					gameObject.SetActive(false);
                return false;
            }
            if (m_animation == null)
            {
                MyLog.LogError("CAnimationMechanism TriggerOther m_animation is null");
				if(m_completedHide)
					gameObject.SetActive(false);
                return false;
            }
            if (!m_animation.isPlaying)
            {
                m_animation.Play(param[1]);
                m_triggerCount--;
            }

            PlayParticleEffect();
        }

        return true;
    }

    protected override bool OnTrigger(Collider other, CBaseMechanism mechanism)
    {
        if (!m_triggerForSelf)
            return false;
        float timeNow = Time.time;
        if (timeNow - m_lastTriggerTime < m_triggerSpaceTime)
            return false;

        if (m_triggerCount == 0)
        {
            if (m_completedHide)
                this.enabled = false;
            return false;
        }

        if (m_callback != null)
            m_callback(other, mechanism, m_revertCallback);

        PlayParticleEffect();

        m_triggerCount--;

        return true;
    }
	
}
