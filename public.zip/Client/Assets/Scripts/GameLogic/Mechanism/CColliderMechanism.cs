﻿using UnityEngine;
using System.Collections;
using System;

public class CColliderMechanism : CBaseMechanism {

    private BoxCollider[] m_colliders;
    private int m_count;

    void Awake()
    {
        m_type = 5;
    }

    public override void Init(string[] args)
    {
        base.Init(args);
        if (m_colliders == null)
            m_colliders = gameObject.GetComponentsInChildren<BoxCollider>();

        if (m_colliders == null)
        {
            gameObject.SetActive(false);
            return;
        }

        m_count = m_colliders.Length;
        for (int i = 0; i < m_count; i++)
        {
            m_colliders[i].isTrigger = false;
        }
        gameObject.layer = DEFINE.AIR_WALL;
    }

    public override bool TriggerOther(string[] param)
    {
        if (m_triggerCount == 0)
        {
			if(m_completedHide)
				gameObject.SetActive(false);
            return false;
        }
        for(int i = 0;i < m_count;i++)
        {
            m_colliders[i].enabled = false;
        }
        gameObject.layer = 0;
        m_triggerCount--;
        return true;
    }

    protected override bool OnTrigger(Collider other, CBaseMechanism mechanism)
    {
        return true;
    }
}
