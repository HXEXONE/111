﻿using UnityEngine;
using System.Collections;

public class CDropOutMechanism : CBaseMechanism {

    private Rigidbody m_rigidbody;
    private BoxCollider m_boxCollider;

    void Awake()
    {
        m_type = 6;
    }

    protected override void onStart()
    {
        base.onStart();
        m_rigidbody = rigidbody;
        if (m_rigidbody)
            m_rigidbody.useGravity = false;

        m_boxCollider = gameObject.GetComponent<BoxCollider>();
        if (m_boxCollider)
            m_boxCollider.isTrigger = true;
    }

    public override bool TriggerOther(string[] param)
    {

        if (m_triggerCount == 0)
        {
			if(m_completedHide)
				gameObject.SetActive(false);
            return false;
        }

        if (m_rigidbody)
            m_rigidbody.useGravity = true;

        m_triggerCount--;

        return true;
    }

    protected override bool OnTrigger(Collider other, CBaseMechanism mechanism)
    {
        Object.DestroyImmediate(m_rigidbody);
        Object.DestroyImmediate(m_boxCollider);

        if (m_callback != null)
            m_callback(other, mechanism, m_revertCallback);

        PlayParticleEffect();

        if (m_animation != null)
            m_animation.Play();

        return true;
    }
}
