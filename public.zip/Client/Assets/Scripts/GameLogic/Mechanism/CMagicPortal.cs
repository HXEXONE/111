﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CMagicPortal : CBaseMechanism {

    enum eState
    {
        None,DelayStart,Duration,DelayEnd,Passive,
    }

    private Dictionary<uint, CBaseNpc> m_npcDictionary;

    private BattleScene m_battleScene;
    private CBaseNpc m_currentNpc;

    private Transform m_transformFrom;
    private Transform m_transformTo;

    private Bounds m_triggerBound;

    private Timer m_intervalTime;   //持续时间内多久触发一次
    private Timer m_durationTime;   //持续时间（主动时间）
    private Timer m_passiveTime;    //被动时间
    private Timer m_delayStartTime;
    private Timer m_delayEndTime;

    private Vector3 m_calculateVector;
    private Vector3 m_triggerPosition;
    private Vector3 m_toPosition;
    private Vector3 m_toForward;

    private eState m_state;

    private float m_interval;
    private float m_duration;
    private float m_passive;
    private float m_delayStart;
    private float m_delayEnd;

    private int m_currentNpcLayer;

    void Awake()
    {
        m_type = 7;
    }

    public override void Init(string[] args)
    {
        if (transform.childCount != 2)
        {
            MyLog.LogError("CMagicPortal Init childCount != 2" + "\t Name = " + gameObject.name);
            return;
        }

        if (args.Length != 3)
        {
            MyLog.Log("CMagicPortal Init args != 4" + "\t ID = " + gameObject.name);
            return;
        }

        m_transformFrom = transform.Find("from");
        if (m_transformFrom == null)
        {
            MyLog.LogError("CMagicPortal Init can not find child from\t  Name = " + gameObject.name);
            return;
        }

        if (m_transformFrom.collider != null)
        {
            m_triggerBound = m_transformFrom.collider.bounds;
            m_transformFrom.collider.enabled = false;
        }
        else
        {
            m_triggerBound = new Bounds(m_transformFrom.position, Vector3.one);
            MyLog.LogError("CMagicPortal Init can not find collider\t  Name = " + gameObject.name);
        }
        
        m_transformTo = transform.Find("to");
        if (m_transformTo == null)
        {
            MyLog.LogError("CMagicPortal Init can not find child to\t  Name = " + gameObject.name);
            return;
        }

        m_delayStart = 0;
        if (!float.TryParse(args[0], out m_delayStart))
        {
            MyLog.LogError("CMagicPortal Init can not parse string : " + args[1] + "\t  Name = " + gameObject.name);
            return;
        }

        m_duration = 0;
        if (!float.TryParse(args[1], out m_duration))
        {
            MyLog.LogError("CMagicPortal Init can not parse string : " + args[3] + "\t  Name = " + gameObject.name);
            return;
        }

        m_delayEnd = 0;
        if (!float.TryParse(args[2], out m_delayEnd))
        {
            MyLog.LogError("CMagicPortal Init can not parse string : " + args[2] + "\t  Name = " + gameObject.name);
            return;
        }

        m_battleScene = SingletonObject<BattleScene>.GetInst();

        if ((m_duration + m_delayStart + m_delayEnd) > m_triggerSpaceTime)
        {
            m_passive = 0;
        }
        else
        {
            m_passive = m_triggerSpaceTime - m_duration - m_delayStart - m_delayEnd;
        }

        m_interval = 0.05f;

        m_durationTime = new Timer();
        m_intervalTime = new Timer();
        m_passiveTime = new Timer();
        m_delayStartTime = new Timer();
        m_delayEndTime = new Timer();

        m_start = true;
        m_args = args;
    }

    void Update()
    {
        if (!m_start)
            return;

        switch (m_state)
        {
            case eState.None:
                {
                    m_delayStartTime.SetTimer(m_delayStart);
                    if (m_transformFrom != null)
                    {
                        m_transformFrom.gameObject.SetActive(true);
                        m_triggerPosition = m_transformFrom.position;
                    }
                    if (m_transformTo != null)
                    {
                        m_transformTo.gameObject.SetActive(true);
                        m_toPosition = m_transformTo.position;
                        m_toForward = m_transformTo.forward;
                    }
                    SetState(eState.DelayStart);
                } break;
            case eState.DelayStart:
                {
                    if (m_delayStartTime.IsExpired(false))
                    {
                        m_durationTime.SetTimer(m_duration);
                        m_intervalTime.SetTimer(m_interval); 
                        SetState(eState.Duration);
                    }
                } break;
            case eState.Duration:
                {
                    if (m_intervalTime.IsExpired(true) && m_battleScene != null)
                    {
                        m_npcDictionary = m_battleScene.GetNpcDict();
                        if (m_npcDictionary != null && m_npcDictionary.Count > 0)
                        {
                            foreach (KeyValuePair<uint, CBaseNpc> pair in m_npcDictionary)
                            {
                                m_currentNpc = pair.Value;
                                if (m_currentNpc == null && m_currentNpc.IsDead())
                                    continue;

                                m_currentNpcLayer = m_currentNpc.Layer;
                                if (m_currentNpcLayer < 0)
                                    continue;

                                m_currentNpcLayer = 1 << m_currentNpcLayer;
                                if ((m_currentNpcLayer & m_layers) <= 0)
                                    continue;

                                if (CalculateMove(m_currentNpc.GetTransform()))
                                {
                                    m_currentNpc.MoveToPosition(m_toPosition, m_toForward);
                                    m_currentNpc.LastUpdatePosition = m_toPosition;
                                }
                            }
                        }
                        m_npcDictionary = null;
                    }
                    if (m_durationTime.IsExpired(false))
                    {
                        m_delayEndTime.SetTimer(m_delayEnd);
                        SetState(eState.DelayEnd);
                    }
                } break;
            case eState.DelayEnd:
                {
                    if (m_delayEndTime.IsExpired(false))
                    {
                        if (m_transformFrom != null)
                        {
                            m_transformFrom.gameObject.SetActive(false);
                        }
                        if (m_transformTo != null)
                        {
                            m_transformTo.gameObject.SetActive(false);
                        }
                        m_passiveTime.SetTimer(m_passive);
                        SetState(eState.Passive);
                    }
                } break;
            case eState.Passive:
                {
                    if (m_passiveTime.IsExpired(false))
                    {
                        m_delayStartTime.SetTimer(m_delayStart);
                        if (m_transformFrom != null)
                        {
                            m_transformFrom.gameObject.SetActive(true);
                            m_triggerPosition = m_transformFrom.position;
                        }
                        if (m_transformTo != null)
                        {
                            m_transformTo.gameObject.SetActive(true);
                            m_toPosition = m_transformTo.position;
                            m_toForward = m_transformTo.forward;
                        }
                        SetState(eState.DelayStart);
                    }
                } break;
        }
    }

    private void SetState(eState state)
    {
        m_state = state;
    }

    private bool CalculateMove(Transform npc)
    {
        if (npc == null)
            return false;

        return m_triggerBound.Contains(npc.position);
    }
}
