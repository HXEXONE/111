﻿using Protocol;
using System.Collections.Generic;
using Network;
using System.IO;
using UnityEngine;

public class OpenBoxManager : SingletonObject<OpenBoxManager>
{

    /*
     * 临时用铁匠铺做入口。
     */
    private OpenBoxMediator _mOpenBoxMediator;
    private List<uint> m_tempListID = new List<uint>();
    public List<uint> tempItemBoxListID { get { return m_tempListID; } set { m_tempListID = value; } }
    private uint m_freeRemainTimes;//剩余免费次数
    public uint freeRemainTimes { get { return m_freeRemainTimes; } set { m_freeRemainTimes = value; } }
    private ulong m_freeRemainTime;//免费cd
    public ulong freeRemainTime { get { return m_freeRemainTime; } set { m_freeRemainTime = value; } }

    private ushort uOpenBoxType = 0;
    private byte bFree = 0;
    private bool bAgain;//是否再次抽

    public int uesPrice = 0;
    public UInt32Array PartnerList = new UInt32Array();
    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_OPEN_BOX, onOpenOneBoxAck, true);//单抽
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_TEN_BOX_RESULT, onOpenTenBoxAck, true);// 十连抽
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_BOX_NEW_PARTNER_SHOW, onG2CAckBoxNewPartnerShow, true);//请求解锁伙伴返回
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_BOX_MARK_NEW_PARTNER, onG2CAckBoxMarkNewPartner, true);//标识已读
    }

    private void onG2CAckBoxMarkNewPartner(BinaryReader br)
    {
        G2CAckBoxMarkNewPartner msg = new G2CAckBoxMarkNewPartner();
        msg.Read(br);

    }

    private void onG2CAckBoxNewPartnerShow(BinaryReader br)
    {
        G2CAckBoxNewPartnerShow msg = new G2CAckBoxNewPartnerShow();
        msg.Read(br);
        PartnerList = msg.lPartnerIDList;
        SingletonObject<OpenBoxMediator>.GetInst().ShowNewPartner(PartnerList);
    }

    //十连抽返回
    private void onOpenTenBoxAck(BinaryReader br)
    {
        G2CAckTenBoxResult result = new G2CAckTenBoxResult();
        result.Read(br);
        if (result.uiResult == (ushort)EnumItemErr.ItemErr_Success)
        {
            _mOpenBoxMediator = SingletonObject<OpenBoxMediator>.GetInst();
            //cardAnimationMediator = SingletonObject<CardAnimationMediator>.GetInst();
            _mOpenBoxMediator.UpdateData();
            _mOpenBoxMediator.boxItemsList.Clear();
            m_tempListID.Clear();
            //打乱排序
            stBoxItemInfo[] tempBoxListArray = result.vecItemList.ToArray();
            tempBoxListArray = RandomSort(tempBoxListArray);
            List<stBoxItemInfo> tempBoxList = new List<stBoxItemInfo>();
            for (int i = 0, len = tempBoxListArray.Length; i < len; i++)
            {
                //MyLog.Log("ID" + tempBoxListArray[i].uiPartnerId + "type==" + tempBoxListArray[i].uiItemType);
                tempBoxList.Add(tempBoxListArray[i]);

            }

            for (int i = 0; i < tempBoxList.Count; i++)
            {
                if (tempBoxList[i].uiItemType == (ushort)EnumBoxItemType.BoxItemType_Partner)
                {
                    ShowOpenPartnerFunTip(true);
                    break;
                }
            }
            //更新到背包---------->2014年10月22日11:44:21已经修改为partnermanager里面更新伙伴列表
            for (int idnexOf = 0, lenght = result.ItemInfoVec.Count; idnexOf < lenght; idnexOf++)
            {
                ushort uiIndex = result.ItemInfoVec[idnexOf].uiIndex;
                ItemManager.GetInst().UpdatePackInfo(result.ItemInfoVec[idnexOf], uiIndex);
            }

            for (int i = 0, count = tempBoxList.Count; i < count; i++)
            {
                m_tempListID.Add(tempBoxList[i].uiItemId);
                DrawItem item = new DrawItem();
                item.mKind = DrawItemKind.box;
                item.uiItemId = tempBoxList[i].uiItemId;
                item.uiItemType = tempBoxList[i].uiItemType;
                item.uiItemCount = tempBoxList[i].uiItemCount;
                _mOpenBoxMediator.boxItemsList.Add(item);
            }


            //2.卡包位移&卡牌淡入淡出.
            if (!bAgain)
                _mOpenBoxMediator.CardReadyPlayEffect();
            else
                _mOpenBoxMediator.OnCardMoveCenterFinish();
            //播放抽卡
            //if (!cardAnimationMediator.IsOpen)
            //{
            //    cardAnimationMediator.Open(); //打开滚动动画
            //}
            //else
            //{
            //    cardAnimationMediator.SetPanelScaleTo();
            //}
        }
        else
        {
            SingletonObject<OpenBoxMediator>.GetInst().bCanClose = true;
            string tips = string.Empty;
            tips = ErrorResult(result.uiResult);
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(tips, Color.red);
        }
    }

    private string ErrorResult(ushort errorcode)
    {
        string tips = string.Empty;
        switch (errorcode)
        {
            case (ushort)EnumProtocolResult.EnumProtocolResult_Box_EquipFull:
                tips = Common.GetText(9948003);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_Box_MaterialFull:
                tips = Common.GetText(9948004);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_Box_PetConsumeFull:
                tips = Common.GetText(9948005);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_Box_MountsConsumeFull:
                tips = Common.GetText(9948006);
                break;
            case (ushort)EnumProtocolResult.EnumProtocolResult_Box_EquipNotEnoughForTenBox:
                tips = Common.GetText(9948007);
                break;
            default:
                tips = "Error Code:" + errorcode;
                break;
        }
        return tips;
    }

    //单抽返回
    private void onOpenOneBoxAck(BinaryReader br)
    {
        G2COpenBoxResult result = new G2COpenBoxResult();
        result.Read(br);
        _mOpenBoxMediator = SingletonObject<OpenBoxMediator>.GetInst();
        if (result.uiResult == (ushort)EnumItemErr.ItemErr_Success)
        {
            ShowOpenPartnerFunTip(result.sBoxItemInfo.uiItemType == (ushort)EnumBoxItemType.BoxItemType_Partner);
            ushort uiIndex = result.ItemInfo.uiIndex;
            //1.更新物品到背包------------>2014年10月22日11:43:41更改为partnermangaer里面接受更新伙伴列表
            ItemManager.GetInst().UpdatePackInfo(result.ItemInfo, uiIndex);

            //2.卡包位移&卡牌淡入淡出.
            if (!bAgain)
                _mOpenBoxMediator.CardReadyPlayEffect();

            //2.播放抽卡动画
            _mOpenBoxMediator.UpdateData();

            _mOpenBoxMediator.boxItemsList.Clear();
            DrawItem item = new DrawItem();
            item.mKind = DrawItemKind.box;
            item.uiItemId = result.sBoxItemInfo.uiItemId;
            item.uiItemType = result.sBoxItemInfo.uiItemType;
            item.uiItemCount = result.sBoxItemInfo.uiItemCount;
            _mOpenBoxMediator.boxItemsList.Add(item);
            _mOpenBoxMediator.TempItemId = result.sBoxItemInfo.uiItemId;
            if (bAgain)
            {
                _mOpenBoxMediator.OnCardMoveCenterFinish();
            }
            //if (!cardAnimationMediator.IsOpen)
            //{
            //    cardAnimationMediator.Open(); //打开滚动动画
            //}
            //else
            //{
            //    cardAnimationMediator.SetPanelScaleTo();
            //}
            if (result.sBoxInfo.uiBoxType == (ushort)EnumBoxType.BoxType_NormalBox)
            {
                //刷新普通计时器
                m_freeRemainTimes = result.sBoxInfo.uiFreeNum;
                m_freeRemainTime = result.sBoxInfo.uiFreeRemainTime;
                CPlayer player = SingletonObject<CPlayer>.GetInst();
                stPlayerInfo playerinfo = player.GetPlayerInfo();
                playerinfo.uiNormalBoxRemainNum = (ushort)m_freeRemainTimes;
                playerinfo.uiNormalBoxRemainTime = (uint)m_freeRemainTime;
                player.SetInfoBack(playerinfo);
                _mOpenBoxMediator.SetNormalTimes(m_freeRemainTime);
                _mOpenBoxMediator.ShowRemainTime();//刷新时间
                if (_mOpenBoxMediator.isNormalFreeNow)
                    _mOpenBoxMediator.isNormalFreeNow = false;
            }
            else if (result.sBoxInfo.uiBoxType == (ushort)EnumBoxType.BoxType_GreatBox)
            {
                //刷新高级计时器
                m_freeRemainTime = result.sBoxInfo.uiFreeRemainTime;
                CPlayer player = SingletonObject<CPlayer>.GetInst();
                stPlayerInfo playerinfo = player.GetPlayerInfo();
                playerinfo.uiGreatBoxRemainTime = (uint)m_freeRemainTime;
                player.SetInfoBack(playerinfo);
                _mOpenBoxMediator.SetAdvanceTimes(m_freeRemainTime);
                _mOpenBoxMediator.ShowRemainTime();//刷新时间
                if (_mOpenBoxMediator.isAdvanceFreeNow)
                    _mOpenBoxMediator.isAdvanceFreeNow = false;
            }
        }
        else
        {
            ItemManager.GetInst().OperItemResult((EnumItemErr)result.uiResult);

        }
    }

    #region 公开接口

    public void ShowOpenPartnerFunTip(bool isPartner)
    {

        if (isPartner)
        {
            //抽到伙伴，且伙伴系统没开启 弹出tips
            eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.Partner);
            if (mode == eOpenMode.Hide)
            {
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(8001230), Color.red);
            }
        }

    }

    /// <summary>
    /// 乱序
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="array"></param>
    /// <returns></returns>
    public static T[] RandomSort<T>(T[] array)
    {
        int len = array.Length;
        List<int> list = new List<int>();
        T[] ret = new T[len];
        System.Random rand = new System.Random();
        int i = 0;
        while (list.Count < len)
        {
            int iter = rand.Next(0, len);
            if (!list.Contains(iter))
            {
                list.Add(iter);
                ret[i] = array[iter];
                i++;
            }

        }
        return ret;
    }
    //单抽请求
    public void OpenOneBoxReq(ushort type, byte isfree, bool agagin = false)
    {
        bAgain = agagin;
        uint uDiscountID = 0;
        bool bDiscount = CheckUseDiscount(ref uDiscountID);
        uOpenBoxType = type;
        bFree = isfree;

        if (isfree != 1 && type == 1 && bDiscount)
        {
            int iDiscount = 5;
            ItemContent itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(uDiscountID);
            if (itemInfo != null)
            {
                int br = 90;
                if (itemInfo.ScriptArg.Count > 0)
                {

                    if (itemInfo.ScriptArg[0].list.Count > 0)
                    {

                        br = itemInfo.ScriptArg[0].list[0];

                    }
                }
                iDiscount = br / 10;
            }
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.okCancelButton, Common.GetTextS(9910881, iDiscount), OkCancelOneUseDiscount);

        }
        else
        {
            C2GReqOpenBox openOneBoxReq = new C2GReqOpenBox();
            openOneBoxReq.uiBoxType = type;
            openOneBoxReq.bFree = isfree;
            openOneBoxReq.iUseHeiHuo = 0;
            NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_OPEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_OPEN_BOX, openOneBoxReq);
        }

    }

    /// <summary>
    /// 十连抽请求
    /// </summary>
    /// <param name="type"> 普通宝箱10是2，高级宝箱10是3</param>
    public void OpenTenBoxReq(byte type, bool again = false)
    {
        bAgain = again;
        uint uDiscountID = 0;
        bool bDiscount = CheckUseDiscount(ref uDiscountID);
        uOpenBoxType = type;

        if (type == 3 && bDiscount)
        {
            int iDiscount = 5;
            ItemContent itemInfo = HolderManager.m_ItemHolder.GetStaticInfo(uDiscountID);
            if (itemInfo != null)
            {
                int br = 90;
                if (itemInfo.ScriptArg.Count > 0)
                {

                    if (itemInfo.ScriptArg[0].list.Count > 0)
                    {
                        br = itemInfo.ScriptArg[0].list[0];

                    }
                }
                iDiscount = br / 10;
            }
            SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.okCancelButton, Common.GetTextS(9910881, iDiscount), OkCancelTenUseDiscount);

        }
        else
        {
            C2GReqTenBox openTenBoxReq = new C2GReqTenBox();
            openTenBoxReq.uiOpenBoxType = type;
            openTenBoxReq.iUseHeiHuo = 0;
            NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_TEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_TEN_BOX_RESULT, openTenBoxReq);
        }
    }

    /// <summary>
    /// 请求获得最新解锁伙伴信息
    /// </summary>
    public void OnRequestNewPartnerList()
    {
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQ_BOX_NEW_PARTNER_SHOW, (ushort)ProCG.GAME_ACK_BOX_NEW_PARTNER_SHOW, null);
    }

    /// <summary>
    /// 通知服务端已经读了
    /// </summary>
    public void OnNotifyServerHasRead()
    {
        C2GReqBoxMarkNewPartner msg = new C2GReqBoxMarkNewPartner();
        msg.lPartnerIDList = PartnerList;
        NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQ_BOX_MARK_NEW_PARTNER, (ushort)ProCG.GAME_ACK_BOX_MARK_NEW_PARTNER, msg);
    }
    #endregion

    public bool CheckUseDiscount(ref uint disCountID)
    {
        List<PackItemInfo> itemList = SingletonObject<NormalItemManager>.GetInst().GetItemList();
        bool haveDiscount = false;
        for (int i = 0; i < itemList.Count; i++)
        {
            if (haveDiscount)
            {
                break;
            }
            for (int s = 0; s < ItemManager.GetInst().SEVEN_DISCOUNT_GOLDBOX_ID.Count; s++)
            {

                if (itemList[i].uiItemId == ItemManager.GetInst().SEVEN_DISCOUNT_GOLDBOX_ID[s])
                {
                    if (ItemManager.GetInst().Overdue(itemList[i]))
                    {
                        haveDiscount = true;
                        disCountID = itemList[i].uiItemId;
                    }
                    else
                    {
                        haveDiscount = false;
                        disCountID = itemList[i].uiItemId;
                    }
                    break;
                }
            }
        }
        return haveDiscount;
    }

    private void OkCancelOneUseDiscount(PopFrameMediator.ClickType mClickType)
    {
        if (mClickType == PopFrameMediator.ClickType.clickOk)
        {
            C2GReqOpenBox openOneBoxReq = new C2GReqOpenBox();
            openOneBoxReq.uiBoxType = uOpenBoxType;
            openOneBoxReq.bFree = bFree;
            openOneBoxReq.iUseHeiHuo = 1;
            NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_OPEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_OPEN_BOX, openOneBoxReq);
        }
        else if (mClickType == PopFrameMediator.ClickType.clickCancel)
        {
            stPlayerInfo playerInfo = SingletonObject<CPlayer>.GetInst().GetPlayerInfo();
            if (playerInfo.uiDiamond >= uesPrice)
            {
                C2GReqOpenBox openOneBoxReq = new C2GReqOpenBox();
                openOneBoxReq.uiBoxType = uOpenBoxType;
                openOneBoxReq.bFree = bFree;
                openOneBoxReq.iUseHeiHuo = 0;
                NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_OPEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_OPEN_BOX, openOneBoxReq);
            }

        }
        else if (mClickType == PopFrameMediator.ClickType.None)
        {
            SingletonObject<OpenBoxMediator>.GetInst().OnReSetToStart();
        }
    }
    private void OkCancelTenUseDiscount(PopFrameMediator.ClickType mClickType)
    {
        if (mClickType == PopFrameMediator.ClickType.clickOk)
        {
            C2GReqTenBox openTenBoxReq = new C2GReqTenBox();
            openTenBoxReq.uiOpenBoxType = uOpenBoxType;
            openTenBoxReq.iUseHeiHuo = 1;
            NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_TEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_TEN_BOX_RESULT, openTenBoxReq);
        }
        else if (mClickType == PopFrameMediator.ClickType.clickCancel)
        {
            stPlayerInfo playerInfo = SingletonObject<CPlayer>.GetInst().GetPlayerInfo();
            if (playerInfo.uiDiamond >= uesPrice)
            {
                C2GReqTenBox openTenBoxReq = new C2GReqTenBox();
                openTenBoxReq.uiOpenBoxType = uOpenBoxType;
                openTenBoxReq.iUseHeiHuo = 0;
                NetworkClient.GetNetworkClient().SendMessageNoResend((ushort)ProCG.CLIENT_REQUEST_GAME_TEN_BOX, (ushort)ProCG.GAME_ACK_CLIENT_TEN_BOX_RESULT, openTenBoxReq);
            }
        }
        else if (mClickType == PopFrameMediator.ClickType.None)
        {
            SingletonObject<OpenBoxMediator>.GetInst().OnReSetToStart();
        }
    }

    #region 全局变量

    #endregion
}
