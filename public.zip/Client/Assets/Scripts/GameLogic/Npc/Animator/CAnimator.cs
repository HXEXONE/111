﻿using System.Runtime.Remoting.Messaging;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class CAnimatorStateInfo
{
    public float startTime;     
    public bool bStartPlay;             //开始播放动作
    public float originalLength;     //原始的长度
}

public struct stStateData
{
    private static Dictionary<eActionState, string> m_ActionDict = new Dictionary<eActionState, string>();


    public static void Init()
    {
        m_ActionDict.Add(eActionState.None, "null");
        m_ActionDict.Add(eActionState.Idle, "idle");
        m_ActionDict.Add(eActionState.Turning, "idle");
        m_ActionDict.Add(eActionState.SmoothMove, "run");
        m_ActionDict.Add(eActionState.Walk, "walk");
        m_ActionDict.Add(eActionState.Run, "run");
        m_ActionDict.Add(eActionState.Assault, "run");
        m_ActionDict.Add(eActionState.Roll, "miss");
        m_ActionDict.Add(eActionState.Stun, "yun");
        m_ActionDict.Add(eActionState.Variation, "");
        m_ActionDict.Add(eActionState.Behit, "hit");
        m_ActionDict.Add(eActionState.Down, "down");
        m_ActionDict.Add(eActionState.BeatFly, "fly");
        m_ActionDict.Add(eActionState.Dead, "die");
        m_ActionDict.Add(eActionState.BossRamble, "walk");
        m_ActionDict.Add(eActionState.BossSneer, "provoke");
        m_ActionDict.Add(eActionState.BossWeakness, "yun");
        m_ActionDict.Add(eActionState.SwitchPartner, "jump");

        m_ActionDict.Add(eActionState.RideJump, "qicheng_jump");
        m_ActionDict.Add(eActionState.BeginRide, "up_down");
        m_ActionDict.Add(eActionState.EndRide, "up_down");

        m_ActionDict.Add(eActionState.BeginFly, "kongzhan_begin");
        m_ActionDict.Add(eActionState.EndFly, "kongzhan_end");
        //m_ActionDict.Add(eActionState.Shapeshift, "idle");
        m_ActionDict.Add(eActionState.IdelInHome, "xiuxian");
        m_ActionDict.Add(eActionState.RunInHome, "pao");

        m_ActionDict.Add(eActionState.Scared, "hit");
        m_ActionDict.Add(eActionState.Scaunter, "run");

        m_ActionDict.Add(eActionState.PetBeginFly, "run");
    }

    public static string GetActionName(eActionState state)
    {
        string sAniname = "";
        m_ActionDict.TryGetValue(state, out sAniname);

        return sAniname;
    }

}
public delegate void PlayOnceFinised(object[] args);

public class CAnimator
{
    private Animator m_pAnimator;

    private CAnimatorStateInfo m_pAniInfo;

    private int m_nLayer;           //动作的层级
    private string m_szAniName;
    private string m_szFullName;

    private const string BaseLayerName = "Base Layer";

    private string[] m_nonFadeList = { "hit", "down", "fly", "fei", "getup" }; //不跟idle融合的动作

    /*
     * 播放一次回调
     */
    public PlayOnceFinised m_playFinished;
    private bool m_bEmptyAction = false;

    //参数
    private object[] m_Args;
    //通过playAction时候的速度,
    private float m_speed = 1;
    public float OriginalSpeed
    {
        get { return m_speed; }
    }

    public CAnimator(Animator animator, int layer = 0/*, bool ishomenpc = false*/)
    {
        m_pAnimator = animator;
        m_pAnimator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        m_nLayer = 0;

        m_pAniInfo = new CAnimatorStateInfo();
        m_pAniInfo.bStartPlay = false;
        
    }

    public bool Enabled
    {
        get
        {
            if (null == m_pAnimator)
            {
                return false;
            }
            return m_pAnimator.enabled;
        }
        set
        {
            if (m_pAnimator != null)
            {
                m_pAnimator.enabled = value;
            }
           
        }
    }

    public string PlayActionName
    {
        get{ return m_szAniName;}
    }

    public float ActionTime 
    {
        get
        {
            if (m_bEmptyAction)
            {
                return 0f;
            }            
            if ( null == m_pAniInfo || !m_pAniInfo.bStartPlay)
            {
                return -1f;
            }

            return m_pAniInfo.originalLength / m_speed;
        }
    }

    public float Speed
    {
        get
        {
            if (null == m_pAnimator || !m_pAnimator.enabled) return 0f;

            return m_pAnimator.speed;
        }
        set
        {
            if (null == m_pAnimator || !m_pAnimator.enabled) return;

            m_pAnimator.speed = value;  
        }
    }

    //bRepeat为true时允许重复播放相同的动作
    public void PlayAction(string aniName, float speed = 1.0f, bool bRepeat = false, PlayOnceFinised playCallBack = null, float fadeTime = 0.05f, object[] parms = null)
    {
        if (null == m_pAnimator || !m_pAnimator.enabled)
        {
            return;
        }

        if (string.IsNullOrEmpty(aniName) || aniName == "0")
        {
            m_bEmptyAction = true;
            return;
        }

        m_bEmptyAction = false;

        if (!bRepeat && m_szAniName == aniName)
        {
            return;
        }
//         if ( m_pAnimator.name.Equals("1"))
//         {
// /*            Debug.Log(" aniname : " + aniName + " objname : " + m_pAnimator.name);*/
// 
//         }
        m_pAnimator.CrossFade(aniName, fadeTime, 0, 0f);//idle -> anystate 0.1 fade

        m_speed = speed;

        m_pAniInfo.bStartPlay = false;
        m_pAniInfo.startTime = Time.time;
        m_szAniName = aniName;
        m_szFullName = BaseLayerName + "." + m_szAniName;

        Speed = speed;

        m_Args = parms;
        m_playFinished = playCallBack;

    }


    public void Update()
    {
        if (null == m_pAnimator || !m_pAnimator.enabled) return;

        AnimatorStateInfo state = m_pAnimator.GetCurrentAnimatorStateInfo(0);

        //避免anystate多次触发
        if (!m_pAniInfo.bStartPlay)
        {
            if (state.nameHash == Animator.StringToHash(m_szFullName))
            {
                m_pAniInfo.bStartPlay = true;
                m_pAniInfo.originalLength = state.length;
            }
        }

        //非loop 才会回调
        if (!state.loop && null != m_playFinished)
        {
            if (m_pAniInfo.startTime != -1 && ActionTime != -1)            
            {
                if (Time.time - m_pAniInfo.startTime >= ActionTime)
                {
                    m_pAniInfo.startTime = -1f;
                    m_playFinished(m_Args);
                }                
            }
        }        
    }

}