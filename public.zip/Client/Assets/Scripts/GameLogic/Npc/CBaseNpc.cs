﻿using UnityEngine;
using System;
using Protocol;
using System.Collections;
using System.Collections.Generic;


public enum ePathFindingType
{
    A_PathFinding,//插件
    NavMesh,//unity自带的
    None,//不寻路
}

public class UseSkillInfo
{
    public readonly Vector3 specifiedPoint;
    public readonly Vector3 toward;

    public UseSkillInfo(Vector3 point, Vector3 toward)
    {
        this.specifiedPoint = point;
        this.toward = toward;
    }
}

public delegate void EnterStateEventHandler(CBaseNpc sender, eActionState state);
public delegate void ParticleHitCallback(uint particleIndex, uint targetNpcIndex, uint skillLoaderKey, eChaseState chaseState);     //飞行特效碰撞回调


public abstract class CBaseNpc
{
    public event EnterStateEventHandler NpcEnterStateEvent;

    public bool attackDone = false;
    public uint attackID = 0;
    public bool m_bIsFinalBoss = false;

    protected uint m_uiNpcType; //npc静态表ID

    protected stCharacterCard m_pOriginCard = new stCharacterCard(1);//原始属性
    protected stCharacterCard m_pCard = new stCharacterCard(1);//可能被BUFF和光环加成后的属性

    protected stCharacterCard m_pBuffCard = new stCharacterCard(1);  //仅仅是buff加成的属性

    protected int m_nHp;//当前血量

    protected float m_minAttackRange;//最小攻击距离
    protected float m_minNormalAtkRange; // 最小普攻距离

    protected float m_maxAttackRange;//最大攻击距离    

	private static float RangeRadius = 12;

    protected List<float> m_AniMoveSpeed;//表现移动速度
    protected float m_maxMoveSpeed;//最大移动速度
    protected ushort m_wLevel;//等级
    protected eNpcSort m_npcSort;
    protected eNpcGroup m_npcGroup;//阵营
    protected uint m_uiIndex;//唯一索引
    protected bool m_bPausedCheck;//暂停所有检测行为
    public bool IsPausedCheck { get { return m_bPausedCheck; } }
    protected bool m_bPausedMove;//暂停移动行为（只有m_bPaused和m_bPausedMove都为空时才能使Npc真正的暂停）
    protected bool m_bStopSimpleMove;//停止胶囊体移动
    public bool IsPauseMove { get { return m_bPausedMove; } }
    protected bool m_bStop; //停止所有行为
    protected float m_modelSize;//原始体型大小,这个值只会受到monster表的体型变更影响,作为BUFF变大还原的依据

    protected CharacterController m_characterController;//原始的碰撞器,但是怪物只取它的半径和高度数据
    protected CAnimator m_pAnimator;
    protected bool m_bApplyRootMotion;


    protected CRagdoll m_pRagdoll; //布娃娃

    private CBaseNpc m_currTarget;//当前锁定目标
    protected List<uint> m_createParticleList = new List<uint>();
    protected List<uint> ParticleList
    {
        get { return m_createParticleList; }
    }

    protected CStateManager m_stateMgr;
    protected CBuffManager m_buffMgr;

    protected Transform m_myTrans;
    protected Transform m_playerTrans;//人骑宠或者飞行时人物的transform
    protected Transform m_followTrans;//跟随或者追踪某个物体

    protected float m_fDeceleratePercent;//减速的百分比
    protected uint m_uiCurrUseSkillType;

    protected int m_nWeaponCount; //武器数量

    private Vector3 m_destPosition;

    protected GameObject m_leftWeapon;      //左手武器
    protected GameObject m_rightWeapon;     //右手武器
    protected CAnimator m_leftWeaponAnimator;//左右武器动画
    protected CAnimator m_rightWeaponAnimaror;

    protected TrailManange m_leftTrail = null;     //左手拖尾
    protected TrailManange m_rightTrail = null;    //右手拖尾

    protected uint m_birthActID = 0;
    protected uint m_unBirthActID = 0;
    public bool HasUnBirthActID
    {
        get { return m_unBirthActID != 0; }
    }

    protected float m_alphaVertexSpeed = 1;   //多长时间完成，以秒计算
    protected float m_alphaVertexAlpha = 1;   //alpha值
    private uint m_fadeOnCallbackIndex = 0; //现身回调索引
    private uint m_fadeOffCallbackIndex = 0; //隐身回调索引

    private bool m_bUsePathFinding;//使用寻路
    protected GameObject m_followObj;//寻路跟随的物体
    private Timer m_moveTimer;//移动计时器,用来处理长时间卡住退出移动
    private Vector3 m_lastMovePosition;//上次移动时所在点

    protected bool m_bMove;//当前是否可切换到run,walk状态
    protected bool m_bTurn;//当前是否可转向
    protected float m_turnSpeed;//转身速度(角速度值)    

    protected List<uint> m_allyList = new List<uint>(); //召唤盟军小弟的list

    protected List<CBaseNpc> m_rangeNpcList = new List<CBaseNpc>();//在最大攻击范围内的NPC
    protected bool m_rangeNpcIncludeAlly;//NPC列表是否包含盟友

    //protected Dictionary<CAura, uint> m_auraDict = new Dictionary<CAura, uint>(); //光环属性dict
    protected List<CAura> m_auraList = new List<CAura>(); //受到的光环列表

    protected CAuraManger m_pAuraMgr; //光环管理器

    protected NavMeshAgent m_nma;//navmesh寻路
    protected NavMeshPath m_nmp;//路径
    protected NavMeshObstacle m_nmo;//动态阻挡

    protected CObject m_pNpcObj;

    protected float m_ColliderRadius;//碰撞器半径
    protected float m_ColliderHeight;//碰撞器高度

    protected CPanel m_pHpPanel;     //血条组件 
    protected CProgressBar m_hpProgress;//血条
    protected CSprite m_csBlood;     //血条
    protected CSprite m_csBloodRed;     //血条
    protected CSprite m_csBloodDeep;     //血条
    protected CSprite m_csBloodRedDeep;     //血条

    protected TimerEx m_ActionTimer;//动作计时器,必须等动作
    protected List<CSound> m_soundList = new List<CSound>();
    public List<CSound> Sounds //当前npc sound列表
    {
        get { return m_soundList; }
    }

    protected List<CBaseNpc> m_targetList;
    protected List<SkillHitResult> m_SkillResultList = new List<SkillHitResult>(); //技能攻击回调

    protected List<SkillHitWithoutTarget> m_ScriptSkillHitList = new List<SkillHitWithoutTarget>();

    private HitResultCallback m_HitResultCallback = null;
    public HitResultCallback HitResultCallback
    {
        set { m_HitResultCallback = value; }
    }


    protected CPanel m_chatBobble;

    protected CBaseNpc m_pGrabNpc; //抓取npc        
    protected bool m_bIsBeGrab; //是否被抓取

    protected string m_sTag;//NPC标签，一般用来在碰撞和触发器中用来区别不同类型的NPC

    protected Vector3 m_lastUpdatePosition = Vector3.zero;//上次更新时候的位置
    public Vector3 LastUpdatePosition
    {
        set
        {
            m_lastUpdatePosition = value;
        }
    }

    protected GameObject m_audioSourceObject = null;   //挂音效的物体
    public GameObject AudioSourceObject
    {
        get { return m_audioSourceObject; }
    }

    protected float m_fOrigionBodyHeight;        //原始模型高度
    public float FBodyHeight
    {
        get
        {
            return m_fOrigionBodyHeight * ModelSize;
        }
    }

    private bool m_bLoadComplete = false; //下载完成
    public bool LoadComplete
    {
        get { return m_bLoadComplete; }
    }


    protected bool m_bInGround = false;

    protected bool m_bInPlatform;//是否在移动平台上
    public bool InPlatform
    {
        get { return m_bInPlatform; }
        //set { m_bInPlatform = value; }
    }

    private float m_fNormalAtkTime;
    public float NormalAtkTime
    {
        get { return m_fNormalAtkTime; }
        set { m_fNormalAtkTime = value; }
    }

    protected CInitiativeSkill m_DefaultSkill;
    protected List<CInitiativeSkill> m_skillList = new List<CInitiativeSkill>();
    public List<CInitiativeSkill> SkillList
    {
        get { return m_skillList; }
    }

    public float DefaultSkillCD
    {
        get
        {
            if (m_DefaultSkill != null)
            {
                return m_DefaultSkill.CD;
            }
            else
            {
                return 0;
            }
        }
        set
        {
            if (m_DefaultSkill != null)
            {
                m_DefaultSkill.CD = value;
            }
        }
    }
    public uint DefaultSkillID
    {
        set
        {
            if (m_DefaultSkill != null)
            {
                m_DefaultSkill.SetSkill(value, null);
            }
        }
        get
        {
            if (null == m_DefaultSkill)
            {
                return 0;
            }
            return m_DefaultSkill.GetSkillID();
        }
    }

    private bool m_bSelfDestruction;
    public bool SelfDestruction
    {
        set { m_bSelfDestruction = value; }
        get { return m_bSelfDestruction; }
    }

    protected eLiveState m_liveState;     //存活状态
    public eLiveState LiveState { get { return m_liveState; } }

    protected SkinnedMeshRenderer[] m_smr;
    public SkinnedMeshRenderer SkinnedRenderer
    {
        get
        {
            if (m_smr != null && m_smr.Length > 0)
            {
                for (int i = 0; i < m_smr.Length; i++)
                {
                    if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    {
                        return m_smr[i];
                    }
                }
                return null;
            }
            else
                return null;
        }
    }
    protected MeshRenderer[] m_mrs;
    private Material[] m_materials = new Material[0];
    protected Material[] Materials
    {
        get { return m_materials; }
        set
        {
            m_materials = value;
            if (value == null)
            {
                m_materiaslCount = 0;
                return;
            }
            m_materiaslCount = m_materials.Length;
            if (m_materiaslCount > 0)
            {
                if (this is Avatar)
                    m_material0Name = DEFINE.SHADER_VERTLIT_XRAY;
                else
                    m_material0Name = DEFINE.SHADER_VERTLIT;
            }
        }
    }

    protected bool m_bHideModel = false; //模型影藏
    public bool HideModel
    {
        get { return m_bHideModel; }
    }

    private SphereCollider m_sphereColliderTirrgerObject;

    protected int m_materiaslCount = -1;

    protected string m_material0Name;   //实际的shader
    protected string m_currShaderName;  //当前shader名

    protected Material m_materialLeft;  //武器的材质 left
    public Material MatLeft
    {
        set { m_materialLeft = value; }
    }

    protected Material m_materialRight;  //武器的材质 right
    public Material MatRight
    {
        set { m_materialRight = value; }
    }


    protected uint m_changeMaterialParticleIndex = 0;  //石像怪替换材质的特效ID
    public uint ChangeMaterialParticleIndex { get { return m_changeMaterialParticleIndex; } }

    protected GameObject m_shadow; //脚下阴影

    protected CObject m_pLeftWeaponObject;//左手武器
    protected CObject m_pRightWeaponObject;//右手武器
    protected uint m_uiWeaponID;//默认武器

    public bool LockHP = false;
    public int LockHPValue = 0;

    private CObject m_textureLeftWeapon;
    private CObject m_textureRightWeapon;

    protected BattleScene m_pBattleScene;
    public BattleScene CurrBattleScene
    {
        get { return m_pBattleScene; }
    }

    protected eNpcUnitsType m_unitsType;
    public eNpcUnitsType UnitsType//兵种类型
    {
        get { return m_unitsType; }
        set { m_unitsType = value; }
    }

    protected bool m_bEscape;
    public bool Escape//当前是否正在逃跑
    {
        get { return m_bEscape; }
        set { m_bEscape = value; }
    }

    protected bool m_bTrusteeship = false;
    public virtual bool Trusteeship//托管挂机
    {
        set
        {
            //离开托管状态
            if (value == false && m_bTrusteeship != value)
            {
                CurrTarget = null;
                if (GetCurrActState() != eActionState.Skill)
                {
                    EnterState(eActionState.Idle);
                }
            }

            m_bTrusteeship = value;
        }
        get
        {
            return m_bTrusteeship;
        }
    }

    protected NpcAI m_pAI;
    public NpcAI AI
    {
        get
        {
            return m_pAI;
        }
    }

    public uint NpcType
    {
        get
        {
            return m_uiNpcType;
        }
        set
        {
            m_uiNpcType = value;
        }
    }


    public ushort NpcLevel
    {
        get
        {
            return m_wLevel;
        }
        set
        {
            m_wLevel = value;
        }
    }

    public uint WeaponID
    {
        set
        {
            m_uiWeaponID = value;
        }
    }


    public float MoveSpeed
    {
        set
        {
            m_pCard.fMoveSpeed = value;

            if (m_pCard.fMoveSpeed > m_maxMoveSpeed)
            {
                m_pCard.fMoveSpeed = m_maxMoveSpeed;
            }

            if (m_pCard.fMoveSpeed < 0f)
            {
                m_pCard.fMoveSpeed = 0f;
            }

        }
        get
        {
            return m_pCard.fMoveSpeed;
        }
    }

    public float WalkSpeed
    {
        set { m_pCard.fWalkSpeed = value; }
        get { return m_pCard.fWalkSpeed; }
    }


    public Material WeaponMaterial
    {
        get
        {
            return m_materialLeft == null ? (m_materialRight == null ? null : m_materialRight) : m_materialLeft;
        }
    }

    private Timer m_comboTimer;//连招计时

    protected int m_nLayer = -1;
    public int Layer { get { return m_nLayer; } }

    public virtual bool Init(BattleScene battlescene, uint index, uint uiNpcID, ushort wLevel, eNpcSort sort, Vector3 position, Quaternion rotation, string tag, List<int> ExtraAiList = null, List<int> ExtraSkillList = null)
    {
        m_pAI = new NpcAI(this);
        m_pAI.AddAI(ExtraAiList);
        m_pAI.AddSkill(ExtraSkillList);

        m_npcSort = sort;
        m_uiNpcType = uiNpcID;

        m_stateMgr = new CStateManager(this);
        m_rangeNpcIncludeAlly = false;//是否包含友军

        if (sort != eNpcSort.Mechanism)
        {
            m_moveTimer = new Timer();
            m_moveTimer.SetTimer(0.5f);

            CreateHpComponent();

            m_buffMgr = new CBuffManager(this);
            if (!IsChest())
            {
                //m_buffMgr = new CBuffManager(this);
                m_pAuraMgr = new CAuraManger(this);
            }
        }
        m_bEscape = false;

        m_pBattleScene = battlescene;

        m_uiIndex = index;
        m_bSelfDestruction = false;

        m_wLevel = wLevel;

        m_ActionTimer = new TimerEx();
        m_targetList = new List<CBaseNpc>();

        m_pGrabNpc = null;
        m_bIsBeGrab = false;

        m_nWeaponCount = 0;
        m_fOrigionBodyHeight = 0f;
        m_modelSize = 1;


        m_sTag = tag;

        m_comboTimer = new Timer();

        InitNpc(uiNpcID, wLevel, position, rotation);

        //    m_liveState = eLiveState.NONE;
        return true;
    }

    protected virtual void InitNpc(uint uiNpcID, ushort wLevel, Vector3 position, Quaternion rotation)
    {
        //m_uiNpcType = uiNpcID;

        m_myTrans = null;
        m_playerTrans = null;

        m_fDeceleratePercent = 0;
        InitCharacterCard(wLevel);


        CreateNpc(position, rotation);

        m_bPausedCheck = false;
        m_bPausedMove = false;

        m_AniMoveSpeed = GetAniMoveSpeed();
        m_maxMoveSpeed = GetMaxMoveSpeed();



        if (CBaseStory.IsInGameStory || CCamera.GetInst().PauseAllNpc)
        {
            if (this is SkillNpc)
            {
                PauseCheckBehave((this as SkillNpc).ParentNpc.IsPausedCheck);
                PauseMoveBehave((this as SkillNpc).ParentNpc.IsPauseMove, true);
            }
            else
                PauseNpc(true, true);
        }
    }

    public uint Index
    {
        get
        {
            return m_uiIndex;
        }
        set
        {
            m_uiIndex = value;
            m_pNpcObj.Name = m_uiIndex.ToString();
        }
    }

    public bool ApplyAnimator
    {
        set
        {
            if (null != m_pAnimator)
            {
                m_pAnimator.Enabled = value;
            }
        }
    }

    public CharacterController NpcCollider
    {
        get { return m_characterController; }
    }

    //胶囊体开关
    public virtual bool ApplyCharacterCtrl
    {
        set
        {
            if (null != m_characterController)
            {
                m_characterController.enabled = value;
            }
        }
        get
        {
            if (null == m_characterController)
            {
                return false;
            }
            return m_characterController.enabled;
        }

    }

    public virtual bool ApplyRootMotion
    {
        set
        {
            if (m_myTrans == null)
            {
                MyLog.LogError(" ApplyRootMotion Error ! Npc Index : " + Index + " transform is null. ");
                return;
            }
            Animator animator = m_myTrans.GetComponent<Animator>();
            if (null != animator)
            {
                animator.applyRootMotion = value;
            }

            m_bApplyRootMotion = value;
        }
        get
        {
            return m_bApplyRootMotion;
        }
    }

    public CBaseNpc GrabNpc
    {
        set
        {
            m_pGrabNpc = value;
        }
        get
        {
            return m_pGrabNpc;
        }
    }

    //目前所使用的技能
    public uint CurUseSkill
    {
        get
        { 
            return m_uiCurrUseSkillType;
        }
    }

    //创建npc血条
    public void CreateHpComponent()
    {
        //         if (m_pHpPanel != null)
        //         {
        //             return;
        //         }

        if (NpcSort == eNpcSort.Ally || NpcSort == eNpcSort.Mechanism)
        {
            return;
        }

        if (this is Avatar || this is Pet || this is SkillNpc)
        {
            return;
        }

        if (IsChest())
        {
            return;
        }

        //特定npc不显示血条
        if (m_uiNpcType == DEFINE.NO_HP_COMPONENT_NPCID)
        {
            return;
        }

        if (SingletonObject<CBattleSceneLoading>.GetInst().battleType == eBattleType.Arena || 
            SingletonObject<CBattleSceneLoading>.GetInst().battleType == eBattleType.Pvp)
        {
            return;
        }

        if (this is Monster)
        {
            SingletonObject<HpFrameMediator>.GetInst().AddHpFrame(InitHpPanel, (eNpcSortType)NpcSortType);
        }
        else
        {
            SingletonObject<HpFrameMediator>.GetInst().AddHpFrame(InitHpPanel, m_npcSort);
        }
    }

    private void InitHpPanel(CPanel mPanel)
    {
        m_pHpPanel = mPanel;
        if (m_pHpPanel != null)
        {
            m_hpProgress = m_pHpPanel.GetElementBase("(ProgressBar)fightblood") as CProgressBar;
            m_hpProgress.SetValue(1);
            if (NpcSortType == eNpcSortType.EliteMonster ||
                NpcSortType == eNpcSortType.Turret)
            {
                m_csBlood = m_pHpPanel.GetElementBase("(Sprite)elitblood") as CSprite;
                m_csBloodRed = m_pHpPanel.GetElementBase("(Sprite)elitbloodred") as CSprite;
                m_csBloodDeep = m_pHpPanel.GetElementBase("(Sprite)deepelitblood") as CSprite;
                m_csBloodRedDeep = m_pHpPanel.GetElementBase("(Sprite)deepelitbloodred") as CSprite;

                m_csBlood.SetSpriteSize(new Vector2(160,10));
                m_csBloodRed.SetSpriteSize(new Vector2(160, 10));
                m_csBloodDeep.SetSpriteSize(new Vector2(160, 10));
                m_csBloodRedDeep.SetSpriteSize(new Vector2(160, 10));
            }
            else if (NpcSortType == eNpcSortType.LeaderMonster || NpcSortType == eNpcSortType.NormalMonster)
            {
                m_csBlood = m_pHpPanel.GetElementBase("(Sprite)colorhp") as CSprite;
                m_csBloodDeep = m_pHpPanel.GetElementBase("(Sprite)deepcolorhp") as CSprite;

                m_csBlood.SetSpriteSize(new Vector2(97,11));
                m_csBloodDeep.SetSpriteSize(new Vector2(97, 11));
            }
            else if (NpcSortType == eNpcSortType.ChapterBoss || NpcSortType == eNpcSortType.WorldBoss
                || NpcSortType == eNpcSortType.SociatyBoss)
            {

                m_csBlood = m_pHpPanel.GetElementBase("(Sprite)fightblood") as CSprite;
                m_csBloodDeep = m_pHpPanel.GetElementBase("(Sprite)deepfightblood") as CSprite;

                m_csBlood.SetSpriteSize(new Vector2(250,12));
                m_csBloodDeep.SetSpriteSize(new Vector2(250, 12));
            }
            else if (NpcSortType == eNpcSortType.Activity)
            {
                m_csBlood = m_pHpPanel.GetElementBase("(Sprite)elitblood") as CSprite;

                m_csBlood.SetSpriteSize(new Vector2(160,10));
            }
        }
    }

    public void HpComponentEnable(bool bEnable)
    {
        if (m_pHpPanel != null)
        {
            if (m_pHpPanel.IsActive() == bEnable)
            {
                return;
            }
            Transform parentObj = m_pHpPanel.ElementObj.transform.parent;
            if (!parentObj.name.Equals("(DynamicComponent)fightblood") && bEnable) //已经清除了动态控件，放入内存池，无需隐藏
            {
                //m_pHpPanel = null;
            }
            else
            {
                m_pHpPanel.SetActive(bEnable);

            }
        }
    }


    //给NPC创建聊天气泡
    public void CreateChatBubble(string text)
    {
        if (m_chatBobble != null)
        {
            SingletonObject<ChatBubbleMediator>.GetInst().RemoveItem(m_chatBobble);
        }
        m_chatBobble = SingletonObject<ChatBubbleMediator>.GetInst().AddChatBobble(text);
    }


    protected virtual void InitCharacterCard(ushort wLevel)
    {
    }

    protected int InitAttr(List<float> list, ushort wLevel)
    {
        int nAttr = 0;

        //主角的属性=roundup(基础值+成长值*（等级/1.202.1）^1.254)
        if (this is BaseBattlePlayer)
        {
            nAttr = (int)(list[0] + list[1] * Math.Pow((wLevel / 1.202), 1.254));
        }
        //怪物的属性=基础值+成长值*等级
        else if (this is Monster || this is Pet)
        {
            nAttr = (int)(list[0] + wLevel * list[1]);
        }
        return nAttr;
    }

    public eNpcSort NpcSort
    {
        get
        {
            return m_npcSort;
        }
    }

    public eNpcGroup NpcGroup
    {
        get
        {
            return m_npcGroup;
        }
    }

    public string NpcTag
    {
        get
        {
            return m_sTag;
        }
    }

    public bool ApplyRagdoll
    {
        set
        {
            if (null == m_pRagdoll) return;

            m_pRagdoll.ApplyRagdoll = value;
        }
        get
        {
            if (null == m_pRagdoll) return false;

            return m_pRagdoll.ApplyRagdoll;
        }
    }

    //布娃娃作用力
    public void AddRagdollForce(string bindName, Vector3 force)
    {
        if (null != m_pRagdoll)
        {
            m_pRagdoll.AddForce(bindName, force);
        }
    }

    public CObject GetObject()
    {
        return m_pNpcObj;
    }


    public bool IsBoss()
    {

        eNpcSortType sortType = (eNpcSortType)NpcSortType;

        return sortType == eNpcSortType.ChapterBoss ||
                    sortType == eNpcSortType.WorldBoss ||
                    sortType == eNpcSortType.SociatyBoss;
    }

    public bool IsChest()
    {

        return NpcSortType == eNpcSortType.Chest;
    }

    //是否为炮塔
    public bool IsTurret()
    {
        return NpcSortType == eNpcSortType.Turret;
    }

    protected abstract void CreateNpc(Vector3 position, Quaternion rotation, bool replace = false);

    public Vector3 GetPosition()
    {
        if (null == m_myTrans)
        {
            return Vector3.zero;
        }
        return m_myTrans.position;
    }

    public void SetPosition(Vector3 position, bool toidle = false)
    {
        //         if (this is RealAvatar )
        //         {
        //             Debug.LogError(this + " SetPosition :  " + position);
        //         }

        if (m_myTrans != null && null != m_nma)
        {
            m_myTrans.position = position;
            m_lastUpdatePosition = Vector3.zero;

            SetNavmeshEnable(false);
            m_followObj.transform.localPosition = Vector3.zero;
            SetNavmeshEnable(true);

            if (toidle)
            {
                EnterState(eActionState.Idle);
            }
        }
    }

    //设置Y轴旋转角度
    public void SetEulerY(float angel)
    {
        if (null != m_myTrans)
        {
            m_myTrans.eulerAngles = Vector3.up * angel;
        }
    }

    public float ModelSize
    {
        get
        {
            return m_modelSize;
        }
    }


    public Transform GetTransform()
    {
        return m_myTrans;
    }

    public Transform GetPlayerTransform()
    {
        return m_playerTrans;
    }

    public CBuffManager GetBuffManager()
    {
        return m_buffMgr;
    }

    protected virtual void InitModel(GameObject o)
    {
        m_myTrans = o.transform;
        m_playerTrans = m_myTrans;

        Transform temp = m_myTrans.Find(DEFINE.OBJECT_NAME_AUDIOSOURCE);

        if (temp == null)
        {
            GameObject audioSourceObject = new GameObject(DEFINE.OBJECT_NAME_AUDIOSOURCE);
            m_audioSourceObject = audioSourceObject;
            m_audioSourceObject.transform.parent = m_myTrans;
        }
        else
            m_audioSourceObject = temp.gameObject;

        m_audioSourceObject.transform.localPosition = Vector3.zero;

        if (m_npcSort != eNpcSort.Mechanism)
        {
            Transform followtrans = m_myTrans.Find("FollowObject");
            if (followtrans == null)
            {
                m_followObj = new GameObject("FollowObject");
                m_followObj.transform.parent = m_myTrans;
                m_followObj.transform.localPosition = Vector3.zero;
                m_followObj.transform.localScale = Vector3.one;
            }
            else
            {
                m_followObj = followtrans.gameObject;
                m_followObj.transform.localPosition = Vector3.zero;
            }

            //加载寻路脚本
            m_nma = m_followObj.GetComponent<NavMeshAgent>();
            if (null == m_nma)
            {
                m_nma = m_followObj.AddComponent<NavMeshAgent>();
                //m_nma.speed = MoveSpeed;
                m_nma.speed = m_pCard.fMoveSpeed;

                m_nma.acceleration = 360;
                m_nma.angularSpeed = 360;
            }

            m_nmo = m_followObj.GetComponent<NavMeshObstacle>();
            if (null == m_nmo)
            {
                m_nmo = m_followObj.AddComponent<NavMeshObstacle>();
                m_nmo.carvingMoveThreshold = 1.0f;
                m_nmo.carving = true;
            }
            m_nmo.enabled = false;
            m_nma.enabled = false;

            m_nmp = new NavMeshPath();

            FixingBP_Buff fixBuff = m_myTrans.GetComponent<FixingBP_Buff>();
            if (null == fixBuff)
            {
                m_myTrans.gameObject.AddComponent<FixingBP_Buff>();
            }


            //脚下阴影
            if (m_unitsType == eNpcUnitsType.Ground)
            {
                Transform shadowTrans = o.transform.FindChild("shadow");
                if (null != shadowTrans)
                {
                    m_shadow = shadowTrans.gameObject;
                    SetFootEffect(true);
                }
                if (ClientMain.IsSupportShadowRunTime)
                {
                    if (m_shadow)
                    {
                        UnityEngine.Object.Destroy(m_shadow);
                    }
                }
            }
        }

        m_smr = m_myTrans.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        m_mrs = m_myTrans.GetComponentsInChildren<MeshRenderer>();
        if (m_smr != null && m_smr.Length > 0)
        {
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].enabled = true;
                    Materials = m_smr[i].materials;
                    break;
                }
            }
        }

        if (m_materiaslCount > 0)
        {
            m_currShaderName = m_material0Name;
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                {
                    if (Materials[i].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                        Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, 1);
                }
            }
        }

        //UnityCallBackManager.GetInst().AddCallBack(0.1f, DealyAddRange,null);
        //AddRangeTrigger();
    }

    //     private void DealyAddRange(params object[] args)
    //     {
    //         AddRangeTrigger();
    //     }



    protected virtual void LoadAI()
    {
        //Do nothing
    }


    protected virtual void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if (null == o) {  return; }

     

        InitModel(o);

        //加载AI
        LoadAI();

        AddRangeTrigger();


        m_bLoadComplete = true;

        //位置修正
        if (!CBaseStory.IsInGameStory && m_npcSort != eNpcSort.Mechanism)
        {
            FixPosition();
        }

        if (m_nma != null)
        {
            m_nma.obstacleAvoidanceType = ObstacleAvoidanceType.HighQualityObstacleAvoidance;
        }

        DynamicShader.ReplaceUnSupportShader(o);

        if (m_npcSort != eNpcSort.Mechanism)
            ChangeWeapon(m_uiWeaponID);


        if (m_pAI != null)
        {
            m_pAI.UpdateCondition(eExtraAICondition.Born, "");
        }

        if (m_sTag != null && !m_sTag.Equals(DEFINE.UNTAGGED_OBJECT_TAG) && m_myTrans != null)
        {
            m_myTrans.gameObject.tag = m_sTag;
        }


        //         if (NpcSortType == eNpcSortType.WorldBoss)
        //         {
        //             if (!ClientMain.GetInst().EnterTestScene)
        //             {
        //                 this.SetHp(SingletonObject<WorldBossManager>.GetInst().m_stbfChallengeBossinfo.uiBossRemainHp);
        //             }            
        //         }

        if (m_npcSort != eNpcSort.Mechanism && m_pBattleScene != null)
        {
            if (!IsBoss())// && NpcSortType != eNpcSortType.EliteMonster)
                ShowNpc(!m_pBattleScene.HideNpc);
        }
    }

    public void FixPosition()
    {
        if (this is Monster && null != (this as Monster).SummonerNpc)
        {
            //召唤物延迟创建
            if (GetCurrActState() != eActionState.Shapeshift)
            {
                UnityCallBackManager.GetInst().AddCallBack(0.1f, DealySummonPos);
            }            
        }
        else if (m_pAI != null && m_pAI.CanMove())
        {
            if (GetCurrActState() != eActionState.Shapeshift)
            {
                m_myTrans.position = m_pBattleScene.SummonPosition(m_myTrans.position, CharacterRadius, false, this, NpcCollider) + Vector3.up * 0.2f; ;
            }
        }
    }

    private void DealySummonPos(params object[] args)
    {
        float radius = (this as Monster).SummonerNpc.CharacterRadius;
        m_myTrans.position = m_pBattleScene.SummonPosition((this as Monster).SummonerNpc.GetPosition(), radius, false, this, NpcCollider) + Vector3.up * 0.2f;

    }

    protected virtual void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        Transform bonetrans = Common.GetBone(m_myTrans, "Bip01 Prop2");
        if (null == bonetrans)
        {
            m_pLeftWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            m_pLeftWeaponObject = null;
            return;
        }
        bonetrans.gameObject.SetActive(true);

        o.transform.parent = bonetrans;
        o.layer = m_myTrans.gameObject.layer;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        m_leftWeapon = o;
        TrailManange[] trails = o.GetComponentsInChildren<TrailManange>();
        if (trails.Length > 0)
        {
            m_leftTrail = trails[0];
            if (m_leftTrail.EndToDisable)
                m_leftTrail.enabled = false;
        }

        Animator leftAni = m_leftWeapon.GetComponent<Animator>();
        if (leftAni != null)
        {
            leftAni.applyRootMotion = false;
            m_leftWeaponAnimator = new CAnimator(leftAni);
            m_leftWeaponAnimator.PlayAction("idle", 1.0f, false, null, 0f);
        }

        //Renderer[] render = bonetrans.GetComponentsInChildren<Renderer>();
        //if (render != null && render.Length > 0)
        //{
        //    m_materialLeft = render[0].material;
        //    if (m_npcSort == eNpcSort.Monster)
        //    {
        //        m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        //        m_materialLeft.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
        //    }
        //}

        DynamicShader.ReplaceUnSupportShader(o);

        Renderer render = m_leftWeapon.renderer;
        if (render != null)
        {
            if (IsBoss() || CGameConfig.GetInst().OpenMonsterFade)
                m_materialLeft = render.material;
            else if (this is Monster)
                m_materialLeft = render.sharedMaterial;
            if (m_npcSort == eNpcSort.Monster)
            {
                m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                m_materialLeft.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
            }

            if (m_pBattleScene != null)
            {
                if (!IsBoss())
                {
                    render.enabled = !m_pBattleScene.HideNpc;
                }
            }
        }

        //if (m_birthActID != 0 && m_unBirthActID == 0)
        //    m_leftWeapon.renderer.enabled = false;

        if (m_textureLeftWeapon != null && m_textureLeftWeapon.PTexture2D != null)
        {
            m_materialLeft.mainTexture = m_textureLeftWeapon.PTexture2D;
        }
    }

    protected virtual void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        if (o == null) return;
        string bindPoint = "Bip01 Prop1";
        if (this is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)this;
            //飞行时绑点修改,射击时需要修改绑点Bip01 R Clavicle的y旋转以达到真实效果
            if (bbp.IsInFly())
            {
                bindPoint = "Bip01 R Hand";
            }
        }
        Transform bonetrans = Common.GetBone(m_myTrans, bindPoint);
        if (null == bonetrans)
        {
            m_pRightWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            m_pRightWeaponObject = null;
            return;
        }
        bonetrans.gameObject.SetActive(true);

        o.transform.parent = bonetrans;
        o.layer = m_myTrans.gameObject.layer;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        m_rightWeapon = o;
        TrailManange[] trails = o.GetComponentsInChildren<TrailManange>();
        if (trails.Length > 0)
        {
            m_rightTrail = trails[0];
            if (m_rightTrail.EndToDisable)
                m_rightTrail.enabled = false;
        }

        Animator rightAni = m_rightWeapon.GetComponent<Animator>();
        if (rightAni != null)
        {
            rightAni.applyRootMotion = false;
            m_rightWeaponAnimaror = new CAnimator(rightAni);
            m_rightWeaponAnimaror.PlayAction("idle", 1.0f, false, null, 0f);
        }


        //Renderer[] render = bonetrans.GetComponentsInChildren<Renderer>();
        //if (render != null && render.Length > 0)
        //{
        //    m_materialRight = render[0].material;

        //    if (m_npcSort == eNpcSort.Monster)
        //    {
        //        m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        //        m_materialRight.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
        //    }
        //}

        DynamicShader.ReplaceUnSupportShader(o);

        Renderer render = m_rightWeapon.renderer;
        if (render != null)
        {
            if (IsBoss() || CGameConfig.GetInst().OpenMonsterFade)
                m_materialRight = render.material;
            else
                m_materialRight = render.sharedMaterial;
            if (m_npcSort == eNpcSort.Monster)
            {
                m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                m_materialRight.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
            }

            if (m_pBattleScene != null)
            {
                if (!IsBoss())
                {
                    render.enabled = !m_pBattleScene.HideNpc;
                }
            }
        }

        //if (m_birthActID != 0 && m_unBirthActID == 0)
        //    m_rightWeapon.renderer.enabled = false;

        if (m_textureRightWeapon != null && m_textureRightWeapon.PTexture2D != null)
        {
            m_materialRight.mainTexture = m_textureRightWeapon.PTexture2D;
        }
    }

    public int WeaponCount
    {
        get
        {
            return m_nWeaponCount;
        }
    }

    //武器隐藏
    public void HideWeapon(bool bHide = true)
    {
        if (m_nWeaponCount > 0)
        {
            Transform r_weapon = Common.GetBone(m_myTrans, "Bip01 Prop1");
            if (null != r_weapon)
            {
                Transform r_hand = Common.GetBone(m_myTrans, "BP_R_Hand");
                if (null != r_hand)
                {
                    r_weapon.gameObject.SetActive(!bHide);
                }
            }
        }
        if (m_nWeaponCount > 1)
        {
            Transform l_weapon = Common.GetBone(m_myTrans, "Bip01 Prop2");
            if (null != l_weapon)
            {
                Transform l_hand = Common.GetBone(m_myTrans, "BP_L_Hand");
                if (null != l_hand)
                {

                    l_weapon.gameObject.SetActive(!bHide);
                }
            }
        }

    }



    //计算出转身时间(近似值)
    public float TurningTime
    {
        get
        {
            float angel = Vector3.Angle(m_destPosition - m_myTrans.position, m_myTrans.forward);
            float rad2deg = angel / Mathf.Rad2Deg; //弧度

            //return rad2deg / m_turnSpeed + 0.1f;
            float time = rad2deg / m_turnSpeed;
            //             if (this is Avatar)
            //             {
            //                 MyLog.Log("  turning time : " + time);
            //             }            

            return time * Common.TimeScale;
            //return time = time > 0.1f ? time - 0.1f : time ;
        }
    }

    //脚底效果开关(影子)
    public virtual void SetFootEffect(bool state)
    {
        //         if (m_directPoint)
        //             m_directPoint.SetActive(state);

        if (!ClientMain.IsSupportShadowRunTime && m_shadow != null)
        {
            MeshRenderer mr = m_shadow.GetComponent<MeshRenderer>();
            mr.enabled = state;
        }
    }

    protected virtual void LoadAcnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        //MyLog.Log("___________________________ LoadAcnimatorCtrl .........");
        //return;
        if (null == m_myTrans)
        {
            return;
        }
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        Animator aniCtrl = m_myTrans.GetComponent<Animator>();
        if (null == aniCtrl) //召唤物可能无animator (如雷电之心)
        {
            aniCtrl = m_myTrans.gameObject.AddComponent<Animator>();
        }

        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;

        BuildAnimator(aniCtrl);
    }

    protected virtual void BuildAnimator(Animator animator)
    {
        m_bLoadComplete = true;

        animator.enabled = true;

        m_pAnimator = new CAnimator(animator);

        //变身也要走这套流程
        eActionState currState = m_stateMgr.GetCurrActState();
        if (currState == eActionState.None)
        {
            EnterState(eActionState.Idle);
        }

    }

    public void SetHp(int hp)
    {
        m_nHp = hp;
    }

    public int GetHp()
    {
        return m_nHp;
    }

    public int GetMaxHp()
    {
        return m_pCard.nMaxHp;
    }


    public virtual void RrefeshHPComponent()
    {
        if (m_bIsFinalBoss)
        {
            SingletonObject<BattleInfoMediator>.GetInst().NpcValue((float)m_nHp / (float)m_pCard.nMaxHp);
            return;
        }

        if (m_pHpPanel == null || m_hpProgress == null)
        {
            return;
        }
        HpFrameMediator mHpFrameMediator = SingletonObject<HpFrameMediator>.GetInst();
        if (!mHpFrameMediator.IsOpen)
        {
            mHpFrameMediator.Open(null);
        }
        float prevalue = m_hpProgress.GetValuePercent();
        float nowvalue = 0;
        nowvalue = (float)m_nHp / (float)m_pCard.nMaxHp;
        HpComponentEnable(true);
        switch (NpcSortType)
        {
            case eNpcSortType.EliteMonster:
            case eNpcSortType.Turret:
                {
                    if (nowvalue > 0.5f)
                    {
                        float mValue = (nowvalue - 0.5f) * 2;
                        m_hpProgress.SetValue(mValue);
                        if (null != m_csBlood)
                            m_csBlood.SetSprite("progressbar_monster1_full");
                        if (null != m_csBloodDeep)
                            m_csBloodDeep.SetActive(true);
                        if (null != m_csBloodRed)
                        {
                            float width = 160 * prevalue;
                            m_csBloodRed.SetSpriteSize(new Vector2(width, 10.0f));
                            prevalue = prevalue - mValue;
                            float tween = width - 160 * prevalue;           //血量减少量
                            SetBloodTween(m_csBloodRed, tween);
                        }
                    }
                    else
                    {
                        float mValue = nowvalue * 2;
                        m_hpProgress.SetValue(mValue);
                        if (null != m_csBlood)
                            m_csBlood.SetSprite("progressbar_monster_full");
                        if (null != m_csBloodRed)
                            m_csBloodRed.SetActive(false);
                        if (null != m_csBloodDeep)
                            m_csBloodDeep.SetActive(false);
                        if (null != m_csBloodRedDeep)
                        {
                            float width = 160 * prevalue;
                            m_csBloodRedDeep.SetSpriteSize(new Vector2(width, 10.0f));
                            prevalue = prevalue - mValue;
                            float tween = width - 160 * prevalue;           //血量减少量
                            SetBloodTween(m_csBloodRedDeep, tween);
                        }
                    }
                }
                break;
            case eNpcSortType.LeaderMonster:
            case eNpcSortType.NormalMonster:
                {
                    m_hpProgress.SetValue(nowvalue);
                    if (null != m_csBloodDeep)
                    {
                        float width = 97 * prevalue;
                        m_csBloodDeep.SetSpriteSize(new Vector2(width, 11.0f));
                        prevalue = prevalue - nowvalue;
                        float tween = width - 97 * prevalue;
                        SetBloodTween(m_csBloodDeep, tween);
                    }
                }
                break;
            case eNpcSortType.ChapterBoss:
            case eNpcSortType.WorldBoss:
            case eNpcSortType.SociatyBoss:
                {
                    if (null != m_csBloodDeep)
                    {
                        float width = 250 * prevalue;
                        m_csBloodDeep.SetSpriteSize(new Vector2(width, 12.0f));
                        prevalue = prevalue - nowvalue;
                        float tween = width - 250 * prevalue;
                        SetBloodTween(m_csBloodDeep, tween);
                    }
                }
                break;
            default:
                {
                    m_hpProgress.SetValue(nowvalue);
                }
                break;
        }
    }

    UITweenControl<TweenWidth> m_tweenwBlood = new UITweenControl<TweenWidth>();

    private void SetBloodTween(CSprite go, float width)
    {
        if (width >= 0)
        {
            m_tweenwBlood.SetFinishDelegate(BloodTweenFinish);
            m_tweenwBlood.Begin(go.ElementObj, go.GetSpriteSize().x, width, 0.5f, 0.0f);
        }
    }

    private void BloodTweenFinish()
    {
        m_tweenwBlood.RemoveEventDelegate();
    }

    public virtual void AddHp(int nHp, bool critical = false, CBaseNpc attack = null, bool fromMsg = false)
    {
        //if (this is AIFriend)
        {
            //MyLog.LogError(" AddHp : " + nHp + " maxHp: " + m_pCard.nMaxHp + " Hp : " + m_nHp);
        }

        //gamover后可能有倒计时 会吃血
        if (m_pBattleScene.IsGameOver() && NpcSort == eNpcSort.Avatar && nHp < 0)
        {
            return;
        }

        int oldHp = m_nHp;

        m_nHp += nHp;

        if (m_pBattleScene.IsNewPlayer && this is Avatar) //新手关锁血
        {
            if (m_nHp < m_pCard.nMaxHp * 0.2f)
            {
                m_nHp = Mathf.RoundToInt(m_pCard.nMaxHp * 0.2f);
            }

        }


        if (m_nHp > m_pCard.nMaxHp)
        {
            m_nHp = m_pCard.nMaxHp;
        }

        //锁血
        if (LockHP && m_nHp < LockHPValue)
        {
            m_nHp = LockHPValue;
        }
        if (this is Monster)
            TriggerManager.GetInst().NpcHPLessThan(m_uiNpcType, ref m_nHp);

        if (m_nHp <= 0)
        {
            if (IsKill())
            {
                NpcDead(true, attack);
            }
            else
            {
                m_nHp = 1;
            }
        }

        if (oldHp != m_nHp)
        {
            RrefeshHPComponent();
        }

        if (m_pAI != null)
        {
            float fPercent = m_nHp / (float)m_pCard.nMaxHp;
            m_pAI.UpdateCondition(eExtraAICondition.Hp, fPercent.ToString());

            if (nHp < 0)
            {
                m_pAI.UpdateCondition(eExtraAICondition.TotalDamage, nHp.ToString());
            }

        }
    }

    public virtual void AddMaxHp(int nMaxHp)
    {

    }




    public stCharacterCard CharacterCard
    {
        set { m_pCard = value; }
        get { return m_pCard; }
    }

    public stCharacterCard OriginCard
    {
        get { return m_pOriginCard; }
    }

    //无敌
    public void InvincibleGMCommand()
    {
        m_pCard.nAttack = 9999999;
        m_pCard.nHitRate = 9999999;
        m_pCard.nDefence = 9999999;
        m_pCard.nMaxHp = 99999999;

        m_pOriginCard.nAttack = 9999999;
        m_pOriginCard.nHitRate = 9999999;
        m_pOriginCard.nDefence = 9999999;
        m_pOriginCard.nMaxHp = 99999999;

        m_nHp = 99999999;
    }

    public void UpdateCharacterCard()
    {
        UpdateBuffAttr();

        //UpdateAuraAttr();
    }


    private double GetTechAttr(double attrValue, List<int> list)
    {
        double result = attrValue;
        if (list.Count != 2)
        {
            MyLog.LogError("GetTechAttr error,list.Count != 2");
            return result;
        }
        byte type = (byte)(list[0]);
        int value = list[1];

        if (type == 1)//数值
        {
            result += value;
        }
        else if (type == 2)//百分比
        {
            result = (double)(result * (1 + value / 10000.0f));
        }

        return result;
    }


    private int GetTechAttr(int attrValue, List<int> list)
    {
        return (int)GetTechAttr((double)attrValue, list);
    }

    private float GetTechAttr(float attrValue, List<int> list)
    {
        return (float)GetTechAttr((double)attrValue, list);
    }


    //直接增加百分比
    private float GetTechAttrPercent(float baseValue, List<int> list)
    {
        float result = baseValue;
        if (list.Count != 2)
        {
            MyLog.LogError("GetTechAttr error,list.Count != 2");
            return result;
        }

        int value = list[1];

        result += value / 10000f;

        return result;
    }

    //更新Buff属性
    public void UpdateBuffAttr()
    {
        if (null == m_buffMgr)
        {
            return;
        }
        //清空
        m_pBuffCard = new stCharacterCard(1);

        //////////////////////////////////////////////////////////////////////////
        ///buff 
        float fStunTime = 0f;
        float fFrostTime = 0f;
        float fInvincibeTime = 0f;
        float fOverlordTime = 0f;
        float fHideTime = 0f;

        float fMoveSpeed_Buff = m_pOriginCard.fMoveSpeed; //buff move 移动速度
        float fWalkSpeed_Buff = m_pOriginCard.fWalkSpeed; //buff walk 移动速度

        //更新buff
        Dictionary<uint, CBuff> buffDict = m_buffMgr.GetBuffDict();
        foreach (KeyValuePair<uint, CBuff> kvp in buffDict)
        {
            CBuff pBuff = kvp.Value;
            if (null == pBuff) continue;

            BuffContent pBuffLoader = pBuff.BuffLoader;
            if (null == pBuffLoader) continue;

            int nMount = pBuff.Amount;

            float addPromotion = pBuff.BuffEffectPromotion;
            //////////////////////////////////////////////////////////////////////////
            //buff 字段效果            
            //移动速度
            fMoveSpeed_Buff = fMoveSpeed_Buff * (1 + pBuffLoader.ChangeSpeed / 10000f);
            fWalkSpeed_Buff = fWalkSpeed_Buff * (1 + pBuffLoader.ChangeSpeed / 10000f);

            //伤害减免 百分比
            //法力护盾 伤害减免
            if (pBuffLoader.MagicShield.Count > 1)
            {
                m_pBuffCard.fDamageRatio *= (1 - pBuffLoader.MagicShield[1] / 10000f);
            }

            //  如有有伤害减免a,有伤害减免b 那么伤害减免为: (1-a%) * (1 - b%)
            if (pBuffLoader.DamageAbsorb != 0)
            {
                m_pBuffCard.fDamageRatio *= Mathf.Pow((1 - pBuffLoader.DamageAbsorb / 10000), nMount) * (1 + addPromotion);
            }

            //伤害转血
            float promotion = nMount * pBuffLoader.DamageMakeHP / 10000f * (1 + addPromotion);

            m_pBuffCard.fDamageAddHp = m_pBuffCard.fDamageAddHp != 0 ? m_pBuffCard.fDamageAddHp * (1 + promotion) : 1 + promotion;
            //m_pBuffCard.fDamageAddHp += nMount * pBuffLoader.GetDamageMakeHP() * (1 + addPromotion);

            //伤害反弹
            m_pBuffCard.fDamageReflex += nMount * pBuffLoader.DamageReflex / 10000f * (1 + addPromotion);

            //吸血
            m_pBuffCard.fLifeSteal += nMount * pBuffLoader.LifeStealblood / 10000f * (1 + addPromotion);

            //攻速变更
            m_pBuffCard.fChangeAtkSpeed += nMount * pBuffLoader.ChangeAtkSpeed / 10000f * (1 + addPromotion);

            //眩晕
            if (pBuffLoader.IsStun)
            {
                if (pBuff.LeftTime == -1f)
                {
                    fStunTime = -1f;
                }
                else
                {
                    fStunTime = fStunTime < pBuff.LeftTime ? pBuff.LeftTime : fStunTime;
                }
            }

            //冰冻
            if (pBuffLoader.IsFrost)
            {
                if (pBuff.LeftTime == -1f)
                {
                    fFrostTime = -1f;
                }
                else
                {
                    fFrostTime = fFrostTime < pBuff.LeftTime ? pBuff.LeftTime : fFrostTime;

                }
            }

            //无敌
            if (pBuffLoader.IsInvincibility)
            {
                if (pBuff.LeftTime == -1f)
                {
                    fInvincibeTime = -1f;
                }
                else
                {
                    fInvincibeTime = fInvincibeTime < pBuff.LeftTime ? pBuff.LeftTime : fInvincibeTime;
                }

            }

            //霸体
            if (pBuffLoader.IsOverlord)
            {
                if (pBuff.LeftTime == -1f)
                {
                    fOverlordTime = -1f;
                }
                else
                {
                    fOverlordTime = fOverlordTime < pBuff.LeftTime ? pBuff.LeftTime : fOverlordTime;
                }
            }

            //隐藏
            if (pBuffLoader.IsHide)
            {
                if (pBuff.LeftTime == -1f)
                {
                    fHideTime = -1f;
                }
                else
                {
                    fHideTime = fHideTime < pBuff.LeftTime ? pBuff.LeftTime : fHideTime;

                }
            }

            //////////////////////////////////////////////////////////////////////////

            //buff 对应属性效果
            UpdateAttribute(nMount, (uint)pBuffLoader.AttrID, ref m_pBuffCard, pBuff.BuffEffectPromotion);
        }

        //buff效果 处理
        m_pBuffCard.fStun = fStunTime;
        if (fStunTime != 0)
        {
            CStunState stunState = m_stateMgr.GetState(eActionState.Stun) as CStunState;
            EnterState(eActionState.Stun);
            stunState.SetTimer(fStunTime); //取最大时间
        }

        m_pBuffCard.fFrost = fFrostTime;
        if (fFrostTime != 0)
        {
            CFrostState stunState = m_stateMgr.GetState(eActionState.Frost) as CFrostState;
            EnterState(eActionState.Frost);
            stunState.SetTimer(fFrostTime); //取最大时间
        }
        m_pBuffCard.fInvincible = fInvincibeTime;
        m_pBuffCard.fOverold = fOverlordTime;
        m_pBuffCard.fHide = fHideTime;

        float hpPercent = (float)(m_pCard.nMaxHp != 0 ? m_nHp * 1f / m_pCard.nMaxHp * 1f : 1f);

        m_pBuffCard.fMoveSpeed = fMoveSpeed_Buff - m_pOriginCard.fMoveSpeed; //增量
        m_pBuffCard.fWalkSpeed = fWalkSpeed_Buff - m_pOriginCard.fWalkSpeed; //增量

        //buff加成属性
        m_pCard = m_pOriginCard + m_pBuffCard;

        //movespeed 需要处理
        MoveSpeed = m_pCard.fMoveSpeed;
        WalkSpeed = m_pCard.fWalkSpeed;

        //加成后血量处理
        m_nHp = (int)(Mathf.Ceil(hpPercent * m_pCard.nMaxHp)); //向上取整

    }


    //被光环作用的属性
    //     public void UpdateAuraAttr()
    //     {
    //         //清空
    //         m_pAuraCard = new stCharacterCard();
    // 
    //         foreach (KeyValuePair<CAura, uint> kvp in m_auraDict)
    //         {
    //             CAura aura = kvp.Key;
    //             if (null == aura) continue;
    // 
    //             UpdateAttribute(1, aura.AttrLoaderKey, ref m_pAuraCard, aura.AuraEffectPromotion);
    //         }
    //         //加成前血量百分比
    //         float hpPercent = m_pCard.nMaxHp != 0 ? m_nHp * 1f / m_pCard.nMaxHp * 1f : 1f;
    //         //光环加成属性
    //         m_pCard = m_pOriginCard + m_pAuraCard + m_pBuffCard;
    //         //movespeed 需要处理
    //         MoveSpeed = m_pCard.fMoveSpeed;
    //         //加成后血量处理
    //         m_nHp =  (int)(Mathf.Ceil(hpPercent * m_pCard.nMaxHp)); //向上取整
    // 
    //     }

    public void UpdateAttribute(int nMount, uint uiAttrID, ref stCharacterCard card, float addPromotion = 0)
    {
        AttrContent pAttrInfo = HolderManager.m_AttrHolder.GetStaticInfo(uiAttrID);
        if (null == pAttrInfo) return;

        if (pAttrInfo.Target == (byte)eAttrTarget.Defence) return;

        if (pAttrInfo.AttrType != (byte)eAttrType.HelpfulBuff &&
            pAttrInfo.AttrType != (byte)eAttrType.DownsideBuff) return;

        int nRate = 1;
        if (pAttrInfo.AttrType == (byte)eAttrType.DownsideBuff)
        {
            nRate = -1;
        }

        // addPromotion 技能等级 提升属性效果        

        card.nMaxHp += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nMaxHp, pAttrInfo.MaxHpList) * (1 + addPromotion));

        card.nAttack += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nAttack, pAttrInfo.AttackList) * (1 + addPromotion));

        card.nDefence += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nDefence, pAttrInfo.DefenceList) * (1 + addPromotion));

        //命中值
        card.nHitRate += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nHitRate, pAttrInfo.HitRateList) * (1 + addPromotion));
        //闪避值
        card.nDodge += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nDodge, pAttrInfo.DodgeList) * (1 + addPromotion));
        //暴击值
        card.nBingo += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nBingo, pAttrInfo.BingoList) * (1 + addPromotion));

        //命中率
        card.fHitRateAddition += (nMount * CountBuffPowerPercent(pAttrInfo.HitRatePercentList) * (1 + addPromotion));
        //闪避率
        card.fDodgeAddition += nMount * CountBuffPowerPercent(pAttrInfo.DodgePercentList) * (1 + addPromotion);
        //暴击率
        card.fBingoAddition += (float)nMount * CountBuffPowerPercent(pAttrInfo.BingoPercentList) * (1 + addPromotion);
        //伤害加成
        float promotion = nMount * CountBuffPower(m_pOriginCard.fDamagePromote, pAttrInfo.DamageList) * (1 + addPromotion);
        promotion = Mathf.Max(promotion, 0f);

        card.fDamagePromote = card.fDamagePromote != 0 ? card.fDamagePromote * (1 + promotion) : (1 + promotion);

        //card.nDarkResis += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nDarkResis, pAttrInfo.GetDarkResisList()) * (1 + addPromotion));

        //card.nLightningResis += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nLightningResis, pAttrInfo.GetLightingResisList()) * (1 + addPromotion));

        //card.nFireResis += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nFireResis, pAttrInfo.GetFireResisList()) * (1 + addPromotion));

        //card.nColdResis += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nColdResis, pAttrInfo.GetColdResisList()) * (1 + addPromotion));

        //card.nSunResis += (int)(nRate * nMount * CountBuffPower(m_pOriginCard.nSunResis, pAttrInfo.GetSunResisList()) * (1 + addPromotion));


    }

    public void EnterAura(CAura pAura, CSkillupInfo skillUpInfo,float dragonPromotion = 0f)
    {
        if (!m_auraList.Contains(pAura))
        {
            m_auraList.Add(pAura);
            AddBuff(pAura.BuffID, skillUpInfo,false,dragonPromotion);
        }
    }

    public void LeaverAura(CAura aura)
    {
        if (m_auraList.Contains(aura))
        {
            m_auraList.Remove(aura);
            DelBuff(aura.BuffID);
        }
    }

    public float CountBuffPower(float nBaseAttr, List<int> list)
    {
        return (float)CountBuffPower((double)nBaseAttr, list);
    }

    public int CountBuffPower(int nBaseAttr, List<int> list)
    {
        return (int)CountBuffPower((double)nBaseAttr, list);
    }

    public double CountBuffPower(double nBaseAttr, List<int> list)
    {
        if (list.Count != 4)
        {
            return 0;
        }
        byte byAttrMode = MyConvert_Convert.ToByte(list[0]);
        int nValue = list[1];
        //int nBeforeValue = list[2];//转化前属性
        //int nAfterValue = list[3];//转化后属性

        double nResult = 0;

        switch ((eAttrMode)byAttrMode)
        {
            case eAttrMode.Percent:
                {
                    nResult = (double)(nBaseAttr * nValue / 10000.0f);
                }
                break;
            case eAttrMode.Value:
                {
                    nResult = nValue;
                }
                break;
            case eAttrMode.Translate:
                {
                }
                break;
        }

        return nResult;
    }

    //得出增加的百分比
    private float CountBuffPowerPercent(List<int> list)
    {
        if (list.Count < 1)
        {
            MyLog.LogError(" CountBuffPowerPercent error , count less than 1. ");
            return 0f;
        }
        float value = (float)list[0] / 10000f;

        return value;
    }

    public CStateManager GetStateMgr()
    {
        return m_stateMgr;
    }

    public eActionState GetCurrActState()
    {
        return m_stateMgr.GetCurrActState();
    }

    public CBaseState GetCurrState()
    {
        return m_stateMgr.GetCurrState();
    }

    public virtual void EnterState(eActionState state, bool forceBreak = false)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.EnterState(state, forceBreak);
            if (NpcEnterStateEvent != null)
            {
                NpcEnterStateEvent(this, state);
            }
            ResetWeaponAnimtor();
        }
    }


    public void ResetWeaponAnimtor() 
    {
        if (m_leftWeaponAnimator != null)
        {
            m_leftWeaponAnimator.PlayAction("idle", 1.0f, false, null, 0f);
        }

        if (m_rightWeaponAnimaror != null)
        {
            m_rightWeaponAnimaror.PlayAction("idle", 1.0f, false, null, 0f);
        }
    }

    public void LeaveState(eActionState state)
    {
        if (m_stateMgr != null)
        {
            m_stateMgr.LeaveState(state);
        }
    }


    public void PlayAction(eActionState state, float fSpeed = 1.0f, bool bRepeat = false, float fadeTime = 0.05f)
    {
        if (null != m_pAnimator)
        {
            string actionName = stStateData.GetActionName(state);
            PlayAction(actionName, fSpeed, bRepeat, null, fadeTime);

            //MyLog.Log("Npc " +m_uiIndex + " _______ PlayAction : " + actionName + "speed : " + fSpeed);
        }
    }

    public virtual void PlayAction(string actionName, float fSpeed = 1.0f, bool bRepeat = false, PlayOnceFinised playCallBack = null, float fadeTime = 0.05f, object[] parms = null)
    {
        if (null != m_pAnimator)
        {
            m_pAnimator.PlayAction(actionName, fSpeed, bRepeat, playCallBack, fadeTime, parms);
        }

        //MyLog.Log(" _______ PlayAction : " + actionName);
    }

    public void SetAnimationSpeed(float fSpeed)
    {
        if (m_pAnimator != null)
        {
            m_pAnimator.Speed = fSpeed;
        }
    }

    public string PlayActionName
    {
        get
        {
            return m_pAnimator.PlayActionName;
        }
    }

    //是否显示加血飘字
    public bool ShowAddHpFlyWord(int nAddHp)
    {
        if (m_pBattleScene.IsGameOver())
        {
            return false;
        }
        if (nAddHp > 0 && m_pBattleScene.GetSceneLoader().Key == DEFINE.NEW_PLAYER_SCENE_ID)
        {
            return false;
        }

        if (nAddHp > 0 && IsFullHp())
        {
            return false;
        }
        return true;
    }

    //是否满血
    public bool IsFullHp()
    {
        return m_pCard.nMaxHp <= m_nHp;
    }

    //是否眩晕
    public bool IsStun()
    {
        bool stunState = GetCurrActState() == eActionState.Stun;
        return m_pCard.fStun != 0 || stunState;
    }


    //是否无敌
    public bool IsInvincibility()
    {
        if (null == m_buffMgr) return false;

        if ((CurrBattleScene.BattleType == eBattleType.Arena ||
            CurrBattleScene.BattleType == eBattleType.Wasteland ||
            CurrBattleScene.BattleType == eBattleType.Mining ||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
            && (this is RealAvatar || this is EnemyAvatar))//竞技场、末日荒野无敌无效
        {
            BaseBattlePlayer pbbp = this as BaseBattlePlayer;
            if (pbbp.IsActurallyInRide() || pbbp.IsActuallyInFly())
            {
                return false;
            }
        }
        return m_pCard.fInvincible != 0;
    }

    //是否霸体
    public virtual bool IsOverlord()
    {
        return m_pCard.fOverold != 0;
    }

    //是否隐形
    public bool IsHide()
    {
        return m_pCard.fHide != 0;
    }

    //是否冻结
    public bool IsFrost()
    {
        bool frost = GetCurrActState() == eActionState.Frost;
        return m_pCard.fFrost != 0 || frost;
    }

    //是否在移动平台上
    public bool IsInPlatform()
    {
        return m_bInPlatform;
    }


    public virtual bool IsDead() { return m_nHp <= 0; }

    //bNaturalDeath 是否正常死亡,如果是BOSS死亡连带小怪死亡的话属于非正常死亡
    public virtual void NpcDead(bool bNaturalDeath, CBaseNpc attack = null, bool fromMsg = false)
    {
        //npc死亡
        m_nHp = 0;

        CDeadState deadState = GetState(eActionState.Dead) as CDeadState;
        if (null != deadState)
        {
            deadState.Attacker = attack;
        }

        EnterState(eActionState.Dead);

        m_pBattleScene.LoseTarget(this);

        RemoveHpPanel();
        if (m_bIsFinalBoss)
        {
            SingletonObject<BattleInfoMediator>.GetInst().NpcValue(0.0f);
        }

        RemoveNpcAttr();

        SetFootEffect(false);

        if (null != GrabNpc)
        {
            Transform grabTrans = GrabNpc.GetTransform();
            grabTrans.parent = null;

            GrabNpc.IsBeGrab = false;
            GrabNpc.SetFootEffect(true);

            GrabNpc.GetTransform().rotation = Quaternion.identity;
            GrabNpc.SetPosition(Common.NavSamplePosition(GrabNpc.GetPosition()) + Vector3.up * 0.5f);
            GrabNpc.LeaveState(eActionState.Stun);


            //GrabNpc.DelBuff(DEFINE.FOREVER_STUN_BUFF_ID);

            GrabNpc = null;
        }


        if (m_characterController != null && NpcSort != eNpcSort.Avatar && NpcSort != eNpcSort.EnermyAvatar)
        {
            m_characterController.enabled = false;
        }
    }

    //移除npc的属性效果,如buff、光环等
    public void RemoveNpcAttr()
    {
        //删除buff
        if (null != m_buffMgr)
            m_buffMgr.Release(false);

        //删除光环
        if (null != m_pAuraMgr)
            m_pAuraMgr.Release();

        //         //小弟陪葬 
        //         int len = m_allyList.Count;
        //         for (int i = 0; i < len; i++)
        //         {
        //             Monster monster = m_allyList[i];
        //             monster.NpcDead(true);
        //         }
        //         if (len > 0)
        //             m_allyList.Clear();
        if (m_pAI != null)
        {
            m_pAI.UpdateCondition(eExtraAICondition.Dead, "");
        }

    }

    public void RemoveHpPanel()
    {
        if (m_pHpPanel != null)
        {
            SingletonObject<HpFrameMediator>.GetInst().RemoveItem(m_pHpPanel);
            m_pHpPanel = null;
        }

        m_hpProgress = null;
    }

    public virtual void RemoveNpc()
    {
        Dictionary<uint, CBaseNpc> npcDict = m_pBattleScene.GetNpcDict();
        foreach (KeyValuePair<uint, CBaseNpc> kvp in npcDict)
        {
            kvp.Value.NpcLeaveRange(this);
        }

        Dictionary<uint, CBaseNpc> mechDict = m_pBattleScene.GetMechanismDirect();
        foreach (KeyValuePair<uint, CBaseNpc> kvp in mechDict)
        {
            kvp.Value.NpcLeaveRange(this);
        }
    }

    public void PauseNpc(bool bPause, bool immediately)
    {
        //if (NpcSort == eNpcSort.Pet)
        //{
        //    return;
        //}
        //m_bPaused = bPause;
        //m_bPausedMove = bPause;
        //if (m_bPaused && m_stateMgr != null)
        //{
        //    eActionState state = m_stateMgr.GetCurrActState();

        //    switch (state)
        //    {
        //        case eActionState.Walk:
        //        case eActionState.Run:
        //        case eActionState.Roll:
        //            {
        //                EnterState(eActionState.Idle);
        //            }
        //            break;
        //    }
        //}
        if (IsDead())
            return;
        PauseCheckBehave(bPause);
        PauseMoveBehave(bPause, immediately);
    }

    public void PauseCheckBehave(bool bPause)
    {
        if (NpcSort == eNpcSort.Pet)
        {
            return;
        }
        m_bPausedCheck = bPause;
    }

    public void StopSimpleMove(bool bStop)
    {
        m_bStopSimpleMove = bStop;
    }

    public void PauseMoveBehave(bool bPause, bool immediately)
    {
        if (NpcSort == eNpcSort.Pet)
        {
            return;
        }
        m_bPausedMove = bPause;
        if (bPause && m_stateMgr != null)
        {
            if (immediately && this is Avatar)
            {
                EnterState(eActionState.Idle);
            }
            else
            {
                eActionState state = m_stateMgr.GetCurrActState();

                switch (state)
                {
                    case eActionState.Walk:
                    case eActionState.Run:
                    case eActionState.Roll:
                        {
                            EnterState(eActionState.Idle);
                        }
                        break;
                    case eActionState.Attack:
                        {
                            EnterState(eActionState.Idle);
                        }
                        break;
                }
            }
        }
    }

    public void PauseCreateParticle(bool bPause)
    {
        if (null != m_createParticleList)
        {
            for (int i = 0, len = m_createParticleList.Count; i < len; i++)
            {
                uint index = m_createParticleList[i];
                CParticle pParticle = CParticleManager.GetInst().GetParticle(index);
                if (null != pParticle)
                {
                    pParticle.Pause(bPause);
                }
            }
        }
    }


    public void Pause(bool bPause)
    {
        if (m_bStop == bPause)
            return;

        m_bStop = bPause;

        PauseCreateParticle(bPause);

        if (!IsDead())
        {
            if (null != m_pAnimator)
                m_pAnimator.Enabled = !bPause;

            if (!bPause) //暂停恢复后从idle开始
                EnterState(eActionState.Idle);
        }

    }



    public virtual void LateUpdate()
    {

    }

    public virtual void Update()
    {
        if (m_liveState != eLiveState.NONE)
        {
            ChangeShaderColor(m_liveState);
        }

        if (m_bStop)
            return;

        if (null == m_myTrans)
        {
            return;
        }


        if (m_comboTimer.IsExpired(false))
        {
            BreakNormalSkill(DefaultSkillID);
        }

        if (m_stateMgr != null)
        {
            m_stateMgr.Update();

            if (IsChest())
            {
                if (m_stateMgr.GetCurrActState() == eActionState.Dead)
                {
                    if (null != m_pAnimator)
                    {
                        m_pAnimator.Update();
                    }
                }
            }
            else
            {
                if (null != m_pAnimator)
                {
                    m_pAnimator.Update();
                }
            }
        }

        if (null != m_pAuraMgr)
        {
            m_pAuraMgr.Update();
        }

        if (m_buffMgr != null)
        {
            m_buffMgr.Update();
        }


        if (m_leftWeaponAnimator != null)
        {
            m_leftWeaponAnimator.Update();
        }

        if (m_rightWeaponAnimaror != null)
        {
            m_rightWeaponAnimaror.Update();
        }

        if (null != m_pRagdoll)
        {
            m_pRagdoll.Update();
        }



        if (m_pHpPanel != null)
        {
            if (m_pHpPanel.IsActive())
            {
                Vector3 hpPosition = GetPosition();
                hpPosition = new Vector3(hpPosition.x, hpPosition.y + FBodyHeight /** m_modelSize*/ + 0.2f, hpPosition.z);

                SingletonObject<HpFrameMediator>.GetInst().UpdatePosition(m_pHpPanel, hpPosition);
            }
        }

        if (m_chatBobble != null)
        {
            SingletonObject<ChatBubbleMediator>.GetInst().UpdatePosition(m_chatBobble, GetPosition());
        }

        CheckGoThroughAirWall();

    }


    //设置当前跟踪的对象
    public void SetFollowTransform(Transform followtrans, bool bUsePathFinding, bool setDesposition = false)
    {
        m_followTrans = followtrans;

        if (setDesposition)
        {
            m_destPosition = m_followTrans.position;
        }

        EnablePathFinding(bUsePathFinding);
    }


    public void UpdateDestPosition()
    {
        if (m_myTrans == null)
        {
            return;
        }
        m_fDeceleratePercent = 0;
        m_destPosition = m_myTrans.position;
        m_lastMovePosition = Vector3.zero;

    }

    //bUsePathFinding使用自动寻路
    public void SetDestPosition(Vector3 destPosition, bool bUsePathFinding)
    {
        m_followTrans = null;
        m_fDeceleratePercent = 0;

        EnablePathFinding(bUsePathFinding);

        m_destPosition = destPosition;
        m_lastMovePosition = Vector3.zero;
    }

    public Vector3 GetDestPosition()
    {
        return m_destPosition;
    }


    public void EnablePathFinding(bool bEnabled)
    {
        m_bUsePathFinding = bEnabled;

    }

    //找到目标点旁可以移动到的网格点,仅用于抓取投掷用
    public Vector3 GetNavMeshEdgePosition(CBaseNpc beGragNpc)
    {
        Vector3 attackPosition = GetPosition();
        Vector3 beDragPosition = Common.NavSamplePosition(beGragNpc.GetPosition());
        float distance = 1;
        float maxDistance = Vector3.Distance(attackPosition, beDragPosition);
        Vector3 destPosition = Vector3.zero;

        while (true)
        {
            Vector3 tmpPosition = Common.GetRayPosition(attackPosition, beDragPosition, distance);
            tmpPosition = Common.NavSamplePosition(tmpPosition);
            SetNavmeshEnable(true);
            m_nma.CalculatePath(tmpPosition, m_nmp);

            if (m_nmp.status != NavMeshPathStatus.PathPartial)//能移动到该点
            {
                distance += 1.0f;
                destPosition = tmpPosition;
                if (distance > maxDistance)
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }

        return destPosition;
    }

    public virtual bool CanMove
    {
        set
        {
            m_bMove = value;
        }
        get
        {
            return m_bMove;
        }

    }

    public virtual bool CanTurn
    {
        set
        {
            m_bTurn = value;
        }
        get
        {
            return m_bTurn;
        }

    }

    public bool CanBeHit
    {
        get
        {
            if (IsOverlord() || IsInvincibility() || IsFrost()) return false;

            return true;
        }
    }

    //是否可被击倒
    public bool CanBeatDown
    {
        get
        {
            if (IsOverlord() || IsInvincibility() || IsFrost() || !IsHitDown()) return false;

            return true;
        }
    }

    //是否可被击飞
    public bool CanBeatFly
    {
        get
        {
            if (IsOverlord() || IsInvincibility() || IsFrost() || !IsBeatFly()) return false;

            return true;
        }
    }

    //是否可被吸引
    public virtual bool CanBeAttract
    {
        get
        {
            if (IsOverlord() || IsInvincibility())
                return false;

            return true;
        }
    }

    //是否可为布娃娃受击
    public bool CanRagdoll
    {
        get
        {
            //if ( IsOverlord() || IsInvincibility() ) return false;

            return true;
        }
    }

    //是否可被击晕、冻结
    public bool CanBeStun
    {
        get
        {
            //无敌不能被晕
            if (IsInvincibility() || !IsCanStun()) return false;

            //骑鸟骑马不能被晕
            if (this is BaseBattlePlayer)
            {
                BaseBattlePlayer pbbp = this as BaseBattlePlayer;
                if (pbbp.IsInFly() || pbbp.IsInRide())
                {
                    return false;
                }
            }

            return true;
        }
    }

    //是否可被减速
    public bool CanReduceSpeed
    {
        get
        {
            if (IsInvincibility() || !IsSlow()) return false;

            return true;
        }
    }

    //是否可被抓取
    public virtual bool CanBeGrab
    {
        get
        {
            return (false == IsInvincibility());
        }
    }

    //是否为被抓取
    public bool IsBeGrab
    {
        set { m_bIsBeGrab = value; }
        get { return m_bIsBeGrab; }
    }

    public float TurnSpeed
    {
        set
        {
            m_turnSpeed = value;
        }
    }

    private void SetMoveActionSpeed(float moveSpeed)
    {
        CBaseState currState = m_stateMgr.GetCurrState();
        if (currState != null && m_AniMoveSpeed != null)
        {
            if (m_AniMoveSpeed.Count == 2)
            {
                switch (currState.GetState())
                {
                    case eActionState.Run:
                    case eActionState.Assault:
                    case eActionState.BossRamble:
                        {
                            //暂定
                            currState.SetActionSpeed(moveSpeed / m_AniMoveSpeed[0]);
                        }
                        break;
                    case eActionState.Walk:
                        {
                            if (this is BaseBattlePlayer)
                            {
                                m_fDeceleratePercent += 1;
                                if (m_fDeceleratePercent > 80)
                                {
                                    LeaveState(eActionState.Walk);
                                }
                                //暂定                                
                                currState.SetActionSpeed(moveSpeed / m_AniMoveSpeed[1]);
                            }
                        }
                        break;
                    case eActionState.Attack:
                        {
                            if (NpcSort == eNpcSort.Avatar)
                            {
                                Avatar pAvatar = (Avatar)this;
                                if (pAvatar.IsInRide() || pAvatar.IsInFly())
                                {
                                    currState.SetActionSpeed(moveSpeed / m_AniMoveSpeed[0]);
                                }
                            }
                        }
                        break;
                }
            }
        }

    }

    public virtual void UpdateTurn(Vector3 turnDirection, bool bImmediate, bool bNewbieuse = false)
    {

        if ((CanTurn || bNewbieuse) && turnDirection != Vector3.zero)
        {
            Quaternion rot = m_myTrans.rotation;
            Quaternion toTarget = Quaternion.LookRotation(turnDirection);

            //             if (Quaternion.Angle(rot, toTarget) < 5)
            //             {
            //                 return;
            //             }

            if (bImmediate)
            {
                rot = toTarget;
            }
            else
            {
                float rtime = Common.TimeScale;
                if (rtime != 0)
                {
                    rot = Quaternion.Slerp(rot, toTarget, m_turnSpeed / rtime * Time.deltaTime);
                }
            }

            Vector3 euler = rot.eulerAngles;
            euler.z = 0;
            euler.x = 0;

            m_myTrans.rotation = Quaternion.Euler(euler);
        }
    }
    //命中率闪避概率计算
    private bool IsDodge(CBaseNpc pAttack, CBaseNpc pDefence)
    {
        stCharacterCard pAttackCard = pAttack.CharacterCard;
        stCharacterCard pDefenceCard = pDefence.CharacterCard;
        bool bDodge = false;
        float nHitRate = pAttackCard.nHitRate + 500.0f;
        float nDodge = pDefenceCard.nDodge + 500.0f;
        float BeHitScale = nHitRate / nDodge;
        //命中率
        float fRange = Mathf.Pow(1.95f, BeHitScale) - 1.075f;
        fRange = fRange + pAttackCard.fHitRateAddition; //nAbsolutelyHitRate 命中加成
        fRange -= pDefenceCard.fDodgeAddition; // nAbsolutelyDodge 闪避加成

        if (fRange >= 1.0f)
        {
            fRange = 1.0f;
        }
        else if (fRange <= 0.60f)
        {
            fRange = 0.60f;
        }
        float random = UnityEngine.Random.Range(0, 1.0f);

        if (random > fRange)
        {
            bDodge = true;
        }
        else
        {
            bDodge = false;
        }

        return bDodge;
    }


    /// <summary>
    /// 暴击率计算
    /// </summary>
    /// <param name="pAttackCard"></param>
    /// <param name="pDefenceCard"></param>
    /// <param name="fRepressValue">等级压制的暴击率提升</param>
    /// <returns></returns>
    private bool IsCritical(stCharacterCard pAttackCard, stCharacterCard pDefenceCard, float fRepressValue = 0f)
    {
        //基础暴击率=0.1*(2^((攻击方暴击值-受击方暴击值）/250))
        float nAttackCritical = pAttackCard.nBingo - pDefenceCard.nBingo;
        nAttackCritical /= 250.0f;

        float powCritical = Mathf.Pow(2.0f, nAttackCritical);
        // fCritical  暴击率
        float fCritical = powCritical * 0.1f + pAttackCard.fBingoAddition; //nAbsolutelyHitRate 加成的暴击率

        if (fCritical <= 0.05f)
        {
            fCritical = 0.05f;
        }
        else if (fCritical >= 0.5f)
        {
            fCritical = 0.5f;
        }
        fCritical += fRepressValue;

        float fRange = UnityEngine.Random.Range(0, 1.0f);

        if (fRange > fCritical)
        {
            return false;
        }

        return true;
    }

    //pAttack是本NPC
    protected virtual int BeHitDamage(CBaseNpc pAttack, CBaseNpc pDefence, uint uiAttrID, ref bool critical)
    {
        int nResultDamage = 0;
        critical = false;
        AttrContent pAttrInfo = HolderManager.m_AttrHolder.GetStaticInfo(uiAttrID);
        if (null == pAttrInfo)
        {
            return nResultDamage;
        }

        //是伤害还是治疗
        int nRatio = 1;

        switch ((eAttrType)pAttrInfo.AttrType)
        {
            case eAttrType.HelpfulBuff:
            case eAttrType.DownsideBuff:
                {
                    return nResultDamage;
                }
            //break;
            case eAttrType.AddValue:
                {
                    nRatio = 1;
                }
                break;
            case eAttrType.ReduceValue:
                {
                    nRatio = -1;
                }
                break;
        }

        eAttrTarget eTarget = (eAttrTarget)pAttrInfo.Target;
        CBaseNpc pTarget = null;
        switch (eTarget)
        {
            //以施法者为源计算
            case eAttrTarget.Attack:
                {
                    pTarget = pAttack;
                }
                break;
            case eAttrTarget.Defence:
                {
                    pTarget = pDefence;
                }
                break;
            default:
                {
                    MyLog.LogError("attribute error,Attr:" + uiAttrID + "has error target");
                    return nResultDamage;
                }
            //break;
        }

        stCharacterCard pAttackCard = pAttack.CharacterCard;
        stCharacterCard pDefenceCard = pDefence.CharacterCard;

        //计算总的物理攻击
        int nNormalAttack = pAttackCard.nAttack;
        int nNormalDefence = pDefenceCard.nDefence;

        //防御为0时,强制为1
        if (nNormalDefence <= 0) nNormalDefence = 1;
        //int nNormalDamage = (int)(Mathf.Pow(nNormalAttack * 0.8f / nNormalDefence, 3) * (nNormalDefence / 2.0f));

        int nNormalDamage = 0;
        //攻击/防御<3.66  伤害=roundup( (1.03^（攻击*0.8/防御)-0.78）* (0.64*攻击^2/防御) )
        if (nNormalAttack / nNormalDefence < 3.66f)
        {
            float temp = (float)(nNormalAttack * 0.8 / nNormalDefence);

            float value1 = Mathf.Pow(1.03f, temp) - 0.78f;
            float value2 = 0.64f * nNormalAttack * nNormalAttack / nNormalDefence;

            nNormalDamage = (int)Mathf.Ceil(value1 * value2);
        }
        else//攻击/防御>=1.25  伤害=攻击-防御
        {
            nNormalDamage = nNormalAttack - nNormalDefence;
        }

        nNormalDamage += CountDamagePower(pAttrInfo.AttackList, pTarget.CharacterCard.nAttack);


        //计算伤害加成
        nResultDamage += (nNormalDamage);

        //这里是根据表里的伤害加成来的,可能会小于100%
        nResultDamage = CountDamagePower(pAttrInfo.DamageList, nResultDamage);

        //计算暴击
        float fRepressValue = CBaseNpc.RepressCritChance(this, pDefence);
        if (nResultDamage != 0 && IsCritical(pAttackCard, pDefenceCard, fRepressValue))
        {
            //基础暴击伤害 150%
            float criticalFactor = 1.5f;
            if (this is BaseBattlePlayer)
            {
                if (pAttackCard.fBingoDamage > criticalFactor)
                {
                    criticalFactor = pAttackCard.fBingoDamage;
                }
            }

            float criticalDamage = nResultDamage * criticalFactor;
            nResultDamage = (int)criticalDamage;
            critical = true;

        }
        nResultDamage += CountDamagePower(pAttrInfo.HpList, pTarget.GetHp());

        int nMaxHpDamge = CountDamagePower(pAttrInfo.MaxHpList, pTarget.GetMaxHp());
        if (nRatio < 0)
        {
            //伤害才伤害减免
            nMaxHpDamge = (int)(nMaxHpDamge * MaxHpReduceRatio(pAttrInfo.MaxHpList, pTarget));
        }

        nResultDamage = (int)(nResultDamage + nMaxHpDamge);

        if (nResultDamage < 3)
        {
            nResultDamage = UnityEngine.Random.Range(1, 4);
        }
        nRatio = nRatio * nResultDamage;

        return nRatio;
    }


    public static float RepressCritChance(CBaseNpc attack, CBaseNpc target)
    {
        float repressValue = 0f;

        BaseBattlePlayer atkbbp = attack as BaseBattlePlayer;
        BaseBattlePlayer tagbbp = target as BaseBattlePlayer;
        SkillNpc atksn = attack as SkillNpc;

        if (null == tagbbp)
        {
            return repressValue;
        }

        //判断是否为skillnpc
        if (null == atksn)
        {
            if (null == atkbbp)
            {
                return repressValue;
            }
        }
        else
        {
            BaseBattlePlayer bbp = atksn.ParentNpc as BaseBattlePlayer;
            if (null == bbp)
            {
                return repressValue;
            }
            else
            {
                atkbbp = bbp;
            }
        }


        //效果1：对低于XX等级的敌人暴击率提高10%
        if (attack.NpcLevel > target.NpcLevel)
        {
            repressValue = attack.CharacterCard.fRepressCrit;
        }

        //对低于X阶的坐骑的暴击率提高x%
        int atkMountRank = (int)atkbbp.MountID % 10000 / 100;
        int tarMountRank = (int)tagbbp.MountID % 10000 / 100;
        if (atkMountRank > tarMountRank)
        {
            repressValue += atkbbp.RepressCritByMount;
        }

        //对低于X阶的宠物的暴击伤害提高x%
        int atkPetRank = (int)atkbbp.PetID % 10000 / 100;
        int tarPetRank = (int)tagbbp.PetID % 10000 / 100;
        if (atkPetRank > tarPetRank)
        {
            repressValue += atkbbp.RepressCritByPet;
        }

        return repressValue;
    }

    public static float RepressDamage(eRepressType type, CBaseNpc attack, CBaseNpc target)
    {
        float repressValue = 0f;

        BaseBattlePlayer atkbbp = attack as BaseBattlePlayer;
        BaseBattlePlayer tagbbp = target as BaseBattlePlayer;

        SkillNpc atksn = attack as SkillNpc;
        if (null == tagbbp)
        {
            return repressValue;
        }

        //判断是否为skillnpc
        if (null == atksn)
        {
            if (null == atkbbp)
            {
                return repressValue;
            }
        }
        else
        {
            BaseBattlePlayer bbp = atksn.ParentNpc as BaseBattlePlayer;
            if (null == bbp)
            {
                return repressValue;
            }
            else
            {
                atkbbp = bbp;
            }
        }

        switch (type)
        {
            case eRepressType.eBaseBattlePlayer:
                {
                    //对低于XX等级的敌人，每高出一级则造成的伤害提高0.5%
                    int differValue = atkbbp.NpcLevel - tagbbp.NpcLevel;
                    if (differValue > 0)
                    {
                        if (attack.CharacterCard.nRepressLevel <= differValue)
                        {
                            repressValue = atkbbp.CharacterCard.nRepressLevel * atkbbp.CharacterCard.fRepressDamage;
                        }
                        else
                        {
                            repressValue = differValue * attack.CharacterCard.fRepressDamage;
                        }
                    }
                }
                break;

        }

        return repressValue;
    }

    //maxhp的伤害减免系数
    public float MaxHpReduceRatio(List<int> maxHpList, CBaseNpc pNpc)
    {
        //         if (ClientMain.GetInst().EnterTestScene)
        //         {
        //             return 1f;
        //         }

        if ((eAttrMode)maxHpList[0] == eAttrMode.Percent)
        {
            if (pNpc is Monster)
            {
                if (pNpc.NpcSortType == eNpcSortType.EliteMonster ||
                    pNpc.NpcSortType == eNpcSortType.Turret ||
                    pNpc.NpcSortType == eNpcSortType.ChapterBoss ||
                    pNpc.NpcSortType == eNpcSortType.WorldBoss ||
                    pNpc.NpcSortType == eNpcSortType.SociatyBoss)
                {
                    return 0.01f;
                }
            }
            else if (pNpc is BaseBattlePlayer)
            {
                if (CurrBattleScene.BattleType == eBattleType.Arena ||
                    CurrBattleScene.BattleType == eBattleType.Mining ||
                    CurrBattleScene.BattleType == eBattleType.Wasteland ||
                    CurrBattleScene.BattleType == eBattleType.Pvp||
                    CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    return 0.01f;
                }
            }
        }

        return 1f;
    }


    private int CountDamagePower(List<int> attrList, int nNpcAttr)
    {
        int nCountDamage = 0;
        if (attrList.Count < 2)
        {
            MyLog.LogError("CountDamagePower error,attrList.Count < 2");
            return nCountDamage;
        }
        int nAttrType = attrList[0];
        int nAttrValue = attrList[1];


        switch (nAttrType)
        {
            case (int)eAttrMode.Percent:
                {
                    nCountDamage = (int)(nNpcAttr * (nAttrValue / 10000.0f));
                }
                break;
            case (int)eAttrMode.Value:
                {
                    nCountDamage = (int)nAttrValue;
                }
                break;
        }

        return nCountDamage;
    }

    //追击目标
    public void ChaseTarget(CBaseNpc pTarget)
    {
        SetFollowTransform(pTarget.GetTransform(), true);
        //  [6/13/2015 admin]
        //SetFollowTransform(pTarget.GetTransform(), false, true);
    }

    //是否可挣扎
    public bool CanStruggleManully()
    {
        eActionState state = m_stateMgr.GetCurrActState();
        if (state == eActionState.Behit)
        {
            return true;
        }
        return false;
    }

    //是否可主动行动
    public bool CanActManully()
    {
        eActionState state = m_stateMgr.GetCurrActState();
        if (state == eActionState.Idle ||
            state == eActionState.Walk ||
            state == eActionState.Run ||
            state == eActionState.Scaunter ||
            state == eActionState.Attack
            )
        {
            return true;
        }
        return false;
    }

    //是否可使用普通攻击26
    public bool CanUseNormalAttackManully()
    {
        eActionState state = m_stateMgr.GetCurrActState();
        if (state == eActionState.Idle ||
            state == eActionState.Walk ||
            state == eActionState.Run ||
            state == eActionState.Scaunter ||
            state == eActionState.Attack)
        {
            return true;
        }
        return false;
    }

    /// <summary>
    /// //是否能使用技能
    /// </summary>
    /// <param name="snuglyCheck">搞基检测</param>
    /// <returns></returns>
    public bool CanUseSkillManully(bool snuglyCheck = false)
    {
        if (snuglyCheck)
        {
            CBaseNpc pTarget = IsSnuglyNpc(-20f);
            if (null != pTarget)
            {
                return false;
            }
        }

        eActionState state = m_stateMgr.GetCurrActState();
        if (state == eActionState.Idle ||
            state == eActionState.Walk ||
            state == eActionState.Run ||
            state == eActionState.Attack ||
            state == eActionState.Scaunter ||
            state == eActionState.Behit)
        {
            return true;
        }

        MyLog.LogWarning(" Waring! can not use skill manully, Npc index: " + m_uiIndex + " state : " + state);
        return false;
    }


    public virtual eNpcBehaviour CheckNpcBehaviour()
    {
        //if ((CBaseStory.IsInGameStory || m_bPausedMove) && m_bPausedChick)
        //         if (m_pBattleScene.IsGameOver())
        //         {
        //             return eNpcBehaviour.None;
        //         }

        if (m_bPausedMove || m_bPausedCheck)
        {
            return eNpcBehaviour.GameStory;
        }

        if (IsChest())
        {
            return eNpcBehaviour.None;
        }

        if (m_bInPlatform)
        {
            return eNpcBehaviour.None;
        }

        if (m_pBattleScene.IsGameOver() && NpcSort == eNpcSort.Monster)
        {
            return eNpcBehaviour.None;
        }

        eNpcBehaviour eBehaviour = eNpcBehaviour.None;

        bool avatarincontrol = false;
        if (this is Avatar)
        {
            avatarincontrol = ((Avatar)this).InMouseControl;
        }


        if (Trusteeship && m_pAI != null && !avatarincontrol)
        {
            eBehaviour = m_pAI.CheckNpcBehaviour();
        }
        else
        {
            //不托管至少检查是否有目标可以进行普通攻击
            List<CBaseNpc> targetList = GetTargets(DefaultSkillID, ref eBehaviour, eEffectRangeType.JudgeType);
            if (eBehaviour == eNpcBehaviour.Attack)
            {
                Avatar ap = this as Avatar;
                if (null != ap && ap.AvatarType == eAvatarType.RealAvatar)
                { 
/*                    Debug.Log("  TriggerUseSkillHandler : " + DefaultSkillID + " Time : " + Time.time);*/
                    //ap.TriggerLocationHandler();
                    ap.TriggerUseSkillHandler(DefaultSkillID, Vector3.zero, (int)eSyncAttack.Player);
                    eBehaviour = eNpcBehaviour.WaitAtkMessage;
                }
                else
                {
                    this.Command(eCommandType.UseSkill, new UseSkillCommandArg(DefaultSkillID, targetList));
                }
            }
            else if (eBehaviour == eNpcBehaviour.None && CurrTarget != null && !CurrTarget.IsDead() && CurrTarget.GetCurrActState() != eActionState.Shapeshift)
            {
                //ChaseTarget(CurrTarget);
                Avatar ap = this as Avatar;
                if (null != ap && ap.AvatarType == eAvatarType.RealAvatar)
                {
                    ap.CheckRotateOrRun(CurrTarget.GetPosition(), false, true, true);
                    eBehaviour = eNpcBehaviour.WaitMoveMessage;
                    //ap.TriggerMoveHandler(CurrTarget.GetPosition(), eSyncMove.RunTo);
                }
                else
                {
                    this.Command(eCommandType.RunTo, new RunToCommandArg(CurrTarget.GetPosition(), false, true));
                    eBehaviour = eNpcBehaviour.Chase;
                }
            }
        }

        return eBehaviour;
    }

    //使用技能回调
    protected virtual void UseSkillCompleted(params object[] args)
    {
        SkillContent pSkillLoader = (SkillContent)args[0];

        if (m_pAI != null)
        {
            m_pAI.UpdateCondition(eExtraAICondition.AppointSkillAttack, pSkillLoader.Key.ToString());
        }
    }


    public CBaseState GetState(eActionState state)
    {
        if (null == m_stateMgr) return null;

        return m_stateMgr.GetState(state);
    }

    //技能作用
    public void AttackResult(params object[] args)
    {
        if (IsDead()) return;

        if (args.Length < 5)
        {
            MyLog.LogError(" error ! AttckResult args less than " + args.Length);
            return;
        }

        ePartnerState partnerStateArg = (ePartnerState)args[3];

        ePartnerState partnerState = ePartnerState.None;
        if (this is BaseBattlePlayer)
            partnerState = (this as BaseBattlePlayer).PartnerState;

        if (partnerState != partnerStateArg) //切换小伙伴
        {
            return;
        }

        SkillContent pSkillInfo = (SkillContent)args[0];

        bool bScript = (bool)args[1];
        UseSkillInfo useInfo = (UseSkillInfo)args[2];

        ActionContent pActLoader = HolderManager.m_ActionHolder.GetStaticInfo(pSkillInfo.AttackID);
        if (pSkillInfo.Key == attackID)
        {
            attackDone = true;
        }

        if (this is SkillNpc)
        {
            CBaseNpc parentNpc = ((SkillNpc)this).ParentNpc;
            if (parentNpc.GetCurrActState() == eActionState.Attack)
            {
                parentNpc.attackDone = true;
            }

        }


        // pActLoader = null 没有动作的技能 直接作用
        if (null != pActLoader && !bScript /*&& NpcSort != eNpcSort.SkillNpc*/)
        {
            eActionState attackState = GetCurrActState();
            if (attackState != eActionState.Attack &&
                attackState != eActionState.Skill &&
                attackState != eActionState.Hook &&
                attackState != eActionState.Grab &&
                attackState != eActionState.Resurrect &&
                attackState != eActionState.SwitchPartner &&
                attackState != eActionState.RandomMove &&
                attackState != eActionState.Charge)
            {
                return;
            }

            //判断是否被其他技能打断           
            if (m_uiCurrUseSkillType != pSkillInfo.Key)
            {
                if (pSkillInfo.SkillType == (byte)eSkillType.AttackType)
                {
                    return;
                }
            }
        }

        //飞行技能通过飞行回调处理
        if (pSkillInfo.SkillRange == (byte)eSkillRange.FlyParticleSingle ||
            pSkillInfo.SkillRange == (byte)eSkillRange.FlyParticleAoe ||
            pSkillInfo.SkillRange == (byte)eSkillRange.RandomPoint)
        {
            return;
        }

        HitResultCallback callback = args.Length > 4 ? args[0] as HitResultCallback : null;


        HitResultWithoutTarget(pSkillInfo, useInfo, callback);
    }

    public void HitResultWithoutTarget(SkillContent pSkillInfo, UseSkillInfo useInfo = null, HitResultCallback callback = null)
    {
/*        Debug.LogError(" skillID " + pSkillInfo.Key + " HitResultWithoutTarget time " + Time.time);*/
        if (null != callback)
        {
            callback();
        }

        if (null != m_HitResultCallback)
        {
            m_HitResultCallback();
            m_HitResultCallback = null;
        }

        if (null != m_ScriptSkillHitList)
        {
            for (int i = 0, len = m_ScriptSkillHitList.Count; i < len; i++)
            {
                if (m_ScriptSkillHitList[i].loaderKey == pSkillInfo.Key)
                {
                    Vector3 position = null == useInfo ? Vector3.zero : useInfo.specifiedPoint;
                    SkillHitWithoutTarget skillHit = m_ScriptSkillHitList[i];
                    skillHit.callback(position, skillHit.scriptArgs);
                }
            }

            m_ScriptSkillHitList.Clear();
            m_ScriptSkillHitList = null;
        }


        eNpcBehaviour eBehaviour = eNpcBehaviour.None;
        List<CBaseNpc> targetList = GetTargets((uint)pSkillInfo.Key, ref eBehaviour, eEffectRangeType.HurtType, useInfo);

        bool isDodge = true;

        for (int i = 0, len = targetList.Count; i < len; i++)
        {
            CBaseNpc pTarget = targetList[i];
            if (i > 2) //同时受击大于3个的npc才会延迟
            {
                float delayTime = UnityEngine.Random.Range(0.03f, 0.1f);
                UnityCallBackManager.GetInst().AddCallBack(delayTime, delegate(object[] args)
                {
                    if (HitResult(pSkillInfo, pTarget, i != 0))
                    {
                        isDodge = false;
                    }
                });
            }
            else
            {
                if (HitResult(pSkillInfo, pTarget, i != 0))
                {
                    isDodge = false;
                }
            }
        }

        if (isDodge)
            return;

        bool gameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();

        if (gameOver)
            return;

        int count = 0;
        if (targetList != null)
            count = targetList.Count;
        
        //PVP不用钝刀
        if (CurrBattleScene.BattleType != eBattleType.Pvp && CurrBattleScene.BattleType != eBattleType.MultiPve  && count > 0 || m_npcGroup == eNpcGroup.Justice)// && pSkillInfo.GetSkillType() == eSkillType.AttackType)
        {
            int randomVal = UnityEngine.Random.Range(0, 100) * 100;

            int val = pSkillInfo.DullKnifeProbability;

            if (randomVal - val < 0)
            {
                //CCamera.GetInst().SetCameraEffect(DEFINE.HIT_RESULT_BULLET_TIME, null, null);
                //CCamera.GetInst().SetCameraEffect(DEFINE.HIT_RESULT_SHAKE, null, null);


                CBaseNpc[] npcs = new CBaseNpc[count];
                targetList.CopyTo(npcs);

                float dullTime = 0.12f;

                DullKnife(dullTime, 0.04f, m_npcSort == eNpcSort.Avatar, npcs);
            }
        }

    }

 

    //命中伤害判定
    public virtual bool HitResult(SkillContent pSkillInfo, CBaseNpc pTarget, bool beHitMute = false)
    {
        if (null == pSkillInfo || null == pTarget)
        {
            return false;
        }

        #region 新手引导：闪避
        eGuidTarget target = NewBieGuidManager.GetInst().CheckTargetType();
        if (target == eGuidTarget.Dodge || target == eGuidTarget.DodgeAgain)
        {
            NewBieGuidManager.GetInst().ActivateGuide(target);
        }
        #endregion

        if (SingletonObject<BattleGuide>.GetInst().IsPause)
        {
            return false;
        }

        bool result = false;
        eSkillRange skillRange = (eSkillRange)pSkillInfo.SkillRange;
        eAffectType affectType = (eAffectType)pSkillInfo.AffectType;

        bool isDodge = false;
        bool positiveEffect = (pSkillInfo.AffectEffect == (byte)eAffectEffect.PositiveEffect);

        //解除绑定特殊判断
        if (skillRange == eSkillRange.RemoveBind)
        {
            Transform targetTrans = pTarget.GetTransform();
            if (null != targetTrans.parent)
            {
                //解除父子级关系
                targetTrans.parent = null;
            }
            if (null != GrabNpc)
            {
                GrabNpc = null;
            }
            if (pTarget is Avatar)
            {
                pTarget.IsBeGrab = false;
            }
            //删除无敌buff
            DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
            //pTarget.DelBuff(DEFINE.FOREVER_STUN_BUFF_ID);
            pTarget.LeaveState(eActionState.Stun);
            Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.MONSTER_LAYER, false);

        }
        else if (skillRange != eSkillRange.CurrentTarget)
        {
            if (!CBaseNpc.AffectResult((eAffectType)pSkillInfo.AffectType, (eAffectEffect)pSkillInfo.AffectEffect, this, pTarget, eEffectRangeType.HurtType, (eSkillAtkType)pSkillInfo.SkillAtkType, pSkillInfo.LockList))
                return false;

            if (positiveEffect)
            {
                isDodge = false;
            }
            else
            {
                //普通伤害类型 计算闪避
                isDodge = IsDodge(this, pTarget);
            }
            if (isDodge)
            {
                //非boss怪物走普攻命中流程
                if (this.m_npcSort == eNpcSort.Monster &&
                    NpcSortType != eNpcSortType.ChapterBoss &&
                    NpcSortType != eNpcSortType.WorldBoss &&
                    NpcSortType != eNpcSortType.SociatyBoss)
                {
                    pTarget.Dodge(m_myTrans);
                    result = false;
                }
                else
                {
                    //其他类型npc 普攻走命中流程 
                    if (pSkillInfo.SkillType == (byte)eSkillType.AttackType)
                    {
                        pTarget.Dodge(m_myTrans);
                        result = false;
                    }
                    else
                    {
                        //其他类型命中100%
                        isDodge = false;
                    }
                }
            }
        }

        pTarget.BeHit((uint)pSkillInfo.DefenceID, this, pSkillInfo, beHitMute);

        CSkillupInfo pSkillUpInfo = GetSkillUpLoader(pSkillInfo, false);
        //计算技能等级加成
        if (!isDodge)
        {
            AttrDamage(pTarget, pSkillUpInfo, (uint)pSkillInfo.AttrID);

            if (pTarget.Trusteeship && pTarget.AI != null && !positiveEffect)
            {
                pTarget.AI.Behit(this);
            }

            if (this is Avatar)
            {
                Avatar pPlayer = (Avatar)this;
                pPlayer.AddCombo();
            }

            //目标script        
            List<int> targetScripts = pSkillInfo.TargetScripts;
            foreach (uint uiScriptID in targetScripts)
            {
                ScriptManager.RequestScript(uiScriptID, pTarget, pSkillUpInfo, 0);
            }
        }

        if (null != m_SkillResultList)
        {
            for (int i = 0, len = m_SkillResultList.Count; i < len; i++)
            {
                if (m_SkillResultList[i].loaderKey == pSkillInfo.Key)
                {
                    m_SkillResultList[i].callback(pTarget, isDodge, m_SkillResultList[i].args);
                }
            }

            m_SkillResultList.Clear();
            m_SkillResultList = null;
        }

        result = true;

        return result;
    }

    //伤害计算公式函数
    //initDamage 初始伤害
    public void AttrDamage(CBaseNpc pTarget, CSkillupInfo pSkillupInfo, uint uiAttrID, int initDamage = 0)
    {
        //计算伤害
        bool critical = false;

        int nDamage = 0;//受到技能伤害值

        int allDamage = initDamage;

        nDamage = BeHitDamage(this, pTarget, uiAttrID, ref critical);
        if (nDamage == 0) return;

        //计算技能等级加成       
        if (pSkillupInfo != null)
        {
            float damageUp = pSkillupInfo.GetAttrPromotion();

            nDamage = (int)(nDamage + nDamage * damageUp);
        }
        //伤害
        if (nDamage < 0)
        {
            //受击者[伤害反弹] 根据攻击力来算
            int nDamageReflex = (int)(pTarget.CharacterCard.nAttack * pTarget.CharacterCard.fDamageReflex);
            if (nDamageReflex != 0)
            {
                //伤害反弹, 攻击方和受击方 交换
                if (CBaseNpc.AffectResult(eAffectType.AffectEnemy, eAffectEffect.NegativeEffect, pTarget, this, eEffectRangeType.HurtType, eSkillAtkType.GroundAirAtk, null))
                {
                    AddHp(-nDamageReflex);
                    SingletonObject<FlywordMediator>.GetInst().CreateFlyword(-nDamageReflex, false, this);
                }
            }
            //攻击者 [伤害增加]            
            nDamage = (int)(nDamage * Mathf.Max(1, m_pCard.fDamagePromote));

            //受击者 [伤害减免/伤害加深]
            //nDamage = (int)( nDamage * (1 - Mathf.Clamp(pTarget.CharacterCard.fDamageReduce,0f,0.99f)) );       
            if (pTarget.CharacterCard.fDamageRatio == 0)
            {
                stCharacterCard card = pTarget.CharacterCard;
                card.fDamageRatio = 1f;
                pTarget.CharacterCard = card;
            }
            nDamage = (int)(nDamage * pTarget.CharacterCard.fDamageRatio);
            //受击者[法力护盾]
            CBuffManager pBuffMgr = pTarget.GetBuffManager();
            CBuff shildBuff = pBuffMgr.FindMagicShield();
            if (null != shildBuff)
            {
                if (shildBuff.Amount > 0)
                {
                    shildBuff.Amount--;
                }
                if (shildBuff.Amount == 0)
                {
                    pBuffMgr.AddDestroyBuff(shildBuff.GetBuffType());
                }
            }

            //等级压制 伤害提升
            float addDamagePercent = CBaseNpc.RepressDamage(eRepressType.eBaseBattlePlayer, this, pTarget);
            nDamage *= (int)(1 + addDamagePercent);

            //攻击者[吸血]
            int nLifeSteal = Mathf.Abs((int)(m_pCard.fLifeSteal * nDamage));
            if (nLifeSteal > 0 && !pTarget.IsChest() && !pTarget.IsTurret())
            {
                AddHp(nLifeSteal);
                SingletonObject<FlywordMediator>.GetInst().CreateFlyword(nLifeSteal, false, this);
            }

            //受击者 [伤害转血]
            int damgeAddHp = Mathf.Abs((int)(nDamage * Mathf.Max(pTarget.CharacterCard.fDamageAddHp - 1f, 0f)));
            if (damgeAddHp > 0)
            {
                pTarget.AddHp(damgeAddHp);
                SingletonObject<FlywordMediator>.GetInst().CreateFlyword(damgeAddHp, false, pTarget);
            }
        }

        //公会副本 挑战该章节最后一关 BOSS关时， 计算时伤害X2
        if (m_pBattleScene.BattleType == eBattleType.TeamPve && m_pBattleScene.IsTeamBossStage)
        {
            nDamage *= 2;
        }

        if (ShowAddHpFlyWord(allDamage))
        {
            eNpcGroup targetGroup = pTarget.NpcGroup;
            eNpcGroup avatarGroup = SingletonObject<Avatar>.GetInst().NpcGroup;
            if (critical)
            {
                if (targetGroup == avatarGroup)
                {
                    SingletonObject<FlywordMediator>.GetInst().RoleCirtedTyp();
                }
            }
            SingletonObject<FlywordMediator>.GetInst().CreateFlyword(nDamage, critical, pTarget);
        }

        if (critical)
        {
            if (this is BaseBattlePlayer)
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_CRITICAL_SHAKE, null, null);
            }
            else if (this is Monster)
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BE_CRITICAL_SHAKE, null, null);
            }
        }


        pTarget.AddHp(nDamage, critical, this);

    }

    //当前连招开始计时
    public void CountingNormalSkill()
    {
        m_comboTimer.SetTimer(DEFINE.COMBO_ATTACK_KEEPING_TIME);
        //MyLog.Log("Count!!!");
    }

    //当前连招被打断
    public void BreakNormalSkill(uint uiSkillType)
    {
        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillType);
        if (pSkillLoader == null)
        {
            return;
        }

        if (SkillManager.GetInst().IsFirstSkill(pSkillLoader))
        {
            return;
        }

        eMultiSkillType mutiType = (eMultiSkillType)pSkillLoader.MultiSkillType;
        if (mutiType == eMultiSkillType.NormalAtk)
        {
            this.DefaultSkillID = (uint)pSkillLoader.FirstSkillID;
            this.attackDone = false;
        }

        m_comboTimer.Release();
        //MyLog.Log("Release!!!");
    }

    //受击音效
    public virtual void PlayBehitSound() { }

    //释放技能喊叫
    public virtual void PlaySkillSound() { }

    //播放死亡动作
    public virtual void PlayDeadAction()
    {
        uint soundID = (uint)GetDeadActID();

    }

    public void SoundBreak()
    {
        for (int i = 0, len = Sounds.Count; i < len; i++)
        {
            AudioContent loader = Sounds[i].AudioLoader;
            if (null != loader)
            {
                if (loader.SoundType != (byte)eSoundType.Behit)
                {
                    Sounds[i].Stop(true);
                }
            }
        }
    }

    public virtual void BeHit(uint uiDefenceActionID, CBaseNpc pAttacker, SkillContent pSkillLoader, bool behitMute = false)
    {
        if (this.NpcEnterStateEvent != null)
        {
            this.NpcEnterStateEvent(pAttacker, eActionState.Behit);
        }

        ActionContent pActionInfo = HolderManager.m_ActionHolder.GetStaticInfo(uiDefenceActionID);
        if (null == pActionInfo)
        {
            return;
        }

        //受击喊叫
        PlayBehitSound();

        eDoActionType doAction = behitMute ? eDoActionType.BehitMute : eDoActionType.Behit;

        DoAction(pActionInfo, pAttacker, pSkillLoader, doAction);


        //         if ( NpcSort == eNpcSort.Avatar)
        //         {
        //             //MyLog.LogError(" attack : " + pAttacker.Index + " skill : " + pSkillLoader.GetKey());
        //         }

        //if (pAttacker.NpcSort == eNpcSort.Monster)
        //{
        //    Monster pMonster = (Monster)pAttacker;
        //    NpcAI pAI = pMonster.AI;
        //    pAI.UpdateCondition(eExtraAICondition.AppointSkillAttack, pSkillLoader.GetKey().ToString());
        //}
    }

    public virtual void Dodge(Transform attackTrans)
    {
        eNpcGroup targetGroup = NpcGroup;
        eNpcGroup avatarGroup = SingletonObject<Avatar>.GetInst().NpcGroup;
        //闪避飘字
        if (targetGroup == avatarGroup)
        {
            SingletonObject<FlywordMediator>.GetInst().CreateWordType(GetPosition(), FlyWordType.RoleDodgeWord);
        }
        else
        {
            SingletonObject<FlywordMediator>.GetInst().CreateWordType(GetPosition(), FlyWordType.MonsterDodgeWord);
        }


    }


    //仅仅播放动作,特效,音效等
    public void DoActionOnly(ActionContent pActionInfo, bool bRepeat, PlayOnceFinised playCallBack = null, object[] parms = null)
    {
        string ActionName = pActionInfo.ActionName;
        PlayAction(ActionName, 1.0f, bRepeat, playCallBack, DEFINE.ANIMATOR_FADE_TIME, parms);

        //音效
        List<int> sounds = Common.GetSounds(pActionInfo);
        foreach (var soundID in sounds)
        {
            CreateSound((uint)soundID);
        }

        bool gameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();
        //镜头
        List<int> cameraEffectList = pActionInfo.SelfCameraIDs;
        for (int i = 0, count = cameraEffectList.Count; i < count; ++i)
        {
            if (!gameOver)
                CCamera.GetInst().SetCameraEffect((uint)cameraEffectList[i], null, null);
        }

        List<int> effectList = Common.GetPlayEffects(pActionInfo);
        //特效
        if (effectList.Count > 0)
        {
            for (int i = 0; i < effectList.Count; ++i)
            {
                CreateParticle((uint)effectList[i]);
            }
        }
    }

    //specifiedPoint 释放技能的指定点
    public virtual Vector3 DoAction(ActionContent pActionInfo, CBaseNpc pAttacker, SkillContent pSkillInfo, eDoActionType doActionType = eDoActionType.Normal, UseSkillInfo useInfo = null)
    {
        Vector3 destPosition = Vector3.zero;
        //自杀攻击排除在外
        if (!pAttacker.SelfDestruction && (IsDead() || pAttacker.IsDead()))
        {
            return destPosition;
        }
        string ActionName = "";
        eActionType actionType = (eActionType)pActionInfo.BehitType;
        CBaseState curState = m_stateMgr.GetCurrState();
        if (null == curState)
        {
            return destPosition;
        }
        switch (actionType)
        {
            case eActionType.Behit:
                {
                    if (curState.GetState() == eActionState.Attract) break;

                    //if (IsOverlord() || IsFrost()) break;
                    if (!CanBeHit) break;

                    ActionName = pActionInfo.ActionName;
                    if (!ActionName.Equals("0"))   //不播放受击
                    {
           
                        curState = (CBeHitState)m_stateMgr.GetState(eActionState.Behit);
                        BreakNormalSkill(CurUseSkill);
                        EnterState(eActionState.Behit);
                    }
                }
                break;
            case eActionType.Down:
                {
                    if (curState.GetState() == eActionState.Attract) break;

                    if (!CanBeatDown) break;

                    ActionName = pActionInfo.BeatDownName;
                    if (!ActionName.Equals("0"))    //不播放击倒
                    {
                        curState = (CBeatDownState)m_stateMgr.GetState(eActionState.Down);

                        BreakNormalSkill(CurUseSkill);

                        EnterState(eActionState.Down);
                    }
                }
                break;
            case eActionType.Fly:
                {
                    if (curState.GetState() == eActionState.Attract) break;

                    if (!CanBeatFly) break;

                    ActionName = pActionInfo.BeatFlyName;
                    if (!ActionName.Equals("0"))   //不播放击飞
                    {
                        curState = (CBeatFlyState)m_stateMgr.GetState(eActionState.BeatFly);

                        BreakNormalSkill(CurUseSkill);

                        EnterState(eActionState.BeatFly);
                    }
                }
                break;

            case eActionType.Attract:
                {
                    if (!CanBeAttract) break;
                    ActionName = pActionInfo.ActionName;

                    //if (!ActionName.Equals("0"))
                    {
                        curState = (CAttractState)m_stateMgr.GetState(eActionState.Attract);

                        BreakNormalSkill(CurUseSkill);
                        EnterState(eActionState.Attract);

                        List<string> rangeArgs = pSkillInfo.ExtraArgs;

                        if (rangeArgs.Count > 2)
                        {
                            float time = MyConvert_Convert.ToSingle(rangeArgs[0]);
                            float forward_offset = MyConvert_Convert.ToSingle(rangeArgs[1]);
                            float left_offset = MyConvert_Convert.ToSingle(rangeArgs[2]);

                            Vector3 despostion = pAttacker.GetTransform().position + pAttacker.GetTransform().forward * forward_offset + pAttacker.GetTransform().right * (-left_offset);

                            (curState as CAttractState).SetAttracInfo(despostion, time);
                        }
                        else
                        {
                            MyLog.LogError(" error ! skillid : " + pSkillInfo.Key + " rangArgs error !");
                        }
                    }
                }
                break;
            case eActionType.Shapeshift:
                {
                    Monster monster = this as Monster;
                    if (null != monster && pSkillInfo.ExtraArgs.Count > 2)
                    {
                        float maxHp = MyConvert_Convert.ToSingle(pSkillInfo.ExtraArgs[0]) / 10000f;
                        float atk = MyConvert_Convert.ToSingle(pSkillInfo.ExtraArgs[1]) / 10000f;
                        float def = MyConvert_Convert.ToSingle(pSkillInfo.ExtraArgs[2]) / 10000f;

                        monster.AttrInheritList = new float[] { maxHp, atk, def };
                        monster.SetSummonerNpc(pAttacker, SummonerType.BeActivated);

                        if (monster.ActiveList.Count > 1)
                        {
                            uint actionID = MyConvert_Convert.ToUInt32(monster.ActiveList[0]);
                            uint monsterID = MyConvert_Convert.ToUInt32(monster.ActiveList[1]);

                            CShapeshiftState pShapeshiftState = (CShapeshiftState)m_stateMgr.GetState(eActionState.Shapeshift);
                            if (pShapeshiftState != null)
                            {
                                pShapeshiftState.SetActionID(actionID);
                                pShapeshiftState.SetReplaceNpcID(monsterID);
                            }
                            EnterState(eActionState.Shapeshift);
                        }
                    }
                }
                break;
            case eActionType.GrabHit:
                {
                    curState = (CGrabHitState)m_stateMgr.GetState(eActionState.GrabHit);

                    ActionName = pActionInfo.BeatFlyName;
                    if (!ActionName.Equals("0"))
                    {
                        BreakNormalSkill(CurUseSkill);

                        (curState as CGrabHitState).SetGrabHitInfo(pAttacker);

                        EnterState(eActionState.GrabHit);

                    }
                }
                break;

            case eActionType.Other: //其他读动作表的动作.(如:技能动作
                {
                    //curState = m_stateMgr.GetCurrState();
                    if (null == curState)
                    {
                        //MyLog.LogError(" error !  DoAction curState is null ! : " + this.Index);
                        return destPosition;
                    }
                    ActionName = pActionInfo.ActionName;

                    if (IsBoss())
                    {
                        float fSkillTime = 0;

                        if (pSkillInfo.SkillType == (byte)eSkillType.AttackType)
                        {
                            //CAnimatorStateInfo info = GetPlayAniState();
                            //if (null != info && !info.bStartPlay)
                            //{
                            //    fSkillTime = info.state.length / Mathf.Abs(info.aniSpeed);
                            //}

                            fSkillTime = PlayActionTime;
                        }
                        else if (pSkillInfo.SkillType == (byte)eSkillType.SkillType)
                        {
                            fSkillTime = pSkillInfo.LastTime;
                        }
                        if (fSkillTime > 0)
                        {
                            UnityCallBackManager.GetInst().AddCallBack(fSkillTime, UseSkillCompleted, new object[] { pSkillInfo });
                        }
                    }
                }
                break;
            case eActionType.Ragdoll:
                {
                    if (!CanRagdoll) return destPosition;

                    CRagdollState pState = (CRagdollState)m_stateMgr.GetState(eActionState.Ragdoll);
                    if (null != pState)
                    {
                        curState = pState;

                        List<string> extraArgs = pActionInfo.ExtraArgs;
                        if (extraArgs.Count != 2)
                        {
                            MyLog.LogError(" Error ! ExtraArgs count  no equals to 2 with actionID : " + pActionInfo.Key);
                            return destPosition;
                        }
                        float offset_x = MyConvert_Convert.ToSingle(extraArgs[0]);
                        float forceValue = MyConvert_Convert.ToSingle(extraArgs[1]);
                        pState.SetRagdollInfo(pAttacker, offset_x, forceValue);

                        EnterState(eActionState.Ragdoll);
                    }
                }
                break;
        }


        float changeSpeed = pSkillInfo.SkillType == (byte)eSkillType.AttackType ? m_pCard.fChangeAtkSpeed : 0f;
        float fAniSpeed = pActionInfo.Speed + changeSpeed;

        if (curState != null)
        {
            //计算硬直
            float fAnkylosisTime = pActionInfo.AnkylosisTime;
            fAnkylosisTime = fAnkylosisTime * (Mathf.Pow(1.9f, (1000 - GetRigidity()) / 1000.0f) - 0.9f);
            curState.SetAnkylosisTime(fAnkylosisTime);

            if (ActionName != "" && ActionName != "0")
            {
                float fHorDistance = pActionInfo.Displacement;
                curState.SetActionInfo(ActionName, fAniSpeed);
                if (fHorDistance != 0)
                {  
                    float fHorSpeed = pActionInfo.HorSpeed;
                    float fHorDelayTime = pActionInfo.HorDelayTime;

                    //这里的fHorDistance主要是控制击退方向,因为怪物增加了物理功能,所以为了防止误差,击退距离*10
//                     if (curState is CSkillState || curState is CAttackState)
//                     {
//                         destPosition = Common.GetRayPosition(m_myTrans.position, m_myTrans.position + m_myTrans.forward, fHorDistance /** 10*/);
//                     }
//                     else
                    {
                        destPosition = Common.GetRayPosition(GetPosition(), pAttacker.GetTransform().position, fHorDistance /** 10*/);
                    }
                    Vector3 npcPosition = GetPosition();
                    RaycastHit hitInfo;
                    Vector3 movementThisStep = destPosition - npcPosition;
                    float movementSqrMagnitude = movementThisStep.sqrMagnitude;
                    float movementMagnitude = Mathf.Sqrt(movementSqrMagnitude);

                    if (Physics.Raycast(npcPosition, movementThisStep, out hitInfo, movementMagnitude, 1 << DEFINE.AIR_WALL))
                    {                        
                        destPosition = hitInfo.point - (movementThisStep / movementMagnitude) * GetGoThroughPartialExtent();
                    }

                    SetDestPosition(destPosition, false);

                    //这里的击退距离会将击退时间算出来
                    curState.SetHorizontalInfo(Common.Get2DVecter3Length(m_destPosition, GetPosition()), fHorSpeed, fHorDelayTime);

                }
            }
        }

        CBaseState baseState = GetCurrState();
        //音效
        if (doActionType != eDoActionType.BehitMute)
        {
            List<int> sounds = Common.GetSounds(pActionInfo);
            for (int i = 0, len = sounds.Count; i < len; i++)
            {
                CSound sound = CreateSound((uint)sounds[i]);
            }
        }

        bool gameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();
        //镜头
        if (CurrBattleScene.BattleType != eBattleType.Arena && CurrBattleScene.BattleType != eBattleType.Pvp && CurrBattleScene.BattleType != eBattleType.MultiPve)
        {
            List<int> cameraEffectList = pActionInfo.SelfCameraIDs;
            for (int i = 0, count = cameraEffectList.Count; i < count; ++i)
            {
                CameraContent cameraInfo = HolderManager.m_CameraHolder.GetStaticInfo(cameraEffectList[i]);
                if (cameraInfo == null)
                    continue;

                eCAMERATYPE cameraType = (eCAMERATYPE)cameraInfo.CameraType;
                bool openType = true;
                if (m_npcSort != eNpcSort.Avatar)
                    openType = cameraType == eCAMERATYPE.CAMERA_TYPE_SHELTER || cameraType == eCAMERATYPE.CAMERA_TYPR_SHAKE;
                if (!gameOver && openType)
                    CCamera.GetInst().SetCameraEffect((uint)cameraEffectList[i], null, null);
            }
        }

        List<int> effectList = Common.GetPlayEffects(pActionInfo);
        //特效
        if (effectList.Count > 0)
        {
            for (int i = 0; i < effectList.Count; ++i)
            {
                CParticleHitInfo hitInfo = null;
                ParticleContent pParticleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(effectList[i]);
                if (null != pParticleInfo)
                {
                    eParticleType type = (eParticleType)pParticleInfo.Sort;

                    //设置飞行特效回调
                    if ((int)type >= (int)eParticleType.Chase_Normal && (int)type <= (int)eParticleType.NonChase_Archery || type == eParticleType.LineParticle)
                    {
                        CParticleCallback callback = new CParticleCallback();
                        callback.BaseNpc = this;

                        hitInfo = new CParticleHitInfo((uint)pSkillInfo.Key, callback.ParticleCallbak);
                    }

                    uint particeIndex = CreateParticle((uint)effectList[i], useInfo, hitInfo, pSkillInfo.SkillType == (byte)eSkillType.AttackType);

                    if (doActionType == eDoActionType.Normal && null == hitInfo) //非受击、非飞行特效 传入特效index
                    {
                        if (baseState is CAttackState || baseState is CSkillState || baseState is CGrabState || baseState is CHookState)
                        {
                            baseState.AddParticle(particeIndex);
                        }
                    }
                }

            }
        }


        //武器动画
        List<string> WeaponAction = pActionInfo.WeaponAction;
        if (WeaponAction.Count >= 2)
        {
            string leftAction = WeaponAction[0];
            string rightAction = WeaponAction[1];

            if (m_leftWeaponAnimator != null && !leftAction.Equals("0"))
            {
                bool loop = false;
                float speed = fAniSpeed;
                if (leftAction.Equals("idle"))
                {
                    loop = true;
                    speed = 1.0f;
                }
                m_leftWeaponAnimator.PlayAction(leftAction, speed, !loop);
            }

            if (m_rightWeaponAnimaror != null && !rightAction.Equals("0"))
            {
                bool loop = false;
                float speed = fAniSpeed;
                if (rightAction.Equals("idle"))
                {
                    loop = true;
                    speed = 1.0f;
                }
                m_rightWeaponAnimaror.PlayAction(rightAction, fAniSpeed, !loop);
            }
        }

        return destPosition;
    }


    //     public virtual CAnimatorStateInfo GetPlayAniState()
    //     {
    //         if (null == m_pAnimator) return null;
    // 
    //         return m_pAnimator.GetAnimatorInfo();
    //     }

    public virtual float PlayActionTime
    {
        get
        {
            if (null == m_pAnimator) return -1f;

            return m_pAnimator.ActionTime;
        }
    }


    public CAnimator GetCAnimator()
    {
        return m_pAnimator;
    }

    public void SetActionTimer(float fTotalTime)
    {
        if (null == m_ActionTimer) return;

        m_ActionTimer.SetTimer(fTotalTime);
    }

    public void AddActionTime(float fTotalTime)
    {
        if (null == m_ActionTimer) return;

        m_ActionTimer.AddExpireTime(fTotalTime);
    }

    public bool NotInAction()
    {
        CBaseState baseState = m_stateMgr.GetCurrState();
        if (null != baseState)
        {
            return m_ActionTimer.IsExpired(false) || !m_ActionTimer.IsStart() && baseState.CheckActState != eCheckActState.StartCheck;
        }

        return false;
    }

    public void ReleaseActionTimer()
    {
        m_ActionTimer.Release();
    }


    public CSound CreateSound(uint uiSoundID)
    {
        CSound pSound = null;
        AudioContent pinfo = HolderManager.m_AudioHolder.GetStaticInfo(uiSoundID);
        if (pinfo == null)
            return pSound;

        pSound = CMusicManager.GetInst().CreateSound(m_audioSourceObject, uiSoundID, this);
        if (null != pSound)
        {
            m_soundList.Add(pSound);
        }
        return pSound;
    }

    public void RemoveSound(CSound sound)
    {
        if (m_soundList.Contains(sound))
        {
            m_soundList.Remove(sound);
        }
    }

    protected virtual GameObject GetEffectBindObject()
    {
        if (m_pNpcObj != null)
        {
            return m_pNpcObj.GetObj();
        }
        return null;

    }

    //hitInfo (飞行特效碰撞回调,默认null)
    public uint CreateParticle(uint dwParticleID, UseSkillInfo useInfo = null, CParticleHitInfo hitInfo = null, bool changeSpeed = false)
    {
        if (null == m_myTrans) return 0;
        ParticleContent pParticleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(dwParticleID);
        uint uiParticleIndex = 0;

        if (pParticleInfo != null)
        {
            switch ((eParticleType)pParticleInfo.Sort)
            {
                case eParticleType.BodyBind:
                    {
                        GameObject bindObj = GetEffectBindObject();
                        if (null != bindObj)
                        {
                            bool bPushCongener = false;//排挤同类特效
                            if (dwParticleID % 10000000 / 1000000 == 9)//受击特效一个NPC身上最多只有一个
                            {
                                bPushCongener = true;
                            }
                            uiParticleIndex = CParticleManager.GetInst().CreateBindEffect(dwParticleID, bindObj, bPushCongener);
                        }
                    }
                    break;
                case eParticleType.GroundSpecified:
                    {
                        Vector3 position = Vector3.zero;
                        Vector3 toward = Vector3.zero;

                        if (null == useInfo)
                        {
                            position = Common.GroundPosition(m_myTrans.position, DEFINE.TERRAINLAYER);
                            toward = m_myTrans.forward;
                        }
                        else
                        {
                            position = useInfo.specifiedPoint;
                            toward = useInfo.toward == Vector3.zero ? m_myTrans.forward : useInfo.toward;
                        }
                        uiParticleIndex = CParticleManager.GetInst().CreateGroundEffect(dwParticleID, position, toward);
                    }
                    break;
                case eParticleType.Chase_Normal:
                case eParticleType.Chase_PopUp:
                case eParticleType.Chase_PopUp_NoRepeat:
                    {
                        uiParticleIndex = CParticleManager.GetInst().CreateChaseParticle(dwParticleID, m_playerTrans, hitInfo);
                    }
                    break;
                case eParticleType.NonChase_Penetration:
                case eParticleType.NonChase_Explosion:
                case eParticleType.NonChase_Archery:
                    {
                        Vector3 destposition = Vector3.zero;
                        //
                        ParticleContent particleLoader = HolderManager.m_ParticleHolder.GetStaticInfo(dwParticleID);
                        if (null != particleLoader)
                        {
                            eNonChaseToward towardType = (eNonChaseToward)particleLoader.TowardType;
                            if (towardType == eNonChaseToward.TowardTarget)
                            {
                                if (CurrTarget != null)
                                {
                                    Transform playerTrans = CurrTarget.GetPlayerTransform();
                                    if (null != playerTrans)
                                    {
                                        Transform hitPoint = Common.GetBone(playerTrans, "BP_Spine");
                                        if (hitPoint != null)
                                        {
                                            destposition = hitPoint.position;
                                        }
                                        else
                                        {
                                            destposition = CurrTarget.GetPosition() + Vector3.up * 0.5f;
                                        }
                                    }
                                }
                            }
                            else if (towardType == eNonChaseToward.TowardAppoint)
                            {
                                float maxDistance = particleLoader.FlyArgs[0];
                                if (null != useInfo)
                                {
                                    destposition = useInfo.specifiedPoint;
                                }
                                else
                                {
                                    destposition = m_myTrans.position + m_myTrans.forward * maxDistance;
                                }
                            }

                            uiParticleIndex = CParticleManager.GetInst().CreateNonChaselParticle(dwParticleID, m_playerTrans, destposition, hitInfo);
                        }

                    }
                    break;
                case eParticleType.Hook:
                    {
                        uiParticleIndex = CParticleManager.GetInst().CreateHookEffect(dwParticleID, m_pNpcObj.GetObj(), delegate()
                        {
                            CHookState pHook = (CHookState)m_stateMgr.GetState(eActionState.Hook);
                            pHook.SetParticleIndex(uiParticleIndex);
                        });

                    }
                    break;
                case eParticleType.Camera:
                    {

                    }
                    break;
                case eParticleType.GroundChase:
                case eParticleType.GroundTerrainLayer:
                    {
                        uiParticleIndex = CParticleManager.GetInst().CreateGroundEffect(dwParticleID, m_myTrans);
                    }
                    break;
                case eParticleType.Trail:
                    {
                        string bindPoint = pParticleInfo.BindPoint;

                        switch (bindPoint)
                        {
                            case DEFINE.BIND_BP_L_Weapon: PlayTrailParticle(m_leftTrail, pParticleInfo); break;
                            case DEFINE.BIND_BP_R_Weapon: PlayTrailParticle(m_rightTrail, pParticleInfo); break;
                            case DEFINE.BIND_BP_L_Hand:
                                {
                                    if (m_leftTrail == null)
                                    {
                                        Transform tran = Common.GetBone(m_playerTrans, DEFINE.BIND_BP_L_Hand);
                                        if (tran != null)
                                        {
                                            TrailManange[] tempTrails = tran.GetComponentsInChildren<TrailManange>();
                                            if (tempTrails != null && tempTrails.Length > 0)
                                            {
                                                m_leftTrail = tempTrails[0];
                                                if (m_leftTrail.EndToDisable)
                                                    m_leftTrail.enabled = false;
                                            }
                                        }
                                    }

                                    if (m_leftTrail != null)
                                        PlayTrailParticle(m_leftTrail, pParticleInfo);
                                }
                                break;
                            case DEFINE.BIND_BP_R_Hand:
                                {
                                    if (m_rightTrail == null)
                                    {
                                        Transform tran = Common.GetBone(m_playerTrans, DEFINE.BIND_BP_R_Hand);
                                        if (tran != null)
                                        {
                                            TrailManange[] tempTrails = tran.GetComponentsInChildren<TrailManange>();
                                            if (tempTrails != null && tempTrails.Length > 0)
                                            {
                                                m_rightTrail = tempTrails[0];
                                                if (m_rightTrail.EndToDisable)
                                                    m_rightTrail.enabled = false;
                                            }
                                        }
                                    }

                                    if (m_rightTrail != null)
                                        PlayTrailParticle(m_rightTrail, pParticleInfo);
                                }
                                break;
                        }
                    }
                    break;
                case eParticleType.ChangeMaterial:
                    {
                        uiParticleIndex = CParticleManager.GetInst().CreateChangeMaterial(dwParticleID, this);
                        m_changeMaterialParticleIndex = uiParticleIndex;
                    }
                    break;
                case eParticleType.LineParticle:
                    {
                        stLineInfo info;
                        info.count = 1;
                        info.targetlist = new List<Transform>();

                        Transform targetTrans = CurrTarget == null ? null : CurrTarget.GetTransform();

                        uiParticleIndex = CParticleManager.GetInst().CreateLineParticle(dwParticleID, m_playerTrans, targetTrans, info, hitInfo);

                    }
                    break;
            }
        }

        if (changeSpeed)
        {
            CParticle particle = CParticleManager.GetInst().GetParticle(uiParticleIndex);
            if (null != particle)
            {
                particle.Speed += m_pCard.fChangeAtkSpeed;
            }
        }

        if (!m_createParticleList.Contains(uiParticleIndex))
        {
            CParticle particle = CParticleManager.GetInst().GetParticle(uiParticleIndex);
            if (null != particle)
            {
                particle.DestoryHandle = ParticleDesotryHandle;
            }
            m_createParticleList.Add(uiParticleIndex);
        }

        return uiParticleIndex;
    }

    private void ParticleDesotryHandle(uint index)
    {
        if (m_createParticleList.Contains(index))
        {
            m_createParticleList.Remove(index);
        }
    }

    //目标是否为盟军
    public bool TargetIsAlly
    {
        get
        {
            if (null == m_currTarget)
            {
                return false;
            }

            return (m_currTarget.NpcGroup == NpcGroup);

        }
    }

    public CBaseNpc CurrTarget
    {
        get
        {
            return m_currTarget;
        }
        set
        {
            //             if (this is Avatar)
            //             {
            //                 int index = null != value ? (int)value.Index : -1;
            //                 Debug.LogError(this.Index + " set curretarget :  " + index);
            //             }

            if (null == value || null == value.GetTransform())
            {
                m_currTarget = null;
            }
            else
            {

                m_currTarget = value;
            }


        }
    }


    public float MinAttackRange
    {
        get { return m_minAttackRange; }
    }

    public float MinNormalAtkRange
    {
        get { return m_minNormalAtkRange; }
    }


    //private uint m_minAttackRangeSkillID;

    public float MaxAttackRange
    {
        get
        {
            return m_maxAttackRange;
        }
    }

    public bool IsInSkillRange(uint uiSkillType, CBaseNpc pTarget, eEffectRangeType rangeType)
    {
        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillType);
        if (pSkillInfo == null)
        {
            return false;
        }
        return IsInSkillRange(pSkillInfo, pTarget, rangeType);
    }

    public float GetSnuglyDistance(CBaseNpc target, float deviationPercent = 0f)
    {
        float radius1 = CharacterRadius;
        float radius2 = target.CharacterRadius;

        float deviationValue = (radius1 + radius2) * deviationPercent * 0.01f;

        return radius1 + radius2 + deviationValue;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="deviationValue">误差值百分比</param>
    /// <returns></returns>
    public CBaseNpc IsSnuglyNpc(float deviationPercent = 0f)
    {
        for (int i = 0, len = m_rangeNpcList.Count; i < len; i++)
        {
            CBaseNpc npc = m_rangeNpcList[i];

            if (npc == this || npc is SkillNpc || npc.NpcSort == eNpcSort.Pet || npc.NpcSort == eNpcSort.Ally || npc.NpcSort == eNpcSort.Mechanism)
                continue;

            if (!npc.NpcCollider.enabled || npc.IsDead())
                continue;

            if (IsSnugly(npc, deviationPercent))
            {
                return npc;
            }
        }
        return null;
    }

    /// <summary>
    ///  判断两个npc是否身贴身,搞基?
    /// </summary>
    /// <param name="target"></param>
    /// <param name="deviationPercent">误差值百分比</param>
    /// <returns></returns>
    public bool IsSnugly(CBaseNpc target, float deviationPercent = 0f)
    {
        float distance = Common.Get2DVecter3Length(GetPosition(), target.GetPosition());

        if (distance > GetSnuglyDistance(target, deviationPercent))
        {
            return false;
        }
        return true;
    }

    //根据ModelSize后碰撞盒大小
    public float CharacterRadius
    {
        get
        {
            float scale = 1;
            if (m_myTrans != null)
            {
                scale = m_myTrans.localScale.x;
            }

            float radius = m_ColliderRadius * scale;

            return radius;
        }
    }

    //specifiedPoint 释放技能的指定点
    public bool IsInSkillRange(SkillContent pSkillInfo, CBaseNpc pTarget, eEffectRangeType rangeType, UseSkillInfo useInfo = null)
    {
        //技能判定范围
        if (rangeType == eEffectRangeType.JudgeType)
        {
            List<float> judgeArgs = pSkillInfo.JudgeArgs;

            float fArg1 = judgeArgs[0];
            float fArg2 = judgeArgs[1];

            if (CBaseNpc.IsInArc(fArg1, fArg2, pTarget, this, m_myTrans.forward))
            {
                return true;
            }
        }
        else
        {
            List<float> rangeArgs = pSkillInfo.RangeArgs;

            switch ((eSkillRange)pSkillInfo.SkillRange)
            {
                case eSkillRange.Arc:
                    {
                        float fArg1 = rangeArgs[0];
                        float fArg2 = rangeArgs[1];

                        if (CBaseNpc.IsInArc(fArg1, fArg2, pTarget, this, m_myTrans.forward))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.FlyParticleAoe:
                case eSkillRange.RandomPoint:
                    {
                        if (null == useInfo)
                            return false;

                        float radius = rangeArgs[0]; //半径                        
                        if (IsInMagicCircle(useInfo.specifiedPoint, pTarget, radius))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.MagicCircle:
                case eSkillRange.SingleTaget:
                    {
                        float forward_offset = rangeArgs[0];
                        float left_offset = rangeArgs[1];
                        float radius = rangeArgs[2];

                        Vector3 appointPos = m_myTrans.position + m_myTrans.forward * forward_offset + m_myTrans.right * (-left_offset);

                        if (IsInMagicCircle(appointPos, pTarget, radius))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.Rect:
                    {
                        Vector3 bottomMidPos = m_myTrans.position;

                        float height = Math.Abs(rangeArgs[0]); //长
                        float width = Math.Abs(rangeArgs[1]); //宽
                        float offset_left = 0f;
                        float offset_front = 0f;
                        if (rangeArgs.Count > 2)
                        {
                            offset_left = rangeArgs[2]; //左偏移     
                            bottomMidPos += m_myTrans.right * (-offset_left);
                        }
                        if (rangeArgs.Count > 3)
                        {
                            offset_front = rangeArgs[3]; //前偏移
                            bottomMidPos += m_myTrans.forward * offset_front;
                        }

                        Vector3 toward = rangeArgs[0] > 0 ? m_myTrans.forward : -m_myTrans.forward;

                        return IsInRect(height, width, toward, bottomMidPos, pTarget);
                    }
                //break;
                case eSkillRange.RandomCircle:
                    {
                        if (null == useInfo)
                            return false;

                        float radius = rangeArgs[3]; //半径
                        if (IsInMagicCircle(useInfo.specifiedPoint, pTarget, radius))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.ComplexArc:
                    {
                        eGrabDirection dir = (eGrabDirection)rangeArgs[0];
                        float maxAngel = rangeArgs[1];
                        float minAngel = rangeArgs[2];
                        float maxDis = rangeArgs[3];
                        float minDis = rangeArgs[4];

                        if (IsInComplexArc(dir, minAngel, maxAngel, minDis, maxDis, pTarget))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.RemoveBind:
                    {
                        if (null != m_pGrabNpc)
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.TargetCircle:
                    {
                        if (null == useInfo)
                            return false;

                        float radius = rangeArgs[0];
                        if (IsInMagicCircle(useInfo.specifiedPoint, pTarget, radius))
                        {
                            return true;
                        }
                    }
                    break;
                case eSkillRange.RandomRect:
                    {
                        if (rangeArgs.Count < 5)
                        {
                            return false;
                        }
                        //半径~角度1~角度2~长度~宽度
                        //float radius = rangeArgs[0];
                        //float minAngel = rangeArgs[1];
                        //float maxAngel   = rangeArgs[2];
                        float height = Math.Abs(rangeArgs[3]);
                        float width = Math.Abs(rangeArgs[4]);

                        //Vector2 ranCircle = UnityEngine.Random.insideUnitCircle* radius;
                        //Vector3 midPos = m_myTrans.position + new Vector3(ranCircle.x, 0f, ranCircle.y); //随机取一个中心点
                        //Vector3 forward = (Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(minAngel, maxAngel)) * m_myTrans.forward).normalized ; //随机取一个朝向

                        Vector3 bottomMidPos = useInfo.specifiedPoint - useInfo.toward * height / 2f;//底边的中心点

                        //                         GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        //                         cube.GetComponent<BoxCollider>().enabled = false;
                        //                         cube.transform.forward = forward;
                        //                         cube.transform.position = midPos;
                        //                         cube.transform.localScale = new Vector3(width, 1f, height                        
                        return IsInRect(height, width, useInfo.toward, bottomMidPos, pTarget);

                    }
                //break;
            }
        }

        return false;
    }

    //技能作用结果
    public static bool AffectResult(eAffectType affectType, eAffectEffect affectEffect, CBaseNpc pAttker, CBaseNpc pTarget, eEffectRangeType rangeType, eSkillAtkType atkType, List<int> locklist = null)
    {
        if (null == pAttker || null == pTarget)
        {
            //MyLog.LogWarning(" AffectResult attacker or target s null !");
            return false;
        }

        if (pTarget.GetCurrActState() == eActionState.Shapeshift)
        {
            return false;
        }

        if (Monster.AppearBoss)
        {
            return false;
        }


        eNpcSort targetSort = pTarget.NpcSort;
        if (!pTarget.LoadComplete)
        {
            return false;
        }

        //友军、宠物、技能npc实体 不受作用
        if (targetSort == eNpcSort.Ally || targetSort == eNpcSort.Pet || targetSort == eNpcSort.SkillNpc || targetSort == eNpcSort.Mechanism || pTarget.NpcGroup == eNpcGroup.GameStory)
        {
            return false;
        }

        if (affectEffect == eAffectEffect.NegativeEffect)
        {
            if (pTarget.IsDead())
                return false;

            if (rangeType == eEffectRangeType.HurtType)
            {
                if (pTarget.IsInvincibility() || pTarget.IsBeGrab)
                    return false;
            }
            if (pTarget.IsHide()) return false;
        }

        switch (affectType)
        {
            case eAffectType.AffectAll:
                break;
            case eAffectType.AffectEnemy://敌方
                {
                    if (pAttker.NpcGroup == pTarget.NpcGroup) return false;

                    if (rangeType == eEffectRangeType.JudgeType &&
                        pTarget.NpcGroup == eNpcGroup.Neutral &&
                        pAttker is Monster) return false;

                    if (atkType == eSkillAtkType.AirAtk && pTarget.UnitsType == eNpcUnitsType.Ground)
                    {
                        return false;
                    }
                    else if (atkType == eSkillAtkType.GroundAtk && pTarget.UnitsType == eNpcUnitsType.Air)
                    {
                        return false;
                    }
                }
                break;
            case eAffectType.AffectFriends://友方
                {
                    if (pAttker.NpcGroup != pTarget.NpcGroup) return false;
                }
                break;
            case eAffectType.AffectSelf:
                {
                    if (pAttker.Index != pTarget.Index) return false;
                }
                break;
            case eAffectType.Boss:
                {
                    if (!pTarget.IsBoss() || pTarget.IsDead()) return false;
                }
                break;
            case eAffectType.AffectFriendExceptSelf:
                {
                    if (pAttker.NpcGroup != pTarget.NpcGroup || pAttker == pTarget) return false;
                }
                break;
            default:
                break;
        }

        //目标限定        
        if (rangeType == eEffectRangeType.JudgeType && null != locklist)
        {
            for (int i = 0, len = locklist.Count; i < len; i++)
            {
                if ((eLockType)locklist[i] == eLockType.Inactive)
                {
                    Monster mt = pTarget as Monster;
                    if (null == mt) return false;

                    return mt.CanBeActive;

                }
            }
        }
        if (rangeType == eEffectRangeType.HurtType && null != locklist)
        {
            for (int i = 0, len = locklist.Count; i < len; i++)
            {
                eLockType locktype = (eLockType)locklist[i];
                switch (locktype)
                {
                    case eLockType.None:
                        {
                            return true;
                        }
                    //break;
                    case eLockType.Assassin:
                    case eLockType.Warrior:
                    case eLockType.Wizard:
                    case eLockType.HolyKnight:
                    case eLockType.Hunter:
                        {
                            BaseBattlePlayer bbp = pTarget as BaseBattlePlayer;
                            if (null == bbp) return false;

                            if (bbp.JobType == (eJobType)locktype) return true;
                        }
                        break;
                    case eLockType.Man:
                        {
                            BaseBattlePlayer bbp = pTarget as BaseBattlePlayer;
                            if (null == bbp) return false;

                            if (bbp.Sex == ePlayerSex.Man) return true;
                        }
                        break;
                    case eLockType.Female:
                        {
                            BaseBattlePlayer bbp = pTarget as BaseBattlePlayer;
                            if (null == bbp) return false;

                            if (bbp.Sex == ePlayerSex.Female) return true;
                        }
                        break;
                    case eLockType.Inactive:
                        {
                            Monster mt = pTarget as Monster;
                            if (null == mt) return false;

                            if (mt.CanBeActive) return true;
                        }
                        break;
                    default:
                        break;
                }
            }

            return false;
        }

        return true;
    }

    //指定的方向是否有敌人在默认技能的攻击范围内
    public bool IsDirectionHasEnemyInRange(Vector3 destPosition)
    {
        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(DefaultSkillID);
        Vector3 dir = (destPosition - m_myTrans.position).normalized;
        if (pSkillLoader != null)
        {
            List<float> judgeArgs = pSkillLoader.JudgeArgs;

            float fArg1 = judgeArgs[0] - 10f; //angel - 10
            float fArg2 = judgeArgs[1];

            foreach (CBaseNpc pNpc in m_rangeNpcList)
            {
                if (pNpc.NpcGroup == NpcGroup)
                {
                    continue;
                }

                if (pNpc.NpcSort == eNpcSort.Mechanism)
                {
                    continue;
                }


                if (pNpc.IsDead() || pNpc.IsHide() || pNpc is Pet)
                {
                    continue;
                }

                if (CBaseNpc.IsInArc(fArg1, fArg2, pNpc, this, dir))
                {
                    return true;
                }
            }

        }
        return false;
    }


    public List<CBaseNpc> GetTargets(uint uiSkillType, ref eNpcBehaviour eBehaviour, eEffectRangeType rangeType, UseSkillInfo specifiedPoint = null)
    {
        m_targetList.Clear();

        BattleScene pScene = m_pBattleScene;

        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillType);
        if (pSkillInfo == null)
        {
            return m_targetList;
        }
        Type ty = this.GetType();
        //抓取技能不受暂停影响
        if (null == GrabNpc && (m_bPausedCheck))
        {
            return m_targetList;
        }

        eSkillRange skillRange = (eSkillRange)pSkillInfo.SkillRange;
        switch (skillRange)
        {
            case eSkillRange.Arc:
            case eSkillRange.FlyParticleSingle:
            case eSkillRange.FlyParticleAoe:
            case eSkillRange.MagicCircle:
            case eSkillRange.Rect:
            case eSkillRange.RandomCircle:
            case eSkillRange.ComplexArc:
            case eSkillRange.TargetCircle:
            case eSkillRange.SingleTaget:
            case eSkillRange.RandomRect:
            case eSkillRange.RandomPoint:
            case eSkillRange.None://填0的技能也作为弧形范围来检测
                {
                    eAffectType affectType = (eAffectType)pSkillInfo.AffectType;
                    eAffectEffect affectEffect = (eAffectEffect)pSkillInfo.AffectEffect;
                    eSkillAtkType atkType = (eSkillAtkType)pSkillInfo.SkillAtkType;
                    List<int> lockList = pSkillInfo.LockList;

                    ICollection<CBaseNpc> npcList;
                    if (rangeType == eEffectRangeType.HurtType && (skillRange == eSkillRange.FlyParticleAoe || skillRange == eSkillRange.RandomPoint))
                    {
                        //此类型可能在triggerRadius 之外
                        npcList = m_pBattleScene.GetNpcDict().Values;
                    }
                    else
                    {
                        npcList = m_rangeNpcList;
                    }

                    foreach (CBaseNpc pNpc in npcList)
                    {
                        if (AffectResult(affectType, affectEffect, this, pNpc, rangeType, atkType, lockList))
                        {
                            if (IsInSkillRange(pSkillInfo, pNpc, rangeType, specifiedPoint))
                            {
                                m_targetList.Add(pNpc);
                            }
                        }
                    }

                    if (skillRange == eSkillRange.SingleTaget && m_targetList.Count > 0)
                    {
                        int nNum = UnityEngine.Random.Range(0, m_targetList.Count);
                        CBaseNpc pTarget = m_targetList[nNum];
                        m_targetList.Clear();
                        m_targetList.Add(pTarget);
                    }
                }
                break;
            case eSkillRange.RemoveBind:
                {
                    if (null != m_pGrabNpc)
                    {
                        m_targetList.Add(m_pGrabNpc);
                    }
                }
                break;
            case eSkillRange.CurrentTarget:
                {
                    if (null != CurrTarget)
                    {
                        m_targetList.Add(CurrTarget);
                    }
                }
                break;
            default:
                {
                    //m_targetList.Add(this);
                }
                break;
        }


        if (m_targetList.Count == 0)
        {
            eBehaviour = eNpcBehaviour.None;

        }
        else
        {
            eBehaviour = eNpcBehaviour.Attack;
        }

        return m_targetList;

    }

    //用AffectReuslt代替
    //     public bool CanBeAttack()
    //     {
    //         if (IsDead())
    //         {
    //             return false;
    //         }
    //         if (IsInvincibility())
    //         {
    //             return false;
    //         }
    //         return true;
    //     }

    public List<CBaseNpc> TargetList
    {
        get { return m_targetList; }
    }

    //判断目标是否在自身左右偏转fAngle,半径为fDistance的弧形内
    public static bool IsInArc(float fAngle, float radius, CBaseNpc target, CBaseNpc src, Vector3 direction)
    {
        //Transform srctrans = src.GetTransform();
        //Transform targetTrans = target.GetTransform();

        //if (null == targetTrans)
        //{
        //    //MyLog.LogWarning(" Npc transfrom is null ! index : " + target.Index);
        //    return false;
        //}

        ////己方单位大小
        //float srcScale = srctrans.localScale.x > srctrans.localScale.z ? srctrans.localScale.x : srctrans.localScale.z;
        ////目标单位包围盒
        //float targetRadius = target.CharacterRadius;
        ////加上施法者包围盒增量                
        //radius = radius + targetRadius;
        ////打到目标包围盒就算打到
        //if (Common.Get2DVecter3Length(srctrans.position, targetTrans.position) > radius)
        //    return false;

        //Vector3 copyTargetPos = targetTrans.position;
        //copyTargetPos.y = 0;

        //Vector3 copySrcPos = srctrans.position;
        //copySrcPos.y = 0;

        //Vector3 dirPos = direction * 1 + srctrans.position;
        //dirPos.y = 0;

        //if (Vector3.Angle(copyTargetPos - copySrcPos, dirPos - copySrcPos) > fAngle / 2)
        //{
        //    return false;
        //}

        if (!CBaseNpc.InRange(radius, src, target))
        {
            return false;
        }

        if (!CBaseNpc.InAngle(fAngle, src, target, direction))
        {
            return false;
        }

        return true;
    }

    public static bool InAngle(float fAngle, CBaseNpc src, CBaseNpc target, Vector3 direction)
    {
        Vector3 copyTargetPos = target.GetPosition();
        copyTargetPos.y = 0;

        Vector3 copySrcPos = src.GetPosition();
        copySrcPos.y = 0;

        Vector3 dirPos = direction * 1 + src.GetPosition();
        dirPos.y = 0;

        if (Vector3.Angle(copyTargetPos - copySrcPos, dirPos - copySrcPos) > fAngle / 2)
        {
            return false;
        }

        return true;
    }


    public static bool InRange(float JudgeDistance, CBaseNpc src, CBaseNpc target)
    {
        if (null == src || null == target)
        {
            return false;
        }
        Transform srctrans = src.GetTransform();
        Transform targetTrans = target.GetTransform();

        if (null == targetTrans)
        {
            return false;
        }

        //己方单位大小
        float srcScale = srctrans.localScale.x > srctrans.localScale.z ? srctrans.localScale.x : srctrans.localScale.z;
        //目标单位包围盒
        float targetRadius = target.CharacterRadius;
        //加上施法者包围盒增量                
        JudgeDistance = JudgeDistance + targetRadius;
        //打到目标包围盒就算打到
        float distance = Common.Get2DVecter3Length(srctrans.position, targetTrans.position);

        return distance <= JudgeDistance;
    }

    public bool IsInMagicCircle(Vector3 appointPos, CBaseNpc tagetNpc, float radius)
    {
        Transform targetTrans = tagetNpc.GetTransform();
        if (null == targetTrans)
        {
            MyLog.LogWarning(" npc transform is null ! ,index : " + m_uiIndex);
            return false;
        }

        //目标单位包围盒
        float targetRadius = tagetNpc.CharacterRadius;
        //实际半径大小
        radius = radius + targetRadius;
        //打到目标包围盒就算打到
        if (Common.Get2DVecter3Length(appointPos, targetTrans.position) <= radius)
        {
            return true;
        }

        return false;
    }

    //复杂扇形区域判定
    public bool IsInComplexArc(eGrabDirection dir, float minAngel, float maxAngel, float minDis, float maxDis, CBaseNpc pTarget)
    {
        Vector3 relative = m_myTrans.InverseTransformPoint(pTarget.GetPosition());
        switch (dir)
        {
            case eGrabDirection.UpRightDir:
                {
                    if (relative.x < 0 || relative.z < 0) return false;
                }
                break;
            case eGrabDirection.UpLeftDir:
                {
                    if (relative.x > 0 || relative.z < 0) return false;
                }
                break;
            case eGrabDirection.BottomLeftDir:
                {
                    if (relative.x < 0 || relative.z > 0) return false;
                }
                break;
            case eGrabDirection.BottomRightDir:
                {
                    if (relative.x > 0 || relative.z > 0) return false;
                }
                break;
            case eGrabDirection.UpDir:
                {
                    if (relative.z < 0) return false;
                }
                break;
            case eGrabDirection.DownDir:
                {
                    if (relative.z > 0) return false;
                }
                break;
        }

        float angel = Vector3.Angle(m_myTrans.forward, pTarget.GetPosition() - m_myTrans.position);
        if (angel < minAngel || angel > maxAngel) return false;

        float distance = Vector3.Distance(m_myTrans.position, pTarget.GetPosition());
        if (distance < minDis || distance > maxDis) return false;


        return true;
    }


    /// <summary>
    /// 判定目标是否在 以bottomMidPos为源的 矩形框内
    /// </summary>
    /// <param name="height">矩形长度</param>
    /// <param name="width">矩形宽度</param>
    /// <param name="torward">矩形的朝向</param>
    /// <param name="bottomMidPos">底边的中心pos</param>
    /// <param name="pTarget">目标</param>
    /// <returns></returns>
    public bool IsInRect(float height, float width, Vector3 torward, Vector3 bottomMidPos, CBaseNpc pTarget)
    {

        height = Math.Abs(height) + pTarget.CharacterRadius; //长
        float half_width = Math.Abs((width + pTarget.CharacterRadius * 2f) / 2); //宽

        //目标位置
        Vector3 targetPos = new Vector3(pTarget.GetPosition().x, 0f, pTarget.GetPosition().z);
        //计算源点位置
        Vector3 scrPos = new Vector3(bottomMidPos.x, 0f, bottomMidPos.z);

        //Vector3 forward = m_myTrans.forward;
        //         if (height < 0)
        //         {
        //             torward = -m_myTrans.forward;
        //         }

        float angel = Vector3.Angle(targetPos - scrPos, torward);

        if (angel > 90)
        {
            return false;
        }
        float checkAngel = Mathf.Atan2(half_width, height) * Mathf.Rad2Deg; //位于对角线时的角度
        float distance = Common.Get2DVecter3Length(targetPos, scrPos);

        if (angel <= checkAngel)
        {
            if (distance > height / Mathf.Cos(angel / Mathf.Rad2Deg))
            {
                return false;
            }
        }
        else
        {
            if (distance > half_width / Mathf.Sin(angel / Mathf.Rad2Deg))
            {
                return false;
            }
        }

        return true;
    }
    public virtual void Release(eObjectDestroyType type)
    {
        if (null != m_myTrans)
        {
            CParticleManager.GetInst().DestoryEffectOnNpcDead(m_myTrans.gameObject);
        }

        m_skillList.Clear();
        m_rangeNpcList.Clear();
        m_createParticleList.Clear();
        m_bLoadComplete = false;
        m_uiCurrUseSkillType = 0;
        m_lastUpdatePosition = Vector3.zero;
        m_DefaultSkill = null;

        if (null != m_pRagdoll)
        {
            m_pRagdoll.Release();
        }

        if (m_characterController != null)
        {
            m_characterController.height = m_fOrigionBodyHeight;
            m_characterController.center = new Vector3(m_characterController.center.x, m_characterController.height / 2.0f, m_characterController.center.z);
        }

        if (m_pNpcObj != null)
        {
            m_pNpcObj.DestroyGameObject(type);
            m_pNpcObj = null;
        }

        if (m_textureLeftWeapon != null)
        {
            m_textureLeftWeapon.DestroyGameObject(eObjectDestroyType.Memory);
            m_textureLeftWeapon = null;
        }

        if (m_textureRightWeapon != null)
        {
            m_textureRightWeapon.DestroyGameObject(eObjectDestroyType.Memory);
            m_textureRightWeapon = null;
        }

        if (m_audioSourceObject != null && m_myTrans != null)
        {
            m_audioSourceObject.transform.parent = m_myTrans;
        }



        if (m_buffMgr != null)
        {
            m_buffMgr.Release(true);
        }

        if (null != m_pAuraMgr)
        {
            m_pAuraMgr.Release();
        }

        if (null != m_targetList)
        {
            m_targetList.Clear();
        }

        m_sTag = DEFINE.UNTAGGED_OBJECT_TAG;

        RemoveWeapon();
        RemoveHpPanel();

        LockHP = false;
        LockHPValue = 0;
        Material mater;
        for (int mc = 0; mc < m_materiaslCount; mc++)
        {
            mater = Materials[mc];
            if (mater.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
            {
                mater.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, 1);
            }
            else if (mater.HasProperty(DEFINE.SHADER_PROPERTY_HITCOLOR))
            {
                mater.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
            }
        }
        Materials = null;
        m_materialLeft = null;
        m_materialRight = null;
        m_material0Name = string.Empty;

    }

    public bool isCheckScriptValue(ScriptContent pScriptInfo)
    {
        eScriptCheckType eType = (eScriptCheckType)pScriptInfo.ScriptType;

        switch (eType)
        {
            case eScriptCheckType.NPC_HP_PERCENT:
                {
                    return ScriptManager.bCheckAttribute(m_nHp, pScriptInfo, (float)m_nHp / (float)m_pCard.nMaxHp);
                }
            case eScriptCheckType.NPC_HP:
                {
                    return ScriptManager.bCheckAttribute(m_nHp, pScriptInfo);
                }
            case eScriptCheckType.NPC_ENEMY_AREA:
                {
                    return ScriptManager.bCheckArea(this, pScriptInfo);
                }
            case eScriptCheckType.NPC_ENEMY_DIRECTION:
                {
                    return ScriptManager.bCheckDirection(this, pScriptInfo);
                }
            case eScriptCheckType.NOT_CHECKED:
                {
                    return true;
                }
            default:
                {
                    MyLog.LogError("isCheckScriptValue can't find scriptType: " + eType);
                }
                break;
        }

        return false;
    }

    public void DoScriptResult(ScriptContent pScriptInfo, bool bCheckValue, CSkillupInfo pSkillupInfo, int nDoScriptCount, uint uiSkillLoaderKey, float dragonPromotion)
    {
        int wAction = 0;
        string sValue = "";

        if (bCheckValue)
        {
            wAction = pScriptInfo.TrueAction;
            sValue = pScriptInfo.TrueValue;
        }
        else
        {
            wAction = pScriptInfo.FalseAction;
            sValue = pScriptInfo.FalseValue;
        }

        switch ((eScriptAction)wAction)
        {
            case eScriptAction.NPC_AddAura:
                {
                    //加光环
                    if (null != m_pAuraMgr)
                    {
                        uint auraID = MyConvert_Convert.ToUInt32(sValue);
                        m_pAuraMgr.AddAura(auraID, pSkillupInfo, dragonPromotion);
                    }
                }
                break;
            case eScriptAction.NPC_AddAlly:
                {
                    //召唤友军
                    string[] args = sValue.Split('$');
                    if (args.Length > 1)
                    {
                        if (m_allyList.Count >= 10)
                        {
                            MyLog.LogWarning(" Npc AddAlly is reaching the 10 limit . ");
                            return;
                        }

                        uint uiNpcLoaderKey = MyConvert_Convert.ToUInt32(args[0]);
                        Monster allyMonster = m_pBattleScene.CreateMonster(uiNpcLoaderKey, 1, m_myTrans.position, m_myTrans.rotation, "", this, pSkillupInfo);

                        float delayTime = MyConvert_Convert.ToSingle(args[1]);
                        if (delayTime > 0 && null != allyMonster)
                        {
                            UnityCallBackManager.GetInst().AddCallBack(delayTime, DelayRemoveNpc, new object[] { allyMonster });
                        }

                        //填写monster表ID$存在时间(秒,-1表示永久)$血量百分比$攻击百分比$防御百分比(10000表示100%)
                        if (args.Length > 4)
                        {
                            float maxHp = MyConvert_Convert.ToSingle(args[2]) / 10000f;
                            float atk = MyConvert_Convert.ToSingle(args[3]) / 10000f;
                            float def = MyConvert_Convert.ToSingle(args[4]) / 10000f;

                            if (allyMonster != null)
                            {
                            allyMonster.AttrInheritList = new float[] { maxHp, atk, def };
                            allyMonster.SetAttrInherit();
                        }
                        }

                        //加入小弟列表
                        if (allyMonster != null && !m_allyList.Contains(allyMonster.Index))
                            m_allyList.Add(allyMonster.Index);
                    }
                }
                break;
            case eScriptAction.NPC_ChangeMaterial:
                {
                    string[] args = sValue.Split('$');
                    if (args.Length == 2)
                    {
                        AddMaterials(false, MyConvert_Convert.ToInt32(args[0]));

                        UnityCallBackManager.GetInst().AddCallBack(MyConvert_Convert.ToSingle(args[1]), DealyResetMaterial);
                    }
                }
                break;
            case eScriptAction.NPC_AddBuff:
                {
                    uint uiBuffID = MyConvert_Convert.ToUInt32(sValue);
                    if (m_buffMgr != null)
                    {
                        m_buffMgr.AddBuff(uiBuffID, pSkillupInfo, false, dragonPromotion);
                    }

                }
                break;
            case eScriptAction.NPC_DelBuff:
                {
                    uint uiBuffID = MyConvert_Convert.ToUInt32(sValue);
                    DelBuff(uiBuffID);
                }
                break;

            case eScriptAction.NPC_AddHP_Percent:
                {
                    string[] args = sValue.Split('$');

                    uint particleID = 0;
                    if (args.Length > 1)
                    {
                        particleID = MyConvert_Convert.ToUInt32(args[1]);
                    }

                    int percent = MyConvert_Convert.ToInt32(args[0]);
                    int value = (int)(m_pCard.nMaxHp * percent / 100);

                    if (ShowAddHpFlyWord(value))
                    {
                        SingletonObject<FlywordMediator>.GetInst().CreateFlyword(value, false, this);
                    }

                    AddHp(value);
                    if (particleID != 0)
                    {
                        CreateParticle(particleID);
                    }
                }
                break;
            case eScriptAction.NPC_AddHP_Value:
                {
                    string[] args = sValue.Split('$');

                    uint particleID = 0;
                    if (args.Length > 1)
                    {
                        particleID = MyConvert_Convert.ToUInt32(args[1]);
                    }

                    int value = MyConvert_Convert.ToInt32(args[0]);
                    if (ShowAddHpFlyWord(value))
                    {
                        SingletonObject<FlywordMediator>.GetInst().CreateFlyword(value, false, this);
                    }


                    AddHp(value);
                    if (particleID != 0)
                    {
                        CreateParticle(particleID);
                    }
                }
                break;
            case eScriptAction.NPC_AddMP_Value:
                {
                    int value = MyConvert_Convert.ToInt32(sValue);
                    if (this is BaseBattlePlayer)
                    {
                        BaseBattlePlayer bbp = (BaseBattlePlayer)this;
                        bbp.AddMp(value);
                    }
                }
                break;
            case eScriptAction.NPC_UseSkill:
                {
                    string[] args = sValue.Split('$');
                    uint uiSkillID = MyConvert_Convert.ToUInt32(args[0]);

                    if (null != GrabNpc)//抓取状态 不允许任何技能插入
                    {
                        MyLog.LogError(" Can not UsesSkill during the GrabState !.");
                        return;
                    }

                    bool bScript = true;
                    if (args.Length > 1)
                    {
                        uint uiCheckID = MyConvert_Convert.ToUInt32(args[1]);

                        if (uiCheckID != 0)
                        {
                            if (GetCurrActState() == eActionState.Skill)
                            {
                                CSkillState pSkillState = m_stateMgr.GetState(eActionState.Skill) as CSkillState;
                                SkillContent pSkillLoader = pSkillState.GetSkillInfo();

                                if (pSkillLoader.Key != uiCheckID)
                                {
                                    return;
                                }
                            }
                            else if (GetCurrActState() == eActionState.Attack)
                            {
                                if (attackID != uiCheckID)
                                {
                                    return;
                                }
                            }
                            else
                            {
                                return;
                            }
                            bScript = false;
                        }
                    }

                    this.Command(eCommandType.UseSkill, new UseSkillCommandArg(uiSkillID, m_targetList, bScript)); ;
                }
                break;
            case eScriptAction.NPC_SkillHit:
                {
                    uint uiSkillID = MyConvert_Convert.ToUInt32(sValue);
                    SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillID);

                    HitResultWithoutTarget(pSkillInfo);
                }
                break;
            case eScriptAction.NPC_PlayEffectAtMouse:
                {
                    uint uiParticleID = MyConvert_Convert.ToUInt32(sValue);

                    ParticleContent pParticleInfo = HolderManager.m_ParticleHolder.GetStaticInfo(uiParticleID);
                    switch ((eParticleType)pParticleInfo.Sort)
                    {
                        case eParticleType.GroundSpecified:
                            {
                                Camera camera = CCamera.GetInst().GetCamera();
                                Ray ray = camera.ScreenPointToRay(Input.mousePosition);

                                RaycastHit rayHit = new RaycastHit();
                                if (Physics.Raycast(ray, out rayHit, 1000, 1 << DEFINE.TERRAINLAYER))
                                {

                                    m_myTrans.LookAt(rayHit.point);
                                    CParticleManager.GetInst().CreateGroundEffect(uiParticleID, rayHit.point, Vector3.zero);
                                }
                            }
                            break;

                    }
                }
                break;
            case eScriptAction.NPC_SkillBreak:
                {
                    CBaseState state = m_stateMgr.GetCurrState();
                    if (state.GetState() == eActionState.Skill && NpcSort == eNpcSort.Avatar)
                    {
                        //m_stateMgr.LeaveState(eActionState.Skill);
                        CSkillState pSkillState = state as CSkillState;
                        pSkillState.SkillCanBreak = true;
                    }
                }
                break;
            case eScriptAction.NPC_IgoneCollider:
                {
                    float ignoreTime = MyConvert_Convert.ToSingle(sValue);
                    // 忽略碰撞
                    IgnoreNpcCollsion(true);

                    UnityCallBackManager.GetInst().AddCallBack(ignoreTime, IgnoreNpcCollsion, new object[] { false });
                }
                break;
            case eScriptAction.NPC_Stealth:
                {
                    string[] args = sValue.Split('$');
                    if (args.Length == 4)
                    {
                        float fadeOutDelay = MyConvert_Convert.ToSingle(args[0]);      //渐隐延迟
                        float fadeOutTime = MyConvert_Convert.ToSingle(args[1]);    //渐隐

                        float fadeInDelay = MyConvert_Convert.ToSingle(args[2]); //渐现延迟
                        float fadeInTime = MyConvert_Convert.ToSingle(args[3]);     //渐现

                        m_fadeOffCallbackIndex = UnityCallBackManager.GetInst().AddCallBack(fadeOutDelay, FadeOut, new object[] { fadeOutTime });
                        m_fadeOnCallbackIndex = UnityCallBackManager.GetInst().AddCallBack(fadeOutDelay + fadeOutTime + fadeInDelay, FadeIn, new object[] { fadeInTime });
                    }
                }
                break;
            case eScriptAction.NPC_AttriDamage:
                {
                    uint attrID = MyConvert_Convert.ToUInt32(sValue);
                    AttrDamage(this, null, attrID);
                }
                break;
            case eScriptAction.NPC_SkillHitResult:
                {
                    SkillHitResult SkillResult = new SkillHitResult(uiSkillLoaderKey, sValue.Split('$'), HitResultCall);
                    if (null == m_SkillResultList)
                    {
                        m_SkillResultList = new List<SkillHitResult>();
                    }
                    m_SkillResultList.Add(SkillResult);
                }
                break;
            case eScriptAction.NPC_SkillHitWithoutTarget:
                {
                    SkillHitWithoutTarget skillHit = new SkillHitWithoutTarget(uiSkillLoaderKey, sValue, HitWithoutTargetCall);
                    if (null == m_ScriptSkillHitList)
                    {
                        m_ScriptSkillHitList = new List<SkillHitWithoutTarget>();
                    }
                    m_ScriptSkillHitList.Add(skillHit);

                }
                break;
            case eScriptAction.NPC_CreateSkillNpc:
                {
                    if (m_pBattleScene.IsGameOver())
                    {
                        return;
                    }
                    string[] spils = sValue.Split('$');
                    uint skillID = MyConvert_Convert.ToUInt32(spils[0]);
                    float time = MyConvert_Convert.ToSingle(spils[1]);
                    eSkillNpcPos posType = (eSkillNpcPos)MyConvert_Convert.ToByte(spils[2]);

                    AddSkillNpc(skillID, time, posType, HolderManager.m_SkillHolder.GetStaticInfo(skillID));
                }
                break;
            case eScriptAction.Other_DelayDoScript:
                {
                    string[] args = sValue.Split('$');
                    if (args.Length == 2)
                    {
                        float delayTime = MyConvert_Convert.ToSingle(args[0]);
                        uint scriptID = MyConvert_Convert.ToUInt32(args[1]);

                        UnityCallBackManager.GetInst().AddCallBack(delayTime, DelayScript, new object[] { scriptID, pSkillupInfo, uiSkillLoaderKey });
                    }
                }
                break;
            case eScriptAction.Other_ProbabilityDoScript:
                {
                    string[] args = sValue.Split('$');
                    if (args.Length == 2)
                    {
                        int probabilityValue = MyConvert_Convert.ToInt32(args[0]);
                        uint scriptID = MyConvert_Convert.ToUInt32(args[1]);

                        int rangeNum = UnityEngine.Random.Range(1, 101);
                        if (rangeNum <= probabilityValue)
                        {
                            ScriptManager.RequestScript(scriptID, this, pSkillupInfo, 0, uiSkillLoaderKey);
                        }
                    }
                }
                break;
            case eScriptAction.Other_CountDoScript:
                {
                    string[] args = sValue.Split('$');
                    if (args.Length == 3 && !m_bStop)
                    {
                        int maxCount = MyConvert_Convert.ToInt32(args[0]);
                        if (nDoScriptCount >= maxCount)
                        {
                            return;
                        }

                        float interval = MyConvert_Convert.ToSingle(args[1]);
                        uint executeScript = MyConvert_Convert.ToUInt32(args[2]);//调用scirpt

                        uint srcScriptID = (uint)pScriptInfo.Key; //源script

                        ePartnerState partnerstate = ePartnerState.None;

                        if (this is BaseBattlePlayer)
                            partnerstate = (this as BaseBattlePlayer).PartnerState;

                        UnityCallBackManager.GetInst().AddCallBack(interval, IntervalScript, new object[] { nDoScriptCount, maxCount, executeScript, srcScriptID, pSkillupInfo, partnerstate, uiSkillLoaderKey });
                    }
                }
                break;
        }
    }
    public void HitResultCall(CBaseNpc pTarget, bool isDodge, string[] args)
    {

        eSkillResultType type = (eSkillResultType)MyConvert_Convert.ToByte(args[0]);

        if (null != pTarget)
        {
            switch (type)
            {
                case eSkillResultType.GotoBehitterPos:
                    {
                        if (!isDodge)
                        {
                            m_myTrans.position = pTarget.GetPosition();
                        }
                    }
                    break;
                case eSkillResultType.RandomPos:
                    {
                        float minRadius = MyConvert_Convert.ToSingle(args[1]);
                        float maxRadius = MyConvert_Convert.ToSingle(args[2]);

                        int count = 0;
                        Vector3 position = Common.SummonRandomPosition(minRadius, maxRadius, pTarget.GetPosition(), ref count);
                        if (position != Vector3.zero)
                        {
                            position = CurrBattleScene.SummonPosition(position, CharacterRadius, false, null, NpcCollider) + Vector3.up * 0.2f;
                            SetPosition(position);
                        }
                    }
                    break;
                default:
                    break;
            }
        }

    }


    private void HitWithoutTargetCall(Vector3 position, string scriptArg)
    {
        string[] scriptArgs = scriptArg.Split('$');
        eSkillHitCallType type = (eSkillHitCallType)MyConvert_Convert.ToByte(scriptArgs[0]);

        switch (type)
        {
            case eSkillHitCallType.CreateSkillNpc://填 1(创建实体)
                {
                    Vector3 entityPos = Vector3.zero;
                    eSkillNpcPosByScript postype = (eSkillNpcPosByScript)MyConvert_Convert.ToByte(scriptArgs[1]); //位置类型(1:施法者位置,2:指定点位置
                    uint skillId = MyConvert_Convert.ToUInt32(scriptArgs[2]); //技能ID
                    float time = MyConvert_Convert.ToSingle(scriptArgs[3]); //时间
                    //string path = scriptArgs[4]; //路径

                    if (postype == eSkillNpcPosByScript.SkillerPos)
                    {
                        entityPos = m_myTrans.position;
                    }
                    else if (postype == eSkillNpcPosByScript.AppointPos)
                    {
                        entityPos = position;
                    }

                    uint index = CreateSkillNpc(skillId, entityPos);
                    UnityCallBackManager.GetInst().AddCallBack(time, RemoveSkillNpc, new object[] { index });
                }
                break;
            case eSkillHitCallType.KillingSelf: //填 2(自杀)
                {
                    if (scriptArgs.Length > 0)
                    {
                        float delayTime = MyConvert_Convert.ToSingle(scriptArgs[1]);
                        UnityCallBackManager.GetInst().AddCallBack(delayTime, delegate(object[] args)
                        {
                            SelfDestruction = true;
                            NpcDead(true);
                        });
                    }
                    else
                    {
                        SelfDestruction = true;
                        NpcDead(true);
                    }
                }
                break;
            default:
                break;
        }
    }

    private void DelayScript(params object[] args)
    {
        uint uiScriptsID = MyConvert_Convert.ToUInt32(args[0]);
        CSkillupInfo pSkillupInfo = (CSkillupInfo)(args[1]);
        uint uiSkillLoaderKey = MyConvert_Convert.ToUInt32(args[2]);

        ScriptManager.RequestScript(uiScriptsID, this, pSkillupInfo, 0, uiSkillLoaderKey);
    }

    private void IntervalScript(params object[] args)
    {
        ePartnerState parterstateArg = (ePartnerState)args[5];

        ePartnerState partnerstate = ePartnerState.None;
        if (this is BaseBattlePlayer)
            partnerstate = (this as BaseBattlePlayer).PartnerState;

        if (IsDead() || partnerstate != parterstateArg || m_bStop)
        {
            return;
        }

        int nDoScriptCount = MyConvert_Convert.ToInt32(args[0]);
        int maxCount = MyConvert_Convert.ToInt32(args[1]);
        uint executeScript = MyConvert_Convert.ToUInt32(args[2]);
        uint srcScriptID = MyConvert_Convert.ToUInt32(args[3]);
        CSkillupInfo pSkillupInfo = (CSkillupInfo)args[4];
        uint skillLoaderkey = MyConvert_Convert.ToUInt32(args[5]);

        ScriptManager.RequestScript(executeScript, this, pSkillupInfo, 0, skillLoaderkey);
        nDoScriptCount++;
        if (nDoScriptCount < maxCount)
        {
            ScriptManager.RequestScript(srcScriptID, this, pSkillupInfo, nDoScriptCount, skillLoaderkey);
        }
    }


    public void RemoveAlly(uint uindex)
    {
        if (m_allyList.Contains(uindex))
        {
            m_allyList.Remove(uindex);
        }
    }

    private void DelayRemoveNpc(params object[] args)
    {
        Monster monster = args[0] as Monster;

        if (null != m_pBattleScene.GetNpc(monster.Index))
        {
            if (null != monster.GetTransform())
            {
                monster.NpcDead(true);
                monster.RemoveNpc();
            }
            m_pBattleScene.RemoveNpc(monster.Index);
        }

    }

    private void DealyResetMaterial(params object[] args)
    {
        AddMaterials(true);
    }

    private void IgnoreNpcCollsion(params object[] args)
    {
        bool state = (bool)args[0];
        IgnoreNpcCollsion(state);
    }

    private void DelayRemoveBingding(params object[] args)
    {
        uint npcIndex = MyConvert_Convert.ToUInt32(args[0]);


        CBaseNpc pNpc = m_pBattleScene.GetNpc(npcIndex);
        if (pNpc != null)
        {
            pNpc.GetTransform().parent = null;
            //pNpc.LookAt(pNpc.GetTransform());
        }
    }

    /// <summary>
    ///忽略碰撞开关
    /// </summary>
    /// <param name="state"></param>
    /// <param name="checkSnugly">是否需要搞基检测</param>
    public void IgnoreNpcCollsion(bool state, bool checkSnugly = true)
    {
        //多人PVE不受此影响
        if (CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            return;
        }
        
        //MyLog.LogError(" IgnoreNpcCollsion :  " + state);
        bool ignoreState = Physics.GetIgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.MONSTER_LAYER);
        if (state == ignoreState)
        {
            return;
        }

        bool bNeedSmoothMove = false;
        if (!state && checkSnugly)
        {
            CBaseNpc pTarget = IsSnuglyNpc(-20f);
            if (null != pTarget)
            {
                //贴身
                EnterState(eActionState.SmoothMove);

                CSmoothMoveState smoothState = GetState(eActionState.SmoothMove) as CSmoothMoveState;
                if (null != smoothState)
                {
                    Vector3 dstPosition = m_myTrans.forward * (pTarget.CharacterRadius + CharacterRadius * 3f) + pTarget.GetPosition();
                    smoothState.SetSmoothInfo(dstPosition);

                    bNeedSmoothMove = true;
                }
            }
        }

        if (!bNeedSmoothMove)
        {
            Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.MONSTER_LAYER, state);

            if (CurrBattleScene.BattleType == eBattleType.Arena ||
                CurrBattleScene.BattleType == eBattleType.Wasteland ||
                CurrBattleScene.BattleType == eBattleType.Mining ||
                CurrBattleScene.BattleType == eBattleType.Pvp ||
                CurrBattleScene.BattleType == eBattleType.MultiPve)
            {
                Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.AVATAR_LAYER, state);
            }

        }
    }



    //npc渐隐
    private void FadeOut(params object[] args)
    {
        //float fadeOutTime = (float)args[0];
        float fadeOutTime = 0.1f;
        SetAlphaVertexColorOff(fadeOutTime);

        m_bHideModel = true;

        m_buffMgr.SetAllParticleEnabled(false);

        BaseBattlePlayer bbp = this as BaseBattlePlayer;
        if (null != bbp)
            bbp.EnabledPvpStepParticle = false;
    }

    //npc渐现
    private void FadeIn(params object[] args)
    {
        float fadeInTime = (float)args[0];
        SetAlphaVertexColorOn(fadeInTime);

        m_bHideModel = false;

        m_buffMgr.SetAllParticleEnabled(true);

        BaseBattlePlayer bbp = this as BaseBattlePlayer;
        if (null != bbp)
            bbp.EnabledPvpStepParticle = true;
    }


    private void ChangeShaderColor(eLiveState liveState)
    {
        switch (liveState)
        {
            case eLiveState.NONE: break;
            //case eLiveState.LiveState: ChangeShaderAlpha_MobileLightmapUnlit(true); break;
            case eLiveState.Fade: ChangeAlphaVertexColor(false); break;
            case eLiveState.Grow: ChangeAlphaVertexColor(true); break;
            //case eLiveState.DeyState: ChangeShaderAlpha_MobileLightmapUnlit(false); break;
            default: break;
        }
    }

    //protected virtual void ChangeShaderAlpha_MobileLightmapUnlit(bool isLive)   //改alpha值，实现淡入淡出
    //{
    //转移到BaseBattlePlayer脚本
    //if (npc != eNpcSort.Monster)
    //{
    //    ChangeShaderToXRayAndBackLightVertex(true);
    //    m_liveState = eLiveState.NONE;
    //    return;
    //}


    //转移到Monster脚本
    //if (m_materials == null || m_materials.Length <= 0)
    //{
    //    m_liveState = eLiveState.NONE;
    //    return;
    //}

    //ChangeShaderToMobileLightmapUnlit(true);
    //if (isLive)
    //{
    //    m_alpha += (1f / m_changeColorSpeed) * Time.deltaTime;
    //}
    //else
    //{
    //    m_alpha -= (1f / m_changeColorSpeed) * Time.deltaTime;
    //}

    //m_alpha = Mathf.Clamp01(m_alpha);

    ////if (m_alpha > 0)
    ////    ShowNpc(true);
    ////else
    ////    ShowNpc(false);

    //m_materials[0].SetFloat("_Alpha", m_alpha);
    //if (m_mat)
    //    m_mat.SetFloat("_Alpha", m_alpha);
    //if (m_materialRight)
    //    m_materialRight.SetFloat("_Alpha", m_alpha);

    //if (m_particleSystem == null)
    //    m_particleSystem = m_myTrans.GetComponentsInChildren<ParticleSystem>();

    //if (m_particleSystem != null)
    //{
    //    int len = m_particleSystem.Length;
    //    Color color;
    //    for (int i = 0; i < len; i++)
    //    {
    //        color = m_particleSystem[i].renderer.material.GetColor("_Color");
    //        color.a = m_alpha;
    //        m_particleSystem[i].renderer.material.SetColor("_Color", color);
    //    }
    //}

    //if (m_alpha == 0 || m_alpha == 1)
    //{
    //    m_liveState = eLiveState.NONE;
    //    if (m_alpha != 0)
    //    {
    //        if (!m_useSpecifyShader)
    //        {
    //            m_materials[0].shader = DynamicShader.GetShader(m_material0Name);
    //        }
    //        if (m_mat)
    //            m_mat.shader = DynamicShader.GetShader("MyMobile/Lightmap");
    //        if (m_materialRight)
    //            m_materialRight.shader = DynamicShader.GetShader("MyMobile/Lightmap");

    //        m_currShaderName = m_material0Name;
    //    }
    //}
    //}
    #region 
    
    //public void ChangeShaderValueColor_XRayAndBackLightSufaces(eXRayAndBackLightSufacesShaderName name,Color color)    
    //{
    //    if (color != null && m_materials != null && m_materials.Length > 0)
    //    {
    //        string tempName = name.ToString();
    //        foreach (Material val in m_materials)
    //        {
    //            val.SetColor(tempName, color);
    //        }
    //        if (m_mat != null)
    //            m_mat.SetColor(tempName, color);
    //        if (m_materialRight != null)
    //            m_materialRight.SetColor(tempName, color);
    //    }
    //}
    //public void ChangeShaderValueFloat_XRayAndBackLightSufaces(eXRayAndBackLightSufacesShaderName name,float valus)     
    //{
    //    if (valus != null && m_materials != null && m_materials.Length > 0)
    //    {
    //        string tempName = name.ToString();
    //        foreach (Material val in m_materials)
    //        {
    //            val.SetFloat(tempName, valus);
    //        }
    //        if (m_mat != null)
    //            m_mat.SetFloat(tempName, valus);
    //        if (m_materialRight != null)
    //            m_materialRight.SetFloat(tempName, valus);
    //    }
    //}
    #endregion

    #region
    //转移到BaseBattlePlayer脚本
    //protected void ChangeShaderToAlphaVertex()
    //{
    //    if (m_materials != null || m_materials.Length <= 0)
    //        for (int i = 0, count = m_materials.Length; i < count;++i )
    //        {
    //            Material val = m_materials[i];
    //            if (val.shader.name != "MyMobile/Avatar AlphaVertex")
    //            {
    //                val.shader = DynamicShader.GetShader("MyMobile/Avatar AlphaVertex");
    //                val.SetColor("_Color", new Color(1, 1, 1, 1));

    //            }
    //        }

    //    if (m_mat != null && m_mat.shader.name != "MyMobile/Avatar AlphaVertex")
    //    {
    //        m_mat.shader = DynamicShader.GetShader("MyMobile/Avatar AlphaVertex");
    //        m_mat.SetColor("_Color", new Color(1, 1, 1, 1));
    //    }
    //    if (m_materialRight != null && m_materialRight.shader.name != "MyMobile/Avatar AlphaVertex")
    //    {
    //        m_materialRight.shader = DynamicShader.GetShader("MyMobile/Avatar AlphaVertex");
    //        m_materialRight.SetColor("_Color", new Color(1, 1, 1, 1));
    //    }
    //}
    #endregion


    //转移到BaseBattlePlayer脚本
    protected virtual void ChangeAlphaVertexColor(bool add)
    {
        //ChangeShaderToAlphaVertex();
        //if (add)
        //{
        //    m_alphaVertexAlpha += (1f / m_alphaVertexSpeed) * Timer.GetTimeForDateTime(Time.deltaTime);
        //}
        //else
        //{
        //    m_alphaVertexAlpha -= (1f / m_alphaVertexSpeed) * Timer.GetTimeForDateTime(Time.deltaTime);
        //}

        //m_alphaVertexAlpha = Mathf.Clamp01(m_alphaVertexAlpha);

        ////if (m_alphaVertexAlpha > 0)
        ////{
        ////    ShowNpc(true);
        ////}
        ////else
        ////{
        ////    ShowNpc(false);
        ////}

        //Color tempColor = new Color(1, 1, 1, m_alphaVertexAlpha);
        //if (m_materials != null)
        //for (int i = 0, count = m_materials.Length; i < count; ++i)
        //{
        //    Material val = m_materials[i];
        //    val.SetColor("_Color", tempColor);
        //}
        //if (m_mat != null)
        //{
        //    m_mat.SetColor("_Color", tempColor);
        //}
        //if (m_materialRight != null)
        //{
        //    m_materialRight.SetColor("_Color", tempColor);
        //}

        //if (m_directPoint != null)
        //{
        //    m_directPoint.transform.GetChild(0).GetChild(0).renderer.material.SetColor("_Color", tempColor);
        //    m_directPoint.transform.GetChild(0).GetChild(1).renderer.material.SetColor("_Color", tempColor);
        //}
        //if (m_alphaVertexAlpha == 0 || m_alphaVertexAlpha == 1)
        //{
        //    m_liveState = eLiveState.NONE;
        //    if (m_alphaVertexAlpha != 0)
        //        ChangeShaderToXRayAndBackLightVertex(true);
        //}
    }

    public static void ChangeShaderToXRayAndBackLightVertex(Material mat, bool resetValue)  //shader替换为MyMobile/XRayAndBackLightVertex
    {
        //for (int i = 0; i < m_materiaslCount; i++)
        //{
        //    Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_XRAY);
        //}

        //if (m_mat != null)
        //{
        //    m_mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_XRAY);
        //}
        //if (m_materialRight != null)
        //{
        //    m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_XRAY);
        //}

        //if (m_mountMat != null)
        //{
        //    m_mountMat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_XRAY);
        //}
        if (mat == null)
        {
            MyLog.DebugLogException("CBaseNpc ChangeShaderToXRayAndBackLightVertex material is null");
            return;
        }
        mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_XRAY);

        if (resetValue)
        {
            ChangeShaderValueColor_XRayAndBackLightVertex(mat, eXRayAndBackLightVertexShaderName._BlendColor, new Color(0, 1, 0.835f, 1));
            ChangeShaderValueFloat_XRayAndBackLightVertex(mat, eXRayAndBackLightVertexShaderName._BlendVal, 0.65f);
            ChangeShaderValueFloat_XRayAndBackLightVertex(mat, eXRayAndBackLightVertexShaderName._BlendPower, 18);

            mat.SetVector(DEFINE.SHADER_PROPERTY_LIGHTPOSITION, CCamera.GetInst().Vector);
            mat.SetColor(DEFINE.SHADER_PROPERTY_LIGHTCOLOR, new Color(0.64f, 0.64f, 0.52f, 0));
            mat.SetFloat(DEFINE.SHADER_PROPERTY_INTENSITY, 3);
        }
    }

    public static void ChangeShaderValueFloat_XRayAndBackLightVertex(Material mat, eXRayAndBackLightVertexShaderName name, float valus)     
    {
        //if (valus != null && m_materiaslCount > 0)
        //{
        //    string tempName = name.ToString();
        //    for (int i = 0; i < m_materiaslCount; ++i)
        //    {
        //        Materials[i].SetFloat(tempName, valus);
        //    }
        //    if (m_mat != null)
        //        m_mat.SetFloat(tempName, valus);
        //    if (m_materialRight != null)
        //        m_materialRight.SetFloat(tempName, valus);
        //}
        if (mat != null)
            mat.SetFloat(name.ToString(), valus);
    }

    public static void ChangeShaderValueColor_XRayAndBackLightVertex(Material mat, eXRayAndBackLightVertexShaderName name, Color color)   
    {
        //if (color != null && m_materiaslCount > 0)
        //{
        //    string tempName = name.ToString();
        //    foreach (Material val in Materials)
        //    {
        //        val.SetColor(tempName, color);
        //    }
        //    if (m_mat != null)
        //        m_mat.SetColor(tempName, color);
        //    if (m_materialRight != null)
        //        m_materialRight.SetColor(tempName, color);
        //}
        if (mat != null)
            mat.SetColor(name.ToString(), color);
    }

    #region
    //转移到BaseBattlePlayer脚本
    //public void SetAlphaVertexColor(Color color)
    //{
    //    ChangeShaderToAlphaVertex();
    //    if (m_materials != null || m_materials.Length <= 0)
    //    for (int i = 0, count = m_materials.Length; i < count; ++i)
    //    {
    //        Material val = m_materials[i];
    //        val.SetColor("_Color", color);
    //    }
    //    if (m_mat != null)
    //    {
    //        m_mat.SetColor("_Color", color);
    //    }
    //    if (m_materialRight != null)
    //    {
    //        m_materialRight.SetColor("_Color", color);
    //    }

    //    if (m_directPoint != null)
    //    {
    //        m_directPoint.transform.GetChild(0).GetChild(0).renderer.material.SetColor("_Color", color);
    //        m_directPoint.transform.GetChild(0).GetChild(1).renderer.material.SetColor("_Color", color);
    //    }
    //}
    #endregion

    public virtual void SetAlphaVertexColorOff(float time)    //死亡出生淡入淡出开关（消失）
    {
    }

    public virtual void SetAlphaVertexColorOn(float time)   //淡入淡出开关（出现）
    {
    }

    public void AddBuff(uint uiBuffID, CSkillupInfo pSkillUpLoader = null, bool speical = false, float dragonPromotion = 0f)
    {
        if (m_buffMgr != null)
        {
            m_buffMgr.AddBuff(uiBuffID, pSkillUpLoader, speical, dragonPromotion);
        }

    }

    public void DelBuff(uint uiBuffID)
    {
        if (m_buffMgr != null)
        {
            m_buffMgr.AddDestroyBuff(uiBuffID);
        }

    }

    public void ClearAllBuff()
    {
        if (m_buffMgr != null)
        {
            m_buffMgr.Release(false);
        }

    }

    //清楚所有光环效果
    public void ClearAllAura()
    {
        if (m_pAuraMgr != null)
        {
            m_pAuraMgr.Release();
        }

        if (null != m_auraList)
        {
            for (int i = 0, len = m_auraList.Count; i < len; i++)
            {
                DelBuff(m_auraList[i].BuffID);
            }

            m_auraList.Clear();
        }
    }

    public void ShowNpc(bool bShow)
    {
        if (m_myTrans == null)
        {
            return;
        }

        Renderer[] renders = m_myTrans.GetComponentsInChildren<Renderer>(true);
        foreach (Renderer render in renders)
        {
            if (!render.name.Equals("clothes"))
            {
                render.enabled = bShow;
            }

        }
    }

    public virtual void AddMaterials(bool restore = true, int index = 0)
    {

    }

    public virtual void ChangeMaterials(bool restore = true, string name = "")
    {

    }


    ////////////////////////////////////////////////////////////////
    // ↓↓↓↓↓↓↓↓Brand new things below!!!↓↓↓↓↓↓↓↓↓↓
    ////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////// 

    //protected CSimpleFSM m_npcBehaviourFSM;

    #region 武器相关
    /// <summary>
    /// 装备武器
    /// </summary>
    /// <param name="weaponId"></param>
    //protected virtual void EquipWeapon(uint weaponId)
    //{
    //    EquipContent pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(weaponId);
    //    if (null != pWeaponLoader)
    //    {
    //        m_leftWeaponAnimator = null;
    //        m_leftWeapon = null;
    //        m_rightWeaponAnimaror = null;
    //        m_rightWeapon = null;

    //        List<string> pathArray = pWeaponLoader.GetPath();
    //        if (!pathArray[0].Equals("0"))
    //        {
    //            m_pLeftWeaponObject = new CObject(pathArray[0]);
    //            m_pLeftWeaponObject.CallBack = LoadLeftWeaponCompleted;
    //            m_pLeftWeaponObject.IsMemoryFactory = true;
    //            m_pLeftWeaponObject.ObjectType = eObjectType.Weapon;
    //            m_pLeftWeaponObject.LoadObject();
    //        }

    //        if (!pathArray[1].Equals("0"))
    //        {
    //            m_pRightWeaponObject = new CObject(pathArray[1]);
    //            m_pRightWeaponObject.CallBack = LoadRightWeaponCompleted;
    //            m_pRightWeaponObject.IsMemoryFactory = true;
    //            m_pRightWeaponObject.ObjectType = eObjectType.Weapon;
    //            m_pRightWeaponObject.LoadObject();
    //        }
    //        m_nWeaponCount = pathArray.Count;
    //    }
    //}
    protected virtual void EquipWeapon(string path, bool left)
    {
        if (string.IsNullOrEmpty(path) || path.Equals("0"))
        {
            return;
        }
        if (left)
        {
            m_leftWeaponAnimator = null;
            m_leftWeapon = null;
            m_pLeftWeaponObject = new CObject(path);
            m_pLeftWeaponObject.CallBack = LoadLeftWeaponCompleted;
            m_pLeftWeaponObject.IsMemoryFactory = true;
            m_pLeftWeaponObject.ObjectType = eObjectType.Weapon;
            m_pLeftWeaponObject.LoadObject();
        }
        else
        {
            m_rightWeaponAnimaror = null;
            m_rightWeapon = null;
            m_pRightWeaponObject = new CObject(path);
            m_pRightWeaponObject.CallBack = LoadRightWeaponCompleted;
            m_pRightWeaponObject.IsMemoryFactory = true;
            m_pRightWeaponObject.ObjectType = eObjectType.Weapon;
            m_pRightWeaponObject.LoadObject();
        }
    }

    List<string> pathArray = null;
    private void LoadEquipWeaponTexture(uint weaponId)
    {
        EquipContent pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(weaponId);
        if (pWeaponLoader != null)
        {

            if (m_textureLeftWeapon != null)
                m_textureLeftWeapon.DestroyGameObject(eObjectDestroyType.Memory);
            if (m_textureRightWeapon != null)
                m_textureRightWeapon.DestroyGameObject(eObjectDestroyType.Memory);

            pathArray = pWeaponLoader.ModelLoader.ModelPath;
            if (pathArray == null)
                return;
            m_nWeaponCount = pathArray.Count;
            if (m_nWeaponCount != 2)
                return;

            List<string> pathTexture = pWeaponLoader.ModelLoader.TexturePath;

            int pathTextureCount = pathTexture.Count;

            if (pathTextureCount == 2)
            {
                //if (m_nWeaponCount != pathTextureCount)
                //{
                //    MyLog.LogError("WeaponCount must equal TextureCount");
                //    m_nWeaponCount = pathTexture.Count;
                //}

                if (m_nWeaponCount >= 1 && !pathTexture[0].Equals("0"))
                {
                    m_textureLeftWeapon = new CObject(pathTexture[0]);
                    m_textureLeftWeapon.ObjectType = eObjectType.Texture;
                    m_textureLeftWeapon.IsMemoryFactory = true;
                    m_textureLeftWeapon.CallBack = LoadWeaponTextureCompleted;
                    m_textureLeftWeapon.Args = new object[] { true, pathArray[0] };
                    m_textureLeftWeapon.LoadObject();
                }

                if (m_nWeaponCount >= 2 && !pathTexture[0].Equals("1"))
                {
                    m_textureRightWeapon = new CObject(pathTexture[1]);
                    m_textureRightWeapon.ObjectType = eObjectType.Texture;
                    m_textureRightWeapon.IsMemoryFactory = true;
                    m_textureRightWeapon.CallBack = LoadWeaponTextureCompleted;
                    m_textureRightWeapon.Args = new object[] { false, pathArray[1] };
                    m_textureRightWeapon.LoadObject();
                }
            }
            else
            {
                EquipWeapon(pathArray[0], true);
                EquipWeapon(pathArray[1], false);
            }


        }
    }

    private void LoadWeaponTextureCompleted(GameObject o, params object[] args)
    {
        bool left = (bool)args[0];
        string path = (string)args[1];
        EquipWeapon(path, left);
    }

    /// <summary>
    /// 卸掉武器
    /// </summary>
    protected virtual void RemoveWeapon()
    {
        //先把武器都卸掉
        if (m_pRightWeaponObject != null)
        {
            m_pRightWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            m_pRightWeaponObject = null;
        }
        if (m_pLeftWeaponObject != null)
        {
            m_pLeftWeaponObject.DestroyGameObject(eObjectDestroyType.Memory);
            m_pLeftWeaponObject = null;
        }
    }

    /// <summary>
    /// 切换武器
    /// </summary>
    /// <param name="weaponId"></param>
    protected virtual void ChangeWeapon(uint weaponId)
    {
        RemoveWeapon();

        //EquipWeapon(weaponId);
        LoadEquipWeaponTexture(weaponId);
    }
    #endregion

    #region 技能相关
    //计算出当前的最小最大攻击判定距离
    public void CountAttackRange()
    {
        CInitiativeSkill pSkill;
        SkillContent pSkillLoader;

        //m_minAttackRangeSkillID = 0u;
        m_minAttackRange = 1000;
        m_minNormalAtkRange = 1000;
        m_maxAttackRange = 0;

        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            pSkill = m_skillList[i];
            pSkillLoader = pSkill.GetSkillInfo();
            if (null == pSkillLoader)
            {
                continue;
            }

            CheckAttackRange(pSkillLoader);
            CheckRangeNpcInclude(pSkillLoader);

        }

        pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(DefaultSkillID);
        if (pSkillLoader != null)
        {
            CheckAttackRange(pSkillLoader);
            CheckRangeNpcInclude(pSkillLoader);
        }

        //固定将自己加入列表,以应付ai,script对自己放技能
        AddRangeNpc(this);

    }

    public void CheckAttackRange(SkillContent pSkillLoader)
    {
        List<float> judgeArgs;
        float fArg;


        judgeArgs = pSkillLoader.JudgeArgs;
        if (judgeArgs.Count != 2)
        {
            return;
        }

        fArg = judgeArgs[1] > CharacterRadius + 0.5f ? judgeArgs[1] : CharacterRadius + 0.5f; //不能比自身半径小       


        if (fArg < m_minAttackRange)
        {
            m_minAttackRange = fArg;
        }

        if (fArg < m_minNormalAtkRange && pSkillLoader.SkillType == (byte)eSkillType.AttackType)
        {
            m_minNormalAtkRange = fArg;
        }

        if (fArg > m_maxAttackRange)
        {
            m_maxAttackRange = fArg;
        }

        uint nextID = (uint)pSkillLoader.NextSkill[0];
        if (/*pSkillLoader.GetMultiSkillType() == eMultiSkillType.NormalAtk &&*/ nextID != 0)
        {
            //连招,继续检测
            SkillContent pNextSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
            if (null != pNextSkillLoader)
            {
                CheckAttackRange(pNextSkillLoader);
            }
        }

    }

    //判断范围NPC是否包含友军或者自己
    public void CheckRangeNpcInclude(SkillContent pSkillLoader)
    {
		if (null == pSkillLoader)
		{
			return;
		}

        if (m_rangeNpcIncludeAlly)
        {
            return;
        }
		

        eAffectType affectType = (eAffectType)pSkillLoader.AffectType;
        if (affectType == eAffectType.AffectAll ||
            affectType == eAffectType.AffectFriends ||
            affectType == eAffectType.AffectSelf ||
            affectType == eAffectType.ExceptSelf ||
            affectType == eAffectType.Boss
            )
        {
            m_rangeNpcIncludeAlly = true;

        }
		
		if ( m_rangeNpcIncludeAlly == false && pSkillLoader.NextSkill.Count > 0)
		{
			int nextId = pSkillLoader.NextSkill[0];
			if (nextId != 0) 
			{
				SkillContent nextContent = HolderManager.m_SkillHolder.GetStaticInfo(nextId);
				if ( null != nextContent) 
				{
					CheckRangeNpcInclude(nextContent);
				}
			}
		}
    }

    public void AddRangeTrigger()
    {
        //加载范围检测
        Transform triggerRange = m_myTrans.Find("TriggerRange");
        BaseNpcTargetTrigger bntt;

        if (null == triggerRange)
        {
            GameObject rangeObj = new GameObject("TriggerRange");
            rangeObj.transform.parent = m_myTrans;
            rangeObj.transform.localPosition = Vector3.zero;


            bntt = rangeObj.AddComponent<BaseNpcTargetTrigger>();

            //             Rigidbody rb = rangeObj.AddComponent<Rigidbody>();
            //             rb.useGravity = false;
            //             rb.isKinematic = true;
        }
        else
        {
            bntt = triggerRange.GetComponent<BaseNpcTargetTrigger>();
        }

        if (bntt != null)
        {
            bntt.m_myNpc = this;
			bntt.Radius = RangeRadius;
            eBattleType battletype = SingletonObject<CBattleSceneLoading>.GetInst().battleType;
            if (battletype == eBattleType.Arena || 
                battletype == eBattleType.Wasteland ||
                battletype == eBattleType.Mining || 
                battletype == eBattleType.Pvp || 
                battletype == eBattleType.MultiPve)
            {
                bntt.Radius = 30;
            }
            else
            {
				bntt.Radius = m_maxAttackRange > RangeRadius ? m_maxAttackRange : RangeRadius;
            }

            bntt.enabled = true;
        }
        else
        {
            MyLog.LogError("AddRangeTrigger error");
        }


        //加载检测目标
        if (NpcSort != eNpcSort.Mechanism)
        {
            Transform triggerTrans = m_myTrans.Find("TriggerObject");
            if (null == triggerTrans)
            {
                GameObject triggerObj = new GameObject("TriggerObject");
                triggerObj.transform.parent = m_myTrans;
                triggerObj.transform.localPosition = Vector3.zero;

                triggerTrans = triggerObj.transform;

                m_sphereColliderTirrgerObject = triggerObj.AddComponent<SphereCollider>();
                //m_sphereColliderTirrgerObject.radius = 0.1f;
                m_sphereColliderTirrgerObject.isTrigger = true;

                Rigidbody rb = triggerObj.AddComponent<Rigidbody>();
                rb.useGravity = false;
                rb.isKinematic = true;
            }
            ResetTirrgerObject();
            triggerTrans.gameObject.layer = DEFINE.NPC_TRIGGER_LAYER;
        }

    }

    //NPC进入攻击区域
    public void NpcEnterRange(CBaseNpc pNpc)
    {
        if (!m_rangeNpcIncludeAlly && pNpc.NpcGroup == NpcGroup)
        {
            return;
        }

        if (pNpc.IsDead())
        {
            return;
        }

        AddRangeNpc(pNpc);

    }

    //NPC离开攻击区域
    public void NpcLeaveRange(CBaseNpc pNpc)
    {
        if (null == m_myTrans)
        {
            return;
        }
        //当忽略碰撞时也会进此函数，所以加上距离判断
        if (Vector3.Distance(m_myTrans.position, pNpc.GetPosition()) <= 10 && !pNpc.IsDead())
        {
            return;
        }

        //切换伙伴/主角 不进入LeaveRange
        BaseBattlePlayer bbp = this as BaseBattlePlayer;
        if (null != bbp &&
            (bbp.PartnerState == ePartnerState.SwitchingToAvatar || bbp.PartnerState == ePartnerState.SwitchingToPartner))
        {
            return;
        }

        RemoveRangeNpc(pNpc);
    }

    protected void AddRangeNpc(CBaseNpc pNpc)
    {

        if (!m_rangeNpcList.Contains(pNpc))
        {
            //MyLog.LogError(this + ":: NpcEnterRange " + pNpc.Index);
            m_rangeNpcList.Add(pNpc);
        }

    }

    protected void RemoveRangeNpc(CBaseNpc pNpc)
    {
        if (m_rangeNpcList.Contains(pNpc))
        {
            //MyLog.LogError(this + ":: NpcLeaveRange " + pNpc.Index);
            m_rangeNpcList.Remove(pNpc);
        }
    }

    public List<CBaseNpc> GetRangeNpcList()
    {
        return m_rangeNpcList;
    }


    public Dictionary<uint, float> GetSkillCD()
    {
        Dictionary<uint, float> ret = new Dictionary<uint, float>();

        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            CInitiativeSkill pSkill = m_skillList[i];
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo != null)
            {
                ret.Add((uint)pSkillInfo.Key, pSkill.CD);
            }
        }

        return ret;
    }

    public bool IsSkillCD(uint uiSkillType, float fCD)
    {
        if (DefaultSkillID == uiSkillType)
        {
            if (m_DefaultSkill.CD == 0)
            {
                m_DefaultSkill.CD = fCD;
                return true;
            }
            return false;
        }
        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            CInitiativeSkill pSkill = m_skillList[i];
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo != null)
            {
                if (pSkillInfo.Key == uiSkillType)
                {
                    if (pSkill.CD == 0)
                    {
                        //pSkill.CD = fCD;             
                        return true;
                    }
                    break;
                }
            }
        }

        return false;
    }

    public virtual bool SetSkillCD(uint uiSkillType, float fCD)
    {
        if (DefaultSkillID == uiSkillType)
        {
            if (m_DefaultSkill.CD == 0)
            {
                m_DefaultSkill.CD = fCD;
                return true;
            }
            return false;
        }
        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            CInitiativeSkill pSkill = m_skillList[i];
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo != null)
            {
                if (pSkillInfo.Key == uiSkillType)
                {
                    if (pSkill.CD == 0)
                    {
                        pSkill.CD = fCD;

                        if (NpcSort == eNpcSort.Avatar)
                        {
                            SingletonObject<SkillBarMediator>.GetInst().SetSkillCD(uiSkillType, fCD);
                        }
                        return true;
                    }
                    break;
                }
            }
        }

        return false;
    }

    //获取技能升级的数据
    //bPassively 被动技能?
    public virtual CSkillupInfo GetSkillUpLoader(SkillContent pUserSkillLoader, bool bPassively)
    {
        if (null == pUserSkillLoader)
        {
            return null;
        }
        if (NpcSort == eNpcSort.Monster || NpcSort == eNpcSort.Pet)
        {
            return null;
        }
        CSkillupInfo skillupInfo = null;

        uint useSkillID = (uint)pUserSkillLoader.Key;

        //         if (bPassively)
        //         {
        //             for (int i = 0, count = m_passivelySkill.Count; i < count; ++i)
        //             {
        //                 CPassivelySkill pSkill = m_passivelySkill[i];
        //                 if (pSkill.TechID == useSkillID)
        //                 {
        //                     pSkillUpLoader = pSkill.SkillUpLoader;
        //                     break;
        //                 }
        //             }
        //         }
        //         else
        {
            //召唤物的技能根据 召唤者的技能等级来算
            if (NpcSort == eNpcSort.Ally)
                skillupInfo = (this as Monster).AllySkillupInfo;
            else
            {
                for (int i = 0, count = m_skillList.Count; i < count; ++i)
                {
                    CInitiativeSkill pSkill = m_skillList[i];
                    SkillContent pSkillInfo = pSkill.GetSkillInfo();

                    //首招ID
                    if (pUserSkillLoader.MultiSkillType == (byte)eMultiSkillType.SkillAtk)
                    {
                        useSkillID = (uint)pUserSkillLoader.FirstSkillID;
                    }

                    if (pSkillInfo != null)
                    {
                        if (pSkillInfo.Key == useSkillID)
                        {
                            //pSkillUpLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(pSkill.GetSkillUpID());
                            skillupInfo = pSkill.GetSkillUpInfo();
                            break;
                        }
                    }
                }
            }


        }
        //if ( null != pSkillUpLoader )
        {
            //MyLog.Log(" GetSkillupLoader : " + pSkillUpLoader.GetKey());
        }
        return skillupInfo;
    }


    public void AddSkill(uint uiSkillType, CSkillupInfo skillInfo, ushort wPos)
    {
        if (uiSkillType >= 10000000)//主动技能
        {
            SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillType);
            if (null == pSkillLoader) return;

            if (FindInitiativeSkill(uiSkillType) != null)
            {
                return;
            }
            CInitiativeSkill pSkill = new CInitiativeSkill(uiSkillType, skillInfo, wPos);

            if (pSkillLoader.SkillType == (byte)eSkillType.AttackType && m_DefaultSkill == null)
            {
                m_DefaultSkill = pSkill;
                m_uiCurrUseSkillType = pSkill.GetSkillID();
            }
            else
            {
                m_skillList.Add(pSkill);

                m_skillList.Sort(SkillCompare);
            }
        }
        else//被动技能
        {
            //             if (FindPassively(uiSkillType) != null)
            //             {
            //                 return;
            //             }
            //             CPassivelySkill pSkill = new CPassivelySkill(uiSkillType, uiSkillUpID);
            //             m_passivelySkill.Add(pSkill);
            //             //MyLog.Log(" uiSkillUpID : " + uiSkillUpID     
        }

    }

    public CInitiativeSkill FindInitiativeSkill(uint uiSkilType)
    {
        foreach (CInitiativeSkill pSkill in m_skillList)
        {
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo != null && pSkillInfo.Key == uiSkilType)
            {
                return pSkill;
            }
        }
        return null;
    }

    //     public CPassivelySkill FindPassively(uint uiSkillType)
    //     {
    //         foreach (CPassivelySkill pSkill in m_passivelySkill)
    //         {
    //             if (pSkill.TechID == uiSkillType)
    //             {
    //                 return pSkill;
    //             }
    //         }
    //         return null;
    //     }

    public void ClearSkill()
    {
        m_skillList.Clear();
        m_DefaultSkill = null;
    }

    private int SkillCompare(CInitiativeSkill a, CInitiativeSkill b)
    {
        SkillContent pAInfo = a.GetSkillInfo();
        SkillContent pBInfo = b.GetSkillInfo();

        if (pAInfo == null || pBInfo == null)
        {
            return 0;
        }

        byte APriority = pAInfo.Priority;
        byte BPriority = pBInfo.Priority;

        int result = 0;
        if (APriority > BPriority)
        {
            result = -1;
        }
        else if (APriority < BPriority)
        {
            result = 1;
        }

        return result;
    }

    public UseSkillInfo GetUseSkillInfo(SkillContent pSkillLoader)
    {
        Vector3 specifedPoint = Vector3.zero;
        Vector3 toward = Vector3.zero;

        switch ((eSkillRange)pSkillLoader.SkillRange)
        {
            case eSkillRange.RandomCircle:
                {
                    //在指定圆内 随机取一点
                    List<float> rangeArgs = pSkillLoader.RangeArgs;
                    if (rangeArgs.Count == 4)
                    {
                        float offset_foward = rangeArgs[0];
                        float offset_right = -rangeArgs[1];
                        float randomRadius = rangeArgs[2];

                        Transform npcTrans = GetTransform();
                        //圆心
                        Vector3 centerPos = npcTrans.position;
                        //偏移
                        centerPos += npcTrans.forward * offset_foward + npcTrans.right * offset_right;
                        //随机点(2D)
                        //UnityEngine.Random.seed = (int)System.DateTime.Now.Ticks;
                        Vector2 randomPos = UnityEngine.Random.insideUnitCircle * randomRadius;
                        //指定点
                        specifedPoint = new Vector3(centerPos.x + randomPos.x, centerPos.y, centerPos.z + randomPos.y);
                    }
                }
                break;
            case eSkillRange.TargetCircle:
                {
                    //取目标点的位置
                    if (null != CurrTarget && !CurrTarget.IsDead())
                    {
                        specifedPoint = CurrTarget.GetPosition();
                    }
                    else
                    {
                        CBaseNpc findNpc = FindNpcBySkill(pSkillLoader);
                        if (null != findNpc)
                        {
                            specifedPoint = findNpc.GetPosition();
                        }
                        else
                        {
                            specifedPoint = m_myTrans.position + m_myTrans.forward * 5;
                        }
                    }

                    //MyLog.Log(" specifedPoint : " + specifedPoint);
                }
                break;
            case eSkillRange.RandomRect:
                {
                    List<float> rangeArgs = pSkillLoader.RangeArgs;

                    if (rangeArgs.Count < 5)
                        break;

                    float radius = rangeArgs[0];
                    float minAngel = rangeArgs[1];
                    float maxAngel = rangeArgs[2];
                    float height = rangeArgs[3];
                    float width = rangeArgs[4];

                    //随机取一个中心点
                    Vector2 ranCircle = UnityEngine.Random.insideUnitCircle * radius;
                    specifedPoint = new Vector3(m_myTrans.position.x + ranCircle.x, m_myTrans.position.y, m_myTrans.position.z + ranCircle.y);

                    //随机取一个朝向
                    toward = (Quaternion.Euler(Vector3.up * UnityEngine.Random.Range(minAngel, maxAngel)) * m_myTrans.forward).normalized;

                    //                     GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    //                     cube.GetComponent<BoxCollider>().enabled = false;
                    //                     cube.transform.forward = toward;
                    //                     cube.transform.position = specifedPoint;
                    //                     cube.transform.localScale = new Vector3(width, 1f, height);

                }
                break;
            case eSkillRange.RandomPoint:
                {
                    List<float> rangeArgs = pSkillLoader.RangeArgs;

                    float offset_x = rangeArgs[1]; //左偏移
                    float offset_z = rangeArgs[2]; //前偏移
                    float radius = rangeArgs[3];   //随机半径    

                    if (CurrTarget != null)
                    {
                        Transform targetTrans = CurrTarget.GetPlayerTransform();
                        specifedPoint = targetTrans.position + m_myTrans.forward * offset_z + m_myTrans.right * (-offset_x);

                        if (radius != 0)
                        {
                            Vector2 randomPos = UnityEngine.Random.insideUnitCircle * radius;
                            specifedPoint += new Vector3(randomPos.x, 0f, randomPos.y);
                        }
                    }
                    else
                    {
                        specifedPoint = m_myTrans.position + m_myTrans.forward * 5f;
                    }
                    //specifedPoint = m_myTrans.forward * offset_z + m_myTrans.right * (-offset_x);
                }
                break;
            default:
                break;
        }

        UseSkillInfo info = null;

        if (specifedPoint != Vector3.zero)
            info = new UseSkillInfo(specifedPoint, toward);

        return info;
    }

    //通过技能判定范围找到离施法者最近的npc
    public CBaseNpc FindNpcBySkill(SkillContent pSkillLoader)
    {
        CBaseNpc findNpc = null;
        float curDistance = 100f;
        foreach (CBaseNpc pNpc in m_rangeNpcList)
        {
            if (AffectResult((eAffectType)pSkillLoader.AffectType, (eAffectEffect)pSkillLoader.AffectEffect, this, pNpc, eEffectRangeType.JudgeType, (eSkillAtkType)pSkillLoader.SkillAtkType))
            {
                if (IsInSkillRange(pSkillLoader, pNpc, eEffectRangeType.JudgeType, null))
                {
                    float distance = Common.Get2DVecter3Length(m_myTrans.position, pNpc.GetPosition());
                    if (distance < curDistance)
                    {
                        curDistance = distance;
                        findNpc = pNpc;
                    }
                }
            }
        }

        return findNpc;
    }

    //是否可以被打
    public bool CanBeAttacked()
    {
        if (this is Pet || this is SkillNpc || this.NpcSort == eNpcSort.Ally || this.NpcSort == eNpcSort.Pet || this.NpcSort == eNpcSort.SkillNpc)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    //当前是否能锁定目标
    public virtual bool CanLockTarget(List<CBaseNpc> targetList)
    {
        if (null != CurrTarget && !CurrTarget.IsDead() && !(this is Monster) && targetList.Contains(CurrTarget))
        {
            return false;
        }
        return true;
    }

    private void OnSkillcallback(uint skillLoaderKey)
    {
        if (SingletonObject<NewBieGuidMediator>.GetInst().isSkillCallBack)
        {
            if (this is Avatar)
            {
                SingletonObject<NewBieGuidMediator>.GetInst().OnSkillcallback(skillLoaderKey);
            }
        }
    }

    private void SetSkillTarget(SkillContent pSkillInfo, UseSkillCommandArg arg)
    {
        eSkillRange skillRange = (eSkillRange)pSkillInfo.SkillRange;
        if (skillRange != eSkillRange.FlyParticleSingle && skillRange != eSkillRange.FlyParticleAoe && skillRange != eSkillRange.RandomPoint)
        {
            if (arg.targetList != null && arg.targetList.Count > 0)
            {
                if (CanLockTarget(arg.targetList))
                {
                    //选择范围内的正前方的NPC为目标
                    float minAngle = 180;
                    for (int i = 0, count = arg.targetList.Count; i < count; ++i)
                    {
                        Vector3 targetposition = arg.targetList[i].GetPosition();
                        targetposition.y = m_myTrans.position.y;

                        float angle = Vector3.Angle(targetposition - m_myTrans.position, m_myTrans.forward);
                        if (angle < minAngle)
                        {
                            CurrTarget = arg.targetList[i];
                            minAngle = angle;
                        }
                    }
                }
            }
        }
        else
        {
            if (null != CurrTarget)
            {
                if (AffectResult((eAffectType)pSkillInfo.AffectType, (eAffectEffect)pSkillInfo.AffectEffect, this, CurrTarget, eEffectRangeType.JudgeType, (eSkillAtkType)pSkillInfo.SkillAtkType))
                {
                    return;
                }
            }

            //飞行技能 //找出离施法者最近的npc作为目标
            CBaseNpc target = null;
            float minDistance = pSkillInfo.JudgeArgs[1];
            foreach (var pNpc in m_rangeNpcList)
            {
                if (AffectResult((eAffectType)pSkillInfo.AffectType, (eAffectEffect)pSkillInfo.AffectEffect, this, pNpc, eEffectRangeType.JudgeType, (eSkillAtkType)pSkillInfo.SkillAtkType))
                {
                    if (IsInSkillRange(pSkillInfo, pNpc, eEffectRangeType.JudgeType))
                    {
                        float disatance = Common.GetHorizontalDis(m_myTrans.position, pNpc.GetPosition());
                        if (disatance < minDistance)
                        {
                            minDistance = disatance;
                        }
                        target = pNpc;
                    }
                }
            }

            CurrTarget = target;
        }

    }

    public bool CanUseSkill(UseSkillCommandArg arg)
    {
        //if (m_pBattleScene.IsGameOver())
        //{
        //    return eCommandReply.ICantDoThatYet;
        //}

        if (m_bStop)
        {
            return false;
        }

        if (null == m_myTrans)
        {
            return false;
        }

        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(arg.uSkillid);
        if (null == pSkillInfo)
        {
            return false;
        }

        if (GetCurrActState() == eActionState.Grab)
        {
            SkillContent preSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(arg.uSkillid - 1);
            if (null == preSkillLoader)
            {
                return false;
            }
            //如果上一个技能不是抓取技能 跳过
            if (preSkillLoader.SkillType != (byte)eSkillType.GrabType)
            {
                return false;
            }
        }

        if (IsStun() || IsFrost())
        {
            MyLog.LogError(" Can not UsesSkill ! the npc index" + m_uiIndex + " Stun ...");
            return false;
        }


        //判断技能CD
        float fCD = pSkillInfo.CD;
        if (fCD != 0 && !arg.bByScript && !(this is SkillNpc)) /*&& eSkillType != eSkillType.AttackType)*/
        {
            if (!this.IsSkillCD(arg.uSkillid, fCD))
            {
                return false;
            }
        }

        if (this is BaseBattlePlayer)
        {
            BaseBattlePlayer basePlayer = this as BaseBattlePlayer;
            //精力判断
            switch ((eCostType)pSkillInfo.CostType)
            {
                case eCostType.CostMp:
                    {
                        if (basePlayer.GetMp() < pSkillInfo.CostValue)
                            return false;

                        basePlayer.ResetMpTimer();

                    }
                    break;
                case eCostType.JudgeMp:
                    {
                        if (basePlayer.GetMp() < pSkillInfo.CostValue)
                            return false;
                    }
                    break;
            }
        }

        return true;
    }

    public virtual eCommandReply DoUseSkillEvent(UseSkillCommandArg arg)
    {
        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(arg.uSkillid);
        if (null == pSkillInfo)
        {
            return eCommandReply.ICantDoThatYet;
        }


        eSkillType skillType = (eSkillType)pSkillInfo.SkillType;

        if (this is BaseBattlePlayer)
        {
            BaseBattlePlayer basePlayer = this as BaseBattlePlayer;
            if ((eCostType)pSkillInfo.CostType == eCostType.CostMp)
            {
                basePlayer.AddMp(-pSkillInfo.CostValue);
            }
        }

        float fCD = pSkillInfo.CD;
        if (fCD != 0 && !arg.bByScript && !(this is SkillNpc))
        {
            SetSkillCD(arg.uSkillid, fCD);
        }

        //set target
        SetSkillTarget(pSkillInfo, arg);

        if (!(this is RealAvatar) || pSkillInfo.SkillType == (byte)eSkillType.AttackType)
        //if (NpcSort != eNpcSort.Avatar || pSkillInfo.SkillType == (byte)eSkillType.AttackType)
        {
            //看向目标
            if (CurrTarget != null)
            {
                Vector3 lookDirection = CurrTarget.GetPosition() - m_myTrans.position;
                lookDirection.y = 0;
                UpdateTurn(lookDirection, true);
            }
        }

        //if (!arg.bByScript)
        {
            switch (skillType)
            {
                case eSkillType.None:
                    break;
                case eSkillType.AttackType:
                    {
                        attackDone = false;
                        //attackID = DefaultSkillID;
                        attackID = arg.uSkillid;
                        EnterState(eActionState.Attack);
                    }
                    break;
                case eSkillType.SkillType:
                    {
                        CSkillState pSkillState = (CSkillState)m_stateMgr.GetState(eActionState.Skill);
                        if (pSkillState != null)
                        {
                            pSkillState.SetSkillInfo(pSkillInfo, OnSkillcallback);
                        }
                        EnterState(eActionState.Skill);
                    }
                    break;
                case eSkillType.HookType:
                    {
                        CHookState pHookState = (CHookState)m_stateMgr.GetState(eActionState.Hook);
                        if (null != pHookState)
                        {
                            pHookState.SetSkillLoader(pSkillInfo);
                        }
                        EnterState(eActionState.Hook);

                    }
                    break;
                case eSkillType.GrabType:
                    {
                        CGrabState pGrabState = (CGrabState)m_stateMgr.GetState(eActionState.Grab);
                        if (null != pGrabState)
                        {
                            pGrabState.SetSkillLoader(pSkillInfo);
                        }

                        EnterState(eActionState.Grab);
                    }
                    break;
                case eSkillType.CreateNpc:
                    {
                        //通过额外参数获取实体技能id,存在时间
                        uint skillID = MyConvert_Convert.ToUInt32(pSkillInfo.ExtraArgs[0]);
                        float removeTime = MyConvert_Convert.ToSingle(pSkillInfo.ExtraArgs[1]);
                        eSkillType enterType = (eSkillType)MyConvert_Convert.ToByte(pSkillInfo.ExtraArgs[2]);
                        eSkillNpcPos posType = (eSkillNpcPos)MyConvert_Convert.ToByte(pSkillInfo.ExtraArgs[3]);

                        if (enterType == eSkillType.AttackType)
                        {
                            // 进入攻击状态
                            attackDone = false;
                            attackID = arg.uSkillid;
                            EnterState(eActionState.Attack);
                        }
                        else
                        {
                            CSkillState pSkillState = (CSkillState)m_stateMgr.GetState(eActionState.Skill);
                            if (pSkillState != null)
                            {
                                pSkillState.SetSkillInfo(pSkillInfo, OnSkillcallback);
                            }
                            EnterState(eActionState.Skill);
                        }

                        AddSkillNpc(skillID, removeTime, posType, pSkillInfo);
                    }
                    break;
                case eSkillType.Charge:
                    {
                        CChargeState pChargeState = (CChargeState)m_stateMgr.GetState(eActionState.Charge);
                        if (null != pChargeState)
                        {
                            pChargeState.SetChargeInfo(pSkillInfo);
                        }

                        EnterState(eActionState.Charge);
                    }
                    break;

                case eSkillType.RandomMove:
                    {
                        CRanMoveState pRandomMove = (CRanMoveState)m_stateMgr.GetState(eActionState.RandomMove);
                        if (null != pRandomMove)
                        {
                            pRandomMove.SetRanMoveInfo(pSkillInfo);
                        }

                        EnterState(eActionState.RandomMove);
                    }
                    break;
            }
        }

        m_uiCurrUseSkillType = arg.uSkillid;

        //UseSkillInfo useSkillInfo = GetUseSkillInfo(pSkillInfo);

        //技能等级信息
        CSkillupInfo pSkillUpInfo = GetSkillUpLoader(pSkillInfo, false);
        //自身script
        List<int> selfScripts = pSkillInfo.SelfScripts;
        foreach (int uiScriptID in selfScripts)
        {
            ScriptManager.RequestScript((uint)uiScriptID, this, pSkillUpInfo, 0, (uint)pSkillInfo.Key);
        }

        ActionContent pActionInfo = HolderManager.m_ActionHolder.GetStaticInfo(pSkillInfo.AttackID);
        if (null != pActionInfo)
        {
            UseSkillInfo useSkillInfo = GetUseSkillInfo(pSkillInfo);
            DoAction(pActionInfo, this, pSkillInfo, eDoActionType.Normal, useSkillInfo);

            //在受击点计算命中和闪避,30帧一秒
            List<float> hitPointList = pActionInfo.BehitPointDelay;
            ePartnerState partnerState = ePartnerState.None;
            if (this is BaseBattlePlayer)
                partnerState = (this as BaseBattlePlayer).PartnerState;

            for (int i = 0, len = hitPointList.Count; i < len; i++)
            {
                float fBehitPointDelay = hitPointList[i];
                if (fBehitPointDelay != -1)
                {
                    float changeSpeed = skillType == eSkillType.AttackType ? m_pCard.fChangeAtkSpeed : 0f;
                    float speed = pActionInfo.Speed + changeSpeed;

                    fBehitPointDelay /= 30f; //30帧一秒                    
                    fBehitPointDelay /= speed;

                    object[] args = new object[5] { pSkillInfo, arg.bByScript, useSkillInfo, partnerState, arg.callback };

                    if (fBehitPointDelay > 0)
                    {
                        UnityCallBackManager.GetInst().AddCallBack(fBehitPointDelay, AttackResult, args);
                    }
                    else
                    {
                        AttackResult(args);
                    }

                    CSkillState pSkillState = GetCurrState() as CSkillState;
                    if (null != pSkillState)
                    {
                        pSkillState.SetIntervalArgs(args);
                    }
                }
            }

        }
        else
        {
            //MyLog.LogError(" action is null ");
        }

        //设置连招        
        uint uiNextSkillID = SkillManager.GetInst().GetRandomNextSkill(pSkillInfo);

        if (uiNextSkillID != 0)
        {
            if (pSkillInfo.MultiSkillType == (byte)eMultiSkillType.NormalAtk)
            {
                DefaultSkillID = uiNextSkillID;
            }
        }
        else
        {
            BreakNormalSkill(arg.uSkillid);
        }

        return eCommandReply.YesSir;
    }

    /// <summary>
    /// 使用技能
    /// </summary>
    /// <param name="arg"></param>
    /// <returns></returns>
    protected virtual eCommandReply DoUseSkill(UseSkillCommandArg arg)
    {
        if (!CanUseSkill(arg))
        {
            return eCommandReply.ICantDoThatYet;
        }

        return DoUseSkillEvent(arg);
    }


    #endregion

    #region 模型相关
    /// <summary>
    /// 变身
    /// </summary>
    /// <param name="uiNpcID"></param>
    public virtual void Shapeshift_before(uint uiNpcID)
    {
        Release(eObjectDestroyType.Memory);
    }

    public virtual void Shapeshift_after(uint uiNpcID, Vector3 position, Quaternion rotation)
    {
        if (m_myTrans != null)
        {
            InitNpc(uiNpcID, m_wLevel, position, rotation);
        }

        //AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        CreateHpComponent();

        if (SingletonObject<BattleInfoMediator>.GetInst().m_uiBossId == uiNpcID)
        {
            SingletonObject<BattleInfoMediator>.GetInst().NpcValue(1.0f);
        }
    }

    /// <summary>
    /// 切换模型
    /// </summary>
    /// <param name="model"></param>
    /// <param name="anim"></param>
    public virtual void ChangeModel(CObject model, CAnimator anim)
    {
        AddMaterials();

        m_pNpcObj = model;

        m_pAnimator = anim;

        //把原资源还原
        if (m_characterController != null)
        {
            m_characterController.height = m_fOrigionBodyHeight;
            m_characterController.center = new Vector3(m_characterController.center.x, m_characterController.height / 2.0f, m_characterController.center.z);
        }

        InitModel(model.gameCObject);

        AddRangeTrigger();


    }
    #endregion

    #region 移动相关

    public bool IsInGround
    {
        set
        {
            if (m_bInGround == value)
            {
                return;
            }
            m_bInGround = value;
        }
        get
        {
            return m_bInGround;
        }
    }

    private void FollowTarget()
    {
        if (m_followTrans != null)
        {
			m_destPosition = Common.NavSamplePosition(m_followTrans.position);
            m_lastMovePosition = Vector3.zero;
        }
    }

    /// <summary>
    ///  移动
    /// </summary>
    /// <param name="fHorizontalSpeed">水平方向每帧改变的高度</param>
    /// <param name="bForceCharacterMove">Move是否强制使用Character.simpleMove,默认是false,动作带位移,部分情况可能会启用</param>
    /// <param name="bMovingTurn">是否需要在移动中转向</param>
    public virtual void Move(float fHorizontalSpeed, bool bForceCharacterMove = false, bool bMovingTurn = true, float fAngel = 0f)
    {
        CBaseState currState = m_stateMgr.GetCurrState();
        if (null == currState)
        {
            return;
        }

        eActionState state = currState.GetState();
        Vector3 myPosition = GetPosition();

        Vector3 lookDirection = Vector3.zero;

        switch (state)
        {
            case eActionState.Idle:
            case eActionState.Wait:
                {
                    if (NpcSort == eNpcSort.Monster && !CBaseStory.IsInGameStory)
                    {
                        FollowTarget();

                        if (CurrTarget != null && !m_sTag.Equals(DEFINE.CARRIAGE_OBJECT_TAG))
                        {
                            lookDirection = CurrTarget.GetPosition() - myPosition;
                            lookDirection.y = 0;
                            UpdateTurn(lookDirection, false); //look at despostion
                        }
                    }

                    SimpleMove(Vector3.zero, 0);
                }
                break;
            case eActionState.Birth:
            case eActionState.EndFly:
            case eActionState.BeginRide:
            case eActionState.UnBirth:
            case eActionState.Dead:
                {
                    SimpleMove(Vector3.zero, 0);
                }
                break;
            case eActionState.Turning:
                {
                    if (bMovingTurn)
                    {
                        lookDirection = m_destPosition - myPosition;
                        lookDirection.y = 0;
                        UpdateTurn(lookDirection, false);
                    }
                }
                break;
            case eActionState.Walk:
            case eActionState.Run:
            case eActionState.BossRamble:
            case eActionState.Attack:
            case eActionState.PetBeginFly:
            case eActionState.Scaunter:
            case eActionState.RideJump:
            case eActionState.BeginFly:
                {
                    FollowTarget();

                    float distance = Common.Get2DVecter3Length(m_destPosition, myPosition);

                    if (m_moveTimer.IsExpired(true) && this is RealAvatar)
                    {
                        //每秒移动距离小于0.1f,视为被卡住了
                        if (Common.Get2DVecter3Length(myPosition, m_lastMovePosition) < 0.1f)
                        {
                            distance = 0;
                        }
                        m_lastMovePosition = myPosition;
                    }

                    float percent = 1 - m_fDeceleratePercent / 100.0f;
                    float sp = fHorizontalSpeed * percent;

                    SetMoveActionSpeed(sp);

                    //1米以上是跑步
                    float compare = 0.5f;                    
                    if (distance > compare && sp > 0)
                    {
                        float deltaTime = Time.deltaTime;
                        if (m_bUsePathFinding && m_nma != null && m_nma.gameObject.activeInHierarchy)
                        {
                            if (UnitsType == eNpcUnitsType.Ground)
                            {
                                m_followObj.transform.position = myPosition + m_myTrans.forward * 0.01f;
                            }
                            else
                            {
                                m_followObj.transform.position = Common.NavSamplePosition(myPosition + m_myTrans.forward * 0.01f);
                            }

                            SetNavmeshEnable(true);
                            if (m_nma.enabled)
                            {
                                m_nma.CalculatePath(m_destPosition, m_nmp);
                            }

                            if (m_nmp.corners.Length >= 2)
                            {
                                lookDirection = m_nmp.corners[1] - m_nmp.corners[0];
                                lookDirection.y = 0;
                            }
                            else
                            {
                                lookDirection = m_destPosition - myPosition;
                                lookDirection.y = 0;
                            }
                           
                        }
                        else
                        {
                            lookDirection = m_destPosition - myPosition;
                            lookDirection.y = 0;
                        }

                        if (fAngel != 0)
                        {
                            lookDirection = Quaternion.Euler(Vector3.up * fAngel) * lookDirection;
                        }


                        if (!m_bApplyRootMotion || bForceCharacterMove)
                        {
                            SimpleMove(lookDirection, sp);
                        }

                        if (bMovingTurn)
                        {
                            UpdateTurn(lookDirection, false);
                        }
                    }
                    else
                    {
                        if (state == eActionState.Walk || state == eActionState.Run)
                        {
                            if (NpcSort != eNpcSort.Pet)
                            {
                                LeaveState(state);
                            }
                        }
                    }

                }
                break;
            default:
                {
                    //test...
                    //bMovingTurn = false;

                    FollowTarget();

                    lookDirection = m_destPosition - myPosition;
                    lookDirection.y = 0;

                    if (bForceCharacterMove)
                    {
                        SimpleMove(lookDirection, fHorizontalSpeed);
                    }

                    if (bMovingTurn)
                    {
                        UpdateTurn(lookDirection, false);
                    }
                }
                break;
        }
    }

    public void MoveToPosition(Vector3 position, Vector3 forward)
    {
        if (m_myTrans != null)
        {
            EnterState(eActionState.Idle);
            m_myTrans.position = position;
            UpdateTurn(forward, true, true);
        }
    }

    public virtual void SetNavmeshObstacleEnable(bool enable)
    {
        //         if (!m_bUsePathFinding)
        //         {
        //             return;
        //         }
        if (m_nmo != null) m_nmo.enabled = enable;
        if (m_nma != null) m_nma.enabled = !enable;

        if (enable && m_followObj != null)
        {
            m_followObj.transform.localPosition = Vector3.zero;
        }
    }

    public virtual void SetNavmeshEnable(bool enable)
    {
        //         if (!m_bUsePathFinding)
        //         {
        //             return;
        //         }
        if (m_nmo != null && enable) m_nmo.enabled = !enable;
        if (m_nma != null) m_nma.enabled = enable;
    }

    //设置碰撞器,主角使用charactercontroll,怪物使用rigidbody
    protected void SetCollider(CharacterController collider, float hpHeightOffset = 0, bool bInit = true)
    {
        m_characterController = collider;
        m_ColliderRadius = collider.radius;
        m_ColliderHeight = collider.height;

        if (m_nma != null)
        {
            m_nma.radius = 0.8f;
            m_nma.height = m_ColliderHeight;
        }

        if (m_nmo != null)
        {
            m_nmo.radius = collider.radius / 2.0f + 0.1f;//和传统意义的半径不一样,正方形
            m_nmo.height = collider.height;
        }

        m_characterController.stepOffset = 0.3f;
        m_characterController.slopeLimit = CurrBattleScene.BattleType == eBattleType.MultiPve ? 90f: 45f;

        if (bInit)
        {
            m_fOrigionBodyHeight = (m_characterController.height > m_characterController.radius * 2 ? m_characterController.height : m_characterController.radius * 2);
            //MyLog.LogError(" m_fOrigionBodyHeight : " + m_fOrigionBodyHeight + " index : " + Index + " hpHeightOffset : " + hpHeightOffset);
            if (m_characterController.height < 6f)
            {
                m_characterController.height = 6f;
                m_characterController.center = new Vector3(m_characterController.center.x, 3.03f, m_characterController.center.z);
            }
        }


        //确保盒子与地面接触的点高于角色Y轴高度
        if (m_characterController.height / 2 > m_characterController.center.y)
        {
            //在地下,拉高
            m_characterController.center = Vector3.up * (m_characterController.height / 2 + 0.03f);
        }

        //尽可能避免与友军的碰撞
        if (NpcSortType == eNpcSortType.Ally)
        {
            m_characterController.radius = 0f;
        }

    }

    //空气墙防穿参数
    public float GetGoThroughPartialExtent()
    {
        if (null == m_characterController)
        {
            return 0;
        }
        float minimumExtent = Mathf.Min(Mathf.Min(m_characterController.bounds.extents.x, m_characterController.bounds.extents.y), m_characterController.bounds.extents.z);
        return minimumExtent * (1.0f - 0.1f) + 1f;
    }

    //public abstract void SimpleMove(Vector3 dir, float speed);
    public virtual void SimpleMove(Vector3 dir, float speed)
    {

    }


    //判断是否穿过空气墙
    private void CheckGoThroughAirWall()
    {
        if (null == m_stateMgr)
        {
            return;
        }
        if (NpcSort == eNpcSort.Pet || CBaseStory.IsInGameStory)
        {
            return;
        }
        eActionState currState = m_stateMgr.GetCurrActState();

        if (currState == eActionState.Idle || currState == eActionState.SwitchPartner)
        {
            return;
        }
        if (IsBeGrab)
        {
            return;
        }
        Vector3 currPosition = GetPosition();

        if (m_lastUpdatePosition == Vector3.zero)
        {
            m_lastUpdatePosition = currPosition;
        }
        else
        {
            //check for obstructions we might have missed 
            CheckGoThrough(currPosition, m_lastUpdatePosition);
            m_lastUpdatePosition = GetPosition();
        }


    }

    private void CheckGoThrough(Vector3 currPosition, Vector3 checkPosition)
    {
        RaycastHit hitInfo;
        Vector3 movementThisStep = currPosition - checkPosition;
        movementThisStep.y = 0;
        float movementSqrMagnitude = movementThisStep.sqrMagnitude;
        float movementMagnitude = Mathf.Sqrt(movementSqrMagnitude);

        Vector3 offset = Vector3.up * 2;//用来填充空气墙脚和玩家位置差异过小
        if (Physics.Raycast(checkPosition + offset, movementThisStep, out hitInfo, movementMagnitude, 1 << DEFINE.AIR_WALL))
        {
            SetPosition(hitInfo.point - offset - (movementThisStep / movementMagnitude) * GetGoThroughPartialExtent());
        }
    }

    /// <summary>
    /// 快跑吧，小姑娘！快跑！！！
    /// </summary>
    /// <param name="arg"></param>
    protected virtual eCommandReply DoRunto(RunToCommandArg arg)
    {
        if (this is Avatar || this is OnlineAvatar)
        {
            //Debug.Log(" DoRunto : " + this);
        }

        eCommandReply reply = eCommandReply.ICantDoThatYet;

        RunToCommandArg mtarg = arg as RunToCommandArg;
        Vector3 position = Vector3.zero;

        //PVP不允许寻路
        //bool usePathFinding = BattleScene.BattleType == eBattleType.Pvp ? false : mtarg.bUsePathFinding;
        bool usePathFinding = arg.bUsePathFinding;
        EnablePathFinding(usePathFinding);
        if (m_unitsType == eNpcUnitsType.Ground)
        {
            if (usePathFinding)
            {
                position = Common.NavSamplePosition(mtarg.dstPosition);

                SetNavmeshEnable(true);
                if (null != m_nma && null != m_nmp)
                {
                    m_nma.CalculatePath(position, m_nmp);
                }

                if (null != m_nmp && m_nmp.status != NavMeshPathStatus.PathPartial)//能移动到该点
                {
                    SetDestPosition(position, true);
                    CurrTarget = null;

                    if (GetCurrActState() != eActionState.Run)
                    {
                        EnterState(eActionState.Run);
                        reply = eCommandReply.YesSir;
                    }
                }
            }
            else
            {
                position = mtarg.dstPosition;
                SetDestPosition(position, false);
                CurrTarget = null;
                EnterState(eActionState.Run);
                reply = eCommandReply.YesSir;
            }

        }
        else if (m_unitsType == eNpcUnitsType.Air)
        {
            position = mtarg.dstPosition;
            SetDestPosition(position, usePathFinding);
            CurrTarget = null;
            EnterState(eActionState.Run);
            reply = eCommandReply.YesSir;
        }


        if (mtarg.bDirectionTurn)
        {
            Vector3 lookDirection = position;
            if (null != m_myTrans)
            {
                lookDirection -= m_myTrans.position;
            }

            lookDirection.y = 0;
            UpdateTurn(lookDirection, true);
        }

        return reply;
    }

    protected eCommandReply DoTurning(TurningCommandArg arg)
    {
        eCommandReply reply = eCommandReply.ICantDoThatYet;
        TurningCommandArg mtarg = arg as TurningCommandArg;

        SetDestPosition(mtarg.dstPosition, false);

        if (m_followObj != null)
        {
            m_followObj.transform.localPosition = Vector3.zero;
        }


        if (GetCurrActState() != eActionState.Turning)
        {
            EnterState(eActionState.Turning);
            reply = eCommandReply.YesSir;
        }
        return reply;
    }
    #endregion

    public void AddSkillNpc(uint createSkillID, float removeTime, eSkillNpcPos posType, SkillContent pSkillContent)
    {
        if (null == pSkillContent)
        {
            return;
        }
        Vector3 pos = Vector3.zero; ;
        if (posType == eSkillNpcPos.PartnerPos)
        {
            pos = m_myTrans.position;
        }
        else if (posType == eSkillNpcPos.TargetPos)
        {
            //没有目标默认5米
            if (null == CurrTarget)
            {
                CBaseNpc findNpc = FindNpcBySkill(pSkillContent);
                if (null == findNpc)
                {
                    pos = m_myTrans.position + m_myTrans.forward * 5f;
                }
                else
                {
                    pos = findNpc.GetPosition();
                }
            }
            else
            {
                pos = CurrTarget.GetPosition();
            }
        }

        uint index = CreateSkillNpc(createSkillID, pos);
        removeTime += 60f;
        UnityCallBackManager.GetInst().AddCallBack(removeTime, RemoveSkillNpc, new object[] { index });
    }

    /// <summary>
    /// 创建技能实体npc
    /// </summary>
    private uint CreateSkillNpc(uint skillId, Vector3 pos, string path = "")
    {
        uint nIndex = m_pBattleScene.GetEmptyIndex();
        SkillNpc skillnpc = new SkillNpc(this, skillId);
        skillnpc.Path = path;
        skillnpc.Init(m_pBattleScene, nIndex, m_uiNpcType, m_wLevel, eNpcSort.SkillNpc, pos, m_myTrans.rotation, DEFINE.UNTAGGED_OBJECT_TAG);

        m_pBattleScene.AddNpc(skillnpc);

        skillnpc.CurrTarget = CurrTarget;

        return nIndex;
    }

    /// <summary>
    /// 删除技能实体npc
    /// </summary>
    /// <param name="args"></param>
    private void RemoveSkillNpc(params object[] args)
    {
        m_pBattleScene.RemoveNpc((uint)args[0]);
    }

    /// <summary>
    /// 命令NPC干坏事
    /// </summary>
    /// <param name="command"></param>
    /// <param name="arg"></param>
    public virtual eCommandReply Command(eCommandType command, CommandArg arg)
    {
        eCommandReply reply = eCommandReply.ICantDoThatYet;

        switch (command)
        {
            case eCommandType.RunTo:
                if (arg is RunToCommandArg)
                {
                    reply = DoRunto(arg as RunToCommandArg);
                }
                break;
            case eCommandType.Turning:
                {
                    reply = DoTurning(arg as TurningCommandArg);
                }
                break;
            case eCommandType.UseSkill:
                if (arg is UseSkillCommandArg)
                {
                    reply = DoUseSkill(arg as UseSkillCommandArg);
                }
                break;
            default:
                reply = eCommandReply.ICantDoThatYet;
                break;
        }

        return reply;
    }

    public void UseSkillNotHit(uint skillID)
    {
        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(skillID);
        if (null == pSkillInfo)
        {
            MyLog.LogError("CMonsterSkillStory cam not find skill ID : " + skillID.ToString());
            return;
        }

        pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(skillID);
        if (pSkillInfo == null)
        {
            MyLog.LogError("CMonsterSkillStory cam not find skill ID : " + skillID.ToString());
            return;
        }

        uint m_attackID = (uint)pSkillInfo.AttackID;

        ActionContent pActionInfo = HolderManager.m_ActionHolder.GetStaticInfo(m_attackID);
        if (pActionInfo == null)
        {
            MyLog.LogError("CMonsterSkillStory cam not find Action ID : " + m_attackID.ToString());
            return;
        }

        string actionName = pActionInfo.ActionName;
        PlayAction(actionName, 1, true);
        uint soundID = (uint)Common.GetSounds(pActionInfo)[0];
        CreateSound(soundID);

        ////镜头
        //List<uint> cameraEffectList = pActionInfo.GetSelfCameraIDs();
        //for (int i = 0, count = cameraEffectList.Count; i < count; ++i)
        //{
        //    CCamera.GetInst().SetCameraEffect(cameraEffectList[i], null);
        //}

        List<int> effectList = Common.GetPlayEffects(pActionInfo);
        //特效
        if (effectList.Count > 0)
        {
            for (int i = 0; i < effectList.Count; ++i)
            {
                CreateParticle((uint)effectList[i]);
            }
        }

        //技能等级信息
        CSkillupInfo pSkillUpLoader = GetSkillUpLoader(pSkillInfo, false);
        //自身script
        List<int> selfScripts = pSkillInfo.SelfScripts;
        foreach (uint uiScriptID in selfScripts)
        {
            ScriptManager.RequestScript(uiScriptID, this, pSkillUpLoader);
        }

        float skillCD = pSkillInfo.LastTime;
        if (skillCD <= 0)
            return;
        List<int> nextSkillIDList = pSkillInfo.NextSkill;
        if (nextSkillIDList == null || nextSkillIDList.Count <= 0)
            return;

        uint nextSkillID = (uint)nextSkillIDList[0];

        if (nextSkillID <= 0)
            return;

        UnityCallBackManager.GetInst().AddCallBack(skillCD, NextSkillNotHit, new object[] { nextSkillID });
    }

    private void NextSkillNotHit(params object[] args)
    {
        uint nextSkill = (uint)args[0];
        if (nextSkill != 0)
            UseSkillNotHit(nextSkill);
    }

    public virtual uint PlayBirthAction(uint actID)
    {
        return 0;
    }

    public void ShowWeapon(bool active)
    {
        if (!IsBoss())
        {
            if (!m_pBattleScene.HideNpc != active)
                return;
        }
        if (m_leftWeapon)
            m_leftWeapon.renderer.enabled = active;
        if (m_rightWeapon)
            m_rightWeapon.renderer.enabled = active;

    }

    protected void InitMaterials(List<Material> mats)
    {
        m_materiaslCount = mats.Count;
        m_materials = new Material[m_materiaslCount];
        mats.CopyTo(m_materials);
        if (m_materiaslCount > 0)
            m_material0Name = m_materials[0].shader.name;
    }

    private void PlayTrailParticle(TrailManange trail, ParticleContent info)
    {
        if (trail == null)
            return;
        trail.DelayTime = info.DelayTime;
        trail.ContinueTime = info.LastTime;

        trail.SpecialMat = DynamicShader.GetMaterials(info.Path);

        trail.enabled = true;
        if ((int)trail.StartOption == 0)
            trail.StartTrail();
    }

    protected void RemoveFadeCallback()
    {
        UnityCallBackManager.GetInst().RemoveCallBack(m_fadeOffCallbackIndex);
        UnityCallBackManager.GetInst().RemoveCallBack(m_fadeOnCallbackIndex);
    }


    protected void DullKnife(float dullTime, float dullValue, bool shakeCamera, CBaseNpc[] npcList)
    {
        if (npcList != null)
        {
            int count = npcList.Length;
            for (int i = 0; i < count; i++)
            {
                if (npcList[i].IsDead())
                    continue;

                if (npcList[i] != null)
                    npcList[i].SetDull(dullValue);
            }
        }

        SetDull(dullValue);
        UnityCallBackManager.GetInst().AddCallBack(dullTime, DullKnifeCallback, npcList);
        if (shakeCamera)
            CCamera.GetInst().SetCameraEffect(DEFINE.HIT_RESULT_SHAKE, null, null);
    }

    public void SetDull(float dullValue)
    {
        if (m_npcGroup == eNpcGroup.Justice)
            Common.CopyTimeScale = dullValue;

        if (this is SkillNpc)
        {
            CBaseNpc parentNpc = (this as SkillNpc).ParentNpc;

            if (parentNpc != null && parentNpc.GetCAnimator() != null)
                parentNpc.GetCAnimator().Speed = parentNpc.GetCAnimator().OriginalSpeed * dullValue;
        }
        else
        {
            if (m_pAnimator != null)
                m_pAnimator.Speed = m_pAnimator.OriginalSpeed * dullValue;
        }
    }

    private void DullKnifeCallback(params object[] args)
    {
        if (args == null)
            return;

        int count = args.Length;
        CBaseNpc curNpc;
        for (int i = 0; i < count; i++)
        {
            curNpc = args[i] as CBaseNpc;
            if (curNpc.IsDead())
                continue;

            curNpc.SetDull(1);
        }

        SetDull(1f);
    }

    public void ChangeSkinMeshRenderMaterialToCommon(Material material)
    {
        if (m_npcSort != eNpcSort.Mechanism)
        {
            if (m_smr != null && m_smr.Length > 0)
            {
                for (int i = 0; i < m_smr.Length; i++)
                {
                    if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    {
                        m_smr[i].sharedMaterial = material;
                        Materials = m_smr[i].sharedMaterials;
                        break;
                    }
                }
            }
        }
    }

    public void ChangeWeaponMaterialToCommon(Material material)
    {
        ChangeLeftWeaponMaterialToCommon(material);
        ChangeRightWeaponMaterialToCommon(material);
    }

    protected void ChangeLeftWeaponMaterialToCommon(Material material)
    {
        if (m_leftWeapon)
        {
            m_leftWeapon.renderer.sharedMaterial = material;
            m_materialLeft = material;
        }
    }

    protected void ChangeRightWeaponMaterialToCommon(Material material)
    {
        if (m_rightWeapon)
        {
            m_rightWeapon.renderer.sharedMaterial = material;
            m_materialRight = material;
        }
    }

    public void ResetTirrgerObject()
    {
        if (m_sphereColliderTirrgerObject != null)
            m_sphereColliderTirrgerObject.radius = 0.1f;
    }

    public void SetTirrgerObject(float radius)
    {
        if (m_sphereColliderTirrgerObject != null)
            m_sphereColliderTirrgerObject.radius = radius;
    }

    public eNpcSortType NpcSortType { get { return GetNpcSortType(); } }
    public abstract eNpcSortType GetNpcSortType();
    public abstract List<float> GetAniMoveSpeed();
    public abstract float GetMaxMoveSpeed();
    public abstract bool IsKill();
    public abstract bool IsHitDown();
    public abstract bool IsBeatFly();
    public abstract bool IsCanStun();
    public abstract bool IsSlow();
    public abstract int GetDeadActID();
    public abstract float GetRigidity();
    public abstract string GetName();
}