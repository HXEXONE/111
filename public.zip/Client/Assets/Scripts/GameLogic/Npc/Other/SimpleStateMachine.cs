﻿using System.Collections.Generic;

public delegate void PlayerModelStateEvent();

public class SimpleStateMachine
{
    private Dictionary<System.Enum, PlayerModelStateEvent> m_enterEvents = new Dictionary<System.Enum, PlayerModelStateEvent>();
    private Dictionary<System.Enum, PlayerModelStateEvent> m_updateEvents = new Dictionary<System.Enum, PlayerModelStateEvent>();
    private Dictionary<System.Enum, PlayerModelStateEvent> m_exitsEvents = new Dictionary<System.Enum, PlayerModelStateEvent>();

    private System.Enum m_currentState = null;

    public void AddEnterEvent(System.Enum type, PlayerModelStateEvent eve)
    {
        if (m_enterEvents.ContainsKey(type))
        {
            DebugMSG("PlayerModelStateMachine AddEnterEvent has PlayerModelStateEvent Type = " + type.ToString(), msgType.Error);
            return;
        }
        if (eve == null)
        {
            DebugMSG("PlayerModelStateMachine AddEnterEvent PlayerModelStateEvent is null Type = " + type.ToString(), msgType.Error);
            return;
        }
        m_enterEvents.Add(type, eve);
    }

    public void AddExitsEvent(System.Enum type, PlayerModelStateEvent eve)
    {
        if (m_exitsEvents.ContainsKey(type))
        {
            DebugMSG("PlayerModelStateMachine AddExitsEvent has PlayerModelStateEvent Type = " + type.ToString(), msgType.Error);
            return;
        }
        if (eve == null)
        {
            DebugMSG("PlayerModelStateMachine AddExitsEvent PlayerModelStateEvent is null Type = " + type.ToString(), msgType.Error);
            return;
        }
        m_exitsEvents.Add(type, eve);
    }

    public void AddUpdateEvent(System.Enum type, PlayerModelStateEvent eve)
    {
        if (m_updateEvents.ContainsKey(type))
        {
            DebugMSG("PlayerModelStateMachine AddUpdateEnent has PlayerModelStateEvent Type = " + type.ToString(), msgType.Error);
            return;
        }
        if (eve == null)
        {
            DebugMSG("PlayerModelStateMachine AddUpdateEnent PlayerModelStateEvent is null Type = " + type.ToString(), msgType.Error);
            return;
        }
        m_updateEvents.Add(type, eve);
    }

    public void ChangeToState(System.Enum type)
    {
        if (type == m_currentState)
            return;
        if (m_currentState != null)
            ExitsCurrentState();
        EnterCurrentState(type);
    }

    public void EnterCurrentState(System.Enum type)
    {
        if (!m_enterEvents.ContainsKey(type))
        {
            DebugMSG("PlayerModelStateMachine ChangeToState not ContainsKey : " + type.ToString(), msgType.Error);
            return;
        }

        m_currentState = type;
        m_enterEvents[type]();
    }

    public void ExitsCurrentState()
    {
        if (m_exitsEvents.ContainsKey(m_currentState))
        {
            m_exitsEvents[m_currentState]();
            m_currentState = null;
        }
    }

    public void Update()
    {
        if (m_currentState != null && m_updateEvents.ContainsKey(m_currentState))
        {
            m_updateEvents[m_currentState]();
        }
    }

    public void Release()
    {
        Stop();
        m_enterEvents.Clear();
        m_exitsEvents.Clear();
    }

    public void Stop()
    {
        if (m_currentState != null && m_exitsEvents.ContainsKey(m_currentState))
        {
            m_exitsEvents[m_currentState]();
        }
        m_currentState = null;
    }

    public System.Enum GetCurrentState()
    {
        return m_currentState;
    }

    enum msgType
    {
        Log, Warm, Error,
    }
    private void DebugMSG(object msg, msgType type)
    {
        switch (type)
        {
            case msgType.Log: MyLog.Log(msg); break;
            case msgType.Warm: MyLog.LogWarning(msg); break;
            case msgType.Error: MyLog.LogError(msg); break;
            default: MyLog.Log(msg); break;
        }
    }
}
