﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HomeMonsterWithoutGravity : BaseHomeMonster
{

    protected enum eHomeMonsterState
    {
        Idle,
        Run,
        Turn,
    }

    private Vector3 m_destinationPosition;
    private Vector3 m_oringinPosition;

    private float m_moveSpeed = 7f;
    private float m_time;
    private float m_accumulativeTime;
    private float m_length;

    private Collider[] m_colliders = null;
    private Rigidbody[] m_rigidbodys = null;
    private MonoBehaviour[] m_monobehaviours = null;
    private Joint[] m_joints = null;

    private NavMeshAgent m_navMeshAgent;
    private Renderer m_shadowRender;

    #region 创建和销毁
    public HomeMonsterWithoutGravity(uint index, uint monterModelID, Vector3 position, Quaternion rotation, float size) :
        base(index, monterModelID, position, rotation, size)
    {
        Load();
    }
    #endregion

    public override void Update()
    {
        base.Update();
    }

    public override void Release()
    {
        //必须在资源回收前还原
        if (null != m_transform)
        {
            ComponentSetActive(m_transform.gameObject, true);
        }
        base.Release();
        m_destinationPosition = Vector3.zero;
        m_colliders = null;
        m_rigidbodys = null;
        m_monobehaviours = null;
        m_joints = null;

        m_navMeshAgent = null;
        m_shadowRender = null;
    }

    private void ComponentSetActive(GameObject o, bool active)
    {
        ComponentSetAble<Joint>(o, active, ref m_joints);
        ComponentSetAble<Collider>(o, active, ref m_colliders);
        ComponentSetAble<Rigidbody>(o, active, ref m_rigidbodys);
        ComponentSetAble<MonoBehaviour>(o, active, ref m_monobehaviours);

        if (m_navMeshAgent != null)
            m_navMeshAgent.enabled = active;

        if (m_shadowRender != null)
            m_shadowRender.enabled = active;
    }

    private void ComponentSetAble<T>(GameObject o,bool able,ref T[] components) where T : Component
    {
        int count = 0;
        if (components == null)
            components = o.GetComponentsInChildren<T>();
        if(components != null)
            count = components.Length;

        if(count > 0)
        {
            System.Type type;
            System.Reflection.PropertyInfo info;
            for (int i = 0; i < count; i++)
            {
                if (components[i] != null)
                {
                    type = components[i].GetType();
                    info = type.GetProperty("enabled");
                    if (info != null)
                        info.SetValue(components[i], able, null);
                }
            }
        }
    }

    #region Initialization
    protected override void onInitialise()
    {
        RegisterStateEvent();
        InitAnimationDictionary();
    }

    private void RegisterStateEvent()
    {
        RegistEnterEvent(eHomeMonsterState.Idle, onIdleEnter);
        RegistUpdateEvent(eHomeMonsterState.Idle, onIdleUpdate);
        RegistExitsEvent(eHomeMonsterState.Idle, onIdleExits);

        RegistEnterEvent(eHomeMonsterState.Run, onRunEnter);
        RegistUpdateEvent(eHomeMonsterState.Run, onRunUpdate);
        RegistExitsEvent(eHomeMonsterState.Run, onRunExits);

        RegistEnterEvent(eHomeMonsterState.Turn, onTurnEnter);
        RegistUpdateEvent(eHomeMonsterState.Turn, onTurnUpdate);
        RegistExitsEvent(eHomeMonsterState.Turn, onTurnExits);
    }

    private void InitAnimationDictionary()
    {
        AddAnimationDictionary(eHomeMonsterState.Idle, "idle");
        AddAnimationDictionary(eHomeMonsterState.Run, "run");
        AddAnimationDictionary(eHomeMonsterState.Turn, "walk");
    }
    #endregion

    #region Loading Model
    protected override void LoadModelCompleted(GameObject o, params object[] args)
    {
        base.LoadModelCompleted(o, args);
        if (null == o)
        {
            return;
        }
        m_navMeshAgent = o.GetComponent<NavMeshAgent>();
        if (null != m_navMeshAgent)
        {
            m_navMeshAgent.enabled = false;
        }

        Transform followTrans = o.transform.Find("FollowObject");
        if (followTrans != null)
        {
            NavMeshAgent nma = followTrans.GetComponent<NavMeshAgent>();
            if (nma != null) nma.enabled = false;
        }

        Transform shadow = o.transform.FindChild("shadow");
        if (ClientMain.IsSupportShadowRunTime)
        {
            if (shadow)
            {
                Object.Destroy(shadow.gameObject);
            }
        }
        else
        {
            if (shadow)
            {
                shadow.transform.localPosition = Vector3.zero;
                m_shadowRender = shadow.renderer;
                m_shadowRender.enabled = false;
            }
        }

        ComponentSetActive(o, false);

        ChangeToIdelState();
    }
    #endregion

    #region State Change

    public float GetDistance(Vector3 position)
    {
        return Vector3.Distance(m_transform.position, position);
    }

    public override void MoveTo(Vector3 position, float speed = 7)
    {
        if (!m_loadCompleted)
            return;
        m_oringinPosition = m_transform.position;
        m_destinationPosition = position;
        m_moveSpeed = speed;
        m_length = Vector3.Distance(m_oringinPosition, m_destinationPosition);
        if (m_length < 1)
            return;
        ChangeState(eHomeMonsterState.Run);
    }

    public override void ChangeToIdelState()
    {
        if (!m_loadCompleted)
            return;
        ChangeState(eHomeMonsterState.Idle);
    }

    public override void ChangeToTurnState()
    {
        if (!m_loadCompleted)
            return;
        ChangeState(eHomeMonsterState.Turn);
    }
    #endregion

    #region StateEvent
    void onIdleEnter()
    {
    }

    void onIdleUpdate()
    {
        if (m_animator != null)
            m_animator.Update();
    }

    void onIdleExits()
    {
    }

    void onRunEnter()
    {
        m_time = m_length / m_moveSpeed;
    }

    void onRunUpdate()
    {
        if (m_animator != null)
            m_animator.Update();

        m_accumulativeTime += Time.deltaTime;
        m_accumulativeTime = Mathf.Min(m_accumulativeTime, m_time);

        float percent = m_accumulativeTime / m_time;

        m_transform.position = Vector3.Lerp(m_oringinPosition, m_destinationPosition,percent);

        if (m_accumulativeTime == m_time)
        {
            ChangeToIdelState();
        }
    }

    void onRunExits()
    {
        if (CBaseStory.IsInGameStory)
        {
            foreach (KeyValuePair<SceneStoryContent, CBaseStory> val in CBaseStory.m_currentState)
            {
                val.Value.DoSomeThing();
            }
        }
    }

    void onTurnEnter()
    {
    }

    void onTurnUpdate()
    {
        if (m_animator != null)
            m_animator.Update();
    }

    void onTurnExits()
    {
    }
    #endregion
}
