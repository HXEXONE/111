﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HomeMonster : BaseHomeMonster
{
    protected enum eHomeMonsterState
    {
        Idle,
        Run,
        Turn,
    }

    private NavMeshAgent m_navMeshAgent;
    private Vector3 m_destinationPosition;

    private float m_moveSpeed;

    #region 创建和销毁
    public HomeMonster(uint index, uint monterModelID, Vector3 position, Quaternion rotation, float size) :
        base(index, monterModelID, position, rotation, size)
    {
        Load();
    }
    #endregion

    public override void Release()
    {
        base.Release();
        m_navMeshAgent = null;
        m_destinationPosition = Vector3.zero;
    }

    #region Initialization
    protected override void onInitialise()
    {
        RegisterStateEvent();
        InitAnimationDictionary();
    }

    private void RegisterStateEvent()
    {
        RegistEnterEvent(eHomeMonsterState.Idle, onIdleEnter);
        RegistUpdateEvent(eHomeMonsterState.Idle, onIdleUpdate);
        RegistExitsEvent(eHomeMonsterState.Idle, onIdleExits);

        RegistEnterEvent(eHomeMonsterState.Run, onRunEnter);
        RegistUpdateEvent(eHomeMonsterState.Run, onRunUpdate);
        RegistExitsEvent(eHomeMonsterState.Run, onRunExits);

        RegistEnterEvent(eHomeMonsterState.Turn, onTurnEnter);
        RegistUpdateEvent(eHomeMonsterState.Turn, onTurnUpdate);
        RegistExitsEvent(eHomeMonsterState.Turn, onTurnExits);
    }

    private void InitAnimationDictionary()
    {
        AddAnimationDictionary(eHomeMonsterState.Idle, "idle");
        AddAnimationDictionary(eHomeMonsterState.Run, "run");
        AddAnimationDictionary(eHomeMonsterState.Turn, "walk");
    }
    #endregion

    #region Loading Model
    protected override void LoadModelCompleted(GameObject o, params object[] args)
    {
        base.LoadModelCompleted(o, args);
        if (null == o)
        {
            return;
        }

        m_navMeshAgent = o.GetComponent<NavMeshAgent>();
        if (null == m_navMeshAgent)
        {
            m_navMeshAgent = o.AddComponent<NavMeshAgent>();
            m_navMeshAgent.radius = 0;
            m_navMeshAgent.height = 0;
            m_navMeshAgent.speed = 7.0f;
            m_navMeshAgent.acceleration = 360;
            m_navMeshAgent.angularSpeed = 360;
        }
        m_navMeshAgent.enabled = true;
        m_transform.position = Common.NavSamplePosition(m_transform.position);

        Transform followTrans = o.transform.Find("FollowObject");
        if (followTrans != null)
        {
            NavMeshAgent nma = followTrans.GetComponent<NavMeshAgent>();
            if (nma != null) nma.enabled = false;
        }

        Transform shadow = o.transform.FindChild("shadow");
        if (ClientMain.IsSupportShadowRunTime)
        {
            if (shadow)
            {
                Object.Destroy(shadow.gameObject);
            }
        }
        else
        {
            if (shadow)
                shadow.transform.localPosition = Vector3.zero;
        }

        ChangeToIdelState();
    }
    #endregion

    #region State Change
    public override void MoveTo(Vector3 position, float speed = 7)
    {
        if (!m_loadCompleted)
            return;
        m_destinationPosition = position;
        m_moveSpeed = speed;
        ChangeState(eHomeMonsterState.Run);
    }

    public override void ChangeToIdelState()
    {
        if (!m_loadCompleted)
            return;
        ChangeState(eHomeMonsterState.Idle);
    }

    public override void ChangeToTurnState()
    {
        if (!m_loadCompleted)
            return;
        ChangeState(eHomeMonsterState.Turn);
    }

    private void StopNavMeshAgent()
    {
        if (m_navMeshAgent != null && m_navMeshAgent.enabled)
        {
            m_navMeshAgent.Stop();
        }
    }

    private bool SetDestination(Vector3 position,float speed)
    {
        if (m_navMeshAgent != null && m_navMeshAgent.enabled)
        {
            m_navMeshAgent.speed = speed;
            m_navMeshAgent.SetDestination(position);
            return true;
        }
        return false;
    }

    private bool CheckArrive()
    {
        if (Common.Get2DVecter3Length(m_transform.position, m_destinationPosition) < 0.5f)
            return true;
        else
            return false;
    }
    #endregion

    #region StateEvent
    void onIdleEnter()
    {
    }

    void onIdleUpdate()
    {
        if (m_animator != null)
            m_animator.Update();
    }

    void onIdleExits()
    {
    }

    void onRunEnter()
    {
        if (!SetDestination(m_destinationPosition,m_moveSpeed))
            ChangeToIdelState();
    }

    void onRunUpdate()
    {
        if (m_animator != null)
            m_animator.Update();

        if (CheckArrive())
        {
            ChangeToIdelState();
        }
    }

    void onRunExits()
    {
        StopNavMeshAgent();
        if (CBaseStory.IsInGameStory)
        {
            foreach (KeyValuePair<SceneStoryContent, CBaseStory> val in CBaseStory.m_currentState)
            {
                val.Value.DoSomeThing();
            }
        }
    }

    void onTurnEnter()
    {
    }

    void onTurnUpdate()
    {
        if (m_animator != null)
            m_animator.Update();
    }

    void onTurnExits()
    { 
    }
    #endregion
}
