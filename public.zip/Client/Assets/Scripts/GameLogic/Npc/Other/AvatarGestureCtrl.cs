﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//主角手势控制(技能)
public class AvatarGestureCtrl 
{
    Avatar m_pAvatar;
    Vector3 m_downPos;
    Vector3 m_upPos;

    eGestureState m_mouseState;
    Camera m_manCamera;

    int m_nClickCount;
    float m_fUpTime;
    float m_fDownTime;



    Timer m_fChargeTimer; //蓄力计时器
    
    const float HOLD_TIME = 0.3f;
    const float INTERVAL_TIME = 0.23f; // 鼠标点击间隔

    public AvatarGestureCtrl(Avatar avatar, Camera mainCamera) 
    {
        m_fDownTime = 0f;
        m_fUpTime = 0f;
        m_nClickCount = 0;        

        m_fChargeTimer = new Timer();
        m_mouseState = eGestureState.None; ;

        m_manCamera = mainCamera;
        m_pAvatar = avatar;
    }


    public void Update()
    {
        if (SingletonObject<BattleGuide>.GetInst().Behavior != eGuideBehavior.Free)
        {
            return;
        }


        if (null == m_pAvatar || null == m_manCamera )
            return;

        if (m_pAvatar.Courageous || Avatar.m_OffHandelClick)//|| NewBieGuidManager.GetInst().bGuidLockBehaviour
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (!UIManager.GetInst().MouseInNGUI())
            {
                m_fDownTime = Time.time;
                m_downPos = Input.mousePosition;
                m_mouseState = eGestureState.Down;            
            }
            
        }

        if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            m_upPos = Input.mousePosition;

            float distance = Vector3.Distance(m_upPos, m_downPos);
            if (m_mouseState == eGestureState.Down)
            {
                m_nClickCount++;
                //滑动判断
                if (distance > 180f)
                {
                    SwipeEnd();
                }
                else
                {
                    float intervalTime = INTERVAL_TIME * Common.TimeScale;
                    if (Time.time - m_fUpTime < intervalTime && distance < 12f/* && m_nClickCount % 2 == 0*/)
                    {
                        DMove();
                    }
                    else
                    {
                        Move();
                    }
                }
            }
            
            m_fUpTime = Time.time;
            m_mouseState = eGestureState.Up;
            SingletonObject<SkillReadyTimeMediator>.GetInst().Close();
        }


        if (Input.GetKey(KeyCode.Mouse0))
        {
            if (!UIManager.GetInst().MouseInNGUI())
            {
                HoldPress();
            }
        }

        if (m_mouseState == eGestureState.Down )
        {
            if (Time.time - m_fDownTime > HOLD_TIME /** Time.timeScale*/)
            {
                //蓄力开始
                ChargeStart();
                m_mouseState = eGestureState.HoldDown;
            }            
        }
        
    }

    //单击(移动)
    private void Move()     
    {
        if (m_pAvatar.IsInPlatform()) return;
        if (m_pAvatar.IsFlyInFall()) return;
        if (m_pAvatar.IsPauseMove) return;

        m_pAvatar.HandelClick(eMouseClick.Onclick);
    }

    //双击(闪避)
    private void DMove() 
    {
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.BattleShanbi);
        if (mode != eOpenMode.Acquiesce) return;
        if (m_pAvatar.IsInRide()) return;
        //if (m_pAvatar.Trusteeship) return;
        if (m_pAvatar.IsInFly()) return;
        if (m_pAvatar.IsInPlatform()) return;
        if (m_pAvatar.IsPauseMove) return;

        //if (Time.time - m_fDClickTime < 2f) return; //双击CD
        
        SkillContent rollSkillLoader = null;
        if (m_pAvatar.PartnerState == ePartnerState.Partner)
        {
            if (null == m_pAvatar.ActivePartner) return;

            if (null == m_pAvatar.ActivePartner.PartnerLoader.ModelLoader) return;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_pAvatar.ActivePartner.PartnerLoader.ModelLoader.RollSkill);
        }
        else
        {
            PlayerConfigContent configLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pAvatar.NpcType);
            if (null == configLoader) return;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(configLoader.RollID);
        }

        //精力值判断
		if (rollSkillLoader.CostType == (byte)eCostType.JudgeMp ||
            rollSkillLoader.CostType == (byte)eCostType.CostMp)
		    {
            if (m_pAvatar.GetMp() < rollSkillLoader.CostValue)
            {
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9100147), Color.red);
                return;
            }
        }

        m_pAvatar.HandelClick (eMouseClick.OnDoubleClick);
    }

    //持续按下 转动方向
    private void HoldPress() 
    {
        //if (m_pAvatar.IsInRide()) return;
        if (m_pAvatar.IsInFly()) return;
        if (m_pAvatar.IsInPlatform()) return;
        if (m_pAvatar.IsPauseMove) return;

        m_pAvatar.HandelClick(eMouseClick.OnHoldClick);
    }

    //开始蓄力
    private void ChargeStart()
    {
        //蓄力条件判断
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.BattleXuli);
        if (mode != eOpenMode.Acquiesce) return;
        if (!m_pAvatar.CanUseSkillManully()) return;            

        if (m_pAvatar.IsInRide()) return;
        if (m_pAvatar.IsInFly()) return;
        if (m_pAvatar.IsInPlatform()) return;
        if (m_pAvatar.PartnerState != ePartnerState.Avatar) return;
        if (m_pAvatar.IsPauseMove) return;

        PlayerConfigContent pConfigLoader = m_pAvatar.GetConfigLoader();
        if ( null != pConfigLoader)
        {
            uint skillID = (uint)pConfigLoader.ChargeList[0];
            if (0 != skillID)
            {
                m_pAvatar.UseSkillManully(skillID,Vector3.zero);
            }
            
        }
    }

    //滑动(抓取)
    private void SwipeEnd()
    {
        eOpenMode mode = NewBieGuidManager.GetInst().isOpenFun(eOpenFunction.BattleZhuaqu);
        if (mode != eOpenMode.Acquiesce) return;

        if (m_pAvatar.CurrBattleScene.BattleType == eBattleType.Arena ||
            m_pAvatar.CurrBattleScene.BattleType == eBattleType.Pvp ||
            m_pAvatar.CurrBattleScene.BattleType == eBattleType.MultiPve)
            return;        

        if (m_pAvatar.IsInRide()) return;
        if (m_pAvatar.IsInFly()) return;
        if (m_pAvatar.PartnerState != ePartnerState.Avatar) return;
        if (!m_pAvatar.CanMove) return;
        if (m_pAvatar.IsInPlatform()) return;
        if (m_pAvatar.IsPauseMove) return;

        PlayerConfigContent pConfigLoader = m_pAvatar.GetConfigLoader();
        if (null == pConfigLoader) return;

        uint skillID = (uint)pConfigLoader.GrabID;
        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(skillID);
        if (null == pSkillLoader) return;
        
        //精力值判断
        if (pSkillLoader.CostType ==  (byte)eCostType.JudgeMp)
        {
            if (m_pAvatar.GetMp() < pSkillLoader.CostValue)
            {
                SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(Common.GetText(9100147), Color.red);
                return;
            }
        }
        
        Vector3 normailed = (m_upPos - m_downPos).normalized;
        Vector3 targetDirection = new Vector3(normailed.x, 0.0f, normailed.y);

        float y = m_manCamera.transform.rotation.eulerAngles.y;
        targetDirection = Quaternion.Euler(0f, y, 0f) * targetDirection;
        //m_pAvatar.UpdateTurn(targetDirection, true);

        if (0 != skillID)
        {
            m_pAvatar.UseSkillManully(skillID,targetDirection);
        }
     
    }

}
