﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public delegate void HomeStroneAvatarCallback(object arg);


public class HomeStroneAvatar{

    private float m_colorTest;

    private bool m_useDefault;
    private uint m_clothID;
    private uint m_weaponID;
    private PlayerContent m_playerInfo;

    private Vector3 m_startPoaition;
    private Quaternion m_startRotation;
    private float m_size;

    private CObject m_model;
    //private CObject m_stroneTexture;
    private static CObject m_timeTexture;
    private CObject m_weaponLeftTexture;
    private CObject m_weaponLeftModel;
    private CObject m_weaponRightTexture;
    private CObject m_weaponRightModel;

    private static GameObject m_sphoreObject;
    private static Shader m_shader;
    private static Color m_color = new Color(1f, 0.97255f, 0.00784f, 0.66667f);

    private stPlayerRankData m_info;

    private Animator m_animator;
    private Transform m_transform;
    private List<GameObject> m_hideList;
    private Dictionary<Renderer, Material> m_originalMaterials;
    private List<Material> m_copyMaterials;
    private TopOneMediator _topOneMediator;//UI
    public Transform Transform { get { return m_transform; } }

    private HomeStroneAvatarCallback m_callback;
    private object m_param;

    public enum eState
    {
        Normal,Create,Unload
    }

    private eState m_targetState;
    private SimpleStateMachine m_stateMechine;

    private float m_alpha;
    private float m_speed;
    private short m_loadWeaponCount;
    private short m_loadWeaponStep;

    private bool m_bCreate;

    public HomeStroneAvatar(Vector3 position, Quaternion rotation, float size,float fadeTime)
    {
        _topOneMediator = SingletonObject<TopOneMediator>.GetInst();
        m_useDefault = false;
        m_bCreate = false;
        m_info = RankManager.GetInst().AllServerNumberOne;
        m_colorTest = m_info.uiJob == 11000001 ? 1 : 0;
        m_clothID = 31230526;
        m_weaponID = 31130526;
        m_startPoaition = position;
        m_startRotation = rotation;
        m_size = size;
        m_playerInfo = HolderManager.m_PlayerHolder.GetStaticInfo(11000003);
        m_hideList = new List<GameObject>();
        m_originalMaterials = new Dictionary<Renderer, Material>();
        m_copyMaterials = new List<Material>();

        if (m_shader == null)
            m_shader = DynamicShader.GetShader(DEFINE.SHADER_DIFFUSE_COLOR_BLEND);

        m_stateMechine = new SimpleStateMachine();

        m_stateMechine.AddEnterEvent(eState.Normal, onEnterNormal);
        m_stateMechine.AddExitsEvent(eState.Normal, onExitNormal);

        m_stateMechine.AddEnterEvent(eState.Create, onEnterCreate);
        m_stateMechine.AddUpdateEvent(eState.Create, onUpdateCreate);
        m_stateMechine.AddExitsEvent(eState.Create, onExitCreate);

        m_stateMechine.AddEnterEvent(eState.Unload, onEnterUnload);
        m_stateMechine.AddUpdateEvent(eState.Unload, onUpdateUnload);
        m_stateMechine.AddExitsEvent(eState.Unload, onExitUnload);

        m_speed = fadeTime > 0 ? (1f / fadeTime) : 1000000f;

        m_loadWeaponStep = 0;
        m_loadWeaponCount = 0;
        m_alpha = 0f;
        m_targetState = eState.Normal;
    }


    #region Loading
    public bool Refresh(stPlayerRankData data, HomeStroneAvatarCallback callback, object arg)
    {
        if (m_stateMechine != null && m_stateMechine.GetCurrentState() != null)
            return false;

        m_info = data;
        m_callback = callback;
        m_param = arg;

        m_targetState = eState.Create;
        ChangeState(eState.Unload);

        return true;
    }

    public void Release()
    {
        m_startPoaition = Vector3.zero;
        m_startRotation = Quaternion.identity;

        m_targetState = eState.Normal;
        m_stateMechine.Stop();
        m_stateMechine = null;

        int count = m_hideList.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_hideList[i] != null)
                m_hideList[i].SetActive(true);
        }
        m_hideList.Clear();
        m_hideList = null;

        m_playerInfo = null;
        m_transform = null;

        foreach(KeyValuePair<Renderer,Material> sm in m_originalMaterials)
        {
            if (sm.Key != null && sm.Value != null)
                sm.Key.material = sm.Value;
        }
        m_originalMaterials.Clear();
        m_originalMaterials = null;

        for (int i = 0; i < m_copyMaterials.Count;i++ )
        {
            if (m_copyMaterials[i] != null)
            {
                Object.DestroyImmediate(m_copyMaterials[i],false);
            }
        }
        m_copyMaterials.Clear();
        m_copyMaterials = null;

        if (m_model != null)
        {
            m_model.DestroyGameObject(eObjectDestroyType.Memory);
            m_model = null;
        }
        //if (m_timeTexture != null)
        //{
        //    m_timeTexture.DestroyGameObject(eObjectDestroyType.Memory);
        //    m_timeTexture = null;
        //}
        if (m_weaponLeftTexture != null)
        {
            m_weaponLeftTexture.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponLeftTexture = null;
        }
        if (m_weaponLeftModel != null)
        {
            m_weaponLeftModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponLeftModel = null;
        }
        if (m_weaponRightTexture != null)
        {
            m_weaponRightTexture.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponRightTexture = null;
        }
        if (m_weaponRightModel != null)
        {
            m_weaponRightModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponRightModel = null;
        }
        if (m_sphoreObject != null)
        {
            m_sphoreObject.SetActive(false);
        }
        if (_topOneMediator != null) _topOneMediator.Close();

        m_callback = null;
        m_param = null;
    }

    public void Update()
    {
        if (m_stateMechine != null)
            m_stateMechine.Update();
    }

    public void ChangeState(eState state)
    {
        if (m_stateMechine == null)
            return;
        m_stateMechine.ChangeToState(state);
    }

    public void Stop()
    {
        if (m_stateMechine == null)
            return;

        m_stateMechine.Stop();
    }

    public void Load(stPlayerRankData data, HomeStroneAvatarCallback callback, object arg)
    {
        m_info = data;
        m_callback = callback;
        m_param = arg;

        m_targetState = eState.Normal;
        ChangeState(eState.Create);
    }

    private void LoadTimeTexture()
    {
        if (m_timeTexture == null || m_timeTexture.PTexture2D == null)
        {
            m_timeTexture = new CObject(DEFINE.ASSETBUNDLE_PATH_TEXTURE_TIME);
            m_timeTexture.CallBack = LoadStroneTextureCompleted;
            m_timeTexture.IsMemoryFactory = true;
            m_timeTexture.ObjectType = eObjectType.Texture;
            m_timeTexture.LoadObject();
        }
        else
        {
            CreateSphore(false);
            LoadModel();
        }
    }

    private void CreateSphore(bool resetTexture)
    {
        if (m_sphoreObject == null)
        {
            m_sphoreObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Material material = m_sphoreObject.renderer.material;
            //m_copyMaterials.Add(material);
            material.shader = DynamicShader.GetShader(DEFINE.SHADER_COLOR_ADDTIVE);
            material.mainTexture = m_timeTexture.PTexture2D;
            material.color = new Color(0.59608f, 0.46667f, 0.23922f, 1);

            m_sphoreObject.transform.position = new Vector3(-2f, 0.5f, 10.6f);
            m_sphoreObject.transform.localScale = new Vector3(5.314f, 8f, 5.314f);

            Object.DestroyImmediate(m_sphoreObject.collider);
            Object.DontDestroyOnLoad(m_sphoreObject);
        }
        else
        {
            if (resetTexture)
                m_sphoreObject.renderer.material.mainTexture = m_timeTexture.PTexture2D;
            m_sphoreObject.SetActive(true);
        }
    }

    private void LoadStroneTextureCompleted(GameObject o, params object[] args)
    {
        if (m_timeTexture.PTexture2D == null)
            MyLog.LogError("Can not find Texture ,Path = " + m_timeTexture.Path);

        CreateSphore(true);
        LoadModel();
    }

    private void LoadModel()
    {
        uint clothID = UpdateManager.GetInst().CheckAssetIDAble(m_info.uiClothesId, eAssetMapCheckType.Cloth, (eJobType)(m_info.uiJob % 10));
        EquipContent pClothesLoader = HolderManager.m_EquipHolder.GetStaticInfo(clothID);
        if (null == pClothesLoader) //用默认职业  法师
        {
            m_useDefault = true;
            clothID = UpdateManager.GetInst().CheckAssetIDAble(m_clothID, eAssetMapCheckType.Cloth, eJobType.Wizard);
            pClothesLoader = HolderManager.m_EquipHolder.GetStaticInfo(clothID);
        }
        if (pClothesLoader == null)
            return;

        List<string> szPaths = pClothesLoader.ModelLoader.ModelPath;

        if (szPaths.Count == 0)
        {
            return;
        }

        m_model = new CObject(szPaths[0]);
        m_model.CallBack = LoadModelCompleted;
        m_model.IsMemoryFactory = true;
        m_model.BParticleActive = false;
        m_model.ObjectType = eObjectType.HomeAvatar;
        m_model.BornPosition = m_startPoaition;
        m_model.BornRotation = m_startRotation;
        m_model.LoadObject();
    }

    private void LoadModelCompleted(GameObject o, params object[] args)
    {
        if (o == null)
        {
            DebugMessage("HomeStroneAvatar LoadNpcCompleted Fail GameObject is Null");
            return;
        }
        m_transform = o.transform;
        m_transform.localScale = Vector3.one * m_size;
        Renderer[] renderers = o.GetComponentsInChildren<Renderer>(true);

        Material material;
        foreach (Renderer render in renderers)
        {
            if (render is SkinnedMeshRenderer && !render.tag.Equals(DEFINE.OTHER_SKINNED))
            {
                material = render.material;
                m_originalMaterials.Add(render, material);
                Material copyMaterial = Object.Instantiate(material) as Material;
                m_copyMaterials.Add(copyMaterial);
                copyMaterial.shader = m_shader;
                copyMaterial.color = m_color;
                copyMaterial.SetFloat("_ColorTest", m_colorTest);
                render.material = copyMaterial;
                if (copyMaterial.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                {
                    copyMaterial.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
                }
            }
            else
            {
                if (!render.gameObject.name.Equals("shadow"))
                {
                    render.gameObject.SetActive(false);
                    m_hideList.Add(render.gameObject);
                }
            }
        }

        string animatorPath;
        if (m_useDefault)
        {
            animatorPath = m_playerInfo.AmimatorPath;
        }
        else
        {
            PlayerContent loader = HolderManager.m_PlayerHolder.GetStaticInfo((uint)m_info.uiJob);
            animatorPath = loader.AmimatorPath;
        }
        animatorPath = Common.ReplaceHomeAniPath(animatorPath); 
        Animator aniCtrl = m_transform.GetComponent<Animator>();
        if (null == aniCtrl)
        {
            MyLog.LogError(animatorPath + " can not find animator Component !  ");
            return;
        }
        if (null == aniCtrl.runtimeAnimatorController) // Controller
        {
            LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
        }
        else
        {
            BuildAnimator(aniCtrl);
        }
    }

    private void LoadAcnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        Animator aniCtrl = m_transform.GetComponent<Animator>();
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;

        BuildAnimator(aniCtrl);
    }

    private void BuildAnimator(Animator animator)
    {
        animator.enabled = true;

        animator.Play("xiuxian");
        m_animator = animator;
        m_animator.speed = 0;
        if (m_useDefault)
        {
            uint weaponID = UpdateManager.GetInst().CheckAssetIDAble(m_weaponID, eAssetMapCheckType.Weapon, eJobType.Wizard);
            LoadWeaponTexture(weaponID);
        }
        else
        {
            uint weaponID = UpdateManager.GetInst().CheckAssetIDAble(m_info.uiWeaponId, eAssetMapCheckType.Weapon, (eJobType)(m_info.uiJob % 10));
            LoadWeaponTexture(weaponID);
        }
    }

    private void LoadWeaponTexture(uint weaponId)
    {
        EquipContent pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(weaponId);
        if (pWeaponLoader != null)
        {
            List<string> pathArray = pWeaponLoader.ModelLoader.ModelPath;
            if (pathArray == null)
            {
                DebugMessage("Can not find weapon path weaponId = " + weaponId.ToString());
                return;
            }
            if (pathArray.Count != 2)
            {
                DebugMessage("weapon count not equal two");
                return;
            }

            List<string> pathTexture = pWeaponLoader.ModelLoader.TexturePath;

            int pathTextureCount = pathTexture.Count;

            if (!string.IsNullOrEmpty(pathArray[0]) && !pathArray[0].Equals("0"))
            {
                m_loadWeaponCount++;
            }
            if (!string.IsNullOrEmpty(pathArray[1]) && !pathArray[1].Equals("0"))
            {
                m_loadWeaponCount++;
            }
            m_bCreate = true;

            if (pathTextureCount == 2)
            {
                if (!pathTexture[0].Equals("0"))
                {
                    m_weaponLeftTexture = new CObject(pathTexture[0]);
                    m_weaponLeftTexture.ObjectType = eObjectType.Texture;
                    m_weaponLeftTexture.IsMemoryFactory = true;
                    m_weaponLeftTexture.CallBack = LoadWeaponLeftTextureCompleted;
                    m_weaponLeftTexture.Args = new object[] { pathArray[0] };
                    m_weaponLeftTexture.LoadObject();
                }

                if (!pathTexture[0].Equals("1"))
                {
                    m_weaponRightTexture = new CObject(pathTexture[1]);
                    m_weaponRightTexture.ObjectType = eObjectType.Texture;
                    m_weaponRightTexture.IsMemoryFactory = true;
                    m_weaponRightTexture.CallBack = LoadWeaponRightTextureCompleted;
                    m_weaponRightTexture.Args = new object[] { pathArray[1] };
                    m_weaponRightTexture.LoadObject();
                }
            }
            else
            {
                LoadWeapon(pathArray[0], true);
                LoadWeapon(pathArray[1], true);
            }

        }
    }

    private void LoadWeaponLeftTextureCompleted(GameObject o, params object[] args)
    {
        if (m_weaponLeftTexture.PTexture2D == null)
            MyLog.LogError("Can not find Texture ,Path = " + m_weaponLeftTexture.Path);

        LoadWeapon((string)args[0], true);
    }

    private void LoadWeaponRightTextureCompleted(GameObject o, params object[] args)
    {
        if (m_weaponRightTexture.PTexture2D == null)
            MyLog.LogError("Can not find Texture ,Path = " + m_weaponRightTexture.Path);
        LoadWeapon((string)args[0], false);
    }

    private void LoadWeapon(string path, bool isLeft)
    {
        if (string.IsNullOrEmpty(path) || path.Equals("0"))
        {
            return;
        }
        if (isLeft)
        {
            m_weaponLeftModel = new CObject(path);
            m_weaponLeftModel.CallBack = LoadWeaponLeftCompleted;
            m_weaponLeftModel.IsMemoryFactory = true;
            m_weaponLeftModel.BParticleActive = false;
            m_weaponLeftModel.ObjectType = eObjectType.Weapon;
            m_weaponLeftModel.LoadObject();
        }
        else
        {
            m_weaponRightModel = new CObject(path);
            m_weaponRightModel.CallBack = LoadWeaponRightCompleted;
            m_weaponRightModel.IsMemoryFactory = true;
            m_weaponRightModel.BParticleActive = false;
            m_weaponRightModel.ObjectType = eObjectType.Weapon;
            m_weaponRightModel.LoadObject();
        }
    }

    private void LoadWeaponLeftCompleted(GameObject o, params object[] args)
    {
        m_loadWeaponStep++;
        if (o == null)
        {
            DebugMessage("NpcGameObject LoadWeaponLeftCompleted Fail GameObject is Null");
            return;
        }

        Transform bonetrans = Common.GetBone(m_transform, "Bip01 Prop2");
        if (null == bonetrans)
        {
            m_weaponLeftModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponLeftModel = null;
            DebugMessage("NpcGameObject LoadWeaponLeftCompleted Fail Can not find Bone : Bip01 Prop2");
            return;
        }

        bonetrans.gameObject.SetActive(true);

        o.transform.parent = bonetrans;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        if (m_weaponLeftTexture != null && m_weaponLeftTexture.PTexture2D != null)
        {
            o.renderer.material.mainTexture = m_weaponLeftTexture.PTexture2D;
        }

        Renderer[] renderers = o.GetComponentsInChildren<Renderer>(true);
        foreach (Renderer render in renderers)
        {
            if (render.gameObject.Equals(o))
            {
                Material material = render.material;
                m_originalMaterials.Add(render, material);
                Material copyMaterial = Object.Instantiate(material) as Material;
                m_copyMaterials.Add(copyMaterial);
                copyMaterial.shader = m_shader;
                copyMaterial.color = m_color;
                copyMaterial.SetFloat("_ColorTest", m_colorTest);
                render.material = copyMaterial;
                if (copyMaterial.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                {
                    copyMaterial.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
                }
            }
            else
            {
                render.gameObject.SetActive(false);
                m_hideList.Add(render.gameObject);
            }
        }
        ParticleSystem[] particles = o.GetComponentsInChildren<ParticleSystem>(true);
        foreach (ParticleSystem particle in particles)
        {
            particle.gameObject.SetActive(false);
            m_hideList.Add(particle.gameObject);
        }
    }

    private void LoadWeaponRightCompleted(GameObject o, params object[] args)
    {
        m_loadWeaponStep++;
        if (o == null)
        {
            DebugMessage("NpcGameObject LoadWeaponLeftCompleted Fail GameObject is Null");
            return;
        }

        Transform bonetrans = Common.GetBone(m_transform, "Bip01 Prop1");
        if (null == bonetrans)
        {
            m_weaponRightModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponRightModel = null;
            DebugMessage("NpcGameObject LoadWeaponRightCompleted Fail Can not find Bone : Bip01 Prop1");
            return;
        }

        bonetrans.gameObject.SetActive(true);

        o.transform.parent = bonetrans;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;

        if (m_weaponRightTexture != null && m_weaponRightTexture.PTexture2D != null)
        {
            o.renderer.material.mainTexture = m_weaponRightTexture.PTexture2D;
        }

        Renderer[] renderers = o.GetComponentsInChildren<Renderer>(true);
        foreach (Renderer render in renderers)
        {
            if (render.gameObject.Equals(o))
            {
                Material material = render.material;
                m_originalMaterials.Add(render, material);
                Material copyMaterial = Object.Instantiate(material) as Material;
                m_copyMaterials.Add(copyMaterial);
                copyMaterial.shader = m_shader;
                copyMaterial.color = m_color;
                copyMaterial.SetFloat("_ColorTest", m_colorTest);
                render.material = copyMaterial;
                if (copyMaterial.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                {
                    copyMaterial.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
                }
            }
            else
            {
                render.gameObject.SetActive(false);
                m_hideList.Add(render.gameObject);
            }
        }

        ParticleSystem[] particles = o.GetComponentsInChildren<ParticleSystem>(true);
        foreach (ParticleSystem particle in particles)
        {
            particle.gameObject.SetActive(false);
            m_hideList.Add(particle.gameObject);
        }
    }

    private void UnloadModel()
    {
        int count = m_hideList.Count;
        for (int i = 0; i < count; i++)
        {
            m_hideList[i].SetActive(true);
        }
        m_hideList.Clear();

        m_transform = null;

        foreach (KeyValuePair<Renderer, Material> sm in m_originalMaterials)
        {
            if (sm.Key != null && sm.Value != null)
                sm.Key.material = sm.Value;
        }
        m_originalMaterials.Clear();

        for (int i = 0; i < m_copyMaterials.Count; i++)
        {
            if (m_copyMaterials[i] != null)
            {
                Object.DestroyImmediate(m_copyMaterials[i], false);
            }
        }
        m_copyMaterials.Clear();

        if (m_model != null)
        {
            m_model.DestroyGameObject(eObjectDestroyType.Memory);
            m_model = null;
        }

        if (m_weaponLeftTexture != null)
        {
            m_weaponLeftTexture.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponLeftTexture = null;
        }
        if (m_weaponLeftModel != null)
        {
            m_weaponLeftModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponLeftModel = null;
        }
        if (m_weaponRightTexture != null)
        {
            m_weaponRightTexture.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponRightTexture = null;
        }
        if (m_weaponRightModel != null)
        {
            m_weaponRightModel.DestroyGameObject(eObjectDestroyType.Memory);
            m_weaponRightModel = null;
        }
    }

    #endregion

    protected void DebugMessage(string msg, LogType type = LogType.Error)
    {
        switch (type)
        {
            case LogType.Log: MyLog.Log(msg); break;
            case LogType.Warning: MyLog.LogWarning(msg); break;
            case LogType.Error: MyLog.LogError(msg); break;
            default: MyLog.DebugLogException(msg); break;
        }
    }

    void onEnterNormal()
    {
        if (m_callback != null)
        {
            m_callback(m_param);
            m_callback = null;
            m_param = null;
        }
        Stop();
    }

    void onExitNormal()
    { 
    }

    void onEnterCreate()
    {
        //m_alpha = 0;
        m_bCreate = false;
        m_loadWeaponStep = 0;
        m_loadWeaponCount = 0;
        LoadTimeTexture();
    }

    void onUpdateCreate()
    {
        if (m_bCreate && m_loadWeaponStep == m_loadWeaponCount)
        {
            m_alpha += (Time.deltaTime * m_speed);

            if (m_alpha >= 1)
                m_alpha = 1;

            for (int i = 0, count = m_copyMaterials.Count; i < count; i++)
            {
                if (m_copyMaterials[i] != null && m_copyMaterials[i].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                {
                    m_copyMaterials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
                }
            }

            if (m_alpha == 1)
            {
                ChangeState(m_targetState);
            }
        }
    }

    void onExitCreate()
    {
        m_loadWeaponStep = 0;
        m_loadWeaponCount = 0;
        m_bCreate = false;
        m_targetState = eState.Normal;
    }

    void onEnterUnload()
    {
        //m_alpha = 1;
    }

    void onUpdateUnload()
    {
        m_alpha -= (Time.deltaTime * m_speed);

        if (m_alpha <= 0)
            m_alpha = 0;

        for (int i = 0, count = m_copyMaterials.Count; i < count; i++)
        {
            if (m_copyMaterials[i] != null && m_copyMaterials[i].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
            {
                m_copyMaterials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
            }
        }

        if (m_alpha == 0)
        {
            ChangeState(m_targetState);
        }
    }

    void onExitUnload()
    {
        m_targetState = eState.Normal;
        UnloadModel();
    }
}
