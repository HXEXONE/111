﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;


public enum eCommandType
{
    RunTo,
    Turning,//转向
    UseSkill,
}

public enum eCommandReply
{
    YesSir,//NPC同意执行你的命令
    ICantDoThatYet,//NPC表示不能完成你的命令
    YouFuckOff,//NPC对你表示不满
}

public abstract class CommandArg
{
}

/// <summary>
/// RunTo command argument
/// </summary>
public class RunToCommandArg : CommandArg
{
    public Vector3 dstPosition;
    public bool bDirectionTurn;
    public bool bUsePathFinding;

    public RunToCommandArg(Vector3 dstPosition, bool bDirectionTurn, bool bUsePathFinding,bool fromMsg = false)
    {
        this.dstPosition = dstPosition;
        this.bDirectionTurn = bDirectionTurn;
        this.bUsePathFinding = bUsePathFinding;
    }
}

/// <summary>
/// Turning command argument
/// </summary>
public class TurningCommandArg : CommandArg
{
    public Vector3 dstPosition;

    public TurningCommandArg(Vector3 dstPosition)
    {
        this.dstPosition = dstPosition;
    }
}

public delegate void HitResultCallback();
/// <summary>
/// UseSkill command argument
/// </summary>
public class UseSkillCommandArg : CommandArg
{
    public uint uSkillid;
    public List<CBaseNpc> targetList;
    public bool bByScript = false;    
    public HitResultCallback callback = null;

    public UseSkillCommandArg(uint uSkillid, List<CBaseNpc> targetList,bool bByScript = false,HitResultCallback call = null)
    {
        this.uSkillid = uSkillid;
        this.targetList = targetList;
        this.bByScript = bByScript;
        this.callback = call;
    }
}

public delegate void SkillResultCallback(CBaseNpc pTarget, bool isDodge,string[] args); //技能攻击回调

public class SkillHitResult
{
    public readonly uint loaderKey;
    public readonly string[] args;
    public SkillResultCallback callback;

    public SkillHitResult(uint skillLoaderkey, string[] hitArgs,SkillResultCallback call)
    {
        loaderKey = skillLoaderkey;
        this.args = hitArgs;
        this.callback = call;
        
    }
}

public delegate void SkillHitCallback(Vector3 position,string stringArgs); //技能攻击回调


public class SkillHitWithoutTarget          //技能伤害
{
    public readonly uint loaderKey;
    public readonly string scriptArgs;
    public SkillHitCallback callback;

    public SkillHitWithoutTarget(uint loaderKey, string scriptArgs, SkillHitCallback callback)
    {
        this.loaderKey = loaderKey;
        this.scriptArgs = scriptArgs;
        this.callback = callback;
    }
}
