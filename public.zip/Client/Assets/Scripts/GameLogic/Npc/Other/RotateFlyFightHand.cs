﻿using UnityEngine;
using System.Collections;

public enum eRotateHandState
{
    None,
    Rotate,//旋转
    Retract,//收回
}

public delegate void RotateFlyFightHandCallback();

public class RotateFlyFightHand : MonoBehaviour {
    private Transform myTransform;

    private Quaternion resultRotation;
    private Quaternion tmpRotation;

    private Vector3 m_lookPosition;

    private float origionY;//原始手的y轴的角度
    private Timer pTimer;//收手的时间
    private Timer pDelayTimer;//收手延迟
    private float turnSpeed = 6;

    private eRotateHandState _state;

    public RotateFlyFightHandCallback callback;
	// Use this for initialization
	void Awake () 
    {
        myTransform = transform;
        LookPosition = Vector3.zero;
        SetState(eRotateHandState.None);
        resultRotation = Quaternion.identity;
        pTimer = new Timer();
        pDelayTimer = new Timer();
	}

    public Vector3 LookPosition
    {
        set
        {
            m_lookPosition = value;
            origionY = myTransform.localRotation.eulerAngles.y;
        }
    }
	
	// Update is called once per frame
	void LateUpdate () 
    {
        switch (_state)
        {
            case eRotateHandState.Rotate:
                {
                    float angle = Mathf.Acos((myTransform.position.y - m_lookPosition.y) / Vector3.Distance(m_lookPosition, myTransform.position));
                    angle = angle * 180 / Mathf.PI + 30;//30是修正值,否则和现象不符合,手垂下的时候是30度
                    resultRotation = Quaternion.Euler(myTransform.localRotation.eulerAngles.x, angle, myTransform.localRotation.eulerAngles.z);

                    myTransform.localRotation = resultRotation;
                    tmpRotation = myTransform.localRotation;

                    SetState(eRotateHandState.Retract);
                    resultRotation = Quaternion.Euler(myTransform.localRotation.eulerAngles.x, origionY, myTransform.localRotation.eulerAngles.z);

                    float rad2deg = Mathf.Abs(origionY - myTransform.localRotation.y) / Mathf.Rad2Deg;
                    pTimer.SetTimer(rad2deg / turnSpeed + 0.1f);
                    pDelayTimer.SetTimer(0.1f);

                    if (callback != null)
                    {
                        callback();
                    }
                }
                break;
            case eRotateHandState.Retract:
                {
                    if (!pDelayTimer.IsExpired(false))
                    {
                        myTransform.localRotation = tmpRotation;
                        break;
                    }
                    tmpRotation = Quaternion.Slerp(tmpRotation, resultRotation, turnSpeed * Time.deltaTime);
                    myTransform.localRotation = tmpRotation;

                    if (pTimer.IsExpired(false))
                    {
                        SetState(eRotateHandState.None);
                    }
                }
                break;
        }
        
	}

    public void SetState(eRotateHandState state)
    {
        _state = state;
    }

    public eRotateHandState GetState()
    {
        return _state;
    }
}
