﻿using UnityEngine;
using System.Collections;

public class PlatformReceiveMessage : MonoBehaviour
{
    public void PrepareEnter(GameObject platformObj) 
    {
        //platformObj = "start.."

        //准备进入        
        //Debug.Log(" PrepareEnter : " + platformObj.name);

        Avatar avatar = SingletonObject<Avatar>.GetInst();
        bool multiPve = avatar.CurrBattleScene.BattleType == eBattleType.MultiPve;
        if (multiPve)
        {            
            string szIndex = platformObj.name.Substring(platformObj.name.Length - 2, 2);
            Protocol.C2GPveBlink info = new Protocol.C2GPveBlink();
            info.type = (byte)eBlinkType.Lift;
            info.index = MyConvert_Convert.ToByte(szIndex);
            MultiPveMsg.RequestBlink(info);
        }
        else
        {
            RequestEnter(avatar.GetTransform().gameObject, platformObj);
        }
    }

    public void RequestEnter(GameObject passenger, GameObject platGo) 
    {    
         platGo.SendMessage("EnterPlatform", passenger);
    }

    public void EnterPlatform(GameObject platformObj)
    {       
        uint index = MyConvert_Convert.ToUInt32(this.transform.name);
        BaseBattlePlayer bbp = SingletonObject<BattleScene>.GetInst().GetNpc(index) as BaseBattlePlayer;
        if ( null != bbp )
        {
            bbp.EnterPlatform(platformObj);
        }
    }

    public void LeavePlatform(GameObject platformObj)
    {
        /*        Debug.Log(transform.name + " LeavePlatform  ");*/
        uint index = MyConvert_Convert.ToUInt32(this.transform.name);
        BaseBattlePlayer bbp = SingletonObject<BattleScene>.GetInst().GetNpc(index) as BaseBattlePlayer;
        if (null != bbp)
        {
            UnityCallBackManager.GetInst().AddCallBack(1f, delegate(object[] _args)
            {
                bbp.LeavePlatform(platformObj);
            });            
        }        
    }

}
