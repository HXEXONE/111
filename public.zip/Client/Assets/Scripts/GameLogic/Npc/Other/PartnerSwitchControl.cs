﻿using UnityEngine;
using System.Collections;

//更换小伙伴(主角)临时包围盒
public class PartnerSwitchControl
{
    private GameObject tempPartnerGO;
    private CharacterController controller;
    private eBattleType battleType;

    public PartnerSwitchControl(eBattleType type)
    {

        tempPartnerGO = new GameObject("switch_partner");

        controller = tempPartnerGO.AddComponent<CharacterController>();
        battleType = type;

        tempPartnerGO.SetActive(false);      

    }

    public CharacterController Controller
    {
        get { return Controller; }
    }

    public bool Enabled
    {  
        set 
        {
            //if (battleType == eBattleType.Arena)
                tempPartnerGO.SetActive(value); 
        }
    }

    public void SetPosition(Vector3 position,CharacterController cc)
    {
        return;
        //if (battleType == eBattleType.Arena)
        {
            Enabled = true;
            controller.center = cc.center;
            controller.radius = cc.radius;
            controller.radius = cc.radius;
            controller.height = cc.height;

            tempPartnerGO.transform.position = position;
        }        

    }
}
