﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ModelAnimation
{
    private uint m_index;
    private uint m_monterModelID;

    private MonsterModelContent m_monsterInfo;

    private Vector3 m_startPoaition;
    private Quaternion m_startRotation;
    private float m_startSize;

    protected bool m_loadCompleted = false;

    private CObject m_model;
    private CObject m_modelTexture;
    private GameObject m_modelAnimation;

    protected CAnimator m_animator;

    protected Transform m_transform;
    protected List<Material> m_materialList;

    private SimpleStateMachine m_stateManager;

    private Dictionary<System.Enum, string> m_animationDictionary = new Dictionary<System.Enum,string>();

    public ModelAnimation(uint index, uint monterModelID, Vector3 position, Quaternion rotation, float size)
    {
        m_materialList = new List<Material>();

        m_index = index;
        m_monterModelID = monterModelID;
        m_startPoaition = position;
        m_startRotation = rotation;
        m_startSize = size;

        m_monsterInfo = HolderManager.m_MonsterModelHolder.GetStaticInfo(monterModelID);

        m_stateManager = new SimpleStateMachine();

        onInitialise();
    }

    public Transform GetTransform()
    {
        return m_transform;
    }

    public virtual void Release()
    {
        m_index = 0;
        m_monterModelID = 0;
        m_startPoaition = Vector3.zero;
        m_startRotation = Quaternion.identity;
        m_startSize = 0;

        if (m_model != null)
            m_model.DestroyGameObject(eObjectDestroyType.Memory);
        if (m_modelTexture != null)
            m_modelTexture.DestroyGameObject(eObjectDestroyType.Memory);
        //if (m_modelAnimation != null)
        //    Object.DestroyImmediate(m_modelAnimation,true);

        m_animator = null;
        m_transform = null;

        if (m_stateManager != null)
        {
            m_stateManager.Release();
            m_stateManager = null;
        }

        m_loadCompleted = false;
    }

    public virtual void Update()
    {
        if (m_stateManager != null)
            m_stateManager.Update();
    }

    #region Register
    protected virtual void onInitialise()
    { 
    }

    protected void AddAnimationDictionary(System.Enum state,string animationName)
    {
        if (m_animationDictionary.ContainsKey(state))
            return;
        m_animationDictionary.Add(state, animationName);
    }

    protected virtual void RegistEnterEvent(System.Enum state, PlayerModelStateEvent enterEvent)
    {
        m_stateManager.AddEnterEvent(state, enterEvent);
    }

    protected virtual void RegistUpdateEvent(System.Enum state, PlayerModelStateEvent enterEvent)
    {
        m_stateManager.AddUpdateEvent(state, enterEvent);
    }

    protected virtual void RegistExitsEvent(System.Enum state, PlayerModelStateEvent enterEvent)
    {
        m_stateManager.AddExitsEvent(state, enterEvent);
    }
    #endregion

    #region Loading
    protected void Load()
    {
        LoadTexture();
    }

    private void LoadTexture()
    {
        if (m_monsterInfo == null)
            return;
        string texturePath = m_monsterInfo.TextureName;
        if (!texturePath.Equals("0"))
        {
            m_modelTexture = new CObject(texturePath);
            m_modelTexture.IsMemoryFactory = true;
            m_modelTexture.ObjectType = eObjectType.Texture;
            m_modelTexture.CallBack = LoadTextureCompleted;
            m_modelTexture.LoadObject();
        }
        else
            LoadModelAnimation();
    }

    private void LoadTextureCompleted(GameObject o, params object[] args)
    {
        if (o == null)
        {
            MyLog.LogError("Can nor load model Texture: " + m_modelTexture.Path);
        }

        LoadModelAnimation();
    }

    private void LoadModelAnimation()
    {
        string animationPath = m_monsterInfo.AniPath;
        LoadHelp.LoadObject(animationPath, animationPath, ThreadPriority.Normal, LoadModelAnimationCompleted);
    }

    private void LoadModelAnimationCompleted(string msg, Object asset)
    {
        if (asset == null)
        {
            MyLog.LogError("Can nor load model animation : " + msg);
            return;
        }
        m_modelAnimation = asset as GameObject;
        LoadModel();
    }

    private void LoadModel()
    {
        m_model = new CObject(m_monsterInfo.Path);
        m_model.IsMemoryFactory = true;
        m_model.ObjectType = eObjectType.Npc;
        m_model.CallBack = LoadModelCompleted;
        m_model.LoadObject();
    }

    protected virtual void LoadModelCompleted(GameObject o, params object[] args)
    {
        if (o == null)
        {
            MyLog.LogError("Can nor load model : " + m_modelTexture.Path);
        }
        else
        {
            m_transform = o.transform;
            m_transform.position = m_startPoaition;
            m_transform.rotation = m_startRotation;
            m_transform.localScale = Vector3.one * m_startSize;

            Collider[] colliders = o.GetComponentsInChildren<Collider>();
            foreach (Collider c in colliders)
            {
                Object.DestroyImmediate(c);
            }

            SkinnedMeshRenderer[] skinnedMeshRenderers = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);

            foreach (SkinnedMeshRenderer smr in skinnedMeshRenderers)
            {
                smr.enabled = true;
                int matLen = smr.sharedMaterials.Length;
                for (int i = 0; i < matLen; i++)
                {
                    if (m_modelTexture != null && m_modelTexture.PTexture2D != null)
                    {
                        smr.sharedMaterials[i].mainTexture = m_modelTexture.PTexture2D;
                    }
                }
                m_materialList.AddRange(smr.sharedMaterials);
            }
        }

        if (null == m_modelAnimation)
        {
            return;
        }
        Animator animator = m_modelAnimation.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + m_modelAnimation.name);
            return;
        }

        Animator aniCtrl = m_transform.GetComponent<Animator>();
        if (null == aniCtrl)
        {
            aniCtrl = m_transform.gameObject.AddComponent<Animator>();
        }
        aniCtrl.avatar = animator.avatar;
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
        aniCtrl.applyRootMotion = false;
        aniCtrl.enabled = true;

        m_animator = new CAnimator(aniCtrl);

        Transform clothTran = m_transform.FindChild("clothes");
        if (clothTran != null)
            clothTran.gameObject.SetActive(false);

        m_loadCompleted = true;
    }
    #endregion

    #region State / Get
    protected virtual void ChangeState(System.Enum state, PlayOnceFinised callback = null,float fadeTime = 0.1f)
    {
        if (m_stateManager == null)
            return;
        m_stateManager.ChangeToState(state);
        if (m_animationDictionary.ContainsKey(state) && m_transform != null)
        {
            if (m_animator != null)
                m_animator.PlayAction(m_animationDictionary[state], 1, false, callback, fadeTime);
        }
    }

    protected System.Enum GetCurrentState()
    {
        if(m_stateManager == null)
            return null;
        else
            return m_stateManager.GetCurrentState();
    }

    protected string GetAnimationName(System.Enum state)
    {
        if (m_animationDictionary.ContainsKey(state))
            return m_animationDictionary[state];
        else
            return string.Empty;
    }
    #endregion
}