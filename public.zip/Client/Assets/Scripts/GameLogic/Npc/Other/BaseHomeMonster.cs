﻿using UnityEngine;
using System.Collections;

public abstract class BaseHomeMonster : ModelAnimation
{
    public BaseHomeMonster(uint index, uint monterModelID, Vector3 position, Quaternion rotation, float size) :
        base(index, monterModelID, position, rotation, size)
    { 
    }

    public abstract void MoveTo(Vector3 position, float speed = 7);

    public abstract void ChangeToIdelState();

    public abstract void ChangeToTurnState();
}
