﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerModel : ModelAnimation
{
    protected enum ePlayerModelState
    {
        Load,
        Init,
        Idle,
        Fly,
        Xiuxian,
        Pose,
        Leave,
    }

    protected struct sRandomStruct
    {
        public ePlayerModelState Type;
        public int Min;
        public int Max;
        public sRandomStruct(ePlayerModelState type, int min, int max)
        {
            Type = type;
            Min = min;
            Max = max;
        }
    }

    private bool m_useRandomTime;
    private bool m_autoEnqueue;

    private float m_alpha;
    private float m_speed;
    private float m_calculagraph;
    private float m_randomTime;

    private Dictionary<int, sRandomStruct> m_randomDictionary;
    private Queue<int> m_animationQueue;

    #region 创建和销毁
    public PlayerModel(uint index, uint monterModelID,Vector3 position,Quaternion rotation,float size):
        base(index,monterModelID,position,rotation,size)
    {
        ChangeState(ePlayerModelState.Load);
    }

    public override void Release()
    {
        base.Release();
        m_randomTime = -1;
    }
    #endregion

    #region Initialization
    protected override void onInitialise()
    {
        m_useRandomTime = false;
        m_autoEnqueue = false;
        m_randomTime = -1;

        RegisterStateEvent();
        InitAnimationDictionary();
        InitRandomDictionary();
        InitQueue();
    }

    private void RegisterStateEvent()
    {
        RegistEnterEvent(ePlayerModelState.Load, onLoadEnter);
        RegistUpdateEvent(ePlayerModelState.Load, onLoadUpdate);

        RegistEnterEvent(ePlayerModelState.Init, onInitEnter);
        RegistUpdateEvent(ePlayerModelState.Init, onInitUpdate);
        RegistExitsEvent(ePlayerModelState.Init, onInitExits);

        RegistEnterEvent(ePlayerModelState.Idle, onCommonEnter);
        RegistUpdateEvent(ePlayerModelState.Idle, onCommonUpdate);
        RegistExitsEvent(ePlayerModelState.Idle, onCommonExits);

        RegistEnterEvent(ePlayerModelState.Fly, onCommonEnter);
        RegistUpdateEvent(ePlayerModelState.Fly, onCommonUpdate);
        RegistExitsEvent(ePlayerModelState.Fly, onCommonExits);

        RegistEnterEvent(ePlayerModelState.Xiuxian, onCommonEnter);
        RegistUpdateEvent(ePlayerModelState.Xiuxian, onCommonUpdate);
        RegistExitsEvent(ePlayerModelState.Xiuxian, onCommonExits);

        RegistEnterEvent(ePlayerModelState.Pose, onCommonEnter);
        RegistUpdateEvent(ePlayerModelState.Pose, onCommonUpdate);
        RegistExitsEvent(ePlayerModelState.Pose, onCommonExits);

        RegistEnterEvent(ePlayerModelState.Leave, onCommonEnter);
        RegistUpdateEvent(ePlayerModelState.Leave, onCommonUpdate);
        RegistExitsEvent(ePlayerModelState.Leave, onCommonExits);
    }

    private void InitAnimationDictionary()
    {
        AddAnimationDictionary(ePlayerModelState.Fly, "fly");
        AddAnimationDictionary(ePlayerModelState.Idle, "idle");
        AddAnimationDictionary(ePlayerModelState.Pose, "pose");
        AddAnimationDictionary(ePlayerModelState.Xiuxian, "xiuxian");
        AddAnimationDictionary(ePlayerModelState.Leave, "fei");
    }

    private void InitRandomDictionary()
    {
        if (m_randomDictionary == null)
            m_randomDictionary = new Dictionary<int, sRandomStruct>();

        m_randomDictionary.Add(0, new sRandomStruct(ePlayerModelState.Idle, 3, 4));
        m_randomDictionary.Add(1, new sRandomStruct(ePlayerModelState.Idle, 8, 9));
        m_randomDictionary.Add(2, new sRandomStruct(ePlayerModelState.Pose, 4, 4));
        m_randomDictionary.Add(3, new sRandomStruct(ePlayerModelState.Xiuxian, 4, 4));
        m_randomDictionary.Add(4, new sRandomStruct(ePlayerModelState.Leave, 4, 4));
    }

    private void InitQueue()
    {
        if (m_animationQueue == null)
            m_animationQueue = new Queue<int>();
        //m_animationQueue.Enqueue(2);
        //m_animationQueue.Enqueue(0);
        //m_animationQueue.Enqueue(3);
        m_animationQueue.Enqueue(2);
        //m_animationQueue.Enqueue(3);
        m_animationQueue.Enqueue(4);
    }
    #endregion

    #region Queue
    private void RandomQueue()
    {
        if (m_animationQueue == null)
            m_animationQueue = new Queue<int>();
        //else
        //    m_animationQueue.TrimExcess();
        
        int randomIndexLast = -1;
        if (m_animationQueue.Count != 0)
            randomIndexLast = m_animationQueue.Peek();

        int index = 0;
        while (index++ < 10)
        {
            int randomIndex;
            if (randomIndexLast == 1)
                randomIndex = Random.Range(2, 4);
            else
                randomIndex = 1;
            
            m_animationQueue.Enqueue(randomIndex);
            randomIndexLast = randomIndex;
        }
    }

    private int DeQueue(bool autoEnqueue)
    {
        if (autoEnqueue && m_animationQueue.Count == 1)
            RandomQueue();
        int index = -1;
        if (m_animationQueue.Count > 0)
            index = m_animationQueue.Dequeue();
        return index;
    }
    #endregion

    #region Loading Model
    protected override void LoadModelCompleted(GameObject o, params object[] args)
    {
        base.LoadModelCompleted(o, args);
        if (null == o)
        {
            return;
        }
        foreach (Material material in m_materialList)
        {
            material.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
            material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
        }

        string animationName = GetAnimationName(ePlayerModelState.Fly);
        if (!string.IsNullOrEmpty(animationName))
        {
            if (m_useRandomTime)
                m_animator.PlayAction(animationName);
            else
                m_animator.PlayAction(animationName, 1, false, onPlayEnd, 0);
        }
    }
    #endregion

    #region State Change
    private void ChangeRandomState()
    {
        int randomIndex = Random.Range(1, 3);
        ePlayerModelState currentState = (ePlayerModelState)GetCurrentState();
        if (currentState == m_randomDictionary[randomIndex].Type) //如果现在的状态和随机状态相同则去其他的
        {
            randomIndex += Random.Range(1, 2);
            randomIndex = ((randomIndex - 1) % 3) + 1;
        }
        sRandomStruct rs = m_randomDictionary[randomIndex];

        if (rs.Min == rs.Max)
            m_randomTime = rs.Min;
        else
            m_randomTime = Random.Range(rs.Min, rs.Max);
        ChangeState(rs.Type);
    }

    private void ChangeQueueState()
    {
        int index = DeQueue(m_autoEnqueue);
        if (index == -1)
        {
            Release();
            return;
        }
        sRandomStruct rs = m_randomDictionary[index];
        if (rs.Type == ePlayerModelState.Idle)
        {
            ChangeState(rs.Type, null);
            if (rs.Type == ePlayerModelState.Idle)
                m_randomTime = Random.Range(rs.Min, rs.Max);
        }
        else
            ChangeState(rs.Type, onPlayEnd);
    }

    protected override void ChangeState(System.Enum state, PlayOnceFinised callback = null, float fadeTime = 0.1f)
    {
        System.Enum tempState = GetCurrentState();
        if (tempState != null)
        {
            ePlayerModelState lastState = (ePlayerModelState)tempState;
            if (lastState == ePlayerModelState.Idle)
                fadeTime = 0.3f;
        }
        base.ChangeState(state, callback, fadeTime);
    }

    private void onPlayEnd(object[] args)
    {
        ChangeQueueState();
    }
    #endregion

    #region StateEvent
    void onLoadEnter()
    {
        Load();
        m_calculagraph = 0;
    }

    void onLoadUpdate()
    {
        if (m_loadCompleted)
        {
            m_animator.Update();

            float animationTime = m_animator.ActionTime;
            if (animationTime > 0)
            {
                m_speed = 4 / animationTime;
                ChangeState(ePlayerModelState.Init);
            }
        }
    }

    void onInitEnter()
    {
        
    }

    void onInitUpdate()
    {
        m_animator.Update();
        if (m_alpha == 1 && m_useRandomTime)
        {
            ChangeRandomState();
        }
        else
        {
            m_alpha += m_speed * Time.deltaTime;
            m_alpha = Mathf.Min(m_alpha, 1);
            for (int i = 0; i < m_materialList.Count; i++)
            {
                m_materialList[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
            }
        }
    }

    void onInitExits()
    {
        m_alpha = Mathf.Min(m_alpha, 1);
        for (int i = 0; i < m_materialList.Count; i++)
        {
            m_materialList[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alpha);
            m_materialList[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        }
    }

    void onCommonEnter()
    {
        m_calculagraph = 0;
    }

    void onCommonUpdate()
    {
        m_animator.Update();

        if (m_randomTime > -1)
        {
            m_calculagraph += Time.deltaTime;
            if (m_calculagraph > m_randomTime)
            {
                if (m_useRandomTime)
                    ChangeRandomState();
                else
                    ChangeQueueState();
            }
        }
    }

    void onCommonExits()
    {
        if(!m_useRandomTime)
            m_randomTime = -1;
    }
    #endregion
}
