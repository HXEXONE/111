﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;
using Network;
using Protocol;


//玩家角色属性类

public class AttrValue
{
    //获取属性值
    public static void GetAttrVec(ref stCharacterCard character, CAttrValueVec attrvec)
    {
        CAttrValueVec attrVec = attrvec;
        int key1 = LoginInit.GameGuardkey1;
        int key2 = LoginInit.GameGuardkey2;
        for (int i = 0, count = attrVec.Count; i < count; ++i)
        {
            switch ((EnumAttr)attrVec[i].uiKey)
            {
                case EnumAttr.ATTR_HP:
                    {
                        character.nMaxHp = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_MP: //精力
                    {
                        //服务端不需要同步精力值
                        //character.nMaxMp = (int)attrVec[i].uiValue;                       
                    }
                    break;
                case EnumAttr.ATTR_ATTACK: //攻击
                    {
                        character.nAttack = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_DEFENSE: //防御
                    {
                        character.nDefence = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_HIT: //命中
                    {
                        character.nHitRate = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_HITRATE: //命中率:
                    {
                        character.fHitRateAddition = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_DODGE: //闪避      
                    {
                        character.nDodge = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_DODGERATE: //闪避率     
                    {
                        character.fDodgeAddition = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_CRIT: //暴击
                    {
                        character.nBingo = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_CRITRATE: //暴击率
                    {
                        character.fBingoAddition = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_SPEED: //移动速度
                    {
                        character.fMoveSpeed = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_HPRECOVER: //生命恢复,百分比
                    {
                        character.fSecondHpRatePercent = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_MPRECOVER: //精力恢复
                    {
                        character.nSecondMpRate = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_CRITHURT: //暴击伤害   
                    {
                        character.fBingoDamage = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                        //character.fBingoDamage = character.fBingoDamage / 10000.0f;
                    }
                    break;
                case EnumAttr.ATTR_HURTREDUCE: //伤害减免
                    {
                        if (attrVec[i].uiValue > 0.8f)
                        {
                            attrVec[i].uiValue = 0.8f; //被动技能加成最多0.8 
                        }
                        attrVec[i].uiValue += 1; //基础值为1

                        character.fDamageRatio = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_HURTADD: //伤害增加
                    {
                        character.fDamagePromote = (1 + (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2));
                    }
                    break;
                case EnumAttr.ATTR_SUCKBLOOD: //吸血
                    {
                        character.fLifeSteal = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_DAMAGERETURN://伤害反弹
                    {
                        character.fDamageReflex = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_HPRECOVER_VALUE: //生命恢复固定值
                    {
                        character.nSecondHpRate = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_REPRESS_LEVEL: //压制的等级
                    {
                        character.nRepressLevel = (int)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_REPRESS_CRIT: //压制的暴击率
                    {
                        character.fRepressCrit = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
                case EnumAttr.ATTR_REPRESS_DAMAGE: //压制的伤害
                    {
                        character.fRepressDamage = (float)Common.EncryptNumber(attrVec[i].uiValue, key1, key2);
                    }
                    break;
            }
        }
    }


    /// <summary>
    /// 转换服务器发来属性:返回一系列属性结构列表.其中包括属性对应的guitextid/索引/显示的属性值等.
    /// </summary>
    /// <param name="attrVec">属性结构</param>
    /// <returns></returns>
    public static List<AttrInfo> AttrVecToStrList(CAttrValueVec attrVec)
    {
        List<AttrInfo> templist = new List<AttrInfo>();
        for (int i = 0, count = attrVec.Count; i < count; ++i)
        {
            AttrInfo info = new AttrInfo();
            if (attrVec[i].uiValue != 0)
            {
                switch ((EnumAttr)attrVec[i].uiKey)
                {
                    case EnumAttr.ATTR_HP:
                        {
                            info.index = 0;
                            info.guitextId = 9900001;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_MP: //精力
                        {
                            info.index = 1;
                            info.guitextId = 9900002;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_ATTACK: //攻击
                        {
                            info.index = 2;
                            info.guitextId = 9900003;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_DEFENSE: //防御
                        {
                            info.index = 3;
                            info.guitextId = 9900004;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_HIT: //命中
                        {
                            info.index = 4;
                            info.guitextId = 9900005;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_HITRATE: //命中率:百分比
                        {
                            info.index = 9;
                            info.guitextId = 9900006;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_DODGE: //闪避      
                        {
                            info.index = 5;
                            info.guitextId = 9900007;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_DODGERATE: //闪避率     :百分比
                        {
                            info.index = 10;
                            info.guitextId = 9900008;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_CRIT: //暴击
                        {
                            info.index = 6;
                            info.guitextId = 9900009;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_CRITRATE: //暴击率:百分比
                        {
                            info.index = 11;
                            info.guitextId = 9900010;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_SPEED: //移动速度
                        {
                            info.index = 8;
                            info.guitextId = 9900011;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_HPRECOVER: //生命恢复,百分比
                        {
                            info.index = 12;
                            info.guitextId = 9900012;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue ).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_MPRECOVER: //精力恢复,百分比
                        {
                            info.index = 13;
                            info.guitextId = 9900013;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_CRITHURT: //暴击伤害   ,百分比
                        {
                            info.index = 7;
                            info.guitextId = 9900014;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_HURTREDUCE: //伤害减免,百分比
                        {
                            info.index = 14;
                            info.guitextId = 9900015;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_HURTADD: //伤害增加,百分比
                        {
                            info.index = 15;
                            info.guitextId = 9900016;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_SUCKBLOOD: //吸血,百分比
                        {
                            info.index = 16;
                            info.guitextId = 9900017;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_DAMAGERETURN://伤害反弹,百分比
                        {
                            info.index = 17;
                            info.guitextId = 9900018;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_HPRECOVER_VALUE: //生命恢复固定值
                        {
                            info.index = 18;
                            info.guitextId = 9900019;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_REPRESS_LEVEL: //压制的等级
                        {
                            //info.index = 19;
                            //info.guitextId = 0;
                            //info.attrValue = attrVec[i].uiValue;
                            //info.attrStr = ((int)(attrVec[i].uiValue)).ToString();
                        }
                        break;
                    case EnumAttr.ATTR_REPRESS_CRIT: //压制的暴击率,百分比
                        {
                            info.index = 20;
                            info.guitextId = 9900020;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                    case EnumAttr.ATTR_REPRESS_DAMAGE: //压制的伤害,百分比
                        {
                            info.index = 21;
                            info.guitextId = 9900021;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrValue = attrVec[i].uiValue;
                            info.attrStr = (attrVec[i].uiValue).ToString("P");
                        }
                        break;
                }
                templist.Add(info);
            }
        }
        return templist;
    }

    /// <summary>
    /// 根据战力和等级 转换成属性的统一公式
    /// </summary>
    /// <param name="character">返回玩家的属性</param>
    /// <param name="gs">玩家战力</param>
    /// <param name="level">排名</param>
    public static void CalcAttrVec(ref stCharacterCard character, float gs, uint level)
    {
        character.nMaxHp = (int)(gs * (0.45f + 0.0006f * level));        //（战斗力*（0.4+0.0006*自己等级））
        character.nAttack = (int)(gs * (0.175f + 0.0002f * level));//int（战斗力*（0.125+0.00025*自己等级）-60）
        character.nDefence = (int)(gs * (0.145f + 0.00015f * level));//int（战斗力*（0.1+0.0002*自己等级）-60）
        character.nHitRate = (int)(gs * (0.02f - 0.000015 * level) + 30);                    //=int（战斗力*0.023+30）
        character.nDodge = (int)(gs * (0.02f - 0.000015 * level) + 30);                      //=int（战斗力*0.023+30）
        character.nBingo = (int)(gs * 0.034f + 15);                     //=int（战斗力*0.028+30）
    }

    /// <summary>
    /// 竞技场计算伙伴属性(由于竞技场玩家和主角属性存在加成,所有伙伴属性需要重新计算.)
    /// </summary>
    /// <param name="attvalue">伙伴属性</param>
    /// <param name="character">玩家角色卡</param>
    /// <param name="partnerload">伙伴数据表</param>
    /// <param name="starlevel">伙伴星级</param>
    public static void CalcPartnerAttrVec(ref CAttrValueVec attvaluevec, stCharacterCard character, PartenrContent partnerload,
        uint starlevel)
    {
        CAttrValue att = new CAttrValue();
        att.uiKey = 0;
        att.uiValue = (partnerload.Hp[(int)starlevel - 1] / 10000F) * character.nMaxHp;
        attvaluevec[(int)(att.uiKey)] = att;
        att = new CAttrValue();
        att.uiKey = 2;
        att.uiValue = (partnerload.Attack[(int)starlevel - 1] / 10000F) * character.nAttack;
        attvaluevec[(int)(att.uiKey)] = att;
        att = new CAttrValue();
        att.uiKey = 3;
        att.uiValue = (partnerload.Defense[(int)starlevel - 1] / 10000F) * character.nDefence;
        attvaluevec[(int)(att.uiKey)] = att;
    }
}

public struct stCharacterCard
{
    public int nAttack;//攻击
    public int nDefence;//防御
    public int nMaxHp;//最大血量
    /*public int nMaxMp;//最大精力*/
    public int nHitRate;//命中
    public float fHitRateAddition;//命中率加成
    public int nDodge;//闪避
    public float fDodgeAddition;//闪避率加成
    public int nBingo;//暴击
    public float fBingoAddition;//暴击率加成
    public float fBingoDamage;//暴击伤害
    public float fMoveSpeed;  //移动速度  (run速度)
    public float fWalkSpeed; // walk速度
    public int nSecondHpRate;//秒回
    public float fSecondHpRatePercent; //秒回百分比
    public int nSecondMpRate;//精回
    public float fDamageRatio;//伤害系数
    public float fDamagePromote;//伤害增加( > 1 )
    public float fDamageAddHp;//伤害转血( >1)
    public float fLifeSteal;//吸血    
    public float fDamageReflex;//伤害反弹
    public float fStun;
    public float fInvincible;
    public float fOverold;
    public float fHide;
    public float fFrost;
    public float fChangeAtkSpeed; //普攻速度
    public int nRepressLevel; //压制的等级
    public float fRepressCrit; //压制的暴击率
    public float fRepressDamage; //压制的总伤害    
    /*************/
    //硬直,客户端暂不用
    /**************/
    //public int nDarkResis;//黑暗抗性
    //public int nLightningResis;//闪电抗性
    //public int nFireResis;//火焰抗性
    //public int nColdResis;//寒冰抗性
    //public int nSunResis;//光明抗性


    public stCharacterCard(float damageRatio)
    {
        nAttack = 0;//攻击
        nDefence = 0;//防御
        nMaxHp = 0;//最大血量
        nHitRate = 0;//命中
        fHitRateAddition = 0;//命中率加成
        nDodge = 0;//闪避
        fDodgeAddition = 0;//闪避率加成
        nBingo = 0;//暴击
        fBingoAddition = 0;//暴击率加成
        fBingoDamage = 0;//暴击伤害
        fMoveSpeed = 0;  //移动速度  (run速度)
        fWalkSpeed = 0; // walk速度
        nSecondHpRate = 0;//秒回
        fSecondHpRatePercent = 0; //秒回百分
        nSecondMpRate = 0;//精回
        fDamageRatio = damageRatio;//伤害减免(-,+)
        fDamagePromote = 0;//伤害增加( > 1 )
        fDamageAddHp = 0;//伤害转血( >1)
        fLifeSteal = 0;//吸血    
        fDamageReflex = 0;//伤害反弹
        nRepressLevel = 0;
        fRepressCrit = 0;
        fRepressDamage = 0;
        fStun = 0;
        fInvincible = 0;
        fOverold = 0;
        fHide = 0;
        fFrost = 0;
        fChangeAtkSpeed = 0; //普攻速度
    }

    public static stCharacterCard operator +(stCharacterCard cardA, stCharacterCard cardB)
    {
        stCharacterCard card;

        card.nAttack = cardA.nAttack + cardB.nAttack;
        card.nDefence = cardA.nDefence + cardB.nDefence;
        card.nMaxHp = cardA.nMaxHp + cardB.nMaxHp;
        card.nHitRate = cardA.nHitRate + cardB.nHitRate;
        card.fHitRateAddition = cardA.fHitRateAddition + cardB.fHitRateAddition;
        card.nDodge = cardA.nDodge + cardB.nDodge;
        card.fDodgeAddition = cardA.fDodgeAddition + cardB.fDodgeAddition;
        card.nBingo = cardA.nBingo + cardB.nBingo;
        card.fBingoAddition = cardA.fBingoAddition + cardB.fBingoAddition;

        float moveSpeed = cardA.fMoveSpeed + cardB.fMoveSpeed;
        card.fMoveSpeed = moveSpeed < 0 ? 0 : moveSpeed;

        float walkSpeed = cardA.fWalkSpeed + cardB.fWalkSpeed;
        card.fWalkSpeed = walkSpeed < 0 ? 0 : walkSpeed;

        card.nSecondHpRate = cardA.nSecondHpRate + cardB.nSecondHpRate;
        card.fSecondHpRatePercent = cardA.fSecondHpRatePercent + cardB.fSecondHpRatePercent;
        card.nSecondMpRate = cardA.nSecondMpRate + cardB.nSecondMpRate;
        //card.fDamageReduce =  Mathf.Clamp01(1 -  (1- cardA.fDamageReduce) * ( 1 - cardB.fDamageReduce));
        card.fDamageRatio = cardA.fDamageRatio * cardB.fDamageRatio;
        card.fDamagePromote = Mathf.Max(cardA.fDamagePromote, 1f) * Mathf.Max(cardB.fDamagePromote, 1f);
        card.fDamageAddHp = Mathf.Max(cardA.fDamageAddHp, 1f) * Mathf.Max(cardB.fDamageAddHp, 1f);
        card.fLifeSteal = cardA.fLifeSteal + cardB.fLifeSteal;
        card.fDamageReflex = cardA.fDamageReflex + cardB.fDamageReflex;
        card.nRepressLevel = cardA.nRepressLevel + cardB.nRepressLevel;
        card.fRepressCrit = cardA.fRepressCrit + cardB.fRepressCrit;
        card.fRepressDamage = cardA.fRepressDamage + cardB.fRepressDamage;

        card.fBingoDamage = cardA.fBingoDamage + cardB.fBingoDamage;
        card.fStun = cardA.fStun + cardB.fStun;
        card.fFrost = cardA.fFrost + cardB.fFrost;
        card.fChangeAtkSpeed = cardA.fChangeAtkSpeed + cardB.fChangeAtkSpeed;
        card.fInvincible = cardA.fInvincible + cardB.fInvincible;
        card.fOverold = cardA.fOverold + cardB.fOverold;
        card.fHide = cardA.fHide + cardB.fHide;

        return card;
    }

    //加密
    public stCharacterCard Encrypt()
    {
        stCharacterCard card;
        int key1 = LoginInit.GameGuardkey1;
        int key2 = LoginInit.GameGuardkey2;
        card.nAttack = (int)Common.EncryptNumber(nAttack, key1, key2);
        card.nDefence = (int)Common.EncryptNumber(nDefence, key1, key2);
        card.nMaxHp = (int)Common.EncryptNumber(nMaxHp, key1, key2);
        card.nHitRate = (int)Common.EncryptNumber(nHitRate, key1, key2);
        card.fHitRateAddition = (float)Common.EncryptNumber(fHitRateAddition, key1, key2);
        card.nDodge = (int)Common.EncryptNumber(nDodge, key1, key2);
        card.fDodgeAddition = (float)Common.EncryptNumber(fDodgeAddition, key1, key2);
        card.nBingo = (int)Common.EncryptNumber(nBingo, key1, key2);
        card.fBingoAddition = (float)Common.EncryptNumber(fBingoAddition, key1, key2);
        card.fBingoDamage = (float)Common.EncryptNumber(fBingoDamage, key1, key2);
        card.fMoveSpeed = (float)Common.EncryptNumber(fMoveSpeed, key1, key2);
        card.fWalkSpeed = fWalkSpeed;
        card.nSecondHpRate = (int)Common.EncryptNumber(nSecondHpRate, key1, key2);
        card.fSecondHpRatePercent = (float)Common.EncryptNumber(fSecondHpRatePercent, key1, key2);
        card.nSecondMpRate = nSecondMpRate;
        card.fDamageRatio = (float)Common.EncryptNumber(fDamageRatio, key1, key2);
        card.fDamagePromote = (float)Common.EncryptNumber(fDamagePromote, key1, key2);
        card.fDamageAddHp = fDamageAddHp;
        card.fLifeSteal = (float)Common.EncryptNumber(fLifeSteal, key1, key2);
        card.fDamageReflex = (float)Common.EncryptNumber(fDamageReflex, key1, key2);
        card.nRepressLevel = (int)Common.EncryptNumber(nRepressLevel, key1, key2);
        card.fRepressCrit = (float)Common.EncryptNumber(fRepressCrit, key1, key2);
        card.fRepressDamage = (float)Common.EncryptNumber(fRepressDamage, key1, key2);
        card.fStun = fStun;
        card.fInvincible = fInvincible;
        card.fOverold = fOverold;
        card.fHide = fHide;
        card.fFrost = fFrost;
        card.fChangeAtkSpeed = fChangeAtkSpeed;


        return card;
    }

    //解密
    public stCharacterCard Decode()
    {
        stCharacterCard card;
        int key1 = LoginInit.GameGuardkey1;
        int key2 = LoginInit.GameGuardkey2;
        card.nAttack = (int)Common.DecodeNumber(nAttack, key1, key2);
        card.nDefence = (int)Common.DecodeNumber(nDefence, key1, key2);
        card.nMaxHp = (int)Common.DecodeNumber(nMaxHp, key1, key2);
        card.nHitRate = (int)Common.DecodeNumber(nHitRate, key1, key2);
        card.fHitRateAddition = (float)Common.DecodeNumber(fHitRateAddition, key1, key2);
        card.nDodge = (int)Common.DecodeNumber(nDodge, key1, key2);
        card.fDodgeAddition = (float)Common.DecodeNumber(fDodgeAddition, key1, key2);
        card.nBingo = (int)Common.DecodeNumber(nBingo, key1, key2);
        card.fBingoAddition = (float)Common.DecodeNumber(fBingoAddition, key1, key2);
        card.fBingoDamage = (float)Common.DecodeNumber(fBingoDamage, key1, key2);
        card.fMoveSpeed = (float)Common.DecodeNumber(fMoveSpeed, key1, key2);
        card.fWalkSpeed = fWalkSpeed;
        card.nSecondHpRate = (int)Common.DecodeNumber(nSecondHpRate, key1, key2);
        card.fSecondHpRatePercent = (float)Common.DecodeNumber(fSecondHpRatePercent, key1, key2);
        card.nSecondMpRate = nSecondMpRate;
        card.fDamageRatio = (float)Common.DecodeNumber(fDamageRatio, key1, key2);
        card.fDamagePromote = (float)Common.DecodeNumber(fDamagePromote, key1, key2);
        card.fDamageAddHp = fDamageAddHp;
        card.fLifeSteal = (float)Common.DecodeNumber(fLifeSteal, key1, key2);
        card.fDamageReflex = (float)Common.DecodeNumber(fDamageReflex, key1, key2);
        card.nRepressLevel = (int)Common.DecodeNumber(nRepressLevel, key1, key2);
        card.fRepressCrit = (float)Common.DecodeNumber(fRepressCrit, key1, key2);
        card.fRepressDamage = (float)Common.DecodeNumber(fRepressDamage, key1, key2);
        card.fStun = fStun;
        card.fInvincible = fInvincible;
        card.fOverold = fOverold;
        card.fHide = fHide;
        card.fChangeAtkSpeed = fChangeAtkSpeed;
        card.fFrost = fFrost;


        return card;
    }

    //card1 加密前的card
    //card2 加密后的card
    public static bool IsNumberAccordFormula(stCharacterCard card1, stCharacterCard card2)
    {
        int key1 = LoginInit.GameGuardkey1;
        int key2 = LoginInit.GameGuardkey2;

        if (!Common.IsNumberAccordFormula(card1.nAttack, card2.nAttack, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.nDefence, card2.nDefence, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.nMaxHp, card2.nMaxHp, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.nHitRate, card2.nHitRate, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fHitRateAddition, card2.fHitRateAddition, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.nDodge, card2.nDodge, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fDodgeAddition, card2.fDodgeAddition, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.nBingo, card2.nBingo, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fBingoAddition, card2.fBingoAddition, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fBingoDamage, card2.fBingoDamage, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fMoveSpeed, card2.fMoveSpeed, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fDamageRatio, card2.fDamageRatio, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fDamagePromote, card2.fDamagePromote, key1, key2))
        {
            return false;
        }
        if (!Common.IsNumberAccordFormula(card1.fLifeSteal, card2.fLifeSteal, key1, key2))
        {
            return false;
        }

        if (!Common.IsNumberAccordFormula(card1.fDamageReflex, card2.fDamageReflex, key1, key2))
        {
            return false;
        }

        if (!Common.IsNumberAccordFormula(card1.nRepressLevel, card2.nRepressLevel, key1, key2))
        {
            return false;
        }

        if (!Common.IsNumberAccordFormula(card1.fRepressCrit, card2.fRepressCrit, key1, key2))
        {
            return false;
        }

        if (!Common.IsNumberAccordFormula(card1.fRepressDamage, card2.fRepressDamage, key1, key2))
        {
            return false;
        }


        return true;
    }
}


public class AttrInfo
{
    public int index;//索引
    public uint guitextId;//对应GUIText表中的ID,用于UI翻译属性
    public double attrValue;//属性值
    public string attrStr;//属性值表现形式
}