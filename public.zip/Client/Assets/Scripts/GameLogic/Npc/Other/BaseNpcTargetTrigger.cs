﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BaseNpcTargetTrigger : MonoBehaviour
{
    public CBaseNpc m_myNpc;
    private SphereCollider m_Collider;

    void Awake()
    {
        m_Collider = gameObject.AddComponent<SphereCollider>();
        m_Collider.isTrigger = true;
    }

    void Start()
    {

    }

    public float Radius
    {
        get { return m_Collider.radius; }
        set
        {
            if (m_Collider != null)
            {
                m_Collider.radius = value;
            }
        }

    }

    //进入NPC的攻击判定范围内
    void OnTriggerEnter(Collider other)
    {
        if (null == m_myNpc)
        {
            return;
        }
        int layer = other.gameObject.layer;
        if (layer != DEFINE.NPC_TRIGGER_LAYER)
        {
            return;
        }
        string rootName = other.transform.root.name;
        int index = 0;
        if (!int.TryParse(rootName, out index))
        {
            return;
        }
        uint uiIndex = (uint)index;
        CBaseNpc ptarget = SingletonObject<BattleScene>.GetInst().GetNpc(uiIndex);
        if (ptarget != null)
        {
            m_myNpc.NpcEnterRange(ptarget);
        }
    }

    //离开NPC的攻击判定范围
    void OnTriggerExit(Collider other)
    {
        if (null == m_myNpc)
        {
            return;
        }
        int layer = other.gameObject.layer;
        if (layer != DEFINE.NPC_TRIGGER_LAYER)
        {
            return;
        }

        string rootName = other.transform.root.name;
        int index = 0;
        if (!int.TryParse(rootName, out index))
        {
            return;
        }
        uint uiIndex = (uint)index;

        CBaseNpc ptarget = SingletonObject<BattleScene>.GetInst().GetNpc(uiIndex);
        if (ptarget != null)
        {
            m_myNpc.NpcLeaveRange(ptarget);
        }
    }

}