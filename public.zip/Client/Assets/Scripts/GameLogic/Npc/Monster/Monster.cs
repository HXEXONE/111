using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Monster : CBaseNpc
{
    protected MonsterContent m_pMonsterLoader;

    private GameObject m_escapeDestObj;//�����жϹ������ܷ���
    private GameObject m_partsObj; //��������(��:���ڵĵ���)

    private Timer m_bemusedTimer;//����1��������

    private uint m_npcID;

    private bool m_useSpecifyShader = false;

    private float m_reColorSpeed = 5;    //�ܻ��ظ�������״̬���ٶ�

    private Color m_hitColor = new Color(0,0,0,0);  //�ܻ��˺�
    private Color m_specifyColor;

    private eHitStyle m_hitStyle;  //�ܻ�����

    private Material m_shadowMat;

    private CObject m_texture2D;
    private CObject m_partsTexture; 

    private bool m_resetMaterialMonster = false;

    private Renderer[] m_renderers;
    private Material[] m_tempMaterials;

    private bool m_shapeShift = false;

    CPanel m_cpGuidePanel   =   null;

    private CBaseNpc m_pSummoner = null;  //�ٻ��ߡ�������    
    private SummonerType m_eSummonerType;
    private CSkillupInfo m_pAllySkillupInfo = null; //�Ѿ����ܵȼ���Ϣ
    public float[] m_attrInheritList = new float[3];

    //$Ѫ���ٷֱ�$�����ٷֱ�$�����ٷֱ�
    public float[] AttrInheritList
    {
        set { m_attrInheritList = value; }
    }

    bool m_bStartUpdate = false;

    private bool m_loadCompleteFadeAlpha = true;  //����MeshRenderer�ķǶ�̬����ĵ�����ǣ�falseΪ�Ƕ�̬����
    
    private bool m_bShowGuide = false;

    private BattlePveHp m_TeamPveInfo;     //�ŶӸ���Ѫ����Ϣ

    private float m_fWalkSpeed; //walk�ٶ�

    private object m_lockObjectBossAppear = new object();

    private Material m_specifyMaterial = null; //������ʬ�Ĳ���
    public Material SpecifyMaterial
    {
        get { return m_specifyMaterial; }
    }

    private MultiPveLogic m_pMultiPveLogic = null;

    public static bool AppearBoss = false;

    private string m_bornArea;//��������

    public override bool Init(BattleScene battlescene, uint index, uint uiNpcID, ushort wLevel, eNpcSort sort, Vector3 position, Quaternion rotation, string tag, List<int> ExtraAiList, List<int> ExtraSkillList)
    {
        m_pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(uiNpcID);
        if (m_pMonsterLoader == null)
        {
            MyLog.LogError("can't find Monster:" + uiNpcID);
            return false;
        }

        m_pMultiPveLogic = new MultiPveLogic(this);
        m_npcGroup = (eNpcGroup)m_pMonsterLoader.NpcGroup;

        m_bemusedTimer = new Timer();

        WeaponID = (uint)m_pMonsterLoader.WeaponID;

        m_TeamPveInfo = null;

        if (m_pMonsterLoader.Sort == (byte)eNpcSortType.Ally)
        {
            sort = eNpcSort.Ally; //�ٻ����Ѿ� �� �ٻ���groupһ��
            if (m_pSummoner != null)
                m_npcGroup = m_pSummoner.NpcGroup;
            else
                m_npcGroup = eNpcGroup.Justice;
        }
        else if (m_pMonsterLoader.Sort == (byte)eNpcSortType.Mechanism)
        {
            sort = eNpcSort.Mechanism;
        }
        else
        {
            sort = eNpcSort.Monster;
        }
        if (sort != eNpcSort.Mechanism)
            m_fWalkSpeed = m_pMonsterLoader.WalkMoveSpeed[1];

        m_unitsType = (eNpcUnitsType)m_pMonsterLoader.ModelLoader.UnitsType; //��������
        m_eSummonerType = SummonerType.None;

        return base.Init(battlescene, index, uiNpcID, wLevel, sort, position, rotation, tag, ExtraAiList,ExtraSkillList);
    }

     protected override void InitCharacterCard(ushort wLevel)
     {
         base.InitCharacterCard(wLevel);

        //�Ѿ��̳��ٻ��ߵ�����
         if (null != m_pSummoner && NpcSortType == eNpcSortType.Ally)
         {
             m_nHp = 100;
             m_pOriginCard = m_pSummoner.CharacterCard;                                       
         }
         else
         {
             if (m_pBattleScene.BattleType == eBattleType.ClimbTower)
             {
                 int layer = TowerManager.GetInst().CurrentLayerNumber;//��ǰ����
                 TowerAwardContent tac = HolderManager.m_TowerAwardHolder.GetStaticInfo(layer);
                 if(tac != null)
                 {
                     int attrID = tac.MonsterBuff;
                     AttrContent ac = HolderManager.m_AttrHolder.GetStaticInfo(attrID);
                     if(ac != null)
                     {
						m_pOriginCard.nMaxHp  = GetTowerAttr(ac.MaxHpList, 3000, layer);
						m_nHp = m_pOriginCard.nMaxHp;
                        m_pOriginCard.nAttack = GetTowerAttr(ac.AttackList, 1000,layer);
                        m_pOriginCard.nDefence = GetTowerAttr(ac.DefenceList, 800, layer);
                        m_pOriginCard.nHitRate = GetTowerAttr(ac.HitRateList, 200, layer);
                        m_pOriginCard.nDodge = GetTowerAttr(ac.DodgeList, 200, layer);
                        m_pOriginCard.nBingo = GetTowerAttr(ac.BingoList, 250, layer);
                     }
                  
                 }
               
             }
             else
             {
                 m_nHp = InitAttr(m_pMonsterLoader.Hp, wLevel);
                 m_pOriginCard.nMaxHp = m_nHp;
                 //m_pOriginCard.nThew = InitAttr(m_pMonsterLoader.GetThew(), byLevel);
                 m_pOriginCard.nAttack = InitAttr(m_pMonsterLoader.Attack, wLevel);
                 m_pOriginCard.nDefence = InitAttr(m_pMonsterLoader.Defence, wLevel);
                 m_pOriginCard.nHitRate = InitAttr(m_pMonsterLoader.HitRate, wLevel);
                 m_pOriginCard.nDodge = InitAttr(m_pMonsterLoader.Dodge, wLevel);
                 m_pOriginCard.nBingo = InitAttr(m_pMonsterLoader.Bingo, wLevel);

             }


             m_pOriginCard.fMoveSpeed = m_pMonsterLoader.WalkMoveSpeed[0];
             m_pOriginCard.fWalkSpeed = m_fWalkSpeed;//m_pMonsterLoader .GetWalkSpeed();
         }

         m_pCard = m_pOriginCard;

         if (m_pBattleScene.BattleType == eBattleType.ClimbTower)
         {
             if (m_pMonsterLoader.Sort == (byte)eNpcSortType.LeaderMonster)
             {
                 AddBuff(7201);
             }
             else if (m_pMonsterLoader.Sort == (byte)eNpcSortType.EliteMonster)
             {
                 AddBuff(7202);
             }
             else if (m_pMonsterLoader.Sort == (byte)eNpcSortType.ChapterBoss)
             {
                 AddBuff(7203);
             }
         }

     }

    //��������=��������*��1+buff*�ؾ�������
    //baseAttr,����ֵ
     private int GetTowerAttr(List<int> list,int nBaseAttr, int layer)
     {
         if (list.Count != 4)
         {
             return 0;
         }
         byte byAttrMode = MyConvert_Convert.ToByte(list[0]);
         int nValue = list[1];
         //int nBeforeValue = list[2];//ת��ǰ����
         //int nAfterValue = list[3];//ת��������

         double nResult = 0;
		int resultAttr = 0;

         switch ((eAttrMode)byAttrMode)
         {
             case eAttrMode.Percent:
                 {
                     nResult = (double)(nValue / 10000.0f);
					 resultAttr = (int)(nBaseAttr * (1 + nResult * layer));
                 }
                 break;
             case eAttrMode.Value:
                 {
                     nResult = nValue;
					 resultAttr = (int)(nBaseAttr + nResult * layer);
                 }
                 break;
             case eAttrMode.Translate:
                 {
                 }
                 break;
         }

         return resultAttr;
     }

    protected override void CreateNpc(Vector3 position, Quaternion rotation,bool replace = false)
    {
        string szPath = m_pMonsterLoader.ModelLoader.Path;
        //szPath = "resources/npc/nv.x";
        m_pNpcObj = new CObject(szPath);

        //m_pNpcObj.Layer = NpcSort == eNpcSort.Ally ? DEFINE.ALLY_LAYER : DEFINE.MONSTER_LAYER;
        //m_pNpcObj.Layer = DEFINE.MONSTER_LAYER;
        switch (NpcSort)
        {
            case eNpcSort.Monster:
                {
                    m_pNpcObj.Layer = DEFINE.MONSTER_LAYER;
                    m_nLayer = DEFINE.MONSTER_LAYER;
                }
                break;
            case eNpcSort.Ally:
                {
                    m_pNpcObj.Layer = DEFINE.ALLY_LAYER;
                    m_nLayer = DEFINE.ALLY_LAYER;
                }
                break;
            case eNpcSort.Mechanism:
                {
                    m_pNpcObj.Layer = DEFINE.MECHANISM_LAYER;
                    m_nLayer = DEFINE.MECHANISM_LAYER;
                }
                break;
            default:
                break;
        }
        
        m_pNpcObj.Name = m_uiIndex.ToString();
        m_pNpcObj.CallBack = LoadNpcCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = replace ? eObjectType.ReplaceModel : eObjectType.Npc;

        if (m_npcGroup != eNpcGroup.GameStory)
        {
            Ray ray = new Ray(position + Vector3.up * 5, Vector3.down);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 100, 1 << DEFINE.TERRAINLAYER))
            {
                position = new Vector3(position.x, hit.point.y, position.z) + Vector3.up;
            }
        }

        m_pNpcObj.BornPosition = position;
        m_pNpcObj.BornRotation = rotation;

        //if (NpcSort != eNpcSort.Mechanism)
        //    m_pNpcObj.LoadObject();
        //else
        //{
        //    if (!m_pNpcObj.Path.Equals("0"))
        //    {
        //        m_pNpcObj.LoadObject();
        //    }
        //    else
        //    {
        //        GameObject mechanism = new GameObject();
        //        LoadNpcCompleted(mechanism, null);
        //    }
        //}

        CreateTexture(replace);
        //m_pathFindingBlurry = 1.0f;//�����ߵ�ģ����
    }

    private void CreateTexture(bool replace = false)
    {
        //MyLog.LogError("  CreateTexture ...  ");
        string path = "";
        if (m_pMonsterLoader.ModelLoader != null)
            path = m_pMonsterLoader.ModelLoader.TextureName;
        if (path.Equals("0") || replace )
        {
            if (NpcSort != eNpcSort.Mechanism)
            {
                LoadHelp.LoadObject("", m_pMonsterLoader.ModelLoader.AniPath, ThreadPriority.Normal, PreloadAnimatorCompleted);
            }
            else
            {
                if (!m_pNpcObj.Path.Equals("0"))
                {
                    LoadHelp.LoadObject("", m_pMonsterLoader.ModelLoader.AniPath, ThreadPriority.Normal, PreloadAnimatorCompleted);
                }
                else
                {
                    GameObject mechanism = new GameObject();
                    LoadNpcCompleted(mechanism, null);
                }
            }
        }
        else
        {
            m_texture2D = new CObject(path);
            m_texture2D.IsMemoryFactory = true;
            m_texture2D.ObjectType = eObjectType.Texture;
            m_texture2D.CallBack = LoadTextureCompleted;
            m_texture2D.Args = new object[]{path};
            m_texture2D.LoadObject();
        }
    }

    //���ؾ����������ˢ����,�������Ԥ���ض������ַ��治̫��Ȼ
    private void PreloadAnimatorCompleted(string interim, UnityEngine.Object asset)
    {
        m_pNpcObj.LoadObject();
    }

    protected void LoadTextureCompleted(GameObject o, params object[] args)
    {
        if (m_texture2D == null || m_texture2D.PTexture2D == null)
            MyLog.LogError("Can not find Texture ,Path = " + args[0]);


        if (NpcSort != eNpcSort.Mechanism)
            LoadHelp.LoadObject("", m_pMonsterLoader.ModelLoader.AniPath, ThreadPriority.Normal, PreloadAnimatorCompleted);
        else
        {
            if (!m_pNpcObj.Path.Equals("0"))
            {
                LoadHelp.LoadObject("", m_pMonsterLoader.ModelLoader.AniPath, ThreadPriority.Normal, PreloadAnimatorCompleted);
            }
            else
            {
                GameObject mechanism = new GameObject();
                LoadNpcCompleted(mechanism, null);
            }
        }
    }

    protected override void LoadAI()
    {
        base.LoadAI();

        if (m_pAI != null && m_pMonsterLoader != null)
        {
            //Dictionary<uint, uint> skillDict = new Dictionary<uint, uint>();
            Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();

            List<int> skillList = m_pMonsterLoader.Skilllist;
            for(int i =0,count = skillList.Count;i < count;++i)
            {
                skillDict.Add(skillList[i],null);
            }
            m_pAI.SetAI((uint)m_pMonsterLoader.BaseAI, m_pMonsterLoader.AIex, skillDict);
        }
    }

    public void AddAI(List<int> aiList)
    {
        if (m_pAI != null && aiList != null)
        {
            m_pAI.AddAI(aiList);
        }
    }

    public void AddSkill(List<int> skillList)
    {
        if (m_pAI != null && skillList != null)
        {
            m_pAI.AddSkill(skillList);
        }
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        //MyLog.Log(" LoadNpcCompleted : " + m_pMonsterLoader.GetKey());
        if (o == null)
        {
            m_pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(DEFINE.REPLACE_MONSTER_LOADER_KEY);
            m_pMonsterLoader = m_pMonsterLoader;

            CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation,true);

            //SingletonObject<BattleScene>.GetInst().RemoveMonsterIndex(m_uiIndex, this);
            //if (args.Length > 0)
                //MyLog.LogError("LoadHelp is " + args[0]);
			return;
        }

        //���ͱ��
        m_modelSize = m_pMonsterLoader.ChangeSize;
        o.transform.localScale = Vector3.one * m_modelSize;

        eNpcSortType type = (eNpcSortType)m_pMonsterLoader.Sort;
        if (type == eNpcSortType.ChapterBoss || type == eNpcSortType.WorldBoss || 
            type == eNpcSortType.EliteMonster || type == eNpcSortType.NormalMonster ||
            type == eNpcSortType.LeaderMonster || type == eNpcSortType.SociatyBoss || 
            type == eNpcSortType.Turret)
            m_resetMaterialMonster = true;

        m_specifyColor = ((MonsterContent)m_pMonsterLoader).ShaderColor;

        base.LoadNpcCompleted(o, args);

        if (!ClientMain.GetInst().EnterTestScene)
        {
            if (NpcSortType == eNpcSortType.WorldBoss)
            {
                this.SetHp(SingletonObject<WorldBossManager>.GetInst().m_stbfChallengeBossinfo.uiBossRemainHp);
            }
        }

        if (CurrBattleScene.BattleType == eBattleType.TeamPve)
        {
            List<BattlePveHp> hpList = SingletonObject<BattlePveManager>.GetInst().HpList;
            for (int i = 0, len = hpList.Count; i < len; i++ )
            {
                BattlePveHp hpInfo = hpList[i];
                if (m_pMonsterLoader.Key == hpInfo.uiNpcTypeID)
                {
                    if (hpInfo.bSetHp)
                        continue;                    
                    
                    this.SetHp(hpInfo.nHp);
                    hpInfo.bSetHp = true;

                    m_TeamPveInfo = hpInfo;

                    //if (hpInfo.nHp == 0)
                    //{                        
                    //    ShowNpc(false);
                    //    NpcDead(true);
                    //    //Release(eObjectDestroyType.Memory);
                    //    //return;                        
                    //}
                    break;
                }                
            }
        }

        if (m_npcSort != eNpcSort.Mechanism)
        {
            #region
            m_birthActID = (uint)m_pMonsterLoader.ModelLoader.BirthActID;
            m_unBirthActID = (uint)m_pMonsterLoader.ModelLoader.UnBirthActID;
            m_loadCompleteFadeAlpha = m_unBirthActID == 0;
            //���س�����Ч
            //if (!IsChest() && !CBaseStory.IsInGameStory)
            //{
            //    //CreateParticle(DEFINE.MONSTER_BRON_PARTICLED);
            //}

            //��������
            if (IsBoss())
            {
                CMusicManager.GetInst().CreateMusic(DEFINE.BOSS1_BACKGOUND_SOUNDID);
                //���ͻ��˵���BOSS���ֵ���Ϣ
                //SingletonObject<BossShowMediator>.GetInst().Open();
            }

            if (m_resetMaterialMonster)
            {
                //m_smr = m_myTrans.GetComponentsInChildren<SkinnedMeshRenderer>(true);
                m_mrs = m_myTrans.GetComponentsInChildren<MeshRenderer>(true);

                if (m_smr != null && m_smr.Length > 0)
                {
                    //for (int i = 0; i < m_smr.Length; i++)
                    //{
                    //    if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    //    {
                    //        Materials = m_smr[i].materials;
                    //        break;
                    //    }
                    //}
                    
                    if (m_materiaslCount > 0)
                    {
                        //int shaderIndex = ((MonsterContent)m_pMonsterLoader).GetShaderIndex();
                        m_useSpecifyShader = ResetShader(m_specifyColor, Materials);
                        if (!m_useSpecifyShader) //�����������ʲ���Ҫ���ɹ�ͬ����
                        {
                            if (IsBoss() || CGameConfig.GetInst().OpenMonsterFade)
                            {
                                for (int i = 0; i < m_materiaslCount; i++)
                                {
                                    if (Materials[i] != null)
                                    {
                                        Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                                        Materials[i].SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                                    }
                                }
                            }
                            else
                            {
                                BattleScene bs = SingletonObject<BattleScene>.GetInst();
                                Material mat = bs.GetMonsterCommonMaterial(m_uiNpcType, false);
                                if (mat == null)
                                {
                                    for (int i = 0; i < m_smr.Length; i++)
                                    {
                                        if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                                        {
                                            mat = m_smr[i].material;
                                            break;
                                        }
                                    }
                                    
                                    mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                                    mat.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                                    bs.AddMonsterCommonMaterial(m_uiNpcType, false, mat);
                                }
                                ChangeSkinMeshRenderMaterialToCommon(mat);
                            }
                        }
                        if (Materials[0] != null)
                        {
                            m_specifyMaterial = new Material(Materials[0]);
                            m_specifyMaterial.CopyPropertiesFromMaterial(Materials[0]);
                            m_currShaderName = Materials[0].shader.name;
                        }
                    }
                }
                else  //������Ǽ���Ҳ����Ҫ�滻�ɹ�ͬ����
                {
                    m_loadCompleteFadeAlpha = false;
                    MeshRenderer[] mrs = m_myTrans.GetComponentsInChildren<MeshRenderer>(true);

                    List<Material> mats = new List<Material>();
                    if (mrs != null)
                    {
                        for (int i = 0, len = mrs.Length; i < len; i++)
                        {
                            if (mrs[i].name != "shadow")
                            {
                                mats.AddRange(mrs[i].materials);
                            }
                        }
                        InitMaterials(mats);
                        //mats.CopyTo(Materials);
                        if (m_materiaslCount > 0)
                        {
                            m_useSpecifyShader = ResetShader(m_specifyColor, Materials);
                            if (!m_useSpecifyShader)
                            {
                                for (int i = 0; i < m_materiaslCount; i++)
                                {
                                    if (Materials[i] != null)
                                    {
                                        Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                                        Materials[i].SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                                    }
                                }
                            }
                            if (Materials[0] != null)
                            {
                                m_specifyMaterial = new Material(Materials[0]);
                                m_specifyMaterial.CopyPropertiesFromMaterial(Materials[0]);
                                m_currShaderName = Materials[0].shader.name;
                            }
                        }
                    }
                }

                if (m_loadCompleteFadeAlpha && (IsBoss() || CGameConfig.GetInst().OpenMonsterFade))
                {
                    m_renderers = o.GetComponentsInChildren<Renderer>(true);
                    if (m_renderers != null)
                    {
                        int len = m_renderers.Length;
                        for (int i = 0; i < len; i++)
                        {
                            if (m_renderers[i].material.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                                m_renderers[i].material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, 1);
                        }
                    }

                    if (m_birthActID == 0)
                    {
                        m_alphaVertexAlpha = 0;
                        float showTime = 2;
                        if (CBaseStory.IsInGameStory)
                            showTime = 0.5f;
                        SetAlphaVertexColorOn(showTime);
                    }
                    else
                    {
                        m_alphaVertexAlpha = 0;
                        for (int i = 0; i < m_materiaslCount; i++)
                        {
                            if (Materials[i] != null)
                            {
                                if (!m_useSpecifyShader)
                                    Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
                                Materials[i].SetFloat("_AlphaCon", m_alphaVertexAlpha);
                            }
                        }
                    }
                }
            }
            
            if (m_texture2D != null && m_texture2D.PTexture2D != null)
            {
                //Texture texture;
                //for (int i = 0; i < m_materiaslCount; i++)
                //{
                //    texture = Materials[i].mainTexture;
                //    //if (texture != null)
                //    //    UnityEngine.Object.DestroyImmediate(texture,true);
                //}

                //if (m_materiaslCount > 0)
                //{
                //    texture = m_specifyMaterial.mainTexture;
                //    //if (texture != null)
                //    //    UnityEngine.Object.DestroyImmediate(texture, true);
                //}
                Texture2D tex = m_texture2D.PTexture2D;
                for (int i = 0; i < m_materiaslCount; i++)
                {
                    if (Materials[i] != null && Materials[i].mainTexture == null)
                        Materials[i].mainTexture = tex;
                }

                if (m_materiaslCount > 0 && m_specifyMaterial != null)
                {
                    if (m_specifyMaterial.mainTexture == null)
                        m_specifyMaterial.mainTexture = tex;
                }
            }

            
            m_bemusedTimer.SetTimer(1);
            //m_groundTimer.SetTimer(0.1f);

            //�����ڶ���֮ǰ��������
            //ShowNpc(false);

            string npcPath = m_pMonsterLoader.ModelLoader.Path;

            //����Animator Controller ���
            //string szPath = npcPath.Replace("_model", "_ctrl");
            string szPath = m_pMonsterLoader.ModelLoader.AniPath;
            LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadAcnimatorCtrl);

            ////�������
            uint szPartsID = (uint)m_pMonsterLoader.ModelLoader.PartsPathID;

            MonsterModelContent modelInfo = HolderManager.m_MonsterModelHolder.GetStaticInfo(szPartsID);
            if (modelInfo != null)
            {
                string szParts = modelInfo.Path;
                string szPartsTex = modelInfo.TextureName;
                if (szPartsTex.Equals("0"))
                    LoadHelp.LoadObject("", szParts, ThreadPriority.Normal, LoadPartsCompleted);
                else
                {
                    m_partsTexture = new CObject(szPartsTex);
                    m_partsTexture.IsMemoryFactory = true;
                    m_partsTexture.ObjectType = eObjectType.Texture;
                    m_partsTexture.Args = new object[] { szParts };
                    m_partsTexture.CallBack = LoadPartsTextureCompleted;
                    m_partsTexture.LoadObject();
                }
            }



            if (IsBoss() && !m_shapeShift && !CBaseStory.IsInGameStory && CurrBattleScene.BattleType != eBattleType.MultiPve)
            {
                //eBattleType battleType = SingletonObject<CBattleSceneLoading>.GetInst().battleType;
                //if (battleType != eBattleType.ClimbTower)
                //{
                if (!CCamera.GetInst().IsLock)
                {
                    CCamera.GetInst().Lock(m_lockObjectBossAppear);
                    UnityCallBackManager.GetInst().AddCallBack(0.1f, BossAppear, null);
                }
                //}
            }

            //��������ָ��
            CreateGuide();
            #endregion
        }
        else
        {
            m_bemusedTimer.SetTimer(1);
            string szPath = m_pMonsterLoader.ModelLoader.AniPath;
            if (szPath.Equals("0"))
            {
                eActionState currState = m_stateMgr.GetCurrActState();
                if (currState == eActionState.None)
                {
                    EnterState(eActionState.Idle);
                }
            }
            else
                LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
           

            //ResetMechanismCollider resetMechanismCollider = o.GetComponent<ResetMechanismCollider>();
            //if (resetMechanismCollider == null)
            //    resetMechanismCollider = o.AddComponent<ResetMechanismCollider>();
        }

        ShowBossHp();
      
    }

    private void ShowBossHp()
    {
        switch ((eNpcSortType)m_pMonsterLoader.Sort)
        {
            case eNpcSortType.ChapterBoss:
                {
                    this.m_bIsFinalBoss = true;
                    SingletonObject<BattleInfoMediator>.GetInst().NpcValue(1.0f);
                    SingletonObject<BattleInfoMediator>.GetInst().SetBossHpActive(true);
                    SingletonObject<BattleInfoMediator>.GetInst().m_uiBossId = (uint)m_pMonsterLoader.Key;
                }
                break;
            case eNpcSortType.WorldBoss:
            case eNpcSortType.SociatyBoss:
                {
                    this.m_bIsFinalBoss = true;
                    SingletonObject<BattleInfoMediator>.GetInst().NpcValue((float)m_nHp / (float)m_pCard.nMaxHp);
                    SingletonObject<BattleInfoMediator>.GetInst().SetBossHpActive(true);
                    SingletonObject<BattleInfoMediator>.GetInst().m_uiBossId = (uint)m_pMonsterLoader.Key;
                }
                break;
        }
    }

    private void HideBossHp()
    {
        switch ((eNpcSortType)m_pMonsterLoader.Sort)
        {
            case eNpcSortType.ChapterBoss:
                {
                    SingletonObject<BattleInfoMediator>.GetInst().SetBossHpActive(false);
                    SingletonObject<BattleInfoMediator>.GetInst().m_uiBossId = 0;
                }
                break;
            case eNpcSortType.WorldBoss:
            case eNpcSortType.SociatyBoss:
                {
                    SingletonObject<BattleInfoMediator>.GetInst().SetBossHpActive(false);
                    SingletonObject<BattleInfoMediator>.GetInst().m_uiBossId = 0;
                }
                break;
        }
    }

    protected override void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        base.LoadLeftWeaponCompleted(o, args);
        if (!ResetShader(m_specifyColor, m_materialLeft) && m_materialLeft != null)
        {
            if (!CGameConfig.GetInst().OpenMonsterFade && !IsBoss())
            {
                BattleScene bs = SingletonObject<BattleScene>.GetInst();
                Material mat = bs.GetMonsterCommonMaterial(m_uiNpcType, true);
                if (mat == null)
                {
                    mat = m_materialLeft;
                    mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                    mat.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                    bs.AddMonsterCommonMaterial(m_uiNpcType, true, mat);
                }
                ChangeLeftWeaponMaterialToCommon(mat);
            }
        }
    }

    protected override void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        base.LoadRightWeaponCompleted(o, args);
        if (!ResetShader(m_specifyColor, m_materialRight) && m_materialLeft != null)
        {
            if (!CGameConfig.GetInst().OpenMonsterFade && !IsBoss())
            {
                BattleScene bs = SingletonObject<BattleScene>.GetInst();
                Material mat = bs.GetMonsterCommonMaterial(m_uiNpcType, true);
                if (mat == null)
                {
                    mat = m_materialRight;
                    mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
                    mat.SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                    bs.AddMonsterCommonMaterial(m_uiNpcType, true, mat);
                }
                ChangeRightWeaponMaterialToCommon(mat);
            }
        }
    }

    //�������(�� ���ڵĵ���)
    private void LoadPartsCompleted(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject parts = UnityEngine.Object.Instantiate(asset) as GameObject;
        parts.name = m_myTrans.name + "_part";
        parts.transform.position = m_myTrans.position;
        Renderer[] renders = parts.GetComponentsInChildren<Renderer>();
        if (m_partsTexture != null && m_partsTexture.PTexture2D != null)
        {
            Texture2D tex = m_partsTexture.PTexture2D;
            for (int i = 0, max = renders.Length; i < max; i++)
            {
                if (renders[0].name.Equals("shadow"))
                    continue;
                renders[i].sharedMaterial.mainTexture = tex;
            }
        }
        m_partsObj = parts;
    }
    //�����������(�� ���ڵĵ���)
    private void LoadPartsTextureCompleted(GameObject o, params object[] args)
    {
        LoadHelp.LoadObject("", (string)args[0], ThreadPriority.Normal, LoadPartsCompleted);
    }

    CharacterController m_cc;
    protected override void InitModel(GameObject o)
    {
        base.InitModel(o);

       
        m_characterController = o.GetComponent<CharacterController>();

        Renderer[] renders = o.GetComponentsInChildren<Renderer>();
        //if ((m_smr != null && m_smr.Length > 0) || (m_mrs != null && m_mrs.Length > 0))
        //if (renders.Length > 0 )
        {
            if (m_characterController != null)
            {
                m_characterController.enabled = true;
                SetCollider(m_characterController);
            }
        }


        if (NpcSort != eNpcSort.Mechanism)
        {
            Collider[] colliders = o.GetComponentsInChildren<Collider>();
            int count = colliders.Length;
            Transform myTrans = o.transform;
            for (int i = 0; i < count; i++)
            {
                if (colliders[i].name == myTrans.name)
                    continue;
                if (colliders[i].isTrigger)
                {
                    continue;
                }
                colliders[i].gameObject.layer = DEFINE.EXPLODER_LAYER;
            }
        }

        if (m_sTag.Equals(DEFINE.CARRIAGE_OBJECT_TAG))
        {
            //������
            if (m_nma != null)
            {
                m_nma.obstacleAvoidanceType = ObstacleAvoidanceType.NoObstacleAvoidance;
            }

            //���Ժ���������ײ
            Avatar pAvatar = SingletonObject<Avatar>.GetInst();
            Common.IgnoreCollision(pAvatar.NpcCollider, this.NpcCollider);
        }

    }

//     private void DealySummonPos(params object[] args)
//     {
//         m_myTrans.position = m_pBattleScene.SummonPosition((this as Monster).SummonerNpc.GetPosition(), (this as Monster).SummonerNpc.CharacterRadius, this) + Vector3.up * 0.2f;
// 
//         //MyLog.Log(" index : " + m_uiIndex + " position : " + m_myTrans.position);
//     }


    //�Ƿ�Ϊ����
    public bool IsCarriage
    {
        get { return m_sTag.Equals(DEFINE.CARRIAGE_OBJECT_TAG); }
    }

    public void CreateGuide()
    {
        Avatar pAvatar = SingletonObject<Avatar>.GetInst();
        if (pAvatar==null)
        {
            return;
        }
        pAvatar.CreateMonsterGuide(this);
    }

    public float WalkSpeed
    {
        get 
        {
            return m_fWalkSpeed;
        }
    }

    //�Ƿ�ɱ�����
    public bool CanBeActive
    {
        get 
        {
            if (m_pMonsterLoader.ActiveList.Count < 2)
            {
                return false;
            }
            if (0 == m_pMonsterLoader.ActiveList[0] && 0 == m_pMonsterLoader.ActiveList[1])
            {
                return false;
            }

            return true;
        }
    }
    
    //������monsterID
    public List<int> ActiveList
    {
        get { return m_pMonsterLoader.ActiveList; }
    }

    public void DeleteGuide()
    {
        SingletonObject<Avatar>.GetInst().DeleteMonsterGuide(this);
        //SingletonObject<Avatar>.GetInst().MosterGuide.Remove(this.m_uiIndex);
        //JudgeGuide();
       
        //m_bStartUpdate = false;
    }

    protected override void BuildAnimator(Animator animator)
    {        
        base.BuildAnimator(animator);

        m_pRagdoll = new CRagdoll();
        m_pRagdoll.Init(this);


        if (NpcSort != eNpcSort.Mechanism)
        {
            if (m_unBirthActID == 0)//�޳���ǰ����
            {
                if (m_birthActID != 0)
                    EnterState(eActionState.Birth);
            }
            else
            {
                EnterState(eActionState.UnBirth);
            }
        }
    }



    //public void SetBemusedTimer()
    //{
    //    if (m_bemusedTimer != null)
    //    {
    //        m_bemusedTimer.SetTimer(1);
    //    }
    //}

    //����������
    public bool IsInBemused()
    {
        return !m_bemusedTimer.IsExpired(false);
    }

    //�ܻ�����
    public override void PlayBehitSound()
    {
        List<int> soundList = m_pMonsterLoader.ModelLoader.BehitSoundID;
        for (int i = 0, len = soundList.Count; i < len; i++ )
        {
            CreateSound((uint)soundList[i]);
        }                
    }

    public string BornArea
    {
        get
        {
            return m_bornArea;
        }
        set
        {
            m_bornArea = value;
        }
    }

    protected override eCommandReply DoUseSkill(UseSkillCommandArg arg)
    {
        eCommandReply reply = base.DoUseSkill(arg);
        if (base.IsBoss() && reply == eCommandReply.YesSir)
        {
           // SingletonObject<BossSkillNameMediator>.GetInst().SetSkillId(arg.uSkillid);
        }
        return reply;
    }

    public override bool CanMove
    {
        set
        {
            m_bMove = value;
        }
        get
        {
            if (null == m_pAI) return true;

            return m_pAI.CanMove() && m_bMove;
        }
        
    }

    public override bool CanTurn
    {
        set
        {
//             if (!string.IsNullOrEmpty(m_sTag) && m_sTag.Equals(DEFINE.CARRIAGE_OBJECT_TAG))
//             {
//                 m_bTurn = false;
//             }
//             else
            {
                m_bTurn = value;
            }
        }
        get
        {
            if (null == m_pAI) return true;

            return m_pAI.CanTurn() && m_bTurn;
        }
        
    }

    public override bool CanBeGrab
    {
        get
        {
            if (!base.CanBeGrab)
            {
                return false;
            }
  
            if (null == m_pMonsterLoader)
            {
                return false;
            }

            return m_pMonsterLoader.CanBeGrab;
            
//             return (m_pMonsterLoader.GetSort() == eNpcSortType.NormalMonster || 
//                         m_pMonsterLoader.GetSort() == eNpcSortType.LeaderMonster);
        }
    }

    public override bool CanBeAttract
    {
        get
        {
            if ( NpcSortType == eNpcSortType.NormalMonster || 
                 NpcSortType == eNpcSortType.LeaderMonster )
            {
                return true;
            }

            return false;
        }
    }

    //ͬ���Ѿ����ܵȼ���Ϣ

    public CSkillupInfo AllySkillupInfo
    {
        set { m_pAllySkillupInfo = value; }
        get { return m_pAllySkillupInfo; }
    }

    //�ٻ���/������
    public CBaseNpc SummonerNpc
    {
        get { return m_pSummoner; }
    }

    public SummonerType SummonerType
    {
        get { return m_eSummonerType; }
    }

    public void SetSummonerNpc(CBaseNpc summoner,SummonerType type) 
    {
        m_pSummoner = summoner;
        m_eSummonerType = type;
    }


    //�Ƿ���������Ϊ
    public bool MoveBehaviour
    {
        get
        {
            if (null == m_pMonsterLoader.ModelLoader)
            {
                return false;
            }
            return m_pMonsterLoader.ModelLoader.MoveBehaviour;
        }        
    }

    //�̳�����
    public void SetAttrInherit()
    {
        if ( null != m_pSummoner && m_attrInheritList.Length > 2)
        {
            m_nHp = (int)(m_pSummoner.OriginCard.nMaxHp * m_attrInheritList[0]);
            m_pOriginCard.nMaxHp = m_nHp;
            m_pOriginCard.nAttack = (int)(m_pSummoner.OriginCard.nAttack * m_attrInheritList[1]);
            m_pOriginCard.nDefence = (int)(m_pSummoner.OriginCard.nDefence * m_attrInheritList[2]);
            m_pOriginCard.nHitRate = (int)(m_pSummoner.OriginCard.nHitRate);
            m_pOriginCard.nDodge = (int)(m_pSummoner.OriginCard.nDodge);
            m_pOriginCard.nBingo = (int)(m_pSummoner.OriginCard.nBingo);

            m_pCard = m_pOriginCard;
        }
    }

    //��ʵNPC��Ϊ
    public override eNpcBehaviour CheckNpcBehaviour()
    {
      
        //if ((CBaseStory.IsInGameStory || m_bPausedMove) && m_bPausedChick)
        if (m_bPausedMove && m_bPausedCheck)
            return eNpcBehaviour.GameStory;

        if (IsInBemused())
        {
            return eNpcBehaviour.None;
        }

        if (NpcSort == eNpcSort.Mechanism && m_rangeNpcList.Count <= 0)
        {
            return eNpcBehaviour.None;
        }

        if (CurrBattleScene.BattleType == eBattleType.MultiPve && MultiPveMsg.LockStep)
        {
            return eNpcBehaviour.LockBehaviour;
        }
        
        return base.CheckNpcBehaviour();
    }

   

    //����
    public override void Shapeshift_after(uint uiNpcID,Vector3 position,Quaternion rotation)
    {
        m_pMonsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(uiNpcID);
        if (m_pMonsterLoader == null)
        {
            MyLog.LogError("can't find Monster:" + uiNpcID);
            return;
        }

        //m_pMonsterLoader = m_pMonsterLoader;

        m_shapeShift = true;

        base.Shapeshift_after(uiNpcID, position, rotation);
    }


    //����Ŀ��
    public void EscapeFromTarget(CBaseNpc pTarget, float fDistance)
    {
        if (null == m_escapeDestObj)
        {
            m_escapeDestObj = new GameObject();
        }

        float fPercent = 1;
        while (fPercent > 0)
        {
            Vector3 destPosition = Common.GetRayPosition(m_myTrans.position, pTarget.GetPosition(), -fDistance * fPercent);

            Vector3 position = Common.NavSamplePosition(destPosition);

            NavMeshPath path = new NavMeshPath();
            SetNavmeshEnable(true);
            m_nma.CalculatePath(position, path);

            if (path.status != NavMeshPathStatus.PathPartial)//���ƶ����õ�
            {
                CurrTarget = null;
                SetDestPosition(position, true);
                m_bEscape = true;
                EnterState(eActionState.Run);
                break;
            }

            fPercent -= 0.1f;
        }

    }

    //public void SetRigidbodyCollisionDetection(CollisionDetectionMode mode)
    //{
    //    if (m_rigidbody != null)
    //    {
    //        m_rigidbody.collisionDetectionMode = mode;
    //    }
    //}


    public override void SimpleMove(Vector3 dir, float speed)
    {
        if (null != m_characterController && m_characterController.enabled)
        {
            Vector3 fDecelerateVector = dir.normalized * speed;

            if (m_bStopSimpleMove)
            {
                fDecelerateVector = Vector3.zero;
            }
            if (UnitsType != eNpcUnitsType.Ground)
            {
                m_characterController.Move(fDecelerateVector * Time.deltaTime);
            }
            else
            {
                m_characterController.Move(fDecelerateVector * Time.deltaTime - Vector3.up * 5);

            }

            if (m_myTrans.position.y < -100)
            {
                NpcDead(false);
            }
        }
        
    }
    public bool JudgeGuide()
    {
        if (this.NpcGroup   ==  eNpcGroup.Evil)
        {
            Avatar pAvatar = SingletonObject<Avatar>.GetInst();
            Vector3 playerPosition = pAvatar.GetPosition();
            Vector3 monsterPosition = GetPosition();
            //pAvatar.UpdateMosterGuide(this);
            float distance = Common.Get2DVecter3Length(playerPosition, monsterPosition);
            bool notdisppear;
            if(distance>DEFINE.GUIDEDISTANCE)
                notdisppear = true;
            else
                notdisppear = false;
            return notdisppear;
        }
        else 
            return true;
    }
     

    public override void Update()
    {
        base.Update();

        if (m_pAI != null)
        {
            m_pAI.Update();
        }

        if (null != m_pMultiPveLogic)
        {
            m_pMultiPveLogic.Update();
        }
        

        if (!IsChest())
        {
            //if (m_pAI != null)
            //{
            //    m_pAI.Update();
            //}

            if (m_hitStyle != eHitStyle.NONE)
            {
                MonsterBeHitChangeColor();
            }
        }

        //if (m_myTrans!=null && m_myTrans.gameObject.tag.Equals(DEFINE.CARRIAGE_OBJECT_TAG))
        //{
        //    MyLog.Log("Carriage State: " + GetCurrActState());
        //}
        //MyLog.Log("  action speed : " + m_pAnimator.Speed);
    }

    public override void NpcDead(bool bNaturalDeath, CBaseNpc attack = null,bool fromMsg = false)
    {
        base.NpcDead(bNaturalDeath, attack, fromMsg);


        if (m_pMonsterLoader.ModelLoader.BehitBlood)
        {
            CreateParticle(DEFINE.MONSTER_BEHIT_BLOOD_ID);
        }

        if (CurrBattleScene.BattleType == eBattleType.MultiPve && !fromMsg)
        {
            Protocol.PvpChangeData data = new Protocol.PvpChangeData();
            data.uiDataType = (byte)Index;
            MultiPveMsg.ReqDataChange(new Protocol.PvpChangeDataList() { data });
        }
        

        //CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_DEAD_SHAKE, null, null);

        if (bNaturalDeath && !CBaseStory.IsInGameStory && 
            SingletonObject<CBattleSceneLoading>.GetInst().battleType != eBattleType.Escort)
        {
            //�жϵ���
              float delayTime = UnityEngine.Random.Range(0.1f, 0.2f);
              UnityCallBackManager.GetInst().AddCallBack(delayTime, delegate(object[] args)
              {
                 CheckDropItem();
              });
        }

        if ( null != m_pSummoner )
        {
            m_pSummoner.RemoveAlly(m_uiIndex);
        }        
        //ɾ��GUIDE
        DeleteGuide();

        if (m_partsObj != null)
        {
            UnityEngine.Object.Destroy(m_partsObj);
        }

        //��ͨ���ٻ��ﲻ����
        if ( SummonerType != SummonerType.Normal )
        {
            TriggerManager.GetInst().NpcDead((uint)m_pMonsterLoader.Key);
        }

        HideBossHp();
    }

    private void CheckDropItem()
    {
        int xoffset = 0;
        int zoffset = 0;
        int circleCount = 0;//Ȧ��

        Protocol.CMonsterDrop drop = m_pBattleScene.MonsterDrop((uint)m_pMonsterLoader.Key);
        if (drop != null)
        {
            for(int i = 0;i < drop.vDropItems.Count;++i)
            {
                DropItem(drop.vDropItems[i].uiItemId, drop.vDropItems[i].uiItemNum, ref xoffset, ref zoffset, ref circleCount);
            }
            
        }

        List<int> battleDropList = m_pMonsterLoader.BattleDropList;
        for (int i = 0, count = battleDropList.Count; i < count; ++i)
        {
            uint uiDropItemID = (uint)battleDropList[i];
            DropItemContent pDropItemLoader = HolderManager.m_DropItemHolder.GetStaticInfo(uiDropItemID);
            if (null == pDropItemLoader)
            {
                continue;
            }

            byte byDropType = pDropItemLoader.DropType;

            switch ((eDropType)byDropType)
            {
                case eDropType.RandomDropOne:
                    {
                        //bool bDrop = false;
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList1(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList2(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList3(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList4(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList5(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList6(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList7(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList8(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList9(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        //bDrop = RandomDrop(uiDropItemID, pDropItemLoader.GetDropList10(), ref xoffset, ref zoffset, ref circleCount, bDrop);
                        DropOne( pDropItemLoader, ref xoffset, ref zoffset, ref circleCount);
                    }
                    break;
                case eDropType.AllRandomDrop:
                    {
                        bool bDrop = false;
                        RandomDrop(pDropItemLoader.DropList1, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop(pDropItemLoader.DropList2, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList3, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList4, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList5, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList6, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList7, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList8, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList9, ref xoffset, ref zoffset, ref circleCount, bDrop);
                        RandomDrop( pDropItemLoader.DropList10, ref xoffset, ref zoffset, ref circleCount, bDrop);
                    }
                    break;
            }
        }

                
    }


    private void DropOne(DropItemContent pDropItemLoader, ref int xoffset, ref int zoffset, ref int circleCount)
    {
        int range = UnityEngine.Random.Range(0, 10000);

        int currRange = 0;

        bool bDrop = false;
        bDrop = OneDropList( pDropItemLoader.DropList1, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList2, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList3, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList4, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList5, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList6, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList7, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList8, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList9, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
        if (bDrop) return;
        bDrop = OneDropList( pDropItemLoader.DropList10, range, ref xoffset, ref zoffset, ref circleCount, ref currRange);
    }

    private bool OneDropList(List<string> dropList, int range, ref int xoffset, ref int zoffset, ref int circleCount, ref int currRange)
    {
        if (dropList.Count != 4)
        {
            return false;
        }
        if (dropList[0].Equals("0"))
        {
            return false;
        }

        int tmp = MyConvert_Convert.ToInt32(dropList[3]);
        currRange += tmp;
        if (currRange <= range)
        {
            return false;
        }



        DropItem(dropList, ref xoffset, ref zoffset, ref circleCount);

        return true;
    }

    private bool RandomDrop( List<string> dropList, ref int xoffset, ref int zoffset, ref int circleCount, bool bDrop)
    {
        if (bDrop)
        {
            return false;
        }

        if (dropList.Count != 4)
        {
            return false;
        }

        int range = MyConvert_Convert.ToInt32(dropList[3]);
        int random = UnityEngine.Random.Range(0, 10000);
        if (random >= range)
        {
            return false;
        }

        DropItem(dropList, ref xoffset, ref zoffset, ref circleCount);

        return true;
    }

    void DropItem(List<string> dropList, ref int xoffset, ref int zoffset, ref int circleCount)
    {
        if (m_myTrans == null) return;
        int minNum = MyConvert_Convert.ToInt32(dropList[1]);
        int maxNum = MyConvert_Convert.ToInt32(dropList[2]);
        int num = UnityEngine.Random.Range(minNum, maxNum + 1);

        string dropName = dropList[0];

        int uiItemID = 0;

        ItemContent pItemLoader = ItemManager.GetLoaderByID(dropName);
        if (null != pItemLoader)
        {
            uiItemID = pItemLoader.Key;
        }
        else
        {
            EquipContent pEquipLoader = EquipItemManager.GetLoaderByID(dropName);
            if (null != pEquipLoader)
            {
                uiItemID = pEquipLoader.Key;
            }
        }

        //���䵽��ͼ��
        Vector3 position = m_myTrans.position + new Vector3(xoffset, 0, zoffset) * 0.5f;

        CDropObjectManager.GetInst().CreateDropObject((uint)uiItemID, (uint)num, position);

        GetNextOffset(ref xoffset, ref zoffset, ref circleCount);
    }

    void DropItem(uint uiItemID,uint uiItemNum, ref int xoffset, ref int zoffset, ref int circleCount)
    {
        if (m_myTrans == null) return;

        if (uiItemID == DEFINE.ITEM_GOLD)
        {
            int range = Random.Range(2, 4);
            uint sum = 0;
            for (int i = 0; i < range; ++i)
            {
                uint rangeNum = 0;
                if (i != range - 1)
                {
                    rangeNum = (uint)((uiItemNum / range) * Random.Range(0.9f, 1.1f));
                    sum += rangeNum;
                }
                else
                {
                    rangeNum = (uint)(uiItemNum - sum);
                }

                Vector3 position = m_myTrans.position + new Vector3(xoffset, 0, zoffset) * 0.5f;

                CDropObjectManager.GetInst().CreateDropObject(uiItemID, rangeNum, position);

                GetNextOffset(ref xoffset, ref zoffset, ref circleCount);
            }
        }
        else
        {
            //���䵽��ͼ��
            Vector3 position = m_myTrans.position + new Vector3(xoffset, 0, zoffset) * 0.5f;

            CDropObjectManager.GetInst().CreateDropObject(uiItemID, uiItemNum, position);

            GetNextOffset(ref xoffset, ref zoffset, ref circleCount);
        }

       
    }


    private void GetNextOffset(ref int xoffset, ref int zoffset, ref int circleCount)
    {
        if (xoffset == -circleCount && zoffset >= -circleCount && zoffset < circleCount)//���º����
        {
            zoffset++;
        }
        else if (zoffset == circleCount && xoffset >= -circleCount && xoffset < circleCount)//������ϱ�
        {
            xoffset++;
        }
        else if (xoffset == circleCount && zoffset > -circleCount && zoffset <= circleCount)//������ұ�
        {
            zoffset--;
        }
        else if (zoffset == -circleCount && xoffset > -circleCount && xoffset <= circleCount)//���º��±�
        {
            xoffset--;
            if (xoffset == -circleCount)
            {
                circleCount++;
                xoffset = -circleCount;
                zoffset = -circleCount;
            }
        }
        else//(0,0)��
        {
            circleCount++;
            xoffset = -circleCount;
            zoffset = -circleCount;
        }
    }
    
    public override void RemoveNpc()
    {
        base.RemoveNpc();
        
        m_pBattleScene.RemoveNpc(m_uiIndex);

        if ( null != m_myTrans)
        {
            m_myTrans.gameObject.SetActive(false);
        }
        if (m_resetMaterialMonster && Materials != null)
        {
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                    Materials[i].shader = DynamicShader.GetShader(m_material0Name);
            }
            if (m_materialLeft)
                m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
            if (m_materialRight)
                m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        }
        if (Materials != null && m_smr != null && m_smr.Length > 0)
        {
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (m_smr[i] != null && !m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = Materials;
                    break;
                }
            }
        }
    }

    public override void Release(eObjectDestroyType type)
    {
        //if (m_del)
        //    type = eObjectDestroyType.Normal;

        base.Release(type);

        //m_pSummoner = null;
        if ( null != m_pMultiPveLogic )
        {
            m_pMultiPveLogic.Release();
            m_pMultiPveLogic = null;
        }        

        if (m_escapeDestObj != null)
        {
            UnityEngine.Object.Destroy(m_escapeDestObj);
        }

        if (m_partsObj != null)
        {
            UnityEngine.Object.Destroy(m_partsObj);
        }

        if (m_partsTexture != null)
        {
            m_partsTexture.DestroyGameObject(eObjectDestroyType.Memory);
            m_partsTexture = null;
        }

        if (m_texture2D != null)
        {
            m_texture2D.DestroyGameObject(eObjectDestroyType.Memory);
            m_texture2D = null;
        }

        if (this.m_bIsFinalBoss)
            this.m_bIsFinalBoss = false;
    }

    //�жϵ�ǰʹ�ù��ļ����Ƿ�ﵽĳ��AI����
    public void UpdateCurrSkillAICondition()
    {
        //m_pAI.UpdateCondition(eExtraAICondition.AppointSkillAttack, m_uiCurrSkillID.ToString());
    }


    public override void AddMaterials(bool restore = true, int index = 0)
    {
        Debug.Log("AddMaterials   Index = " + Index.ToString());
        if (IsDead())
            return;

        if (!m_resetMaterialMonster)
            return;

        if (m_smr == null || m_smr.Length <= 0)
        {
            MyLog.LogError("AddMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t SkinMeshRenderer is null or length is 0");
            return;
        }

        if (m_materiaslCount <= 0)
        {
            MyLog.LogError("AddMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
        }
        if (restore)
        {
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = Materials;
                    break;
                }
            }
        }
        else
        {

            Material material = DynamicShader.GetMaterials(index);
            if (material == null)
                return;

            Material[] materials = new Material[m_materiaslCount + 1];
            for (int i = 0; i < m_materiaslCount; i++)
            {
                materials[i] = Materials[i];
            }
            materials[m_materiaslCount] = material;
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = materials;
                    break;
                }
            }
        }
    }

    public override void ChangeMaterials(bool restore = true, string name = "")
    {
        Debug.Log("ChangeMaterials   Index = " + Index.ToString());

        if (IsDead())
            return;

        if (!m_resetMaterialMonster)
            return;

        if (m_smr == null || m_smr.Length <= 0)
        {
            MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t SkinMeshRenderer is null or length is 0");
            return;
        }

        if (m_materiaslCount <= 0)
        {
            MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
        }
        if (restore)
        {
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = Materials;
                    break;
                }
            }
        }
        else
        {

            Material material = DynamicShader.GetMaterials(name);
            if (material == null)
                return;
            Material[] materials = new Material[m_materiaslCount];
            for (int i = 0; i < m_materiaslCount; i++)
            {
                materials[i] = material;
            }
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = materials;
                    break;
                }
            }
        }
    }

    public override bool IsOverlord()
    {
        if (!m_pAI.CanMove())
        {
            return true;
        }

        if (base.IsOverlord())
        {
            return true;
        }

        return false;
    }


    private void ChangeShaderToMobileLightmapUnlit(float resetValue)     //shader�滻ΪMyMobile/Lightmap Alpha
    {
        if (!m_resetMaterialMonster)
            return;


        if (!m_useSpecifyShader)
        {
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                {
                    if (Materials[i].HasProperty(DEFINE.SHADER_PROPERTY_HITCOLOR))
                    {
                        Materials[i].SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                        m_hitColor = Color.black;
                    }
                    Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
                }
            }
            m_currShaderName = DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON;
        }
        else
        {
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                    Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_TIME_HART_DIFFUSE);
            }
            m_currShaderName = DEFINE.SHADER_VERTLIT_TIME_HART_DIFFUSE;
        }
        for (int i = 0; i < m_materiaslCount; i++)
        {
            if (Materials[i] != null)
                Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, resetValue);
        }

        if (m_materialLeft)
        {
            m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
            m_materialLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, resetValue);
        }
        if (m_materialRight)
        {
            m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_ON);
            m_materialRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, resetValue);
        }

    }

    private void MonsterBeHitChangeColor()    //�ܻ�ʱ����ת��Ϊ�ܻ���ɫ
    {
        if (!m_resetMaterialMonster)
            return;

        if (m_materiaslCount <= 0)
            return;
        if (m_currShaderName == DEFINE.SHADER_VERTLIT)
        {
            m_hitColor.r = Mathf.Lerp(m_hitColor.r, 0, Time.deltaTime * m_reColorSpeed);
            m_hitColor.g = Mathf.Lerp(m_hitColor.g, 0, Time.deltaTime * m_reColorSpeed);
            m_hitColor.b = Mathf.Lerp(m_hitColor.b, 0, Time.deltaTime * m_reColorSpeed);

            //MyLog.Log(m_hitColor.r);

            if (m_hitColor.r <= 0.01f)
            {
                m_hitColor = Color.black;
                m_hitStyle = eHitStyle.NONE;
            }
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                    Materials[i].SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, m_hitColor);
            }
        }
    }

    private void MonsterSetHitColor(Color color)      //�����ܻ�ʱ�õ���Ҫ�ı䵽����ɫ
    {
        if (!m_resetMaterialMonster)
            return;

        if (m_materiaslCount <= 0)
            return;
        if (m_hitStyle == eHitStyle.NONE)
        {
            if (m_currShaderName == DEFINE.SHADER_VERTLIT)
            {
                m_hitColor = color;
                //    m_smr.material.SetColor("_HitColor", m_hitColor);
                m_hitStyle = eHitStyle.HIT_SMALL;
            }
        }
    }

    protected bool ResetShader(/*int shaderIndex,*/Color color,params Material[] mats)
    {
        if (!m_resetMaterialMonster)
            return true;

        bool reset = false;
        //if (shaderIndex > 0)
        //{
         //   Color color = DynamicShader.GetMonsterSpecialMaterialColor(shaderIndex);
        if(!color.Equals(Color.white))
        {
            Shader shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_TIME_HART_DIFFUSE);
            int len = mats.Length;
            for (int i = 0; i < len; i++)
            {
                if (mats[i] != null)
                {
                    mats[i].shader = shader;
                    mats[i].SetColor(DEFINE.SHADER_PROPERTY_COLOR, color);
                    mats[i].SetFloat(DEFINE.SHADER_PROPERTY_EXPAND, 0.0125f);
                    mats[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
                }
            }
            reset = true;

            //if (m_specifyMaterial == null)
            //{
            //    m_specifyMaterial = new Material(shader);
            //    m_specifyMaterial.SetColor(DEFINE.SHADER_PROPERTY_COLOR, color);
            //    m_specifyMaterial.SetFloat(DEFINE.SHADER_PROPERTY_EXPAND, 0.0125f);
            //}
        }

        return reset;
    }

    protected override void ChangeAlphaVertexColor(bool add)
    {
        if (m_materiaslCount <= 0)
        {
            if (m_pNpcObj != null)
                MyLog.LogError("ChangeAlphaVertexColor Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
            m_liveState = eLiveState.NONE;
            return;
        }
        if (add)
        {
            m_alphaVertexAlpha += m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
        }
        else
        {
            m_alphaVertexAlpha -= m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
        }

        m_alphaVertexAlpha = Mathf.Clamp01(m_alphaVertexAlpha);

        //if (m_alpha > 0)
        //    ShowNpc(true);
        //else
        //    ShowNpc(false);

        //m_materials[0].SetFloat("_AlphaCon", m_alphaVertexAlpha);
        //if (m_mat)
        //    m_mat.SetFloat("_AlphaCon", m_alphaVertexAlpha);
        //if (m_materialRight)
        //    m_materialRight.SetFloat("_AlphaCon", m_alphaVertexAlpha);

        //if (m_renderers == null)
        if (m_loadCompleteFadeAlpha)
        {
            if (m_myTrans == null)
            {
                m_liveState = eLiveState.NONE;
                return;
            }
            m_renderers = m_myTrans.GetComponentsInChildren<Renderer>();

            if (m_renderers != null)
            {
                int len = m_renderers.Length;
                
                for (int i = 0; i < len; i++)
                {
                    m_tempMaterials = m_renderers[i].materials;
                    if (m_tempMaterials != null)
                    {
                        for (int m = 0, count = m_tempMaterials.Length; m < count; m++)
                        {
                            if (m_tempMaterials[m] != null && m_tempMaterials[m].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                                m_tempMaterials[m].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
                        }
                    }
                }
            }
            else
            {
                m_liveState = eLiveState.NONE;
                return;
            }
        }
        else
        {
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null && Materials[i].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                    Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
            }
        }

        if (m_alphaVertexAlpha % 1f == 0f)
        {
            if (add && m_alphaVertexAlpha == 1)
            {
                m_liveState = eLiveState.NONE;
                //m_hitStyle = eHitStyle.NONE;
                if (!m_useSpecifyShader)
                {
                    for (int i = 0; i < m_materiaslCount; i++)
                    {
                        if (Materials[i] != null)
                        {
                            if (m_specifyMaterial != null)
                                Materials[i].shader = m_specifyMaterial.shader;
                            else
                                Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

                            //if (m_materials[i].HasProperty(DEFINE.SHADER_PROPERTY_HITCOLOR))
                            //{
                            //    m_materials[i].SetColor(DEFINE.SHADER_PROPERTY_HITCOLOR, Color.black);
                            //    m_hitColor = Color.black;
                            //}
                        }
                    }
                }
                if (m_materialLeft)
                    m_materialLeft.shader = m_specifyMaterial.shader;
                if (m_materialRight)
                    m_materialRight.shader = m_specifyMaterial.shader;

                m_currShaderName = m_material0Name;
            }
            else if (!add && m_alphaVertexAlpha == 0)
            {
                m_liveState = eLiveState.NONE;
                //m_hitStyle = eHitStyle.NONE;
            }
        }
    }

    public override void SetAlphaVertexColorOff(float time)
    {
        if (!CGameConfig.GetInst().OpenMonsterFade && !IsBoss())
            return;
        if (!m_resetMaterialMonster || m_liveState == eLiveState.Fade)
            return;
        m_liveState = eLiveState.Fade;
        m_alphaVertexSpeed = time <= 0 ? Mathf.Epsilon : time;
        m_alphaVertexSpeed = 1f / m_alphaVertexSpeed;
        SetFootEffect(false);

        HpComponentEnable(false);
        ChangeShaderToMobileLightmapUnlit(1);
    }

    public override void SetAlphaVertexColorOn(float time)
    {
        if (!CGameConfig.GetInst().OpenMonsterFade && !IsBoss())
            return;
        if (!m_resetMaterialMonster || m_liveState == eLiveState.Grow)
            return;
        m_liveState = eLiveState.Grow;
        m_alphaVertexSpeed = time <= 0 ? Mathf.Epsilon : time;
        m_alphaVertexSpeed = 1f / m_alphaVertexSpeed;

        m_hitStyle = eHitStyle.NONE;

        SetFootEffect(true);
        //HpComponentEnable(true);
        //ChangeShaderToMobileLightmapUnlit(0);
    }

    public override void BeHit(uint uiDefenceActionID, CBaseNpc pAttacker, SkillContent pSkillLoader,bool beHitMute = false)
    {
        base.BeHit(uiDefenceActionID, pAttacker, pSkillLoader, beHitMute);

        if (pSkillLoader.AffectEffect == (byte)eAffectEffect.NegativeEffect)
        {
            if (IsBoss() || CGameConfig.GetInst().OpenMonsterFade)
                MonsterSetHitColor(new Color(1, 1, 1, 1));
        }

    }

    public override uint PlayBirthAction(uint actID)
    {
        uint uiParticleIndex = 0;
        ActionContent pActionInfo = HolderManager.m_ActionHolder.GetStaticInfo(actID);
        if (null != pActionInfo)
        {

            PlayAction(pActionInfo.ActionName);

            List<int> sounds = Common.GetSounds(pActionInfo);
            foreach (var soundID in sounds)
            {
                CreateSound((uint)soundID);
            }

            BattleScene bs = SingletonObject<BattleScene>.GetInst();

            if (CBaseStory.IsInGameStory || bs.HideNpc)
                return uiParticleIndex;

            List<int> effectList = Common.GetPlayEffects(pActionInfo);
            //��Ч
            if (effectList.Count > 0)
            {
                for (int i = 0; i < effectList.Count; ++i)
                {
                    uiParticleIndex = CreateParticle((uint)effectList[i]);
                }
            }
        }

        return uiParticleIndex;
    }

    private void BossAppear(params object[] args)
    {
        BattleScene bs = SingletonObject<BattleScene>.GetInst();
        bs.PauseAllNpc(true,true);
        bs.HideNpcExceptBoss(true);
        TriggerManager.GetInst().PauseAlltrigger(true);
        CCamera.GetInst().PauseAllNpc = true;
        Avatar.m_OffHandelClick = true;
        //CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_FOLLOW);
        CCamera.GetInst().PauseAllCameraEffect(m_lockObjectBossAppear);

        AppearBoss = true;

        GameObject fadeObject;
        WeatherCommon.GetInst().CreateCameraFadeObject(out fadeObject,PrimitiveType.Quad);
        if (fadeObject)
            ScreenFadeOn(fadeObject);
    }

    private void ScreenFadeOn(params object[] args)   //��Ļ�䰵
    {
        GameObject fadeObj = args[0] as GameObject;
        WeatherCommon.GetInst().AlphaFadeTo(fadeObj, 0.2f, 1, true, BossAppearCameraEffect,new object[]{fadeObj,this,m_lockObjectBossAppear});
    }

    private void BossAppearCameraEffect(params object[] args)
    {
        SingletonObject<UIManager>.GetInst().CloseAllWnd();
        CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BOSS_SP_GO,m_lockObjectBossAppear, ScreenFadeOff,args);
    }

    private void ScreenFadeOff(params object[] args)  //��Ļ����
    {
        GameObject fadeObj = args[0] as GameObject;
        WeatherCommon.GetInst().AlphaFadeTo(fadeObj, 0.2f, 0, true, BeginCameraEffect,new object[]{ fadeObj, m_lockObjectBossAppear});
    }

    private void BeginCameraEffect(params object[] args)
    {
        CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BOSS_BULLETTIME, m_lockObjectBossAppear, UIShowBossDescript, args);
        CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BOSS_DRAK,m_lockObjectBossAppear, null, null);
    }

    private void UIShowBossDescript(params object[] args)  //�������UI����
    {
        IntroduceMediator mIntroduceMediator = SingletonObject<IntroduceMediator>.GetInst();
        mIntroduceMediator.Open(delegate()
        {
            mIntroduceMediator.SetIntroduceText(m_pMonsterLoader, UIShowBossDescriptCallback, args);
        });
        

        if (m_pMonsterLoader.ModelLoader.HasProvoke)
        {
            CBossSneerState pSneerState = (CBossSneerState)m_stateMgr.GetState(eActionState.BossSneer);
            if (pSneerState != null)
            {
                pSneerState.SetActionInfo(1.0f);
                EnterState(eActionState.BossSneer);
                CreateSound(403);
            }
        }
    }

    private void UIShowBossDescriptCallback(params object[] args)  //UI�ص�
    {
        EndCameraEffect(args);
    }

    private void EndCameraEffect(params object[] args)  
    {
        CCamera.GetInst().ForcePauseCameraEffect(eCAMERATYPE.CAMERA_TYPE_DRAG,m_lockObjectBossAppear);
        CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BOSS_BACK,m_lockObjectBossAppear, BossAppearCameraEffectBack, args);
    }

    private void BossAppearCameraEffectBack(params object[] args)
    {
        CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_BOSS_SP_BACK, m_lockObjectBossAppear,null, args);

        SingletonObject<UIManager>.GetInst().OpenCurrentWnd();

        GameObject fadeObj = args[0] as GameObject;

        BattleScene bs = SingletonObject<BattleScene>.GetInst();
        bs.PauseAllNpc(false,true);
        bs.HideNpcExceptBoss(false);

        TriggerManager.GetInst().PauseAlltrigger(false);
        CCamera.GetInst().PauseAllNpc = false;
        Avatar.m_OffHandelClick = false;
        if (fadeObj)
            UnityEngine.Object.Destroy(fadeObj);

        CCamera.GetInst().Unlock();
        AppearBoss = false;
    }

    public override void ChangeModel(CObject model, CAnimator anim)
    {
        base.ChangeModel(model, anim);
       // MyLog.LogError("????");
       // CreateGuide();
    }

    public void RestoreChangeMaterialParticleMaterial()
    {
        if (m_smr == null || m_smr.Length <= 0)
        {
            if (m_pNpcObj != null)
                MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t SkinMeshRenderer is null or length is 0");
            return;
        }

        if (m_materiaslCount <= 0)
        {
            if (m_pNpcObj != null)
                MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
            return;
        }
        for (int i = 0; i < m_smr.Length; i++)
        {
            if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
            {
                m_smr[i].materials = Materials;
                break;
            }
        }
    }

    public void ChangeToMaterial(Material material)
    {
        if (m_smr == null || m_smr.Length <= 0)
        {
            if (m_pNpcObj != null)
                MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t SkinMeshRenderer is null or length is 0");
            return;
        }

        if (m_materiaslCount <= 0)
        {
            if (m_pNpcObj != null)
                MyLog.LogError("ChangeMaterials Monster ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
            return;
        }
        for (int i = 0; i < m_smr.Length; i++)
        {
            if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
            {
                m_smr[i].material = material;
                break;
            }
        }
    }

    public override void AddHp(int nHp, bool critical = false, CBaseNpc attacker = null,bool fromMsg = false)
    {
        if (CurrBattleScene.BattleType == eBattleType.TeamPve && null != m_TeamPveInfo)
        {
            if (nHp < 0)
            {
                m_TeamPveInfo.nDamage += -nHp;
                if (m_TeamPveInfo.nDamage > m_TeamPveInfo.nHp)
                {
                    m_TeamPveInfo.nDamage = m_TeamPveInfo.nHp;
                }
            }
        }

        base.AddHp(nHp, critical, attacker, fromMsg);
        if (CurrBattleScene.BattleType == eBattleType.GlobalBoss && this.NpcSortType == eNpcSortType.WorldBoss && nHp < 0)
        {
            WorldBossManager.GetInst().m_uiDamage += -nHp;

            if (WorldBossManager.GetInst().m_uiDamage > m_pCard.nMaxHp)
            {
                WorldBossManager.GetInst().m_uiDamage = m_pCard.nMaxHp;
            }
        }
    }
    public int GetBirthActID()
    {
        return m_pMonsterLoader.ModelLoader.BirthActID;
    }
    public int GetUnBirthActID()
    {
        return m_pMonsterLoader.ModelLoader.UnBirthActID;
    }

    public override eNpcSortType GetNpcSortType()
    {
        return (eNpcSortType)m_pMonsterLoader.Sort;
    }
    public override List<float> GetAniMoveSpeed()
    {
        return m_pMonsterLoader.ModelLoader.AniMoveSpeed;
    }
    public override float GetMaxMoveSpeed()
    {
        return 10;
    }

    public override bool IsKill()
    {
        if (CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            return m_pMultiPveLogic.CanKill;
        }        
        return m_pMonsterLoader.m_bKill;
    }
    public override bool IsHitDown()
    {
        return m_pMonsterLoader.IsHitDown;
    }
    public override bool IsBeatFly()
    {
        return m_pMonsterLoader.IsBeatFly;
    }
    public override bool IsCanStun()
    {
        return m_pMonsterLoader.IsStun;
    }
    public override bool IsSlow()
    {
        return m_pMonsterLoader.IsSlow;
    }
    public override int GetDeadActID()
    {
        return m_pMonsterLoader.ModelLoader.DeadActID;
    }
    public override float GetRigidity()
    {
        return m_pMonsterLoader.Rigidity;
    }


    public override string GetName()
    {
        return Common.GetText(m_pMonsterLoader.NpcName);
    }


#region ����PVE�߼�
    public void ReqMove(uint targetIndex)
    {
        MultiPveMsg.ReqMonsterMove(targetIndex, this);
    }

    public void ReqDoAttack(uint uiSkillType)
    {
        float eulerY = m_myTrans.eulerAngles.y;
        MultiPveMsg.ReqDoAttack(uiSkillType, eulerY, Index, this.m_myTrans);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="msg"></param>
    /// <param name="selfCmd">�Ƿ�Ϊ������ָ��</param>
    public void RecvMonsterMove(object msg,bool selfCmd) 
    {
        if ( null != m_pMultiPveLogic )
        {
            m_pMultiPveLogic.DoCommand(msg, eRPCmdType.Move,selfCmd);
        }        
    }

    public void RecvAttack(object msg, bool selfCmd)
    {
        if ( null != m_pMultiPveLogic )
        {
            m_pMultiPveLogic.DoCommand(msg, eRPCmdType.Attack,selfCmd);
        }
    }
    
#endregion

}
