﻿using UnityEngine;
using System.Collections;

public enum eMonsterColliderType
{
    Enter,
    Stay,
    Exit,
}
public class MonsterCollider : MonoBehaviour {

    private Rigidbody m_rigidbody;
    private Transform m_myTrans;
    public CBaseNpc pNpc;

    private bool m_bLockY;
    void Awake()
    {
        m_rigidbody = rigidbody;
        m_myTrans = transform;
        m_bLockY = false;
    }

    void OnCollisionEnter(Collision collision)
    {
        Lock(collision, true);
        Collision(collision, eMonsterColliderType.Enter);
    }

    void OnCollisionStay(Collision collision)
    {
        Lock(collision, true);
    }


    void OnCollisionExit(Collision collision)
    {
        Lock(collision, false);
        Collision(collision, eMonsterColliderType.Exit);
    }


    void Lock(Collision collision, bool bLock)
    {
        if (m_bLockY == bLock)
        {
            return;
        }
        if (null == pNpc)
        {
            return;
        }
        int layer = collision.gameObject.layer;


        if (layer == DEFINE.AVATAR_LAYER || layer == DEFINE.MONSTER_LAYER)
        {
            CStateManager stateMgr = pNpc.GetStateMgr();
            eActionState currState = stateMgr.GetCurrActState();

            bool bRun = (currState == eActionState.Run || currState == eActionState.Walk);
            if (stateMgr != null && bLock && bRun)
            {
                return;
            }

            if (bLock)
            {
                if (collision.transform.root.position.y < m_myTrans.position.y)
                {
                    m_rigidbody.constraints |= RigidbodyConstraints.FreezePositionY;
                    m_bLockY = true;
                }
            }
            else
            {
                m_rigidbody.constraints &= ~RigidbodyConstraints.FreezePositionY;
                m_bLockY = false;
            }
        
        }

    }

    void Collision(Collision collision, eMonsterColliderType type)
    {
        if (null == pNpc)
        {
            return;
        }
        int layer = collision.gameObject.layer;

        if (layer == DEFINE.AIR_WALL && collision.contacts.Length > 0)
        {
            Vector3 hitPoint = collision.contacts[0].point;
            hitPoint = new Vector3(hitPoint.x, m_myTrans.position.y, hitPoint.z);
            //有碰撞
            float distance = Common.Get2DVecter3Length(m_myTrans.position, hitPoint);
            float radius = pNpc.CharacterRadius;
            if (distance < radius)
            {
                pNpc.SetPosition(Common.GetRayPosition(hitPoint, m_myTrans.position, radius));
            }
        }
        else if (layer == DEFINE.TERRAINLAYER)
        {
            pNpc.IsInGround = (type == eMonsterColliderType.Enter || type == eMonsterColliderType.Stay);
        }
    }
}
