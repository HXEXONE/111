﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Protocol;

/// <summary>
/// monster 多人联机逻辑部分
/// </summary>
public class MultiPveLogic
{
    private Monster m_pMonster = null;
    //private int m_nBuffFrame = 0;

    private bool m_bCanKill = false;
    public bool CanKill
    {
        get { return m_bCanKill; }
        set { m_bCanKill = value; }
    }

    //当前玩家的指令
    private RealPlayerCmd m_pCurCmd;
    public RealPlayerCmd CurCmd
    {
        get { return m_pCurCmd; }
        set { m_pCurCmd = value; }
    }

    //上一次玩家的指令
    private RealPlayerCmd m_pLastCmd;
    public RealPlayerCmd LastCmd
    {
        get { return m_pLastCmd; }
        set { m_pLastCmd = value; }
    }


    public MultiPveLogic(Monster monster)
    {
        m_pMonster = monster;

        //m_nBuffFrame = 0;
        m_pLastCmd = null;

        //m_bCanKill = AvatarOnlineInfo.IsHost ? true : false;
        m_bCanKill = true;
    }

    //public void ResetBuffTime() { m_nBuffFrame = 0; }


    public void DoCommand(object msg, eRPCmdType type,bool selfCmd)
    {
        CommandInfo commandInfo = new CommandInfo();
        uint uiCmdStamp = 0;

        if (type == eRPCmdType.Move)
        {
            MonsterMoveCmdInfo moveInfo;

            if (selfCmd) //是本机指令
            {
                G2CPveMonsterMove moveCmd = msg as G2CPveMonsterMove;
                moveInfo = new MonsterMoveCmdInfo(moveCmd.fMoverPosX,
                                                                                                                moveCmd.fMoverPosY,
                                                                                                                moveCmd.uiSyncType,
                                                                                                                moveCmd.monsterIndex,
                                                                                                                moveCmd.targetIndex,
                                                                                                                moveCmd.uiTimestamp);
            }
            else
            {
                G2CNotifyPveOtherMonsterMove moveCmd = msg as G2CNotifyPveOtherMonsterMove;
                moveInfo = new MonsterMoveCmdInfo(moveCmd.fMoverPosX,
                                                                                                  moveCmd.fMoverPosY,
                                                                                                  moveCmd.uiSyncType,
                                                                                                  moveCmd.monsterIndex,
                                                                                                  moveCmd.targetIndex,
                                                                                                  moveCmd.uiTimestamp);
            }

            uiCmdStamp = moveInfo.uiTimestamp; 
            commandInfo = moveInfo as CommandInfo;
        }
        else if (type == eRPCmdType.Attack)
        {
            AttackCmdInfo attackInfo;
            if (selfCmd)
            {
                G2CPveDoAttack attackCmd = msg as G2CPveDoAttack;
                attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);

            }
            else
            {
                G2CNotifyPveBeingAttack attackCmd = msg as G2CNotifyPveBeingAttack;
                attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
            }

            uiCmdStamp = attackInfo.uiTimestamp;
            commandInfo = attackInfo as CommandInfo;
        }

        if (PvpMsgMgr.Timestamp > uiCmdStamp)
        {
            //分析目标的消息检测点
            uint targetFrame = PvpMsgMgr.GetFrame(uiCmdStamp);
            //MyLog.Log("targetFrame frame : " + targetFrame);

            uint myFrame = PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp);
            //MyLog.Log(" current myFrame  : " + myFrame);

            uint checkFrame = PvpMsgMgr.GetCheckFrame(targetFrame);

            eCmdExecuteType executeType = eCmdExecuteType.None;
            if (myFrame < checkFrame)
            {
                //等待执行
                executeType = eCmdExecuteType.Wait;
                CurCmd = new RealPlayerCmd(commandInfo.Copy(), type, executeType);
            }
            else
            {
                executeType = myFrame == checkFrame ? eCmdExecuteType.Execute : eCmdExecuteType.Timeout;
                CurCmd = new RealPlayerCmd(commandInfo.Copy(), type, executeType);
                if (type == eRPCmdType.Move)
                {
                    //Execute
                    RecvMove((MonsterMoveCmdInfo)commandInfo.Copy());
                }
                else if (type == eRPCmdType.Attack)
                {
                    //Execute
                    RecvAttack((AttackCmdInfo)commandInfo.Copy());
                }
                //保存当前的指令                    
                CurCmd.isExecute = executeType == eCmdExecuteType.Execute ? true : false;
                LastCmd = CurCmd.DeepCopy();
            }
        }
        else
        {
            //说明卡了,补帧
            MyLog.LogError("Need Fix Frame !   " + PvpMsgMgr.Timestamp + " cmdStamp : " + uiCmdStamp);
            //临时解决方案.
            PvpMsgMgr.Timestamp = uiCmdStamp + PvpDefine.FixTimestamp;
            DoCommand(msg, type, selfCmd);
        }
    }

    public void RecvMove(MonsterMoveCmdInfo moveInfo)
    {
        //MyLog.Log( this + " RecvMove : " + CurCmd.actionType + " myFrame : " + PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp));
        CBaseState baseState = m_pMonster.GetCurrState();
        if (!baseState.CanBeBreak)
        {
            return;
        }


        CBaseNpc target = m_pMonster.CurrBattleScene.GetNpc(moveInfo.targetIndex);
        if (null != target)
        {
            m_pMonster.SetFollowTransform(target.GetTransform(), true, true);
            m_pMonster.EnterState(eActionState.Run);
        }
    }

    public void RecvAttack(AttackCmdInfo attackInfo)
    {
        CBaseState baseState = m_pMonster.GetCurrState();
        if (!baseState.CanBeBreak /*|| !CanUseSkillManully()*/)
        {
            return;
        }

        if (attackInfo.fEulerY != 0f)
        {
            m_pMonster.SetEulerY(attackInfo.fEulerY);
        }

        m_pMonster.DoUseSkillEvent(new UseSkillCommandArg(attackInfo.uiSkillID, null));
        
    }

    public void Release() 
    {
        CurCmd = null;       
    }

    public void Update() 
    {
        if (null != CurCmd && CurCmd.isExecute == false)
        {
            if (CurCmd.executeType == eCmdExecuteType.Wait)
            {
                //只可能是wait
                if (MultiPveMsg.IsLogicTurn)
                {
                    //马上执行
                    if (CurCmd.cmdType == eRPCmdType.Move)
                    {
                        RecvMove((MonsterMoveCmdInfo)CurCmd.cmdInfo);
                    }
                    else if (CurCmd.cmdType == eRPCmdType.Attack)
                    {
                        RecvAttack((AttackCmdInfo)CurCmd.cmdInfo);
                    }
                    //保存当前的指令
                    CurCmd.isExecute = true;
                    LastCmd = CurCmd.DeepCopy();
                }
            }
            else if (CurCmd.executeType == eCmdExecuteType.Timeout)
            {
//                 if (m_nBuffFrame > 0)
//                 {
//                     m_nBuffFrame--;
//                 }
//                 else
                {
                    Time.timeScale = 1.0f; //还原
                    CurCmd.isExecute = true;
                }
            }
        }
    }
}
