﻿using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AvatarPvpLogic
{
    private Avatar m_pAvatar;
    //请求的消息队列
    private Queue<RealPlayerCommand> m_CommandReqQueue = new Queue<RealPlayerCommand>();

    private eActionState m_eCurrentState; //

    private Timer m_pLocationUpdate = new Timer();
    private Timer m_pRecvBufferTimer = new Timer(); //
    private Timer m_pSendBuffTimer = new Timer();


    public RealPlayerCmd LastCmd
    {
        get { return m_pAvatar.LastCmd; }
        set { m_pAvatar.LastCmd = value; }
    }

    public RealPlayerCmd CurCmd
    {
        get { return m_pAvatar.CurCmd; }
        set { m_pAvatar.CurCmd = value; }
    }

    private eMsgLockType m_eMsgLock;
    public eMsgLockType MsgLock
    {
        get { return m_eMsgLock; }
        set { m_eMsgLock = value; }
    }

    public AvatarPvpLogic(Avatar avatar)
    {
        m_pAvatar = avatar;
        m_eMsgLock = eMsgLockType.Lock;
        m_CommandReqQueue.Clear();
        m_pRecvBufferTimer.SetTimer(PvpDefine.FixBufferTime);//100ms缓冲时间
        m_pSendBuffTimer.SetTimer(PvpDefine.FixBufferTime);//100ms

    }

    public void ReqPvpMove(Vector3 hitPos, eSyncMove syncType)
    {
        ReqMove(hitPos, syncType);

//         if (m_CommandReqQueue.Count == 0)
//         {
//             ReqMove(hitPos, syncType);
//         }
//         else
//         {
//             m_pAvatar.LockCmdType = eRPCmdType.Move;
//             m_eCurrentState = m_pAvatar.GetCurrActState();
//             m_CommandReqQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Move, new object[] { hitPos, syncType }));
//         }
    }

    public void ReqPvpLocation()
    {
        m_eCurrentState = eActionState.None;
        //m_CommandReqQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Location, m_pAvatar.GetTransform()));
    }

    public void ReqPvpDoAttack(uint uiSkillID, Vector3 turnDirection, uint index)
    {

        ReqAttack(uiSkillID, turnDirection, index);

//         m_pAvatar.LockCmdType = type == eSyncAttack.Self ? eRPCmdType.Attack : eRPCmdType.None;
//         if (m_CommandReqQueue.Count == 0)
//         {
//             ReqAttack(uiSkillID, turnDirection, type);
//         }
//         else
//         {
//             m_eCurrentState = m_pAvatar.GetCurrActState();
//             m_CommandReqQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Attack, new object[] { uiSkillID, turnDirection, type }));
//         }
    }

    public void ReqSelfDataChange(List<PvpChangeData> dataList)
    {
        //暂不处理..
        //m_RequestCommand.Enqueue(new RealPlayerCommand(eRPCmdType.DataChange, dataList));
        //m_bLockBehaviour = true;

        m_eCurrentState = eActionState.None;

        if (m_pAvatar.CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            PvpMsgMgr.ReqSelfDataChange(AvatarOnlineInfo.PvpMsgIndex, dataList);
        }

    }


    public void RecvPvpAttack(N2CPvpDoAttack msg)
    {
        //MyLog.Log(" RecvPvpAttack ." + Time.time);
        //DoCommand(msg, eRPCmdType.Attack);

//         if (m_pAvatar.CommandRecvQueue.Count == 0)
//         {
//             RecvAttack(msg);
//         }
//         else
//         {
//             AvatarOnlineInfo.CommandCount++;
//             m_pAvatar.CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Attack, msg));
//         }
    }

    public void RecvPvpMove(N2CPvpMove msg)
    {
        //MyLog.Log(" RecvPvpMove .. : " + Time.time );

        //DoCommand(msg, eRPCmdType.Move);

//         if (m_pAvatar.CommandRecvQueue.Count == 0)
//         {
//             RecvMove(msg);
//         }
//         else
//         {
//             AvatarOnlineInfo.CommandCount++;
//             m_pAvatar.CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Move, msg));
//         }
    }

    public void DoCommand(object msg, eRPCmdType type)
    {
        m_pAvatar.DoCommand(msg, type);
    }

//     public void DoCommand(object msg, eRPCmdType type)
//     {
//         Debug.Log(" DoCommand : " + type + " time : " + System.DateTime.Now.Millisecond);
// 
//         if (type == eRPCmdType.Move)
//         {
//             N2CPvpMove moveCmd = msg as N2CPvpMove;
//             MoveCmdInfo moveInfo = new MoveCmdInfo(moveCmd.fDesPosX, moveCmd.fDesPosY, moveCmd.fMoverPosX, moveCmd.fMoverPosY, moveCmd.uiSyncType, moveCmd.uiTimestamp);
// 
//             if (PvpMsgMgr.Timestamp > moveCmd.uiTimestamp)
//             {
//                 //分析目标的消息检测点
//                 uint targetFrame = PvpMsgMgr.GetFrame(moveCmd.uiTimestamp);
//                 Debug.Log("before frame : " + targetFrame);
// 
//                 uint myFrame = PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp);
//                 Debug.Log(" now myFrame  : " + myFrame);
// 
//                 uint checkFrame = PvpMsgMgr.GetCheckFrame(targetFrame);
//                 if (myFrame == checkFrame)
//                 {
//                     //Execute
//                     RecvMove(moveInfo);
//                     //保存当前的指令                    
//                     LastCmd = new RealPlayerCmd(moveInfo.Copy(), CmdActionType.Execute);
//                     CurCmd = null;
//                 }
//                 else
//                 {
//                     CmdActionType actionType = myFrame < checkFrame ? CmdActionType.Wait : CmdActionType.FixDelay;
//                     CurCmd = new RealPlayerCmd(moveInfo.Copy(), actionType);      
//                 }
//             }
//             else
//             {
//                 //说明卡了,补帧
//             }
//         }
//         else if (type == eRPCmdType.Attack)
//         {
//             N2CPvpDoAttack attackCmd = msg as N2CPvpDoAttack;
//             AttackCmdInfo attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
// 
//             if (PvpMsgMgr.Timestamp > attackCmd.uiTimestamp)
//             {
//     
//             }
//         }
//     }

    public void RecvPvpLocation(N2CPvpLocationChange locationMsg)
    {
        //MyLog.Log(" RecvPvpLocation .. : " + Time.time);
        AvatarOnlineInfo.CommandCount++;
       /* m_pAvatar.CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Location, locationMsg));*/
    }

    private void SendRequestCmd()
    {
        //指令为空了才能执行
        if (m_CommandReqQueue.Count > 0 && AvatarOnlineInfo.CommandCount == 0 && m_pSendBuffTimer.IsExpired(true))
        {
            RealPlayerCommand command = m_CommandReqQueue.Peek();
            object info = command.commandInfo;
            //MyLog.Log(" SendReqCmd : " + command.commandType + " , " + Time.time);
            switch (command.commandType)
            {
                case eRPCmdType.Move:
                    {
                        object[] args = info as object[];
                        ReqMove((Vector3)args[0], (eSyncMove)args[1]);
                    }
                    break;
                case eRPCmdType.Attack:
                    {
                        object[] args = info as object[];
                        ReqAttack((uint)args[0], (Vector3)args[1], (uint)args[2]);
                    }
                    break;
                case eRPCmdType.Location:
                    {
                        ReqLocation();
                    }
                    break;
                case eRPCmdType.DataChange:
                    break;
                default:
                    break;
            }
            m_CommandReqQueue.Dequeue();
        }

    }

//     private void RecvRequestCmd()
//     {
//         if (null == m_pAvatar.GetTransform()) return;
// 
//         if (m_pAvatar.CommandRecvQueue.Count > 0 && m_pRecvBufferTimer.IsExpired(true))
//         {
//             RealPlayerCommand command = m_pAvatar.CommandRecvQueue.Peek();
//             object info = command.commandInfo;
//             //MyLog.Log(" RecvRequestCmd :   " + command.commandType + " " + System.DateTime.Now.Millisecond);
//             switch (command.commandType)
//             {
//                 case eRPCmdType.Move:
//                     {
//                         //RecvMove((MoveCmdInfo)CurCmd.cmdInfo);
//                     }
//                     break;
//                 case eRPCmdType.Attack:
//                     {
//                         object[] args = info as object[];
//                         //RecvAttack((AttackCmdInfo)info);
//                     }
//                     break;
// 
//                 case eRPCmdType.Location:
//                     {
//                         RecvLocation((N2CPvpLocationChange)info);
//                     }
//                     break;
//                 default:
//                     break;
//             }
//             //MyLog.Log(" ExecuteCommand : " + System.DateTime.Now.Second + " , " + System.DateTime.Now.Millisecond);
//             AvatarOnlineInfo.CommandCount--;
//             m_pAvatar.CommandRecvQueue.Dequeue();
//         }
//     }

    private void ReqMove(Vector3 hitPos, eSyncMove syncType)
    {
        //MyLog.Log(" ReqMove : " + syncType);

        if (m_pAvatar.CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            PvpMsgMgr.ReqPvpMove(m_pAvatar, hitPos, syncType);
        }
        else if (m_pAvatar.CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            MultiPveMsg.ReqPlayerMove(m_pAvatar, hitPos, syncType);
        }
    }

    private void ReqAttack(uint uiSkillID, Vector3 turnDirection, uint index)
    {
        //MyLog.Log(" ReqAttack : " + uiSkillID);
        //m_bWaitingMsg = true;

        float eulerY = 0f;
        if (turnDirection != Vector3.zero)
        {
            Quaternion toTarget = Quaternion.LookRotation(turnDirection);
            eulerY = toTarget.eulerAngles.y;
        }                

        if (m_pAvatar.CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            PvpMsgMgr.ReqPvpDoAttack(uiSkillID, eulerY, index, m_pAvatar.GetTransform());
        }        
        else if ( m_pAvatar.CurrBattleScene.BattleType == eBattleType.MultiPve )
        {
            MultiPveMsg.ReqDoAttack(uiSkillID, eulerY, index, m_pAvatar.GetTransform());
        }
       
    }

    private void ReqLocation()
    {
        //MyLog.Log(" ReqLocation : "  + m_pAvatar.GetTransform().position);
        //m_bLockBehaviour = true;
        PvpMsgMgr.ReqPvpLocationChange(AvatarOnlineInfo.PvpMsgIndex, m_pAvatar.GetTransform());
    }

    private void FixPosition() 
    {

    }

    private void RecvLocation(N2CPvpLocationChange locationMsg)
    {
        PvpLocationInfoList locationList = locationMsg.sLocationList; ;
        Vector3 position = new Vector3(locationList[0].fPosX, PvpDefine.PvpScenceYPos, locationList[0].fPosY);
        //MyLog.Log(" ReceiveLocation : " + position + " , " + m_pAvatar.GetPosition() + " Time : " + Time.time);
        //m_pAvatar.LockBehaviour = false;     
    }

    public void Update()
    {
//         if (null != CurCmd)
//         {
//             uint myFrame = PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp);
// 
//             //只可能是wait/Fix传过来的
//             if (myFrame % PvpDefine.IntervalFrame == 0)
//             {
//                 //马上执行
//                 RecvMove((MoveCmdInfo)CurCmd.cmdInfo);
//                 //保存当前的指令                
//                 LastCmd = CurCmd.DeepCopy();                
//                 CurCmd = null;
//                 Debug.Log(" LastMoveCmd : " + LastCmd.actionType);
//             }                    
//         }


        SendRequestCmd();
        //RecvRequestCmd();
    }

}
