﻿using UnityEngine;
using System;
using System.Collections.Generic;
using Protocol;

public struct AvatarOnlineInfo
{
    public static bool IsHost = false;
    public static int PvpMsgIndex = 0;
    public static int CommandCount = 0;
}

public class RealAvatar : BaseBattlePlayer
{
    private int m_nBuffFrame = 0;

    protected bool m_bCanKill = false;
    public bool CanKill
    {
        get { return m_bCanKill; }
        set { m_bCanKill = value; }
    }

    protected float m_fAddMoveSpeed = 0f;
    public float AddMoveSpeed
    {
        set
        {
            m_fAddMoveSpeed = value;
        }
        get { return m_fAddMoveSpeed; }
    }

    protected float m_fTimeScale = 1.0f;

    public void ResetBuffTime() { m_nBuffFrame = 0; }


    //当前玩家的指令
    private RealPlayerCmd m_pCurCmd;
    public RealPlayerCmd CurCmd
    {
        get { return m_pCurCmd; }
        set { m_pCurCmd = value; }
    }

    //上一次玩家的指令
    private RealPlayerCmd m_pLastCmd;
    public RealPlayerCmd LastCmd
    {
        get { return m_pLastCmd; }
        set { m_pLastCmd = value; }
    }


    //接收的指令队列
    protected Queue<RealPlayerCmd> m_CommandRecvQueue = new Queue<RealPlayerCmd>();
    public Queue<RealPlayerCmd> CommandRecvQueue
    {
        get { return m_CommandRecvQueue; }
    }

    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.UNTAGGED_OBJECT_TAG)
    {
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);

        AvatarOnlineInfo.CommandCount = 0;

        m_nBuffFrame = 0;
        m_fTimeScale = 1.0f;
        m_pLastCmd = null;


        if (battlescene.BattleType == eBattleType.Pvp)
        {
            m_bCanKill = AvatarOnlineInfo.IsHost ? true : false; //客机不能死,只有等主机通知
        }
    }

    public override void EnterState(eActionState state, bool forceBreak = false)
    {
        base.EnterState(state, forceBreak);

        if (state != eActionState.Attack)
        {
            NextPosition = Vector3.zero;
        }
    }

    public override bool IsKill()
    {
        if (CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            return m_bCanKill;
        }
        return base.IsKill();
    }

    public override void AddHp(int nHp, bool critical = false, CBaseNpc attack = null, bool fromMsg = false)
    {
        base.AddHp(nHp, critical, attack, fromMsg);

        if (AvatarOnlineInfo.IsHost)
        {
            Protocol.PvpChangeData hpInfo = new Protocol.PvpChangeData();
            hpInfo.iNewValue = (float)GetHp();

            Avatar avatar = this as Avatar;
            if (null != avatar)
            {
                hpInfo.uiDataType = (byte)ePvpDataType.AvatarHp;
            }
            else if (this is OnlineAvatar)
            {
                hpInfo.uiDataType = (byte)ePvpDataType.OtherHp;
                avatar = (this as OnlineAvatar).AvatarPlayer;
            }

            if (null != avatar)
            {
                avatar.TriggerDataChange(new Protocol.PvpChangeDataList() { hpInfo });
            }
        }
    }

    public override void AddMp(int nMp)
    {
        base.AddMp(nMp);

        if (CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            LeagueBattleInfoMediator leagueUI = SingletonObject<LeagueBattleInfoMediator>.GetInst();
            if (this is Avatar)
            {
                leagueUI.SetLeftValue(m_nMp, m_nMaxMp);
            }
            else if (this is OnlineAvatar)
            {
                leagueUI.SetRightValue(m_nMp, m_nMaxMp);
            }
        }
        else
        {
            //精力值面板更新...   
            SingletonObject<RoleMediator>.GetInst().SetEnergyValue(m_nMp, m_nMaxMp);
        }
    }


    public virtual void DoCommand(object msg, eRPCmdType type)
    {
        //MyLog.LogError(" DoCommand : " + type + " time : " + System.DateTime.Now.Millisecond);       

        CommandInfo commandInfo = new CommandInfo();
        uint uiCmdStamp = 0;

        if (type == eRPCmdType.Move)
        {
            MoveCmdInfo moveInfo = null;
            if (this is Avatar)
            {                
                //判断是pve还是pvp
                if (CurrBattleScene.BattleType == eBattleType.Pvp)
                {
                    N2CPvpMove moveCmd = msg as N2CPvpMove;
                    moveInfo = new MoveCmdInfo(moveCmd.fDesPosX, moveCmd.fDesPosY, moveCmd.fMoverPosX, moveCmd.fMoverPosY, moveCmd.uiSyncType, moveCmd.uiTimestamp);
                }          
                else if (CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    G2CPveMove moveCmd = msg as G2CPveMove;
                    moveInfo = new MoveCmdInfo(moveCmd.fDesPosX, moveCmd.fDesPosY, moveCmd.fMoverPosX, moveCmd.fMoverPosY, moveCmd.uiSyncType, moveCmd.uiTimestamp);
                }
            }
            else
            {
                if (CurrBattleScene.BattleType == eBattleType.Pvp)
                {
                    N2CNotifyPvpOtherMove moveCmd = msg as N2CNotifyPvpOtherMove;
                    moveInfo = new MoveCmdInfo(moveCmd.fDesPosX, moveCmd.fDesPosY, moveCmd.fMoverPosX, moveCmd.fMoverPosY, moveCmd.uiSyncType, moveCmd.uiTimestamp);
                }
                else if (CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    G2CNotifyPveOtherMove moveCmd = msg as G2CNotifyPveOtherMove;
                    moveInfo = new MoveCmdInfo(moveCmd.fDesPosX, moveCmd.fDesPosY, moveCmd.fMoverPosX, moveCmd.fMoverPosY, moveCmd.uiSyncType, moveCmd.uiTimestamp);
                }                
            }
            if ( null == moveInfo )
            {
                return;
            }
            uiCmdStamp = moveInfo.uiTimestamp;
            commandInfo = moveInfo as CommandInfo;
        }
        else if (type == eRPCmdType.Attack)
        {
            AttackCmdInfo attackInfo = null;
            if (this is Avatar)
            {
                //判断是pve还是pvp
                if (CurrBattleScene.BattleType == eBattleType.Pvp)
                {
                    N2CPvpDoAttack attackCmd = msg as N2CPvpDoAttack;
                    attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
                }
                else if (CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    G2CPveDoAttack attackCmd = msg as G2CPveDoAttack;
                    attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
                }                
            }
            else
            {
                //判断是pve还是pvp
                if (CurrBattleScene.BattleType == eBattleType.Pvp)
                {
                    N2CNotifyPvpBeingAttack attackCmd = msg as N2CNotifyPvpBeingAttack;
                    attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
                }
                else if (CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    G2CNotifyPveBeingAttack attackCmd = msg as G2CNotifyPveBeingAttack;
                    attackInfo = new AttackCmdInfo(attackCmd.fEulerY, attackCmd.uiSkillID, attackCmd.uiTimestamp, attackCmd.uiUserType, attackCmd.sLocationList);
                }                

            }
            if ( null == attackInfo)
            {
                return;
            }
            uiCmdStamp = attackInfo.uiTimestamp;
            commandInfo = attackInfo as CommandInfo;
        }

        if (PvpMsgMgr.Timestamp > uiCmdStamp)
        {
            //分析目标的消息检测点
            uint targetFrame = PvpMsgMgr.GetFrame(uiCmdStamp);
            //MyLog.Log("targetFrame frame : " + targetFrame);

            uint myFrame = PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp);
            //MyLog.Log(" current myFrame  : " + myFrame);

            uint checkFrame = PvpMsgMgr.GetCheckFrame(targetFrame);

            eCmdExecuteType executeType = eCmdExecuteType.None;
            if (myFrame < checkFrame)
            {
                //等待执行
                executeType = eCmdExecuteType.Wait;
                CurCmd = new RealPlayerCmd(commandInfo.Copy(), type, executeType);
            }
            else
            {
                executeType = myFrame == checkFrame ? eCmdExecuteType.Execute : eCmdExecuteType.Timeout;
                CurCmd = new RealPlayerCmd(commandInfo.Copy(), type, executeType);
                if (type == eRPCmdType.Move)
                {
                    //Execute
                    ExecuteMove((MoveCmdInfo)commandInfo.Copy());
                }
                else if (type == eRPCmdType.Attack)
                {
                    //Execute
                    ExecuteAttack((AttackCmdInfo)commandInfo.Copy());
                }
                //保存当前的指令                    
                CurCmd.isExecute = executeType == eCmdExecuteType.Execute ? true : false;
                LastCmd = CurCmd.DeepCopy();
            }
        }
        else
        {
            //说明卡了,补帧
            MyLog.LogError("Need Fix Frame !   " + PvpMsgMgr.Timestamp + " cmdStamp : " + uiCmdStamp);
            //临时解决方案.
            PvpMsgMgr.Timestamp = uiCmdStamp + PvpDefine.FixTimestamp;
            DoCommand(msg, type);
        }
    }

    protected virtual void ExecuteMove(MoveCmdInfo moveInfo)
    {
        //MyLog.Log( this + " RecvMove : " + CurCmd.actionType + " myFrame : " + PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp));
        CBaseState baseState = GetCurrState();
        if (!baseState.CanBeBreak)
        {
            return;
        }

        Vector3 recvDestPos = new Vector3(moveInfo.fDesPosX, PvpDefine.PvpScenceYPos, moveInfo.fDesPosY);

//         bool equls = EqualWithLocation(moveInfo.fMoverPosX, moveInfo.fMoverPosY, 1.0f);
//         if (equls == false)
//         {
//             SetPosition(new Vector3(moveInfo.fMoverPosX, PvpDefine.PvpScenceYPos, moveInfo.fMoverPosY));
//         }

        //MovingFix(moveInfo);
        //FixingDelay(moveInfo.uiTimestamp);

        switch ((eSyncMove)moveInfo.uiSyncType)
        {
            case eSyncMove.TurningImmediateToRun:
                {
                    Command(eCommandType.RunTo, new RunToCommandArg(recvDestPos, true, true));
                }
                break;
            case eSyncMove.TurningSlowlyToRun:
                {
                    Command(eCommandType.RunTo, new RunToCommandArg(recvDestPos, false, true));
                }
                break;
            case eSyncMove.TurningOnly:
                {
                    Command(eCommandType.Turning, new TurningCommandArg(recvDestPos));
                }
                break;
            case eSyncMove.CallPartner:
                {
                    DoCallPartner();
                }
                break;
            case eSyncMove.BeginRide:
                {
                    BeginRide(false, 0, true);
                }
                break;
            case eSyncMove.BeiginFly:
                {
                    BeginFly(false, true);
                }
                break;
            case eSyncMove.HoldClick:
                {
                    OnHoldClick(recvDestPos);
                }
                break;
            default:
                {
                    MyLog.LogError(" error  Move Command !");
                }
                break;
        }
    }

    public void SendRequestEnter(int index) 
    {
        if (null != m_pPlatformReceiver)
        {
            //m_pPlatformReceiver.SendMessage("RequestEnter", this.m_myTrans.gameObject);
            PlatformMove move = CBaseScene.FindPlatform(index);
            if ( null != move )
            {
                m_pPlatformReceiver.RequestEnter(m_myTrans.gameObject, move.gameObject);
            }            
        }
    }

    private void ExecuteAttack(AttackCmdInfo attackInfo)
    {
//         if (attackInfo.uiUserType == (ushort)eSyncAttack.Self)
//         {


            uint startStamp = attackInfo.uiTimestamp;

            if (attackInfo.uiUserType == (byte)eSyncAttack.Player)
            {            
                CBaseState baseState = GetCurrState();
                if (!baseState.CanBeBreak /*|| !CanUseSkillManully()*/)
                {
                    return;
                }
                //攻击者 位置修复
                //FixDelayCommand(startStamp, startPos, direction);
                AttackingFix(attackInfo);
                FixingDelay(attackInfo.uiTimestamp);

                if (attackInfo.fEulerY != 0f)
                {
                    Turnimmediately(attackInfo.fEulerY);
                }

                List<CBaseNpc> targetList = IsMissSkill((int)attackInfo.uiSkillID) ? new List<CBaseNpc>() : m_targetList;
                this.DoUseSkillEvent(new UseSkillCommandArg(attackInfo.uiSkillID, targetList));

                //                 MyLog.LogError(this + " RecvAttack : " + attackInfo.uiSkillID +
                //                     " , " + GetPosition() +
                //                     " YEuler : " + m_myTrans.eulerAngles.y);
            }
            else if (attackInfo.uiUserType == (byte)eSyncAttack.Pet)
            {
                MyPet.DoUseSkillEvent(new UseSkillCommandArg(attackInfo.uiSkillID, new List<CBaseNpc> { this }));
            }
/*        }*/
    }

    public bool IsMissSkill(int skillKey)
    {
        SkillContent rollSkillLoader;

        bool isPartner = PartnerState == ePartnerState.Partner;
        if (isPartner)
        {
            if (ActivePartner == null) return false;

            PartnerModelContent partnerModelLoader = ActivePartner.PartnerLoader.ModelLoader;
            if (null == partnerModelLoader) return false;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(partnerModelLoader.RollSkill);

        }
        else
        {
            PlayerConfigContent configLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pPlayerLoader.Key);
            if (null == configLoader) return false;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(configLoader.RollID);
        }

        return (rollSkillLoader.Key == skillKey);
    }

    private void FixingDelay(uint targetStamp)
    {
        return;
        if (null == CurCmd)
            return;

        if (CurCmd.executeType == eCmdExecuteType.Timeout)
        {
            //延迟了,加速播放
            uint myFrame = PvpMsgMgr.GetFrame(PvpMsgMgr.Timestamp);
            //当前检查点
            uint targetFrame = PvpMsgMgr.GetFrame(targetStamp);
            uint checkFrame = PvpMsgMgr.GetCheckFrame(targetFrame);
            //下一个检测点
            uint nextFrame = checkFrame + PvpDefine.IntervalFrame;
            //判断延迟了多少帧
            uint timeoutFrame = nextFrame - myFrame;
            if (nextFrame > myFrame)
            {
                //加速
                float times = PvpDefine.IntervalFrame * 1.0f / timeoutFrame * 1.0f;
                MyLog.LogError(" times : " + times);
                Time.timeScale = times;
                m_nBuffFrame = (int)timeoutFrame; //加速多少帧
            }
            else
            {
                //太卡了,直接设置坐标!
            }
        }
    }


    private void MovingFix(MoveCmdInfo moveCmd)
    {
        if (null == CurCmd) return;

        float curStartStamp = moveCmd.uiTimestamp;
        Vector3 curStartPos = new Vector3(moveCmd.fMoverPosX, PvpDefine.PvpScenceYPos, moveCmd.fMoverPosY);
        Vector3 curDestpos = new Vector3(moveCmd.fDesPosX, PvpDefine.PvpScenceYPos, moveCmd.fDesPosY);



        switch (CurCmd.executeType)
        {
            case eCmdExecuteType.Wait:
            case eCmdExecuteType.Execute:
                {
                    if (GetCurrActState() != eActionState.Run)
                    {
                        //如果是不是run状态,说明之前不是run状态,或run状态被打断                        
                    }
                    else
                    {
                        break; //暂时屏蔽                        
                        //有细微的不同,需要插值                           
                        //推算出检查点的位置
                        if (null != LastCmd && LastCmd.cmdType == eRPCmdType.Move)
                        {
                            MoveCmdInfo lastCmdInfo = LastCmd.cmdInfo as MoveCmdInfo;
                            if (null != lastCmdInfo)
                            {
                                Vector3 lastDir = new Vector3(lastCmdInfo.fDesPosX, PvpDefine.PvpScenceYPos, lastCmdInfo.fDesPosY) -
                                                            new Vector3(lastCmdInfo.fMoverPosX, PvpDefine.PvpScenceYPos, lastCmdInfo.fMoverPosY);

                                float disTime = (PvpMsgMgr.Timestamp - curStartStamp) / 1000f;
                                float movement = disTime * MoveSpeed;
                                Vector3 checkPos = curStartPos + lastDir.normalized * movement;

                                //下一个检查点的位置
                                Vector3 nextCheckPos = checkPos + (curDestpos - checkPos).normalized * MoveSpeed * PvpDefine.FixTimestampSec;//  time : PvpDefine.FixIntervalTime

                                float distance = Common.Get2DVecter3Length(GetPosition(), nextCheckPos) - DEFINE.PVP_MOVEPOSITION_DIS;

                                float distanceBase = Common.Get2DVecter3Length(checkPos, nextCheckPos) - DEFINE.PVP_MOVEPOSITION_DIS;
                                float baseTime = distanceBase / MoveSpeed;

                                float curMovespeed = distance / baseTime;
                                AddMoveSpeed = curMovespeed - MoveSpeed;
                            }
                        }
                    }
                }
                break;
            case eCmdExecuteType.Timeout:
                {
                    //加速
                }
                break;
            default:
                return;
        }
    }

    public OnlineAvatar GetOnlineAvatar() 
    {
        OnlineAvatar otherAvatar  = null;
        if (m_pBattleScene.BattleType == eBattleType.Pvp)
        {
             otherAvatar = PvpManager.GetInst().GetEnemyPlayer();
        }
        else if (m_pBattleScene.BattleType == eBattleType.MultiPve)
        {
             otherAvatar = MultiPveManager.GetInst().GetEnemyPlayer();
        }

        return otherAvatar;
    }

    private void AttackingFix(AttackCmdInfo curCmd)
    {

        OnlineAvatar otherAvatar = GetOnlineAvatar();
        Avatar avatar = SingletonObject<Avatar>.GetInst();

        //技能状态就不修复
        //if (otherAvatar.GetCurrActState() == eActionState.Skill) return;

        if (this is Avatar && otherAvatar.GetCurrActState() == eActionState.Skill)
        {
            return;
        }
        if (this is OnlineAvatar && avatar.GetCurrActState() == eActionState.Skill)
        {
            return;
        }

        if (null == CurCmd) return;

        float curStartStamp = curCmd.uiTimestamp;
        Vector3 curStartPos = Vector3.zero;

        float vaglue = 1.0f;

        for (int i = 0, len = curCmd.sLocationList.Count; i < len; i++)
        {
            PvpLocationInfo location = curCmd.sLocationList[i];
            //Vector3 pos = new Vector3(location.fPosX, PvpDefine.PvpScenceYPos, location.fPosY);
            float eulerY = location.fEulerY;
            if (location.uiPlayerIDType == (byte)ePlayerIDType.AvatarSelf)  //收到自己的数据
            {
                //攻击方的位置信息,一定是攻击方自己
                bool equals = EqualWithLocation(location.fPosX, location.fPosY, vaglue);
                if (equals == false)
                {
                    SetPosition(CheckPvpPosition(this, location.fPosX, location.fPosY));
                    SetEulerY(eulerY);
                }
            }
            else if (location.uiPlayerIDType == (byte)ePlayerIDType.EnemyAvatar) //收到敌人的数据
            {
                //受击方的位置信息
                if (this is Avatar) //如果攻击方是自己,受击方就是otherAvatar
                {
                    bool equals = otherAvatar.EqualWithLocation(location.fPosX, location.fPosY, vaglue);
                    if (equals == false)
                    {
                        otherAvatar.SetPosition(CheckPvpPosition(otherAvatar, location.fPosX, location.fPosY));
                        otherAvatar.SetEulerY(eulerY);
                    }
                }
                else if (this is OnlineAvatar) //如果攻击方是敌人,受击方是Avatar
                {
                    bool equals = avatar.EqualWithLocation(location.fPosX, location.fPosY, 5f);
                    //在误差允许范围外,强行拉回
                    if (equals == false)
                    {
                        avatar.SetPosition(CheckPvpPosition(avatar, location.fPosX, location.fPosY));
                        avatar.SetEulerY(eulerY);
                    }
                }
            }
        }
    }

    public Vector3 CheckPvpPosition(RealAvatar target, float posx, float posz)
    {
        if (target.IsInFly()) //鸟上重新设置Y坐标
        {
            Vector3 petTransPosition = Common.GroundPosition(GetPosition(), DEFINE.TERRAINLAYER) + Vector3.up * DEFINE.PET_FLY_FIGHT_AVATAR_FLY_HEGHT;
            return new Vector3(posx, petTransPosition.y, posz); ;
        }

        return new Vector3(posx, PvpDefine.PvpScenceYPos, posz);
    }


    //根据时间戳,算出检查点的位置
    private Vector3 GetPositionForCheck(uint stamp, Vector3 startPos, Vector3 direction)
    {
        //目标的指令信息
        //目标执行指令的帧数
        uint targetFrame = PvpMsgMgr.GetFrame(stamp);
        //触发指令的帧数
        uint targetCheck = PvpMsgMgr.GetCheckFrame(targetFrame);

        uint targetInterval = targetCheck - targetFrame;
        //算出到检测点时候,目标的位置
        Vector3 targetPos = startPos;
        Vector3 targetCheckPos = targetPos + direction * MoveSpeed * targetInterval * PvpDefine.FrameTimeSec;

        return targetCheckPos;
    }



    public PvpLocationInfo GetLocationInfo(ePlayerIDType type, AttackCmdInfo attackInfo)
    {
        for (int i = 0, len = attackInfo.sLocationList.Count; i < len; i++)
        {
            PvpLocationInfo location = attackInfo.sLocationList[i];
            if (location.uiPlayerIDType == (byte)type)
            {
                return location;
            }
        }
        return null;
    }

    public bool IsLogicTurn
    {
        get 
        {
            if (m_pBattleScene.BattleType == eBattleType.Pvp)
            {
                return PvpMsgMgr.IsLogicTurn;
            }
            else if (m_pBattleScene.BattleType == eBattleType.MultiPve)
            {
                return MultiPveMsg.IsLogicTurn;
            }
            return true; 
        }
    }

    public override void Update()
    {
        base.Update();

        if (null != CurCmd && CurCmd.isExecute == false)
        {
            if (CurCmd.executeType == eCmdExecuteType.Wait)
            {
                //只可能是wait
                if (IsLogicTurn)
                {
                    //马上执行
                    if (CurCmd.cmdType == eRPCmdType.Move)
                    {
                        ExecuteMove((MoveCmdInfo)CurCmd.cmdInfo);
                    }
                    else if (CurCmd.cmdType == eRPCmdType.Attack)
                    {
                        ExecuteAttack((AttackCmdInfo)CurCmd.cmdInfo);
                    }
                    //保存当前的指令
                    CurCmd.isExecute = true;
                    LastCmd = CurCmd.DeepCopy();
                }
            }
            else if (CurCmd.executeType == eCmdExecuteType.Timeout)
            {
                if (m_nBuffFrame > 0)
                {
                    m_nBuffFrame--;
                }
                else
                {
                    Time.timeScale = 1.0f; //还原
                    CurCmd.isExecute = true;
                }
            }
        }
    }

    public override void SimpleMove(Vector3 dir, float speed)
    {
        //         if (m_nBuffFrame > 0)
        //         {
        //             m_nBuffFrame--;
        //         }
        //         else if (AddMoveSpeed != 0)        
        //         {
        //             AddMoveSpeed = 0;
        //         }

        speed += AddMoveSpeed;

        base.SimpleMove(dir, speed);
    }

    public override void Move(float fHorizontalSpeed, bool bForceCharacterMove = false, bool bMovingTurn = true, float fAngel = 0f)
    {
//         if (PvpMsgMgr.LockStep)
//         {
//             return;
//         }
        base.Move(fHorizontalSpeed, bForceCharacterMove, bMovingTurn, fAngel);
    }

    public override void UpdateTurn(Vector3 turnDirection, bool bImmediate, bool bNewbieuse = false)
    {
//         if (PvpMsgMgr.LockStep)
//         {
//             return;
//         }
        base.UpdateTurn(turnDirection, bImmediate, bNewbieuse);
    }

    public void Turnimmediately(float fEulerY)
    {
        SetEulerY(fEulerY);
    }


    /// <summary>
    /// 是否与本地坐标相等
    /// </summary>
    /// <param name="targetPosX">目标XPos</param>
    /// <param name="targetPosY">目标YPos</param>
    /// <param name="vagueValue">模糊值</param>
    public bool EqualWithLocation(float targetPosX, float targetPosY, float vagueValue = float.MinValue)
    {

        float myTransPosX = m_myTrans.position.x;
        float myTransPosY = m_myTrans.position.z;

        float curPosX = (float)Math.Round(targetPosX, 2);
        float curPosY = (float)Math.Round(targetPosY, 2);
        float transPosX = (float)Math.Round(myTransPosX, 2);
        float transPosY = (float)Math.Round(myTransPosY, 2);

        if (vagueValue != float.MinValue)
        {
            float distance = Vector2.Distance(new Vector2(curPosX, curPosY), new Vector2(transPosX, transPosY));
            //MyLog.LogError(" distance : " + distance);
            if (distance < vagueValue)
            {
                return true;
            }
        }

        bool equlsPos = transPosX.Equals(curPosX) && transPosY.Equals(curPosY);

        return equlsPos;

    }

}
