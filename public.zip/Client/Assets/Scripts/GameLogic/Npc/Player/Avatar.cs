using System;
using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Avatar : RealAvatar
{
    private UseSkillCallback UseSkillHandler = null;
    private LocationCallback LocationHandler = null;
    private MoveCallback MoveHandler = null;
    private DataChangeCallbak DataChangeHandler = null;


    public bool m_bInMouseControl = false;
    public bool InMouseControl
    {
        get { return m_bInMouseControl; }
        set { m_bInMouseControl = value; }
    }

    private CBaseNpc m_pProtectNpc; //�ػ����߻��͵�npc
    public CBaseNpc ProtectNpc
    {
        get { return m_pProtectNpc; }
        set { m_pProtectNpc = value; }
    }

    public static bool m_OffHandelClick = false; //�ر�Ӣ�۽�����Ļ��Ϣ

    private CEffectManage m_pSkillEffectMgr;

    private AvatarGestureCtrl m_pGesture;

    public Dictionary<Monster, CObject> m_dgMosterGuideDict = new Dictionary<Monster, CObject>();//ָ����ͷ�����ֵ�
    private GameObject m_goParentGuide;             //����ָ����ͷ������

    private Timer m_bemusedTimer;//����1��������

    public bool m_bGMInvincible = false;//GM�޵�

    private int m_nWaypointIndex;
    private bool m_bSetFootEffect = false; //

    //����
    protected ushort m_wComboNum;//������
    protected Timer m_ComboTimer;//������ʱ

    protected bool m_bDClickLocking = false;

    public bool DClickLocking
    {
        set { m_bDClickLocking = value; }
    }


    public override bool Trusteeship//�йܹһ�
    {
        set
        {
            base.Trusteeship = value;
            SingletonObject<AutoBattleMediator>.GetInst().IsAuto = value;
        }
        get
        {
            return base.Trusteeship;
        }
    }
    private eAvatarType m_eAvatarType = eAvatarType.NormalAvatar;
    public eAvatarType AvatarType
    {
        set { m_eAvatarType = value; }
        get { return m_eAvatarType; }
    }

    private AvatarPvpLogic m_pPvpLogic;

    private bool m_useOtherCameraID = false;
    public bool UseOtherCameraID
    {
        get { return m_useOtherCameraID; }
        set { m_useOtherCameraID = value; }
    }

    public eMsgLockType MsgLock
    {
        get 
        {
            if ( null == m_pPvpLogic )
            {
                return eMsgLockType.Error; 
            }
            return m_pPvpLogic.MsgLock;
        }
        set 
        {
            if ( null != m_pPvpLogic )
            {
                m_pPvpLogic.MsgLock = value;
            }
        }
    }

    // Use this for initialization
    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.AVATAR_OBJECT_TAG)
    {
        //������ʼ��
        List<CrystalItemInfo> atkCryItem = LongjingManager.GetInst().GetLongJingList(battlescene.BattleType, eLongJingPos.Attack);
        //�������� �ж������Ƿ�������    
        if (null != atkCryItem && atkCryItem.Count > 0)
        {
            CreateDragonshard(atkCryItem[0], eDragonshardType.avatarAttack);
        }
        else
        {
            m_pAtkDragon = null;            
        }
        //��������
        List<CrystalItemInfo> defCryItem = LongjingManager.GetInst().GetLongJingList(battlescene.BattleType, eLongJingPos.Defense);
        //�������� �ж������Ƿ�������     
        if (null != defCryItem && defCryItem.Count > 0)
        {
            CreateDragonshard(defCryItem[0], eDragonshardType.avatarDef);
        }
        else
        {
            m_pDefDragon = null;
        }

        m_nWaypointIndex = 1;
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);

        InitFSM();


        switch (battlescene.BattleType)
        {
            case eBattleType.Arena:
                {
                    AddBuff(DEFINE.ARENA_LIFE_BUFF, null, true);
                }
                break;
            case eBattleType.Wasteland:
                {
                    AddBuff(DEFINE.WASTELAND_LIFE_BUFF, null, true);
                }
                break;
            case eBattleType.Mining:
                {
                    AddBuff(DEFINE.MINING_LIFE_BUFF, null, true);
                }
                break;
            case eBattleType.Pvp:
            case eBattleType.MultiPve:
                {
                    AddBuff(DEFINE.WASTELAND_LIFE_BUFF, null, true);

                    m_pPvpLogic = new AvatarPvpLogic(this);

                    UseSkillHandler = ReqPvpDoAttack;
                    DataChangeHandler = ReqSelfDataChange;
                    MoveHandler = ReqPvpMove;
                    LocationHandler = ReqPvpLocation;
                }
                break;
            default:
                break;
        }

        m_partnerFSM.EnterStateEvent += onPartnerEntry;
        m_partnerFSM.LeaveStateEvent += onPartnerExit;

        if (null == m_pSkillEffectMgr)
        {
            m_pSkillEffectMgr = new CEffectManage();
            m_pSkillEffectMgr.Init();
        }

        SingletonObject<BattleGuide>.GetInst().BattleScene = m_pBattleScene;

        m_bemusedTimer = new Timer();
        m_bemusedTimer.SetTimer(1f);
        m_bSetFootEffect = true;

        //����
        m_wComboNum = 0;
        m_ComboTimer = new Timer();


        UpdatePanel(m_skillList, true);
    }


    public void SetSkillEffect(uint effectID)
    {
        if (null != m_pSkillEffectMgr)
        {
            m_pSkillEffectMgr.SetEffect(effectID);
        }

    }



    public override void Update()
    {
        base.Update();
        //MyLog.Log("Avatar HP: " + m_nHp + "/"+ GetMaxHp());
        //MyLog.Log("Avatar State: " + GetCurrActState());
        //MyLog.Log("Avatar IsStun: " + m_buffMgr.IsStun);
        //MyLog.Log("Avatar IsOverlord: " + m_buffMgr.IsOverlord);

        //if (!m_characterController.isGrounded)
        //{
        //    MyLog.LogError(" isGrounded false ");
        //}

        if (null != m_pPvpLogic)
        {
            m_pPvpLogic.Update();

        }

        if (m_ComboTimer != null && m_ComboTimer.IsExpired(false))
        {
            ClearCombo();
            m_ComboTimer.Release();
        }

        if (null != m_pSkillEffectMgr)
        {
            m_pSkillEffectMgr.Update();
        }

        if (null != m_pGesture)
        {
            m_pGesture.Update();
        }
        EnableMonsterParentGuide();
        EnableMonsterGuide();

        #region ��ݼ�
#if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.F1))
        {
            //UseSkillManully(51047601);
            //CMusicManager.GetInst().CreateSound(m_myTrans.gameObject, 202);
            AddBuff(2057);
            AddBuff(2116);
            //AddBuff(2084);

            InvincibleGMCommand();
        }

        if (Input.GetKeyDown(KeyCode.P))
        {

            AddHp(1 - GetMaxHp());
            //m_pBattleScene.Pause(true);
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            CallPartner(false);
        }

        if (Input.GetKeyDown(KeyCode.O))
        {
 
            SingletonObject<EnemyAvatar>.GetInst().AddHp(1 - GetMaxHp());
            //m_pBattleScene.Pause(false);
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            SingletonObject<BattleScene>.GetInst().GameOver(true, true);
            //CallPartner(true);
        }

        if (Input.GetKeyDown(KeyCode.Z))
        {
            SingletonObject<EnemyAvatar>.GetInst().AddHp(1 - GetMaxHp());
        }

        if (Input.GetKeyDown(KeyCode.X))
        {
            AddHp(1 - GetMaxHp());
        }

        if (Input.GetKeyDown(KeyCode.G))
        {
          
            for (int i = 0, len = m_rangeNpcList.Count; i < len; i++)
            {
                if (m_rangeNpcList[i] == this)
                {
                    //SetHp(m_pCard.nMaxHp / 2);
                    AddHp(-1);
                    continue;
                }

                CBaseNpc target = m_rangeNpcList[i];
                //target.AddHp(-target.GetMaxHp());
      
                target.AddHp(-target.GetMaxHp());
            }
        }
        if (Input.GetKeyDown(KeyCode.J))
        {
            //SingletonObject<BattleScene>.GetInst().GameOver(true, true);
            //AddHp(-GetMaxHp() / 2);
        }
#endif
        #endregion

   
        if ((m_pBattleScene.BattleType == eBattleType.PVE || m_pBattleScene.BattleType == eBattleType.ClimbTower) && m_myTrans != null && null != m_directPoint)
        {
            if (m_nWaypointIndex != -1)
            {
                GameObject gobj = m_pBattleScene.FindWaypoint("area_" + string.Format("{0:D2}", m_nWaypointIndex));
                if (gobj != null && gobj.activeSelf)
                {
                    Vector3 direction = gobj.transform.position - m_myTrans.position;
                    m_directPoint.transform.forward = new Vector3(direction.x, 0f, direction.z);
                    m_directPoint.transform.position = m_myTrans.position + m_directPoint.transform.forward * 1f + Vector3.up * 0.5f;
                }
                else
                {
                    m_nWaypointIndex++;

                    if (m_nWaypointIndex >= DEFINE.MAX_WAY_POINT_COUNT)
                    {
                        m_nWaypointIndex = -1;
                        //m_directPoint.SetActive(false);
                        SetFootEffect(false);
                    }
                }
            }
        }


        //��ֹ����͵�ǰĿ���غ�
        CBaseNpc currTarget = CurrTarget;
        //         if (currTarget != null && m_myTrans != null && m_characterController != null && m_characterController.enabled)
        //         {
        //             Vector3 myPosition = m_myTrans.position;
        //             Vector3 targetPosition = currTarget.GetPosition();
        //             float distance = Common.Get2DVecter3Length(m_myTrans.position, targetPosition);
        //             if (distance < CharacterRadius + currTarget.CharacterRadius)
        //             {
        //                 Vector3 dir = (myPosition - targetPosition).normalized;
        //                 m_characterController.SimpleMove(dir * 20 * Time.deltaTime);
        //             }
        //         }
    }



    public override void ChangeModel(CObject model, CAnimator anim)
    {
        base.ChangeModel(model, anim);

        //��ͷ������ģ��

        if (null != m_directPoint)
        {
            m_directPoint.transform.parent = m_pNpcObj.transform;
            //m_directPoint.transform.localPosition = Vector3.zero;
            m_directPoint.transform.localPosition = new Vector3(0f, 0f, 1f);
            m_directPoint.transform.localRotation = Quaternion.Euler(Vector3.zero);
        }

        if (null != m_goParentGuide)
        {
            m_goParentGuide.transform.parent = m_pNpcObj.transform;
            m_goParentGuide.transform.localPosition = Vector3.zero;
            m_goParentGuide.transform.localScale = Vector3.one;
        }


        //����ͷ������ģ��
        //SceneContent sceneLoader = m_pBattleScene.GetSceneLoader();
        //if (sceneLoader != null)
        //{
        //    CCamera.GetInst().SetCameraEffect(sceneLoader.GetCameraID(), null, new object[] { m_pNpcObj.gameCObject });
        //}

        //InitFollowCamera();
        GameObject cameraGo = CurrBattleScene.BattleType == eBattleType.Arena ? CurrBattleScene.TempCameraAncher : m_pNpcObj.gameCObject;
        SetFollowCamera(cameraGo, eCAMERAFOLLOW.DIRECT);
        //����������Ч����
        RainOrSnow.GetInst().ResetTransform(model.transform, CCamera.GetInst().GetCameraObj().transform);
    }


    public void CreateMonsterGuide(Monster monster)
    {
        if (monster.NpcGroup != eNpcGroup.Evil)
            return;
        if (m_dgMosterGuideDict.ContainsKey(monster))
        {
            return;
        }
        CObject GuideObject;
        GuideObject = new CObject("resources/effect/other/other_guaiwuzhishi.x");
        GuideObject.Args = new object[1] { monster.Index };
        GuideObject.CallBack = LoadGuideCompleted;
        GuideObject.IsMemoryFactory = true;
        GuideObject.ObjectType = eObjectType.Guide;
        GuideObject.Layer = DEFINE.AVATAR_LAYER;
        GuideObject.LoadObject();

        m_dgMosterGuideDict.Add(monster, GuideObject);
    }

    
    private void UpdateMosterGuide(Monster monster)
    {
        if (!m_dgMosterGuideDict.ContainsKey(monster))
            return;
        GameObject guideGameobject = m_dgMosterGuideDict[monster].GetObj();
        if (null == guideGameobject)
        {
            return;
        }
        Vector3 monterPosition = monster.GetPosition();
        guideGameobject.transform.LookAt(new Vector3(monterPosition.x, guideGameobject.transform.position.y, monterPosition.z));
    }

    private void LoadGuideCompleted(GameObject o, params object[] args)
    {
        if (null == o) { return; }
        if (null != m_goParentGuide)
        {
            o.transform.parent = m_goParentGuide.transform;
        }
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        o.transform.localScale = Vector3.one;


        uint index;
        index = (uint)args[0];
        o.transform.name = "Guide" + index.ToString();
    }

    private void EnableMonsterParentGuide()
    {
        if (m_bemusedTimer.IsExpired(true))
        {
            if (m_goParentGuide != null)
            {
                bool bShowGuide = true;
                foreach (KeyValuePair<Monster, CObject> kv in m_dgMosterGuideDict)
                {
                    if (kv.Key.JudgeGuide() == false)
                    {
                        bShowGuide = false;
                        break;
                    }
                }

                if (m_bSetFootEffect && m_nWaypointIndex != -1 && null != m_directPoint) //�����ͨ��setfooteffect ����Ϊtrue���ܿ���
                {
                    m_directPoint.SetActive(bShowGuide);
                }

                if (m_goParentGuide.activeSelf == bShowGuide)
                    return;
                m_goParentGuide.SetActive(bShowGuide);

            }
        }
   }

    private void EnableMonsterGuide()
    {
        if (m_goParentGuide != null)
        {
             
            if (m_goParentGuide.activeSelf == true)
            {
                foreach (KeyValuePair<Monster, CObject> kv in m_dgMosterGuideDict)
                {
                    UpdateMosterGuide(kv.Key);
                }
            }
        }
    }




    private void SetFollowCamera(GameObject o, eCAMERAFOLLOW followType = eCAMERAFOLLOW.SMOOTH, bool effectTimeScale = true)
    {
        //SceneContent sceneLoader = m_pBattleScene.GetSceneLoader();
        //if (sceneLoader != null)
        //{
        //    CCamera.GetInst().SetCameraEffect(sceneLoader.GetCameraID(), null, new object[] { o });
        //}

        if ( (m_pBattleScene.BattleType == eBattleType.Pvp 
            /*||              m_pBattleScene.BattleType == eBattleType.MultiPve*/) 
              && m_useOtherCameraID)
        {
            CCamera.GetInst().SetCameraEffect(DEFINE.OTHER_CAMERA_ID, null, null, new object[] { o, followType, effectTimeScale });
            return;
        }

        SceneInfoContent info = m_pBattleScene.SceneLoaderInfo;
        if (info != null)
        {
            CCamera.GetInst().SetCameraEffect((uint)info.CameraID, null, null, new object[] { o, followType, effectTimeScale });
        }
        else
        {
            MyLog.LogError("The game has not cameraID");
        }
    }

    protected override void LoadAI()
    {
        base.LoadAI();

        if (!ClientMain.GetInst().EnterTestScene)
        {
            //key: skillID, value: skillUpID
            Dictionary<int, CSkillupInfo> skillupdict = new Dictionary<int, CSkillupInfo>();

            //��UI�Ǳ߶�ȡ����
            List<stSkillInfo> stskills = SingletonObject<SkillManager>.GetInst().GetAllSkill();
            foreach (stSkillInfo stskill in stskills)
            {
                //if (stskill.isCarry)
                {
                    //uint uiSkillupLoaderKey = stskill.uiSkillID + stskill.uiLvl;           
                    SkillUpContent csul = HolderManager.m_SkillUpHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csul != null)
                    {
                        //uint skillUpID = uiSkillupLoaderKey;
                        MyLog.Log(this + " LoadAI skillID : " + csul.SkillId);
                        CSkillupInfo info = new CSkillupInfo(stskill.uiLvl, csul);
                        int uiSkillID = csul.SkillId;
                        if (!skillupdict.ContainsKey(uiSkillID))
                        {
                            skillupdict.Add(uiSkillID, info);
                        }
                        else
                        {
                            MyLog.LogError("avatar skill has the same key :" + uiSkillID);
                        }
                    }
                }
            }
            skillupdict.Add(m_pPlayerLoader.NormalSkill, null);

            if (m_pAI != null)
            {
                CBattleSceneLoading bsl = SingletonObject<CBattleSceneLoading>.GetInst();
                if (bsl != null && bsl.battleType == eBattleType.Arena)
                {
                    m_pAI.SetAI(DEFINE.ARENA_BATTLE_AI_ID, null, skillupdict);//ʹ�þ�����AI
                }
                //2015��7��17��17:30:18������,����ʹ��PVE��AI,������������AI
                //else if (bsl != null && bsl.battleType == eBattleType.ClimbTower)
                //{
                //    m_pAI.SetAI(DEFINE.CLIMBTOWER_AI_ID, null, skillupdict);//ʹ������AI:
                //}
                else
                {
                    m_pAI.SetAI(DEFINE.AVATAR_BASE_AI_ID, null, skillupdict);//ʹ�û���AI
                }
            }
        }
        else
        {
            Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();

            foreach (int sid in ClientMain.GetInst().TestSkillID)
            {
                if (!skillDict.ContainsKey(sid))
                {
                    skillDict.Add(sid, null);
                }
            }
            skillDict.Add(m_pPlayerLoader.NormalSkill, null);

            if (m_pAI != null)
            {
                m_pAI.SetAI(DEFINE.AVATAR_BASE_AI_ID, null, skillDict);
            }

        }

        UpdateSkillPanel();
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if (null == o)
        {
            if (null != args && args.Length > 0 && args[0] is bool && (bool)args[0])
            {
                return;
            }
            m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);

            PlayerConfigContent playerConfig = HolderManager.m_PlayerConfigHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            if (null == playerConfig)
                return;

            ClothesID = (uint)playerConfig.Clothes;

    
            CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation, true);
            return;
        }

        bool replace = (bool)m_pNpcObj.Args[0];
        if (replace)
        {
            Common.MaterialCulling(o);
        }

        base.LoadNpcCompleted(o, args);

        CMusicManager.GetInst().FollowObj = o;
        //
        o.tag = DEFINE.AVATAR_OBJECT_TAG;
        m_pPlatformReceiver = AddPlatformReceiveMessage(o);
        int layers = CMechanismManage.GetInst().NavMeshLayers;
        CMechanismManage.GetInst().OpenOrCloseNavMeshLayersMask(o, layers, false);

        if (null == m_pGesture)
        {
            //���Ƽ���
            Camera mainCamera = CCamera.GetInst().GetCamera();
            m_pGesture = new AvatarGestureCtrl(this, mainCamera);
        }



        //����.
        //CParticleManager.GetInst().CreateBindEffect(DEFINE.AVATAR_WEAPON_PARTICLEID, o);
        //CParticleManager.GetInst().CreateBindEffect(DEFINE.AVATAR_STICK_PARTICLEID, o);

        if (m_pBattleScene.BattleType == eBattleType.Arena)
        {
            //�������ӳ�0.5�� ��Ϊ�˾�ͷ����ס
            UnityCallBackManager.GetInst().AddCallBack(0.5f, delegate(object[] args_)
            {
                SetFollowCamera(m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.DIRECT);
            });
        }
        else
        {
            SetFollowCamera(o, eCAMERAFOLLOW.DIRECT);
        }
        GetDirectPoint();

        m_uiPvpParticleIndex = AddPvpStepParticle();

        //��ը��
        //Collider[] colliders = o.GetComponentsInChildren<Collider>();
        //int count = colliders.Length;
        //Transform myTrans = o.transform;
        //for (int i = 0; i < count; i++)
        //{
        //    if (colliders[i].name == myTrans.name)
        //        continue;
        //    if (colliders[i].isTrigger)
        //    {
        //        continue;
        //    }
        //    colliders[i].gameObject.layer = DEFINE.EXPLODER_LAYER;
        //}

        //m_smr = m_myTrans.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        m_mrs = m_myTrans.GetComponentsInChildren<MeshRenderer>(true);
        //if (m_smr != null && m_smr.Length > 0)
        //{
        //    Materials = m_smr[0].materials;
        //    ChangeShaderToXRayAndBackLightVertex(true);
        //    m_currShaderName = m_material0Name;
        //}

        //if (m_materiaslCount > 0)
        //{
        //    m_currShaderName = m_material0Name;
        //}

        if (m_goParentGuide == null)
        {
            m_goParentGuide = new GameObject("Guide");
            m_goParentGuide.transform.parent = o.transform;
            m_goParentGuide.transform.localPosition = Vector3.zero;
            m_goParentGuide.transform.localRotation = Quaternion.identity;
            m_goParentGuide.transform.localScale = Vector3.one;
        }

    
        RainOrSnow.GetInst().StartRain(m_myTrans, CCamera.GetInst().GetCameraObj().transform);

        for (int i = 0, len = m_PartnerList.Count; i < len; i++)
        {
            m_PartnerList[i].CreateObj(o.transform.position, o.transform.rotation);
        }


    }


    protected override void BuildAnimator(Animator animator)
    {
        base.BuildAnimator(animator);

        CNormalState normalState = GetCurrState() as CNormalState;
        if (null != normalState)
        {
            ApplyRootMotion = true; //���������µ�
        }

    }

    public void AddCombo()
    {
        m_wComboNum++;
        m_ComboTimer.SetTimer(DEFINE.AVATAR_COMBO_TIME);
        SingletonObject<FlywordMediator>.GetInst().CreateComboWord(m_wComboNum);
    }


    public void ClearCombo()
    {
        m_wComboNum = 0;
        SingletonObject<FlywordMediator>.GetInst().OnComboBreakFinish();
    }

    public override void AddHp(int nHp, bool critical = false, CBaseNpc attacker = null, bool sendMsg = false)
    {
        base.AddHp(nHp, critical, attacker, sendMsg);
        TriggerManager.GetInst().AvatarHPLessThen((m_nHp * 10000) / m_pCard.nMaxHp);

    }

    public void CheckHpWarning()
    {
        if (m_pBattleScene == null || m_pBattleScene.BattleType == eBattleType.Arena)
        {
            return;
        }
        BattleHpWarning hpWarning = SingletonObject<BattleHpWarning>.GetInst();

        if (!hpWarning.IsOpen && !(AvatarDead || PartnerDead))
        {
            if (m_nHp > 0 && m_nHp < m_pCard.nMaxHp * 0.2f)
            {
                hpWarning.Open(null);
            }
        }
        else
        {
            if (m_nHp >= m_pCard.nMaxHp * 0.2f || m_nHp <= 0)
            {
                hpWarning.Close();
            }
        }
    }

    public override void RrefeshHPComponent()
    {
        base.RrefeshHPComponent();

        CheckHpWarning();
        if (CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            SingletonObject<LeagueBattleInfoMediator>.GetInst().SetHpValue(m_nHp, m_pCard.nMaxHp);
        }
        else if (CurrBattleScene.BattleType == eBattleType.Arena)
        {
            SingletonObject<ArenaResultMediator>.GetInst().SetHpValue(m_nHp, m_pCard.nMaxHp);
        }
        else
        {
            SingletonObject<RoleMediator>.GetInst().SetHPValue(m_nHp, m_pCard.nMaxHp);
        }         
    }

    public override void BeHit(uint uiDefenceActionID, CBaseNpc pAttacker, SkillContent pSkillLoader, bool beHitMute = false)
    {
        base.BeHit(uiDefenceActionID, pAttacker, pSkillLoader, beHitMute);

        TriggerManager.GetInst().AvatarBehit();
    }

    /// <summary>
    /// ����ƶ�
    /// </summary>
    /// <param name="hitPosition"></param>
    /// <param name="sendMsg">�Ƿ���Ҫ����Ϣ�������</param>
    public void OnClick(Vector3 hitPosition, bool sendMsg = false)
    {
        CBaseState pCurrState = m_stateMgr.GetCurrState();
        if (pCurrState == null) return;
        eActionState actionState = pCurrState.GetState();

        if (m_bDClickLocking)
        {
            return;
        }

        if (actionState != eActionState.Skill)
        {
            //if (CanMove)
            if (CanUseNormalAttackManully())
            {
                bool bDirectionTurn = false;
                //���ָ����Դ����Ϣ,�Ͳ�ʹ��Ѱ·,�������
                bool bUsePathFinding = sendMsg ? false : true;
                Vector3 destPosition = bUsePathFinding ? Common.NavSamplePosition(hitPosition) : hitPosition;
                Vector3 addpos = (destPosition - m_myTrans.position).normalized * 4f;
                destPosition += addpos;

                CBaseNpc pEnemy = m_pBattleScene.GetNearestNpc(this, eCheckNpcType.Emeny, DEFINE.DEFAULT_IMMEDIATE_TURN_DISTANCE, 360, false, true);
                if (pEnemy != null && !IsInRide() && !IsInFly())
                {
                    bDirectionTurn = true;
                }

                if (IsInRide())
                {
                    destPosition = Common.GetRayPosition(m_myTrans.position, destPosition, 1000);
                    bUsePathFinding = false;
                }
                //Debug.Log(" OnClick .. NotInAction() " + NotInAction());
                //����Ѿ����궯��                
                if (NotInAction())
                {
                    CheckRotateOrRun(destPosition, bDirectionTurn, bUsePathFinding, sendMsg);
                }
                else
                {
                    NextPosition = hitPosition;
                }
                Avatar avatar = this as Avatar;
                if (null != avatar)
                {
                    avatar.InMouseControl = true;
                }

            }
        }
    }

    private void OnDoubleClick(Vector3 hitPosition, bool sendMsg = false)
    {
        eActionState state = m_stateMgr.GetCurrActState();

        if (state == eActionState.Skill)
        {
            CSkillState skillState = GetCurrState() as CSkillState;
            if (!skillState.GetSkillInfo().CanBlink)
            {
                return;
            }
        }
        //else if (!CanMove)        
        else if (!CanUseSkillManully())
        {
            return;
        }

        //         CanTurn = true;
        //         UpdateTurn(hitPosition - m_myTrans.position, true);
        //         EnterState(eActionState.Roll);
        /*Debug.Log(" OnDoubleClick ...");*/
        //DoDoubleClick(hitPosition - m_myTrans.position, sendMsg);

        m_bDClickLocking = true;
        //if (CanMove && state != eActionState.Skill)
        //{
        //    UpdateTurn(hitPosition - m_myTrans.position, true);
        //    EnterState(eActionState.Roll);  
        //}

        Vector3 turnDirection = hitPosition - m_myTrans.position;
        SkillContent rollSkillLoader;
        //С��鷭�������ǲ�һ�������Է�����Ҫ�ж��Ƿ���С���
        bool isPartner = PartnerState == ePartnerState.Partner;
        if (isPartner)
        {
            if (ActivePartner == null) return;

            PartnerModelContent partnerModelLoader = ActivePartner.PartnerLoader.ModelLoader;
            if (null == partnerModelLoader) return;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(partnerModelLoader.RollSkill);

        }
        else
        {
            PlayerConfigContent configLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pPlayerLoader.Key);
            if (null == configLoader) return;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(configLoader.RollID);
        }
        GetCurrState().BreakState();
        //CanTurn = true;
        //UpdateTurn(turnDirection, true);

        if (m_eAvatarType == eAvatarType.RealAvatar)
        {
            TriggerUseSkillHandler((uint)rollSkillLoader.Key, turnDirection, (int)eSyncAttack.Player);
        }
        else
        {
            CanTurn = true;
            UpdateTurn(hitPosition - m_myTrans.position, true);
            DoUseSkillEvent(new UseSkillCommandArg((uint)rollSkillLoader.Key, new List<CBaseNpc>()));
        }

        SoundBreak();


        //UseSkillManully((uint)rollSkillLoader.Key, turnDirection);

        UnityCallBackManager.GetInst().AddCallBack(rollSkillLoader.LastTime, delegate(object[] args_)
        {
            m_bDClickLocking = false;
        });

        CurrTarget = null;
        NextPosition = Vector3.zero;
        BreakNormalSkill(DefaultSkillID);
    }

    public override void OnHoldClick(Vector3 hitPosition, bool sendMsg = false)
    {
        if (!sendMsg)
        {
            base.OnHoldClick(hitPosition);
        }
        else
        {
            CBaseState pCurrState = m_stateMgr.GetCurrState();
            if (null == pCurrState) return;

            if ((pCurrState is CSkillState || pCurrState is CChargeState) && (CanMove || CanTurn))
            {
                TriggerMoveHandler(hitPosition, eSyncMove.HoldClick);
            }
        }
    }

    public void HandelClick(eMouseClick state)
    {
        if (m_OffHandelClick)
            return;

        //����������ס�û���Ϊ
        //if (NewBieGuidManager.GetInst().bGuidLockBehaviour)
        //    return;

        if (ClientMain.GetInst().GetCurrentState() != eGameState.Battle)
        {
            return;
        }

        //if (m_pBattleScene.IsGameOver())
        //{
        //    return;
        //}

        CBaseState pCurrState = m_stateMgr.GetCurrState();
        if (pCurrState == null) return;

        eActionState actionState = pCurrState.GetState();

        RaycastHit hit;
        Camera camera = CCamera.GetInst().GetCamera();

        Ray ray = camera.ScreenPointToRay(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));

        Vector3 hitPosition = Vector3.zero;
        if (Physics.Raycast(ray, out hit, 1000, 1 << DEFINE.TERRAINLAYER))
        {
            hitPosition = hit.point;
        }
        else
        {
            Vector3 screenPoint = camera.WorldToScreenPoint(m_myTrans.position);
            hitPosition = camera.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenPoint.z));
        }

        bool sendMsg = CurrBattleScene.BattleType == eBattleType.Pvp  || CurrBattleScene.BattleType ==  eBattleType.MultiPve;

        switch (state)
        {
            case eMouseClick.Onclick:
                {
                    OnClick(hitPosition, sendMsg);
                }
                break;
            case eMouseClick.OnDoubleClick:
                {
                    OnDoubleClick(hitPosition, sendMsg);
                }
                break;
            case eMouseClick.OnHoldClick:
                {
                    OnHoldClick(hitPosition, sendMsg);
                }
                break;
        }

    }

    public bool CallPartner(bool immediate)
    {
        if (m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar) && PartnerDead)
        {
            //С�����˾Ͳ������ٻ�С�����
            return false;
        }

        if (!CanUseSkillManully())
        {
            return false;
        }

        if (m_rideState != eRideState.None)
        {
            return false;//���״̬������
        }

        if (m_flyState != eFlyState.None)
        {
            return false;
        }

        if (m_bInPlatform)
        {
            return false;
        }

        if (immediate)
        {
            m_partnerFSM.TriggerEventQueued(ePartnerEvent.SwitchImmediately);
        }
        else if (m_switchCDTimer.IsExpired(false))
        {
            if (m_eAvatarType == eAvatarType.RealAvatar)
            {
                TriggerMoveHandler(Vector3.zero, eSyncMove.CallPartner);
                return false;
            }

            DoCallPartner();
        }
        else
        {
            return false;//CDû�����ó�ս
        }

        return true;
    }

    public bool DoBeginRideCommand()
    {
        if (m_eAvatarType == eAvatarType.RealAvatar && CanRiding)
        {
            TriggerMoveHandler(Vector3.zero, eSyncMove.BeginRide);
            return false;
        }

        return BeginRide();
    }


    public bool DoBeginFlyCommand()
    {
        if (m_eAvatarType == eAvatarType.RealAvatar && CanFly)
        {
            TriggerMoveHandler(Vector3.zero, eSyncMove.BeiginFly);
            return false;
        }

        return BeginFly();
    }

    /// <summary>
    /// �ֶ�ʹ�ü��ܽӿ�
    /// </summary>
    /// <param name="uiSkillType"></param>
    /// <param name="turnDirection">ת���ĳ���</param>
    /// <param name="bNewbieUse">�Ƿ�Ϊ��������ʹ��</param>
    /// <returns></returns>
    public virtual bool UseSkillManully(uint uiSkillType, Vector3 turnDirection, bool bNewbieUse = false)
    {
        if (!CanUseSkillManully() && !bNewbieUse)
        {
#if UNITY_EDITOR
            MyLog.LogWarning(" UseSkill WARNING !! CAN NOT use this skill :" + uiSkillType + " now !");
#endif
            return false;
        }

        UseSkillCommandArg args = new UseSkillCommandArg(uiSkillType, m_targetList);

        if (m_eAvatarType == eAvatarType.RealAvatar && CanUseSkill(args))
        {
            //TriggerLocationHandler();            
            TriggerUseSkillHandler(uiSkillType, turnDirection, (int)eSyncAttack.Player);
            return false;
        }

        if (turnDirection != Vector3.zero)
        {
            UpdateTurn(turnDirection, true);
        }

        return this.Command(eCommandType.UseSkill, args) == eCommandReply.YesSir;
    }


    public void DeleteMonsterGuide(Monster monster)
    {
        if (!m_dgMosterGuideDict.ContainsKey(monster))
            return;
        m_dgMosterGuideDict[monster].DestroyGameObject(eObjectDestroyType.Memory);
        m_dgMosterGuideDict.Remove(monster);
    }

    public override void NpcDead(bool bNaturalDeath, CBaseNpc attack = null,bool fromMsg = false)
    {
        base.NpcDead(bNaturalDeath, attack, fromMsg);

        ArenaManager pArena = ArenaManager.GetInst();
        if (pArena != null && CurrBattleScene.BattleType == eBattleType.Arena && (AvatarDead || PartnerDead) && pArena.challengeRst == 1)
        {
            if (!LockHP)
            {
                LockHP = true;
                LockHPValue = (int)(GetMaxHp() * 0.1f);
            }
        }

        if (IsDead())
        {
            TriggerManager.GetInst().AvatarDead();
            SingletonObject<BattleHpWarning>.GetInst().Close();

            if (CurrBattleScene.BattleType == eBattleType.MultiPve)
            {                
                PvpChangeData data = new PvpChangeData();
                data.uiDataType = (byte)ePvpDataType.AvatarHp;
                MultiPveMsg.ReqDataChange(new Protocol.PvpChangeDataList() { data});
            }

            //if (m_pBattleScene.SceneLogic != null)
            //{
            //    if (m_pBattleScene.SceneLogic is ArenaSceneLogic)
            //    {
            //        ArenaManager.GetInst().OnC2GReportChallenge(ArenaManager.GetInst().arenaAvatarInfo.m_llAccountID, ArenaManager.GetInst().arenaAvatarInfo.uiPlayerID, SingletonObject<ArenaPartnerMediator>.GetInst().pArenaBasicInfo.uiNum, 0);
            //    }
            //    else
            //    {
            //        TriggerManager.GetInst().AvatarDead();
            //        SingletonObject<SingleBattleMediator>.GetInst().DisplayResurgence(true);
            //        BattleResultMediator res = SingletonObject<BattleResultMediator>.GetInst();
            //        res.SetBattleResult(false);
            //        res.Open();
            //    }
            //}
        }

    }

    protected override void InitCharacterCard(ushort wLevel)
    {
        base.InitCharacterCard(wLevel);

        SingletonObject<RoleMediator>.GetInst().SetHPValue(m_nHp, m_pCard.nMaxHp);


        if (m_bGMInvincible)
        {
            InvincibleGMCommand();
        }

        TestSceneCharacter();
    }

    public void TestSceneCharacter()
    {
        if (ClientMain.GetInst().EnterTestScene)
        {
            ushort wLevel = ClientMain.GetInst().PlayerLevel;

            m_nHp = InitAttr(m_pPlayerLoader.Hp, wLevel);
            m_pOriginCard.nMaxHp = m_nHp;
            //m_pOriginCard.nThew = InitAttr(m_pNpcInfo.GetThew(), byLevel);
            m_pOriginCard.nAttack = InitAttr(m_pPlayerLoader.Attack, wLevel);
            m_pOriginCard.nDefence = InitAttr(m_pPlayerLoader.Defence, wLevel);
            m_pOriginCard.nHitRate = InitAttr(m_pPlayerLoader.HitRate, wLevel);
            m_pOriginCard.nDodge = InitAttr(m_pPlayerLoader.Dodge, wLevel);
            m_pOriginCard.nBingo = InitAttr(m_pPlayerLoader.Bingo, wLevel);
            m_pOriginCard.fDamageRatio = 1f;

            //m_pOriginCard.nDarkResis = m_pNpcInfo.GetDarkResis();
            //m_pOriginCard.nLightningResis = m_pNpcInfo.GetLightingResis();
            //m_pOriginCard.nFireResis = m_pNpcInfo.GetFireResis();
            //m_pOriginCard.nColdResis = m_pNpcInfo.GetColdResis();
            //m_pOriginCard.nSunResis = m_pNpcInfo.GetSunResis();
            m_pOriginCard.fMoveSpeed = m_pPlayerLoader.m_moveSpeed;
            //m_pOriginCard.fWalkSpeed = m_pNpcInfo.GetMoveSpeed() / 1.5f;
            m_pOriginCard.fWalkSpeed = 3f;

            m_pCard = m_pOriginCard;

            PartnerList[0].Card = m_pCard;

            //Dictionary<uint, uint> skillDict = new Dictionary<uint, uint>();
        }
    }

    public void OnTestSkill(params object[] args)
    {
        uint skillID = (uint)args[0];
        UseSkillManully(skillID, Vector3.zero);
    }


    //����
    public override void Resurrect(bool direct = false)
    {
        m_avatarLifePercent = 1.0f;

        base.Resurrect(direct);

        ApplyCharacterCtrl = true;

        RemoveFadeCallback();

        SetAlphaVertexColorOn(0);

        CurrBattleScene.SetBootyShow = false;

        SetFollowCamera(m_myTrans.gameObject, eCAMERAFOLLOW.DIRECT);
    }


    public void GetDirectPoint()
    {
        LoadHelp.LoadObject("", "resources/effect/other/jiantou.x", ThreadPriority.Normal, LoadDirectComplete);
    }

    void LoadDirectComplete(string interim, UnityEngine.Object org)
    {
        if (null == org) { MyLog.LogError("" + interim); return; }
        m_directPoint = UnityEngine.Object.Instantiate(org) as GameObject;
        UnityEngine.Object.DontDestroyOnLoad(m_directPoint);
        m_directPoint.transform.parent = this.GetTransform();
        m_directPoint.transform.localPosition = new Vector3(0f, 0f, 1f);
        m_directPoint.transform.localRotation = Quaternion.Euler(Vector3.zero);

        DynamicShader.ReplaceUnSupportShader(m_directPoint);

        SetFootEffect(true);
    }
    public override void SetFootEffect(bool state)
    {
        base.SetFootEffect(state);

        if (m_directPoint)
        {
            if (state && m_nWaypointIndex != -1 && !CurrBattleScene.IsGameOver())
            {

                m_directPoint.SetActive(true);
                m_bSetFootEffect = true;
            }
            else
            {

                m_directPoint.SetActive(false);
                m_bSetFootEffect = false;
            }
        }
    }

    public void SetFootEffectForGameStory(bool state)
    {
        if (m_directPoint)
        {
            if (state && m_nWaypointIndex != -1 && !CurrBattleScene.IsGameOver())
            {

                m_directPoint.SetActive(true);
                m_bSetFootEffect = true;
            }
            else
            {

                m_directPoint.SetActive(false);
                m_bSetFootEffect = false;
            }
        }
    }

    //���¼�����ʾ���
    public void UpdatePanel(List<CInitiativeSkill> skillList, bool IsAvator)
    {
        SingletonObject<SkillBarMediator>.GetInst().BindSkill(skillList, IsAvator);
    }



    public void UpdateSkillPanel()
    {
        UpdatePanel(m_skillList, (bool)(PartnerState == ePartnerState.Avatar && m_rideState == eRideState.None));
    }

    public override void Release(eObjectDestroyType type)
    {
        m_partnerFSM.EnterStateEvent -= onPartnerEntry;
        m_partnerFSM.LeaveStateEvent -= onPartnerExit;

        if (this.Trusteeship)
        {
            this.Trusteeship = false;
        }

        EnterState(eActionState.Idle);
        UpdateDestPosition();
        CurrTarget = null;

        m_pGesture = null;
        if (m_goParentGuide != null)
            GameObject.Destroy(m_goParentGuide);

        m_goParentGuide = null;

        m_dgMosterGuideDict.Clear();
        InMouseControl = false;



        ClearCombo();

        base.Release(type);

    }


    public void onPartnerEntry(System.Enum stateToEnter)
    {
        if (stateToEnter.Equals(ePartnerState.Avatar))
        {
            UpdatePanel(m_skillList, true);
        }
        else if (stateToEnter.Equals(ePartnerState.Partner))
        {
            UpdatePanel(m_skillList, false);
            InMouseControl = false;
        }
        else if (stateToEnter.Equals(ePartnerState.SwitchingToPartner))
        {
            //���ܲ���
            m_OffHandelClick = true;

            //����ͷ����ԭ��
            CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
            EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();

            //             if (pcbsl.battleType == eBattleType.Arena && penemyavatar.IsInFly())
            //             {
            //                 CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.DIRECT, true, false });
            //             }
            //             else
            {
                SetFollowCamera(m_tempCameraAncher, eCAMERAFOLLOW.DIRECT);
            }

            //��ͷ����������Զ
            if (pcbsl.battleType != eBattleType.Arena)
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.PARTNER_CAMERA_ZOOM_IN, null, null);
                CCamera.GetInst().SetCameraEffect(DEFINE.PARTNER_CAMERA_ZOOM_OUT, null, null);
            }

        }
        else if (stateToEnter.Equals(ePartnerState.SwitchingToAvatar))
        {
            //���ܲ���
            m_OffHandelClick = true;

            //����ͷ����ԭ��
            CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
            EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();

            //             if (pcbsl.battleType == eBattleType.Arena && penemyavatar.IsInFly())
            //             {
            //                 CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.DIRECT, true, false });
            //             }
            //             else
            {
                SetFollowCamera(m_tempCameraAncher, eCAMERAFOLLOW.DIRECT);
            }

            //��ͷ����������Զ
            if (pcbsl.battleType != eBattleType.Arena)
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.PARTNER_CAMERA_ZOOM_IN, null, null);
                CCamera.GetInst().SetCameraEffect(DEFINE.PARTNER_CAMERA_ZOOM_OUT, null, null);
            }
        }
    }

    public void onPartnerExit(System.Enum stateToLeave)
    {
        if (stateToLeave.Equals(ePartnerState.Avatar))
        {
            UpdatePanel(m_skillList, true);
        }
        else if (stateToLeave.Equals(ePartnerState.Partner))
        {
            UpdatePanel(m_skillList, false);
        }
        else if (stateToLeave.Equals(ePartnerState.SwitchingToPartner))
        {
            //�ָ�����
            m_OffHandelClick = false;

            //����ͷת��С���
            CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
            EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();

            if (pcbsl.battleType == eBattleType.Arena)
            {
                SetFollowCamera(CurrBattleScene.TempCameraAncher, eCAMERAFOLLOW.SMOOTH);
            }
            else
            {
                SetFollowCamera(ActivePartner.Go, eCAMERAFOLLOW.SMOOTH);
            }
            //             if (pcbsl.battleType == eBattleType.Arena && penemyavatar.IsInFly())
            //             {
            //                 CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.DIRECT, true, false });
            //             }
            //             else
            //             {
            //                 //SetFollowCamera(m_partnerObj.gameCObject, eCAMERAFOLLOW.DIRECT);
            //                 SetFollowCamera(ActivePartner.Go, eCAMERAFOLLOW.DIRECT);
            //             }

        }
        else if (stateToLeave.Equals(ePartnerState.SwitchingToAvatar))
        {
            //�ָ�����
            m_OffHandelClick = false;

            //����ͷת������
            CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
            EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();

            if (pcbsl.battleType == eBattleType.Arena)
            {
                SetFollowCamera(CurrBattleScene.TempCameraAncher, eCAMERAFOLLOW.SMOOTH);
            }
            else
            {
                SetFollowCamera(m_avatarObj.gameCObject, eCAMERAFOLLOW.SMOOTH);
            }

            //             if (pcbsl.battleType == eBattleType.Arena && penemyavatar.IsInFly())
            //             {
            //                 CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.DIRECT, true ,false});
            //             }
            //             else
            //             {
            //                 SetFollowCamera(m_avatarObj.gameCObject, eCAMERAFOLLOW.DIRECT);
            //             }

        }
    }

    #region PVP


 
    public void TriggerMoveHandler(Vector3 destPosition, eSyncMove moveType)
    {
        if (null != MoveHandler)
        {
            MoveHandler(destPosition, moveType);
        }
    }

    public void TriggerLocationHandler()
    {
        if (null != LocationHandler)
        {
            LocationHandler();
        }
    }

    
    public void TriggerUseSkillHandler(uint uiSkillID, Vector3 turnDirection, /*eSyncAttack type*/uint index)
    {
        if (null != UseSkillHandler)
        {
            UseSkillHandler(uiSkillID, turnDirection, index);
        }
    }

 
    public void TriggerDataChange(PvpChangeDataList list)
    {

        if (null != DataChangeHandler)
        {
            DataChangeHandler(list);
        }
    }


    //     public override bool HitResult(SkillContent pSkillInfo, CBaseNpc pTarget, bool beHitMute = false)
    //     {
    //         bool result = base.HitResult(pSkillInfo, pTarget, beHitMute);
    //
    //         if (BattleScene.BattleType == eBattleType.Pvp && result)
    //         {
    //             m_pPvpLogic.HitResult(pTarget);
    //         }
    //
    //         return result;
    //     }

    private void ReqPvpMove(Vector3 destPos, eSyncMove syncType)
    {
        if (MsgLock == eMsgLockType.Lock)
        {
            return;
        }

        //MsgLock = eMsgLockType.Lock;

        m_pPvpLogic.ReqPvpMove(destPos, syncType);
    }

    private void ReqPvpLocation()
    {
        m_pPvpLogic.ReqPvpLocation();
    }


    private void ReqPvpDoAttack(uint uiSkillID, Vector3 turnDirection, uint index)
    {
        if (MsgLock == eMsgLockType.Lock)
        {
            return;
        }

        //MsgLock = eMsgLockType.Lock;

        m_pPvpLogic.ReqPvpDoAttack(uiSkillID, turnDirection, index);
    }

    private void ReqSelfDataChange(List<PvpChangeData> dataList)
    {
        m_pPvpLogic.ReqSelfDataChange(dataList);
    }

    public void RecvAttack(object msg)
    {
        //m_pPvpLogic.RecvPvpAttack(msg);

        m_pPvpLogic.MsgLock = eMsgLockType.Unlock;

        DoCommand(msg, eRPCmdType.Attack);
    }

    public void RecvMove(object msg)
    {
        m_pPvpLogic.MsgLock = eMsgLockType.Unlock;

        DoCommand(msg, eRPCmdType.Move);
    }

    public void RecvPvpLocation(N2CPvpLocationChange locationMsg)
    {
        m_pPvpLogic.RecvPvpLocation(locationMsg);
    }

    public override void CheckRotateOrRun(Vector3 destPosition, bool bDirectionTurn, bool bUsePathFinding, bool sendMsg = false)
    {
        if (!sendMsg)
        {
            base.CheckRotateOrRun(destPosition, bDirectionTurn, bUsePathFinding, sendMsg);
        }
        else
        {
            eSyncMove moveType = eSyncMove.Max;

            bool turning = IsDirectionHasEnemyInRange(destPosition);
            if (turning)
            {
                moveType = eSyncMove.TurningOnly;
            }
            else
            {
                moveType = bDirectionTurn ? eSyncMove.TurningImmediateToRun : eSyncMove.TurningSlowlyToRun;
            }
            TriggerMoveHandler(destPosition, moveType);
        }
    }

    public override void EnterPlatform(GameObject platformObj)
    {
        base.EnterPlatform(platformObj);

        //�ӳٹرմ��ڣ�NGUI������������ʱ��trigger,��ײ���رջᱨ��        
        UIManager.GetInst().IsLockNGUIEvent(true);
        UnityCallBackManager.GetInst().AddCallBack(0.1f, DelayCloseAllWindow, null);


        if (m_pBattleScene.BattleType == eBattleType.MultiPve)
        {
            //avatar����ƽ̨,������avatarǿ��������
            OnlineAvatar oa = MultiPveManager.GetInst().GetEnemyPlayer();
            if ( null != oa)
            {
                //Debug.LogError(this + "  EnterPlatform : ");
                //Vector3 destPos = m_pBattleScene.SummonPosition(this.GetPosition(), oa.CharacterRadius, false, this, this.NpcCollider);
                oa.SetPosition(this.m_myTrans.position);
                oa.SetEnterPlatform(platformObj);
            }            
        }
    }

    private void DelayCloseAllWindow(params object[] args)
    {
        UIManager.GetInst().CloseAllWnd();

    }

    public override void LeavePlatform(GameObject platformObj)
    {
        base.LeavePlatform(platformObj);

        UIManager.GetInst().OpenCurrentWnd();
        UIManager.GetInst().IsLockNGUIEvent(false);

    }

    public override eNpcBehaviour CheckNpcBehaviour()
    {
        if (CurrBattleScene.BattleType == eBattleType.Pvp)
        {
            if (PvpMsgMgr.LockStep)
            {
                return eNpcBehaviour.LockBehaviour;
            }
        }
        else if (CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            if (MultiPveMsg.LockStep)
            {
                return eNpcBehaviour.LockBehaviour;
            }
        }        
             
        return base.CheckNpcBehaviour();

    }


    #endregion

}
