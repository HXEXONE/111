﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Position3D = UnityEngine.Vector3;
using Direction3D = UnityEngine.Vector3;

//处理人刚挂在宠物上先下降再攀升的状态
public enum eFlyFightHeightState
{
    Drop,//猛的下坠
    Climb,//爬升
    Stably,//稳定
    Fall,//降落
}

public class Pet : CBaseNpc
{
    public uint NpcType
    {
        get
        {
            return m_uiNpcType;
        }
        set
        {
            m_uiNpcType = value;
        }
    }

    public bool IsValid
    {
        get
        {
            //bool ret = m_pPetLoader != null && m_ob
            return m_pPetLoader != null;
        }
    }

    private PetContent m_pPetLoader = null;//数据表加载器

    private uint m_uiNpcType = DEFINE.PET_NPCTYPE_ID;//默认宠物
    private List<PetSkillContent>[] m_petSkills = {null, new List<PetSkillContent>(), new List<PetSkillContent>(), new List<PetSkillContent>() };//宠物技能列表

    private CharacterController m_characterController;

    //宠物所在的场景
    ePetOccasion m_petOccasion = ePetOccasion.None;
    
    //自己和主人的transform
    BaseBattlePlayer m_masterNpc = null;
    public BaseBattlePlayer MyMaster
    {
        get { return m_masterNpc; }
        set 
        {
            m_masterNpc = value;
            m_npcGroup = m_masterNpc.NpcGroup;


            AddRangeNpc(m_masterNpc);

            if (m_masterNpc != null)
            {
                m_masterNpc.NpcEnterStateEvent += OnMasterEnterState;//监听状态改变事件
            }

        }
    }

    public Transform MasterTrans
    {
        get
        {
            if (m_masterTransform != null)
            {
                return m_masterTransform;
            }
            if( m_masterNpc != null)
                m_masterTransform = m_masterNpc.GetTransform();

            return m_masterTransform;
        }
    }

    Transform m_selfTransform = null;//自己的transform
    Transform m_masterTransform = null;//主人的transform
    
    //移动、捡东西相关
    private CSimpleFSM m_petFSM = new CSimpleFSM();
    private ePetState m_petState;
    private float m_distance;//距离主角的平面距离
    private Vector3 m_targetPosition = Vector3.zero;//目标点坐标
    private Vector3 m_targetFaceDirection = Vector3.zero;//目标方向
    private Vector3 m_originFaceDirection = Vector3.zero;//上一帧朝向
    private Vector3 m_currPosition = Vector3.zero;//当前的平面位置
    private Vector3 m_cradOutVector = Vector3.zero;//圆心到当前位置向量
    private Vector3 m_midPosition = Vector3.zero;//圆心到当前位置连线与圆的交点
    private Vector3 m_mradOutVector = Vector3.zero;//圆心到圆心到当前位置连线与圆的交点的向量
    private Vector3 m_ctangentVector = Vector3.zero;//当前位置的切线
    private Vector3 m_mtangentVector = Vector3.zero; //圆上的切线
    private Vector3 m_tradVector = Vector3.zero;//从圆心到圆外点到圆的切点的半径向量
    private GameObject m_tobj;//目标点
    private GameObject m_nobj;//目标点反向点，或者第二目标点
    private GameObject m_pobj;//当前切线前方点
    private GameObject m_qobj;//圆外点到圆切线的切点
    private float m_maxDistance = 20.0f;//宠物超出这个距离后就会瞬移到主角身边
    private float m_currentHeight = 0.0f;//当前实际的高度
    private float m_height = 3.5f;//盘旋高度
    private float m_wanderRadius = 2.5f;//盘旋半径
    private float m_pickRadius = 15.0f;//自动拾取半径
    private bool m_isIn = false;//是否在盘旋区域内，不在区域内则走切线进区域
    private float m_timeCountDown = 0.0f;//计时器
    private float m_timeToCount = 1.0f;//计时器的设定值
    private CBaseDropObject m_dobj = null;//要捡的东西
    private Position3D m_dobjPickPosition = Position3D.zero;
    private Position3D m_pickgoStartPosition = Position3D.zero;
    private eActionState m_masterEventState = eActionState.None;
    private uint m_skillToCast = 0;

    private float m_flyFightoriginDistance = 0.0f;//合体前人和宠物之间的距离
    private bool m_bFlyFightInit;//是否飞行合体初始化
    private eFlyFightHeightState m_flyFightHeightState;
    private float m_fFlyFightOffset = 0;
    private bool m_bFlyFightTurn;
    //喊话相关
    private float m_chatTimeCountCown = 0.0f;
    private float m_chatTimeToCount = 30.0f;
    private List<string> m_chatWordsInBattleList = new List<string>();
    private List<string> m_chatWordsAtHomeList = new List<string>();
    //
    //private uint m_effectID = 0;
    private Timer m_effectOffTimer = new Timer();

    private Transform m_buffTrans;//宠物的BUFF绑点,在带人飞行时隐藏自己

    private bool m_isRelease = false;

    private void setupFSM()
    {
        switch (m_petOccasion)
        {
            //case ePetOccasion.Home:
            //    m_petFSM.AddEntry(ePetState.Town, townEntry);
            //    m_petFSM.AddUpdate(ePetState.Town,townUpdate);
            //    m_petFSM.Init(ePetState.Town);
            //    break;
            case ePetOccasion.Battle:
                m_petFSM.AddPreUpdate(fsmpreUpdate);
                m_petFSM.AddLateUpdate(fsmlateUpadate);

                m_petFSM.AddEntry(ePetState.Wander, onEntry);
                m_petFSM.AddUpdate(ePetState.Wander, wanderUpdate);
                m_petFSM.AddTransistion(ePetState.Wander, ePetEvent.LEAVE_WANDER_CIRCLE, ePetState.Follow, null);
                m_petFSM.AddTransistion(ePetState.Wander, ePetEvent.FOUND_ITEM, ePetState.PickGo, null);
                m_petFSM.AddTransistion(ePetState.Wander, ePetEvent.USE_SKILL, ePetState.Skill, null);
                m_petFSM.AddTransistion(ePetState.Wander, ePetEvent.LEAVE_EDGE, ePetState.Blink, null);
                m_petFSM.AddTransistion(ePetState.Wander, ePetEvent.BEGIN_FLY_FIGHT, ePetState.BeginFlyFight, null);

                m_petFSM.AddEntry(ePetState.Follow, onEntry);
                m_petFSM.AddUpdate(ePetState.Follow, followUpdate);
                m_petFSM.AddTransistion(ePetState.Follow, ePetEvent.ENTER_WANDER_CIRCLE, ePetState.Wander, null);
                m_petFSM.AddTransistion(ePetState.Follow, ePetEvent.USE_SKILL, ePetState.Skill, null);
                m_petFSM.AddTransistion(ePetState.Follow, ePetEvent.LEAVE_EDGE, ePetState.Blink, null);
                m_petFSM.AddTransistion(ePetState.Follow, ePetEvent.BEGIN_FLY_FIGHT, ePetState.BeginFlyFight, null);

                m_petFSM.AddEntry(ePetState.PickGo, onEntry);
                m_petFSM.AddUpdate(ePetState.PickGo, pickgoUpdate);
                m_petFSM.AddTransistion(ePetState.PickGo, ePetEvent.GOT_ITEM, ePetState.PickBack, null);
                m_petFSM.AddTransistion(ePetState.PickGo, ePetEvent.LOST_ITEM, ePetState.Wander, null);
                m_petFSM.AddTransistion(ePetState.PickGo, ePetEvent.BEGIN_FLY_FIGHT, ePetState.BeginFlyFight, null);

                m_petFSM.AddEntry(ePetState.PickBack, onEntry);
                m_petFSM.AddUpdate(ePetState.PickBack, pickbackUpdate);
                m_petFSM.AddTransistion(ePetState.PickBack, ePetEvent.LOST_ITEM, ePetState.Wander, null);
                m_petFSM.AddTransistion(ePetState.PickBack, ePetEvent.BEGIN_FLY_FIGHT, ePetState.BeginFlyFight, null);

                m_petFSM.AddEntry(ePetState.Skill, skillEntry);
                m_petFSM.AddUpdate(ePetState.Skill, skillUpdate);
                m_petFSM.AddTransistion(ePetState.Skill, ePetEvent.USE_SKILL_DONE, ePetState.Wander, null);
                m_petFSM.AddTransistion(ePetState.Skill, ePetEvent.BEGIN_FLY_FIGHT, ePetState.BeginFlyFight, null);

                m_petFSM.AddEntry(ePetState.Blink, onEntry);
                m_petFSM.AddUpdate(ePetState.Blink, blinkUpdate);
                m_petFSM.AddTransistion(ePetState.Blink, ePetEvent.BLINK_DONE, ePetState.Wander, null);

                m_petFSM.AddEntry(ePetState.BeginFlyFight, beginFlyFightEntry);
                m_petFSM.AddUpdate(ePetState.BeginFlyFight, beginFlyUpdate);
                m_petFSM.AddTransistion(ePetState.BeginFlyFight, ePetEvent.FLY_FIGHT, ePetState.FlyFight, null);
                m_petFSM.AddTransistion(ePetState.BeginFlyFight, ePetEvent.ENTER_WANDER_CIRCLE, ePetState.Wander, null);

                m_petFSM.AddEntry(ePetState.FlyFight, flyFightEntry);
                m_petFSM.AddUpdate(ePetState.FlyFight, flyFightUpdate);
                m_petFSM.AddTransistion(ePetState.FlyFight, ePetEvent.END_FLY_FIGHT, ePetState.EndFlyFight, null);
                m_petFSM.AddTransistion(ePetState.FlyFight, ePetEvent.ENTER_WANDER_CIRCLE, ePetState.Wander, null);

                m_petFSM.AddEntry(ePetState.EndFlyFight, endFlyEntry);
                m_petFSM.AddUpdate(ePetState.EndFlyFight, endFlyUpdate);
                m_petFSM.AddTransistion(ePetState.EndFlyFight, ePetEvent.ENTER_WANDER_CIRCLE, ePetState.Wander, null);

                //m_petFSM.AddEntry(ePetState.BeginCooperate, BeginCooperate);
                //m_petFSM.AddUpdate(ePetState.BeginCooperate, BeginCooperateUpdate);

                m_petFSM.Init(ePetState.Wander);
                break;
            default:
                break;
        }
        
    }

    public void InitPet(BattleScene battlescene, uint index, uint uiPetID, ushort wLevel, Vector3 position, ePetOccasion occasion)
    {
        //宠物所处的环境
        m_petOccasion = occasion;
        m_uiNpcType = uiPetID;
        //重数据加载器
        m_pPetLoader = HolderManager.m_PetHolder.GetStaticInfo(m_uiNpcType);
        //m_pPetLoader = null;

        if (m_pPetLoader != null)
        {

            //初始化运动数据
            m_height = m_pPetLoader.ModelLoader.PetFlyHeight;
            m_wanderRadius = m_pPetLoader.ModelLoader.PetFollowRadius;
            //m_pickRadius = m_pPetLoader.GetPetPickupRadius();

            ////初始化宠物战斗场景喊话数据
            //foreach (uint uTexId in m_pPetLoader.GetPetBattleWords())
            //{
            //    GUITextContent textLoader = HolderManager.m_GUITextHolder.GetStaticInfo(uTexId);
            //    if (textLoader != null)
            //    {
            //        m_chatWordsInBattleList.Add(textLoader.GetSimpleChinese());
            //    }
            //}

            //初始化宠物家园场景喊话数据
            foreach (uint uTexId in m_pPetLoader.ModelLoader.PetHomeWords)
            {
                m_chatWordsAtHomeList.Add(Common.GetText(uTexId));
            }

            //准备宠物技能信息
            foreach (uint petSkillID in m_pPetLoader.ModelLoader.PetSkills)
            {
                //判断是否被动技能
                if (petSkillID > 100000) continue;
                             
                PetSkillContent cpsl = HolderManager.m_PetSkillHolder.GetStaticInfo(petSkillID);
                if (cpsl !=null)
                {
                    int i = (int)cpsl.PetSkillReq;//i对应ePetSkillType三种类型
                    if (i > 0 && m_petSkills[i] != null) 
                    {
                        m_petSkills[i].Add(cpsl);
                        m_skillList.Add(new CInitiativeSkill((uint)cpsl.PetSkillIndex,null, 0));
                    }
                }
            }

            CountAttackRange();//重算攻击距离

            ////初始化一些零时变量
            if (null == m_tobj)
            {
                m_tobj = new GameObject("pet_tobj");//目标点
                //UnityEngine.Object.DontDestroyOnLoad(m_tobj);
            }

            if (null == m_nobj)
            {
                m_nobj = new GameObject("pet_nobj");//目标点反向点，或者第二目标点
                //UnityEngine.Object.DontDestroyOnLoad(m_nobj);
            }

            if (null == m_pobj)
            {
                m_pobj = new GameObject("pet_pobj");//当前切线前方点
                //UnityEngine.Object.DontDestroyOnLoad(m_pobj);
            }

            if (null == m_qobj)
            {
                m_qobj = new GameObject("pet_qobj");//圆外点到圆切线的切点
                //UnityEngine.Object.DontDestroyOnLoad(m_qobj);
            }
            
           //部队类型
            m_unitsType = eNpcUnitsType.Air;

            //可移动可转圈
            m_bMove = true;
            m_bTurn = true;

            //初始高度
            m_currentHeight = position.y + m_height;

            //调用基类初始化
            base.Init(battlescene, index, NpcType, wLevel, eNpcSort.Pet, position, Quaternion.identity, DEFINE.UNTAGGED_OBJECT_TAG);

            m_pOriginCard.fMoveSpeed = 5.0f;
            MoveSpeed = 5.0f;

            AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);//宠物是无敌的
            EnablePathFinding(false);//不需要寻路
            setupFSM();//配好状态机
        }

    }

    protected override void CreateNpc(Vector3 position, Quaternion rotation,bool replace = false)
    {
        string szPath = m_pPetLoader.ModelLoader.Path;
        //string szPath = "resources/npc/pet/chongwu_001_model.x";//这里需要从数据表里面读取，临时写一个替代一下
        if (null != m_pNpcObj)
        {
            m_pNpcObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        
        m_pNpcObj = new CObject(szPath);

        m_pNpcObj.Layer = DEFINE.PET_LAYER;

        m_pNpcObj.Name = m_uiIndex.ToString();
        m_pNpcObj.CallBack = LoadNpcCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = replace ? eObjectType.ReplaceModel :eObjectType.Pet;
        m_pNpcObj.BornPosition = position;
        m_pNpcObj.BornRotation = rotation;
        m_pNpcObj.LoadObject();
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
		if (null == o)
        {
            m_pPetLoader = HolderManager.m_PetHolder.GetStaticInfo(DEFINE.REPLACE_PET_LOADER_KEY);
            if (null != m_pPetLoader)
            {
                CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation, true);
            }
            return;
        }
        //体型变更
        o.transform.localScale = Vector3.one * m_pPetLoader.ModelLoader.ModleScale;

        base.LoadNpcCompleted(o, args);

        //加载Animator Controller 组件
        string szPath = m_pPetLoader.ModelLoader.Path;
        szPath = szPath.Replace("_model", "_ctrl");
        LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadAcnimatorCtrl);

        //加载拖尾特效
        //m_effectID = CreateParticle(DEFINE.PET_TRAIL_EFFECT);

        //不需要controller
        //GameObject.Destroy(m_characterController);
        //m_characterController = null;

        m_buffTrans = Common.GetBone(o.transform, "BP_Buff");
        
        //宠物忽略所有碰撞
        ApplyCharacterCtrl = false;


        m_selfTransform = GetTransform();

        CBaseHomeAvatar.setPetParticals(o, m_uiNpcType);
    }

   

    protected override void InitModel(GameObject o)
    {
        base.InitModel(o);


        //玩家使用charactercontroll移动
        m_characterController = o.GetComponent<CharacterController>();
        if (m_characterController != null)
        {
            m_characterController.enabled = true;
            SetCollider(m_characterController);
        }

    }

    public void RenameBuffPoint(bool bRename)
    {
        if (m_buffTrans != null)
        {
            if (bRename)
            {
                m_buffTrans.name = "BP_Buff_bak";
            }
            else
            {
                m_buffTrans.name = "BP_Buff";
            }
            
        }
    }


    public PetModelContent GetPetModelLoader()
    {
        return m_pPetLoader.ModelLoader;
    }

    public void Refresh()
    {
        if (IsValid)
        {
            m_masterTransform = m_masterNpc.GetTransform();
            //m_petFSM.TriggerEventQueued(ePetEvent.LEAVE_EDGE);
            //CParticle cp = CParticleManager.GetInst().GetParticle(m_effectID);
            //if (cp != null)
            //{
            //    cp.GetGameObj().SetActive(false);
            //}
            m_effectOffTimer.SetTimer(1);
        }
    }


    public override void SimpleMove(Direction3D dir, float speed)
    {
        Vector3 fDecelerateVector = dir.normalized * speed;

        if (null != m_characterController && m_characterController.enabled)
        {
            m_characterController.Move(fDecelerateVector * Time.deltaTime);
        }
    }

    public override void Update()
    {
        if (m_isRelease)
            return;
        if (IsValid)
        {
            base.Update();

            if (m_effectOffTimer.IsExpired(false))
            {
                //CParticle cp = CParticleManager.GetInst().GetParticle(m_effectID);
                //if (cp != null)
                //{
                //    cp.GetGameObj().SetActive(true);
                //}
                m_effectOffTimer.Release();
            }

            UpdateChat();

            m_petFSM.Update();

            //MyLog.Log("Pet State: " + m_petFSM.CurrentState);

            //UpdateWander();
            //TestUpdate();
            if (Input.GetKeyDown(KeyCode.Q))
            {
                //m_partnerFSM.TriggerEventQueued(ePartnerEvent.SwitchCompleted);
                //UseSkill(DEFINE.MOUNT_SUMMON_SKILL, m_targetList, false, true);

            }
        }
    }

    public override void Release(eObjectDestroyType type)
    {
        if (m_isRelease)
            return;
        m_isRelease = true;

        base.Release(type);

        m_chatWordsAtHomeList.Clear();
        //m_chatWordsInBattleList.Clear();
        m_petFSM.Clear();

        CBaseNpc m_masterNpc = null;
        Transform m_selfTransform = null;//自己的transform
        Transform m_masterTransform = null;//主人的transform

        //CParticleManager.GetInst().AddDestroyParticle(m_effectID);

        GameObject.Destroy(m_tobj);
        GameObject.Destroy(m_nobj);
        GameObject.Destroy(m_pobj);
        GameObject.Destroy(m_qobj);
        m_tobj = null;
        m_nobj = null;
        m_pobj = null;
        m_qobj = null;
    }

    public override void RemoveNpc()
    {
        base.RemoveNpc();
        m_pBattleScene.RemoveNpc(m_uiIndex);
        Release(eObjectDestroyType.UnloadAll);
    }

    public void OnMasterEnterState(CBaseNpc sender, eActionState state)
    {
        if (state != eActionState.None)
        {
            ePetSkillType psType = ePetSkillType.None;
            switch (state)
            {
                case eActionState.Attack:
                    psType = ePetSkillType.Atttack;
                    break;
                case eActionState.Behit:
                    psType = ePetSkillType.Behit;
                    break;
                case eActionState.Roll:
                    psType = ePetSkillType.Roll;
                    break;
                default:
                    psType = ePetSkillType.None;
                    break;
            }

            if (psType != ePetSkillType.None)
            {
                foreach (PetSkillContent cpsl in m_petSkills[(int)psType])
                {
                    //丢骰子看是否触发
                    if (Random.Range(0.0f, 1.0f) <= cpsl.PetSkillPro / 10000f
                        && m_petState != ePetState.PickGo && m_petState != ePetState.PickBack)
                    {
                        m_skillToCast = (uint)cpsl.PetSkillIndex;
                        m_petFSM.TriggerEventQueued(ePetEvent.USE_SKILL);
                    }
                }
            }
        }
    }

    public void UpdateChat()
    {
        m_chatTimeCountCown -= Time.deltaTime;
        if (m_chatTimeCountCown <= 0.0f)
        {
            m_chatTimeCountCown = m_chatTimeToCount;

            List<string> wordsList = null;
            switch (m_petOccasion)
            {
                //case ePetOccasion.Home:
                //    wordsList = m_chatWordsAtHomeList;
                //    break;
                case ePetOccasion.Battle:
                    //wordsList = m_chatWordsInBattleList;
                    break;
                default:
                    wordsList = null;
                    break;
            }

            if (wordsList != null)
            {
                if (wordsList.Count > 0)
                {
                    string wordsToSay = wordsList[Random.Range(0, wordsList.Count)];
                    CreateChatBubble(wordsToSay);
                } 
            }
        }
    }

    public void fsmpreUpdate(System.Enum stateToUpdate)
    {
        if (m_selfTransform != null && MasterTrans != null && m_petFSM != null && m_petFSM.CurrentState != null)
        {
            if (!m_petFSM.CurrentState.Equals(ePetState.FlyFight) &&
                !m_petFSM.CurrentState.Equals(ePetState.EndFlyFight))
            {
                m_targetPosition = MasterTrans.position + Vector3.up * m_height;
            }

            m_currPosition = new Vector3(m_selfTransform.position.x, m_targetPosition.y, m_selfTransform.position.z);
            m_cradOutVector = m_currPosition - m_targetPosition;
            m_midPosition = m_targetPosition + m_cradOutVector.normalized * m_wanderRadius;
            m_mradOutVector = m_midPosition - m_targetPosition;
            m_ctangentVector = new Vector3(-m_cradOutVector.z, 0, m_cradOutVector.x);
            m_mtangentVector = new Vector3(-m_mradOutVector.z, 0, m_mradOutVector.x);

            float alpha = Mathf.Acos(m_wanderRadius / m_cradOutVector.magnitude);
            m_tradVector = m_mradOutVector;
            if (alpha > 0.1f)
            {
                Quaternion qua = Quaternion.AngleAxis(Mathf.Rad2Deg * -alpha, Vector3.up);
                m_tradVector = (qua * m_cradOutVector.normalized) * m_wanderRadius;
            }


            m_tobj.transform.position = m_targetPosition;
            m_pobj.transform.position = m_mtangentVector + m_midPosition;
            m_qobj.transform.position = m_targetPosition + m_tradVector;

            //计算距离
            m_distance = m_cradOutVector.magnitude;

            //更新计时器
            m_timeCountDown -= Time.deltaTime;
        }
    }

    public void fsmlateUpadate(System.Enum stateToUpdate)
    {
        if (!m_petFSM.CurrentState.Equals(ePetState.FlyFight) && 
            !m_petFSM.CurrentState.Equals(ePetState.BeginFlyFight) &&
            !m_petFSM.CurrentState.Equals(ePetState.EndFlyFight) &&
            m_selfTransform != null)
        {        
            //同步高度
            if (Mathf.Abs(m_currentHeight - m_targetPosition.y) > 0.05f)
            {
                m_currentHeight += Time.deltaTime * Mathf.Sign(m_targetPosition.y - m_currentHeight) * 1.6f;
            }
            else
            {
                m_currentHeight = m_targetPosition.y;
            }

            m_selfTransform.position = new Vector3(m_selfTransform.position.x, m_currentHeight, m_selfTransform.position.z);
            //插值转向  
            Vector3 nobjDir = Vector3.Slerp(m_originFaceDirection, m_targetFaceDirection, Mathf.Clamp((m_timeToCount - m_timeCountDown) / m_timeToCount, 0.0f, 1.0f));
            m_nobj.transform.position = m_currPosition + nobjDir.normalized * m_wanderRadius;
        }
       

        //MyLog.Log(m_petFSM.CurrentState);
        //MyLog.Log("m_originFaceDirection: " + m_originFaceDirection.normalized);
        //MyLog.Log("forward:" + m_selfTransform.forward.normalized);
        //MyLog.Log("m_originFaceDirection: " + m_targetFaceDirection);
        //MyLog.Log("amount: " + Mathf.Clamp01((m_timeToCount - m_timeCountDown) / m_timeToCount));
        //MyLog.Log("m_timeCountDown: " + m_timeCountDown);
        //MyLog.Log("m_timeToCount: " + m_timeToCount);
    }

    private void wanderUpdate(System.Enum stateToUpdate)
    {
        if (m_selfTransform != null && MasterTrans != null)
        {
            //确定父类中的状态
            if (GetCurrActState() != eActionState.Run && (!m_bPausedCheck || !m_bPausedMove))
            {
                EnterState(eActionState.Run);
                SetFollowTransform(m_nobj.transform,false);
                CurrTarget = null;
            }

            if (m_distance <= m_wanderRadius)//闲逛，搜寻
            {
                //随机确定目标点           
                if (m_timeCountDown <= 0)
                {
                    float minR = -1.0f;
                    float maxR = 1.0f;
                    //float maxR = distance < m_radius ? 1.0f : Mathf.Lerp(1.0f, -1.0f, Mathf.Clamp01(distance / m_radius));
                    float minT = -1.0f;
                    float maxT = 1.0f;

                    float lenR = Random.Range(minR, maxR);
                    float lenT = Random.Range(minT, maxT);

                    Vector3 faceVec = m_cradOutVector.normalized * lenR + m_ctangentVector.normalized * lenT;
                    faceVec = faceVec.normalized + m_selfTransform.forward.normalized / 2.0f;

                    m_targetFaceDirection = faceVec;
                    m_originFaceDirection = m_selfTransform.forward;

                    m_timeToCount = Random.Range(0.5f, 1.5f);
                    m_timeCountDown = m_timeToCount;
                    ////闲逛的时候找装备
                    //m_dobj = CDropObjectManager.GetInst().PickDropObjectInRange(m_targetPosition, m_pickRadius);
                    //if (m_dobj != null)
                    //{
                    //    if (m_dobj.State == eDropObjectState.Created || m_dobj.State == eDropObjectState.Wait)
                    //    {
                    //        //发现物品进入pickgo状态
                    //        m_pickgoStartPosition = m_selfTransform.position;
                    //        m_petFSM.TriggerEventQueued(ePetEvent.FOUND_ITEM);
                    //    }
                    //}
                }

                if (m_pAnimator != null)
                {
                    m_pAnimator.Speed = 1.0f;
                    //m_pAnimator.Speed = Mathf.Clamp(Mathf.Pow(m_timeToCount, 2.0f * Mathf.Clamp01((m_timeToCount - m_timeCountDown) / m_timeToCount)), 0.5f, 2.0f);
                }

            }
            else if (m_distance <= m_maxDistance) 
            {
                //跟随移动
                m_petFSM.TriggerEventQueued(ePetEvent.LEAVE_WANDER_CIRCLE);
            }
            else
            {
                //瞬间移动
                m_petFSM.TriggerEventQueued(ePetEvent.LEAVE_EDGE);
            }
        }
    }

    private void followUpdate(System.Enum stateToUpdate)
    {
        if (m_selfTransform != null && MasterTrans != null)
        {
            //确定父类中的状态
            if (GetCurrActState() != eActionState.Run && (!m_bPausedCheck || !m_bPausedMove))
            {
                EnterState(eActionState.Run);
                SetFollowTransform(m_nobj.transform,false);
                CurrTarget = null;
            }

            if (m_distance <= m_wanderRadius)
            {
                //进入闲逛，搜寻模式
                m_petFSM.TriggerEventQueued(ePetEvent.ENTER_WANDER_CIRCLE);
            }
            else if (m_distance <= m_maxDistance)
            {
                //跟随移动
                //将目标点设为玩家角色
                if (m_timeCountDown <= 0)
                {
                    m_targetFaceDirection = -m_cradOutVector;
                    m_originFaceDirection = m_selfTransform.forward;

                    m_timeToCount = 0.5f;
                    m_timeCountDown = m_timeToCount;
                }

                if (m_pAnimator != null)
                {
                    m_pAnimator.Speed = Mathf.Clamp(Mathf.Pow(1.2f, (m_distance - m_wanderRadius)), 0.5f, 1.0f);
                }
            }
            else
            {
                //进入瞬间移动模式
                m_petFSM.TriggerEventQueued(ePetEvent.LEAVE_EDGE);
            }
        }
    }

    private void pickgoUpdate(System.Enum stateToUpdate)
    {
        if (m_dobj == null)
        {
            m_petFSM.TriggerEventQueued(ePetEvent.LOST_ITEM);
            return;
        }

        if (m_dobj.State != eDropObjectState.Created && m_dobj.State != eDropObjectState.Wait)
        {
            m_petFSM.TriggerEventQueued(ePetEvent.LOST_ITEM);
            m_dobj = null;
            return;
        }

        //距离物品还有多远
        float distanceToItem = Common.Get2DVecter3Length(m_currPosition, m_dobj.Obj.transform.position);

        //将目标点设为物品
        if (m_timeCountDown <= 0)
        {
            m_targetFaceDirection = m_dobj.Obj.transform.position - m_selfTransform.position;
            m_targetFaceDirection.y = 0.0f;
            m_originFaceDirection = m_selfTransform.forward;

            m_timeToCount = 0.5f;
            m_timeCountDown = m_timeToCount;
        }

        //飞下去捡东西
        float itemHeight = m_dobj.Obj.transform.position.y;// +0.5f;
        m_currentHeight = Mathf.Lerp(m_pickgoStartPosition.y, itemHeight, 1.0f - Mathf.Clamp01(distanceToItem / m_wanderRadius));
        m_selfTransform.position = new Vector3(m_selfTransform.position.x, m_currentHeight, m_selfTransform.position.z);


        //捡到东西
        Direction3D toPet = (m_selfTransform.position - m_dobj.Obj.transform.position).normalized;

        if (distanceToItem < m_height && distanceToItem > 0.5f )
        {
            m_dobj.Obj.transform.position = m_dobj.Obj.transform.position + toPet * 0.1f;
        }
        else if (distanceToItem <= 0.5)
        {
            Transform bindTrans = Common.GetBone(m_selfTransform,"BP_Step");
            m_dobj.Obj.transform.parent = bindTrans;
            m_dobj.Obj.transform.localPosition = Vector3.zero;
            m_dobj.Obj.transform.localRotation = Quaternion.identity;
            
        }
        if (distanceToItem <= 0.1f)
        {
            m_dobjPickPosition = m_dobj.Obj.transform.position;
            m_petFSM.TriggerEventQueued(ePetEvent.GOT_ITEM);
        }

        if (m_pAnimator != null)
        {
            //float e = 2.71828f;
            //float prime = -Mathf.Pow(distanceToItem/m_wanderRadius, 2.0f);
            //m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * (Mathf.Pow(e, prime) + 1);
            //m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * Mathf.Clamp01(Mathf.Pow(distanceToItem + 0.2f, 2.0f) / m_wanderRadius);
            m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * Mathf.Clamp(distanceToItem / m_wanderRadius, 0.15f, 1.0f);
        }
    }

    private void pickbackUpdate(System.Enum stateToUpdate)
    {
        if (m_dobj == null)
        {
            m_petFSM.TriggerEventQueued(ePetEvent.LOST_ITEM);
            return;
        }

        if (m_dobj.State != eDropObjectState.Created && m_dobj.State != eDropObjectState.Wait)
        {
            m_petFSM.TriggerEventQueued(ePetEvent.LOST_ITEM);
            m_dobj = null;
            return;
        }

        //距离拾取点已经有多远
        float distanceToItem = Common.Get2DVecter3Length(m_currPosition, m_dobjPickPosition);

        //将目标点设为玩家角色
        if (m_timeCountDown <= 0)
        {
            m_targetFaceDirection = -m_cradOutVector;
            m_originFaceDirection = m_selfTransform.forward;

            m_timeToCount = 0.5f;
            m_timeCountDown = m_timeToCount;
        }

        //飞下去捡东西
        float itemHeight = m_dobjPickPosition.y;//+ 0.5f;
        m_currentHeight = Mathf.Lerp(m_targetPosition.y, itemHeight, 1.0f - Mathf.Clamp01(distanceToItem / m_wanderRadius));
        m_selfTransform.position = new Vector3(m_selfTransform.position.x, m_currentHeight, m_selfTransform.position.z);

        ////飞下去捡东西
        //float itemHeight = m_dobj.Obj.transform.position.y;
        //itemHeight += 2.0f * Time.deltaTime;
        //if (itemHeight > m_currentHeight)
        //{
        //    itemHeight = m_currentHeight;
        //}
        //m_selfTransform.position = new Vector3(m_selfTransform.position.x, itemHeight, m_selfTransform.position.z);
        
        //东西跟随宠物飞行
        //m_dobj.Obj.transform.position = m_selfTransform.position;

        if (m_pAnimator != null)
        {
            //float e = 2.71828f;
            //float prime = -Mathf.Pow(distanceToItem / m_wanderRadius, 2.0f);
            //m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * (Mathf.Pow(e, prime) + 1);
            //m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * Mathf.Clamp01(Mathf.Pow(distanceToItem + 0.2f, 2.0f) / m_wanderRadius);
            m_pAnimator.Speed = (Mathf.Clamp01(m_distance / m_wanderRadius) + 1) * Mathf.Clamp(distanceToItem / m_wanderRadius, 0.5f, 1.0f);
            //m_pAnimator.Speed = Mathf.Clamp01(m_distance / m_wanderRadius) * 2.0f;
        }
    }

    private void skillEntry(System.Enum stateToEnter)
    {
        m_timeCountDown = 0.0f;
        m_height = 3.5f;

        if (m_skillToCast != 0)
        {
            if (m_pAnimator != null)
            {
                m_pAnimator.Speed = 0.5f;
            }
            Avatar pavatar = SingletonObject<Avatar>.GetInst();

            //切换小伙伴中 不能使用技能
            if (pavatar.PartnerState == ePartnerState.SwitchingToAvatar ||
                pavatar.PartnerState == ePartnerState.SwitchingToPartner)
            {
                return;
            }

            List<CBaseNpc> targets = new List<CBaseNpc>();
            targets.Add(m_masterNpc);

            bool canUse = this.CanUseSkill(new UseSkillCommandArg(m_skillToCast, targets, false));
            if (canUse == true)
            {
                if (CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve)
                {
                    SingletonObject<Avatar>.GetInst().TriggerUseSkillHandler(m_skillToCast, Vector3.zero, (int)eSyncAttack.Pet);
                }
                else
                {
                    this.Command(eCommandType.UseSkill, new UseSkillCommandArg(m_skillToCast, targets, false));
                }
            }    
                                                        
            m_skillToCast = 0;
        }       
    }

    private void skillUpdate(System.Enum stateToUpdate)
    {
        if (GetCurrActState() != eActionState.Skill)
        {
            m_petFSM.TriggerEventQueued(ePetEvent.USE_SKILL_DONE);
        }
    }

    private void blinkUpdate(System.Enum stateToUpdate)
    {
        //瞬间移动
        m_selfTransform.position = m_targetPosition;
        SetFollowTransform(m_nobj.transform,false);
        CurrTarget = null;

        m_dobj = null;

        m_petFSM.TriggerEventQueued(ePetEvent.BLINK_DONE);
    }

    private void beginFlyFightEntry(System.Enum stateToEnter)
    {
        m_timeCountDown = 0.0f;
        m_bFlyFightInit = false;
        m_height = DEFINE.PET_FLY_FIGHT_AVATAR_JUMP_HEGHT;

        Vector3 flyDestPosition = m_masterNpc.GetMountAndJumpPosition() + new Vector3(0, m_height, 0);
        m_nobj.transform.position = flyDestPosition;

        

        EnterState(eActionState.PetBeginFly);
    }


    private void beginFlyUpdate(System.Enum stateToUpdate)
    {
        CBaseState currMasterState = m_masterNpc.GetCurrState();
        if(currMasterState == null)
        {
            return;
        }
        if(currMasterState.GetState() != eActionState.BeginFly)
        {
            return;
        }
        if (GetCurrActState() != eActionState.PetBeginFly)
        {
            return;
        }

        float fTime = currMasterState.GetActionTime();
        if(fTime == -1)
        {
            return;
        }

        if (!m_bFlyFightInit)
        {
            m_timeToCount = fTime;
            m_flyFightoriginDistance = m_distance;
            m_timeCountDown = m_timeToCount;
            //iTween.ScaleTo(m_selfTransform.gameObject, new Vector3(3, 3, 3), m_timeToCount - 0.2f);
            if (null != m_selfTransform)
            {
                iTween.ScaleTo(m_selfTransform.gameObject, Vector3.one * m_pPetLoader.ModelLoader.BattleScale, m_timeToCount - 0.2f);
            }
            m_bFlyFightInit = true;
        }

        //算出水平位置
        Vector3 flyDestPosition = m_masterNpc.GetPosition() + new Vector3(0, m_height, 0);

        m_nobj.transform.position += MasterTrans.forward * 2 * Time.deltaTime;
        if (null != m_selfTransform)
        {
            iTween.MoveUpdate(m_selfTransform.gameObject, iTween.Hash("position", flyDestPosition, "time", m_timeToCount, "axis", "y", "looktarget", m_nobj.transform, "looktime", m_timeToCount, "delay", 0.0f, "loopType", iTween.LoopType.none, "easetype", iTween.EaseType.linear));
        }
        

        //float d = Common.Get2DVecter3Length(flyDestPosition, m_selfTransform.position);

        ////高度缓慢升降
        //float y = Mathf.Lerp(m_selfTransform.position.y, flyDestPosition.y, Time.deltaTime * 5);
        //m_selfTransform.position = new Vector3(m_selfTransform.position.x, y, m_selfTransform.position.z);

        ////计算旋转
        //float angleSpeed = m_flyFightAngleMargin / m_timeToCount;
        //Vector3 currAngle = m_selfTransform.transform.rotation.eulerAngles;
        //currAngle.y += angleSpeed * Time.deltaTime;
        //m_selfTransform.transform.rotation = Quaternion.Euler(currAngle);

        //if (m_pAnimator != null)
        //{
        //    if (d > 0.1f)
        //    {
        //        MoveSpeed = m_distance / m_timeToCount;
        //    }
        //    else
        //    {
        //        LeaveState(eActionState.PetBeginFly);
        //    }
        //}
        
    }


    private void flyFightEntry(System.Enum stateToEnter)
    {
        m_flyFightHeightState = eFlyFightHeightState.Drop;
        m_height = DEFINE.PET_FLY_FIGHT_AVATAR_FLY_HEGHT;
        
        m_fFlyFightOffset = 0;
        m_bFlyFightTurn = false;
        EnterState(eActionState.PetFlyFight);
    }

    private void flyFightUpdate(System.Enum stateToUpdate)
    {
        //先下降两米再缓慢爬升回来
        switch (m_flyFightHeightState)
        {
            case eFlyFightHeightState.Drop:
                {
                    float verticalSpeed = 4.0f;
                    float y = m_selfTransform.position.y;
                    y -= verticalSpeed * Time.deltaTime;

                    m_targetPosition = Common.GroundPosition(MasterTrans.position, DEFINE.TERRAINLAYER) + Vector3.up * (m_height - 2);

                    m_selfTransform.position = new Vector3(m_selfTransform.position.x, y, m_selfTransform.position.z);

                    if (m_selfTransform.position.y <= m_targetPosition.y)
                    {
                        m_flyFightHeightState = eFlyFightHeightState.Climb;
                    }
                }
                break;
            case eFlyFightHeightState.Climb:
                {
                    float verticalSpeed = 2f;
                    float y = m_selfTransform.position.y;
                    y += verticalSpeed * Time.deltaTime;
                    m_targetPosition = Common.GroundPosition(MasterTrans.position, DEFINE.TERRAINLAYER) + Vector3.up * m_height;
                    m_selfTransform.position = new Vector3(m_selfTransform.position.x, y, m_selfTransform.position.z);

                    if (m_selfTransform.position.y >= m_targetPosition.y)
                    {
                        m_flyFightHeightState = eFlyFightHeightState.Stably;
                        m_timeCountDown = 0;
                    }
                }
                break;
            case eFlyFightHeightState.Stably:
                {
                    float verticalSpeed = 0.5f;

                    float speed = 0;
                    if (m_bFlyFightTurn)
                    {
                        speed = verticalSpeed;
                        m_fFlyFightOffset += speed * Time.deltaTime;
                    }
                    else
                    {
                        speed = -verticalSpeed;
                        m_fFlyFightOffset += speed * Time.deltaTime;
                    }

                    if (m_fFlyFightOffset >= 0.3) m_bFlyFightTurn = false;
                    if (m_fFlyFightOffset < 0) m_bFlyFightTurn = true;

                    m_targetPosition = Common.GroundPosition(MasterTrans.position, DEFINE.TERRAINLAYER) + Vector3.up * m_height;

                    m_selfTransform.position = new Vector3(m_selfTransform.position.x, m_targetPosition.y + m_fFlyFightOffset, m_selfTransform.position.z);

                    if (m_timeCountDown > 0)
                    {
                        m_flyFightHeightState = eFlyFightHeightState.Drop;
                    }
                }
                break;
        }

       
    }
    private void endFlyEntry(System.Enum stateToEnter)
    {
        m_timeCountDown = 0.1f;//猛烈下降的时间
        m_flyFightHeightState = eFlyFightHeightState.Fall;
        m_height = DEFINE.PET_FLY_FIGHT_AVATAR_JUMP_HEGHT + 1;

    }

    private void endFlyUpdate(System.Enum stateToUpdate)
    {
        float verticalSpeed = 4f;
        float y = m_selfTransform.position.y;
        y -= verticalSpeed * Time.deltaTime;
        m_targetPosition = Common.GroundPosition(MasterTrans.position, DEFINE.TERRAINLAYER) + Vector3.up * m_height;
        m_selfTransform.position = new Vector3(m_selfTransform.position.x, y, m_selfTransform.position.z);

        if (y <= m_targetPosition.y)
        {
            m_masterNpc.EndFly(null);

        }

        //
    }

    private void onEntry(System.Enum stateToEnter)
    {
        m_timeCountDown = 0.0f;
        m_height = 3.5f;
    }

    private void onTransition(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        
    }

    public void townEntry(System.Enum stateToEnter)
    {
        //ApplyRootMotion = false;
    }

    public void TriggerEvent(ePetEvent eve)
    {
        m_petFSM.TriggerEvent(eve);
    }

    public override bool HitResult(SkillContent pSkillInfo, CBaseNpc pTarget, bool beHitMute = false)
    {
        if (pTarget.IsDead())
        {
            return false;
        }

        return base.HitResult(pSkillInfo, pTarget, beHitMute);
    }

    /// <summary>
    /// 在主城里的行为
    /// </summary>
    public void townUpdate(System.Enum stateToUpdate)
    {
        if (m_selfTransform != null && MasterTrans != null)
        {
            //Vector3 targetPosition = master.position;
            Vector3 targetPosition = MasterTrans.position + MasterTrans.right.normalized * 1f + MasterTrans.forward.normalized * 0.5f;

            m_tobj.transform.position = targetPosition;

            float distance = Common.Get2DVecter3Length(m_selfTransform.position, targetPosition);
            //float distance = Common.Get2DVecter3Length(self.position, master.position);

            //同步高度
            m_selfTransform.position = new Vector3(m_selfTransform.position.x, MasterTrans.position.y + 1.5f, m_selfTransform.position.z);
            //m_selfTransform.position = new Vector3(m_selfTransform.position.x, m_selfTransform.position.y + (Mathf.Pow(1.5f, distance) - 1.0f) / 8.0f, m_selfTransform.position.z);

           float animateSpeed = Mathf.Pow(1.4f, distance) - 1.0f;

           if (animateSpeed <= 0.25f)//停止移动
            {
                //UpdateTurn(master.forward, false);
                if (GetCurrActState() != eActionState.Idle)
                {
                    if (m_pAnimator != null)
                    {
                        m_pAnimator.Speed = 1;
                    }
                    EnterState(eActionState.Idle);

                    //m_selfTransform.position = targetPosition;
                    UpdateTurn(MasterTrans.forward, false);
                }
            }
            else if (distance <= m_maxDistance) //跟随移动
            {
                if (m_pAnimator != null)
                {
                    //m_pAnimator.Speed = 1.0f;
                    m_pAnimator.Speed = animateSpeed;
                }
                SetDestPosition(targetPosition, false);
                if (GetCurrActState() != eActionState.Run)
                {
                    //SetLookTransform(m_tobj.transform);
                    UpdateTurn(m_tobj.transform.position - m_selfTransform.position, false);
                    //SetLookTransform(master);

                    //SetDestPosition(master.position, false);
                    CurrTarget = null;

                    EnterState(eActionState.Run);
                }
            }
            else//瞬间移动
            {
                m_selfTransform.position = targetPosition;
            }
        }
    }

    //设置技能CD
    public bool SetSkillCD(uint uiSkillType, float fCD)
    {
        foreach (CInitiativeSkill pSkill in m_skillList)
        {
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo != null)
            {
                if (pSkillInfo.Key == uiSkillType)
                {
                    if (pSkill.CD == 0)
                    {
                        pSkill.CD = fCD;
                        return true;
                    }
                    break;
                }
            }
        }

        return false;
    }

    public override bool IsDead()
    {
        //宠物不会死，呵呵呵
        return false;
    }

    public PetContent GetNpcLoader()
    {
        return m_pPetLoader;
    }

    public override eNpcSortType GetNpcSortType()
    {
        return eNpcSortType.Pet;
    }
    public override List<float> GetAniMoveSpeed()
    {
        return m_pPetLoader.ModelLoader.AniMoveSpeed;
    }
    public override float GetMaxMoveSpeed()
    {
        return m_pPetLoader.ModelLoader.MaxMoveSpeed;
    }

    public override bool IsKill()
    {
        return false;
    }
    public override bool IsHitDown()
    {
        return false;
    }
    public override bool IsBeatFly()
    {
        return false;
    }
    public override bool IsCanStun()
    {
        return false;
    }
    public override bool IsSlow()
    {
        return false;
    }
    public override int GetDeadActID()
    {
        return 0;
    }
    public override float GetRigidity()
    {
        return 0;
    }

    public override string GetName()
    {
        return Common.GetText(m_pPetLoader.PetName);
    }
    

    
}