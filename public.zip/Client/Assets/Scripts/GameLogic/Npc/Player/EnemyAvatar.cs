﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Protocol;

public class EnemyAvatar : BaseBattlePlayer
{

    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.UNTAGGED_OBJECT_TAG)
    {
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);   
  
        InitFSM();

        switch (battlescene.BattleType)
        {
            case eBattleType.Arena:
                {
                    AddBuff(DEFINE.ARENA_LIFE_BUFF,null,true);
                }
                break;
            case eBattleType.Wasteland:
                {
                    AddBuff(DEFINE.WASTELAND_LIFE_BUFF, null, true);
                    AddBuff(DEFINE.WASTELAND_ATK_SPEED_BUFF_ID, null, true);

                    SceneContent pLoader = m_pBattleScene.GetSceneLoader();
                    if ( null != pLoader )
                    {
                        List<int> bufflist = pLoader.SceneBuff;
                        for (int i = 0, len = bufflist.Count; i < len; i ++ )
                        {
                            uint buffId = (uint)bufflist[i];
                            if ( 0 == buffId )
                                 continue;

                            //MyLog.LogError(" wasteland buff : " + buffId);
                            AddBuff(buffId, null, true);
                        }
                    }
                }
                break;
            case eBattleType.Mining:
                {
                    AddBuff(DEFINE.MINING_LIFE_BUFF, null, true);
                    AddBuff(DEFINE.MINING_ENEMYAVATAR_BUFF, null, true);
                    AddBuff(DEFINE.WASTELAND_ATK_SPEED_BUFF_ID, null, true);
                }
                break;

        }

        Trusteeship = true;
    }

    protected override void LoadAI()
    {
        base.LoadAI();

        //Dictionary<uint, uint> skillDict = new Dictionary<uint, uint>();
        Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();

        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        
        if (pcbsl != null && pcbsl.battleType == eBattleType.Arena)//读取竞技场技能数据
        {
            //从UI那边读取技能
            List<CSkillValue> skillvls = SingletonObject<ArenaManager>.GetInst().arenaSkillInfo;
            foreach (CSkillValue stskill in skillvls)
            {
                if (stskill.uiSkillID.ToString().Length == 8)
                {
                    //SKILL表
                    SkillContent csl = HolderManager.m_SkillHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csl != null)
                    {
                        if (!skillDict.ContainsKey((int)stskill.uiSkillID))
                        {
                            skillDict.Add((int)stskill.uiSkillID, null);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,skill id:" + stskill.uiSkillID + "is exist");
                        }
                        
                    }
                }
                else if (stskill.uiSkillID.ToString().Length == 6)
                {
                    SkillUpContent csul = HolderManager.m_SkillUpHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csul != null)
                    {
                        CSkillupInfo info = new CSkillupInfo(stskill.uiLvl, csul);
                        int uiSkillID = csul.SkillId;
                        if (!skillDict.ContainsKey(uiSkillID))
                        {
                            skillDict.Add(uiSkillID, info);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,CSkillupInfo id:" + stskill.uiSkillID + "is exist");
                        }
                    }
                }
                else
                {
                    MyLog.LogError("can't find id" + stskill.uiSkillID + "in skill/skillup!");
                }
            }
        }
        else if (pcbsl != null && pcbsl.battleType == eBattleType.Wasteland)
        {
            MoorManager.stEnemyData pEnemyDataInfo = MoorManager.GetInst().StEnemyDataInfo;

            foreach (CSkillValue stskill in pEnemyDataInfo.MatherInfo.skillDataVec)
            {
                if (stskill.uiSkillID.ToString().Length == 8)
                {
                    //SKILL表
                    SkillContent csl = HolderManager.m_SkillHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csl != null)
                    {
                        if (!skillDict.ContainsKey((int)stskill.uiSkillID))
                        {
                            MyLog.Log(this + " add SkillId : " + stskill.uiSkillID);
                            skillDict.Add((int)stskill.uiSkillID, null);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,skill id:" + stskill.uiSkillID + "is exist");
                        }
                    }
                }
                else if (stskill.uiSkillID.ToString().Length == 6)
                {
                    SkillUpContent csul = HolderManager.m_SkillUpHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csul != null)
                    {
                        CSkillupInfo info = new CSkillupInfo(stskill.uiLvl, csul);
                        uint uiSkillID = (uint)csul.SkillId;
                        if (!skillDict.ContainsKey((int)uiSkillID))
                        {
                            MyLog.Log(this + " add CSkillupInfo : " + uiSkillID);
                            skillDict.Add((int)uiSkillID, info);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,CSkillupInfo id:" + stskill.uiSkillID + "is exist");
                        }
                    }
                }
                else
                {
                    MyLog.LogError("can't find id" + stskill.uiSkillID + "in skill/skillup!");
                }
            }
        }

        MyLog.Log(this + " add Normal SkillId : " + m_pPlayerLoader.NormalSkill);
        skillDict.Add(m_pPlayerLoader.NormalSkill, null);

        if (m_pAI != null)
        {
           
            if (CurrBattleScene.BattleType == eBattleType.Arena)
            {
                m_pAI.SetAI(DEFINE.ARENA_BATTLE_AI_ID, null, skillDict);
            }
            else if (CurrBattleScene.BattleType == eBattleType.Wasteland || 
                       CurrBattleScene.BattleType == eBattleType.Mining)
            {
                m_pAI.SetAI(DEFINE.WASTELAND_BATTLE_AI_ID, null, skillDict);
            }
            else
            {
                m_pAI.SetAI(DEFINE.AVATAR_BASE_AI_ID, null, skillDict);
            }
   
        }
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if ( null == o)
        {
            m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            PlayerConfigContent playerConfig = HolderManager.m_PlayerConfigHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            ClothesID = (uint)playerConfig.Clothes;

            CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation, true);
            return;
        }

        bool replace = (bool)m_pNpcObj.Args[0];
        if (replace)
        {
            Common.MaterialCulling(o);
        }

        base.LoadNpcCompleted(o, args);

        for (int i = 0, len = m_PartnerList.Count; i < len; i++)
        {
            m_PartnerList[i].CreateObj(o.transform.position, o.transform.rotation,false);
        }

        m_uiPvpParticleIndex = AddPvpStepParticle();
    }

    public override void Update()
    {
        base.Update();
        //MyLog.Log("EnemyAvatar HP: " + m_nHp + "/" + GetMaxHp());
    }

    protected override void InitCharacterCard(ushort wLevel)
    {
        base.InitCharacterCard(wLevel);
    }

    public override void RrefeshHPComponent()
    {
        base.RrefeshHPComponent();

        if (CurrBattleScene.BattleType == eBattleType.Arena)
        {
            SingletonObject<ArenaResultMediator>.GetInst().SetEnemyHpValue(m_nHp, m_pCard.nMaxHp);
        }
    }

    public override void NpcDead(bool bNaturalDeath, CBaseNpc attack = null, bool fromMsg = false)
    {
        base.NpcDead(bNaturalDeath, attack, fromMsg);

        ArenaManager pArena = ArenaManager.GetInst();
        if ( pArena != null && CurrBattleScene.BattleType == eBattleType.Arena && (AvatarDead || PartnerDead) && pArena.challengeRst == 0)
        {
            //伙伴挂了,结果为敌方胜利,锁血
            if (!LockHP)
            {
                LockHP = true;
                LockHPValue = (int)(GetMaxHp() * 0.1f);
            }
        }

        if (IsDead())
        {
            SingletonObject<BattleScene>.GetInst().UpdateWinProcess(eBattleWinCondition.KillEnemyAvatar, "1");
        }
    }

    //protected override void ChangeAlphaVertexColor(bool add)
    //{
    //    if (m_materiaslCount <= 0)
    //    {
    //        MyLog.LogError("ChangeAlphaVertexColor EnemyAvatar ID : " + Index.ToString() + "\tPath : " + m_pNpcObj.Path + "\t Materials count is 0");
    //        m_liveState = eLiveState.NONE;
    //        return;
    //    }
    //    if (add)
    //    {
    //        m_alphaVertexAlpha += m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
    //    }
    //    else
    //    {
    //        m_alphaVertexAlpha -= m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
    //    }

    //    m_alphaVertexAlpha = Mathf.Clamp01(m_alphaVertexAlpha);

    //    if (m_materiaslCount <= 0)
    //        MyLog.LogError("EnemyAvatar Materials is not get,Count is 0");

    //    for (int i = 0; i < m_materiaslCount; ++i)
    //    {
    //        Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //    }
    //    if (m_mat != null)
    //    {
    //        m_mat.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //    }
    //    if (m_mat1 != null)
    //    {
    //        m_mat1.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //    }

    //    if (m_mountMat != null)
    //    {
    //        m_mountMat.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //    }

    //    if (m_directPoint != null)
    //    {
    //        m_directPoint.transform.GetChild(0).GetChild(0).renderer.material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //        m_directPoint.transform.GetChild(0).GetChild(1).renderer.material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
    //    }

    //    if (m_alphaVertexAlpha % 1f == 0f)
    //    {
    //        if (add && m_alphaVertexAlpha == 1)
    //        {
    //            m_liveState = eLiveState.NONE;


    //            for (int i = 0; i < m_materiaslCount; i++)
    //            {
    //                Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
    //            }

    //            if (m_mat)
    //                m_mat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
    //            if (m_mat1)
    //                m_mat1.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

    //            if (m_mountMat)
    //                m_mountMat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
    //            m_currShaderName = m_material0Name;
    //        }
    //        else if (!add && m_alphaVertexAlpha == 0)
    //        {
    //            m_liveState = eLiveState.NONE;
    //        }
    //    }
    //}
}