﻿using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class BaseBattlePlayer : CBaseNpc
{
    protected PlayerContent m_pPlayerLoader;
    protected GameObject m_directPoint;  //脚底箭头

    protected List<CPartner> m_PartnerList = new List<CPartner>();
    public List<CPartner> PartnerList 
    {
        set { m_PartnerList = value; }
        get { return m_PartnerList; }
    }

    protected CPartner m_activePartner = null;
    public CPartner ActivePartner //激活的伙伴
    {
        get{ return m_activePartner;}
    }

    private CPartner m_inActivePartner; 
    public CPartner InActivePartner  //未激活的小伙伴(如果有)
    {
        get { return m_inActivePartner; }
    }

    private Timer m_secondTimer;//每秒执行的代码计时器

    protected Material m_mountMat;//坐骑的材质

    public bool HasPartner
    {
        get { return m_PartnerList.Count > 0; }
    }

    //protected CharacterController m_characterController;//原始的碰撞器,但是怪物只取它的半径和高度数据

    protected Pet m_myPet;
    public Pet MyPet
    {
        get { return m_myPet; }
        set { m_myPet = value; }
    }
    
    protected bool m_bCourageous = false;
    public bool Courageous//英勇无畏
    {
        get { return m_bCourageous; }
        set 
        {
            if (value)
            {
                AddBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
            }
            else
            {
                DelBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
            }
            m_bCourageous = value;
        }
    }

    private uint m_uiClothesID;//默认衣服

    //精力...
    protected int m_nMp;//当前精力
    protected int m_nMaxMp = 100;//最大精力
    private Timer m_pMpTimer = new Timer(); //精力恢复计时

    private Vector3 m_NextPosition;//等待当前动作播完中断连击,进入run状态

    private float m_fRepressCritbyMount;  //坐骑的暴击率压制
    public float RepressCritByMount
    {
        get { return m_fRepressCritbyMount; }
    }
    private float m_fRepressCritbyPet;       //宠物的暴击率压制
    public float RepressCritByPet
    {
        get { return m_fRepressCritbyPet; }
    }

    private PlayerConfigContent m_pConfigLoader;

    private CharacterController m_replaceModelController;//替代模型的碰撞,主要用来切换小伙伴,骑乘,下鸟用来预先定位
    public CharacterController ReplaceModelController
    {
        get
        {
            if (null == m_replaceModelController)
            {
                GameObject o = new GameObject("ReplaceController");
                o.layer = DEFINE.HOMENPC_LAYER;//借用
                m_replaceModelController = o.AddComponent<CharacterController>();
                m_replaceModelController.enabled = false;
            }
            return m_replaceModelController;
        }
    }

    private void ReplaceModelPauseOtherMove(bool pause)
    {
        if (m_replaceModelController != null) m_replaceModelController.enabled = pause;
        if (m_pBattleScene != null)
        {
            m_pBattleScene.StopAllNpcSimpleMove(this,pause);
        }
    }

    //骑乘
    private bool m_bUseRide;//一场战斗只能骑乘一次
    public bool UseRide
    {
        get { return m_bUseRide; }
        set { m_bUseRide = value; }
    }
    private CObject m_mountObj;
    public GameObject GetMountObj() { if (m_mountObj == null) return null; return m_mountObj.gameCObject; }
    private CAnimator m_mountAnimator;
    protected MountsContent m_pMountLoader;
    private Timer m_pMountTimer;
    protected eRideState m_rideState;
    //private int m_RideTimeFrameCount = 0;//作为qicheng_jump和qicheng中间的过度,详见遇见的<疑难杂症解决方案.docx>第10条   
    private Vector3 m_mountAndPetJumpPosition;

    //飞行,骑乘公用
    private stCharacterCard m_pBakOriginCard;//在骑乘前人物的初始角色卡
    private uint m_uiBakDefaultSkill;//在骑乘前人物的默认技能
    private List<CInitiativeSkill> m_bakPlayerSkillList = new List<CInitiativeSkill>();//在骑乘前人物的技能列表
    private CObject m_bakObject;//在骑乘前人物的模型
    private CAnimator m_bakAnimator;//在骑乘前人物的动作管理器
    private GameObject m_bakShadow;//在骑乘前人物的阴影
    private Transform m_bakTrans;//在骑乘前人物的变换

    public Transform BakTrans
    {
        get { return m_bakTrans; }
    }
    private SkinnedMeshRenderer[] m_bakSmr;//在骑乘前人物的蒙皮
    private MeshRenderer[] m_bakMrs;//在骑乘前人物的影子
    private Material[] m_bakMaterials;//在骑乘前人物的材质
    private CharacterController m_bakController;//在骑乘时人物的胶囊体
    private List<float> m_bakAniMoveSpeed;
    private float m_fBakMaxMoveSpeed;//骑乘前人物的最大速度

    protected PlatformReceiveMessage m_pPlatformReceiver = null;
//     public PlatformReceiveMessage PlatformReceiver
//     {
//         get { return m_pPlatformReceiver; }
//    
    //飞行
    private bool m_bUseFly;//一场战斗只能飞行一次
    public bool UseFly
    {
        get { return m_bUseFly; }
        set { m_bUseFly = value; }
    }
    private Timer m_pPetTimer;
    protected eFlyState m_flyState;

    protected uint m_uiPvpParticleIndex = 0;

    //小伙伴
    protected PartnerSortItem m_partnerInfo;
    public PartnerSortItem partnerInfo { get { return m_partnerInfo; } }

    protected Timer m_switchCDTimer = new Timer();//小伙伴切换定时器
    protected bool m_isAvatarDead = false;
    protected bool m_bTwoPartners = false;  //两个小伙伴
    public bool TwoPartner
    {
        get { return m_bTwoPartners; }
        set { m_bTwoPartners = value; }        
    }

    protected CObject m_avatarObj = null;

    private CAnimator m_avatarAnimator = null;

    private CObject m_avatarLeftWeapon = null;
    private CObject m_avatarRightWeapon = null;
    protected CSimpleFSM m_partnerFSM = new CSimpleFSM();
    private float m_jumpRadius = 15.5f;
    private float m_switchTime = 0.75f;
    protected float m_avatarLifePercent = 1.0f;

    protected GameObject m_tempCameraAncher;

    private List<Material> m_materialsList = new List<Material>();
    
    protected Dragonshard m_pAtkDragon; //攻击龙晶
    public Dragonshard AtkDragon
    {
        set { m_pAtkDragon = value; }
        get { return m_pAtkDragon; }
    }
    protected Dragonshard m_pDefDragon;//防御龙晶
    public Dragonshard DefDragon
    {
        set { m_pDefDragon = value; }
        get { return m_pDefDragon; }
    }

    //小伙伴公开属性
    public float PartnerSwitchTimeLeft//小伙伴出战剩余时间
    {
        get { return m_switchCDTimer.GetLeftTime(); }
    }
    public float MountSwitchTimeLeft//坐骑出战剩余时间
    {
        get 
        {
            if (m_pMountTimer == null)
                return 0.0f;
            return m_pMountTimer.GetLeftTime(); 
        }
    }
    public float PetSwitchTimeLeft//坐骑出战剩余时间
    {

        get
        {
            if (m_pPetTimer == null)
                return 0.0f;
            return m_pPetTimer.GetLeftTime();
        }
    }
    public float PartnerSwitchCD//小伙伴最大出战时间
    {
        get
        {
            if ( null == ActivePartner ) return 0;

            return ActivePartner.PartnerLoader == null ? 0 : ActivePartner.PartnerLoader.ModelLoader.SwitchCD;
        }    
    }

    //当前坐骑id
    private uint m_uiMountID;
    public uint MountID
    {
        get { return m_uiMountID; }
    }

    //当前宠物id
    public uint PetID
    {
        get { return PetManager.GetInst().CurPetID; }
    }

    public float MountSwitchCD//坐骑最大出战时间
    {
        get { return m_pMountLoader == null ? 0 : m_pMountLoader.ModelLoader.MountsFightTime; }
    }

    public uint MountJumpSound //上下坐骑音效id
    {
        get { return m_pMountLoader == null ? 0 : (uint)m_pMountLoader.ModelLoader.SoundID; }
    }

    public uint PetJumpSound //上下宠物音效id
    {
        get { return m_myPet.GetPetModelLoader() == null ? 0 : (uint)m_myPet.GetPetModelLoader().SoundID;}
    }

    public float PetSwitchCD//飞行宠物最大出战时间
    {
        get {
            if (null == m_myPet)
            {
                return 0;
            }
            PetModelContent content = m_myPet.GetPetModelLoader();
            if (null == content)
            {
                return 0;
            }
            return content.FightTime;
        }
    }
    public bool PartnerDead//小伙伴是不是已经挂了
    {
        //get { return m_isPartnerDead; }
        get 
        {
            for (int i = 0, len = m_PartnerList.Count; i < len; i++)
            {
                if (!m_PartnerList[i].Dead)
                    return false;                
            }

            
            return true;
        }
        //set { m_isPartnerDead = value; }
        set 
        {
            if (null != ActivePartner)
            {
                ActivePartner.Dead = value;
            }            
        }
    }
    public bool AvatarDead//主角是不是已经挂了
    {
        get { return m_isAvatarDead; }
        set 
        { 
            m_isAvatarDead = value; 
            if (value)
            {
                m_avatarLifePercent = 0f;
            }
        }
    }
    public float PartnerLifePercent//小伙伴生命值百分比
    {
        //get { return m_partnerLifePercent; }
        //set { m_partnerLifePercent = value; }
        get
        {
            if (!HasPartner)
                return 0f;

            if ( null == ActivePartner )
                return 1.0f;

            return ActivePartner.LifePercent;
        }
        set
        {
            if (null != ActivePartner)
            {
                ActivePartner.LifePercent = value;
            }
        }
    }
    public float AvatarLifePercent//主角生命值百分比
    {
        get { return m_avatarLifePercent; }
        set { m_avatarLifePercent = value; }
    }
    public ePartnerState PartnerState//小伙伴当前状态
    {
        get
        {
            if (m_partnerFSM.CurrentState != null && m_partnerFSM.CurrentState is ePartnerState)
            {
                return (ePartnerState)m_partnerFSM.CurrentState;
            }
            else
            {
                return ePartnerState.None;
            }
        }
    }

    public event EntryAction PartnerEnterStateEvent
    {
        add
        {
            m_partnerFSM.EnterStateEvent += value;
        }
        remove
        {
            m_partnerFSM.EnterStateEvent -= value;
        }
    }

    public event FSMEventHandler PartnerFSMEvent
    {
        add
        {
            m_partnerFSM.FSMEvent += value;
        }
        remove
        {
            m_partnerFSM.FSMEvent -= value;
        }
    }

    //职业类型(小伙伴/主角)
    public eJobType JobType
    {
        get
        {
            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar))
            {
                if (null == m_pPlayerLoader)
                {
                    return eJobType.Error;
                }
                return (eJobType)Common.GetJobType(m_pPlayerLoader);
            }
            else if (m_partnerFSM.CurrentState.Equals(ePartnerState.Partner))
            {
                PartenrContent partnerLoader = ActivePartner.PartnerLoader;
                if ( null == partnerLoader )
                {
                    return eJobType.Error;
                }

                return (eJobType)partnerLoader.JobIndex;                
            }
       
            return eJobType.Error;
        }
    }

    public ePlayerSex Sex
    {
        get         
        {
            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar))
            {
                if (null == m_pPlayerLoader)
                {
                    return ePlayerSex.None;
                }
                return GetPlayerSex(m_pPlayerLoader);
            }
            else if (m_partnerFSM.CurrentState.Equals(ePartnerState.Partner))
            {
                PartenrContent partnerLoader = ActivePartner.PartnerLoader;
                if (null == partnerLoader)
                {
                    return ePlayerSex.None;
                }
                return (ePlayerSex)partnerLoader.ModelLoader.PlayerSex;        
            }

            return ePlayerSex.None;                
        }
    }


    public ePlayerSex GetPlayerSex(PlayerContent loader)
    {
        eJobType jobType = (eJobType)Common.GetJobType(loader);

        if (jobType == eJobType.Assassin || jobType == eJobType.Wizard)
        {
            return ePlayerSex.Female;
        }
        else
        {
            return ePlayerSex.Man;
        }
    }


//     public override bool CanBeAttract 
//     {
//         get { return false; } 
//     }

    private float m_fAddMpSpeed = 4.0f;
    public float AddMpSpeed
    {
        get { return m_fAddMpSpeed;}
    }

    //是否可骑乘
    public bool CanRiding
    {
        get
        {
            if (null == m_pBattleScene)
            {
                return false;
            }

            if ((this is Avatar) && (m_pBattleScene.IsGameOver() || m_bPausedCheck || m_bPausedMove || m_bInPlatform))
            {
                //MyLog.LogError("m_pBattleScene.IsGameOver() = " + m_pBattleScene.IsGameOver());
                //MyLog.LogError("m_bPausedCheck = " + m_bPausedCheck);
                //MyLog.LogError("m_bPausedMove ==" + m_bPausedMove);
                //MyLog.LogError("m_bInPlatform = " + m_bInPlatform);
                return false;
            }

            if (IsDead())
            {
                return false;
            }

            if (!m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar))
            {
                //MyLog.LogError("BeginRide not in avatar");
                return false;//如果当前不是在主角状态则不能骑乘
            }

            if (m_rideState != eRideState.None || m_bUseRide)
            {
                //MyLog.LogError("BeginRide m_rideState != eRideState.None");
                return false;
            }

            if (m_flyState != eFlyState.None)
            {
                return false;
            }

            if (IsStun() || IsFrost())
            {
                return false;
            }

            eActionState state = GetCurrActState();
            if (state == eActionState.Idle ||
                state == eActionState.Walk ||
                state == eActionState.Run ||
                state == eActionState.Attack ||
                state == eActionState.Behit)
            {
                return true;
            }


            return false;
        }
    }

    //是否可飞行
    public bool CanFly
    {
        get
        {
            if ((this is Avatar) && (m_pBattleScene.IsGameOver() || m_bPausedCheck || m_bPausedMove || m_bInPlatform))
            {
                //MyLog.LogError("m_pBattleScene.IsGameOver() = " + m_pBattleScene.IsGameOver());
                //MyLog.LogError("m_bPausedCheck = " + m_bPausedCheck);
                //MyLog.LogError("m_bPausedMove ==" + m_bPausedMove);
                //MyLog.LogError("m_bInPlatform = " + m_bInPlatform);
                return false;
            }


            if (IsDead())
            {
                return false;
            }


            if (!m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar))
            {
                //MyLog.LogError("BeginFly not in avatar");
                return false;//如果当前不是在主角状态则不能飞行
            }

            if (m_flyState != eFlyState.None || m_bUseFly)
            {
                //MyLog.LogError("BeginFly error:" + m_flyState);
                return false;
            }

            if (m_rideState != eRideState.None)
            {
                return false;
            }

            if (m_myPet == null)
            {
                return false;
            }

            if (!m_myPet.IsValid)
            {
                return false;
            }

            if (IsStun() || IsFrost())
            {
                return false;
            }

            eActionState state = GetCurrActState();
            if (state == eActionState.Idle ||
                state == eActionState.Walk ||
                state == eActionState.Run ||
                state == eActionState.Attack ||
                state == eActionState.Behit)
            {
                return true;
            }


            return false;
        }
    }

    public PlayerConfigContent GetConfigLoader()
    {
        return m_pConfigLoader;
    }

    private void InitMpAddSpeed() 
    {
        m_fAddMpSpeed = DEFINE.BASE_ADDMP_SPEED * 2f;

        List<sBattleInfo> pveInfoList =  BattlePveManager.GetInst().GetBattleInfoList();
        if ( null != pveInfoList )
        {
            if (pveInfoList.Count < 20)
            {
                m_fAddMpSpeed -= pveInfoList.Count * DEFINE.BASE_ADDMP_SPEED * 0.05f;
            }
            else
            {
                m_fAddMpSpeed = DEFINE.BASE_ADDMP_SPEED;
            }            
        }

        //MyLog.LogError(" InitMpAddSpeed : " + m_fAddMpSpeed);
    }

    public virtual void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.UNTAGGED_OBJECT_TAG)
    {        
        m_nLayer = layer;
        m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(npcTypeID);
        if (m_pPlayerLoader == null)
        {
            MyLog.LogError("can't find Player:" + npcTypeID + " in player.txt");
            return;
        }

        InitMpAddSpeed();

        m_npcGroup = group;
      
        //m_DefaultSkill = new CSkill(m_pPlayerLoader.GetNormalSkill(), 0);

        m_pOriginCard = playerAttr;
        m_pCard = playerAttr;

        //m_nHp = playerAttr.nMaxHp;
        m_nMp = m_nMaxMp;

        m_pMpTimer.SetTimer(1.0f / m_fAddMpSpeed);

        m_NextPosition = Vector3.zero;

        m_unitsType = eNpcUnitsType.Ground;// 默认地面部队

        //MoveSpeed = m_pPlayerLoader.GetMoveSpeed();

        //初始化小伙伴数据
        //m_partnerId = partnerId;
        //m_partnerInfo = partnerInfo;

        //m_pPatnerCard = m_pPatnerCard.Decode();

        m_switchCDTimer.SetTimer(0);
        //m_isPartnerDead = false;
        //m_isAvatarDead = false;
        m_bInPlatform = false;
        m_activePartner = null;
        m_inActivePartner = null;
    

        //m_partnerLifePercent = 1.0f;

        base.Init(battlescene, index, npcTypeID, m_wLevel, sort, position, rotation, tag);

        m_pConfigLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pPlayerLoader.Key);

        InitMountPassive();
        InitPetPassive();

        //坐骑
        if (battlescene.BattleType != eBattleType.Wasteland && 
            battlescene.BattleType != eBattleType.Mining ) //末日荒野、挖矿通过消息同步
        {
            m_bUseRide = false;
            m_bUseFly = false;
        }
         
        m_secondTimer = new Timer();
        m_secondTimer.SetTimer(1);

        m_rideState = eRideState.None;
        m_flyState = eFlyState.None;
        //宠物合体
        if (m_tempCameraAncher == null)
        {
            m_tempCameraAncher = new GameObject();
            GameObject.DontDestroyOnLoad(m_tempCameraAncher);
        }

    }

    public override eCommandReply DoUseSkillEvent(UseSkillCommandArg arg)
    {
        eCommandReply replay = base.DoUseSkillEvent(arg);

        SkillContent pSkillInfo = HolderManager.m_SkillHolder.GetStaticInfo(arg.uSkillid);
        if (null != pSkillInfo && null != m_pAtkDragon)
        {
            if (pSkillInfo.SkillType == (byte)eSkillType.AttackType)
            {
                //m_pDragonshard.TriggerEvent(eTriggerType.attack);
            }
        }

        return replay;
    }


    public override bool HitResult(SkillContent pSkillInfo, CBaseNpc pTarget, bool beHitMute = false)
    {
        bool hitResult = base.HitResult(pSkillInfo, pTarget, beHitMute);

        //触发攻击龙晶效果
        if (hitResult)
        {         
            //伙伴攻击龙晶
            if (null != ActivePartner && ActivePartner.Active && null != ActivePartner.Dragonshard)
            {
                ActivePartner.Dragonshard.TriggerEvent(eTriggerType.attack);
            }
            else if (null != m_pAtkDragon && m_pAtkDragon.Active)
            {
                m_pAtkDragon.TriggerEvent(eTriggerType.attack);
            }
        }                

        return hitResult;
    }

    public override void BeHit(uint uiDefenceActionID, CBaseNpc pAttacker, SkillContent pSkillLoader, bool behitMute = false)
    {
        base.BeHit(uiDefenceActionID, pAttacker, pSkillLoader, behitMute);

        //触发防御龙晶效果
        //伙伴龙晶
        if (null != ActivePartner && ActivePartner.Active)
        {
            if (null != ActivePartner.Dragonshard)
            {
                ActivePartner.Dragonshard.TriggerEvent(eTriggerType.defence);
            }            
        }
        //主角防御龙晶
        else if (null != m_pDefDragon && m_pDefDragon.Active)
        {
            m_pDefDragon.TriggerEvent(eTriggerType.defence);
        }
    }

    private void InitMountPassive() 
    {
        m_uiMountID = 0;
        //不同情况下坐骑ID不一样
        if (this is Avatar)
        {
            m_uiMountID = MountManager.GetInst().CurMountID;
        }
        else if (this is EnemyAvatar)
        {
            switch (CurrBattleScene.BattleType)
            {
                case eBattleType.Arena:
                    {
                        m_uiMountID = ArenaManager.GetInst().mountID;
                    }
                    break;
                case eBattleType.Wasteland:
                    {
                        MoorManager.stEnemyData pEnemyDataInfo = MoorManager.GetInst().StEnemyDataInfo;
                        m_uiMountID = (uint)pEnemyDataInfo.MatherInfo.uiMountId;
                    }
                    break;
                case eBattleType.Mining:
                    {
                        m_uiMountID = 13000101;// 服务端没同步,暂时写死
                    }
                    break;       
            }
        }
        else if (this is OnlineAvatar)
        {
            OnlineAvatar pvpPlayer = PvpManager.GetInst().GetEnemyPlayer((this as OnlineAvatar).BattleInfo.playerInfo.uiPlayerID);
            if (null != pvpPlayer)
            {
                m_uiMountID = (uint)pvpPlayer.BattleInfo.playerInfo.uiMountId;
            }
        }
        

        m_pMountLoader = HolderManager.m_MountsHolder.GetStaticInfo(m_uiMountID);
        if (null != m_pMountLoader)
        {
            List<int> skillList = m_pMountLoader.ModelLoader.MountsSkill;
            for (int i = 0, count = skillList.Count; i < count; ++i)
            {
                //遍历被动技能
                uint skillID = (uint)skillList[i];
                if (skillID < 10000000 && skillID != 0)//被动技能
                {
                    // skillupid
                    SkillUpContent skillupContent = HolderManager.m_SkillUpHolder.GetStaticInfo(skillID);
                    if (null != skillupContent)
                    {
                        TechContent techContent = HolderManager.m_TechHolder.GetStaticInfo(skillupContent.SkillId);
                        if (null != techContent)
                        {
                            m_fRepressCritbyMount = techContent.RepressCrit[1] / 10000f;                            
                        }
                    }

                    break;
                }
            }
        }      
    }

    private void InitPetPassive() 
    {
        uint petID = PetID;

        PetContent petContent = HolderManager.m_PetHolder.GetStaticInfo(petID);
        if (null != petContent)
        {
            List<int> skillList = petContent.ModelLoader.PetSkills;
            for ( int i = 0, len = skillList.Count; i < len; i++)
            {
                if (skillList[i] > 100000) //被动技能
                {
                    // skillupid
                    SkillUpContent skillupContent = HolderManager.m_SkillUpHolder.GetStaticInfo(skillList[i]);
                    if (null != skillupContent)
                    {
                        TechContent techContent = HolderManager.m_TechHolder.GetStaticInfo(skillupContent.SkillId);
                        if (null != techContent)
                        {
                            m_fRepressCritbyMount = techContent.RepressCrit[1] / 10000f;
                        }
                    }
                    break;
                }                
            }
        }
    }

    protected void InitFSM()
    {
        //初始化小伙伴状态
        m_partnerFSM.AddInit(fsmInit);

        m_partnerFSM.AddEntry(ePartnerState.Avatar, avatarEntry);
        m_partnerFSM.AddUpdate(ePartnerState.Avatar, avatarUpdate);
        m_partnerFSM.AddExit(ePartnerState.Avatar, avatarExit);


        m_partnerFSM.AddEntry(ePartnerState.SwitchingToPartner, switchingToPartnerEntry);
        m_partnerFSM.AddUpdate(ePartnerState.SwitchingToPartner, switchingToPartnerUpdate);
        m_partnerFSM.AddExit(ePartnerState.SwitchingToPartner, switchingToPartnerExit);

        m_partnerFSM.AddEntry(ePartnerState.Partner, partnerEntry);
        m_partnerFSM.AddUpdate(ePartnerState.Partner, partnerUpdate);
        m_partnerFSM.AddExit(ePartnerState.Partner, partnerExit);

        m_partnerFSM.AddEntry(ePartnerState.SwitchingToAvatar, switchingToAvatarEntry);
        m_partnerFSM.AddUpdate(ePartnerState.SwitchingToAvatar, switchingToAvatarUpdate);
        m_partnerFSM.AddExit(ePartnerState.SwitchingToAvatar, switchingToAvatarExit);

        m_partnerFSM.AddTransistion(ePartnerState.Avatar, ePartnerEvent.Switch, ePartnerState.SwitchingToPartner, trans_Avatar_SwitchAnother_SwitchingToPartner);
        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.SwitchAnother, ePartnerState.SwitchingToPartner, trans_Partner_SwitchAnother_SwitchingToPartner);

        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.PartnerDeadSwitch, ePartnerState.SwitchingToPartner, trans_Partner_PartnerDeadSwitch_SwitchingToPartner);

        m_partnerFSM.AddTransistion(ePartnerState.SwitchingToPartner, ePartnerEvent.SwitchCompleted, ePartnerState.Partner, null);
        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.Switch, ePartnerState.SwitchingToAvatar, trans_Partner_SwitchAnother_SwitchingToAvatar);

        m_partnerFSM.AddTransistion(ePartnerState.SwitchingToAvatar, ePartnerEvent.SwitchCompleted, ePartnerState.Avatar, null);

        //m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.FightTimeOut, ePartnerState.SwitchingToAvatar, null);
        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.PartnerDie, ePartnerState.SwitchingToAvatar, trans_Partner_PartnerDie_SwitchingToAvatar);
        m_partnerFSM.AddTransistion(ePartnerState.Avatar, ePartnerEvent.AvatarDie, ePartnerState.SwitchingToPartner, trans_Avatar_AvatarDie_SwitchingToPartner);

        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.Resurrect, ePartnerState.Avatar, trans_Resurrect);
        m_partnerFSM.AddTransistion(ePartnerState.Avatar, ePartnerEvent.Resurrect, ePartnerState.Avatar, trans_Resurrect);

        m_partnerFSM.AddTransistion(ePartnerState.Avatar, ePartnerEvent.SwitchImmediately, ePartnerState.Partner, trans_Aavatar_SwitchImmediately_Partner);
        m_partnerFSM.AddTransistion(ePartnerState.Partner, ePartnerEvent.SwitchImmediately, ePartnerState.Avatar, trans_Partner_SwitchImmediately_Aavatar);


        ePartnerState parterState = m_bTwoPartners || m_isAvatarDead ? ePartnerState.Partner : ePartnerState.Avatar;

        m_partnerFSM.Init(parterState);
    }

    public override bool IsDead()
    {
        return m_nHp <= 0 && m_isAvatarDead && PartnerDead;
    }

    public virtual void BindPet(Pet pet)
    {
        this.MyPet = pet;
        pet.MyMaster = this;
        
    }

    #region 小伙伴相关

    //private void CameraFollow(GameObject gobj)
    //{
    //    SceneContent sceneLoader = m_pBattleScene.GetSceneLoader();
    //    if (sceneLoader != null)
    //    {
    //        //CCamera.GetInst().SetCameraEffect(sceneLoader.GetCameraID(), null, new object[] { gobj });

    //        uint mapinfoID = sceneLoader.GetMapInfo();
    //        SceneInfoContent info = HolderManager.m_SceneInfoHolder.GetStaticInfo(mapinfoID);
    //        if (info != null)
    //        {
    //            CCamera.GetInst().SetCameraEffect(info.GetCameraID(), null, new object[] { gobj });
    //        }
    //        else
    //        {
    //            MyLog.LogError("The game has not cameraID");
    //        }
    //    }
    //}

    private void fsmInit(System.Enum stateToInit)
    {

    }

    private void avatarEntry(System.Enum stateToEnter)
    {
        //还原技能面板
        List<CInitiativeSkill> avatarSkillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("avatarSkillList");
        if (avatarSkillList != null)
        {
            m_skillList = avatarSkillList;
        }

        if (m_partnerFSM.ExistParam("avatarDefaultSkill"))
        {
            DefaultSkillID = m_partnerFSM.GetParam<uint>("avatarDefaultSkill");
        }

        CountAttackRange();//重算攻击距离


        //还原属性
        if (m_partnerFSM.ExistParam("avatarCard"))
        {
            m_pOriginCard = m_partnerFSM.GetParam<stCharacterCard>("avatarCard");
            m_pCard = m_pOriginCard;
        }

        //恢复体形大小
        if ( m_myTrans )
        {
            m_myTrans.localScale = Vector3.one * ModelSize; 
            
            SetPvpStepParticle(m_myTrans);

            if ( this is Avatar)
            {
                CMusicManager.GetInst().FollowObj = m_myTrans.gameObject;
            }            
        }

        m_nHp = (int)(m_avatarLifePercent * (float)m_pOriginCard.nMaxHp);

        UpdateCharacterCard();

        //还原血量
        if (m_partnerFSM.ExistParam("avatarHp"))
        {
            //m_nHp = m_partnerFSM.GetParam<int>("avatarHp");
        }

        //if (Courageous)
        //{
        //    AddBuff(DEFINE.AVATAR_RIDE_BATI_BUFF_ID);
        //}

        //显示血条
        RrefeshHPComponent();

        if (null != m_pAtkDragon)
        {
            m_pAtkDragon.Active = true;
        }
        if (null != m_pDefDragon)
        {
            m_pDefDragon.Active = true;
        }  
    }

    private void avatarUpdate(System.Enum stateToUpdate)
    {
        //if (!m_isPartnerDead && m_pPartnerLoader != null)
        //{
        //    float lifeGen = Time.deltaTime * m_pPartnerLoader.hpRegenRate / 10000.0f;
        //    m_partnerLifePercent = Mathf.Clamp01(m_partnerLifePercent + lifeGen);
        //}

        if (m_isAvatarDead)
        {
            m_avatarLifePercent = 0f;
        }
        else
        {
            m_avatarLifePercent = CharacterCard.nMaxHp != 0 ? Mathf.Clamp01((float)m_nHp / (float)CharacterCard.nMaxHp) : 0f;
        }

        if (m_pBattleScene.IsGameOver())
        {
            return;
        }

        if (null != ActivePartner && !ActivePartner.Dead && ActivePartner.PartnerLoader != null)
        {
            float lifeGen = Time.deltaTime * ActivePartner.PartnerLoader.ModelLoader.HpRegenRate / 10000.0f;
            ActivePartner.LifePercent = Mathf.Clamp01(ActivePartner.LifePercent + lifeGen);
        }

    }

    private void avatarExit(System.Enum stateToLeave)
    {
        //储存角色技能并清空技能面板
        List<CInitiativeSkill> avatarSkillList = new List<CInitiativeSkill>();

        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            avatarSkillList.Add(m_skillList[i]);
        }
        m_partnerFSM.StoreParam<List<CInitiativeSkill>>("avatarSkillList", avatarSkillList);
        m_partnerFSM.StoreParam<uint>("avatarDefaultSkill", DefaultSkillID);
        m_partnerFSM.StoreParam<stCharacterCard>("avatarCard", m_pOriginCard);
        m_partnerFSM.StoreParam<int>("avatarHp", m_nHp);

        m_skillList.Clear();

        DefaultSkillID = 0;
         
        ClearAllBuff();
        ClearAllAura();

        //隐藏血条
        HpComponentEnable(false);
    }

    public override void SetAlphaVertexColorOff(float time)
    {
        m_liveState = eLiveState.Fade;
        m_alphaVertexSpeed = time <= 0 ? Mathf.Epsilon : time;
        m_alphaVertexSpeed = 1f / m_alphaVertexSpeed;
        SetFootEffect(false);

        HpComponentEnable(false);

        ChangeShaderToAlphaVertex(1);
        GetMaterialsList();
    }
    public override void SetAlphaVertexColorOn(float time)
    {
        m_liveState = eLiveState.Grow;
        m_alphaVertexSpeed = time <= 0 ? Mathf.Epsilon : time;
        m_alphaVertexSpeed = 1f / m_alphaVertexSpeed;

        GetMaterialsList();

        SetFootEffect(true);
        //HpComponentEnable(true);
    }


    protected virtual void ChangeShaderToAlphaVertex(float alpha)
    {
        for (int i = 0; i < m_materiaslCount; ++i)
        {
            if (Materials[i] != null)
            {
                Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
                Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
            }
        }

        if (m_materialLeft != null)
        {
            m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_materialLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }
        if (m_materialRight != null)
        {
            m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_materialRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }

        if (m_mountMat != null)
        {
            m_mountMat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_mountMat.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }

//         if (m_materialPartner)
//         {
//             m_materialPartner.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
//             m_materialPartner.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
//         }

//         if (m_materialPartnerLeft)
//         {
//             m_materialPartnerLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
//             m_materialPartnerLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
//         }
// 
//         if (m_materialPartnerRight)
//         {
//             m_materialPartnerRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
//             m_materialPartnerRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
//         }
        m_currShaderName = DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF;
    }

    private void switchingToPartnerEntry(System.Enum stateToEnter)
    {
        //进入一种状态
        m_stateMgr.ClearLastActList();
        EnterState(eActionState.SwitchPartner);

        ActivePartner.Enabled = true;

        //将角色模型换成小伙伴
        ChangeModel(ActivePartner.Object, ActivePartner.CAnimator);


        //忽略主角和小伙伴碰撞
        //m_partnerObj.gameCObject.SetActive(true);
        CharacterController newbie_cc = ActivePartner.Go.GetComponent<CharacterController>();

        if (NpcSort == eNpcSort.Avatar || NpcSort == eNpcSort.FriendlyAvatar)
        {
            ActivePartner.Go.tag = DEFINE.UNTAGGED_OBJECT_TAG;
            m_avatarObj.gameCObject.tag = DEFINE.UNTAGGED_OBJECT_TAG;
            m_pPlatformReceiver = AddPlatformReceiveMessage(ActivePartner.Go);
        }

        //将武器换成小伙伴的武器
        //ChangeWeapon(m_pPartnerLoader.weaponID);
//         m_pLeftWeaponObject = m_partnerLeftWeapon;
//         m_materialLeft = m_partnerLeftWeapon != null ? m_partnerLeftWeapon.transform.renderer.material : null;
//         m_pRightWeaponObject = m_partnerRightWeapon;
//         m_materialRight = m_partnerRightWeapon != null ? m_partnerRightWeapon.transform.renderer.material : null;

        m_pLeftWeaponObject = ActivePartner.LeftWeapon;
        m_materialLeft = ActivePartner.LeftMat;
        m_pRightWeaponObject = ActivePartner.RightWeapon;
        m_materialRight = ActivePartner.RightMat;

        //宠物状态改变
        if (m_myPet != null)
        {
            m_myPet.Refresh();
        }

        //清除所有BUFF，再加个无敌BUFF
        ClearAllBuff();
        ClearAllAura();
        AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        Transform preTrans = m_bTwoPartners ? m_inActivePartner.Trans : m_avatarObj.transform; //之前的trans

        //准备跳进跳出点

        //设置一下位置
         Vector3 anchorPos = m_pBattleScene.SummonPosition(preTrans.position, newbie_cc.radius, false, this, newbie_cc,1,true);
         m_tempCameraAncher.transform.position = anchorPos;

         //预先预订位置,忽略和自身的碰撞
         CharacterController replaceModelController = ReplaceModelController;
         replaceModelController.slopeLimit = newbie_cc.slopeLimit;
         replaceModelController.stepOffset = newbie_cc.stepOffset;
         replaceModelController.center = newbie_cc.center;
         replaceModelController.radius = newbie_cc.radius;
         replaceModelController.height = newbie_cc.height;
         ReplaceModelPauseOtherMove(true);
         replaceModelController.gameObject.transform.position = anchorPos;
         replaceModelController.gameObject.transform.rotation = preTrans.rotation;
         CharacterController avatarController = m_avatarObj.gameCObject.GetComponent<CharacterController>();
         if (avatarController == null)
         {
             avatarController = m_avatarObj.gameCObject.GetComponent<CharacterController>();
         }
         avatarController.enabled = false;
         newbie_cc.enabled = false;

        if (m_bTwoPartners)
        {
            m_inActivePartner.PlayAction("jump", 2.0f);
        }
        else
        {
            m_avatarAnimator.PlayAction("jump", 2.0f);
        }

        
        //准备跳进跳出点
//         Vector3 anchorPos = m_avatarObj.transform.position;
//         m_tempCameraAncher.transform.position = anchorPos;

        Vector3 outDirection = Vector3.right;
        if (CCamera.GetInst().GetCameraObj() != null)
        {
            Vector3 cright = CCamera.GetInst().GetCameraObj().transform.right;
            outDirection = (new Vector3(cright.x, 0.0f, cright.z)).normalized;
        }        
        Vector3 inOrigin = anchorPos - outDirection * m_jumpRadius;               
     
        m_partnerFSM.StoreParam<Vector3>("anchorPos", anchorPos);

        //准备好跳进跳出的位置、方向和动作
//         if (!m_isAvatarDead)
//         {
//             m_avatarObj.transform.forward = outDirection;
//             m_avatarObj.transform.position = anchorPos;
//             m_avatarAnimator.PlayAction("jump", 2.0f, true,null,0f);            
//         }
//         else
//         {
//             m_avatarAnimator.PlayAction(stStateData.GetActionName(eActionState.Dead));
//         }

        if (m_bTwoPartners && m_inActivePartner.Dead)
        {
            m_inActivePartner.PlayAction(stStateData.GetActionName(eActionState.Dead));
        }
        else if (m_isAvatarDead)
        {
            m_avatarAnimator.PlayAction(stStateData.GetActionName(eActionState.Dead));
        }
        
        preTrans.forward = outDirection;
        preTrans.position = anchorPos;

        
        //m_partnerObj.transform.forward = outDirection;
        //m_partnerObj.transform.position = inOrigin;
        //m_partnerAnimator.PlayAction("jump", 1.0f, true,null,0f);
        //m_partnerAnimator.Speed = 2.0f;
        //ApplyRootMotion = true;

        ActivePartner.Trans.forward = outDirection;
        ActivePartner.Trans.position = inOrigin;
        ActivePartner.PlayAction("jump", 2.0f, true);
        ApplyRootMotion = true;


        //准备计时器
        m_partnerFSM.StoreParam<float>("switchCounter", m_switchTime);
        m_partnerFSM.StoreParam<float>("switchTime", m_switchTime);
        m_partnerFSM.StoreParam<bool>("switchAOE", false);

        //让怪物跟过来
        m_pBattleScene.ReplaceTarget(this, this);
        m_pBattleScene.ReplaceTargetTrans(this, m_tempCameraAncher.transform);
        m_myTrans = m_tempCameraAncher.transform;

        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();
    }

    private void switchingToPartnerUpdate(System.Enum stateToUpdate)
    {
        //你跳来，我跳去
        float counter = m_partnerFSM.GetParam<float>("switchCounter");
        float time = m_partnerFSM.GetParam<float>("switchTime");

        counter -= Time.deltaTime;

        if (counter > 0.0f)
        {
            float amount = Mathf.Clamp01(1.0f - counter / time);

            if (amount >= 0.7 && !m_partnerFSM.GetParam<bool>("switchAOE"))
            {
                m_partnerFSM.StoreParam<bool>("switchAOE", true);
                //释放一个AOE
                this.Command(eCommandType.UseSkill, new UseSkillCommandArg(DEFINE.PARTNER_ENTER_SKILL, m_targetList, true));
            }
        }
        else
        {
            m_partnerFSM.TriggerEventQueued(ePartnerEvent.SwitchCompleted);
        }

        m_partnerFSM.StoreParam<float>("switchCounter", counter);

        if (m_bTwoPartners)
        {
            m_inActivePartner.CAnimator.Update();
        }
        else
        {
            //让主角跑出去
            if (m_avatarAnimator != null)
            {
                m_avatarAnimator.Update();
            }
        }

        Vector3 position = ActivePartner.Trans.position;
        CharacterController replaceModelController = ReplaceModelController;
        ActivePartner.Trans.position = new Vector3(position.x, replaceModelController.transform.position.y, position.z);
        m_avatarObj.transform.position = new Vector3(m_avatarObj.transform.position.x, replaceModelController.transform.position.y, m_avatarObj.transform.position.z);


    }

    private void switchingToPartnerExit(System.Enum stateToLeave)
    {
        if (null == ActivePartner)
        {
            return;
        }
        //隐藏主角
        if (m_bTwoPartners)
        {
            m_inActivePartner.Enabled = false;
        }
        else
        {
            m_avatarObj.gameCObject.SetActive(false);
        }        

        //m_avatarController.enabled = false;

        //设回自己的transform
        //m_myTrans = m_partnerObj.transform;
        m_myTrans = ActivePartner.Trans;
        m_pBattleScene.ReplaceTargetTrans(this, this.GetTransform());

        m_myTrans.gameObject.tag = DEFINE.AVATAR_OBJECT_TAG;

        //去掉无敌BUFF
        DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        
        //离开一种状态
        LeaveState(eActionState.SwitchPartner);

        GameObject preGo = m_bTwoPartners ? m_inActivePartner.Go : m_avatarObj.gameCObject;

        //替代碰撞的碰撞关闭
        CharacterController replaceModelController = ReplaceModelController;
        ReplaceModelPauseOtherMove(false);
        CharacterController partnerController = ActivePartner.Trans.GetComponent<CharacterController>();
        partnerController.enabled = true;

        m_myTrans.position = replaceModelController.transform.position;


        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();

        //重置切换CD
        m_switchCDTimer.SetTimer(PartnerSwitchCD);
    }

    private void partnerEntry(System.Enum stateToEnter)
    {

//         if (null == ActivePartner)
//         {
//             return;
//         }

        //加载小伙伴技能面板
//         List<CInitiativeSkill> partnerSkillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("partnerSkillList");
//         if (partnerSkillList != null)
//         {
//             m_skillList = partnerSkillList;
//         }

        m_skillList.Clear();

        if (null != ActivePartner)
        {
            if (null != ActivePartner.SkillList)
            {
                for (int i = 0, len = ActivePartner.SkillList.Count; i < len; i++)
                {
                    m_skillList.Add(ActivePartner.SkillList[i]);
                }  
            }
            DefaultSkillID = ActivePartner.DeafaultSkill;
            m_uiCurrUseSkillType = ActivePartner.DeafaultSkill; 
        }
              

//         if (m_partnerFSM.ExistParam("partnerDefaultSkill"))
//         {
//             DefaultSkillID = m_partnerFSM.GetParam<uint>("partnerDefaultSkill");
//         }

        

        CountAttackRange();//重算攻击距离



        //加载小伙伴属性
        if (null != ActivePartner)
        {
            m_pOriginCard = ActivePartner.Card;
            m_pCard = m_pOriginCard;
        }
        
        //if (m_pPartnerLoader != null)
        //{
        //    if (m_partnerFSM.ExistParam("avatarCard"))
        //    {
        //        stCharacterCard partnerCard = m_partnerFSM.GetParam<stCharacterCard>("avatarCard");
        //        partnerCard.nAttack = (int)((float)partnerCard.nAttack * m_pPartnerLoader.attack[(int)m_partnerInfo.info.uiPartnerStar - 1] / 10000f);
        //        partnerCard.nDefence = (int)((float)partnerCard.nDefence * m_pPartnerLoader.defense[(int)m_partnerInfo.info.uiPartnerStar - 1] / 10000f);
        //        partnerCard.nMaxHp = (int)((float)partnerCard.nMaxHp * m_pPartnerLoader.hp[(int)m_partnerInfo.info.uiPartnerStar - 1] / 10000f);

        //        m_pOriginCard = partnerCard;
        //    }
        //}

        //恢复体形大小
        //恢复体形大小
        if (m_myTrans)
        {
            m_myTrans.localScale = Vector3.one * ModelSize; 
            
            SetPvpStepParticle(m_myTrans);
            if (this is Avatar)
            {
                CMusicManager.GetInst().FollowObj = m_myTrans.gameObject;   
            }            
        }
        if (null != ActivePartner)
        {
            m_nHp = (int)(ActivePartner.LifePercent * (float)m_pOriginCard.nMaxHp);
        }
        else
        {
            m_nHp = 0;
        }

        if (m_pBattleScene.BattleType == eBattleType.Arena) //这里处理竞技场中途会加的buff,小伙伴初始化时候没加上,所以在这里同步,而且只会同步一次
        {
            CBuff pEnhanceBuff = m_buffMgr.FindBuff(DEFINE.ARENA_ENHANCE_BUFF);
            if (null != pEnhanceBuff)
            {
                if (pEnhanceBuff.Amount > 1)
                    pEnhanceBuff.Amount--;

                AddBuff(DEFINE.ARENA_ENHANCE_BUFF, null, true);
            }
            
            CBuff pImmoBuff = m_buffMgr.FindBuff(DEFINE.ARENA_IMMORTALIZATION_BUFF);
            if (null != pImmoBuff)
            {
                if (pImmoBuff.Amount > 1)                
                    pImmoBuff.Amount--;

                AddBuff(DEFINE.ARENA_IMMORTALIZATION_BUFF, null, true);
            }
        }
        else
        {
            UpdateCharacterCard();
        }        

        //读取之前保存的血量数据
        if (m_partnerFSM.ExistParam("partnerHp"))
        {
            //m_nHp = m_partnerFSM.GetParam<int>("partnerHp");
        }

        //显示血条
        RrefeshHPComponent();

        if ( null != m_pAtkDragon )
        {
            m_pAtkDragon.Active = false;
        }
        if ( null != m_pDefDragon )
        {
            m_pDefDragon.Active = false;
        }

    }




    private void partnerUpdate(System.Enum stateToUpdate)
    {
        if (ActivePartner.Dead)
        {
            ActivePartner.LifePercent = 0f;
        }
        else
        {
            ActivePartner.LifePercent = CharacterCard.nMaxHp != 0 ? Mathf.Clamp01((float)m_nHp / (float)CharacterCard.nMaxHp) : 0f;
        }

        if (m_pBattleScene.IsGameOver())
        {
            return;
        }        

        if (!m_isAvatarDead)
        {
            float lifeGen = Time.deltaTime * ActivePartner.PartnerLoader.ModelLoader.HpRegenRate / 10000.0f;
            m_avatarLifePercent = Mathf.Clamp01(m_avatarLifePercent + lifeGen);
        }
        else if (m_bTwoPartners && !m_inActivePartner.Dead && null != m_inActivePartner.PartnerLoader)
        {
            float lifeGen = Time.deltaTime * InActivePartner.PartnerLoader.ModelLoader.HpRegenRate / 10000.0f;
            InActivePartner.LifePercent = Mathf.Clamp01(InActivePartner.LifePercent + lifeGen);
        }

        //if (m_isPartnerDead)
        //{
        //    m_partnerLifePercent = 0f;
        //}
        //else
        //{
        //    m_partnerLifePercent = CharacterCard.nMaxHp != 0 ? Mathf.Clamp01((float)m_nHp / (float)CharacterCard.nMaxHp) : 0f;
        //}
    }

    private void partnerExit(System.Enum stateToLeave)
    {
        //储存伙伴技能并清空技能面板
        //List<CInitiativeSkill> partnerSkillList = new List<CInitiativeSkill>();

        //for (int i = 0, count = m_skillList.Count; i < count; ++i)
        //{
        //    partnerSkillList.Add(m_skillList[i]);
        //}
        //m_partnerFSM.StoreParam<List<CInitiativeSkill>>("partnerSkillList", partnerSkillList);
        //m_partnerFSM.StoreParam<uint>("partnerDefaultSkill", DefaultSkillID);
        //m_partnerFSM.StoreParam<stCharacterCard>("partnerCard", m_pOriginCard);
        //m_partnerFSM.StoreParam<int>("partnerHp", m_nHp);

        ClearAllBuff();
        ClearAllAura();

        //清空技能面板
        m_skillList.Clear();

        DefaultSkillID = 0;

        //隐藏血条
        HpComponentEnable(false);
    }

    private void trans_Aavatar_SwitchImmediately_Partner(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        //设置小伙伴模型位置
        //m_partnerObj.gameCObject.SetActive(true);
        //m_partnerObj.transform.position = m_avatarObj.transform.position;

        ActivePartner.Go.SetActive(true);
        ActivePartner.Trans.position = m_avatarObj.transform.position;

        //将角色模型换成小伙伴
        ChangeModel(ActivePartner.Object, ActivePartner.CAnimator);
        //将武器换成小伙伴的武器
        //ChangeWeapon(m_pPartnerLoader.weaponID);
        //m_pLeftWeaponObject = m_partnerLeftWeapon;
        //m_materialLeft = m_partnerLeftWeapon != null ? m_partnerLeftWeapon.transform.renderer.material : null;
        //m_pRightWeaponObject = m_partnerRightWeapon;
        //m_materialRight = m_partnerRightWeapon != null ? m_partnerRightWeapon.transform.renderer.material : null;

        m_pLeftWeaponObject = ActivePartner.LeftWeapon;
        m_materialLeft = ActivePartner.LeftMat;
        m_pRightWeaponObject = ActivePartner.RightWeapon;
        m_materialRight = ActivePartner.RightMat;

        //宠物状态改变
        if (m_myPet != null)
        {
            m_myPet.Refresh();
        }

        //隐藏主角
        m_avatarObj.gameCObject.SetActive(false);
        //m_avatarController.enabled = false;

//         m_avatarAnimator.Speed = 1.0f;
//         m_partnerAnimator.Speed = 1.0f;

        ActivePartner.Trans.gameObject.layer = DEFINE.AVATAR_LAYER;
    }

    private void trans_Partner_SwitchImmediately_Aavatar(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        //设置小伙伴模型位置
        //         m_avatarObj.gameCObject.SetActive(true);
        //         m_avatarObj.transform.position = m_partnerObj.transform.position;
        // 
        //         //将角色模型换成小伙伴
        //         ChangeModel(m_avatarObj, m_avatarAnimator);
        //         //将武器换成小伙伴的武器
        //         m_pLeftWeaponObject = m_avatarLeftWeapon;
        //         m_materialLeft = m_avatarLeftWeapon != null ? m_avatarLeftWeapon.transform.renderer.material : null;
        //         m_pRightWeaponObject = m_avatarRightWeapon;
        //         m_materialRight = m_avatarRightWeapon != null ? m_avatarRightWeapon.transform.renderer.material : null;

        m_avatarObj.gameCObject.SetActive(true);
        m_avatarObj.transform.position = ActivePartner.Trans.position;

        //将角色模型换成小伙伴
        ChangeModel(m_avatarObj, m_avatarAnimator);

        //将武器换成小伙伴的武器
        m_pLeftWeaponObject = m_avatarLeftWeapon;
        m_materialLeft = m_avatarLeftWeapon != null ? m_avatarLeftWeapon.transform.renderer.material : null;
        m_pRightWeaponObject = m_avatarRightWeapon;
        m_materialRight = m_avatarRightWeapon != null ? m_avatarRightWeapon.transform.renderer.material : null;

        //宠物状态改变
        if (m_myPet != null)
        {
            m_myPet.Refresh();
        }

        //隐藏伙伴
        //m_partnerObj.gameCObject.SetActive(false);
        ActivePartner.Enabled = false;
        //m_avatarController.enabled = false;

        //         m_avatarAnimator.Speed = 1.0f;
        //         m_partnerAnimator.Speed = 1.0f;

        m_avatarObj.gameCObject.layer = DEFINE.AVATAR_LAYER;
    }

    private void trans_Partner_PartnerDeadSwitch_SwitchingToPartner(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        //两个伙伴
        if (m_PartnerList[0].Dead)
        {   
            m_inActivePartner = m_PartnerList[0];
            m_activePartner = m_PartnerList[1];
        }
        else if (m_PartnerList[1].Dead)
        {
            m_inActivePartner = m_PartnerList[1];
            m_activePartner = m_PartnerList[0];
        }
        m_activePartner.Active = true;
    }

    //主角->小伙伴
    private void trans_Avatar_SwitchAnother_SwitchingToPartner(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        m_activePartner.Active = true;
    }

    //小伙伴->主角
    private void trans_Partner_SwitchAnother_SwitchingToAvatar(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        m_activePartner.Active = false;
    }
    //伙伴->伙伴
    private void trans_Partner_SwitchAnother_SwitchingToPartner(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue) 
    {
        //两个伙伴
        if (m_PartnerList[0].Active)
        {
            m_inActivePartner = m_PartnerList[0];
            m_activePartner = m_PartnerList[1];
        }
        else if (m_PartnerList[1].Active)
        {
            m_inActivePartner = m_PartnerList[1];
            m_activePartner = m_PartnerList[0];
        }

        m_activePartner.Active = true;
        m_inActivePartner.Active = false;        
    }

    private void trans_Partner_PartnerDie_SwitchingToAvatar(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        //m_isPartnerDead = true;
        ActivePartner.Dead = true;
    }

    private void trans_Avatar_AvatarDie_SwitchingToPartner(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        m_isAvatarDead = true;
        if (!PartnerDead)
        {
            m_activePartner = m_PartnerList[0];
            m_activePartner.Active = true;
        }
    }

    private void trans_Resurrect(System.Enum fromStateValue, System.Enum eventValue, System.Enum toStateValue)
    {
        //复活之后一定变回主角
        if (fromStateValue.Equals(ePartnerState.Partner))
        {
            //启用主角模型
            m_avatarObj.gameCObject.SetActive(true);
            //设置位置
            //m_avatarObj.transform.position = m_partnerObj.transform.position;
            m_avatarObj.transform.position = ActivePartner.Trans.position;
            //将角色模型换成主角
            ChangeModel(m_avatarObj, m_avatarAnimator);
            //将武器换成主角的武器
            m_pLeftWeaponObject = m_avatarLeftWeapon;
            m_materialLeft = m_avatarLeftWeapon != null ? m_avatarLeftWeapon.transform.renderer.material : null;
            m_pRightWeaponObject = m_avatarRightWeapon;
            m_materialRight = m_avatarRightWeapon != null ? m_avatarRightWeapon.transform.renderer.material : null;
            //隐藏小伙伴
            //m_partnerObj.gameCObject.SetActive(false);
            ActivePartner.Enabled = false;
//             m_avatarAnimator.Speed = 1.0f;
//             m_partnerAnimator.Speed = 1.0f;

            //宠物状态改变
            if (m_myPet != null)
            {
                m_myPet.Refresh();
            }

            //让怪物跟过来
            m_pBattleScene.LoseTarget(this);
        }

        for (int i = 0, len = m_PartnerList.Count; i < len; i++ )
        {
            m_PartnerList[i].LifePercent = 0f;
        }
        m_isAvatarDead = false;
    }

    protected override void InitModel(GameObject o)
    {
        base.InitModel(o);


        //玩家使用charactercontroll移动
        m_characterController = o.GetComponent<CharacterController>();
        if (m_characterController != null)
        {
            m_characterController.enabled = true;

            SetCollider(m_characterController);
        }

        //有时会用伙伴代替怪物,这里还原伙伴的碰撞
        CapsuleCollider capCollider = o.GetComponent<CapsuleCollider>();
        if (capCollider != null)
        {
            capCollider.enabled = false;
        }

    }

    private void switchingToAvatarEntry(System.Enum stateToEnter)
    {
        if (m_avatarObj == null)
        {
            MyLog.LogError("switchingToAvatarEntry,m_avatarObj == null");
            return;
        }

        if (m_tempCameraAncher == null)
        {
            MyLog.LogError("switchingToAvatarEntry,m_tempCameraAncher == null");
            return;
        }

        if (m_avatarAnimator == null)
        {
            MyLog.LogError("switchingToAvatarEntry,m_avatarAnimator == null");
            return;
        }

        //进入一种状态
        m_stateMgr.ClearLastActList();
        EnterState(eActionState.SwitchPartner);

        //忽略小伙伴和主角碰撞
        m_avatarObj.gameCObject.SetActive(true);
        

        //将角色模型换成主角
        ChangeModel(m_avatarObj, m_avatarAnimator);

        //将武器换成主角的武器
        //ChangeWeapon(m_uiWeaponID);
        m_pLeftWeaponObject = m_avatarLeftWeapon;
        m_materialLeft = m_avatarLeftWeapon != null && m_avatarLeftWeapon.transform != null ? m_avatarLeftWeapon.transform.renderer.material : null;
        m_pRightWeaponObject = m_avatarRightWeapon;
        m_materialRight = m_avatarRightWeapon != null && m_avatarRightWeapon.transform != null ? m_avatarRightWeapon.transform.renderer.material : null;

        if (NpcSort == eNpcSort.Avatar)
        {
            m_avatarObj.gameCObject.tag = DEFINE.UNTAGGED_OBJECT_TAG;
            ActivePartner.Go.tag = DEFINE.UNTAGGED_OBJECT_TAG;
        }

        //宠物状态改变
        if (m_myPet != null)
        {
            m_myPet.Refresh();
        }

        //清除所有BUFF，再加个无敌BUFF
        ClearAllBuff();
        ClearAllAura();
        AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        //准备跳进跳出点
        CharacterController newbie_cc = m_avatarObj.gameCObject.GetComponent<CharacterController>();
        Vector3 anchorPos = m_pBattleScene.SummonPosition(ActivePartner.Trans.position, newbie_cc.radius, false, this, newbie_cc,  1, true);
        m_tempCameraAncher.transform.position = anchorPos;

        //预先预订位置,忽略和自身的碰撞
        CharacterController replaceModelController = ReplaceModelController;
        replaceModelController.slopeLimit = newbie_cc.slopeLimit;
        replaceModelController.stepOffset = newbie_cc.stepOffset;
        replaceModelController.center = newbie_cc.center;
        replaceModelController.radius = newbie_cc.radius;
        replaceModelController.height = newbie_cc.height;
        ReplaceModelPauseOtherMove(true);
        replaceModelController.gameObject.transform.position = anchorPos;
        replaceModelController.gameObject.transform.rotation = m_avatarObj.transform.rotation;
        CharacterController partnerController = ActivePartner.Trans.GetComponent<CharacterController>();
        partnerController.enabled = false;
        newbie_cc.enabled = false;

        Vector3 outDirection = Vector3.right;
        GameObject cameraObj = CCamera.GetInst().GetCameraObj();
        if (cameraObj != null)
        {
            Vector3 cright = cameraObj.transform.right;
            outDirection = (new Vector3(cright.x, 0.0f, cright.z)).normalized;
        }
        Vector3 inOrigin = anchorPos - outDirection * m_jumpRadius;
        m_partnerFSM.StoreParam<Vector3>("anchorPos", anchorPos);


        //准备好跳进跳出的位置、方向和动作
        //如果小伙伴没挂掉，小伙伴就跳出去，否则原地死掉
        if (!ActivePartner.Dead)
        {
            ActivePartner.Trans.forward = outDirection;
            ActivePartner.Trans.position = anchorPos;
            ActivePartner.PlayAction("jump", 2.0f, true);
        }
        else
        {
            ActivePartner.PlayAction(stStateData.GetActionName(eActionState.Dead));
        }
        
        
        m_avatarObj.transform.forward = outDirection;
        m_avatarObj.transform.position = inOrigin;

        m_avatarAnimator.PlayAction("jump", 2.0f, true,null,0);
        //m_avatarAnimator.Speed = 2.0f;
        ApplyRootMotion = true;


        //准备计时器
        m_partnerFSM.StoreParam<float>("switchCounter", m_switchTime);
        m_partnerFSM.StoreParam<float>("switchTime", m_switchTime);
        m_partnerFSM.StoreParam<bool>("switchAOE", false);


        //让怪物跟过来
        m_pBattleScene.ReplaceTarget(this, this);
        m_pBattleScene.ReplaceTargetTrans(this, m_tempCameraAncher.transform);
        m_myTrans = m_tempCameraAncher.transform;
        m_playerTrans = m_myTrans;

        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();
    }

    private void switchingToAvatarUpdate(System.Enum stateToUpdate)
    {
        //你跳来，我跳去
        float counter = m_partnerFSM.GetParam<float>("switchCounter");
        float time = m_partnerFSM.GetParam<float>("switchTime");

        counter -= Time.deltaTime;

        if (counter > 0.0f)
        {
            float amount = Mathf.Clamp01(1.0f - counter / time);

            if (amount >= 0.7 && !m_partnerFSM.GetParam<bool>("switchAOE"))
            {
                m_partnerFSM.StoreParam<bool>("switchAOE", true);
                //释放一个AOE
                this.Command(eCommandType.UseSkill, new UseSkillCommandArg(DEFINE.PARTNER_ENTER_SKILL, m_targetList, true));
            }
        }
        else
        {
            m_partnerFSM.TriggerEventQueued(ePartnerEvent.SwitchCompleted);
        }

        m_partnerFSM.StoreParam<float>("switchCounter", counter);

        //让小伙伴跑出去
        //if (m_partnerAnimator != null)
        //{
        //    m_partnerAnimator.Update();
        //}

        if (ActivePartner.CAnimator != null)
        {
            ActivePartner.CAnimator.Update();
        }


        Vector3 position = m_avatarObj.transform.position;
        CharacterController replaceModelController = ReplaceModelController;
        m_avatarObj.transform.position = new Vector3(position.x, replaceModelController.transform.position.y, position.z);
        ActivePartner.Trans.position = new Vector3(ActivePartner.Trans.position.x, replaceModelController.transform.position.y, ActivePartner.Trans.position.z);
    }

    private void switchingToAvatarExit(System.Enum stateToLeave)
    {
        //MyLog.LogError(" switchingToAvatarExit .. ");
        //隐藏小伙伴
        //m_partnerObj.gameCObject.SetActive(false);
        ActivePartner.Enabled = false;

        //重设下自己的transform
        m_myTrans = m_avatarObj.transform;
        m_playerTrans = m_myTrans;
        m_pBattleScene.ReplaceTargetTrans(this, this.GetTransform());

        m_myTrans.gameObject.tag = DEFINE.AVATAR_OBJECT_TAG;
        m_myTrans.gameObject.layer = DEFINE.AVATAR_LAYER;

        m_avatarAnimator.Speed = 1.0f;
        //m_partnerAnimator.Speed = 1.0f;

        //去掉无敌BUFF
        DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        //离开一种状态
        LeaveState(eActionState.SwitchPartner);


        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();

        CharacterController replaceModelController = ReplaceModelController;
        ReplaceModelPauseOtherMove(false);
        CharacterController avatarController = m_avatarObj.gameCObject.GetComponent<CharacterController>();
        avatarController.enabled = true;

        m_myTrans.position = replaceModelController.transform.position;

        //重置切换CD
        m_switchCDTimer.SetTimer(PartnerSwitchCD);
    }
    #endregion

    #region 坐骑相关
    private void SetRideState(eRideState state)
    {
        m_rideState = state;
        bool bEnter = (state == eRideState.None ? false : true);
        if (this is Avatar)
        {
            SingletonObject<BattleLeftButtonMediator>.GetInst().EnterRide(bEnter);
        }
    }

    public bool CanUseRide()
    {
        return !m_bUseRide;
    }

    public void DoCallPartner()
    {
        if (PartnerState == ePartnerState.Avatar)
        {
            if (m_PartnerList.Count > 0)
            {
                m_activePartner = m_PartnerList[0];
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.Switch);
            }
        }
        else if (PartnerState == ePartnerState.Partner)
        {
            if (m_PartnerList.Count == 1)
            {
                m_activePartner = m_PartnerList[0];
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.Switch);
            }
            else //说明有两个伙伴
            {
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.SwitchAnother);
            }
        }

        if (null != m_activePartner)
        {
            m_activePartner.Active = true;
        }
    }



    public virtual void OnHoldClick(Vector3 hitPosition,bool sendMsg = false)
    {
        CBaseState pCurrState = m_stateMgr.GetCurrState();
        if (pCurrState == null) return;
        eActionState actionState = pCurrState.GetState();

        CSkillState skillState = pCurrState as CSkillState;
        if (null != skillState)
        {
            skillState.MouseClick(hitPosition);
        }
        else
        {
            CChargeState chargeState = pCurrState as CChargeState;
            if (null != chargeState)
            {
                chargeState.MouseClick(hitPosition);
            }
        }
    }

    public bool BeginRide(bool forever = false,uint mountID = 0,bool fromMsg = false)
    {
        if (!CanRiding && !fromMsg)
        {
            return false;
        }

        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();

        uint uiMountID = m_uiMountID == 0 ? mountID : m_uiMountID;
         
        if (null == m_pMountLoader)
        {            
            return false;
        }

        if (!forever)
        {
            m_bUseRide = true;
        }

        //增加无敌隐身BUFF
        AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
       
        //丢失目标
        m_pBattleScene.LoseTarget(this);

        //m_bUseRide = true;//测试阶段暂时屏蔽
        SetRideState(eRideState.WaitRide);


        //在场景外创建坐骑      
        CreateMount();

        /*if (pcbsl.battleType != eBattleType.Arena && this is Avatar)
        {
            //CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_PET_MOUNT_PULL_NEAR_ID, null, CameraPullFar, null);
            List<int> effect = m_pMountLoader.ModelLoader.CameraEffects[0].list;
            int c = effect.Count;
            for (int i = 0; i < c; i++)
            {
                CCamera.GetInst().SetCameraEffect((uint)effect[i], null, null);
            }
        }*/

        return true;
    }

    public void CreateDragonshard(CrystalItemInfo info, eDragonshardType type,CPartner partner = null)
    {
        switch (type)
        {
            case eDragonshardType.avatarAttack:
                {
                    m_pAtkDragon = new Dragonshard(info, this);
                }
                break;
            case eDragonshardType.avatarDef:
                {
                    m_pDefDragon = new Dragonshard(info, this);
                }
                break;
            default:
                break; 
        }
    }

    private void CreateMount(bool replaceModel = false)
    {
        if (null != m_mountObj)
        {
            m_mountObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        m_mountObj = new CObject(m_pMountLoader.ModelLoader.MountsModelPath);
        m_mountObj.CallBack = LoadMountCompleted;
        m_mountObj.Layer = DEFINE.PET_LAYER;//借用宠物层
        m_mountObj.IsMemoryFactory = true;
        m_mountObj.ObjectType = replaceModel ? eObjectType.ReplaceModel : eObjectType.Mount;
        m_mountObj.LoadObject();
    }

    public void Ride()
    {
        if (m_rideState != eRideState.WaitRide)
        {
            return;
        }
        SetRideState(eRideState.RideDelay);
        //m_pAnimator.PlayAction("qicheng", 1.0f, false);
        RideDelay();


        if (this is Avatar && CurrBattleScene.BattleType != eBattleType.Arena)
        {
            CCamera.GetInst().SetCameraEffect((uint)m_pMountLoader.ModelLoader.FollowCameraID, null, null, new object[] { m_mountObj.gameCObject, eCAMERAFOLLOW.SMOOTH, true, true });
        }

    }

    private void RideDelay()
    {
        if (m_rideState != eRideState.RideDelay)
        {
            return;
        }
        if (null == m_mountObj)
        {
            return;
        }
        GameObject o = m_mountObj.GetObj();
        if (null == o)
        {
            return;
        }
        Transform boneTrans = Common.GetBone(o.transform, "Bone026");
        if (null == boneTrans)
        {
            return;
        }


        //策划说骑乘前清除所有BUFF
        ClearAllBuff();

        //清除所有光环
        ClearAllAura();

        //---------------------保存角色卡----------------------------------
        m_pBakOriginCard = m_pOriginCard;

        m_bakAniMoveSpeed = m_pPlayerLoader.m_AniMoveSpeed;
        m_AniMoveSpeed = m_pMountLoader.ModelLoader.MountsShowSpeed;
        m_fBakMaxMoveSpeed = m_maxMoveSpeed;

        List<int> buffList = m_pMountLoader.ModelLoader.BuffList;
        for (int i = 0, count = buffList.Count; i < count; ++i)
        {
            AddBuff((uint)buffList[i]);
        }

        m_pOriginCard.fMoveSpeed = m_pMountLoader.ModelLoader.MountsMoveSpeed;
        if (m_pOriginCard.fMoveSpeed > m_pMountLoader.ModelLoader.MountsMoveSpeedMax)
        {
            m_pOriginCard.fMoveSpeed = m_pMountLoader.ModelLoader.MountsMoveSpeedMax;
        }

        UpdateCharacterCard();

        //---------------------保存角色卡----------------------------------

        CurrTarget = null;


        //保存原先玩家的坐标
        Vector3 beforePosition = m_myTrans.position + Vector3.up*5;

        //-----------------------将主角作为子物体-----------------------------------------
        o.transform.forward = m_myTrans.forward;
        m_myTrans.parent = boneTrans;
        m_myTrans.localPosition = Vector3.zero;
        m_myTrans.localRotation = Quaternion.identity;
        o.name = m_myTrans.name;
        if (NpcSort == eNpcSort.Avatar || NpcSort == eNpcSort.FriendlyAvatar)
        {
            m_pPlatformReceiver = AddPlatformReceiveMessage(o);
        }


        CharacterController replaceController = ReplaceModelController;
        o.transform.position = replaceController.transform.position + Vector3.up * 0.05f;
        //-----------------------将主角作为子物体-----------------------------------------

        //摄像机看向大象
        //!!!!!!!!!!!!!!!!!!!!//SetFollowCamera(o);
        //摄像机看向大象

        //----------------------------碰撞器和寻路调整-------------------------------------
        if (m_characterController != null)
        {
            m_characterController.enabled = false;
            m_bakController = m_characterController;
            m_characterController = o.GetComponent<CharacterController>();
            m_characterController.enabled = true;

            Transform oldFollowObj = o.transform.Find("FollowObject");
            if (oldFollowObj != null)
            {
                UnityEngine.Object.Destroy(oldFollowObj.gameObject);
            }

            m_followObj.transform.parent = o.transform;
            m_followObj.transform.localPosition = Vector3.zero;

            SetCollider(m_characterController,3f,false);

        }

        //----------------------------碰撞器和寻路调整-------------------------------------

        //-----------------------脚下箭头调整-----------------------------------------
        if (NpcSort == eNpcSort.Avatar && m_directPoint != null)
        {
            m_directPoint.transform.parent = o.transform;
            m_directPoint.transform.localPosition = Vector3.zero;
            m_directPoint.transform.localRotation = Quaternion.identity;
        }
        
        //-----------------------脚下箭头调整-----------------------------------------

        if (m_pAnimator != null)
        {
            ApplyRootMotion = false;
        }

        //替换相关资源
        m_bakObject = m_pNpcObj;
        m_pNpcObj = m_mountObj;
        o.layer = DEFINE.AVATAR_LAYER;
        o.tag = DEFINE.AVATAR_OBJECT_TAG;



        if (!ClientMain.IsSupportShadowRunTime)
        {
            m_bakShadow = m_shadow;

            if (m_shadow != null)
            {
                MeshRenderer mr = m_shadow.GetComponent<MeshRenderer>();
                mr.enabled = false;
            }

            Transform shadowTrans = o.transform.Find("shadow");
            if (shadowTrans != null)
            {
                m_shadow = shadowTrans.gameObject;
            }
        }

        m_bakTrans = m_myTrans;
        m_myTrans = o.transform;

        m_bakSmr = m_smr;
        m_smr = o.GetComponentsInChildren<SkinnedMeshRenderer>();

        m_bakMrs = m_mrs;
        m_mrs = o.GetComponentsInChildren<MeshRenderer>();

        m_bakMaterials = Materials;
        for (int i = 0; i < m_smr.Length; i++)
        {
            if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
            {
                Materials = m_smr[i].materials;
                break;
            }
        }

        m_bakAnimator = m_pAnimator;
        m_pAnimator = m_mountAnimator;

        //更换武器
        ChangeWeapon((uint)m_pPlayerLoader.MountWeapon);

        //更换PVP标识特效
        SetPvpStepParticle(m_myTrans);



        //--------------------重置技能面板-------------------------------
        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            m_bakPlayerSkillList.Add(m_skillList[i]);
        }

        m_skillList.Clear();

        m_uiBakDefaultSkill = DefaultSkillID;

        DefaultSkillID = (uint)m_pPlayerLoader.RideNormalSkill;
        List<int> skillList = m_pMountLoader.ModelLoader.MountsSkill;
        for (int i = 0, count = skillList.Count; i < count; ++i)
        {
            uint skillID = (uint)skillList[i];
            AddSkill(skillID, null, (ushort)i);
        }

        if (NpcSort == eNpcSort.Avatar)
        {
            SingletonObject<Avatar>.GetInst().UpdateSkillPanel();
        }

        //!!!!!!!!!!!!!!!!!!!!//UpdatePanel(m_skillList);
        //--------------------重置技能面板-------------------------------

        //重算攻击距离
        CountAttackRange();

        //坐骑碰撞脚本
        //CPlayerRideHit prh = o.GetComponent<CPlayerRideHit>();
        //if (null == prh)
        //{
        //    prh = o.AddComponent<CPlayerRideHit>();
        //}
        //prh.enabled = true;

        if (null == m_pMountTimer)
        {
            m_pMountTimer = new Timer();
        }

        //竞技场坐骑时间减半
       
        if (CurrBattleScene.BattleType == eBattleType.Arena)
        {
            m_pMountTimer.SetTimer(m_pMountLoader.ModelLoader.MountsFightTime / 2.0f);
        }
        else
        {
            m_pMountTimer.SetTimer(m_pMountLoader.ModelLoader.MountsFightTime);
        }

  
        if (CurrBattleScene.BattleType == eBattleType.Wasteland ||
            CurrBattleScene.BattleType == eBattleType.Mining || 
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            AddBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
        }

        //如果坐骑和自己之间没有空气墙的话,之前的坐标套用坐骑的
        //Vector3 dir = o.transform.position - beforePosition;
        //dir.y = 0;
        //Ray tmpRay = new Ray(beforePosition, dir);
        //RaycastHit tmpHit;
        //if (Physics.Raycast(tmpRay, out tmpHit, Common.Get2DVecter3Length(beforePosition, o.transform.position), 1 << DEFINE.AIR_WALL))
        //{
        //    //修正坐骑的位置
        //    o.transform.position = m_pBattleScene.SummonPosition(beforePosition, CharacterRadius, false, this, NpcCollider,false,1,true);

        //}
        //else
        //{
        //    //修正坐骑的位置
        //    o.transform.position = m_pBattleScene.SummonPosition(o.transform.position, CharacterRadius, false, this, NpcCollider, false, 1, true);
        //}


        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();

        CharacterController replaceModelController = ReplaceModelController;
        ReplaceModelPauseOtherMove(false);
       
        SetRideState(eRideState.Ride);
        
        EnterState(eActionState.BeginRide,true);
    }


    private void LoadMountCompleted(GameObject o, params object[] args)
    {
        if (null == m_pMountLoader)
        {
            return;
        }
        if (m_rideState != eRideState.WaitRide)
        {
            m_mountObj.DestroyGameObject(eObjectDestroyType.Memory);
            return;
        }
        string szPath = m_pMountLoader.ModelLoader.MountsModelPath.Replace("_model", "_ctrl");

        if (null != o)
        {
            o.transform.localScale = Vector3.one * m_pMountLoader.ModelLoader.ModleScale;
            o.SetActive(false);

            SkinnedMeshRenderer[] smrs = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            if (smrs.Length > 0)
            {
                for (int i = 0; i < smrs.Length; i++)
                {
                    if (!smrs[i].tag.Equals(DEFINE.OTHER_SKINNED))
                    {
                        m_mountMat = smrs[i].material;
                        break;
                    }
                }
                ChangeShaderToXRayAndBackLightVertex(m_mountMat, true);
            }

            CBaseHomeAvatar.setMountParticals(o, (uint)m_pMountLoader.Key);
        }
        else
        {
            m_pMountLoader = HolderManager.m_MountsHolder.GetStaticInfo(DEFINE.REPLACE_MOUNT_LOADER_KEY);
            if (null != m_pMountLoader)
            {
                CreateMount(true);
            }
            return;
        }

        
        LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadMountAnimatorCtrl);
    }

    protected override void InitCharacterCard(ushort wLevel)
    {
        base.InitCharacterCard(wLevel);

        m_pOriginCard.fWalkSpeed = m_pOriginCard.fMoveSpeed / 1.5f;

        if (SingletonObject<CBattleSceneLoading>.GetInst().battleType == eBattleType.Arena)
        {
            if (NpcSort == eNpcSort.EnermyAvatar || NpcSort == eNpcSort.PvpEnemyAvatar)
            {
                SingletonObject<ArenaResultMediator>.GetInst().SetEnemyHpValue(m_nHp, m_pCard.nMaxHp);
            }
            else if (NpcSort == eNpcSort.Avatar)
            {
                SingletonObject<ArenaResultMediator>.GetInst().SetHpValue(m_nHp, m_pCard.nMaxHp);
            }
        }
        if (SingletonObject<CBattleSceneLoading>.GetInst().battleType == eBattleType.Pvp)
        {
            if (NpcSort == eNpcSort.EnermyAvatar || NpcSort == eNpcSort.PvpEnemyAvatar)
            {
                if (m_pCard.nMaxHp==0)
                {
                    m_pCard.nMaxHp = 1;
                }
                SingletonObject<LeagueBattleInfoMediator>.GetInst().SetEnemyHpValue(m_pCard.nMaxHp * 1.0f / (m_pCard.nMaxHp * 1.0f));
                SingletonObject<LeagueBattleInfoMediator>.GetInst().SetRightValue(m_nMaxMp, m_nMaxMp);
            }
            else if (NpcSort == eNpcSort.Avatar)
            {
                SingletonObject<LeagueBattleInfoMediator>.GetInst().SetHpValue(m_nHp, m_pCard.nMaxHp);
                SingletonObject<LeagueBattleInfoMediator>.GetInst().SetLeftValue(m_nMaxMp, m_nMaxMp);

            }
        }
    }

    public bool IsActurallyInRide()
    {
        return m_rideState == eRideState.Ride;
    }

    public bool IsInRide()
    {
        return m_rideState != eRideState.None;
    }

    public eRideState GetRideState()
    {
        return m_rideState;
    }
   

    private void LoadMountAnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        GameObject o = m_mountObj.GetObj();

        if (null == o)
        {
            return;
        }
        o.SetActive(true);

        Animator aniCtrl = o.GetComponent<Animator>();
        aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//         if (null == aniCtrl)
//         {
//             aniCtrl = o.gameObject.AddComponent<Animator>();
//             aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
//             aniCtrl.avatar = animator.avatar;
//             //ApplyRootMotion = true;
//         }


        PlaySound playSound = o.GetComponent<PlaySound>();
        if (null == playSound)
        {
            playSound = o.AddComponent<PlaySound>();
        }
        playSound.StepHandle = OnStepHandle;


        FixingBP_Buff fixBuff = o.GetComponent<FixingBP_Buff>();
        if (null == fixBuff)
        {
            o.AddComponent<FixingBP_Buff>();
        }

        aniCtrl.applyRootMotion = false;

        m_mountAnimator = new CAnimator(aniCtrl);

        CharacterController cc = o.GetComponent<CharacterController>();
        cc.center = new Vector3(0, cc.center.y, 0);
        cc.enabled = false;

        o.transform.rotation = m_myTrans.rotation;

        m_mountAndPetJumpPosition = m_pBattleScene.SummonPosition(m_myTrans.position, cc.radius, false, this, cc, 1, true);
        m_mountAndPetJumpPosition += Vector3.up;

        m_avatarObj.gameCObject.layer = DEFINE.TEMP_LAYER;

        CharacterController replaceModelController = ReplaceModelController;
        replaceModelController.slopeLimit = cc.slopeLimit;
        replaceModelController.stepOffset = cc.stepOffset;
        replaceModelController.center = cc.center;
        replaceModelController.radius = cc.radius;
        replaceModelController.height = cc.height;
        ReplaceModelPauseOtherMove(true);

        replaceModelController.gameObject.transform.position = m_mountAndPetJumpPosition;
        replaceModelController.gameObject.transform.rotation = m_myTrans.rotation;
        replaceModelController.gameObject.transform.localScale = o.transform.localScale;
        o.transform.position = m_mountAndPetJumpPosition - m_myTrans.forward * m_jumpRadius;
       
        EnterState(eActionState.RideJump);

    }

    public void MountJumpToDest(float totalTime)
    {
        float speed = m_jumpRadius / totalTime;

        if (m_mountObj != null)
        {
            GameObject o = m_mountObj.GetObj();
            CharacterController replaceModelController = ReplaceModelController;
            Vector3 replacePosition = replaceModelController.transform.position;
            Vector3 dir = (replacePosition - o.transform.position).normalized;
            dir.y = 0;

            Vector3 position = o.transform.position;
            
            position += dir * Time.deltaTime * speed;

            if (Vector3.Dot((replacePosition - position).normalized, dir) < 0)
            {
                o.transform.position = replacePosition;
            }
            else
            {
                o.transform.position = new Vector3(position.x, replacePosition.y, position.z);
            }
        }
    }

    private void EndRideState()
    {
        /*CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (pcbsl.battleType != eBattleType.Arena && this is Avatar)
        {
            //CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_PET_MOUNT_PULL_NEAR_ID,null, CameraPullFar, null);
            List<int> effect = m_pMountLoader.ModelLoader.CameraEffects[1].list;
            int c = effect.Count;
            for (int i = 0; i < c; i++)
            {
                CCamera.GetInst().SetCameraEffect((uint)effect[i], null, null);
            }
        }*/

        CharacterController replaceModelController = ReplaceModelController;
        replaceModelController.slopeLimit = m_bakController.slopeLimit;
        replaceModelController.stepOffset = m_bakController.stepOffset;
        replaceModelController.center = m_bakController.center;
        replaceModelController.radius = m_bakController.radius;
        replaceModelController.height = m_bakController.height;
        ReplaceModelPauseOtherMove(true);

        replaceModelController.gameObject.transform.position = m_pBattleScene.SummonPosition( m_avatarObj.transform.position,m_bakController.radius,false,this,m_bakController);
        replaceModelController.gameObject.transform.rotation = m_myTrans.rotation;

        m_avatarObj.gameCObject.layer = DEFINE.TEMP_LAYER;
        m_myTrans.gameObject.layer = DEFINE.TEMP_LAYER;

        EnterState(eActionState.EndRide);
    }

    public void EndRide(bool forceEnd)
    {
        if (m_rideState == eRideState.RideDelay || m_rideState == eRideState.WaitRide)
        {
            m_rideState = eRideState.None;
            if (m_mountObj != null)
            {
                m_mountObj.DestroyGameObject(eObjectDestroyType.Memory);
            }
            EnterState(eActionState.Idle,true);
            return;
        }
        if (m_mountObj == null || m_mountObj.transform == null)
        {
            return;
        }

        if (forceEnd)
        {
            CharacterController replaceModelController = ReplaceModelController;
            replaceModelController.slopeLimit = m_bakController.slopeLimit;
            replaceModelController.stepOffset = m_bakController.stepOffset;
            replaceModelController.center = m_bakController.center;
            replaceModelController.radius = m_bakController.radius;
            replaceModelController.height = m_bakController.height;
            ReplaceModelPauseOtherMove(true);

            replaceModelController.transform.position = m_avatarObj.transform.position;
            replaceModelController.transform.rotation = m_avatarObj.transform.rotation;
        }

        SetRideState(eRideState.None);

        //替换相关资源
        m_pNpcObj = m_bakObject;
        m_pNpcObj.transform.parent = null;
        m_pNpcObj.gameCObject.layer = DEFINE.AVATAR_LAYER;


        m_characterController = m_bakController;
        m_characterController.enabled = true;
        m_bakController = null;
        SetCollider(m_characterController,0,false);
        //修正坐骑的位置


        if (!CStoryManage.GetInst().IsInStory())
        {
            CharacterController replaceModelController = ReplaceModelController;
            ReplaceModelPauseOtherMove(false);
            m_pNpcObj.transform.position = replaceModelController.gameObject.transform.position + Vector3.up;
        }
       
        m_pNpcObj.transform.rotation = m_mountObj.transform.rotation;
        //SetImitate(imitatePosition, NpcCollider);

        //if (NpcSort == eNpcSort.Avatar)
        //{
        //    m_mountObj.gameCObject.tag = "";
        //    RemovePlatformReceiveMessage(m_mountObj.gameCObject);
        //}
        //!!!!!!!!!!!!!!!!!!!!!//SetFollowCamera(m_pNpcObj.GetObj());

        if (NpcSort == eNpcSort.Avatar && null != m_directPoint)
        {
            m_directPoint.transform.parent = m_pNpcObj.transform;
            m_directPoint.transform.localPosition = Vector3.zero;
            m_directPoint.transform.localRotation = Quaternion.identity;
        }
        
        //if (m_mountObj != null)
        //{
        //    m_mountObj.DestroyGameObject(eObjectDestroyType.Memory);
        //    m_mountObj = null;
        //}

        if (!ClientMain.IsSupportShadowRunTime)
        {
            m_shadow = m_bakShadow;
            m_bakShadow = null;

            if (m_shadow != null)
            {
                MeshRenderer mr = m_shadow.GetComponent<MeshRenderer>();
                mr.enabled = true;
            }
            
        }

        m_myTrans = m_bakTrans;
        m_bakTrans = null;

        m_followObj.transform.parent = m_myTrans;
        m_followObj.transform.localPosition = Vector3.zero;

        m_smr = m_bakSmr;
        m_bakSmr = null;

        m_mrs = m_bakMrs;
        m_bakMrs = null;

        Materials = m_bakMaterials;
        m_bakMaterials = null;

        m_pAnimator = m_bakAnimator;
        m_bakAnimator = null;

        m_mountAnimator = null;


        DefaultSkillID = m_uiBakDefaultSkill;
        m_uiCurrUseSkillType = m_uiBakDefaultSkill;//必须设置,否则下马的一瞬间被打断连招会出现人物非骑马时调用骑马的普工
        m_uiBakDefaultSkill = 0;
        

        m_skillList.Clear();
        for (int i = 0, count = m_bakPlayerSkillList.Count; i < count; ++i)
        {
            m_skillList.Add(m_bakPlayerSkillList[i]);
        }
        m_bakPlayerSkillList.Clear();

        if (NpcSort == eNpcSort.Avatar)
        {
            SingletonObject<Avatar>.GetInst().UpdateSkillPanel( );
        }

        //!!!!!!!!!!!!!!!!//UpdatePanel(m_skillList);
        //清除所有BUFF;
        ClearAllBuff();
        ClearAllAura();


        //更换PVP标识特效
        SetPvpStepParticle(m_myTrans);

        //还原角色卡
        m_pOriginCard = m_pBakOriginCard;       
        UpdateCharacterCard();


        //还原武器
        ChangeWeapon(m_uiWeaponID);

        //坐骑碰撞脚本
        //CPlayerRideHit prh = m_mountObj.GetObj().GetComponent<CPlayerRideHit>();
        //if (null != prh)
        //{
        //    prh.enabled = false;
        //}


        //MoveSpeed = m_pPlayerLoader.GetMoveSpeed();

        m_AniMoveSpeed = m_bakAniMoveSpeed;
        m_bakAniMoveSpeed = null;
        m_maxMoveSpeed = m_fBakMaxMoveSpeed;

        EnterState(eActionState.Idle);

        m_pBattleScene.LoseTarget(this);

        m_mountObj.DestroyGameObject(eObjectDestroyType.Memory);

        CreateParticle(DEFINE.RIDE_END_PARTICLEID);

        SetRideState(eRideState.None);

        m_mountMat = null;

        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (CurrBattleScene.BattleType == eBattleType.Wasteland || 
            CurrBattleScene.BattleType == eBattleType.Mining ||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            DelBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
        }

        //重算攻击距离
        CountAttackRange();

        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();



        if (pcbsl.battleType != eBattleType.Arena)
        {
            InitFollowCamera(m_pNpcObj.gameCObject, eCAMERAFOLLOW.SMOOTH,true);
        }
        
    }
    #endregion

    # region 飞行相关
    public bool CanUseFly()
    {
        return !m_bUseFly;
    }

    public bool BeginFly(bool forever = false,bool fromMsg = false)
    {
        if (!CanFly && !fromMsg)
        {
            return false;
        }

        if (!forever)
        {
            m_bUseFly = true;
        }

        //大家一起进入起飞状态
        SetFlyState(eFlyState.BeginFly);

        //丢失目标
        m_pBattleScene.LoseTarget(this);

        //提前更换武器
        ChangeWeapon((uint)m_pPlayerLoader.FlyWeapon);

        //增加转胳膊脚本
        Transform handTrans = Common.GetBone(m_myTrans, "Bip01 R Clavicle");
        if (handTrans != null)
        {
            RotateFlyFightHand rffh = handTrans.GetComponent<RotateFlyFightHand>();
            if (null == rffh)
            {
                rffh = handTrans.gameObject.AddComponent<RotateFlyFightHand>();
            }
            else
            {
                rffh.LookPosition = Vector3.zero;
                rffh.enabled = true;
            }


        }
        Vector3 myTransPos = Vector3.zero;
        if (null != m_myTrans)
        {
            myTransPos = m_myTrans.position;
        }
        m_mountAndPetJumpPosition = m_pBattleScene.SummonPosition(myTransPos, m_myPet.CharacterRadius * 2, false, this, m_myPet.NpcCollider,  1, false);

        //玩家进入起飞状态
        EnterState(eActionState.BeginFly);
        //宠物进入起飞状态
        m_myPet.TriggerEvent(ePetEvent.BEGIN_FLY_FIGHT);

        if (null != m_myTrans)
        {
            m_myTrans.gameObject.layer = DEFINE.TEMP_LAYER;
        }

      
        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        Avatar pavatar = SingletonObject<Avatar>.GetInst();
        EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();

        if (this is Avatar)
        {
            if (pcbsl.battleType == eBattleType.Arena)
            {
                //CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.ROTATE, true ,false});
            }
            else
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_PET_MOUNT_PULL_NEAR_ID, null, CameraPullFar, null);
                CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_AVATAR_FLY_FIGHT, null, null, new object[] { m_pNpcObj.gameCObject, eCAMERAFOLLOW.SMOOTH, true ,false});
            }
        }

        if (this is EnemyAvatar)
        {
//             if (pcbsl.battleType == eBattleType.Arena && !pavatar.IsInFly())
//             {
//                 CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_ARENA_BIRDS, null, null, new object[] { m_pBattleScene.TempCameraAncher, eCAMERAFOLLOW.ROTATE, true ,false});
//             }
            
        }

        return true;
    }


    public Vector3 GetMountAndJumpPosition()
    {
        return m_mountAndPetJumpPosition;
    }

    private void CameraPullFar(params object[] args)
    {
        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (pcbsl.battleType != eBattleType.Arena && this is Avatar)
        {
            CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_PET_MOUNT_PULL_FAR_ID, null, null);
        }
    }

    public void InitFollowCamera(GameObject o, eCAMERAFOLLOW followType = eCAMERAFOLLOW.DIRECT,bool resetFOV = true)
    {
        SceneInfoContent info = m_pBattleScene.SceneLoaderInfo;
        if ( CurrBattleScene.BattleType != eBattleType.Arena)
        {
            if (info != null && this is Avatar)
            {
                CCamera.GetInst().SetCameraEffect((uint)info.CameraID, null, null, new object[] { o, followType, true, resetFOV });
            }
            else
            {
                MyLog.LogError("The game has not cameraID");
            }
        }        
    }

    public void Fly()
    {
        if (m_flyState != eFlyState.BeginFly)
        {
            return;
        }
        PetContent pPetLoader = (PetContent)m_myPet.GetNpcLoader();
        PetModelContent pPetModelLoader = m_myPet.GetPetModelLoader();

        Transform petTrans = m_myPet.GetTransform();
        if (null == petTrans)
        {
            return;
        }

        CAnimator petAnimator = m_myPet.GetCAnimator();

        Transform boneTrans = Common.GetBone(petTrans, "BP_Step");
        if (null == boneTrans)
        {
            MyLog.LogError("Fly error ,can't find bone:BP_Step");
            return;
        }

        m_myPet.RenameBuffPoint(true);

        //策划说骑乘前清除所有BUFF
        ClearAllBuff();

        //清除所有光环
        ClearAllAura();
       

        //--------------------重置技能面板-------------------------------
        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            m_bakPlayerSkillList.Add(m_skillList[i]);
        }

        m_skillList.Clear();

        m_uiBakDefaultSkill = DefaultSkillID;

        DefaultSkillID = (uint)pPetModelLoader.NormalFlySkill;
        if (NpcSort == eNpcSort.Avatar)
        {
            SingletonObject<Avatar>.GetInst().UpdateSkillPanel( );
        }
        //List<uint> skillList = pPetLoader.GetPetSkills();
        //for (int i = 0, count = skillList.Count; i < count; ++i)
        //{
        //    AddSkill(skillList[i], (ushort)i);
        //}

   
        //!!!!!!!!!!!!!!!!!!!!//UpdatePanel(m_skillList);
        //--------------------重置技能面板-------------------------------

        //---------------------保存角色卡----------------------------------
        m_pBakOriginCard = m_pOriginCard;

        m_bakAniMoveSpeed = m_pPlayerLoader.m_AniMoveSpeed;
        m_AniMoveSpeed = m_myPet.GetAniMoveSpeed();
        m_fBakMaxMoveSpeed = m_maxMoveSpeed;

        List<int> buffList = pPetModelLoader.BuffList;
        for (int i = 0, count = buffList.Count; i < count; ++i)
        {
            AddBuff((uint)buffList[i]);
        }

        m_pOriginCard.fMoveSpeed = pPetLoader.ModelLoader.MoveSpeed;
        if (m_pOriginCard.fMoveSpeed > m_myPet.GetMaxMoveSpeed())
        {
            m_pOriginCard.fMoveSpeed = m_myPet.GetMaxMoveSpeed();
        }

        UpdateCharacterCard();

        //---------------------保存角色卡----------------------------------

        CurrTarget = null;
        //-----------------------将主角作为子物体-----------------------------------------
        string petName = null;
        if (null != m_myTrans)
        {
            m_myTrans.parent = boneTrans;
            m_myTrans.localPosition = new Vector3(0, m_myTrans.localPosition.y, 0);
            m_myTrans.localRotation = Quaternion.identity;
            petName = m_myTrans.name;
        }
        if (null != petTrans)
        {
            petTrans.name = m_myTrans.name;
            if (NpcSort == eNpcSort.Avatar || NpcSort == eNpcSort.FriendlyAvatar)
            {
                m_pPlatformReceiver = AddPlatformReceiveMessage(petTrans.gameObject);
            }
        }
        
        //-----------------------将主角作为子物体-----------------------------------------

        //----------------------------碰撞器和寻路调整-------------------------------------
        if (m_characterController != null)
        {
			if (m_pBattleScene.BattleType == eBattleType.PVE ||
			    m_pBattleScene.BattleType == eBattleType.Escort ||
			    m_pBattleScene.BattleType == eBattleType.GlobalBoss ||
			    m_pBattleScene.BattleType == eBattleType.Protect)
			{
				m_characterController.enabled = false;
			}
            
            m_bakController = m_characterController;
            m_characterController = petTrans.GetComponent<CharacterController>();
            m_characterController.enabled = true;
            SetCollider(m_characterController,-0.1f,false);

            m_followObj.transform.parent = petTrans.transform;
        }

        //----------------------------碰撞器和寻路调整-------------------------------------

        //-----------------------脚下箭头调整-----------------------------------------
        //m_directPoint.transform.parent = petTrans;
        //m_directPoint.transform.localPosition = Vector3.zero;
        //m_directPoint.transform.localRotation = Quaternion.identity;
        //-----------------------脚下箭头调整-----------------------------------------

        if (m_pAnimator != null)
        {
            ApplyRootMotion = false;
        }

        //替换相关资源
        m_bakObject = m_pNpcObj;
        m_pNpcObj = m_myPet.GetObject();
        if (null != m_myTrans)
        {
            m_myTrans.gameObject.layer = DEFINE.AVATAR_LAYER;
        }
        if (null != m_pNpcObj && null != m_pNpcObj.GetObj())
        {
            m_pNpcObj.GetObj().layer = DEFINE.AVATAR_LAYER;
            m_pNpcObj.GetObj().tag = DEFINE.AVATAR_OBJECT_TAG;
        }
        

        SetFootEffect(false);

        m_bakTrans = m_myTrans;
        m_myTrans = petTrans;

        m_bakSmr = m_smr;
        m_smr = petTrans.GetComponentsInChildren<SkinnedMeshRenderer>();

        m_bakMrs = m_mrs;
        m_mrs = petTrans.GetComponentsInChildren<MeshRenderer>();

        m_bakMaterials = Materials;
        for (int i = 0; i < m_smr.Length; i++)
        {
            if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
            {
                Materials = m_smr[i].materials;
                break;
            }
        }

        m_bakAnimator = m_pAnimator;
        m_pAnimator = petAnimator;

        if (null == m_pPetTimer)
        {
            m_pPetTimer = new Timer();
        }

        //竞技场飞行时间减半
        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        if (pcbsl != null && pcbsl.battleType == eBattleType.Arena)
        {
            m_pPetTimer.SetTimer(pPetModelLoader.FightTime / 2.0f);
        }
        else
        {
            m_pPetTimer.SetTimer(pPetModelLoader.FightTime);
        }

        if (CurrBattleScene.BattleType == eBattleType.Wasteland ||
            CurrBattleScene.BattleType == eBattleType.Mining||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            AddBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
        }        

        //更换PVP标识特效
        if (null != m_myTrans)
        {
            SetPvpStepParticle(m_myTrans);
        }

        //重算攻击距离
        CountAttackRange();

        //转变为空中单位
        UnitsType = eNpcUnitsType.Air;

        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();

        SetFlyState(eFlyState.Fly);
        m_myPet.TriggerEvent(ePetEvent.FLY_FIGHT);

        EnterState(eActionState.Idle);
    }

    private void SetFlyState(eFlyState state)
    {
        m_flyState = state;
        bool bEnter = (state == eFlyState.None ? false : true);
        if (this is Avatar)
        {
            SingletonObject<BattleLeftButtonMediator>.GetInst().EnterFly(bEnter);
        }
    }

    public void EndFlyDelay()
    {
        if (m_flyState != eFlyState.Fly)
        {
            m_flyState = eFlyState.None;
            return;
        }
        m_flyState = eFlyState.EndFly;
        m_myPet.TriggerEvent(ePetEvent.END_FLY_FIGHT);
    }

    public void EndFly(object lockObject = null)
    {
        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        Avatar pavatar = SingletonObject<Avatar>.GetInst();
        EnemyAvatar penemyavatar = SingletonObject<EnemyAvatar>.GetInst();
        if (this is Avatar)
        {
            if (pcbsl.battleType == eBattleType.Arena)
            {
                if (!penemyavatar.IsActuallyInFly() || penemyavatar.PartnerState != ePartnerState.Avatar)
                {
                    SceneInfoContent info = m_pBattleScene.SceneLoaderInfo;

                    //CCamera.GetInst().SetCameraEffect(info.GetCameraID(), lockObject, null, new object[] { pavatar.BakTrans.gameObject, eCAMERAFOLLOW.ROTATE, true ,false});
                }
            }
            else
            {
                CCamera.GetInst().SetCameraEffect(DEFINE.CAMERA_PET_MOUNT_PULL_NEAR_ID, null, CameraPullFar, null);
            }  
        }
        else if(this is EnemyAvatar)
        {
            if (pcbsl.battleType == eBattleType.Arena)
            {
                if (!pavatar.IsActuallyInFly() || pavatar.PartnerState != ePartnerState.Avatar)
                {
                    SceneInfoContent info = m_pBattleScene.SceneLoaderInfo;

                    GameObject pAvatarObj = pavatar.GetTransform().gameObject;
                    if (pavatar.IsInFly())
                    {
                        pAvatarObj = pavatar.BakTrans.gameObject;
                    }
                    //CCamera.GetInst().SetCameraEffect(info.GetCameraID(), lockObject, null, new object[] { pAvatarObj, eCAMERAFOLLOW.ROTATE, true ,false});
                }
            }
        }

    
        if (CurrBattleScene.BattleType == eBattleType.Wasteland || 
            CurrBattleScene.BattleType == eBattleType.Mining||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            DelBuff(DEFINE.FOREVER_ENDURE_BUFF_ID);
        }


        PetContent pPetLoader = (PetContent)m_myPet.GetNpcLoader();

        Transform petTrans = m_myPet.GetTransform();

        CAnimator petAnimator = m_myPet.GetCAnimator();

        m_myPet.RenameBuffPoint(false);

        //缩小
        if (null != petTrans)
        {
            iTween.ScaleTo(petTrans.gameObject, Vector3.one, 2);
        }

        m_myTrans = m_bakTrans;
        m_bakTrans = null;
        //if (NpcSort == eNpcSort.Avatar)
        //{
        //    petTrans.gameObject.tag = "";
        //    RemovePlatformReceiveMessage(petTrans.gameObject);
        //}
         
        m_followObj.transform.parent = m_myTrans;
        m_followObj.transform.localPosition = Vector3.zero;

        m_smr = m_bakSmr;
        m_bakSmr = null;

        m_mrs = m_bakMrs;
        m_bakMrs = null;

        Materials = m_bakMaterials;
        m_bakMaterials = null;

        m_pAnimator = m_bakAnimator;
        m_bakAnimator = null;

        m_characterController.enabled = false;
        m_characterController = m_bakController;
        m_characterController.enabled = true;
        m_bakController = null;
        SetCollider(m_characterController,0,false);

        //替换相关资源
        m_pNpcObj = m_bakObject;
        m_pNpcObj.transform.parent = null;

        //还原脚下箭头
        //m_directPoint.transform.parent = m_pNpcObj.transform;
        //m_directPoint.transform.localPosition = Vector3.zero;
        //m_directPoint.transform.localRotation = Quaternion.identity;
        SetFootEffect(true);

        Ray ray = new Ray(m_pNpcObj.transform.position + Vector3.up * 10,-Vector3.up);
        if (Physics.Raycast(ray,0.1f + 10, 1 << DEFINE.TERRAINLAYER))//防止宠物沉下的时候突然下鸟
        {
            m_pNpcObj.transform.position = m_pBattleScene.SummonPosition(petTrans.position, CharacterRadius, false, this, NpcCollider);
        }

        m_pNpcObj.transform.rotation = petTrans.rotation;
        m_pNpcObj.transform.localScale = Vector3.one;

        petTrans.name = m_myPet.Index.ToString();
        petTrans.gameObject.layer = DEFINE.PET_LAYER;
        

        DefaultSkillID = m_uiBakDefaultSkill;
        m_uiCurrUseSkillType = m_uiBakDefaultSkill;//必须设置,否则下马的一瞬间被打断连招会出现人物非骑马时调用骑马的普工
        m_uiBakDefaultSkill = 0;

        m_skillList.Clear();
        for (int i = 0, count = m_bakPlayerSkillList.Count; i < count; ++i)
        {
            m_skillList.Add(m_bakPlayerSkillList[i]);
        }
        m_bakPlayerSkillList.Clear();

        if (NpcSort == eNpcSort.Avatar)
        {
            SingletonObject<Avatar>.GetInst().UpdateSkillPanel( );
        }

        //!!!!!!!!!!!!!!!!//UpdatePanel(m_skillList);
        //清除所有BUFF;
        ClearAllBuff();
        ClearAllAura();

        //还原角色卡
        m_pOriginCard = m_pBakOriginCard;


        UpdateCharacterCard();


        //MoveSpeed = m_pPlayerLoader.GetMoveSpeed();

        m_AniMoveSpeed = m_bakAniMoveSpeed;
        m_bakAniMoveSpeed = null;

        m_maxMoveSpeed = m_fBakMaxMoveSpeed;

        m_pBattleScene.LoseTarget(this);

        //转变为地面单位
        UnitsType = eNpcUnitsType.Ground;
        SetFlyState(eFlyState.None);

        //还原武器
        ChangeWeapon(m_uiWeaponID);

        if (null != m_myTrans)
        {
            //更换PVP标识特效
            SetPvpStepParticle(m_myTrans);

            //禁用转胳膊脚本
            Transform handTrans = Common.GetBone(m_myTrans, "Bip01 R Clavicle");
            if (handTrans != null)
            {
                RotateFlyFightHand rffh = handTrans.GetComponent<RotateFlyFightHand>();
                if (null != rffh)
                {
                    rffh.enabled = false;
                }
            }
        }
        

        if (pcbsl.battleType != eBattleType.Arena && null != m_pNpcObj)
        {
            InitFollowCamera(m_pNpcObj.gameCObject, eCAMERAFOLLOW.SMOOTH, true);
        }
        
        EnterState(eActionState.EndFly);
        m_myPet.TriggerEvent(ePetEvent.ENTER_WANDER_CIRCLE);

        //重算攻击距离
        CountAttackRange();

        //和马车忽略碰撞
        CurrBattleScene.IgnoreAvatarAndCarriage();

    }

    public bool IsActuallyInFly()
    {
        return m_flyState == eFlyState.Fly;
    }

    public bool IsInFly()
    {
        return m_flyState != eFlyState.None;
    }

    //是否在飞行下落阶段
    public bool IsFlyInFall()
    {
        return m_flyState == eFlyState.EndFly;
    }

    #endregion
    //public uint NpcType
    //{
    //    get
    //    {
    //        return m_uiNpcType;
    //    }
    //    set
    //    {
    //        m_uiNpcType = value;
    //    }
    //}

    public uint ClothesID
    {
        set
        {
            m_uiClothesID = value;
        }
    }

    //是否可被抓取
    public override bool CanBeGrab
    {
        get
        {
            if (!base.CanBeGrab || CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve)
            {
                return false;
            }
            bool canBeGrab = (!IsInRide() && !IsInFly() && NpcSort != eNpcSort.EnermyAvatar && NpcSort != eNpcSort.PvpEnemyAvatar && NpcSort != eNpcSort.FriendlyAvatar);            
                        
            return canBeGrab;
        } 
    }

    protected override void CreateNpc(Vector3 position,Quaternion rotation,bool replace = false)
    {
        EquipContent pClothesLoader = HolderManager.m_EquipHolder.GetStaticInfo(m_uiClothesID);
        if (null == pClothesLoader)
        {
            return;
        }
 
       List<string> szPaths = pClothesLoader.ModelLoader.ModelPath;
           
        if (szPaths.Count == 0)
        {
            return;
        }
        if (null != m_pNpcObj)
        {
            m_pNpcObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        m_pNpcObj = new CObject(szPaths[0]);
        m_pNpcObj.Layer = m_nLayer;

        m_pNpcObj.Name = m_uiIndex.ToString();
        m_pNpcObj.CallBack = LoadNpcCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = eObjectType.HomeAvatar;
        m_pNpcObj.Args = new object[] { replace };
        Ray ray = new Ray(position + Vector3.up * 5, Vector3.down);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, 100, 1 << DEFINE.TERRAINLAYER))
        {
            position = new Vector3(position.x, hit.point.y, position.z) + Vector3.up;
        }

        m_pNpcObj.BornPosition = position;
        m_pNpcObj.BornRotation = rotation;
        m_pNpcObj.Args = new object[] { replace };
        m_pNpcObj.LoadObject();

    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {     
        if (null == o) 
        {
            if (null != args && args.Length > 0 && args[0] is bool && (bool)args[0])
            {
                return;
            }
            m_pPlayerLoader = HolderManager.m_PlayerHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            PlayerConfigContent playerConfig = HolderManager.m_PlayerConfigHolder.GetStaticInfo(DEFINE.REPLACE_PLAYER_LOADER_KEY);
            if (null == m_pPlayerLoader || null == playerConfig)
            {
                return;
            }
            m_uiClothesID = (uint)playerConfig.Clothes;
            CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation, true);
            return;
        }
        base.LoadNpcCompleted(o, args);
        Common.ShowAvatarClothes(o, false);

        //屏蔽家园的navmesh
        NavMeshAgent nma = o.GetComponent<NavMeshAgent>();
        if (nma != null) nma.enabled = false;
      
        string animatorPath = m_pPlayerLoader.AmimatorPath;
        
        if (null == m_myTrans)
        {
            return;
        }
        Animator aniCtrl = m_myTrans.GetComponent<Animator>();
        if (null == aniCtrl)
        {            
            MyLog.LogError(animatorPath + " can not find animator Component !  ");
            return;
        }

        if (null == aniCtrl.runtimeAnimatorController) // Controller
        {
            LoadHelp.LoadObject("", animatorPath, ThreadPriority.Normal, LoadAcnimatorCtrl);
        }
         else
         {
             BuildAnimator(aniCtrl);
         }

        //初始化
        m_avatarObj = m_pNpcObj;

        //if (m_npcSort != eNpcSort.Pet)
        //{
        //    m_smr = o.GetComponentsInChildren<SkinnedMeshRenderer>();
            if (m_smr != null && m_smr.Length > 0)
            {
                //for (int i = 0; i < m_smr.Length; i++)
                //{
                //    if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                //    {
                //        Materials = m_smr[i].materials;
                //        break;
                //    }
                //}
                if (m_materiaslCount > 0)
                    ChangeShaderToXRayAndBackLightVertex(Materials[0], true);
                m_currShaderName = m_material0Name;
            }
        //}

        //m_avatarController = m_controller;

        if (m_PartnerList.Count > 0)
        {
            m_activePartner = m_PartnerList[0];
            m_inActivePartner = m_PartnerList.Count > 1 ? m_PartnerList[1] : null;
        }

        if (m_bTwoPartners || m_isAvatarDead)
        {
            //主角模型隐藏
            o.gameObject.SetActive(false);

            m_activePartner.Active = true;
            m_avatarLifePercent = 0f;
        }
        else
        {
            if (null != m_activePartner)
            {
                m_activePartner.Active = false;                
            }
        }

        if ( null != m_pAtkDragon )
        {
            m_pAtkDragon.BindParentTransfrom(0);
        }
        if ( null != m_pDefDragon )
        {
            m_pDefDragon.BindParentTransfrom(0);
        }
                

        m_switchCDTimer.SetTimer(0);
    }

    //PVP红圈特效
    public uint AddPvpStepParticle() 
    {
        if (CurrBattleScene.BattleType == eBattleType.Arena || 
            CurrBattleScene.BattleType == eBattleType.Wasteland || 
            CurrBattleScene.BattleType == eBattleType.Mining ||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            uint particleId = 0;

            if ( this is Avatar )
            {
                particleId = DEFINE.PVP_OWN_SIDE_PARTICLEID;
            }
            else if ( this is EnemyAvatar || this is OnlineAvatar)
            {
                particleId = DEFINE.PVE_ENEMY_SIDE_PARTICLEID;
            }
            else
            {
                return 0;
            }

            return CreateParticle(particleId);
        }
        return 0;
    }

    public void SetPvpStepParticle(Transform trans) 
    {
        if (null == CurrBattleScene)
        {
            return;
        }

        if (CurrBattleScene.BattleType == eBattleType.Arena || 
            CurrBattleScene.BattleType == eBattleType.Wasteland || 
            CurrBattleScene.BattleType == eBattleType.Mining||
            CurrBattleScene.BattleType == eBattleType.Pvp ||
            CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            CGroundParticle pParticle = CParticleManager.GetInst().GetParticle(m_uiPvpParticleIndex) as CGroundParticle;
            if (null == pParticle)
                return;

            pParticle.SetSrcTrans(trans);
        }
    }

    public bool EnabledPvpStepParticle
    {
        set 
        {
            if (CurrBattleScene.BattleType == eBattleType.Arena || 
                CurrBattleScene.BattleType == eBattleType.Wasteland || 
                CurrBattleScene.BattleType == eBattleType.Mining ||
                CurrBattleScene.BattleType == eBattleType.Pvp ||
                CurrBattleScene.BattleType == eBattleType.MultiPve)
            {
                CGroundParticle pParticle = CParticleManager.GetInst().GetParticle(m_uiPvpParticleIndex) as CGroundParticle;
                if (null == pParticle)
                    return;

                pParticle.ParticleEnabled = value;
            }
        }
    }

    protected override void BuildAnimator(Animator animator)
    {
        base.BuildAnimator(animator);

        m_avatarAnimator = m_pAnimator;
        if (null == m_myTrans)
        {
            return;
        }
        PlaySound playSound = m_myTrans.GetComponent<PlaySound>();
        if (null == playSound)
        {
            playSound = m_myTrans.gameObject.AddComponent<PlaySound>();
        }
        playSound.StepHandle = OnStepHandle;
    }

    private void OnStepHandle(int step)
    {
        if (!(this is Avatar))
            return;

        uint baseId = 0;
        uint soundId = 0;
        if (IsInRide())
        {
            MountModelContent modelLoader = m_pMountLoader.ModelLoader;
            if ( null != modelLoader )
            {
                if (modelLoader.Key / 130100 < 4) // 1 ~ 3
                {
                    soundId = 8131;
                }                
                else if ( modelLoader.Key  / 130100 < 8 ) // 4~7
                {
                    soundId = 8132;
                }
                else if ( modelLoader.Key == 130801)                
                {
                    soundId = 8133;
                }
                else if ( modelLoader.Key == 130901)
                {
                    soundId = 8134;
                }
                else if (modelLoader.Key == 131001)
                {
                    soundId = 8211;
                }
            }
        }
        else
        {
            baseId = 500; //基础id
            soundId = (uint)(baseId + step + (int)JobType * 10);
        }
        
        //CMusicManager.GetInst().CreateSound(m_myTrans.gameObject, soundId);
        CreateSound(soundId);
    }

    protected override void LoadLeftWeaponCompleted(GameObject o, params object[] args)
    {
        base.LoadLeftWeaponCompleted(o, args);

        //初始化
        m_avatarLeftWeapon = m_pLeftWeaponObject;

        if (m_materialLeft != null)
            ChangeShaderToXRayAndBackLightVertex(m_materialLeft, true);
    }

    protected override void LoadRightWeaponCompleted(GameObject o, params object[] args)
    {
        base.LoadRightWeaponCompleted(o, args);

        //初始化
        m_avatarRightWeapon = m_pRightWeaponObject;

        if (m_materialRight != null)
            ChangeShaderToXRayAndBackLightVertex(m_materialRight, true);
    }

    public override void NpcDead(bool bNaturalDeath, CBaseNpc attack = null, bool fromMsg = false)
    {
        if (IsInRide())
        {
            EndRide(true);
        }

        if (IsInFly())
        {
            EndFly();
        }

        if (m_partnerFSM.CurrentState != null)
        {
            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Partner))
            {
                //m_isPartnerDead = true;
                PartnerDead = true;
            }
            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar))
            {
                AvatarDead = true;
            }
            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Partner) && !m_isAvatarDead)
            {
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.PartnerDie);
                RemoveNpcAttr();
                return;
            }

            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Partner) && (null != InActivePartner && !InActivePartner.Dead) )
            {
                ActivePartner.Dead = true;
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.PartnerDeadSwitch);
                RemoveNpcAttr();
                return;
            }

            if (m_partnerFSM.CurrentState.Equals(ePartnerState.Avatar) && !PartnerDead)
            {
                m_partnerFSM.TriggerEventQueued(ePartnerEvent.AvatarDie);
                RemoveNpcAttr();
                return;
            }

            if (m_partnerFSM.CurrentState.Equals(ePartnerState.SwitchingToAvatar) || m_partnerFSM.CurrentState.Equals(ePartnerState.SwitchingToPartner))
            {
                return;
            }
        }

        base.NpcDead(bNaturalDeath, attack, fromMsg);

        if ( (CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve ) && AvatarOnlineInfo.IsHost)
        {
            PvpMsgMgr.RequestEnterPvPBattleResult();
        }                
    }

    //受击喊叫
    public override void PlayBehitSound()
    {
        int soundID = 0;
        if (PartnerState == ePartnerState.Partner)
        {
            //小伙伴受击从partner表读取
            if (null == ActivePartner.PartnerLoader) return;

            soundID = ActivePartner.PartnerLoader.ModelLoader.BehitSoundID;
        }
        else
        {
            //其他的从player表读取
            if (null == m_pPlayerLoader) return;

            int index = Random.Range(0,m_pPlayerLoader.BehitSoundID.Count);
            soundID = m_pPlayerLoader.BehitSoundID[index];
        }

        CreateSound((uint)soundID);
    }

    //释放技能喊叫
    public override void PlaySkillSound() 
    {
        uint soundID = 0;
        if (PartnerState == ePartnerState.Partner)
        {
            //小伙伴受击从partner表读取
            if (null == ActivePartner.PartnerLoader.ModelLoader) return;

            soundID = (uint)ActivePartner.PartnerLoader.ModelLoader.SkillSoundID;
        }
        else
        {
            //其他的从player表读取
            if (null == m_pPlayerLoader) return;
            soundID = (uint)m_pPlayerLoader.SkillSoundID;
        }

        CreateSound(soundID);
    }

    public PartenrContent PartenrLoader
    {
        get
        {
            if ( null == ActivePartner) return null;
            
            return ActivePartner.PartnerLoader;
        }
        //get { return m_pPartnerLoader; }
    }

    public void ResetMpTimer()
    {
        if (null != m_pMpTimer)
        {
            m_pMpTimer.ResetTimer();
        }
    }

    public int GetMp()
    {
        return m_nMp;
    }

    public void SetMp(int mp)
    {
        m_nMp = mp;
    }

    public int GetMaxMp()
    {
        return m_nMaxMp;
    }

    public virtual void AddMp(int nMp)
    {
        if (m_pBattleScene.IsGameOver())
        {
            return;
        }

        m_nMp += nMp;

        if (m_nMp > m_nMaxMp)
        {
            m_nMp = m_nMaxMp;
        }

        if (m_nMp < 0)
        {
            m_nMp = 0;
        }

        //精力值面板更新...   
        //SingletonObject<RoleMediator>.GetInst().SetEnergyValue(m_nMp, m_nMaxMp);
    }

    //private float RunTo(Transform trans)
    //{
    //    float distance = Common.Get2DVecter3Length(trans.position, m_myTrans.position);
    //    //if (m_followTrans == trans)
    //    //{
    //    //    return distance;
    //    //}

        
    //    if (distance >= DEFINE.DEFAULT_IMMEDIATE_TURN_DISTANCE)
    //    {
    //        SetFollowTransform(trans, true);
    //    }
    //    else
    //    {
    //        Vector3 lookDirection = trans.position - m_myTrans.position;
    //        lookDirection.y = 0;
    //        UpdateTurn(lookDirection, true);
    //    }



    //    SetDestPosition(trans.position, true);
    //    CurrTarget = null;

    //    EnterState(eActionState.Run);
    //    return distance;
    //}

    public CInitiativeSkill GetAvailableSkill(CBaseNpc pTarget)
    {
        CInitiativeSkill pResultSkill = null;
        for (int i = 0, count = m_skillList.Count; i < count; ++i)
        {
            CInitiativeSkill pSkill = m_skillList[i];
            if (pSkill.CD != 0)
            {
                continue;
            }
            SkillContent pSkillInfo = pSkill.GetSkillInfo();
            if (pSkillInfo == null)
            {
                continue;
            }

            if (pTarget == null)
            {
                pResultSkill = pSkill;
                break;
            }
            else
            {
                if (IsInSkillRange((uint)pSkillInfo.Key, pTarget, eEffectRangeType.JudgeType))
                {
                    pResultSkill = pSkill;
                    break;
                }
            }
        }
        return pResultSkill;
    }

    public virtual void Resurrect(bool direct = false)
    {        
        m_partnerFSM.TriggerEvent(ePartnerEvent.Resurrect);

        if (!direct)
            m_pBattleScene.GameOver(false, false);

        m_stateMgr.Reuse();

        AddHp(m_pCard.nMaxHp);

        CreateHpComponent();

        CurrTarget = null;

        if (m_myTrans != null)
        {
            m_myTrans.gameObject.tag = DEFINE.AVATAR_OBJECT_TAG;
        }

        //这里设置两次IDLE是因为useskill的状态不能是dead,并且释放完技能回到idle状态
        //EnterState(eActionState.Idle);

        EnterState(eActionState.Resurrect);

        if (!direct)
        {
            this.Command(eCommandType.UseSkill, new UseSkillCommandArg(DEFINE.AVATAR_RESURRECT_SKILL, m_targetList, true));
        }
        else
        {
            LeaveState(eActionState.Resurrect);
        }
        
        //EnterState(eActionState.Idle);

        //m_ActionTimer.SetTimer(2);//两秒僵直

    }

    public Dictionary<uint, float> GetSkillCDs(ePartnerState pstate)
    {
        if (PartnerState == pstate)
        {
            return GetSkillCD();
        }
        else
        {
            Dictionary<uint, float> ret = new Dictionary<uint, float>();

            List<CInitiativeSkill> pskillList = null;
            if (pstate == ePartnerState.Avatar)
            {
                pskillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("avatarSkillList");
            }
            else if(pstate == ePartnerState.Partner)
            {
                //pskillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("partnerSkillList");
                pskillList = ActivePartner.SkillList;
            }

            if (pskillList != null)
            {
                for (int i = 0, count = pskillList.Count; i < count; ++i)
                {
                    CInitiativeSkill pSkill = pskillList[i];
                    SkillContent pSkillInfo = pSkill.GetSkillInfo();
                    if (pSkillInfo != null)
                    {
                        ret.Add((uint)pSkillInfo.Key, pSkill.CD);
                    }
                }
            }

            return ret;
        }
    }

    public void SetSkillCDs(ePartnerState pstate, Dictionary<uint, float> skillcds)
    {
        if (skillcds != null)
        {
            if (PartnerState == pstate)
            {
                foreach (KeyValuePair<uint, float> kvp in skillcds)
                {
                    SetSkillCD(kvp.Key, kvp.Value);
                }
            }
            else
            {
                List<CInitiativeSkill> pskillList = null;
                if (pstate == ePartnerState.Avatar)
                {
                    pskillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("avatarSkillList");
                }
                else if (pstate == ePartnerState.Partner)
                {
                    //pskillList = m_partnerFSM.GetParam<List<CInitiativeSkill>>("partnerSkillList");
                    pskillList = ActivePartner.SkillList;
                }

                if (pskillList != null)
                {
                    for (int i = 0, count = pskillList.Count; i < count; ++i)
                    {
                        CInitiativeSkill pSkill = pskillList[i];
                        SkillContent pSkillInfo = pSkill.GetSkillInfo();
                        if (skillcds.ContainsKey((uint)pSkillInfo.Key))
                        {
                            pSkill.CD = (uint)skillcds[(uint)pSkillInfo.Key];
                        }
                    }

                    if (pstate == ePartnerState.Avatar)
                    {
                        m_partnerFSM.StoreParam<List<CInitiativeSkill>>("avatarSkillList", pskillList);
                    }
                    else if (pstate == ePartnerState.Partner)
                    {
                        //m_partnerFSM.StoreParam<List<CInitiativeSkill>>("partnerSkillList", pskillList);
                        
                    }
                }
            }
        }
    }


    public override void SimpleMove(Vector3 dir, float speed)
    {
        Vector3 fDecelerateVector = dir.normalized * speed;

        if (null == m_myTrans)
        {
            return;
        }

        float deltaTime = 0f;
        if (m_pBattleScene.BattleType == eBattleType.Pvp || m_pBattleScene.BattleType == eBattleType.MultiPve)
        {
            deltaTime = PvpMsgMgr.PvpDeltaTime;
        }
        else
        {
            deltaTime = Time.deltaTime;
        }

        //float deltaTime = Time.deltaTime;
        //Debug.LogError(" deltaTime : " + deltaTime);

        if (null != m_characterController && m_characterController.enabled && m_myTrans.gameObject.activeInHierarchy)
        {
            Vector3 beforePos = m_myTrans.position;
            if (UnitsType != eNpcUnitsType.Ground)
            {
                m_characterController.Move(fDecelerateVector * deltaTime);
            }
            else
            {
                m_characterController.Move(fDecelerateVector * deltaTime - Vector3.up * 0.5f);                
            }
/*            Debug.LogError(" m_characterController : " + m_characterController.velocity.magnitude + " speed :  " + speed);*/
            if (fDecelerateVector == Vector3.zero)
            {
                m_myTrans.position = new Vector3(beforePos.x, m_myTrans.position.y, beforePos.z);
            }

            //MyLog.LogError(" SimpleMove position : " + m_myTrans.position);
            
            //Ray ray = new Ray(m_myTrans.position + Vector3.up * 20, Vector3.down);
            //RaycastHit hit;
            //if (Physics.Raycast(ray, out hit, 100, 1 << DEFINE.TERRAINLAYER))
            //{
            //    if (m_myTrans.position.y > hit.point.y + 0.3f)
            //    {
            //        m_myTrans.position = new Vector3(m_myTrans.position.x, hit.point.y + 0.3f, m_myTrans.position.z);
            //    }
            //}

            if (m_myTrans.position.y < -100)
            {
                if (!SingletonObject<PopFrameMediator>.GetInst().IsOpen)
                {
                    //SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(Common.GetText(), PopFrameType.singleOkButton, delegate() {
                    
                    //}, false);
                }
            }
        }
    }

    public override void Update()
    {
        base.Update();

        m_partnerFSM.Update();

        //MyLog.LogError(" m_tempCameraAncher.transform.position : " + m_tempCameraAncher.transform.position);
        //MyLog.Log("Action State: " + GetCurrActState());

        //if (Time.frameCount >= m_RideTimeFrameCount + 1)
        //{
        //    RideDelay();
        //}

        if (null != m_secondTimer && m_secondTimer.IsExpired(true))
        {
            if (!IsDead())
            {       
                //秒回
                if ((m_pCard.nSecondHpRate > 0 || m_pCard.fSecondHpRatePercent > 0) && m_nHp < m_pCard.nMaxHp)
                {
                    int nAddHp = m_pCard.nSecondHpRate;
                    nAddHp += Mathf.RoundToInt(m_pCard.fSecondHpRatePercent * m_pCard.nMaxHp);


                    if (ShowAddHpFlyWord(nAddHp))
                    {
                        SingletonObject<FlywordMediator>.GetInst().CreateFlyword(nAddHp, false, this);
                    }

                    AddHp(nAddHp);
                }      
                //精回
                if (m_pCard.nSecondMpRate > 0 && m_nMp < m_nMaxMp)
                {
                    //AddMp(m_pCard.nSecondMpRate);
                }
          
            }
        }

        if (m_replaceModelController != null && m_replaceModelController.enabled)
        {
            m_replaceModelController.SimpleMove(- Vector3.up * 0.5f);
            if (m_tempCameraAncher != null)
                m_tempCameraAncher.transform.position = m_replaceModelController.transform.position;
        }

        if (m_bakAnimator != null)
        {
            m_bakAnimator.Update();
        }

        if (m_mountAnimator != null)
        {
            m_mountAnimator.Update();
        }

        if (! m_bInPlatform && m_pMountTimer != null && m_rideState == eRideState.Ride)
        {
            if (m_bPausedCheck)
            {
                m_pMountTimer.AddExpireTime(Time.deltaTime);
            }
            if (m_pMountTimer.IsExpired(false) && NotInAction() && GetCurrActState() != eActionState.Skill)
            {
                EndRideState();
                m_pMountTimer.Release();
            }
        }

        if (!m_bInPlatform && m_pPetTimer != null && m_flyState == eFlyState.Fly)
        {
            if (m_bPausedCheck)
            {
                m_pPetTimer.AddExpireTime(Time.deltaTime);
            }
            if (m_pPetTimer.IsExpired(false) )
            {
                EndFlyDelay();
                m_pPetTimer.Release();
            }
        }

        if (null != m_pMpTimer && !IsDead())
        {
            if (m_nMp < m_nMaxMp)
            {
                //恢复精力值            
                if (m_pMpTimer.IsExpired(true))
                {
                    AddMp(1);
                }
            }
        }                

#if UNITY_EDITOR
        if (Input.GetKeyDown(KeyCode.L))
        {

            switch (m_flyState)
            {
                case eFlyState.BeginFly:
                    {
                    }
                    break;
                case eFlyState.Fly:
                    {
                        EndFlyDelay();
                    }
                    break;
                case eFlyState.EndFly:
                    {
                    }
                    break;
                case eFlyState.None:
                    {
                        BeginFly(true);
                    }
                    break;
            }
        }

        if (Input.GetKeyDown(KeyCode.K))
        {
            switch (m_rideState)
            {
                case eRideState.WaitRide:
                    {
                    }
                    break;
                case eRideState.Ride:
                    {
                        EndRideState();
                    }
                    break;
                case eRideState.None:
                    {
                        BeginRide(true);
                    }
                    break;
            }
        }
#endif

        //if (m_pPartnerLoader != null && m_partnerObj != null && m_partnerAnimator != null)
        {
            //小伙伴状态更新
            //m_partnerFSM.Update();
            //MyLog.Log(m_partnerFSM.CurrentState);
        }
    }



    /// <summary>
    ///  //前行
    /// </summary>
    /// <param name="fMaxDistance">最大移动距离</param>
    public Vector3 WalkForward(float fMaxDistance,bool sendMsg = false)
    {
        if (IsInFly())
        {
            return Vector3.zero;
        }

        Vector3 dstPosition = Vector3.one;
        if (null != m_myTrans)
        {
            dstPosition = m_myTrans.position + m_myTrans.forward * fMaxDistance;
//             if (sendMsg)
//             {
//                (this as Avatar).TriggerMoveHandler(dstPosition, eSyncMove.WalkForward);
//             }
//             else
//             {
//                 Command(eCommandType.RunTo, new RunToCommandArg(dstPosition, false, false));
//             }

            CheckRotateOrRun(dstPosition, false, true, sendMsg);
        }

        return dstPosition;
//         SetDestPosition(dstPosition, false);
//         CurrTarget = null;
// 
//         if ( GetCurrActState() != eActionState.Run)
//         {
//             EnterState(eActionState.Run);        
//         }        
    }



    public Vector3 RunForward(float fMaxDistance,bool sendMsg = false)
    {
        Vector3 dstPosition = Vector3.one;
        if (null != m_myTrans)
        {
            dstPosition = m_myTrans.position + m_myTrans.forward * fMaxDistance;
            //Command(eCommandType.RunTo, new RunToCommandArg(dstPosition, false, false));
            CheckRotateOrRun(dstPosition, false, true, sendMsg);
        }

        return dstPosition;

//         SetDestPosition(dstPosition, false);
//         CurrTarget = null;
// 
//         EnterState(eActionState.Run);
    }

    public override float PlayActionTime
    {
        get
        {
            if (IsInRide())
            {
                eActionState currState = m_stateMgr.GetCurrActState();
                switch (currState)
                {
                    case eActionState.Idle:
                    case eActionState.Run:
                        {
                            if (null == m_mountAnimator)
                            {
                                return -1f;
                            }
                            return m_mountAnimator.ActionTime;
                        }
                    case eActionState.Attack:
                        {
                            if (m_bakAnimator == null)
                            {
                                return -1f;
                            }
                            return m_bakAnimator.ActionTime;
                        }
                }
            }
            else if (IsInFly())
            {
                CAnimator pAnimator = m_myPet.GetCAnimator();
                eActionState currState = m_stateMgr.GetCurrActState();
                switch (currState)
                {
                    case eActionState.Idle:
                    case eActionState.Run:
                        {
                            if (null == pAnimator)
                            {
                                return -1f;
                            }
                            return pAnimator.ActionTime;
                        }
                    case eActionState.Attack:
                        {
                            if (m_bakAnimator == null)
                            {
                                return -1f;
                            }
                            return m_bakAnimator.ActionTime;
                        }
                }
            }
            return base.PlayActionTime;
        }
    }

//     public override CAnimatorStateInfo GetPlayAniState()
//     {
// 
//         if (IsInRide())
//         {
//             eActionState currState = m_stateMgr.GetCurrActState();
//             switch (currState)
//             {
//                 case eActionState.Idle:
//                 case eActionState.Run:
//                     {
//                         if (null == m_mountAnimator)
//                         {
//                             return null;
//                         }
//                         return m_mountAnimator.GetAnimatorInfo();
                    //}
//                     break;
//                 case eActionState.Attack:
//                     {
//                         if (m_bakAnimator == null)
//                         {
//                             return null;
//                         }
//                         return m_bakAnimator.GetAnimatorInfo();
                    //}
//                     break;
//             }
//         }
//         else if (IsInFly())
//         {
//             CAnimator pAnimator = m_myPet.GetCAnimator();
//             eActionState currState = m_stateMgr.GetCurrActState();
//             switch (currState)
//             {
//                 case eActionState.Idle:
//                 case eActionState.Run:
//                     {
//                         if (null == pAnimator)
//                         {
//                             return null;
//                         }
//                         return pAnimator.GetAnimatorInfo();
                    //}
//                     break;
//                 case eActionState.Attack:
//                     {
//                         if (m_bakAnimator == null)
//                         {
//                             return null;
//                         }
//                         return m_bakAnimator.GetAnimatorInfo();
                    //}
//                     break;
//             }
//         }
//         return base.GetPlayAniState();
//     }



    public override void PlayAction(string actionName, float fSpeed = 1.0f, bool bRepeat = false, PlayOnceFinised playCallBack = null,float fadeTime = 0.05f, object[] parms = null)
    {
        eActionState currState = m_stateMgr.GetCurrActState();

        if (IsInRide())
        {
            switch (currState)
            {
                case eActionState.Idle:
                case eActionState.Walk:
                case eActionState.BeginRide:
                case eActionState.EndRide:
                    {
                        if (m_mountAnimator != null)
                        {
                            m_mountAnimator.PlayAction(actionName, fSpeed, bRepeat);                            
                        }
                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction("qicheng", fSpeed, bRepeat,null,0);
                        }
                        return;
                    }
                    break;
                case eActionState.Run:
                    {
                        if (m_mountAnimator != null)
                        {
                            m_mountAnimator.PlayAction(actionName, fSpeed, bRepeat);
                        }
                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction("qicheng_run", fSpeed, bRepeat);
                        }
                        return;
                    }
                    break;
                case eActionState.Attack:
                    {
                        string aniName = "";
                        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
                        if (pcbsl.battleType == eBattleType.Arena)
                        {
                            aniName = stStateData.GetActionName(eActionState.Idle);

                        }
                        else
                        {
                            aniName = stStateData.GetActionName(eActionState.Run);

                            if (CurrTarget != null)
                            {
                                SetFollowTransform(CurrTarget.GetTransform(), false);
                            }
                            
                        }

                        if (m_mountAnimator != null)
                        {
                            m_mountAnimator.PlayAction(aniName, 1.0f, false);
                        }

                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction(actionName, fSpeed, bRepeat);
                        }

                        //骑马的时候一往无前
                        //if (NextPosition != Vector3.zero)
                        //{
                        //    Command(eCommandType.RunTo, new RunToCommandArg(pAvatar.NextPosition, immediateTurn));
                        //}

                        //Command(eCommandType.RunTo, new RunToCommandArg(m_myTrans.position + m_myTrans.forward * 1000, false));
                        return;
                    }
                    break;
                case eActionState.Skill:
                    {
                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction("qicheng", 1.0f, false, null, 0);
                        }

                        if (m_mountAnimator != null)
                        {
                            m_mountAnimator.PlayAction(actionName, fSpeed, bRepeat);
                        }

                        return;
                    }
                    break;
                case eActionState.RideJump:
                    {
                        if (m_pAnimator != null)
                        {
                            m_pAnimator.PlayAction(actionName, 1.0f, true,null,0f);
                        }
                        if (m_mountAnimator != null)
                        {
                            m_mountAnimator.PlayAction("jump", 1.0f, true,null,0f) ;
                        }
                        return;
                    }
                    break;
            }
        }
        else if (IsInFly())
        {
            CAnimator pAnimator = m_myPet.GetCAnimator();
            switch (currState)
            {
                case eActionState.Idle:
                case eActionState.Run:
                case eActionState.Walk:
                    {
                        if (pAnimator != null)
                        {
                            pAnimator.PlayAction(actionName, fSpeed, bRepeat);
                        }
                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction("kongzhan", fSpeed, bRepeat);
                        }
                        return;
                    }
                    break;
                case eActionState.Attack:
                case eActionState.Skill:
                    {
                        string runName = stStateData.GetActionName(eActionState.Idle);
                        if (pAnimator != null)
                        {
                            pAnimator.PlayAction(runName, 1.0f, false);
                        }

                        if (m_bakAnimator != null)
                        {
                            m_bakAnimator.PlayAction(actionName, fSpeed, bRepeat);
                        }
                        return;
                    }
                    break;
            }
        }

        base.PlayAction(actionName, fSpeed, bRepeat,null,fadeTime);
    }


    public virtual void CheckRotateOrRun(Vector3 destPosition, bool bDirectionTurn, bool bUsePathFinding, bool sendMsg = false)
    {
        //Debug.Log("CheckRotateOrRun .. dest : " + destPosition +" , "  + m_myTrans.position );
        if (IsDirectionHasEnemyInRange(destPosition))
        {
            Command(eCommandType.Turning, new TurningCommandArg(destPosition));
        }
        else
        {
            Command(eCommandType.RunTo, new RunToCommandArg(destPosition, bDirectionTurn, bUsePathFinding, sendMsg));
        }
    }

    protected override GameObject GetEffectBindObject()
    {
        if (IsInFly() && m_bakObject != null)
        {
            return m_bakObject.GetObj();
        }
        return base.GetEffectBindObject();
    }

    public Vector3 NextPosition
    {
        get
        {
            return m_NextPosition;
        }
        set
        {
            m_NextPosition = value;
        }
    }

    public override eNpcBehaviour CheckNpcBehaviour()
    {
        if (m_rideState == eRideState.WaitRide || m_rideState == eRideState.RideDelay)
        {
            return eNpcBehaviour.None;
        }
        if (m_flyState == eFlyState.BeginFly || m_flyState == eFlyState.EndFly)
        {
            return eNpcBehaviour.None;
        }
        return base.CheckNpcBehaviour();
    }


    protected PlatformReceiveMessage AddPlatformReceiveMessage(GameObject o)
    {
        PlatformReceiveMessage prm = o.GetComponent<PlatformReceiveMessage>();
        if (null == prm)
        {
            prm = o.AddComponent<PlatformReceiveMessage>();
        }

        return prm;
    }

    protected void RemovePlatformReceiveMessage(GameObject o)
    {
        PlatformReceiveMessage prm = o.GetComponent<PlatformReceiveMessage>();
        if (null != prm)
        {
            UnityEngine.Object.Destroy(prm);
        }
    }

  
    /// <summary>
    /// 
    /// </summary>
    /// <param name="platformObj"></param>
    public virtual void EnterPlatform(GameObject platformObj)
    {
        SetEnterPlatform(platformObj);
    }

    public void SetEnterPlatform(GameObject platformObj) 
    {
        m_bInPlatform = true;

        if (IsInFly())
        {
            EndFly();
        }

        if (IsInRide())
        {
            EndRide(true);
        }
        if (null != m_myTrans)
        {
            Transform child = platformObj.transform.GetChild(0);
            if ( null != child )
            {
                m_myTrans.parent = child.transform;
            }
            else
            {
                m_myTrans.parent = platformObj.transform;
            }

        }

        SetDestPosition(platformObj.transform.position, false);
        EnterState(eActionState.Run);        
    }

//     void DelayCloseAllWindow(params object[] args)
//     {
//         UIManager.GetInst().CloseAllWnd();
// 
//     }

    public virtual void LeavePlatform(GameObject platformObj)
    {
        m_bInPlatform = false;
        m_lastUpdatePosition = Vector3.zero;

        m_myTrans.parent = null;

        if (m_allyList.Count > 0)
        {
            for (int i = 0, len = m_allyList.Count; i < len; i++)
            {
                CBaseNpc allyNpc = m_pBattleScene.GetNpc(m_allyList[i]);
                if (null != allyNpc && !allyNpc.IsDead())
                {
                    allyNpc.SetPosition(m_myTrans.position, true);
                }
            }
        }

        SetNavmeshEnable(false);
        m_followObj.transform.localPosition = Vector3.zero;
        SetNavmeshEnable(true);

    }

    public void SetLeavePlatform(GameObject platformObj)
    {
        m_bInPlatform = false;
        m_lastUpdatePosition = Vector3.zero;

        m_myTrans.parent = null;

        if (m_allyList.Count > 0)
        {
            for (int i = 0, len = m_allyList.Count; i < len; i++)
            {
                CBaseNpc allyNpc = m_pBattleScene.GetNpc(m_allyList[i]);
                if (null != allyNpc && !allyNpc.IsDead())
                {
                    allyNpc.SetPosition(m_myTrans.position, true);
                }
            }
        }

        SetNavmeshEnable(false);
        m_followObj.transform.localPosition = Vector3.zero;
        SetNavmeshEnable(true);
    }

    public override void Release(eObjectDestroyType type)
    {
        Courageous = false;
        TwoPartner = false;
        m_pAtkDragon = null;

        if (IsInRide())
        {
            EndRide(true);
        }

        if (IsInFly())
        {
            EndFly();
        }



        if (m_directPoint != null)
        {
            UnityEngine.Object.Destroy(m_directPoint);
        }

        if (m_materiaslCount > 0)
        {
            for (int i = 0; i < m_materiaslCount; i++)
            {
                if (Materials[i] != null)
                    Materials[i].shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
            }
        }
        if (m_materialLeft)
            m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if(m_materialRight)
            m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        //if(m_materialPartner)
        //    m_materialPartner.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

//         if(m_materialPartnerLeft)
//             m_materialPartnerLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
// 
//         if (m_materialPartnerRight)
//             m_materialPartnerRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        for ( int i = 0, len = m_PartnerList.Count; i < len; i++ )
        {
            CPartner partner = m_PartnerList[i];
            partner.Release(type);
        }

        if(m_mountMat)
            m_mountMat.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_mountObj != null)
        {
            m_mountObj.DestroyGameObject(type);
            m_mountObj = null;
        }

//         if (m_partnerObj != null)
//         {
//             m_partnerObj.DestroyGameObject(type);
//             m_partnerObj = null;
//         }

        if (m_partnerFSM != null)
        {
            m_partnerFSM.Clear();
        }

		//m_isPartnerDead = false;
		//m_isAvatarDead = false;
		//m_pPartnerLoader = null;

//         if (m_partnerObj != null)
//         {
//             m_partnerObj.DestroyGameObject(type);
//             m_partnerObj = null;
//         }

        if (m_avatarObj != null)
        {
            m_avatarObj.DestroyGameObject(type);
            m_avatarObj = null;
        }
		
		//m_partnerAnimator = null;
		m_avatarAnimator = null;
        m_myPet = null;

//         if (m_partnerLeftWeapon != null)
//         {
//             m_partnerLeftWeapon.DestroyGameObject(type);
//             m_partnerLeftWeapon = null;
//         }
// 
//         if (m_partnerRightWeapon != null)
//         {
//             m_partnerRightWeapon.DestroyGameObject(type);
//             m_partnerRightWeapon = null;
//         }

        if (m_avatarLeftWeapon != null)
        {
            m_avatarLeftWeapon.DestroyGameObject(type);
            m_avatarLeftWeapon = null;
        }

        if (m_avatarRightWeapon != null)
        {
            m_avatarRightWeapon.DestroyGameObject(type);
            m_avatarRightWeapon = null;
        }

        if (m_replaceModelController != null)
        {
            UnityEngine.Object.Destroy(m_replaceModelController.gameObject);
            m_replaceModelController = null;
        }

        m_bUseRide = false;
        m_bUseFly = false;

		m_jumpRadius = 15.5f;
		m_switchTime = 0.75f;
		//m_partnerLifePercent = 1.0f;
		m_avatarLifePercent = 1.0f;


        m_bakPlayerSkillList.Clear();

        base.Release(type);

    }

    public override void RemoveNpc()
    {
        base.RemoveNpc();

        if (!IsChest())
        {
            m_pBattleScene.RemoveNpc(m_uiIndex);
        }
        if (m_myTrans.gameObject.activeSelf)
            m_myTrans.gameObject.SetActive(false);
        for (int i = 0; i < m_materiaslCount; i++)
        {
            if (Materials[i] != null)
                Materials[i].shader = DynamicShader.GetShader(m_material0Name);
        }
        if (m_materialLeft)
            m_materialLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);
        if (m_materialRight)
            m_materialRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_smr != null && m_smr.Length > 0)
        {
            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = Materials;
                    break;
                }
            }
        }
    }




    protected override void ChangeAlphaVertexColor(bool add)
    {
        if (m_materiaslCount <= 0)
        {
            MyLog.LogError("ChangeAlphaVertexColor " +this.GetType().ToString() + " Path : " + m_pNpcObj.Path + "\t Materials count is 0");
            m_liveState = eLiveState.NONE;
            return;
        }
        if (add)
        {
            m_alphaVertexAlpha += m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
        }
        else
        {
            m_alphaVertexAlpha -= m_alphaVertexSpeed * Timer.GetTimeForDateTime(Time.deltaTime);
        }

        m_alphaVertexAlpha = Mathf.Clamp01(m_alphaVertexAlpha);

        //if (m_alphaVertexAlpha > 0)
        //{
        //    ShowNpc(true);
        //}
        //else
        //{
        //    ShowNpc(false);
        //}

        if (m_materiaslCount <= 0)
            MyLog.LogError(this.GetType().ToString() + " Materials is not get,Count is 0");

        //for (int i = 0; i < m_materiaslCount; ++i)
        //{
        //    Materials[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        //}



        int count = m_materialsList.Count;
        for (int i = 0; i < count; i++)
        {
            if (m_materialsList[i] != null)
            {
                if (m_materialsList[i].HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
                    m_materialsList[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
                else if (m_materialsList[i].HasProperty("_Alpha"))
                    m_materialsList[i].SetFloat("_Alpha", m_alphaVertexAlpha);
            }
        }

        if (m_materialLeft != null && m_materialLeft.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_materialLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        }
        if (m_materialRight != null && m_materialRight.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_materialRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        }

        if (m_mountMat != null && m_mountMat.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_mountMat.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        }

        if ( null != ActivePartner )
        {
            ActivePartner.ChangeAlphaVertexColor(m_alphaVertexAlpha);
        }        

        //if (m_materialPartner != null)
        //{
        //    m_materialPartner.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        //}

//         if (m_materialPartnerLeft != null)
//         {
//             m_materialPartnerLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
//         }
// 
//         if (m_materialPartnerRight != null)
//         {
//             m_materialPartnerRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
//         }

        if (m_directPoint != null)
        {
            m_directPoint.transform.GetChild(0).GetChild(0).renderer.material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
            m_directPoint.transform.GetChild(0).GetChild(1).renderer.material.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        }


        //int count = m_materialsList.Count;
        //for (int i = 0; i < count; i++)
        //{
        //    if (m_materialsList[i] != null)
        //        m_materialsList[i].SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, m_alphaVertexAlpha);
        //}

        if (m_alphaVertexAlpha % 1f == 0f)
        {
            if (add && m_alphaVertexAlpha == 1)
            {
                m_liveState = eLiveState.NONE;
                if (m_materiaslCount > 0)
                    ChangeShaderToXRayAndBackLightVertex(Materials[0], true);
                if (m_materialLeft)
                    ChangeShaderToXRayAndBackLightVertex(m_materialLeft, true);
                if(m_materialRight)
                    ChangeShaderToXRayAndBackLightVertex(m_materialRight, true);
                if(m_mountMat)
                    ChangeShaderToXRayAndBackLightVertex(m_mountMat, true);

                if ( null != ActivePartner )
                {
                    ActivePartner.ChangeShaderToXRay();
                }                
//                 if(m_materialPartnerLeft)
//                     ChangeShaderToXRayAndBackLightVertex(m_materialPartnerLeft, true);
//                 if (m_materialPartnerRight)
//                     ChangeShaderToXRayAndBackLightVertex(m_materialPartnerRight, true);
//                 if (m_materialPartner)
//                     ChangeShaderToXRayAndBackLightVertex(m_materialPartner, true);

                m_currShaderName = m_material0Name;
            }
            else if (!add && m_alphaVertexAlpha == 0)
            {
                m_liveState = eLiveState.NONE;
            }
        }
    }

    public override void AddMaterials(bool restore = true, int index = 0)
    {
        if (m_smr == null || m_smr.Length <= 0)
        {
            MyLog.LogError("AddMaterials Avatar SkinMeshRenderer is null or length is 0");
            return;
        }

        if (Materials == null || m_materiaslCount <= 0)
        {
            MyLog.LogError("AddMaterials Avatar Materials count is 0");
            return;
        }

        if (restore)
        {
            if (Materials == null)
                return;

            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = Materials;
                    break;
                }
            }
        }
        else
        {
            Material material = DynamicShader.GetMaterials(index);
            if (material == null)
            {
                return;
            }

            Material[] materials = new Material[m_materiaslCount + 1];
            for (int i = 0; i < m_materiaslCount; i++)
            {
                materials[i] = Materials[i];
            }
            materials[m_materiaslCount] = material;

            for (int i = 0; i < m_smr.Length; i++)
            {
                if (!m_smr[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_smr[i].materials = materials;
                    break;
                }
            }
        }
    }


    private void GetMaterialsList()
    {
        m_materialsList.Clear();

        if (m_pNpcObj == null)
            return;

        GameObject gameObjectTemp = m_pNpcObj.gameCObject;

        if (gameObjectTemp == null)
            return;

        Renderer[] renderers = gameObjectTemp.GetComponentsInChildren<Renderer>();

        if (renderers == null)
            return;

        m_materialsList.AddRange(Materials);

        int count = renderers.Length;
        Material material;

        for (int i = 0; i < count; i++)
        {
            material = renderers[i].material;
            if (m_materialsList.Contains(material))
                continue;

            m_materialsList.Add(material);
        }
    }

    public override void SetNavmeshObstacleEnable(bool enable)
    {
        base.SetNavmeshObstacleEnable(enable);

        if (IsInRide())
        {
            if (m_nmo != null) m_nmo.enabled = false;
        }
    }

    public override void SetNavmeshEnable(bool enable)
    {
        base.SetNavmeshEnable(enable);

        if (IsInRide())
        {
            if (m_nmo != null) m_nmo.enabled = false;
        }
    }


    public override eNpcSortType GetNpcSortType()
    {
        return (eNpcSortType)m_pPlayerLoader.Sort;
    }
    public override List<float> GetAniMoveSpeed()
    {
        return m_pPlayerLoader.m_AniMoveSpeed;
    }
    public override float GetMaxMoveSpeed()
    {
        return m_pPlayerLoader.m_MaxMoveSpeed;
    }

    public override bool IsKill()
    {
        return true;
    }
    public override bool IsHitDown()
    {
        return true;
    }
    public override bool IsBeatFly()
    {
        return true;
    }
    public override bool IsCanStun()
    {
        return true;
    }
    public override bool IsSlow()
    {
        return true;
    }
    public override int GetDeadActID()
    {
        return m_pPlayerLoader.m_DeadActID;
    }
    public override float GetRigidity()
    {
        return m_pPlayerLoader.Rigidity;
    }

    public override string GetName()
    {
        return Common.GetText(m_pPlayerLoader.NpcName);
    }

}
