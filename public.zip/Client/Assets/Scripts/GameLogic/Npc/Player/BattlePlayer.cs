﻿using UnityEngine;
using System.Collections.Generic;

public class BattlePlayer : BaseBattlePlayer {

    private uint m_iAI = 0;
    public new uint AI{set { m_iAI = value; }}

    private uint[] m_skills;
    public uint[] Skills{set { m_skills = value; }}

    private bool m_bMountLoadCompleted = false;
    public bool BMountLoadCompleted { get { return m_bMountLoadCompleted; } }

    private bool m_bPetLoadCompleted = false;
    public bool BPetLoadCompleted { get { return m_bPetLoadCompleted; } }

    private uint m_mountID;
    public uint Mount_ID{get { return m_mountID; }set { m_mountID = value; }}

    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.UNTAGGED_OBJECT_TAG)
    {
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);
        InitFSM();
    }

    public void LoadMount()
    {
        m_pMountLoader = HolderManager.m_MountsHolder.GetStaticInfo(m_mountID);
        if (null == m_pMountLoader)
        {
            MyLog.LogError("BattlePlayer MountsContent is null mountID = " + m_mountID.ToString());
            return;
        }
        LoadHelp.LoadObject("mount~" + m_pMountLoader.ModelLoader.MountsModelPath, m_pMountLoader.ModelLoader.MountsModelPath, ThreadPriority.Normal, LoadMountOrPetCompleted);
    }

    public void LoadPet(uint petID)
    {
        PetContent m_pPetLoader = HolderManager.m_PetHolder.GetStaticInfo(petID);
        if (null == m_pPetLoader)
        {
            MyLog.LogError("BattlePlayer MountsContent is null mountID = " + petID.ToString());
            return;
        }
        LoadHelp.LoadObject("pet~" + m_pPetLoader.ModelLoader.Path, m_pPetLoader.ModelLoader.Path, ThreadPriority.Normal, LoadMountOrPetCompleted);
    }

    protected override void LoadAI()
    {
        base.LoadAI();

        Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();
        if (m_skills != null)
        {
            foreach (int uiSkillID in m_skills)
            {
                if (uiSkillID == 0)
                    continue;
                SkillContent csl = HolderManager.m_SkillHolder.GetStaticInfo(uiSkillID);
                if (csl != null)
                {
                    skillDict.Add(uiSkillID, null);
                }
            }
        }
        skillDict.Add(m_pPlayerLoader.NormalSkill, null);

        if (m_pAI != null)
        {
            m_pAI.SetAI(m_iAI, null, skillDict);
        }
    }

    private void LoadMountOrPetCompleted(string msg, Object asset)
    {
        if (asset == null)
        {
            MyLog.LogError("BattlePlayer LoadMountCompleted Load Mount Fail");
            return;
        }
        string[] args = msg.Split('~');
        string szPath = args[1].Replace("_model", "_ctrl");
        LoadHelp.LoadObject(args[0], szPath, ThreadPriority.Normal, LoadMounOrPettAnimatorCtrlCompleted);
    }

    private void LoadMounOrPettAnimatorCtrlCompleted(string msg, Object asset)
    {
        if (asset == null)
        {
            MyLog.LogError("BattlePlayer LoadMountAnimatorCtrlCompleted Load Mount Fail");
            return;
        }
        if (msg.Equals("mount"))
            m_bMountLoadCompleted = true;
        else
        {
            m_bPetLoadCompleted = true;
        }
    }

}
