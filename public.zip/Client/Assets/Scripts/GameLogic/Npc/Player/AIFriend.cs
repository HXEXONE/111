﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AIFriend : BaseBattlePlayer
{
    protected bool m_bAvatarLastFrameInPlatform = false;


    protected override void LoadAI()
    {
        base.LoadAI();

        //Dictionary<uint, uint> skillDict = new Dictionary<uint, uint>();
        Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();

        //读取助战好友技能技能
        stFriendInfo friendInfo = SingletonObject<FriendManager>.GetInst().GetFightFriend();
        for (int i = 0, len = friendInfo.skillList.Count; i < len; i++ )
        {
            CSkillupInfo info = friendInfo.skillList[i];
            skillDict.Add(info.skilluploader.SkillId, info);
        }

        skillDict.Add(m_pPlayerLoader.NormalSkill, null);
        
        if (m_pAI != null)
        {
            m_pAI.SetAI(DEFINE.FRIEND_BASE_AI_ID, null, skillDict);
        }
    }

    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.AIFRIEND_OBJECT_TAG)
    {
        tag = DEFINE.AIFRIEND_OBJECT_TAG;
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);
        InitFSM();

        battlescene.EnterDynamicEvent += onActiveDynamic;
    }

    private void onActiveDynamic(bool guangmu,bool chuansong) 
    {
        if (guangmu)
        {
            Avatar pAvatar = SingletonObject<Avatar>.GetInst();
            float distance = Common.Get2DVecter3Length(pAvatar.GetPosition(), m_myTrans.position);

            Ray ray = new Ray(m_myTrans.position + Vector3.up, pAvatar.GetPosition() - m_myTrans.position + Vector3.up);

            if (Physics.Raycast(ray, distance, 1 << DEFINE.AIR_WALL))
            {
                Vector3 sumpos = m_pBattleScene.SummonPosition(pAvatar.GetPosition(), pAvatar.CharacterRadius, false, this, this.NpcCollider);
                SetPosition(sumpos, true);
            }
        }        
    }


    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        base.LoadNpcCompleted(o, args);

        Avatar pAvatar = SingletonObject<Avatar>.GetInst();

        AddRangeNpc(pAvatar);

        Common.IgnoreCollision(pAvatar.NpcCollider, NpcCollider, true);
        //Physics.IgnoreLayerCollision(DEFINE.AIFRIEND_LAYER, DEFINE.AIR_WALL,true);
        //pAvatar.npcco
    }

    public override void Update()
    {
        base.Update();

        //MyLog.Log(GetCurrActState());
#if UNITY_EDITOR

//         if (Input.GetKeyDown(KeyCode.K))
//         {
//             AddHp(-this.GetMaxHp() - 1);
//         }
#endif

        if (m_pBattleScene != null && m_pBattleScene.IsGameOver())
        {
            if (m_pHpPanel != null)
            {
                RemoveHpPanel();
            }
        }

        Avatar pavatar = SingletonObject<Avatar>.GetInst();
        if (pavatar != null)
        {
            if (pavatar.InPlatform)
            {
                m_bAvatarLastFrameInPlatform = true;
            }
            else if (m_bAvatarLastFrameInPlatform)
            {
                Vector3 destPos = m_pBattleScene.SummonPosition(pavatar.GetPosition(), this.CharacterRadius,false, pavatar, pavatar.NpcCollider);

                this.SetPosition(destPos);
                m_bAvatarLastFrameInPlatform = false;
            }            
        }
    }

    public override void Release(eObjectDestroyType type)
    {
        base.Release(type);

        m_pBattleScene.EnterDynamicEvent -= onActiveDynamic;
    }
}
