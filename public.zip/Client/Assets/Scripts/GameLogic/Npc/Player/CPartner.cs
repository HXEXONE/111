﻿using Protocol;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//小伙伴类
public class CPartner
{
    private PartenrContent m_pPartnerLoader = null;
    
    private float m_fLifePercent;
    public float LifePercent
    {
        set { m_fLifePercent = value; }
        get { return m_fLifePercent; }
    }

    private bool m_bDead;
    public bool Dead
    {
        get { return m_bDead; }
        set 
        {
            m_bDead = value;
            if (value)
            {
                m_fLifePercent = 0f;
                m_bActive = false;
            }
        }
    }

    private bool m_bCanKill;
    public bool CanKill
    {
        get { return m_bCanKill; }
        set { m_bCanKill = value; }
    }

    private bool m_bActive;
    public bool Active
    {
        get { return m_bActive; }
        set
        {
            m_bActive = value;
            if ( null != m_pDragonshard) //龙晶
            {
                m_pDragonshard.Active = value;
            }
        }
    }

    private BaseBattlePlayer m_pParentNpc; //Avatar  或者  EnemyAvatar

    private Dragonshard m_pDragonshard; //伙伴龙晶    
    public Dragonshard Dragonshard
    {
        get { return m_pDragonshard; }
    }

    private CObject m_Obj;
    private CAnimator m_pAnimator;

    private CObject m_LeftWeapon;
    public CObject LeftWeapon 
    {
        get { return m_LeftWeapon; }
    }

    private CObject m_RightWeapon;
    public CObject RightWeapon 
    {
        get { return m_RightWeapon; }
    }

    private Material m_materialPartnerLeft;
    public Material LeftMat
    {
        get { return m_materialPartnerLeft; }
    }

    private Material m_materialPartnerRight;
    public Material RightMat
    {
        get { return m_materialPartnerRight; }
    }

    private Material m_materialPartner;

    private List<CInitiativeSkill> m_skillList = new List<CInitiativeSkill>();
    public List<CInitiativeSkill> SkillList 
    {
        get { return m_skillList; }
    }

    private uint m_uiDeafaultSkill = 0;
    public uint DeafaultSkill 
    {
        get { return m_uiDeafaultSkill; }
    }

    private stCharacterCard m_pCard = new stCharacterCard(1);
    public stCharacterCard Card
    {
        get { return m_pCard; }
        set 
        {
            if (ClientMain.GetInst().EnterTestScene) 
            {
                m_pCard = value;//只在测试场景赋值
            }
        }
        
    }

    private float mBodyHeight;

    private PartnerSortItem m_SortItem;
    public PartnerSortItem PartenrSortItem { get { return m_SortItem; } set { m_SortItem = value; } }
    public CPartner(PartnerSortItem sortItem,BaseBattlePlayer parentNpc)
    {
        m_bDead = false;
        m_bActive = false;
        m_SortItem = sortItem;
        m_pParentNpc = parentNpc;
        m_pDragonshard = null;

        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
        eBattleType battleType = pcbsl.battleType;

        //m_fLifePercent = pcbsl.battleType == eBattleType.Wasteland ? sortItem.PartnerHpPre : 1.0f;
        if (battleType == eBattleType.Wasteland || battleType == eBattleType.Mining)
        {
            m_fLifePercent = sortItem.PartnerHpPre;
        }
        else
        {
            m_fLifePercent = 1.0f;
        }

//        if (battleType == eBattleType.Pvp)
//        {
//            m_bCanKill = AvatarOnlineInfo.IsHost;
//        }

        //MyLog.LogError(parentNpc + " PartnerHpPre : " + m_fLifePercent);

        m_pPartnerLoader = m_SortItem.loader;

        m_uiDeafaultSkill = (uint)m_pPartnerLoader.ModelLoader.NormalAtkID;

        //m_uiDeafaultSkill = m_SortItem.loader.normalAtkID;
       

        if ( null != sortItem.info)
        {
            if (!ClientMain.GetInst().EnterTestScene)
            {
                AttrValue.GetAttrVec(ref m_pCard, sortItem.info.attrVec);
                m_pCard = m_pCard.Decode();
            }
        }

        List<SkillCell> skillcesList = m_SortItem.info.vecSkillList;
        for (int i = 0, len = skillcesList.Count; i < len; i++)
        {
            SkillCell cell = skillcesList[i];
            SkillUpContent skillupLoader = HolderManager.m_SkillUpHolder.GetStaticInfo(cell.ID);//skillupID
            if (null == skillupLoader)
                continue;

            SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(skillupLoader.SkillId);
            if (pSkillLoader != null)
            {
                CSkillupInfo info = new CSkillupInfo((ushort)cell.Level, skillupLoader);
                CInitiativeSkill pskill = new CInitiativeSkill((uint)skillupLoader.SkillId, info, (ushort)i);
                m_skillList.Add(pskill);
            }
        }

        //伙伴龙晶
//         CrystalItemInfo crystalItemInfo = LongjingManager.GetInst().PartnerLongJing(m_pPartnerLoader.Key);
//         if (null != crystalItemInfo)
//         {
//             //创建龙晶
//             m_pDragonshard = new Dragonshard(crystalItemInfo, m_pParentNpc, this);
//         }

        CrystalItemInfo crystalItemInfo = sortItem.longJingItem;
        if ( null != crystalItemInfo && crystalItemInfo.uiCrystalId != 0)
        {
            //创建龙晶
            m_pDragonshard = new Dragonshard(crystalItemInfo, m_pParentNpc, this);
        }

    }
    

    public PartenrContent PartnerLoader
    {
        //get { return m_SortItem.loader; }
        get { return m_pPartnerLoader; }
    }
    
    public Transform Trans
    {
        get { return m_Obj.transform; }
    }

    public GameObject Go
    {
        get { return m_Obj.gameCObject; }
    }

    public CObject Object
    {
        get { return m_Obj; }
    }

    public CAnimator CAnimator
    {
        get { return m_pAnimator; }
    }

    public bool Enabled
    {
        set { m_Obj.gameCObject.SetActive(value); }
    }

    public void PlayAction(string name,float speed = 1.0f,bool repeat = false) 
    {
        m_pAnimator.PlayAction(name, speed, repeat);
    }


    public void CreateObj(Vector3 position,Quaternion rotaion,bool replace = false)
    {
        m_Obj = new CObject(m_pPartnerLoader.ModelLoader.ModelRes);
        m_Obj.Layer = DEFINE.AVATAR_LAYER;
        m_Obj.BornPosition = position;
        m_Obj.BornRotation = rotaion;
        m_Obj.CallBack = LoadPartnerCompleted;
        m_Obj.IsMemoryFactory = true;
        m_Obj.ObjectType = eObjectType.Partner;
        m_Obj.Args = new object[] { replace };
        m_Obj.LoadObject();
    }

    private void LoadPartnerCompleted(GameObject o, params object[] args)
    {
        if ( null == o )
        {
            m_pPartnerLoader = HolderManager.m_PartenrHolder.GetStaticInfo(DEFINE.REPLACE_PARTNER_LOADER_KEY);
            CreateObj(m_Obj.BornPosition, m_Obj.BornRotation, true);
            return;
        }

        bool replace = (bool)m_Obj.Args[0];
        if (replace)
        {
            Common.MaterialCulling(o);
        }

        //载入小伙伴动画
        string szPath = m_pPartnerLoader.ModelLoader.ModelRes;
        szPath = szPath.Replace("_model", "_ctrl");
        LoadHelp.LoadObject("", szPath, ThreadPriority.Normal, LoadPartnerAnimatorCtrl);
        SkinnedMeshRenderer[] psmrs = o.GetComponentsInChildren<SkinnedMeshRenderer>();
        if (psmrs.Length > 0 && psmrs[0].material)
        {
            for (int i = 0; i < psmrs.Length; i++)
            {
                if (!psmrs[i].tag.Equals(DEFINE.OTHER_SKINNED))
                {
                    m_materialPartner = psmrs[i].material;
                    break;
                }
            }
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartner, true);
        }
        //载入小伙伴武器
        EquipContent pWeaponLoader = HolderManager.m_EquipHolder.GetStaticInfo(m_pPartnerLoader.ModelLoader.WeaponID);
        if (pWeaponLoader != null)
        {
            List<string> pathArray = pWeaponLoader.ModelLoader.ModelPath;
            if (!pathArray[0].Equals("0"))
            {
                m_LeftWeapon = new CObject(pathArray[0]);
                m_LeftWeapon.CallBack = LoadPartnerLeftWeaponCompleted;
                m_LeftWeapon.IsMemoryFactory = true;
                m_LeftWeapon.ObjectType = eObjectType.Weapon;
                m_LeftWeapon.Layer = DEFINE.AVATAR_LAYER;
                m_LeftWeapon.LoadObject();
            }

            if (!pathArray[1].Equals("0"))
            {
                m_RightWeapon = new CObject(pathArray[1]);
                m_RightWeapon.CallBack = LoadPartnerRightWeaponCompleted;
                m_RightWeapon.IsMemoryFactory = true;
                m_RightWeapon.ObjectType = eObjectType.Weapon;
                m_RightWeapon.Layer = DEFINE.AVATAR_LAYER;
                m_RightWeapon.LoadObject();
            }

        }

        SkinnedMeshRenderer[] smrs = o.GetComponentsInChildren<SkinnedMeshRenderer>(true);
        if (smrs.Length > 0)
            mBodyHeight = smrs[0].bounds.size.y;
        else
            mBodyHeight = 2.0f; //默认高度

        //设置小伙伴名字与主角一致
        o.name = m_pParentNpc.Index.ToString();
        //小伙伴加载完后设置
        o.SetActive(m_bActive);

        if ( null != m_pDragonshard)
        {
            m_pDragonshard.BindParentTransfrom(mBodyHeight);
        }        

    }

    private void LoadPartnerAnimatorCtrl(string interim, UnityEngine.Object asset)
    {
        if (null == asset) { MyLog.LogError("" + interim); return; }
        GameObject go = (GameObject)asset;

        Animator animator = go.GetComponent<Animator>();
        if (animator == null)
        {
            MyLog.LogError(" can not find animator source: " + go.name);
            return;
        }

        if ( null != m_Obj )
        {
            GameObject o = m_Obj.GetObj();
            Animator aniCtrl = o.GetComponent<Animator>();
            if (null == aniCtrl)
            {
                aniCtrl = o.gameObject.AddComponent<Animator>();

            }
            aniCtrl.runtimeAnimatorController = animator.runtimeAnimatorController;
            //aniCtrl.avatar = animator.avatar;

            m_pAnimator = new CAnimator(aniCtrl);
        }


        if (m_bActive)
        {
            m_pParentNpc.ChangeModel(m_Obj, m_pAnimator);
        }

    }

    private void LoadPartnerLeftWeaponCompleted(GameObject o, params object[] args)
    {
        Transform bonetrans = Common.GetBone(m_Obj.transform, "Bip01 Prop2");
        if (null == bonetrans)
        {
            return;
        }
        if (null == o) {return; }
        o.transform.parent = bonetrans;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        m_materialPartnerLeft = o.renderer.material;
        if (Active)
        {
            m_pParentNpc.MatLeft = m_materialPartnerLeft;
        }
      
        if (m_materialPartnerLeft)
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartnerLeft, true);
    }

    private void LoadPartnerRightWeaponCompleted(GameObject o, params object[] args)
    {
        Transform bonetrans = Common.GetBone(m_Obj.transform, "Bip01 Prop1");
        if (null == bonetrans)
        {
            return;
        }
        if (null == o) {  return; }
        o.transform.parent = bonetrans;
        o.transform.localPosition = Vector3.zero;
        o.transform.localRotation = Quaternion.identity;
        m_materialPartnerRight = o.renderer.material;

        if (Active)
        {
            m_pParentNpc.MatRight = m_materialPartnerRight;
        }

        if (m_materialPartnerRight)
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartnerRight, true);
    }

    protected void ChangeShaderToAlphaVertex(float alpha)
    {

        if (m_materialPartner)
        {
            m_materialPartner.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_materialPartner.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }

        if (m_materialPartnerLeft)
        {
            m_materialPartnerLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_materialPartnerLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }

        if (m_materialPartnerRight)
        {
            m_materialPartnerRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT_ALPHA_DEPTH_OFF);
            m_materialPartnerRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alpha);
        }
    }

    public void ChangeAlphaVertexColor( float alphaVertexAlpha)
    {

        if (m_materialPartner != null && m_materialPartner.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_materialPartner.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alphaVertexAlpha);
        }

        if (m_materialPartnerLeft != null && m_materialPartnerLeft.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_materialPartnerLeft.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alphaVertexAlpha);
        }

        if (m_materialPartnerRight != null && m_materialPartnerRight.HasProperty(DEFINE.SHADER_PROPERTY_ALPHACON))
        {
            m_materialPartnerRight.SetFloat(DEFINE.SHADER_PROPERTY_ALPHACON, alphaVertexAlpha);
        }
    }

    public void ChangeShaderToXRay() 
    {
        if (m_materialPartner)
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartner, true);
        if (m_materialPartnerLeft)
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartnerLeft, true);
        if (m_materialPartnerRight)
            CBaseNpc.ChangeShaderToXRayAndBackLightVertex(m_materialPartnerRight, true);
    }

    public void Release(eObjectDestroyType type)
    {
        if (null != m_Obj)
            m_Obj.DestroyGameObject(eObjectDestroyType.Memory);

        if (m_materialPartner)
            m_materialPartner.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_materialPartnerLeft)
            m_materialPartnerLeft.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_materialPartnerRight)
            m_materialPartnerRight.shader = DynamicShader.GetShader(DEFINE.SHADER_VERTLIT);

        if (m_LeftWeapon != null)
        {
            m_LeftWeapon.DestroyGameObject(type);
            m_LeftWeapon = null;
        }

        if (m_RightWeapon != null)
        {
            m_RightWeapon.DestroyGameObject(type);
            m_RightWeapon = null;
        }

    } 
}
