﻿using UnityEngine;
using Network;
using Protocol;
using System;
using System.Collections;
using System.Collections.Generic;

//在线玩家（敌对方、盟友）
public class OnlineAvatar : RealAvatar
{
    protected PvpBattleInfo m_pBattleInfo = new PvpBattleInfo();
    public PvpBattleInfo BattleInfo
    {
        get { return m_pBattleInfo; }
    }

    public bool m_bOffline = false; //离线
    public bool Offline
    {
        set { m_bOffline = value; }
    }

    private Timer m_pRecvBufferTimer = new Timer(); //
    private Avatar m_pAvatar = null;
    public Avatar AvatarPlayer
    {
        get { return m_pAvatar; }
    }

    private bool m_bFixPos = false; //坐标修复
    private Vector3 m_FixPos = new Vector3();

    public OnlineAvatar(PvpBattleInfo info)
    {
        m_pBattleInfo = info;
        m_pRecvBufferTimer.SetTimer(PvpDefine.FixBufferTime); //70ms
        m_pAvatar = SingletonObject<Avatar>.GetInst();
    }


    public override void InitPlayer(BattleScene battlescene, uint index, uint npcTypeID, stCharacterCard playerAttr, eNpcSort sort, Vector3 position, Quaternion rotation, eNpcGroup group, int layer, string tag = DEFINE.AVATAR_OBJECT_TAG)
    {
        base.InitPlayer(battlescene, index, npcTypeID, playerAttr, sort, position, rotation, group, layer, tag);

        InitFSM();

        if (battlescene.BattleType == eBattleType.Pvp || battlescene.BattleType == eBattleType.MultiPve)
        {
            AddBuff(DEFINE.WASTELAND_LIFE_BUFF, null, true);
        }

        m_CommandRecvQueue.Clear();

        Trusteeship = false;

        //多人pve模式,只有等对方通知才能死
        if (CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            m_bCanKill = false;
        }
    }



    public override Vector3 DoAction(ActionContent pActionInfo, CBaseNpc pAttacker, SkillContent pSkillInfo, eDoActionType doActionType = eDoActionType.Normal, UseSkillInfo useInfo = null)
    {
        Vector3 destPosition = base.DoAction(pActionInfo, pAttacker, pSkillInfo, doActionType, useInfo);

        if (doActionType == eDoActionType.BehitMute || doActionType == eDoActionType.Behit)
        {
            //             Avatar ap = pAttacker as Avatar;
            //             if (null != ap && ap.AvatarType == eAvatarType.PvpAvatar)
            //             {
            //                 ap.TriggerMoveHandler(destPosition, eSyncMove.BeHit);
            //             }
        }

        return destPosition;
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        base.LoadNpcCompleted(o, args);

        for (int i = 0, len = m_PartnerList.Count; i < len; i++)
        {
            m_PartnerList[i].CreateObj(o.transform.position, o.transform.rotation, false);
        }

        m_pPlatformReceiver = AddPlatformReceiveMessage(o);
    }

    protected override void LoadAI()
    {
        base.LoadAI();

        Dictionary<int, CSkillupInfo> skillDict = new Dictionary<int, CSkillupInfo>();
        if (CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            foreach (CSkillValue stskill in m_pBattleInfo.playerInfo.skillDataVec)
            {
                if (stskill.uiSkillID.ToString().Length == 8)
                {
                    //SKILL表
                    SkillContent csl = HolderManager.m_SkillHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csl != null)
                    {
                        if (!skillDict.ContainsKey((int)stskill.uiSkillID))
                        {
                            skillDict.Add((int)stskill.uiSkillID, null);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,skill id:" + stskill.uiSkillID + "is exist");
                        }
                    }
                }
                else if (stskill.uiSkillID.ToString().Length == 6)
                {
                    SkillUpContent csul = HolderManager.m_SkillUpHolder.GetStaticInfo(stskill.uiSkillID);
                    if (csul != null)
                    {
                        CSkillupInfo info = new CSkillupInfo(stskill.uiLvl, csul);
                        uint uiSkillID = (uint)csul.SkillId;
                        if (!skillDict.ContainsKey((int)uiSkillID))
                        {
                            skillDict.Add((int)uiSkillID, info);
                        }
                        else
                        {
                            MyLog.LogError("Enemy avatar loadai error,CSkillupInfo id:" + stskill.uiSkillID + "is exist");
                        }
                    }
                }
                else
                {
                    MyLog.LogError("can't find id" + stskill.uiSkillID + "in skill/skillup!");
                }
            }
        }

        skillDict.Add(m_pPlayerLoader.NormalSkill, null);
        if (m_pAI != null)
        {
            if (CurrBattleScene.BattleType == eBattleType.Pvp || CurrBattleScene.BattleType == eBattleType.MultiPve)
            {
                m_pAI.SetAI(DEFINE.WASTELAND_BATTLE_AI_ID, null, skillDict);
            }
        }
    }

    public override void EnterPlatform(GameObject platformObj)
    {
        base.EnterPlatform(platformObj);

        if (m_pBattleScene.BattleType == eBattleType.MultiPve)
        {
            //将avatar强制拉过来
/*            Debug.LogError( this + "  EnterPlatform : ");*/
            //Vector3 destPos = m_pBattleScene.SummonPosition(this.GetPosition(), m_pAvatar.CharacterRadius, false, this, this.NpcCollider);
            m_pAvatar.SetPosition(m_myTrans.position);
            m_pAvatar.SetEnterPlatform(platformObj);
        }
    }


    public override eNpcBehaviour CheckNpcBehaviour()
    {
        if (m_bOffline)
        {
            return base.CheckNpcBehaviour();
        }
        else
        {
            return eNpcBehaviour.NoneBehaviour;
        }
    }

    public override void RrefeshHPComponent()
    {
        base.RrefeshHPComponent();
        switch (this.PartnerState)
        {
            case ePartnerState.Avatar:
                {                 
                    SingletonObject<LeagueBattleInfoMediator>.GetInst().SetEnemyHpValue(m_nHp * 1.0f / m_pCard.nMaxHp * 1.0f);
                }
                break;
            case ePartnerState.Partner:
                {
                    SingletonObject<LeagueBattleInfoMediator>.GetInst().SetEnemyPartnerHpValue(m_nHp * 1.0f / m_pCard.nMaxHp * 1.0f);
                }
                break;
        }
    }

    public void RecvMove(object moveMsg)
    {
        //MyLog.Log("  RecvPvpMove  :  " + (eSyncMove)moveMsg.uiSyncType + " , " + m_myTrans.position + " , " + Time.time);
        DoCommand(moveMsg, eRPCmdType.Move);
//         if (m_CommandRecvQueue.Count == 0)
//         {
//             RecvMove(moveMsg);
//         }
//         else
//         {
//             AvatarOnlineInfo.CommandCount++;
//             m_CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Move, moveMsg));
//         }
    }

    public void RecvPvpLocation(N2CNotifyPvpLocationChange locationMsg)
    {
        //Vector3 position = new Vector3(locationMsg.sLocationList[0].fPosX, PvpDefine.PvpScenceYPos, locationMsg.sLocationList[0].fPosY);

//         AvatarOnlineInfo.CommandCount++;
//         m_CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Location, locationMsg));
    }

//     public void RecvPvpAttack(N2CNotifyPvpBeingAttack attackInfo)
//     {
//         //MyLog.Log("  RecvPvpAttack  :  " + attackInfo.uiSkillID + " , " + m_myTrans.position + " , " + Time.time );
//         if (m_CommandRecvQueue.Count == 0)
//         {
//             RecvAttack(attackInfo);
//         }
//         else
//         {
//             AvatarOnlineInfo.CommandCount++;
//             m_CommandRecvQueue.Enqueue(new RealPlayerCommand(eRPCmdType.Attack, attackInfo));
//         }
//     }

    public void RecvAttack(object attackMsg)
    {
        DoCommand(attackMsg, eRPCmdType.Attack);
        //MyLog.Log("  RecvPvpAttack  :  " + attackInfo.uiSkillID + " , " + m_myTrans.position + " , " + Time.time );

    }

    //处理移动队列指令
//     private void RecvEnemyCmd()
//     {
//         if (null == m_myTrans) return;
// 
//         if (m_CommandRecvQueue.Count > 0 && m_pRecvBufferTimer.IsExpired(true))
//         {
//             RealPlayerCommand command = m_CommandRecvQueue.Peek();
//             MyLog.Log(" RecvEnemyCmd :   " + command.commandType + " " + System.DateTime.Now.Millisecond);
//             switch (command.commandType)
//             {
//                 case eRPCmdType.Move:
//                     {
//                         RecvMove((MoveCmdInfo)CurCmd.cmdInfo);
//                     }
//                     break;
//                 case eRPCmdType.Attack:
//                     {
//                         RecvAttack((AttackCmdInfo)CurCmd.cmdInfo);
//                     }
//                     break;
//                 case eRPCmdType.Location:
//                     {
//                         RecvLocation((N2CNotifyPvpLocationChange)command.commandInfo);
//                     }
//                     break;
//                 case eRPCmdType.DataChange:
//                     break;
//                 default:
//                     break;
// 
//             }
//             //MyLog.Log(" ExecuteCommand : " + System.DateTime.Now.Second + " , " + System.DateTime.Now.Millisecond);
//             AvatarOnlineInfo.CommandCount--;
//             m_pRecvBufferTimer.ResetTimer();
//             m_CommandRecvQueue.Dequeue();
//         }
//     }

    //     private void FixLocation(PvpLocationInfoList locationList, bool fromAtk = false) 
    //     {   
    //         //主机模式不修复坐标
    //         //if (AvatarOnlineInfo.IsHost == false)
    //         {
    //             Vector3 position = new Vector3(locationList[0].fPosX, PvpDefine.PvpScenceYPos, locationList[0].fPosY);
    //             Vector3 position1 = new Vector3(locationList[1].fPosX, PvpDefine.PvpScenceYPos, locationList[1].fPosY);
    //             MyLog.Log(" FixAvatarPos : " + position + " , RecvOtherAvatarPos" + position1 + " currentPos : " + GetPosition() + " Time : " + System.DateTime.Now.Millisecond);
    //             m_fAddMoveSpeed = 0f;
    //     //         bool equalWithLocation = true;
    //     //         for (int i = 0, len = locationList.Count; i < len; i++)
    //     //         {
    //     //             PvpLocationInfo locationInfo = locationList[i];
    //     //             //坐标与本地坐标不相等,强制进入同步
    //     //             if (!EqualWithLocation(locationInfo.fPosX, locationInfo.fPosY))
    //     //             {
    //     //                 equalWithLocation = false;
    //     //                 break;
    //     //             }            
    //     //         }
    //     //         if (!equalWithLocation)
    //             {
    //             
    //                 RealAvatar bp = null;
    //                 for (int i = 0, len = locationList.Count; i < len; i++)
    //                 {
    //                     PvpLocationInfo locationInfo = locationList[i];
    // 
    //                     if (PvpMgr.SelfInfo.playerInfo.uiPlayerID == locationInfo.uiPlayerID)
    //                     {
    //                         //AvatarPlayer           
    //                         bp = SingletonObject<Avatar>.GetInst();
    //                     }
    //                     else
    //                     {
    //                         //其他人
    //                         bp = PvpMgr.GetEnemyPlayer(locationInfo.uiPlayerID);
    //                     }
    //        
    //                     bp.SetEulerY(locationInfo.fEulerY);
    //                     bp.SetPosition(new Vector3(locationInfo.fPosX, PvpDefine.PvpScenceYPos, locationInfo.fPosY));
    //                     //m_pFixStepDict.Add(locationInfo.uiPlayerID, stepInfo);
    //                 }
    //                 //MyLog.LogError("  Fix Location!");
    //             }
    //             //else
    //             {
    //                 //MyLog.LogError(" Location Equals! ");
    //             }
    //         }
    //     }




//     public override void RecvMove(object moveInfo)
//     {
//         base.RecvMove(moveInfo);        
//     }
// 
//     
//     public override void RecvAttack(object attackInfo)
//     {
//         base.RecvAttack(attackInfo);   
//     }

    public void DoUseSkillFromMsg(uint uiSkillId)
    {
        eNpcBehaviour eBehaviour = eNpcBehaviour.None;
        List<CBaseNpc> targetList = GetTargets(DefaultSkillID, ref eBehaviour, eEffectRangeType.JudgeType);
        this.Command(eCommandType.UseSkill, new UseSkillCommandArg(uiSkillId, targetList));
    }

    public void DataChange(List<PvpChangeData> dataList)
    {
        for (int i = 0, len = dataList.Count; i < len; i++)
        {
            PvpChangeData change = dataList[i];

            switch ((ePvpDataType)change.uiDataType)
            {
                case ePvpDataType.AvatarHp:
                    break;
                case ePvpDataType.BehitDamage:
                    {

                    }
                    break;
                default:
                    break;
            }
        }
    }


    public override void LateUpdate()
    {
        base.LateUpdate();

        //ExecuteCommand();
    }

    public override void Update()
    {
        //RecvEnemyCmd();
        base.Update();
    }


}
