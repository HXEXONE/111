﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum eDragonScript
{
    self     = 1,
    target   = 2,
}

public enum eTriggerType //触发条件
{
    None        = 0, //伙伴用
    attack          = 1,//攻击
    defence           = 2,//防御
}

public enum eDragonshardType //龙晶类型
{
    avatarAttack,                   //角色攻击型龙晶
    avatarDef,                      //角色防御型龙晶
}

//龙晶
public class Dragonshard : CBaseNpc
{
    private BaseBattlePlayer m_pParentNpc;
    private CPartner m_pPartner = null;

    private DragoncrystalContent m_pDragonContent = null;    
    private float m_fCDtime;
    private float m_fMarkTime;

    private byte m_byStar; //星级
    private int m_nLevel; //当前等级
    private float m_fPromotePercent = 0f;
    private bool m_bActive = false;

    public bool Active
    {
        set { m_bActive = value; }
        get { return m_bActive; }
    }

    public Dragonshard(CrystalItemInfo info, BaseBattlePlayer parent, CPartner partner = null) 
    {        
        m_pParentNpc = parent;
        m_pPartner = partner;
        m_pDragonContent = HolderManager.m_DragoncrystalHolder.GetStaticInfo((int)info.uiCrystalId);
        if ( null == m_pDragonContent )
        {  
            return;
        }

        m_byStar = (byte)info.uiCrystalStar;//默认1星
        m_nLevel = (int)info.uiCrystalLevel; //默认1级
        List<int> cdlist = m_pDragonContent.BuilInCD;
        if (cdlist.Count > 4)
        {
            m_fCDtime = cdlist[m_byStar - 1]; // 根据星级来取
        }

        m_bActive = partner == null; //小伙伴的话 默认不激活
        m_fMarkTime = Time.time;

        m_fPromotePercent = (m_pDragonContent.SkillEffectUP[0] + m_nLevel * m_pDragonContent.SkillEffectUP[1]) / 10000f;

        //不传id会出问题,所以这里传一个
        uint uiNpcLoaderKey = 11000001;
        BattleScene battleScent = SingletonObject<BattleScene>.GetInst();
        uint nIndex = battleScent.GetEmptyIndex();
        Init(battleScent, nIndex, uiNpcLoaderKey, 1, eNpcSort.Dragonshard, Vector3.zero, Quaternion.identity, DEFINE.UNTAGGED_OBJECT_TAG);

        m_pBattleScene.AddNpc(this);
    }
    
    // 触发龙晶效果
    public void TriggerEvent(eTriggerType triggerType) 
    {
        if ( null == m_pDragonContent)
        {
            return;
        }
        //是否满足触发条件
        if ((int)triggerType != m_pDragonContent.TriggerType)
        {
            return;
        }
     
        //是否CD中
        if (Time.time - m_fMarkTime < m_fCDtime)
        {
            return;
        }
        List<int> triggerList = m_pDragonContent.TriggerUp;
        if (triggerList.Count < 4)
        {
            return;
        }
    
        int percent = triggerList[m_byStar - 1] / 100; //百分比

        int  randomNum = Random.Range(0, 100);
        bool trigger = percent > randomNum;
        //bool trigger = true;

        if (trigger)
        {
            //触发了,CD重置
            m_fMarkTime = Time.time;
            //触发script
            List<int> effectList = m_pDragonContent.TriggerEffect;
            if (effectList.Count > 1)
            {
                CBaseNpc scriptNpc = null;
                eDragonScript type = (eDragonScript)effectList[0];
                if (type == eDragonScript.self)
                {
                    scriptNpc = m_pParentNpc;
                }
                else if (type == eDragonScript.target)
                {
                    scriptNpc = m_pParentNpc.CurrTarget;
                }
                else
                {
                    MyLog.LogError(" TriggerType error !");
                    return;
                }

                if ( null == scriptNpc )
                {
                    return;
                }
                int scriptKey = effectList[1];
              
                ScriptContent scriptContent = HolderManager.m_ScriptHolder.GetStaticInfo(scriptKey);
                if ( null != scriptContent )
                {
                    ScriptManager.RequestScript((uint)scriptKey, scriptNpc, null, 0, 0, m_fPromotePercent);
                    //加载施法特效
                    List<int> particleList = m_pDragonContent.CrystalAndEnchantEffect;
                    if (particleList.Count > 1)
                    {
                        CreateParticle((uint)particleList[1]);
                    }      
                }
            }
        }

    }


    public void BindParentTransfrom(float mBodyHeight) 
    {
        //挂在父物体身上 , m_pPartner为空表示挂在主角身上
        UnityCallBackManager.GetInst().AddCallBack(1f, delegate(object[] _args)
        {
            m_myTrans.parent = m_pPartner == null ? m_pParentNpc.GetTransform() : m_pPartner.Trans;
            m_myTrans.localPosition = mBodyHeight == 0 ?Vector3.zero:new Vector3(0, mBodyHeight - 2.2f, 0);//2.2米是龙晶离原点的高度
            m_myTrans.localRotation = Quaternion.identity;
        });        
    }

    #region load
    protected override void CreateNpc(Vector3 position, Quaternion rotation, bool replace = false)
    {
        string loadPath = "resources/npc/npc/skillnpc_model.x";
        if (null != m_pNpcObj)
        {
            m_pNpcObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        m_pNpcObj = new CObject(loadPath);

        m_pNpcObj.Name = m_uiIndex.ToString();
        m_pNpcObj.CallBack = LoadNpcCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = eObjectType.Npc;
        m_pNpcObj.BornPosition = position;
        m_pNpcObj.BornRotation = rotation;

        m_pNpcObj.LoadObject();
        
    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if (null == o)
        {
            return;
        }
        m_myTrans = o.transform;
        m_playerTrans = m_myTrans;

        GameObject bpStep = new GameObject("BP_Step");
        bpStep.transform.parent = o.transform;
        bpStep.transform.localPosition = Vector3.zero;
        bpStep.transform.localRotation = Quaternion.identity;

        m_myTrans = o.transform;
        m_playerTrans = m_myTrans;

        List<int> effectList = m_pDragonContent.CrystalAndEnchantEffect;
        if (effectList.Count > 1)
        {
            CreateParticle((uint)effectList[0]);
        }       

        m_maxAttackRange = m_pParentNpc.MaxAttackRange;
        m_rangeNpcList = m_pParentNpc.GetRangeNpcList();


    }
#endregion

    #region get
    public override eNpcSortType GetNpcSortType()
    {
        return eNpcSortType.Pet;
    }

    public override System.Collections.Generic.List<float> GetAniMoveSpeed()
    {
        return null;
    }

    public override float GetMaxMoveSpeed()
    {
        return 0f;
    }

    public override bool IsKill()
    {
        return false;
    }
    public override bool IsHitDown()
    {
        return false;
    }
    public override bool IsBeatFly()
    {
        return false;
    }
    public override bool IsCanStun()
    {
        return false;
    }
    public override bool IsSlow()
    {
        return false;
    }
    public override int GetDeadActID()
    {
        return 0;
    }
    public override float GetRigidity()
    {
        return 0f;
    }

    public override string GetName()
    {
        return string.Empty;
    }
    #endregion


}
