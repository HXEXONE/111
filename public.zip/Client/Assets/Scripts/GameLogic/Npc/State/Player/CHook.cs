﻿using UnityEngine;
using System;
using System.Collections;

public delegate void AddHookFinish(GameObject go);
public delegate void AddHookGameobj(GameObject go);

public enum eHookState
{
    None,
    Put,                //放钩子
    HookEmpty,            //勾空/勾住
    HookBody,           //
    PullEmpty,       //收钩子(空钩子)
    PullBody,       //收钩子(勾住人)
    Finish,             //勾取完成
}

public class CHook : MonoBehaviour
{    
    private GameObject dragObj;

    private eHookState m_hookstate;
    private AnimationState anistate;

    private Rigidbody rigidbody;
    private Timer m_pTimer;

    private Animation animation;
    private float aniLength;

    private float fStratTime;
    private bool bDrag;

    private const float HOOK_TIME = 0.06f;//勾住敌人的停留时间

    public delegate void HookEventHandler(object sender, HookEventArgs args);
    public event HookEventHandler HookEvent;

    public class HookEventArgs 
    {
        public readonly GameObject gameobject;
        public HookEventArgs(GameObject gameobj)
        {
            gameobject = gameobj;
        }
    }

    public void OnHook(HookEventArgs args) 
    {
        if ( null != HookEvent )
            HookEvent(this, args);
    }

    public eHookState HookState
    {
        get { return m_hookstate; }
    }

    public void Init() 
    {
        bDrag = false;

        dragObj = null;
        m_pTimer = new Timer();
        m_hookstate = eHookState.None;
        HookEvent = null;

        transform.gameObject.layer = DEFINE.SKILLCHECK__LAYER;
        //防止自身发生碰撞        
        //Common.IgnoreCollision(transform.root.GetComponent<Collider>(), transform.GetComponent<Collider>());

        Physics.IgnoreLayerCollision(DEFINE.TERRAINLAYER, DEFINE.SKILLCHECK__LAYER);
        Physics.IgnoreLayerCollision(DEFINE.AIR_WALL, DEFINE.SKILLCHECK__LAYER);


//         int hookerLayer = transform.root.gameObject.layer;
//         Physics.IgnoreLayerCollision(hookerLayer, DEFINE.SKILLCHECK__LAYER

        SphereCollider sphereCollider = transform.GetComponent<SphereCollider>();
        if ( null == sphereCollider)
        {
            MyLog.LogError(" can not find SphereCollider.");
            return;
        }

        sphereCollider.isTrigger = true;

        Rigidbody rigBody = transform.GetComponent<Rigidbody>();
        if (null == rigBody)
        {
            this.rigidbody = transform.gameObject.AddComponent<Rigidbody>();
        }
        else
        {
            this.rigidbody = rigBody;
        }

        this.rigidbody.useGravity = false;

        animation = transform.parent.GetComponent<Animation>();
        if (animation == null)
        {
            MyLog.LogError(" can not find Animation in : " + transform.parent);
            return;
        }

        m_hookstate = eHookState.Put;
        anistate = animation["Take 001"];
        if (anistate == null)
        {
            MyLog.LogError(" error ! The hook particle not containing animation [Take 001] .");
            return;
        }
        anistate.speed = 1f;
        aniLength = anistate.length;
        m_pTimer.SetTimer(aniLength);

        fStratTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        if (null != m_pTimer)
        {
            switch (m_hookstate)
            {
                case eHookState.Put:
                    {
                        //时间到,没勾住敌人
                        if (m_pTimer.IsExpired(false))  
                        {
                            HookEventArgs e = new HookEventArgs(null);
                            OnHook(e);

                            m_pTimer.SetTimer(HOOK_TIME);           //设置钩子停留的时间
                            m_hookstate = eHookState.HookEmpty;

                            //rigidbody.isKinematic = true;       //防止钩子下落
                            
                        }
                    }
                    break;
                case eHookState.HookEmpty:
                    {
                        if (m_pTimer.IsExpired(false))
                        {
                            Playback(aniLength);
                            m_pTimer.SetTimer(aniLength);
                            m_hookstate = eHookState.PullEmpty;

                            //Common.IgnoreCollision(transform.root.GetComponent<Collider>(), transform.GetComponent<Collider>(), false);


                            //rigidbody.isKinematic = false; 

                        }                                        
                    }
                    break;
                case eHookState.HookBody:
                    {    
//                         Vector3 navPostion = NavSamplePosition(transform.position); 
//                         if (transform.position.y < navPostion.y )
//                         {
//                             dragObj.transform.position = navPostion; //防止掉地底下去
//                         }
//                         else
//                         {
//                             dragObj.transform.position = transform.position; //胸部点合理一点
//                         }

                        BindBone(DEFINE.BONE_Spine);
                        
                        //dragObj.transform.position = NavSamplePosition(transform.position);
                        if (m_pTimer.IsExpired(false))
                        {
                            m_hookstate = eHookState.PullBody;
                            //float fbacktime = Time.time - HOOK_TIME - fStratTime;
                            //m_pTimer.SetTimer(fbacktime * 0.9f); //收钩子到90%时 完成
                            
                        }           
                    }
                    break;
                case eHookState.PullEmpty:
                    {
                        if (m_pTimer.IsExpired(false))
                        {
                            m_hookstate = eHookState.Finish;

                        }
                    }
                    break;
                case eHookState.PullBody:
                    {
                        //dragObj.transform.position = NavSamplePosition(transform.position);
//                         Vector3 navPostion = NavSamplePosition(transform.position);
//                         if (transform.position.y < navPostion.y)
//                         {
//                             dragObj.transform.position = navPostion; //防止掉地底下去
//                         }
//                         else
//                         {
//                             dragObj.transform.position = transform.position; //胸部点合理一点
//                                 
                        BindBone(DEFINE.BONE_Spine);

                        float distance = Common.Get2DVecter3Length(transform.root.position, dragObj.transform.position);
                        if (distance < 2.5f)                        
                        //if (m_pTimer.IsExpired(false))
                        {
                            m_hookstate = eHookState.Finish;

                        }

                        //Common.IgnoreCollision(transform.root.GetComponent<Collider>(), transform.GetComponent<Collider>(), false);

                    }
                    break;
                case eHookState.Finish:
                    {
                        HookEventArgs e = new HookEventArgs(dragObj);
                        OnHook(e);

                        transform.parent.gameObject.SetActive(false);

                        if (null != dragObj)
                        {
                            dragObj.transform.position = NavSamplePosition(dragObj.transform.position) + Vector3.up * 0.5f;
                        }

                        //UnityEngine.GameObject.Destroy(transform.GetComponent<CHook>());
                    }
                    break;
            }
        }
    }


    public void BindBone(string boneName)
    {
        Transform targetTrans = dragObj.transform;
        targetTrans.position = transform.position;
        ////找到胸部绑点
        Transform spineTrans = Common.GetBone(targetTrans, boneName);
        //如果找不到胸部绑点,换其他店
        if (null == spineTrans)
        {
            spineTrans = targetTrans;
        }
        //将胸部绑点对应到抓取点上
        targetTrans.position -= (spineTrans.position - targetTrans.position);
    }

    //找到navmesh上最近的点
    public static Vector3 NavSamplePosition(Vector3 srcPosition)
    {
        Vector3 dstPosition = srcPosition;
        NavMeshHit meshHit = new NavMeshHit();
        if (NavMesh.SamplePosition(srcPosition, out meshHit, 100, 1 << NavMesh.GetNavMeshLayerFromName("Default")))
        {
            dstPosition = meshHit.position;
        }

        return dstPosition;
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.isTrigger)
        {
            return;
        }
        if (collider.gameObject.layer != DEFINE.MONSTER_LAYER && 
		    collider.gameObject.layer != DEFINE.AVATAR_LAYER)        
        {
            return;
        }

        if (m_hookstate != eHookState.Put)
        {
            return;
        }

        //MyLog.Log(" OnTriggerEnter : " + collider.gameObject.name);

        HookEventArgs e = new HookEventArgs(collider.gameObject);
        OnHook(e);


    }

    public void EnterHookBody(GameObject go) 
    {
        dragObj = go;

        animation.Stop();
        m_pTimer.SetTimer(HOOK_TIME);

        m_hookstate = eHookState.HookBody;

        CapsuleCollider capsule = go.GetComponent<CapsuleCollider>();
        if (null != capsule)
            capsule.enabled = false;

        UnityCallBackManager.GetInst().AddCallBack(HOOK_TIME, DealyPlayback, new object[] { Time.time - fStratTime });
        UnityEngine.Object.Destroy(rigidbody);
    }

    private void DealyPlayback(params object[] args)
    {
        float anitime = (float)args[0];
        Playback(anitime);
    }

    private void Playback(float anitime)
    {
        if (null == anistate)
        {
            return;
        }
        anistate.time = anitime;//钩子运行时间
        anistate.speed = -1f;
        animation.Play();
    }


   
}
