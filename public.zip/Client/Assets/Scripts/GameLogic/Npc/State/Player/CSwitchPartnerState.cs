﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class CSwitchPartner : CBaseState
{

    public CSwitchPartner(CBaseNpc pNpc) :
        base(pNpc, eActionState.SwitchPartner, false, false, false, false)
    {

    }

    public override void EnterState()
    {
        base.EnterState();
        //m_pNpc.PlayAction(m_state, m_fActionSpeed, true);
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = true;
        m_pNpc.EnablePathFinding(false);

        SetTimer(-1f);
    }

}