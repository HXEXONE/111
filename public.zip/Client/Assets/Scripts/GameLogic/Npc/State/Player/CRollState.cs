using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CRollState : CBaseState
{
    public CRollState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Roll, false, false, false, true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
     
        m_pNpc.EnablePathFinding(false);

        m_pNpc.SoundBreak();

        //m_pNpc.IgnoreNpcCollsion(true);

        SkillContent rollSkillLoader;
        eCommandReply replyType;
        BaseBattlePlayer bbp = m_pNpc as BaseBattlePlayer;
        //С��鷭�������ǲ�һ�������Է�����Ҫ�ж��Ƿ���С���
        bool isPartner = null != bbp  ? ((BaseBattlePlayer)m_pNpc).PartnerState == ePartnerState.Partner : false;
        if (isPartner)
        {
            
            if (bbp.ActivePartner == null) return;

            PartnerModelContent partnerModelLoader = bbp.ActivePartner.PartnerLoader.ModelLoader;
            if (null == partnerModelLoader) return;

            rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(partnerModelLoader.RollSkill);

            //replyType = m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)partnerModelLoader.RollSkill, new List<CBaseNpc>()));
            m_pNpc.DoUseSkillEvent(new UseSkillCommandArg((uint)partnerModelLoader.RollSkill, new List<CBaseNpc>()));
        }
        else
        {
            PlayerConfigContent configLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pNpc.NpcType);
            if (null == configLoader) return;

             rollSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(configLoader.RollID);

            //replyType = m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)configLoader.RollID, new List<CBaseNpc>()));
             m_pNpc.DoUseSkillEvent(new UseSkillCommandArg((uint)configLoader.RollID, new List<CBaseNpc>()));
        }

        Avatar avatar = m_pNpc as Avatar;
        if (null != avatar)
        {
            UnityCallBackManager.GetInst().AddCallBack(rollSkillLoader.LastTime, delegate(object[] args_)
            {
                avatar.DClickLocking = false;
                //Debug.LogError("avatar.DClickLocking = false");
            });
        }                

        //if (replyType == eCommandReply.YesSir)
        {
            m_pNpc.CurrTarget = null;
            m_pNpc.BreakNormalSkill(m_pNpc.DefaultSkillID);                    
        }
    }


}