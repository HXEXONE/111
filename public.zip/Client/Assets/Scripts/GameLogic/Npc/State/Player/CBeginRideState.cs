﻿using UnityEngine;
using System.Collections;

public class CBeginRideState : CBaseState
{
    public CBeginRideState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BeginRide, true, false, false, true)
    {
       
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, true);

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        //m_pNpc.CreateSound(DEFINE.SOUND_AVATAR_RIDE_BEGIN);

        m_pNpc.SetTirrgerObject(2f);
    }


    //public override void Update()
    //{
    //    base.Update();

    //    m_pNpc.Move(0);
    //}
}
