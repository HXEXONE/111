﻿using UnityEngine;
using System.Collections;

public class CEndRideState : CBaseState
{
    public CEndRideState(CBaseNpc pNpc) :
        base(pNpc, eActionState.EndRide, true, false, false, false)
    {
       
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, true);
        //下坐骑音效
        m_pNpc.CreateSound((m_pNpc as BaseBattlePlayer).MountJumpSound);

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        //m_pNpc.CreateSound(DEFINE.SOUND_AVATAR_RIDE_END);

    }

    public override void LeaveState()
    {
        base.LeaveState();

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            bbp.EndRide(false);
        }
        m_pNpc.ResetTirrgerObject();
    }
}
