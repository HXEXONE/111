﻿using UnityEngine;
using System.Collections;

public class CRideJumpState : CBaseState
{
    private Vector3 m_startJumpPos;
    private float m_waitTime;
    private float m_startTime;

    private Transform m_boneTrans;
    private GameObject m_mountObj;

    private float m_playerRideOffset;

    public CRideJumpState(CBaseNpc pNpc) :
        base(pNpc, eActionState.RideJump, true, false, false, false)
    {
       
    }

    public override void EnterState()
    {
        base.EnterState();

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            Transform npctrans = m_pNpc.GetTransform();
            m_mountObj = bbp.GetMountObj();
            if(m_mountObj != null)
                m_boneTrans = Common.GetBone(m_mountObj.transform, "Bone026");

            //将摄像机焦点定于临时物体
            CharacterController replaceCC = bbp.ReplaceModelController;
            bbp.InitFollowCamera(replaceCC.gameObject, eCAMERAFOLLOW.SMOOTH);

            switch (bbp.JobType)
            {
                case eJobType.Assassin:
                    {
                        m_playerRideOffset = 2.86f;
                    }
                    break;
                case eJobType.Warrior:
                    {
                        m_playerRideOffset = 2.46f;
                    }
                    break;
                case eJobType.Wizard:
                    {
                        m_playerRideOffset = 2.81f;
                    }
                    break;
                case eJobType.HolyKnight:
                    {
                        m_playerRideOffset = 2.49f;
                    }
                    break;
            }
        }

        m_pNpc.PlayAction(m_state, m_fActionSpeed, true, 0);
        //上坐骑音效
        m_pNpc.CreateSound((m_pNpc as BaseBattlePlayer).MountJumpSound);

        //m_pNpc.CreateSound();


        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);


        m_startJumpPos = m_pNpc.GetPosition();
        m_waitTime = 0;
        m_startTime = Time.time;
    }

    public override void LeaveState()
    {
        base.LeaveState();
        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            bbp.Ride();
        }

        
    }

    public override void Update()
    {
        base.Update();

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            Vector3 mountAndJumpPosition = bbp.GetMountAndJumpPosition();

            float time = GetActionTime();
            float moveSpeed = 0;
            if (time != -1)
            {
                moveSpeed = Common.Get2DVecter3Length(mountAndJumpPosition, m_startJumpPos) / (time - m_waitTime-0.1f);

                bbp.MountJumpToDest(time - m_waitTime-0.1f);

            }
            else
            {
                m_waitTime += Time.deltaTime;
            }

            Transform npcTrans = m_pNpc.GetTransform();
            Vector3 horizontalDir = (mountAndJumpPosition - npcTrans.position).normalized;
            npcTrans.position += horizontalDir * moveSpeed * Time.deltaTime;

            if (time != -1)
            {
                //同步位置
                if (Time.time - m_startTime >= time + m_waitTime - 0.2f)
                {
                    float offset = (m_boneTrans.position.y - m_mountObj.transform.position.y) - 2.86f;
                    Vector3.Lerp(npcTrans.position, npcTrans.position + Vector3.up * offset, Time.deltaTime);
                }

                if(Time.time - m_startTime >= time + m_waitTime - 0.1f)
                {
                    m_pNpc.LeaveState(m_state);
                }
            }

        }

       
      
    }

}
