﻿using UnityEngine;
using System.Collections;

//蓄力状态
public class CChargeState  : CBaseState
{
    private SkillContent m_pSkillLoader;
    private Timer m_fChargeTimer = new Timer(); //蓄力计时器
    private bool m_bTurnStart;          //开始转向
    private Vector3 m_clickDirection;       //点击朝向

    public CChargeState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Charge, true, false, false, true) { }


    public void SetChargeInfo(SkillContent pSkillLoader)
    { 
        m_pSkillLoader = pSkillLoader;
    }            
    
    public override void EnterState()
    {        
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);
        m_bTurnStart = false;

        RaycastHit hit;
        Camera camera = CCamera.GetInst().GetCamera();
        Ray ray = camera.ScreenPointToRay(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));

        if (Physics.Raycast(ray, out hit, 1000, 1 << DEFINE.TERRAINLAYER) && !CBaseStory.IsInGameStory)
        {
            Vector3 lookDirection = hit.point - m_pNpc.GetPosition();
            lookDirection.y = 0;
            m_pNpc.UpdateTurn(lookDirection, true);
        }

        float chargeTime =  m_pSkillLoader.LastTime;
        m_fChargeTimer.SetTimer(chargeTime);

        //蓄力UI..
        SingletonObject<SkillReadyTimeMediator>.GetInst().StartReadyTime(chargeTime);
    }

    public override void LeaveState()
    {
        base.LeaveState();

        //蓄力技能
        uint nextID = (uint)(m_pSkillLoader.Key + 1);
        if (nextID != 0)
        {
            //设置下一个技能
            SkillContent nextInfo = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
            if (null != nextInfo)
            {
                m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)nextInfo.Key, null));
                return;
            }
        }
    }

    public void MouseClick(Vector3 point) 
    {
        if (m_pNpc.CanTurn)
        {
            m_bTurnStart = true;
            m_clickDirection = point - m_pNpc.GetPosition();
        }
    }


    public override void BreakState()
    {
        base.BreakState();

        //蓄力被打断
        SingletonObject<SkillReadyTimeMediator>.GetInst().StartReadyTime(0.0f);

        eGuidTarget target = NewBieGuidManager.GetInst().CheckTargetType();
        if (target == eGuidTarget.Charge || target == eGuidTarget.ChargeAgain)
        {
            NewBieGuidManager.GetInst().ActivateGuide(target);
            SingletonObject<BattleGuide>.GetInst().Pause(target, true, true);
        }

        m_pNpc.SoundBreak();
    }

    public override void Update()
    {
        if (m_bTurnStart)
        {
            m_pNpc.UpdateTurn(m_clickDirection, false);
        }

        if (Input.GetKey(KeyCode.Mouse0) || CBaseStory.IsInGameStory )
        {
            SingletonObject<SkillReadyTimeMediator>.GetInst().UpdateReadyTime(m_fChargeTimer.GetLeftTime());
        }

        else if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            //蓄力被打断
            SingletonObject<SkillReadyTimeMediator>.GetInst().StartReadyTime(0.0f);
            eGuidTarget target = NewBieGuidManager.GetInst().CheckTargetType();
            if (target == eGuidTarget.Charge || target == eGuidTarget.ChargeAgain)
            {
                m_pNpc.EnterState(eActionState.Wait);
            }
            else
            {
                m_pNpc.EnterState(eActionState.Idle);
            }

            return;
        }

        base.Update();

    }
}
