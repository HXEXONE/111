﻿using UnityEngine;
using System.Collections;

//等待状态
public class CWaitState : CBaseState
{
    public CWaitState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Wait, false, false, false, true)
    {
        
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(eActionState.Idle,m_fActionSpeed,false,0.8f);

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        
        m_pNpc.EnablePathFinding(false);
    }

    public override void Update()
    {
        base.Update();

        m_pNpc.Move(0f);
    }

    public override void BreakState()
    {
        base.BreakState();

        if ( m_pNpc is Avatar )
        {
            //SingletonObject<BattleGuide>.GetInst().Behavior = eGuideBehavior.Free;
        }
    }
}
