﻿using UnityEngine;
using System.Collections;

public class CBeginFlyState : CBaseState
{
    private Vector3 m_startJumpPos;
    private float m_waitTime;

    public CBeginFlyState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BeginFly, true, false, false, false)
    {
       
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, true);
        m_pNpc.CreateSound((m_pNpc as BaseBattlePlayer).PetJumpSound);

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        //m_pNpc.CreateSound(DEFINE.SOUND_AVATAR_PET_BEGIN);


        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            bbp.SetDestPosition(bbp.GetMountAndJumpPosition(), false);
        }
        m_startJumpPos = m_pNpc.GetPosition();
        m_waitTime = 0;
    }

    public override void LeaveState()
    {
        base.LeaveState();

        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            bbp.Fly();
        }

        
    }

    public override void Update()
    {
        base.Update();

        float time = GetActionTime();
        float moveSpeed = 0;
        if (time != -1)
        {
            moveSpeed = Common.Get2DVecter3Length(m_pNpc.GetDestPosition(), m_startJumpPos) / (time - m_waitTime);
        }
        else
        {
            m_waitTime += Time.deltaTime;
        }

        m_pNpc.Move(moveSpeed, true);
    }
}
