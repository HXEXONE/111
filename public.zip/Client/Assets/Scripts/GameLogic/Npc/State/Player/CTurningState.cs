﻿using UnityEngine;
using System.Collections;

public class CTurningState : CBaseState 
{
    public CTurningState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Turning, false, false, false, true)
    {
        
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);

        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 4f;
        m_pNpc.EnablePathFinding(false);
        m_pNpc.CurrTarget = null;
        
        m_fTime = m_pNpc.TurningTime < 0.1f ? m_pNpc.TurningTime + 0.1f : m_pNpc.TurningTime;
        //m_fTime = m_pNpc.TurningTime;
        m_eCheckState = eCheckActState.CheckOver;
        SetTimer(m_fTime);
    }

    public override void Update()
    {
        base.Update();

        if (m_pNpc.NotInAction())
        {
            m_pNpc.Move(m_pNpc.MoveSpeed);
        }
        
    }
}
