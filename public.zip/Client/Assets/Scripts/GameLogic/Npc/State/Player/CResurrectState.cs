﻿using UnityEngine;
using System.Collections;

public class CResurrectState : CBaseState
{
    public CResurrectState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Resurrect, true, false, false, true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 2;
        m_pNpc.EnablePathFinding(false);
        //m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
    }

    public override void BreakState()
    {
        base.BreakState();
        if (m_pNpc.CurrBattleScene.IsBattleWin)
        {
            m_pNpc.CurrBattleScene.GameOver(true, true);
        }
    }

    public override void LeaveState()
    {
        base.LeaveState();
        //m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        if (m_pNpc.CurrBattleScene.IsBattleWin)
        {
            m_pNpc.CurrBattleScene.GameOver(true, true);
        }
    }
}
