﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CHookState : CBaseState
{
    private  CHook m_pHook;
    private SkillContent m_pSkillLoader;
    private uint m_uiParticleIndex;

    private Transform m_hookTrans;

    public CHookState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Hook, false, false, false, true)
    {
        m_pHook = null;
       
    }

    public override void EnterState()
    {
        base.EnterState();

        m_uiParticleIndex = 0;

        m_hookTrans = null;
        

        //m_pHook = null;
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;

        m_pNpc.ApplyRootMotion = true;

    }

    public void SetSkillLoader(SkillContent pSkillLoader) 
    {
        m_pSkillLoader = pSkillLoader;
    }

    public override void BreakState()
    {
        base.BreakState();

        m_pHook = null;
    }

    public override void LeaveState()
    {
        base.LeaveState();

        m_pHook = null;
    }

    public void SetParticleIndex(uint uiIndex) 
    {
        m_uiParticleIndex = uiIndex;

        if (m_pHook == null)
        {
            Transform npcTrans = m_pNpc.GetTransform();
            if (null != npcTrans)
            {
                CHook[] pHooks = npcTrans.GetComponentsInChildren<CHook>();
                if (pHooks.Length > 0)
                {
                    m_pHook = pHooks[0];
                    m_pHook.HookEvent += HookGameObj;// 注册勾取事件               
                }
                else
                {
                    MyLog.LogError(" can not find CHook Script.!");
                }
            }

        }
    }


    private void HookGameObj(object sender,CHook.HookEventArgs args) 
    {
        
        CHook hook = (CHook)sender;
        GameObject go = args.gameobject;
        if (hook.HookState == eHookState.Put)
        {//抓住
            if (null != go)
            {
                //判断是否可以被抓取
                uint npcIndex = MyConvert_Convert.ToUInt32(go.name);
                CBaseNpc pNpc = m_pNpc.CurrBattleScene.GetNpc(npcIndex);
                if (pNpc.CanBeGrab)
                {
                    if (CBaseNpc.AffectResult((eAffectType)m_pSkillLoader.AffectType, (eAffectEffect)m_pSkillLoader.AffectEffect, m_pNpc, pNpc, eEffectRangeType.HurtType, (eSkillAtkType)m_pSkillLoader.SkillAtkType,m_pSkillLoader.LockList))
                    {
                        if (null != m_pHook)
                            m_pHook.EnterHookBody(go);
     
                        string hookName = go.name;
                        CBaseNpc pHookNpc = m_pNpc.CurrBattleScene.GetNpc(MyConvert_Convert.ToByte(hookName));
                        if (null != pHookNpc)
                        { //抓取成功

                            pHookNpc.IsBeGrab = true;
                            //音效打断
                            pHookNpc.SoundBreak();
                            //眩晕永久
                            //pHookNpc.AddBuff(DEFINE.LAST_STUN_BUFFID);
                            CStunState pStunState = pHookNpc.GetState(eActionState.Stun) as CStunState;
                            pHookNpc.EnterState(eActionState.Stun);
                            pStunState.SetTimer(-1f);
                            //钩子受击特效
                            pHookNpc.CreateParticle(DEFINE.HOOK_HIT_PARTICLEID);
                            //无敌永久
                            m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
                            //与抓取者忽略碰撞
                            //Common.IgnoreCollision(m_pNpc.NpcCollider, pHookNpc.NpcCollider);
                        }
                        m_hookTrans = go.transform;
                    }
                }
            }

            //播放收钩子动作
            uint dragActionID = MyConvert_Convert.ToUInt32(m_pSkillLoader.ExtraArgs[0]);
            ActionContent actionLoader = HolderManager.m_ActionHolder.GetStaticInfo(dragActionID);
            if (null != actionLoader)
                m_pNpc.PlayAction(actionLoader.ActionName);
        }
        else if (hook.HookState == eHookState.Finish )
        {//抓取完成
            if (null != go)
            {
                if (null != go.GetComponent<Collider>())
                {
                    //踢飞技能
                    BattleScene battle = m_pNpc.CurrBattleScene;
                    m_pNpc.GrabNpc = battle.GetNpc(MyConvert_Convert.ToUInt32(go.name));

                    uint nextID = (uint)(m_pSkillLoader.Key + 1);
                    m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg(nextID, null));
                    //删除无敌buff
                    m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

                    //删除钩子受击特效
                    //CParticleManager.GetInst().AddDestroyParticle(m_hitParticleIndex);
                }
            }
            else
            {
                m_pNpc.LeaveState(eActionState.Hook);
            }
            CParticleManager.GetInst().AddDestroyParticle(m_uiParticleIndex);
        }
    }
    
}
