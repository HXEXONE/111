﻿using UnityEngine;
using System.Collections;

public class CEndFlyState : CBaseState
{
    public CEndFlyState(CBaseNpc pNpc) :
        base(pNpc, eActionState.EndFly, true, false, false, true)
    {
       
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, true);
        m_pNpc.CreateSound((m_pNpc as BaseBattlePlayer).PetJumpSound);


        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        //m_pNpc.CreateSound(DEFINE.SOUND_AVATAR_PET_END);
    }

    public override void LeaveState()
    {
        base.LeaveState();
        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
    }

    public override void Update()
    {
        base.Update();

        m_pNpc.Move(0);
    }
}
