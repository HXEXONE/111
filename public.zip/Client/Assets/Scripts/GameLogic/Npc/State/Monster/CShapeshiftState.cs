﻿using UnityEngine;
using System.Collections;

public class CShapeshiftState : CBaseState
{
    private eShapeshiftState m_shapeshiftState;
    private uint m_uiActionID;
    private uint m_uiReplaceNpcID;

    private Timer m_shapeshiftTimer = new Timer();

    private Vector3 m_beforePosition;
    private Quaternion m_beforeRotation;

    private bool m_bPlayFinish = false;

    public CShapeshiftState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Shapeshift, true, true, false,true)
    {
        
    }

    public override void EnterState()
    {
        base.EnterState();

        m_bPlayFinish = false;

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;

        m_pNpc.EnablePathFinding(false);

        m_shapeshiftState = eShapeshiftState.Action;
        //m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_HIDE_BUFF_ID);

    }

    public override void LeaveState()
    {
        base.LeaveState();

        //m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_HIDE_BUFF_ID);
    }

    public void SetActionID(uint uiActionID)
    {
        m_uiActionID = uiActionID;
    }

    public void SetReplaceNpcID(uint uiNpcID)
    {
        m_uiReplaceNpcID = uiNpcID;

        MonsterContent monsterLoader = HolderManager.m_MonsterHolder.GetStaticInfo(m_uiReplaceNpcID);
        if ( null != monsterLoader )
        {
            string modelPath = monsterLoader.ModelLoader.Path;
            LoadHelp.LoadObject("", modelPath, ThreadPriority.Normal, null);

            LoadHelp.LoadObject("", monsterLoader.ModelLoader.AniPath, ThreadPriority.Normal, null);
          
        }
        
    }

    private void PlayActFinish(object[] args) 
    {
        m_bPlayFinish = true;
    }

    public override void Update()
    {
        base.Update();

        switch (m_shapeshiftState)
        {
            case eShapeshiftState.Action:
                {
                    ActionContent pActionLoader = HolderManager.m_ActionHolder.GetStaticInfo(m_uiActionID);
                    if(pActionLoader != null)
                    {
                        m_pNpc.DoActionOnly(pActionLoader, false,PlayActFinish,null);
                    }

                    m_pNpc.SetAlphaVertexColorOff(2);
                    m_shapeshiftTimer.SetTimer(3);

                    Transform trans = m_pNpc.GetTransform();
                    m_beforePosition = trans.position;
                    m_beforeRotation = trans.rotation;

                    m_shapeshiftState = eShapeshiftState.Replace_before;
                }
                break;
            case eShapeshiftState.Replace_before:
                {
                    if (m_bPlayFinish || m_shapeshiftTimer.IsExpired(false))
                    {
                        SingletonObject<BattleScene>.GetInst().LoseTarget(m_pNpc);
                        m_pNpc.Shapeshift_before(m_uiReplaceNpcID);

                        m_shapeshiftState = eShapeshiftState.Replace_after;
                    }
                }
                break;
            case eShapeshiftState.Replace_after:
                {
                    m_pNpc.Shapeshift_after(m_uiReplaceNpcID, m_beforePosition, m_beforeRotation);
                    
                    Monster monster = m_pNpc as Monster;
                    if ( null != monster )
                    {
                        monster.SetAttrInherit();
                    }
                    //m_shapeshiftTimer.SetTimer(2);
                    //m_shapeshiftState = eShapeshiftState.Completed;
                }
                break;
//             case eShapeshiftState.Completed:
//                 {
//                     if (m_shapeshiftTimer.IsExpired(false))
//                     {
//                         m_pNpc.LeaveState(m_state);
//                         m_pNpc.SetAlphaVertexColorOn(1);
//                     }
//                 }
//                 break;
        }
    }
}
