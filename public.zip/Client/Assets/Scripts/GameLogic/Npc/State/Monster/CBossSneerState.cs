﻿using UnityEngine;
using System.Collections;

//BOSS嘲讽状态
public class CBossSneerState : CBaseState
{
    public CBossSneerState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BossSneer, true, false, false, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_szActionName, m_fActionSpeed, true);



        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        CBaseNpc target = m_pNpc.CurrTarget;
        if( target != null)
        {
            Vector3 direction = target.GetPosition() - m_pNpc.GetPosition();
            direction.y = 0;

            m_pNpc.UpdateTurn(direction, true);
        }

    }

}
