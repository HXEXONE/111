﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


//BOSS漫步状态
public class CBossRambleState : CBaseState 
{
    private eRambleType m_rambleType;

    private Timer m_pRambleTimer;

    private List<eRambleType> m_typeList = new List<eRambleType>();

    private GameObject m_rambleObject;

    private float m_speed;

    public CBossRambleState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BossRamble, false, false, false, true)
    {
        m_pRambleTimer = new Timer();
        m_pRambleTimer.SetTimer(3);
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);
        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED / 2;
        m_pNpc.EnablePathFinding(false);

    }

    private void CheckDirection(CBaseNpc target)
    {
        if (m_pRambleTimer.IsExpired(true))
        {
            float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), target.GetPosition());

            m_typeList.Clear();

            if (distance > 6)//优先前进
            {
                m_typeList.Add(eRambleType.Forward);
                m_typeList.Add(eRambleType.LeftForward);
                m_typeList.Add(eRambleType.RightForward);
                m_typeList.Add(eRambleType.Left);
                m_typeList.Add(eRambleType.Right);
            }
            else if (distance < 3)//优先后退
            {
                m_typeList.Add(eRambleType.Back);
                m_typeList.Add(eRambleType.LeftForward);
                m_typeList.Add(eRambleType.RightForward);
                m_typeList.Add(eRambleType.Left);
                m_typeList.Add(eRambleType.Right);
            }
            else//优先左移或者右移
            {   
                m_typeList.Add(eRambleType.LeftForward);
                m_typeList.Add(eRambleType.RightForward);
                m_typeList.Add(eRambleType.Left);
                m_typeList.Add(eRambleType.Right);
                m_typeList.Add(eRambleType.Forward);
                m_typeList.Add(eRambleType.Back);
            }

            

            Ray ray = new Ray();
            bool bFind = false;
            Transform targetTrans = target.GetTransform();
            Vector3 myPosition = m_pNpc.GetPosition();

            if (null == m_rambleObject)
            {
                m_rambleObject = new GameObject("RambleObject");
            }

            m_rambleObject.transform.position = myPosition;
            m_rambleObject.transform.LookAt(targetTrans);


            float rayDistance = 6;//射线检测的长度
            for (int i = 0, count = m_typeList.Count; i < count; ++i)
            {
                eRambleType eType = m_typeList[i];
                if (eType == eRambleType.Forward)
                {
                    ray = new Ray(myPosition, m_rambleObject.transform.forward);
                    bFind = true;
                }
                else if (eType == eRambleType.Left)
                {
                    ray = new Ray(myPosition, -m_rambleObject.transform.right);
                    bFind = true;
                }
                else if (eType == eRambleType.LeftForward)
                {
                    m_rambleObject.transform.Rotate(Vector3.up, 45);
                    ray = new Ray(myPosition, m_rambleObject.transform.forward);
                    bFind = true;
                }
                else if (eType == eRambleType.Right)
                {
                    ray = new Ray(myPosition, m_rambleObject.transform.right);
                    bFind = true;
                }
                else if (eType == eRambleType.RightForward)
                {
                    m_rambleObject.transform.Rotate(Vector3.up, -45);
                    ray = new Ray(myPosition, m_rambleObject.transform.forward);
                    bFind = true;
                }
                else
                {
                    //ray = new Ray(myPosition, -m_rambleObject.transform.forward);
                    //if (!Physics.Raycast(ray, rayDistance, 1 << DEFINE.AIR_WALL))
                    //{
                    //    m_pNpc.SetFollowTransform(target.GetTransform(),false);
                    //    m_speed = m_pNpc.MoveSpeed / 2;
                    //    break;
                    //}
                }

                if (bFind && !Physics.Raycast(ray, rayDistance, 1 << DEFINE.AIR_WALL))
                {
                    Vector3 dstPosition = ray.GetPoint(distance);
                    m_pNpc.SetDestPosition(dstPosition, true);
                    //m_speed = m_pNpc.MoveSpeed / 1.5f;
                    m_speed = m_pNpc.MoveSpeed;
                    break;
                }
               
            }
        }
    }

    public override void Update()
    {
        base.Update();

        if( m_pNpc.NpcSort == eNpcSort.Monster)
        {
            Monster monster = (Monster)m_pNpc;
            NpcAI pAI = monster.AI;

            CBaseNpc pTarget = monster.CurrTarget;
            if (pTarget != null)
            {
                CheckDirection(pTarget);
            }
            
            //转向
            m_pNpc.Move(m_speed);
        }
        
    }
}
