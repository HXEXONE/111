﻿using UnityEngine;
using System.Collections;


public enum eScaType//闲逛类型
{
    move,
    idle,
}

//闲逛状态
public class CScaunterState : CBaseState
{
    private Timer m_pScanunterTimer = new Timer();

    private eScaType m_eScaType;

    public CScaunterState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Scaunter, false, false, false, true)
    {

    }
    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, 0.5f);

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_eScaType = eScaType.move;
 
        RandomTime();
        RandomDestPos();
    }

    private void RandomDestPos() 
    {
        //UnityEngine.Random.seed = (int)System.DateTime.Now.Ticks;
        float angel = 180f;

        Transform trans = m_pNpc.GetTransform();
        Vector3 direction = Quaternion.Euler(Vector3.up * angel) * trans.forward ;
        m_pNpc.SetDestPosition(trans.position + direction * 4f, false);
    }

    private void RandomTime() 
    {
        //UnityEngine.Random.seed = (int)System.DateTime.Now.Ticks;
        float interval = UnityEngine.Random.Range(0.1f, 2f);

        if (m_eScaType == eScaType.idle)
        {
            interval += 3f;
        }
        m_pScanunterTimer.SetTimer(interval);
    }

    public override void Update()
    {
        base.Update();

        if (m_pScanunterTimer.IsExpired(true))
        {
            m_eScaType = m_eScaType == eScaType.move ? eScaType.idle : eScaType.move;
            if (m_eScaType == eScaType.move)
            {
                m_pNpc.PlayAction(eActionState.Scaunter, 0.5f);
  
                RandomDestPos();
            }
            else if (m_eScaType == eScaType.idle)
            {
                m_pNpc.PlayAction(eActionState.Idle);
            }

            RandomTime();           
        }

        if (m_pNpc.NotInAction() && m_pJudgeTimer.IsExpired(true))
        {
            m_pNpc.CheckNpcBehaviour();
        }

        if (m_eScaType == eScaType.move)
        {
            m_pNpc.Move(m_pNpc.MoveSpeed / 2f, true);
        }        
    }

}
