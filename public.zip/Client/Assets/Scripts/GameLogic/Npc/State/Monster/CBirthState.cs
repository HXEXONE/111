﻿using UnityEngine;
using System.Collections;

public class CBirthState : CBaseState 
{
    private Timer m_pBirthTimer;
    private CChangeMaterialParticle m_particle;
    private uint m_uiParticleIndex = 0;
    private bool m_isSetAlpha = false;

    public CBirthState(CBaseNpc pNpc)
        : base(pNpc, eActionState.Birth, true, false, false, true)
    {
        m_pBirthTimer = new Timer();
    }

    public override void EnterState()
    {
        base.EnterState();

        Monster monster = m_pNpc as Monster;

        uint actID = (uint)monster.GetBirthActID();
        if (null != monster && null != monster.SummonerNpc)
        {
            //延迟0.12 fixposition
            UnityCallBackManager.GetInst().AddCallBack(0.12f, delegate(object[] args)
            {
                m_uiParticleIndex = m_pNpc.PlayBirthAction(actID);
            } );
        }
        else
        {
            m_uiParticleIndex = m_pNpc.PlayBirthAction(actID);
        }
        

        //播放出生前加载的石化渐变特效
        m_particle = CParticleManager.GetInst().GetParticle(m_pNpc.ChangeMaterialParticleIndex) as CChangeMaterialParticle;

        if (m_particle != null)
            m_particle.StartPlay();

        if (!m_pNpc.HasUnBirthActID)
        {
            m_pBirthTimer.SetTimer(0.2f);
            m_pNpc.ShowWeapon(false);
        }
        else
        {
            m_isSetAlpha = true;
        }

        //没有出生动作,离开
        if (actID == 0)
        {
            m_pNpc.LeaveState(eActionState.Birth);
        }
        else
        {
            m_pNpc.AddBuff(DEFINE.BIRTH_BUFF_ID);
        }

    }

    public override void Update()
    {
        base.Update();

        m_pNpc.Move(0);

        if (m_pBirthTimer.IsExpired(false))
        {
            m_pNpc.SetAlphaVertexColorOn(0f);
            m_pNpc.ShowWeapon(true);
            m_pBirthTimer.Release();
            m_isSetAlpha = true;
        }
    }

    public override void BreakState()
    {
        base.BreakState();

        if (m_uiParticleIndex != 0)
        {
            CParticleManager.GetInst().AddDestroyParticle(m_uiParticleIndex);
        }

        if (!m_isSetAlpha)
        {
            m_pNpc.SetAlphaVertexColorOn(0f);
            m_pNpc.ShowWeapon(true);
            m_pBirthTimer.Release();
        }

        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_HIDE_BUFF_ID);
    }

    public override void LeaveState()
    {
        base.LeaveState();

        if (!m_pBirthTimer.IsExpired(false) && m_pBirthTimer.IsStart())
        {
            m_pNpc.SetAlphaVertexColorOn(0f);
            m_pNpc.ShowWeapon(true);
            m_pBirthTimer.Release();
        }

        //m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_HIDE_BUFF_ID);
    }
}
