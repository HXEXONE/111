﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//出生前状态（石化）
public class CUnBirthState : CBaseState
{
    private Timer m_pBirthTimer;
    private bool m_isSetAlpha = false;

    public CUnBirthState(CBaseNpc pNpc)
        : base(pNpc, eActionState.UnBirth, false, false, false, true)
    {
        m_pBirthTimer = new Timer();
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        Monster monster = (Monster)m_pNpc;
        uint actID = (uint)monster.GetUnBirthActID();

        m_pBirthTimer.SetTimer(0.2f);

        m_pNpc.PlayBirthAction(actID);
       
    }

    public override void Update()
    {
        base.Update();

        m_pNpc.Move(0);

        if (m_pBirthTimer.IsExpired(false))
        {
            m_pNpc.SetAlphaVertexColorOn(0f);
            m_pNpc.ShowWeapon(true);
            m_pBirthTimer.Release();
            m_isSetAlpha = true;
        }

        BattleScene pBattleScene = m_pNpc.CurrBattleScene;
        if (null != pBattleScene)
        {
            List<CBaseNpc> rangeNpcList = m_pNpc.GetRangeNpcList();
            foreach (CBaseNpc pNpc in rangeNpcList)
            {
                if (CBaseNpc.AffectResult(eAffectType.AffectEnemy, eAffectEffect.NegativeEffect, m_pNpc, pNpc, eEffectRangeType.JudgeType, eSkillAtkType.GroundAirAtk))
                {
                    float distance = Common.GetHorizontalDis(pNpc.GetPosition(), m_pNpc.GetPosition());
                    if (distance < 10f)
                    {				
                        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
                        m_pNpc.EnterState(eActionState.Birth);
                        break;
                    }
                }
            }
        }
      
    }


    public override void BreakState()
    {
        base.BreakState();
        if (!m_isSetAlpha)
        {
            m_pNpc.SetAlphaVertexColorOn(0f);
            m_pNpc.ShowWeapon(true);
            m_pBirthTimer.Release();
        }
    }
}
