﻿using UnityEngine;
using System.Collections;

//BOSS虚弱状态
public class CBossWeaknessState : CBaseState
{
    public CBossWeaknessState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BossWeakness, false, false, true, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();
        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddBuff(DEFINE.BOSS_WEAKNESS_BUFF_ID);

    }

    public override void LeaveState()
    {
        base.LeaveState();

        m_pNpc.DelBuff(DEFINE.BOSS_WEAKNESS_BUFF_ID);

        //重置怪物的虚弱血量计数
        NpcAI pAI = m_pNpc.AI;
        if (pAI != null)
        {
            pAI.ResetWeaknessCount();
        }
        
    }
}
