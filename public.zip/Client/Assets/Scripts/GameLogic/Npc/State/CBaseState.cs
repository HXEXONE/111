using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CBaseState
{
    protected CBaseNpc m_pNpc;
    protected eActionState m_state;
    protected float m_fActionSpeed;

    protected eCheckActState m_eCheckState;
    protected float m_fCheckTime;
    protected bool m_bSetActionTime;
    
    protected Timer m_pTimer;
    protected float m_fTime;
    protected float m_fAnkylosisTime;   //Ӳֵʱ��
    protected string m_szActionName;

    protected float m_fHorizontalSpeed;     //ˮƽ�ٶ�
    protected float m_fHorizontalDis;           //ˮƽ����
    protected Timer m_pHorzontalTimer;          //ˮƽλ��timer
    protected float m_fHorDealyTime;
    protected Timer m_pHorDelayTimer;     //ˮƽλ���ӳ�timer

    protected bool m_bSpecial;//�Ƿ�����״̬,Attack������״̬,����������Ҳ�����˳���״̬
    protected bool m_bLastState;         //�Ƿ����״̬(״̬����Ϻ��ȵ���ǰ״̬�������ٽ���)
    protected bool m_bBreaked;          //�Ƿ�ɱ����,Ŀǰֻ�б��� ���ɱ����

    protected Timer m_pJudgeTimer;//�����жϼ��

    protected List<uint> m_particleList =new List<uint>(); //������ЧID

    public void AddParticle(uint uiIndex)
    {
        if (m_particleList.Contains(uiIndex))
        {
            return; 
        }
        m_particleList.Add(uiIndex);

        //if ( m_pNpc is Avatar )
        {
            //MyLog.Log( this + " AddParticle : " + uiIndex);
        }
    }



    public CBaseState(CBaseNpc pNpc, eActionState state,bool bSetActionTime,bool bSpecial,bool bLast,bool bBreaked)
    {
        m_pNpc = pNpc;
        m_state = state;
        m_pTimer = new Timer();
        m_pHorzontalTimer = new Timer();
        m_pHorDelayTimer = new Timer();

        m_bSetActionTime = bSetActionTime;
        m_bSpecial = bSpecial;
        m_bLastState = bLast;
        m_bBreaked = bBreaked;        

        m_eCheckState = eCheckActState.NONE;
   
        m_fTime = -1;
        m_fActionSpeed = 1.0f;
        m_fAnkylosisTime = 0f;
        m_fHorDealyTime = 0f;
        m_fHorizontalDis = 0;

        m_pJudgeTimer = new Timer();
        m_pJudgeTimer.SetTimer(DEFINE.NPC_ATTACK_JUDGE_TIME);

        //SetActionSpeed(1);
    }

    public eCheckActState CheckActState
    {
        get { return m_eCheckState; }
    }

    public void SetActionInfo(string szActionName,float fSpeed) 
    {
        m_szActionName = szActionName;
        SetActionSpeed(fSpeed);

        m_pNpc.PlayAction(szActionName, fSpeed, true);

    }

    public void SetActionInfo(float fSpeed)
    {
        m_szActionName = stStateData.GetActionName(m_state);
        SetActionSpeed(fSpeed);
    }

    //����ˮƽ��Ϣ
    public virtual void SetHorizontalInfo(float fDistance,float fHorSpeed,float delayTme = 0)
    {
        m_fHorizontalDis = fDistance;

        if (m_pNpc.CurrBattleScene.BattleType == eBattleType.Pvp || m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve)
        {
            //�ٶ�����            
            fHorSpeed = Mathf.Min(fHorSpeed,2f);
        }

        m_fHorizontalSpeed = fHorSpeed;
        m_fHorDealyTime = delayTme;

        m_pHorDelayTimer.SetTimer(delayTme);

        m_pHorzontalTimer.SetTimer(Mathf.Abs(m_fHorizontalDis / m_fHorizontalSpeed) + delayTme);

    }

    public virtual void SetTimer(float fTime)
    {
        m_fTime = fTime;
        if (m_fTime != -1)
        {
            m_pTimer.SetTimer(m_fTime);
        }
    }

    public float LeftTime
    {
        get
        {
            if ( m_fTime == -1 )
            {
                return m_fTime;
            }

            return m_pTimer.GetLeftTime();
        }
    }

    public void AddTime(float fTime)
    {
        if (fTime != -1)
        {
            m_pTimer.AddExpireTime(fTime);
        }
    }

    public bool LastState
    {
        get
        {
            return m_bLastState;
        }
    }

    public bool CanBeBreak
    {
        get{ return m_bBreaked; }
    }    

    public void SetAnkylosisTime(float time)
    {
        m_fAnkylosisTime = time;
    }

    public void SetActionSpeed(float fSpeed)
    {
        m_fActionSpeed = fSpeed;
        m_pNpc.SetAnimationSpeed(m_fActionSpeed);

    }


    public virtual void EnterState() 
    {
        m_pJudgeTimer.ResetTimer();

        if (m_bSetActionTime)
        {
            m_eCheckState = eCheckActState.StartCheck;
            m_fCheckTime = Time.time;
        }

        if (m_state != eActionState.Skill)
        {
            m_particleList.Clear();
        }

        if (m_pNpc.UnitsType == eNpcUnitsType.Ground)
        {
            if (m_state == eActionState.Run || 
                m_state == eActionState.Walk ||
                m_state == eActionState.Roll ||
                m_state == eActionState.Dead || 
                m_state == eActionState.Behit || 
                m_state == eActionState.Down ||
                m_state == eActionState.BeatFly)
            {
                m_pNpc.SetNavmeshObstacleEnable(false);
            }
            else
            {
                m_pNpc.SetNavmeshObstacleEnable(true);
            }
        }

        if (/*m_pNpc is Monster ||*/ m_pNpc is RealAvatar)
        {
/*                        Debug.LogError(m_pNpc + " EnterState : " + this);*/
        }


        //����״̬ʱǿ������һ��,�����жϴ�����ǽʱ���������
        m_fHorizontalDis = 0;
    }

    public virtual void LeaveState()
    {

//         if (/*m_pNpc is Monster ||*/ m_pNpc is EnemyAvatar)
//         {
//             //MyLog.Log(m_pNpc + " LeaveState : " + this + " time : " + Time.time);
//         }

        if (m_pNpc is Avatar)
        {
            ((Avatar)m_pNpc).InMouseControl = false;
        }
        m_pTimer.Release();
  
    }

    //״̬�����
    public virtual void BreakState() 
    {
//         if (/*m_pNpc is Monster ||*/ m_pNpc is EnemyAvatar)
//         {
//             MyLog.Log(m_pNpc + " BreakState : " + this + " time : " + Time.time);
//         }

        if (m_pNpc is Avatar)
        {
            ((Avatar)m_pNpc).InMouseControl = false;
        }

        //���������,��Чǿ��ֹͣ����
        if (m_particleList.Count > 0)
        {                        
            for (int i = 0, len = m_particleList.Count; i < len; i++ )
            {                
                CParticle particle = CParticleManager.GetInst().GetParticle(m_particleList[i]);
                if (null != particle)
                {
                    //particle.ParticleEnabled = false;
                    particle.Remove();              
                }
            }

            m_particleList.Clear();
        }
    }

    public virtual float GetActionTime()
    {
        //CAnimatorStateInfo info = m_pNpc.GetPlayAniState();
        //if (null == info || !info.bStartPlay) return -1;

        //return info.state.length / Mathf.Abs(info.aniSpeed);
//         if (m_pNpc is Avatar && m_pNpc.PlayActionTime != -1f)
//         {
//             MyLog.LogError(m_pNpc + " ActionTime  :  " + m_pNpc.PlayActionTime);
//         }
        return m_pNpc.PlayActionTime;
    }


    public virtual void Update()
    {
        if (m_fTime != -1 && m_eCheckState != eCheckActState.StartCheck)
        {
            if (m_pTimer.IsExpired(false))
            {
                m_pNpc.LeaveState(m_state);
            }
        }

        if (m_eCheckState == eCheckActState.StartCheck)
        {
            float fActionTime = GetActionTime();
            if (fActionTime != -1)
            {
                if (fActionTime != 0f)
                {
                    fActionTime -= Time.time - m_fCheckTime;
                }                
                fActionTime += m_fHorDealyTime;

                if (!m_bSpecial)
                {
                    SetTimer(fActionTime);
                }
                    
                m_pNpc.SetActionTimer(fActionTime);
                m_eCheckState = eCheckActState.CheckOver;
            }
        }
    }

    public eActionState GetState() { return m_state; }

    //protected void SetMonsterCollisionMode(bool enter)
    //{
    //    if (m_pNpc.NpcSort == eNpcSort.Monster)
    //    {
    //        Monster pMonster = (Monster)m_pNpc;
    //        if (enter && m_fHorizontalSpeed > 5)
    //        {
    //            pMonster.SetRigidbodyCollisionDetection(CollisionDetectionMode.ContinuousDynamic);
    //        }
    //        else
    //        {
    //            pMonster.SetRigidbodyCollisionDetection(CollisionDetectionMode.Discrete);
    //        }
            
    //    }
    //}

}
