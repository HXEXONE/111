﻿using UnityEngine;
using System.Collections;

public class CPetBeginFlyState : CBaseState
{
    public CPetBeginFlyState(CBaseNpc pNpc) :
        base(pNpc, eActionState.PetBeginFly, false, false, false, true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;

    }

}
