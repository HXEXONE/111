﻿using UnityEngine;
using System.Collections;

public class CPetFlyFightState : CBaseState
{

    public CPetFlyFightState(CBaseNpc pNpc) :
        base(pNpc, eActionState.PetFlyFight, false, false, true, true)
    {
        
    }

    public override void EnterState()
    {
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
    }
}
