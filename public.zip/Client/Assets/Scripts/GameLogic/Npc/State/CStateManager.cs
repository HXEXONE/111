using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CStateManager
{
    private CBaseNpc m_pNpc;
    private CBaseState m_currState;
    private eStateType m_stateType;

    private Dictionary<eActionState, CBaseState> m_stateDict = new Dictionary<eActionState, CBaseState>();

    private List<eActionState> m_lastActList = new List<eActionState>(); //�����ļ���״̬(ѣ�Ρ����Ρ������� .)

    public CStateManager(CBaseNpc pNpc)
    {
        m_pNpc = pNpc;        
        Reuse();        

        RegisterState(new CAssaultState(pNpc));
        RegisterState(new CAttackState(pNpc));
        RegisterState(new CBeatDownState(pNpc));
        RegisterState(new CBeatFlyState(pNpc));
        RegisterState(new CBeHitState(pNpc));
        RegisterState(new CAttractState(pNpc));
        RegisterState(new CWalkState(pNpc));
        RegisterState(new CRunState(pNpc));
        RegisterState(new CSmoothMoveState(pNpc));
        RegisterState(new CRanMoveState(pNpc));
        RegisterState(new CSkillState(pNpc));
        RegisterState(new CGrabState(pNpc));
        RegisterState(new CRagdollState(pNpc));
        RegisterState(new CNormalState(pNpc));
        RegisterState(new CStunState(pNpc));
        RegisterState(new CFrostState(pNpc));
        RegisterState(new CVariationState(pNpc));
        RegisterState(new CDeadState(pNpc));
        RegisterState(new CGrabHitState(pNpc));
        RegisterState(new CScaredState(pNpc));
        RegisterState(new CTurningState(pNpc));
		RegisterState(new CHookState(pNpc));
        RegisterState(new CWaitState(pNpc));

        if (pNpc.IsBoss())
        {
            RegisterState(new CBossRambleState(pNpc));
            RegisterState(new CBossSneerState(pNpc));
            RegisterState(new CBossWeaknessState(pNpc));
        }

        if (pNpc.NpcSort == eNpcSort.Avatar || 
            pNpc.NpcSort == eNpcSort.EnermyAvatar || 
            pNpc.NpcSort == eNpcSort.BattlePlayer ||
            pNpc.NpcSort == eNpcSort.PvpEnemyAvatar ||
            pNpc.NpcSort == eNpcSort.FriendlyAvatar)
        {
           
            //RegisterState(new CWaitState(pNpc));
            RegisterState(new CRollState(pNpc));
            //RegisterState(new CHookState(pNpc));
            RegisterState(new CResurrectState(pNpc));
            RegisterState(new CSwitchPartner(pNpc));

            RegisterState(new CRideJumpState(pNpc));
            RegisterState(new CBeginRideState(pNpc));
            RegisterState(new CEndRideState(pNpc));

            RegisterState(new CBeginFlyState(pNpc));
            RegisterState(new CEndFlyState(pNpc));
            RegisterState(new CChargeState(pNpc));
        }
        else if (pNpc.NpcSort == eNpcSort.Pet)
        {
            RegisterState(new CPetFlyFightState(pNpc));
            RegisterState(new CPetBeginFlyState(pNpc));
        }
        else if (pNpc.NpcSort == eNpcSort.Monster)
        {
            RegisterState(new CShapeshiftState(pNpc));
            RegisterState(new CBirthState(pNpc));
            RegisterState(new CUnBirthState(pNpc));
            RegisterState(new CScaunterState(pNpc));
            //RegisterState(new CInactiveState(pNpc));
            //RegisterState(new CFloatingState(pNpc));
        }
        
        
    }

    private void RegisterState(CBaseState pState)
    {
        eActionState eState = pState.GetState();
        m_stateDict.Add(eState, pState);
    }

    //ǿ�ƴ��
    public void EnterState( eActionState state,bool forceBreak = false)
    {
        if (m_currState != null)
        {
            //��ǰ״̬���ܱ����
            if (!m_currState.CanBeBreak && !forceBreak)
            {
                return;
            }
            if (m_stateType == eStateType.EnterState)
            {
                if (state != m_currState.GetState())
                    m_currState.BreakState();
            }
        }

        CBaseState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            m_stateType = eStateType.EnterState;

            if (pState.LastState)
            {
                if (!m_lastActList.Contains(state))
                {
                    m_lastActList.Add(state);
                }
                CheckLastState();
            }
            else
            {
                m_currState = pState;
                pState.EnterState();
            }

            //m_stateType = eStateType.EnterState;
        }

    }

    public void LeaveState( eActionState state )
    {
        CBaseState pState = null;
        m_stateDict.TryGetValue(state, out pState);
        if (pState != null)
        {
            if (m_currState != null && m_currState == pState)
            {
                m_stateType = eStateType.LeaveState;

                pState.LeaveState();

                //LeaveState���ܻ�EnterState �����ж�һ��
                if (m_currState == pState)
                {
                    if (pState.LastState)
                    {
                        if (m_lastActList.Contains(state))
                        {
                            m_lastActList.Remove(state);
                        }
                    }
                    CheckLastState();
                }                                
             }
            //m_stateType = eStateType.LeaveState;
        }
    }

    //����״̬���
    public void CheckLastState() 
    {
        if (m_lastActList.Count > 0)
        {
            m_lastActList.Sort();

            int nLastIndex = m_lastActList.Count - 1;

            CBaseState pState = null;

            m_stateDict.TryGetValue(m_lastActList[nLastIndex], out pState);

            if (pState != null)
            {
                m_currState = pState;
                pState.EnterState();
                m_pNpc.ResetWeaponAnimtor();                

                m_stateType = eStateType.EnterState;
            }
        }        
    }

    public void Reuse() 
    {
        m_stateType = eStateType.None;
        m_currState = null;
        m_lastActList.Clear();
        m_lastActList.Add(eActionState.Idle);
    }

    public void ClearLastActList()
    {
        m_lastActList.Clear();
        m_lastActList.Add(eActionState.Idle);
    }

    public CBaseState GetState(eActionState state)
    {
        CBaseState pState = null;
        m_stateDict.TryGetValue(state, out pState);

        return pState;
    }

    public eActionState GetCurrActState() 
    {
        if (null == m_currState)
        {
            return eActionState.None;
        }

        return m_currState.GetState();
    }

    public CBaseState GetCurrState()
    {
        return m_currState;
    }

    public void Update()
    {

        if (m_currState != null)
        {
            m_currState.Update();
        }
    }
}
