using UnityEngine;
using System.Collections;

public class CStunState : CBaseState
{
    public CStunState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Stun, false, false, true, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();
        m_pNpc.PlayAction(m_state, m_fActionSpeed,false);
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

    }

    public override void BreakState()
    {
        base.BreakState();
    } 

}
