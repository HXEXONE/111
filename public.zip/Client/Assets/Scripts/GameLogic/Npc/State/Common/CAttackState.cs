using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CAttackState : CBaseState
{
    private List<CBaseNpc> m_targetList = new List<CBaseNpc>();


    private Timer m_turnTimer;//ת��ʱ��

    public CAttackState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Attack, true, true, false, true)
    {
    }



    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;

        m_pNpc.NormalAtkTime = Time.time;

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer player = (BaseBattlePlayer)m_pNpc;
            if (player.IsInRide() || player.IsInFly() )
            {
                m_pNpc.ApplyRootMotion = false;
                m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;
            }
            else
            {
                CBaseNpc target = m_pNpc.CurrTarget;
                if (target != null && (target.IsOverlord() || target.IsFrost()))
                {
                    m_pNpc.ApplyRootMotion = false;
                }
                else
                {
                    m_pNpc.ApplyRootMotion = true;
                }

                m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 2;
            }
            
        }
        else
        {
            m_pNpc.ApplyRootMotion = true;
         
            m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 2;
        }

        m_pNpc.ApplyRootMotion = true;
        m_pNpc.EnablePathFinding(false);

        //MyLog.LogError(" EnterState : " + this + " name " + HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.attackID).GetSkillName());
        
    }

    public override void LeaveState()
    {
        m_pNpc.CountingNormalSkill();

        base.LeaveState();
    }

    public override void BreakState()
    {
        //m_pNpc.BreakNormalSkill(m_pNpc.DefaultSkillID);

        base.BreakState();

    }

    //׷������
    public bool CanChase(SkillContent pSkillLoader = null )
    {
        BaseBattlePlayer bbp = m_pNpc as BaseBattlePlayer;
        if (null == bbp)
            return false;

        if (bbp.JobType == eJobType.Wizard)
            return false;
        
        if ( null == pSkillLoader )
        {
            pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.attackID);
            if ( null == pSkillLoader )
            {
                return false;
            }            
        }
        CBattleSceneLoading pcbsl = SingletonObject<CBattleSceneLoading>.GetInst();
//         if (pcbsl.battleType == eBattleType.Arena ||
//             pcbsl.battleType == eBattleType.Wasteland ||
//             pcbsl.battleType == eBattleType.Mining)
//         {
//             return false;
//         }

        if ( pSkillLoader.SkillRange == (byte)eSkillRange.FlyParticleAoe ||
             pSkillLoader.SkillRange == (byte)eSkillRange.FlyParticleSingle ||
             pSkillLoader.SkillRange == (byte)eSkillRange.RandomPoint)
        {
            return false;
        }        


        if ( null != m_pNpc.CurrTarget && m_pNpc.CurrTarget.IsHide())
        {
            return false;
        }

        if (  null != m_pNpc.CurrTarget && m_pNpc.CurrTarget.GetCurrActState() == eActionState.Skill)
        {
            return false;
        }

        return true;
    }

    private bool ChaseAttack()
    {
        bool chaseAttack = false;

        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.attackID);
        if (null == pSkillLoader)
        {
            return chaseAttack;
        }

        if (!CanChase(pSkillLoader))
        {
            return chaseAttack;
        }

        if (m_pNpc.CurrTarget != null)
        {
            Vector3 myPosition = m_pNpc.GetPosition();
            Vector3 targetPosition = m_pNpc.CurrTarget.GetPosition();
            float distance = Common.Get2DVecter3Length(targetPosition, myPosition);
            float closeDistance = m_pNpc.MinNormalAtkRange + m_pNpc.CurrTarget.CharacterRadius;
            float snuglyDistance = m_pNpc.CharacterRadius + m_pNpc.CurrTarget.CharacterRadius;

            bool isFirst = (pSkillLoader.Key == pSkillLoader.FirstSkillID);
            bool isLast = (pSkillLoader.NextSkill[0] == 0);
            
            bool isNormal = (!isFirst && !isLast);

            if ( (isFirst && m_pNpc.attackDone) || (isLast && !m_pNpc.attackDone) || isNormal )
            {
                Ray ray = new Ray(myPosition, targetPosition + Vector3.up * 1 - myPosition);

                chaseAttack = true;

                if (Physics.Raycast(ray, Vector3.Distance(myPosition, targetPosition), 1 << DEFINE.AIR_WALL))
                {
                    chaseAttack = false;
                }

                //�ж�Ҫ��Ҫ׷��
                //if (chaseAttack && distance + m_pNpc.CharacterRadius + m_pNpc.CurrTarget.CharacterRadius > (m_pNpc.MinNormalAtkRange + DEFINE.AVATAR_ATTACK_CHASE_DISTANCE))
                if (chaseAttack && distance + m_pNpc.CharacterRadius + m_pNpc.CurrTarget.CharacterRadius > pSkillLoader.JudgeArgs[1] + DEFINE.AVATAR_ATTACK_CHASE_DISTANCE)
                {
                    chaseAttack = false;
                }

//                 if (chaseAttack && distance + m_pNpc.CharacterRadius + m_pNpc.CurrTarget.CharacterRadius > (m_pNpc.MinNormalAtkRange + DEFINE.AVATAR_ATTACK_CHASE_DISTANCE))
//                 {
//                     chaseAttack = false;
//                 }
       

//                if (!m_bChasingAttack && distance <= closeDistance)
//                {
//                    chaseAttack = false;
//                }

                //if (distance <= m_pNpc.MinNormalAtkRange)
                if (distance <= pSkillLoader.JudgeArgs[1] )
                {
                    chaseAttack = false;
                }

                if (m_pNpc.IsSnugly(m_pNpc.CurrTarget))
                {
                    chaseAttack = false;
                }

                //��������׷��
                if (m_pNpc is BaseBattlePlayer)
                {
                    BaseBattlePlayer pbbp = (BaseBattlePlayer)m_pNpc;
                    if (pbbp.IsInRide() || pbbp.IsInFly())
                    {
                        chaseAttack = false;
                    }
                }

            }

            if (chaseAttack)
            {
                //MyLog.Log(" chaseAtk ..");
                m_pNpc.ChaseTarget(m_pNpc.CurrTarget);

                float movespeed = m_pNpc.MoveSpeed  * Mathf.Pow(distance / closeDistance, 5) * 2f;
 
                m_pNpc.Move(movespeed, true);

                //Debug.Log( m_pNpc + " chase MoveSpeed :  " + movespeed);
            }
        }
        return chaseAttack;
    }

    public override void Update()
    {
        base.Update();

        //MyLog.LogWarning(" Update Attack befroce ...  : " + m_pNpc.GetPosition());
        //Debug.LogError(" m_eCheckState : " + m_eCheckState);
        if (m_eCheckState == eCheckActState.CheckOver)        
        {

            bool bNotInAction = m_pNpc.NotInAction();

            if (((m_pNpc is Monster) || m_pNpc.NpcSort == eNpcSort.BattlePlayer) && bNotInAction)
            {
                eNpcBehaviour eBehaviour = m_pNpc.CheckNpcBehaviour();
                switch (eBehaviour)
                {
                    case eNpcBehaviour.None:
                    case eNpcBehaviour.GameStory:
                        {
                            m_pNpc.LeaveState(m_state);
                        }
                        break;
                    case eNpcBehaviour.WaitMessage:
                        {
                            if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve)
                            {
                                m_pNpc.EnterState(eActionState.Wait);
                                return;
                            }
                        }
                        break;
                }

            }
            else if (m_pNpc.NpcSort == eNpcSort.EnermyAvatar /*&& bNotInAction*/)
            {
                //EnemyAvatar pAvatar = (EnemyAvatar)m_pNpc;
                BaseBattlePlayer pAvatar = m_pNpc as BaseBattlePlayer;

                uint uiSkillType = pAvatar.DefaultSkillID;
                CBaseNpc pCurrTarget = pAvatar.CurrTarget;

                ChaseAttack();

                if(  bNotInAction )
                {
                    eNpcBehaviour eBehaviour = pAvatar.CheckNpcBehaviour();
                    switch (eBehaviour)
                    {
                        case eNpcBehaviour.None:
                            {
                                if (!pAvatar.IsInRide() && !pAvatar.IsInFly())
                                {
                                    //pAvatar.BreakNormalSkill(uiSkillType);
                                    pAvatar.CountingNormalSkill();
                                }

                                pAvatar.LeaveState(m_state);
                                                                                            
                                //if (pAvatar.CurrTarget != null && !pAvatar.CurrTarget.IsDead())
                                //{
                                //    pAvatar.WalkForward(3);
                                //}
                            }
                            break;
                    }
                }
            }
            else if (m_pNpc.NpcSort == eNpcSort.Avatar || 
                       m_pNpc.NpcSort == eNpcSort.PvpEnemyAvatar||
                       m_pNpc.NpcSort == eNpcSort.FriendlyAvatar)
            {
                //Avatar pAvatar = (Avatar)m_pNpc;
                RealAvatar pAvatar = (RealAvatar)m_pNpc;
                eBattleType battleType = pAvatar.CurrBattleScene.BattleType;
                bool isInRide = pAvatar.IsInRide();

                if (isInRide && battleType != eBattleType.Arena)
                {
                    m_pNpc.Move(m_pNpc.MoveSpeed);
                }

                ChaseAttack();

                if (pAvatar.NextPosition != Vector3.zero && m_pNpc.NpcSort == eNpcSort.Avatar) //PvpEnemyPlayer��������
                {
                    bool sendMsg = (m_pNpc as Avatar).AvatarType == eAvatarType.RealAvatar;
                    bool immediateTurn = true;
                    if (isInRide || pAvatar.IsInFly())
                    {
                        immediateTurn = false;

                        if (null == m_turnTimer) m_turnTimer = new Timer();
                        m_turnTimer.SetTimer(pAvatar.TurningTime);

                        pAvatar.CheckRotateOrRun(pAvatar.NextPosition, immediateTurn, true, sendMsg);
                        pAvatar.NextPosition = Vector3.zero;
                    }
                    else if (bNotInAction)
                    {
                        pAvatar.CheckRotateOrRun(pAvatar.NextPosition, immediateTurn, true, sendMsg);
                        pAvatar.NextPosition = Vector3.zero;
                    }

                    //�����ai���ж��߼�
                    if (m_pNpc is Avatar)
                    {
                        ((Avatar)m_pNpc).InMouseControl = true;
                    }                      
                               
                }
                else if (bNotInAction )
                {
                    if (m_turnTimer == null || (m_turnTimer != null && m_turnTimer.IsExpired(false)))
                    {
                        uint uiSkillType = pAvatar.DefaultSkillID;
                        CBaseNpc pCurrTarget = pAvatar.CurrTarget;

                        //if (!ChaseAttack())
                        {
                            eNpcBehaviour eBehaviour = pAvatar.CheckNpcBehaviour();

                          
                            if (eBehaviour == eNpcBehaviour.NoneBehaviour ||
                                eBehaviour == eNpcBehaviour.WaitAtkMessage)
                            {
                                BaseBattlePlayer bp = m_pNpc as BaseBattlePlayer;
                                if (bp.IsInRide() || bp.IsInFly())
                                {
                                    eBehaviour = eNpcBehaviour.None;
                                }
                            }                                                        
                            switch (eBehaviour)
                            {                                
                                case eNpcBehaviour.NoneBehaviour:
                                case eNpcBehaviour.WaitAtkMessage:
                                    {
                                        //m_pNpc.PlayAction(eActionState.Idle, 1.0f, false, 0.8f);
                                        m_pNpc.EnterState(eActionState.Wait);
                                    }
                                    break;
                                case eNpcBehaviour.Chase:
                                    {
                                        if (CanChase() && battleType != eBattleType.Pvp && battleType != eBattleType.MultiPve) //PVP������׷��
                                        {
                                            CRunState runstate = m_pNpc.GetCurrState() as CRunState;
                                            if (null != runstate)
                                            {
                                                runstate.Chase = true;
                                                m_pNpc.CountingNormalSkill();
                                            }
                                        }
                                        else
                                        {
                                            m_pNpc.LeaveState(m_state);
                                        }
                                    }
                                    break;
                                case eNpcBehaviour.None:
                                    {
                                        if (m_pNpc.NpcSort == eNpcSort.Avatar)
                                        {
                                            if (isInRide && battleType != eBattleType.Arena )
                                            {
                                                bool sendMsg = pAvatar is Avatar && (pAvatar as Avatar).AvatarType == eAvatarType.RealAvatar;
                                                Vector3 destPosition = pAvatar.RunForward(100f, sendMsg);                                                                                                                                                
                                            }
                                            else if (pAvatar.IsInFly())
                                            {

                                            }
                                            else                                                                        
                                            {
                                                if ((pAvatar.CurrTarget == null || pAvatar.CurrTarget.IsDead()) && pAvatar.GetCurrActState() != eActionState.Run)
                                                {
                                                    bool sendMsg = pAvatar is Avatar && (pAvatar as Avatar).AvatarType == eAvatarType.RealAvatar;
                                                    Vector3 destPositon = pAvatar.WalkForward(6, sendMsg);
                                                }

                                                //m_pNpc.BreakNormalSkill(uiSkillType);
                                                m_pNpc.CountingNormalSkill();
                                            }
                                        }
                                        m_pNpc.LeaveState(m_state);
                                    }
                                    break;
                            }
                        }   
                    }
                }
            }
            else if (m_pNpc.NpcSort == eNpcSort.AIFriend && bNotInAction)
            {
                AIFriend pAIFriend = (AIFriend)m_pNpc;

                uint uiSkillType = pAIFriend.DefaultSkillID;
                CBaseNpc pCurrTarget = pAIFriend.CurrTarget;

                if (!ChaseAttack())
                {
                    eNpcBehaviour eBehaviour = pAIFriend.CheckNpcBehaviour();
                    switch (eBehaviour)
                    {
                        case eNpcBehaviour.None:
                            {
                                //pAIFriend.BreakNormalSkill(uiSkillType);
                                pAIFriend.CountingNormalSkill();
                                pAIFriend.LeaveState(m_state);

                                //if (pAIFriend.CurrTarget != null && !pAIFriend.CurrTarget.IsDead())
                                //{
                                //    pAIFriend.WalkForward(3);
                                //}
                            }
                            break;
                    }
                }
            }
        }

        //MyLog.LogWarning(" Update Attack after ...  : " + m_pNpc.GetPosition());
    }
}
