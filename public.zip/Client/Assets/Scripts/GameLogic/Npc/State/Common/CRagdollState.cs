﻿using UnityEngine;
using System.Collections;

//布娃娃状态
public class CRagdollState : CBaseState
{
    private float m_fStartTime;
    private const string BindName = DEFINE.BONE_Spine;

    private Timer m_pResetTimer = null;
    private uint m_uiCameraID;

    public CRagdollState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Ragdoll, false, false, false, true)
    {
        m_uiCameraID = 0;
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.HideWeapon();

        if (m_pNpc is Avatar)
        {
            m_pResetTimer = new Timer();
            m_pResetTimer.SetTimer(1.5f);
        }
        else
        {
            m_pResetTimer = null;
            m_pNpc.NpcDead(true);
        }


        SceneInfoContent info = m_pNpc.CurrBattleScene.SceneLoaderInfo;
        if (info != null)
        {
            m_uiCameraID = (uint)info.CameraID;
        }
    }


    //pAttacker 抓取者
    //offset_x_ration x轴的偏转角度
    //forceValue 力的大小
    public void SetRagdollInfo(CBaseNpc pAttacker,float offset_x_ration,float forceValue ) 
    {       
        //布娃娃作用
        Vector3 force = new Vector3();
        Quaternion qot = pAttacker.GetTransform().rotation;

        //新建一下GameObject记录人物朝向偏转值,
        GameObject go = new GameObject();
        Quaternion goQot = go.transform.rotation;
        //人物绕x轴旋转-offset_x_ration度        

        goQot.eulerAngles = new Vector3(qot.eulerAngles.x - offset_x_ration, qot.eulerAngles.y, qot.eulerAngles.z);
        go.transform.rotation = goQot;

        SceneContent mapLoader = SingletonObject<BattleScene>.GetInst().GetSceneLoader();
        if ( null != mapLoader )
        {
            if (mapLoader.Key / 10000 == 1007) //第七章特殊处理
            {
                if (forceValue > 10f)
                {
                    forceValue = 10f;
                }                
            }            
        }

        //forceValue = Mathf.Min(20f, forceValue);
        Vector3 dir = go.transform.forward;
        force = dir * forceValue;           
        //布娃娃作用力(胸部绑点)
      
        m_pNpc.AddRagdollForce(BindName, force);

        UnityEngine.Object.Destroy(go);
    }


    private void ResetPostion() 
    {
        Transform npcTrans = m_pNpc.GetTransform();
        Transform bindTrans = Common.GetBone(npcTrans, BindName);

        //位置修正             
        Vector3 bindPos = bindTrans.position;
        Vector3 resetPos = Common.NavSamplePosition(bindPos) + new Vector3(0f, 0.5f, 0f);
        npcTrans.position = resetPos;
        npcTrans.up = Vector3.up;

        m_pNpc.ApplyRagdoll = false;

        m_pNpc.HideWeapon(false);
        m_pNpc.SetFootEffect(true);
        //起身动作
        m_pNpc.PlayAction("getup");

        m_pResetTimer = null;
        UnityCallBackManager.GetInst().AddCallBack(1.67f, GetUpFinish);
    }

    private void GetUpFinish(params object[] args) 
    {
        m_pNpc.IsBeGrab = false;

        m_pNpc.SetAnimationSpeed(1.0f);

        m_pNpc.EnterState(eActionState.Idle);
        if (m_uiCameraID != 0)
        {
            //恢复视角
            CCamera.GetInst().SetCameraEffect(m_uiCameraID,null, null, new object[] { m_pNpc.GetTransform().gameObject, eCAMERAFOLLOW.DIRECT, true,true });
        }
    }

    public override void Update()
    {
        base.Update();

        if (null != m_pResetTimer)
        {
            if (m_pResetTimer.IsExpired(false))
            {
                ResetPostion();
            }
            else
            {
                CameraLockBindTrans();
            }
        }        

//         Transform bindTrans = Common.GetBone(m_pNpc.GetTransform(), BindName);
//         MyLog.Log(" location : " + bindTrans.position);
    }

    //相机锁定绑点（跟随）
    private void CameraLockBindTrans() 
    {
        Transform npcTrans = m_pNpc.GetTransform();
        if (null != npcTrans)
        {
            Transform bindTrans = Common.GetBone(npcTrans, BindName);
            if (m_uiCameraID != 0)
            {
                //让摄像机 对准 BindName 绑点
                CCamera.GetInst().SetCameraEffect(m_uiCameraID,null, null, new object[] { bindTrans.gameObject, eCAMERAFOLLOW.DIRECT,true,true });
            }
        }
    }



}
