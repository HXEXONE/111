using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CDeadState : CBaseState
{
    private Timer m_pColorTimer;
    private Timer m_pDeadTimer;

    private eNpcGroup m_NpcGroup;
    private CBaseNpc m_pAttacker;

    public CDeadState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Dead, false, false, true,true)
    {
        m_pColorTimer = new Timer();
        m_pDeadTimer = new Timer();
    }

    public CBaseNpc Attacker
    {
        set { m_pAttacker = value; }
    }

    bool exploder = false;
    public override void EnterState()
    {
        base.EnterState();
     
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_NpcGroup = m_pNpc.NpcGroup;

        exploder = false;

        Transform npcTrans = m_pNpc.GetTransform();
        if (npcTrans != null)
        {
            if (!m_pNpc.SelfDestruction)
            {
                if (m_pNpc.NpcSort == eNpcSort.Monster)
                {
                    //����ʱ�Ѳ���������,��������Ч������
                    //Monster pMonster =  m_pNpc as Monster;
                    if (!m_pNpc.ApplyRagdoll)
                    {
                        //��ʬ�ж�
                        if (ClientMain.GetInst().EnterTestScene)
                            CExploderManage.GetInst().Exploder(m_pNpc.NpcType, npcTrans, ref exploder);
                        else
                            CExploderManage.GetInst().ExploderForPath(m_pNpc.GetObject().Path, m_pNpc.NpcType, ((Monster)m_pNpc).SpecifyMaterial, npcTrans, ref exploder);
                        // ����ʬ
                        if (!exploder)
                        {
                            PlayDeadAction();
                        }
                        else
                        {
                            GameObject audio = m_pNpc.AudioSourceObject;
                            if (audio)
                                audio.transform.parent = null;

                            //Transform npcTrans = m_pNpc.GetTransform();
                            //AudioSource audioSource = npcTrans.GetComponent<AudioSource>();
                            //if (null != audioSource)
                            //{
                            //    //audioSource.Stop();
                            //}
                        }
                    }
                }
                else
                {
                    PlayDeadAction();
                }
            }


            //if (CBaseStory.IsInGameStory)
            //{
            //    m_pColorTimer.SetTimer(0);
            //    m_pDeadTimer.SetTimer(0);
            //    return;
            //}
            //else
            //{
            SkinnedMeshRenderer[] renders = npcTrans.GetComponentsInChildren<SkinnedMeshRenderer>();
            if (null != renders && !exploder && renders.Length > 0)
            {
                m_pColorTimer.SetTimer(2f);
                m_pDeadTimer.SetTimer(4);
            }
            else
            {
                m_pDeadTimer.SetTimer(2f);
            }
        }
        else
        {
            m_pNpc.RemoveNpc();
        }
        

        m_pAttacker = null;
        //}

    }

    private void PlayDeadAction()
    {
        if (m_pNpc.GetTransform() == null)
        {
            return;
        }
        uint deadID = (uint)m_pNpc.GetDeadActID();

        //С���
        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer player = m_pNpc as BaseBattlePlayer;

            if (player.PartnerState == ePartnerState.Partner)
            {
                if (null == player.PartenrLoader) return;

                deadID = (uint)player.PartenrLoader.ModelLoader.DeadActionID;
            }
        }

        //������������
        ActionContent pActionInfo = HolderManager.m_ActionHolder.GetStaticInfo(deadID);
        if (null != pActionInfo)
        {
            if (pActionInfo.BehitType == (byte)eActionType.Ragdoll)
            {                                
                //m_pNpc.ApplyRagdoll = true;
                m_pNpc.HideWeapon();

                float force = UnityEngine.Random.Range(1f, 1.5f);
                
                Vector3 npcDir;
                if(null == m_pAttacker || m_pAttacker.GetTransform() == null)
                {
                    npcDir = -m_pNpc.GetTransform().forward;
                }
                else
                {
                    npcDir = m_pAttacker.GetTransform().forward;
                }
                Vector3 dir = npcDir + Vector3.up;
                m_pNpc.AddRagdollForce("BP_Spine", dir * force);                                
            }
            else
            {
                m_pNpc.PlayAction(pActionInfo.ActionName);

                m_pNpc.ApplyCharacterCtrl = false;
            }

            List<int> sounds = Common.GetSounds(pActionInfo);
            foreach (var soundID in sounds)
            {
                m_pNpc.CreateSound((uint)soundID);
            }

            List<int> effectList = Common.GetPlayEffects(pActionInfo);
            //��Ч
            if (effectList.Count > 0)
            {
                for (int i = 0; i < effectList.Count; ++i)
                {
                    m_pNpc.CreateParticle((uint)effectList[i]);
                }
            }
        }
 
    }


    public override void Update()
    {
        base.Update();

        //MyLog.Log(" TimeScale : " + Time.timeScale);

        //���������һ�������ʬ��
        //bool isGameOver = SingletonObject<BattleScene>.GetInst().IsGameOver();
        //if (isGameOver && m_NpcGroup == eNpcGroup.Evil)
        //    return;

        if (m_pColorTimer.IsExpired(false))
        {
            //m_pNpc.ApplyCharacterCtrl = false;

            //if (m_pNpc.NpcSort == eNpcSort.Monster)
            if (m_pNpc is Monster && !exploder)
            {
                if (!CBaseStory.IsInGameStory)
                    m_pNpc.SetAlphaVertexColorOff(1.5f);
            }
            m_pNpc.ApplyCharacterCtrl = false;
            m_pColorTimer.Release();
        }

        if (m_pDeadTimer.IsExpired(false))
        {
            m_pDeadTimer.Release();
            if (m_pNpc is Monster || m_pNpc is AIFriend )
            {
                //MyLog.Log(" RemoveNpc : " + m_pNpc.Index + " time : " + Time.time);
                m_pNpc.RemoveNpc();
                if (m_pNpc.ApplyRagdoll)
                    m_pNpc.HideWeapon(false);
            }
        }

        m_pNpc.Move(0);
    }

}
