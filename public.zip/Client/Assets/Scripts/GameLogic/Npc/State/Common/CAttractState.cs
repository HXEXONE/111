﻿using UnityEngine;
using System.Collections;

//吸引、吸收 状态
public class CAttractState : CBaseState
{
    public CAttractState(CBaseNpc pNpc)
        : base(pNpc, eActionState.Attract, false, false, false, true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.SoundBreak();
    }

    public override void LeaveState()
    {
        base.LeaveState();

        m_pNpc.AddBuff(9029);
    }

    public void SetAttracInfo(Vector3 desposition,float time)
    {
        float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), desposition);

        SetHorizontalInfo(distance, distance / time);

        SetTimer(time);

        m_pNpc.SetDestPosition(desposition, false);
    }

    public override void Update()
    {
        base.Update();

        if (m_fHorizontalDis != 0)
        {
            if (!m_pHorzontalTimer.IsExpired(false))
            {
                m_pNpc.Move(m_fHorizontalSpeed, true);
            }
        }
    }
}
