﻿using UnityEngine;
using System.Collections;

//挤压平滑移动
public class CSmoothMoveState : CBaseState 
{
    private const float SmoothSpeed = 20f;
    private int m_count = 0;
    private float m_fDistance;
    //private Timer m_pTimer = new Timer();    
    

    public CSmoothMoveState(CBaseNpc pNpc) :
        base(pNpc, eActionState.SmoothMove,false,false,false,false)
    {

    }

    public override void EnterState()
    {
        base.EnterState();
        m_count = 0;

        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;

        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        m_pNpc.EnablePathFinding(false);

    }

    public void SetSmoothInfo(Vector3 dstPosition,float extraTime = 0f) 
    {
        float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), dstPosition);
        //m_pTimer.SetTimer(distance / SmoothSpeed);

        m_pNpc.SetDestPosition(dstPosition, false);

        SetTimer(distance / SmoothSpeed + extraTime);
    }


    public override void LeaveState()
    {
        base.LeaveState();

        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.MONSTER_LAYER, false);

       eBattleType battleType = m_pNpc.CurrBattleScene.BattleType;
       if (battleType == eBattleType.Arena ||
           battleType == eBattleType.Wasteland ||
           battleType == eBattleType.Mining ||
           battleType == eBattleType.Pvp ||
           battleType == eBattleType.MultiPve)
        {
            Physics.IgnoreLayerCollision(DEFINE.AVATAR_LAYER, DEFINE.AVATAR_LAYER, false);
        }

    }

    //public override void Update()
    //{
    //    m_pNpc.Move(SmoothSpeed, true, true);
      
    //    if (m_pTimer.IsExpired(false))
    //    {
    //        m_count++;
    //        CBaseNpc pTarget = m_pNpc.IsSnuglyNpc(-20f);
    //        Vector3 dstPosition;
    //        if (null != pTarget)
    //        {
    //            if (m_count < 2)
    //            {
    //                //还有跟人贴身
    //                dstPosition = m_pNpc.GetTransform().forward * (pTarget.CharacterRadius + m_pNpc.CharacterRadius * 3f ) + pTarget.GetPosition();
    //                SetSmoothInfo(dstPosition);
    //            }
    //            else
    //            {
    //                dstPosition = m_pNpc.BattleScene.SummonPosition(pTarget.GetPosition(), pTarget.CharacterRadius,false, m_pNpc, m_pNpc.NpcCollider);
    //                //SetSmoothInfo(dstPosition);
    //                m_pNpc.SetPosition(dstPosition, false);
    //                m_pNpc.LeaveState(eActionState.SmoothMove);

    //                return;
    //            }
    //        }
    //    }

    //    base.Update();
    //}
}
