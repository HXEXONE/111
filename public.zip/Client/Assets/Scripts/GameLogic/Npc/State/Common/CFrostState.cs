﻿using UnityEngine;
using System.Collections;

public class CFrostState : CBaseState
{
    public CFrostState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Frost, false, false, true, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.AddMaterials(false, 1);
        m_pNpc.ApplyAnimator = false;
    }


    public override void BreakState()
    {
        base.BreakState();

        m_pNpc.AddMaterials(true);
        m_pNpc.ApplyAnimator = true;

    }

    public override void LeaveState()
    {
        base.LeaveState();

        m_pNpc.AddMaterials(true);
        m_pNpc.ApplyAnimator = true;        
    }

}
