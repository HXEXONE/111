using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CNormalState : CBaseState
{
    private float m_fStartTime;
    public CNormalState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Idle, false, false, true, true)
    {
        
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed,false,0.2f);

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;

        m_pNpc.ApplyRootMotion = false;

        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;
        m_pNpc.EnablePathFinding(false);


        m_pNpc.UpdateDestPosition();

    }

    public override void Update()
    {
        base.Update();

        //lookat target
        m_pNpc.Move(0);


        if (m_pNpc.IsChest())
        {
            return;
        }

        if (m_pNpc.NotInAction() )
        {

            if (Time.time - m_pNpc.NormalAtkTime > 1.5f)
            {
                SkillContent skillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.DefaultSkillID);
                if ( null != skillLoader)
                {
                    m_pNpc.DefaultSkillID = (uint)skillLoader.FirstSkillID;
                }                
            }

            if (m_pNpc is Monster)
            {
                if(m_pJudgeTimer.IsExpired(true) )
                {
                    eNpcBehaviour eBehaviour = m_pNpc.CheckNpcBehaviour();
                    if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve)
                    {
                        if (eBehaviour == eNpcBehaviour.WaitMessage)                        
                         {
                             m_pNpc.EnterState(eActionState.Wait);
                         }                         
                                                
                    }                    
                }
               
            }
            else if (m_pNpc is BaseBattlePlayer )
            {
                //0.5sʱ�䴦������������idle�ںϵ����,�Ա����¸��������Ų�����
                m_pNpc.CheckNpcBehaviour();
            }
        }

        ////�����NPC��ǰ��Ŀ����ת���Ŀ��
        //if (m_pNpc.CurrTarget != null)
        //{
        //    Vector3 lookDirection = m_pNpc.CurrTarget.GetPosition() - m_pNpc.GetPosition();
        //    lookDirection.y = 0;
        //    m_pNpc.UpdateTurn(lookDirection, true);
        //}
        
    }
}
