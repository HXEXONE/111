using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ChaseInfo
{
    public ChaseInfo(float time) 
    { 
        chaseTimer = new Timer();
        chaseTimer.SetTimer(time);
    }

    public Vector3 position;
    public Timer chaseTimer;
}

public class CRunState : CBaseState
{
    private ChaseInfo m_pChaseInfo = null;

    private float m_fStartTime;
    private float m_fTurnTime;
    private bool m_bChase;

    private uint m_rideYangchenIndex;

    private float m_fTurningAngel;

    private Timer m_pRunTimer = null;

    public CRunState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Run, false, false, false, true)
    {
        m_rideYangchenIndex = 0;
      
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;

        bool applyRootMotion = false;
        if (m_pNpc.NpcSort == eNpcSort.Pet)
        {
            applyRootMotion = true;
        }
        //else
        //{
        //    if (m_pNpc is BaseBattlePlayer)
        //    {
        //        BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
        //        if (bbp.IsInFly())
        //        {
        //            applyRootMotion = false;
                    
        //        }
        //    }
            
        //}
        if (m_pNpc is Monster)
        {
            m_pChaseInfo = new ChaseInfo(2f);
            m_pChaseInfo.position = m_pNpc.GetPosition();

            if ( (m_pNpc as Monster).MoveBehaviour)
            {
                m_pRunTimer = new Timer();
                m_pRunTimer.SetTimer(5f);
            }
            else
            {
                m_pRunTimer = null;
            }
        }
        m_pNpc.ApplyRootMotion = applyRootMotion;

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;

            m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 2 ; //�ݶ�
            //���ת����ʱ��
            m_fTurnTime = m_pNpc.TurningTime;

            if (bbp.IsInRide())
            {
                //���������ﳾ��Ч
                if (0 == m_rideYangchenIndex)
                {
                    m_rideYangchenIndex = m_pNpc.CreateParticle(DEFINE.AVATAR_RIDE_YANGCHEN);
                }
               
            }
        }
        else
        {
            m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;
        }

        m_fStartTime = Time.time;
        m_bChase = false;
        m_fTurningAngel = 0f;
    }

    public override void BreakState()
    {
        base.BreakState();
        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            if (bbp.IsInRide())
            {
                RemoveYangchenEffect();
            }
        }
    }


    //׷��
    public bool Chase
    { 
        set 
        {
            m_bChase = value;

            if (m_bChase)
                m_pNpc.CreateParticle(DEFINE.CHASE_PARTICLEID);
        } 
    }


    private void RemoveYangchenEffect()
    {
        if (m_rideYangchenIndex != 0)
        {
            CParticleManager.GetInst().AddDestroyParticle(m_rideYangchenIndex);
            m_rideYangchenIndex = 0;
        }
    }

    public override void LeaveState()
    {
        base.LeaveState();

        if (CBaseStory.IsInGameStory)
        {
            foreach (KeyValuePair<SceneStoryContent, CBaseStory> val in CBaseStory.m_currentState)
            {
                val.Value.DoSomeThing();
            }
        }

        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            if (bbp.IsInRide())
            {
                bbp.WalkForward(10);

                RemoveYangchenEffect();
            }
        }

    }

    public override void Update()
    {
        base.Update();

        //float fAngel = 0f;

        if (m_pNpc.NotInAction())
        {                       
            //m_pNpc.Move(m_pNpc.MoveSpeed,true);

            if (Time.time - m_pNpc.NormalAtkTime > 1.5f)
            {
                SkillContent skillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_pNpc.DefaultSkillID);
                if ( null != skillLoader)
                {
                    m_pNpc.DefaultSkillID = (uint)skillLoader.FirstSkillID;
                }                
            }

            if (m_pNpc is Monster)
            {
                if (m_pJudgeTimer.IsExpired(true))
                {
                    eNpcBehaviour eBehaviour =  m_pNpc.CheckNpcBehaviour();          
      
                    if (m_pNpc.CurrBattleScene.BattleType == eBattleType.MultiPve)
                    {
                        if (eBehaviour == eNpcBehaviour.WaitMessage)
                        {
                            m_pNpc.EnterState(eActionState.Wait);
                            return;
                        }
                    }
                    if (eBehaviour == eNpcBehaviour.Attack)
                    {
                        return;
                    }
                }
                if ( null != m_pRunTimer)
                {
                    if (m_pRunTimer.IsExpired(false))
                    {
                        m_pNpc.EnterState(eActionState.Walk);
                        return;
                    }
                }

                if ( null != m_pChaseInfo )
                {
                   if (m_pChaseInfo.chaseTimer.IsExpired(true))
                   {
                       float distance = Common.GetHorizontalDis(m_pNpc.GetPosition(), m_pChaseInfo.position);
                       if (distance < 1f) //С��2 ԭ��̤��
                       {
                           m_pChaseInfo.position = m_pNpc.GetPosition();
                           int range = UnityEngine.Random.Range(0, 100);
                           int value = range > 50 ? 1 : -1;
                           m_fTurningAngel = 60 * value;
                       }
                       else
                       {
                           m_pChaseInfo.position = m_pNpc.GetPosition();
                           m_fTurningAngel = 0f;
                       }
                   }
                }

                //�޸���ʱ��������ǻ���׷�������2��ת������
                bool targetAlly = m_pNpc.NpcSort == eNpcSort.Ally && m_pNpc.TargetIsAlly; //�Ѿ�Ŀ��λ������,������turning
                if (m_pNpc.CurrTarget != null && !m_pNpc.CurrTarget.IsDead() && !targetAlly)
                {
                    Vector3 targetPosition = m_pNpc.CurrTarget.GetPosition();
                    if (Common.Get2DVecter3Length(m_pNpc.GetPosition(), targetPosition) <= m_pNpc.MinAttackRange )
                    {
                        m_pNpc.Command(eCommandType.Turning, new TurningCommandArg(targetPosition));
                        return;
                    }

                }
            }
            else if (m_pNpc is BaseBattlePlayer)
            {
                //���ﲻ���й�������ж�����Ϊ����ɹ����ж������������
                //ת�������в����м��ܼ��
                if (Time.time - m_fStartTime >= m_fTurnTime)
                {
                    eNpcBehaviour eBehaviour  = m_pNpc.CheckNpcBehaviour();
                    if (eBehaviour == eNpcBehaviour.WaitMoveMessage)
                    {
                        //�뿪run״̬,����idle�ȴ�
                        m_pNpc.LeaveState(m_state);
                        return;
                    }
                }
            }
        }

        float moveSpeed = m_bChase ? 40 : m_pNpc.MoveSpeed;
        m_pNpc.Move(moveSpeed, true, true, m_fTurningAngel);
    }
}
