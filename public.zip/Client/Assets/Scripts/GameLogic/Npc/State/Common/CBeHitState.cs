using UnityEngine;
using System.Collections;

public class CBeHitState : CBaseState
{
    public CBeHitState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Behit, true, false, false, true)
    {
    }

    public override void EnterState()
    {        
        base.EnterState();

        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.SoundBreak();
    }   

    public override float GetActionTime()
    {
        float fActionTime = base.GetActionTime();

        if (fActionTime != -1)
        {
            fActionTime = fActionTime > m_fAnkylosisTime ? fActionTime : m_fAnkylosisTime;
        }

        return fActionTime;
    }

    public override void Update()
    {
        base.Update();

        if (m_fHorizontalSpeed != 0)
        {
            if (m_pHorDelayTimer.IsExpired(false))
            {
                if (!m_pHorzontalTimer.IsExpired(false))
                {
                    m_pNpc.Move(m_fHorizontalSpeed, true,false);
                }
                else
                {
                    //����Ӱ��
                    if (!m_pNpc.IsInGround)
                    {
                        m_pNpc.Move(0f, true);
                    }                    
                }
            }

        }
        
        if (m_pNpc.NpcSort == eNpcSort.EnermyAvatar )
        {
            eNpcBehaviour eBehaviour = m_pNpc.CheckNpcBehaviour();
            if (eBehaviour != eNpcBehaviour.None)
            {
                m_pNpc.LeaveState(m_state);
            }
        }
    }

}
