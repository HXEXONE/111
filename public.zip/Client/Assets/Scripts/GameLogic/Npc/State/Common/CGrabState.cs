﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;



public class CGrabState : CBaseState
{
    private SkillContent m_pSkillLoader;
    private eGrabState m_grabState;
    private Timer m_flyTimer;

    private Transform m_bindTrans;  //需要绑定的点

    private const float FLY_SPEED = 4f;

    public CGrabState(CBaseNpc pNpc):
        base(pNpc, eActionState.Grab, false, false, false, true)
    {
        m_bindTrans = null;
        m_flyTimer = new Timer();

        m_grabState = eGrabState.None;

    }

    public void SetSkillLoader(SkillContent pSkillLoader)
    {
        m_pSkillLoader = pSkillLoader;

        float time = pSkillLoader.LastTime;
        SetTimer(time);

        m_pNpc.SetActionTimer(time);

    }

    private void UntieGrabNpc() 
    {
        //return;
        CBaseNpc grabNpc = m_pNpc.GrabNpc;
        if (null != grabNpc)
        {
            MyLog.LogError("Error !  Enter GrabState this npc : " + m_pNpc.Index + " exist grabNpc : " + grabNpc.Index + " already !");

            grabNpc.GetTransform().parent = null;

            if (grabNpc is Monster)
            {
                if (!grabNpc.IsDead())
                {
                    grabNpc.NpcDead(true);
                    return;
                }                
            }

            m_pNpc.GrabNpc = null;

            grabNpc.IsBeGrab = false;
            grabNpc.SetFootEffect(true);

            grabNpc.GetTransform().rotation = Quaternion.identity;
            grabNpc.SetPosition( Common.NavSamplePosition(grabNpc.GetPosition())  + Vector3.up * 0.5f );
            grabNpc.LeaveState(eActionState.Stun);

        }
    }

    public override void EnterState()
    {
        base.EnterState();

        //m_pNpc.AddBuff(DEFINE.Invincible_BuffID);//无敌永久

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = true;
        m_pNpc.EnablePathFinding(false);

        if (null != m_pNpc.GrabNpc)
        {
            UntieGrabNpc();
            return;
        }

        Transform bindTrans = Common.GetBone(m_pNpc.GetTransform(), "BP_Grab");
        if ( null == bindTrans )
        {
            MyLog.LogError(" Error ! Npc : " + m_pNpc.Index + " has not exsit BP_Grab transfrom !");
            return; 
        }
       
        m_bindTrans = bindTrans;

        m_grabState = eGrabState.Check;


    }

    public override void LeaveState()
    {
        base.LeaveState();

       // m_pNpc.DelBuff(DEFINE.Invincible_BuffID);

        if (m_grabState != eGrabState.Finish) return;

        if ( null == m_pNpc.GrabNpc)
        {
            MyLog.LogError(" LeaveState  GrabState . grabNpc is null !");
            return;
        }

        if ((m_pNpc is Avatar && (m_pNpc as Avatar).JobType == eJobType.Wizard))
        {
            Animation ani = m_bindTrans.GetComponent<Animation>();
            if (null != ani)
            {
                ani.Play();
            }
        }     
        //抓取后表现
        uint nextID = SkillManager.GetInst().GetRandomNextSkill(m_pSkillLoader);
        if (nextID != 0)
        {
            //设置下一个技能
            SkillContent nextInfo = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
            if (null != nextInfo)
            {
                m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)nextInfo.Key, null));
            }
        }
        
    }

    public override void BreakState()
    {
        //这种情况一般不会出现
        MyLog.LogError(" BreakState  GrabState !!");

        base.BreakState();

        m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        UntieGrabNpc();
    }

    private void BindNpc(CBaseNpc pTarget)
    {
        if (m_grabState != eGrabState.Bind) return;

        if (null == pTarget) return;

        Transform targetTrans = pTarget.GetTransform();
        Common.IgnoreCollision(m_pNpc.NpcCollider, pTarget.NpcCollider);
        //Physics.IgnoreLayerCollision(m_pNpc.GetObject().Layer, pTarget.GetObject().Layer, true);

        if ((m_pNpc is Avatar && (m_pNpc as Avatar).JobType == eJobType.Wizard))
        {
        }
        else
        {
            targetTrans.forward = -m_pNpc.GetTransform().forward;

            targetTrans.position = m_bindTrans.position;
            ////找到胸部绑点
			Transform spineTrans = Common.GetBone(targetTrans, DEFINE.BONE_Spine);
            //将胸部绑点对应到抓取点上
            targetTrans.position -= (spineTrans.position - targetTrans.position);
        }

        //设置父节点
        targetTrans.parent = m_bindTrans;

        m_grabState = eGrabState.Finish;
    }


    public void UpdateBindPos() 
    {
        if ( null != m_pNpc.GrabNpc )
        {
            if (m_pNpc is Monster || (m_pNpc is Avatar && (m_pNpc as Avatar).JobType != eJobType.Wizard))
            {
                Transform targetTrans = m_pNpc.GrabNpc.GetTransform();
                targetTrans.forward = -m_pNpc.GetTransform().forward;

                targetTrans.position = m_bindTrans.position;
                ////找到胸部绑点
				Transform spineTrans = Common.GetBone(targetTrans, DEFINE.BONE_Spine);
                //将胸部绑点对应到抓取点上
                targetTrans.position -= (spineTrans.position - targetTrans.position);
            }            
        }       
    }

    //吸收飞行
    private void AbsorbFly() 
    {
        CBaseNpc pTarget = m_pNpc.GrabNpc;

        if (!m_flyTimer.IsExpired(false))
        {
            //水平移动
            pTarget.Move(FLY_SPEED, true, true);
        }
        else
        {
            //结冰特效
            List<string> extraArgs = m_pSkillLoader.ExtraArgs;
            if (extraArgs.Count > 0)
            {
                uint particleId = MyConvert_Convert.ToUInt32(extraArgs[0]);
                pTarget.CreateParticle(particleId);

                //pTarget.ChangeMaterials(false, 1);
            }            

            m_grabState = eGrabState.Bind;
            BindNpc(pTarget);
        }
    }

    private void CheckBind() 
    {
        //抓取判定
        if (null != m_pNpc.GrabNpc)
        {
            UntieGrabNpc();
            return;
        }

        eAffectType affectType = (eAffectType)m_pSkillLoader.AffectType;
        CBaseNpc pTarget = null;

        float minDistance = 100f;
        List<CBaseNpc> rangeNpcList = m_pNpc.GetRangeNpcList();
        foreach (CBaseNpc pNpc in rangeNpcList)
        {
            //抓取npc额外判断...
            if (!pNpc.CanBeGrab)
                continue;

            if (CBaseNpc.AffectResult((eAffectType)m_pSkillLoader.AffectType, (eAffectEffect)m_pSkillLoader.AffectEffect, m_pNpc, pNpc, eEffectRangeType.HurtType, (eSkillAtkType)m_pSkillLoader.SkillAtkType,m_pSkillLoader.LockList))
            {
                if (m_pNpc.IsInSkillRange(m_pSkillLoader, pNpc, eEffectRangeType.HurtType))
                {
                    //寻找最近单位
                    float distance = Common.Get2DVecter3Length(m_pNpc.GetPosition(), pNpc.GetPosition());
                    if (distance < minDistance)
                    {
                        pTarget = pNpc;
                        minDistance = distance;
                    }
                }
            }
        }

        if (null == pTarget) return;

        //抓到人.上无敌buff
        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        pTarget.SetFootEffect(false);

        pTarget.SoundBreak();
  
        //pTarget.AddBuff(DEFINE.FOREVER_STUN_BUFF_ID);
        CStunState pStunState = pTarget.GetState(eActionState.Stun) as CStunState;
        pTarget.EnterState(eActionState.Stun);
        pStunState.SetTimer(-1f);

        pTarget.IsBeGrab = true;
        //pTarget.ApplyAnimator = false;

        m_pNpc.GrabNpc = pTarget;

        if (m_pNpc is Avatar && (m_pNpc as Avatar).JobType == eJobType.Wizard)
        {
            Vector3 destPosition = m_pNpc.GetPosition() + m_pNpc.GetTransform().forward * 4f;

            float distance = Common.GetHorizontalDis(pTarget.GetPosition(), destPosition);

            float flyTime = distance / FLY_SPEED;

            pTarget.SetDestPosition(destPosition, false);

            m_flyTimer.SetTimer(flyTime);
            AddTime(flyTime);
            m_pNpc.AddActionTime(flyTime);

            m_grabState = eGrabState.Absorb;
        }
        else
        {
            m_grabState = eGrabState.Bind;
            BindNpc(pTarget);
        }
    }

    public override void Update()
    {
        if (m_grabState == eGrabState.Check)
        {
            CheckBind();
        }
        if (m_grabState == eGrabState.Absorb) 
        {
            AbsorbFly();
        }

        if (m_grabState == eGrabState.Finish)
        {
            UpdateBindPos();
        }

        base.Update(); //会leaveState..
    }

}
