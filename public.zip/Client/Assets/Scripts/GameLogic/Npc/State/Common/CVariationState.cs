using UnityEngine;
using System.Collections;

public class CVariationState : CBaseState
{
    public CVariationState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Variation,false,false,true,true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_state, m_fActionSpeed,true);
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;
        m_pNpc.EnablePathFinding(false);

    }
}
