using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//���
public class CAssaultState : CBaseState
{
    public CAssaultState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Assault, false, false, false,true)
    {
      
    }


    public override void EnterState()
    {
        base.EnterState();
     
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        PlayerConfigContent configLoader = HolderManager.m_PlayerConfigHolder.GetStaticInfo(m_pNpc.NpcType);
        if (null == configLoader) return;
        
        m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)configLoader.AssaultID, new List<CBaseNpc>()));
    }

}
