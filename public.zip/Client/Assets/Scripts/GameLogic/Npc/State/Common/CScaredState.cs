﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CScaredState : CBaseState
{
    public CScaredState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Scared, true, false, false, true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.PlayAction(m_szActionName, m_fActionSpeed, true);

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);
    }
}
