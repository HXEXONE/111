using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CWalkState : CBaseState
{
    private float m_fStartTime;
    private const float Fade_time = 0.5f; //walk�����ںϵ�ʱ��

    private Timer m_pWalkTimer= null; 

    public CWalkState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Walk,false,false,false,true)
    {

    }

    public override void EnterState()
    {
        base.EnterState();
        //m_pNpc.PlayAction(m_state, m_pNpc.MoveSpeed,false);                
        m_pNpc.PlayAction(m_state, m_fActionSpeed, false);       

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = true;
        m_pNpc.CanTurn = true;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED;
        m_pNpc.EnablePathFinding(true);

        m_fStartTime = Time.time;

        if ( m_pNpc is Monster )
        {
            m_pWalkTimer = new Timer();
            m_pWalkTimer.SetTimer(3f);
        }

        SetActionSpeed(m_pNpc.WalkSpeed / m_pNpc.GetAniMoveSpeed()[1]);
    }

    public override void Update()
    {
        base.Update();

        if (m_pNpc.NotInAction() )
        {
            //float moveSpeed = m_pNpc.MoveSpeed / 1.5f;

            //�ں�ʱ���ڲ����
            if (m_pNpc is BaseBattlePlayer && Time.time - m_fStartTime > Fade_time)
            {
                eNpcBehaviour eBehaviour = m_pNpc.CheckNpcBehaviour();

                //switch (eBehaviour)
                //{
                //    case eNpcBehaviour.None:
                //        {
                //            if (!pPlayer.TrusteeshipBattle())
                //            {
                //                pPlayer.LeaveState(m_state);
                //            }
                //        }
                //        break;
                //}

//                 if (pPlayer.IsInRide())
//                 {
//                     moveSpeed = m_pNpc.MoveSpeed / 1.5f;
//                 }
            }
            else if ( m_pNpc is Monster )
            {
                if (m_pWalkTimer.IsExpired(false))
                {
                    m_pNpc.EnterState(eActionState.Run);
                    return;
                }
                else
                {
                    m_pNpc.CheckNpcBehaviour();
                }
            }

           //m_pNpc.Move(m_pNpc.MoveSpeed);
           m_pNpc.Move(m_pNpc.WalkSpeed,true,true);
         
        }

    }
}
