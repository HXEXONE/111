﻿using UnityEngine;
using System.Collections;

public class CGrabHitState : CBaseState
{
    private const float Invincibility_Time = 0.2f;//抓取受击无敌时间(浮空时间)
    private Timer m_pInvincibilityTimer ;
    private CBaseNpc m_pAttacker = null;

    public CGrabHitState(CBaseNpc pNpc) :
        base(pNpc, eActionState.GrabHit, true, false, false, true)
    {
        m_pInvincibilityTimer = new Timer();
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;

        m_pNpc.EnablePathFinding(false);

        //加上无敌buff
        m_pInvincibilityTimer.SetTimer(Invincibility_Time);
        m_pNpc.AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);

        m_pNpc.SoundBreak();
    }

    public override void LeaveState()
    {
        base.LeaveState();

        //Physics.IgnoreLayerCollision(m_pNpc.GetObject().Layer, m_pAttacker.GetObject().Layer,false);

        Common.IgnoreCollision(m_pNpc.NpcCollider, m_pAttacker.NpcCollider,false);
        m_pNpc.IgnoreNpcCollsion(false);
    }

    public override void BreakState()
    {
        base.BreakState();

        //Physics.IgnoreLayerCollision(m_pNpc.GetObject().Layer, m_pAttacker.GetObject().Layer, false);

        Common.IgnoreCollision(m_pNpc.NpcCollider, m_pAttacker.NpcCollider,false);
        m_pNpc.IgnoreNpcCollsion(false);
    }

    public override float GetActionTime()
    {
        float fActiontime = base.GetActionTime();

        if (fActiontime != -1)
        {
            fActiontime = fActiontime > m_fAnkylosisTime ? fActiontime : m_fAnkylosisTime;
        }
        return fActiontime;
    }

    public void SetGrabHitInfo(CBaseNpc attacker) 
    {
        m_pAttacker = attacker;
        Transform attackTrans = attacker.GetTransform();
        Transform npcTrans = m_pNpc.GetTransform();
        npcTrans.up = attackTrans.up;
        npcTrans.forward = -attackTrans.forward;

        npcTrans.position = attackTrans.position + attackTrans.forward * 0.5f;        //若不一致,需要计算y轴点

        m_pNpc.ApplyCharacterCtrl = true;
        m_pNpc.IgnoreNpcCollsion(true);
        m_pNpc.HideWeapon(false);
        m_pNpc.SetFootEffect(true);

        m_pNpc.IsBeGrab = false;
    }

    public override void Update()
    {
        base.Update();

        if (m_pInvincibilityTimer.IsExpired(false))
        {
            m_pNpc.DelBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);
        }

        if (m_fHorizontalSpeed != 0)
        {
            if (m_pHorDelayTimer.IsExpired(false))
            {
                if (!m_pHorzontalTimer.IsExpired(false))
                {
                    m_pNpc.Move(m_fHorizontalSpeed, true);
                }
            }
        }
    }
}
