using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public delegate void SkillStateHandle(uint skillLoaderKey);

public class CSkillState : CBaseState
{
    private SkillContent m_pSkillInfo;
    private Timer m_damageTimer = new Timer();

    private bool m_bCanBreak;            //���ܿɱ��ж�(������ж�)
    private bool m_bTurnStart;          //��ʼת��
    private Vector3 m_clickDirection;       //�������

    private bool m_AutoSelectDirection;//�Զ�ѡ����
    private uint m_uiDirParticleIndex = 0;

    private object[] m_IntervalArgs = new object[5]; //���ܼ������

    private SkillStateHandle m_SkillStateCallback = null; //����״̬�ص�

    public CSkillState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Skill, false, false, false, true)
    {
        m_bCanBreak = false;
    }

    public void SetSkillInfo(SkillContent pSkillInfo,SkillStateHandle callback = null)
    {
        m_pSkillInfo = pSkillInfo;

        float time =  pSkillInfo.LastTime;
        SetTimer(time);

        m_pNpc.SetActionTimer(time);
        m_SkillStateCallback = callback;
    }
    
    

    public void SetIntervalArgs(object[] args) 
    {
        m_IntervalArgs = args;
    }

    public SkillContent GetSkillInfo()
    {
        return m_pSkillInfo;
    }

    public override void SetTimer(float fTime)
    {
        fTime = m_pSkillInfo.LastTime;
        base.SetTimer(fTime);
    }

    public override void EnterState()
    {
        base.EnterState();        

        float interval = m_pSkillInfo.Interval;
        if (m_pSkillInfo != null && interval != 0)
        {
            m_damageTimer.SetTimer(m_pSkillInfo.Interval);
        }

        //�����֮ǰ�Ķ�����Чlist���
        if (!SkillManager.GetInst().IsContinuous(m_pSkillInfo))
        {
            //�����м���
            m_particleList.Clear();
        }
        else
        {
            //�Ƿ�Ϊ���м���
            if (SkillManager.GetInst().IsFirstSkill(m_pSkillInfo))
            {
                m_particleList.Clear();
            }
        }

        m_bCanBreak = false;
        m_bTurnStart = false;
        m_AutoSelectDirection = true;

        eSkillMouseAction action = (eSkillMouseAction)m_pSkillInfo.MouseAction;
       
        m_pNpc.CanMove = action == eSkillMouseAction.MoveAndTurn || action == eSkillMouseAction.CanMove;
        m_pNpc.CanTurn = action == eSkillMouseAction.MoveAndTurn || action == eSkillMouseAction.CanTurn;

        //���м���
        if (SkillManager.GetInst().IsFirstSkill(m_pSkillInfo))
        {
            //���ܺ���            
            m_pNpc.PlaySkillSound();
            //avatar���п�ת���ܶ���ѡ������Ч
            if (m_pNpc is RealAvatar && m_pNpc.CanTurn )
            {
                m_uiDirParticleIndex = m_pNpc.CreateParticle(DEFINE.CHOOSE_DIRECTION_PARTICLEID);
            }
       }
       else
       {
           if (m_pNpc is RealAvatar)
           {
               if (m_uiDirParticleIndex != 0 )
               {
                   CParticleManager.GetInst().AddDestroyParticle(m_uiDirParticleIndex);
                   m_uiDirParticleIndex = 0;
               }               
           }
       }
    
        m_pNpc.ApplyRootMotion = true;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.TurnSpeed = DEFINE.DEFAULT_TURN_SPEED * 2f;
        m_pNpc.UpdateDestPosition();

        bool  ignore = m_pSkillInfo.IgnoreCollider;
        if (ignore)
            m_pNpc.IgnoreNpcCollsion(true);
        
    }

    public bool SkillCanBreak //���ܿ����ж�
    {
        get
        {
            return m_bCanBreak;
        }
        set
        {
            m_bCanBreak = value;
        }
    }

    public void MouseClick(Vector3 point)
    {
        if (m_pNpc.CanMove)
        {
            m_pNpc.SetDestPosition(point, false);
            m_pNpc.CurrTarget = null;
        }
        if (m_pNpc.CanTurn)
        {
            m_bTurnStart = true;
            m_clickDirection = point - m_pNpc.GetPosition();
        }
    }

    public override void LeaveState()
    {
        base.LeaveState();
        Reuse();

        m_pNpc.UpdateDestPosition();

        uint nextID = SkillManager.GetInst().GetRandomNextSkill(m_pSkillInfo);
        if (nextID == 0) //û�������� �ٰѺ�����ײ�رյ�
        {
            bool ignore = m_pSkillInfo.IgnoreCollider;
            if (ignore)
                m_pNpc.IgnoreNpcCollsion(false);
        }

        if (null != m_SkillStateCallback)
        {
            m_SkillStateCallback((uint)m_pSkillInfo.Key);
            m_SkillStateCallback = null;
        }
        
    }

    public override void BreakState()
    {
        base.BreakState();
        Reuse();    

        m_pNpc.UpdateDestPosition();
        bool ignore = m_pSkillInfo.IgnoreCollider;
        if (ignore)            
            m_pNpc.IgnoreNpcCollsion(false,false);
    }

    private void Reuse() 
    {     
        m_bCanBreak = false;
        m_bTurnStart = false;
        if (null != m_damageTimer)
        {
            m_damageTimer.Release();
        }        
    }


    public override void Update()
    {
        if (m_damageTimer.IsExpired(true) && m_pSkillInfo.Interval != 0)
		{
            UseSkillInfo useInfo = m_pNpc.GetUseSkillInfo(m_pSkillInfo);
            m_IntervalArgs[2] = useInfo;
            m_pNpc.AttackResult(m_IntervalArgs);
		}

        if (m_pNpc.CanMove )
        {
            m_pNpc.Move(m_pNpc.MoveSpeed, true,false);
        }
        if (m_pNpc.CanTurn )
        {
            if (m_pNpc is RealAvatar && m_bTurnStart)
            {
                m_pNpc.UpdateTurn(m_clickDirection, false);            
            }
            else
            {
                if (null != m_pNpc.CurrTarget)
                {
                    m_pNpc.UpdateTurn(m_pNpc.CurrTarget.GetPosition() - m_pNpc.GetPosition(), false);
                }                
            }                        
        }
        if (m_pNpc is BaseBattlePlayer)
        {
            BaseBattlePlayer bbp = (BaseBattlePlayer)m_pNpc;
            CBaseNpc target = bbp.CurrTarget;
            if (target == null)
            {
                eSkillMouseAction action = (eSkillMouseAction)m_pSkillInfo.MouseAction;
                switch (action)
                {
                    case eSkillMouseAction.CanTurn:
                        {
                            if (m_AutoSelectDirection)
                            {
                                target = m_pNpc.CurrBattleScene.GetNearestNpc(m_pNpc,eCheckNpcType.Emeny,10000,360,false,true);
                                if (target != null)
                                {
                                    m_bTurnStart = true;

                                    m_clickDirection = (target.GetPosition() - m_pNpc.GetPosition()).normalized;
                                    m_clickDirection.y = 0;
                                }
                                m_AutoSelectDirection = false;
                            }
                            
                        }
                        break;
                    case eSkillMouseAction.CanMove:
                    case eSkillMouseAction.MoveAndTurn:
                        {
                            if (bbp.Trusteeship)
                            {
                                target = m_pNpc.CurrBattleScene.GetNearestNpc(m_pNpc, eCheckNpcType.Emeny, 10000, 360, false, true);
                                if (target != null)
                                {
                                    m_pNpc.SetFollowTransform(target.GetTransform(), true);
                                }
                            }
                            

                        }
                        break;
                }
            }
        }

        if (m_fTime != -1)
        {
            if (m_pTimer.IsExpired(false))
            {
                uint nextID = SkillManager.GetInst().GetRandomNextSkill(m_pSkillInfo);
                if (nextID != 0)
                {
                    //������һ������
                    SkillContent nextInfo = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
                    if (null != nextInfo)
                    {
                        //leaveState
                        eSkillType skillType = (eSkillType)nextInfo.SkillType;
                        if (skillType == eSkillType.CreateNpc)
                        {
                            eSkillType enterType = (eSkillType)MyConvert_Convert.ToByte(nextInfo.ExtraArgs[2]);
                            if (enterType != eSkillType.SkillType)
                            {
                                m_pNpc.LeaveState(m_state); 
                            }
                        }
                        else if (skillType != eSkillType.SkillType)
                        {
                            m_pNpc.LeaveState(m_state);
                        }

                        List<CBaseNpc>  targetlist = m_pNpc.TargetList;
                        m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)nextInfo.Key, targetlist));
                        return;
                    }
                }
            }
        }  

		base.Update();

    }
}
