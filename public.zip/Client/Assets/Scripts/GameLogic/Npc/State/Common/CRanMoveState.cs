﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CRanMoveState : CBaseState
{
    private SkillContent m_pSkillLoader;
    public CRanMoveState(CBaseNpc pNpc) :
        base(pNpc, eActionState.RandomMove, false, false, false, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.ReleaseActionTimer();
        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;

        //m_pNpc.HitResultCall = HitResult;

    }

    public void SetRanMoveInfo(SkillContent pSkillInfo)
    {
        m_pSkillLoader = pSkillInfo;
        float time = pSkillInfo.LastTime;
        SetTimer(time);

        m_pNpc.SetActionTimer(time);        
    }

    private Vector3 SummonPosition(CBaseNpc srcNpc,float minRadius, float maxRadius) 
    {
        Vector3 summonPosition = Vector3.zero;

        float radius = UnityEngine.Random.Range(minRadius, maxRadius);        

        Vector3 destPosition = srcNpc.GetPosition() + Common.RandomOnCircle(radius); ;

        Ray ray = new Ray(destPosition, srcNpc.GetPosition() - destPosition);

        //判断随机点是否在空气墙外
        if (Physics.Raycast(ray, radius, 1 << DEFINE.AIR_WALL))
        {
            summonPosition = SummonPosition(srcNpc, minRadius, maxRadius);           
        }
        else
        {
            summonPosition = m_pNpc.CurrBattleScene.SummonPosition(destPosition, m_pNpc.CharacterRadius, false,m_pNpc,m_pNpc.NpcCollider);
        }

        return summonPosition;
        //沙
    }

    public void HitResult(uint loaderkey,CBaseNpc pTarget)
    //public void HitResult(params object[] args)
    {
        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(loaderkey);
        //CBaseNpc pTarget = args[1] as CBaseNpc;
        if (null == pTarget || null == pSkillLoader)
        {
            return;
        }
    
        List<float> rangs = pSkillLoader.RangeArgs;
        float minRadius = rangs[0];
        float maxRadius = rangs[1];

        Vector3 destPosition = SummonPosition(pTarget,minRadius,maxRadius);
        m_pNpc.SetPosition(destPosition);

        m_pNpc.LeaveState(eActionState.RandomMove);
    }

    

    public override void BreakState()
    {
        base.BreakState();

        //m_pNpc.HitResultCall = null;

        //uint nextID = m_pSkillLoader.GetRandomNextSkill();
        //if (nextID != 0)
        //{
        //    //设置下一个技能
        //    SkillContent nextInfo = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
        //    if (null != nextInfo)
        //    {
        //        m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg(nextInfo.GetKey(), null));
        //    }
        //}
    }

    public override void LeaveState()
    {
        base.LeaveState();

        //m_pNpc.HitResultCall = null;

        uint nextID = SkillManager.GetInst().GetRandomNextSkill(m_pSkillLoader);
        if (nextID != 0)
        {
            //设置下一个技能
            SkillContent nextInfo = HolderManager.m_SkillHolder.GetStaticInfo(nextID);
            if (null != nextInfo)
            {
                m_pNpc.Command(eCommandType.UseSkill, new UseSkillCommandArg((uint)nextInfo.Key, null));
            }
        }
    }

}
