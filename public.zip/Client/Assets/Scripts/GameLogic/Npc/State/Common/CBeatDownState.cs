using UnityEngine;
using System.Collections;

//����
public class CBeatDownState : CBaseState
{

    public CBeatDownState(CBaseNpc pNpc) :
        base(pNpc, eActionState.Down, true, false, false, true)
    {
    }

    public override void EnterState()
    {      
        base.EnterState();

        if (m_pNpc is BaseBattlePlayer)
        {
            //m_pNpc.AddBuff(DEFINE.AVATAR_BEHIT_INVINCIBILITY_BUFF_ID);
        }

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;
        m_pNpc.EnablePathFinding(false);

        m_pNpc.SoundBreak();
    }

    public override void LeaveState()
    {
        base.LeaveState();
        if (m_pNpc is BaseBattlePlayer)
        {
            m_pNpc.DelBuff(DEFINE.AVATAR_BEHIT_INVINCIBILITY_BUFF_ID);
        }
    }

    public override float GetActionTime()
    {
        float fActionTime = base.GetActionTime();

        if (fActionTime != -1)
        {
            //float moveTime =  Mathf.Abs(m_fHorizontalDis / m_fHorizontalSpeed) ;
            fActionTime = fActionTime > m_fAnkylosisTime ? fActionTime : m_fAnkylosisTime;
        }

        return fActionTime;
    }

    public override void Update()
    {
        base.Update();

        if (m_fHorizontalSpeed != 0)
        {
            if (m_pHorDelayTimer.IsExpired(false))
            {
                if (!m_pHorzontalTimer.IsExpired(false))
                {
                    m_pNpc.Move(m_fHorizontalSpeed, true,false);
                }
                else
                {
                    //����Ӱ��
                    if (!m_pNpc.IsInGround)
                    {
                        m_pNpc.Move(0f, true);
                    }
                }
            }

        }



    }


}
