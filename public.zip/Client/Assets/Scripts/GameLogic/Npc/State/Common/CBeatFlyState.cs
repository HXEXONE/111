using UnityEngine;
using System.Collections;

public class CBeatFlyState : CBaseState
{
    public CBeatFlyState(CBaseNpc pNpc) :
        base(pNpc, eActionState.BeatFly, true, false, false, true)
    {
    }

    public override void EnterState()
    {
        base.EnterState();

        m_pNpc.CanMove = false;
        m_pNpc.CanTurn = false;
        m_pNpc.ApplyRootMotion = false;                

        m_pNpc.EnablePathFinding(false);

        m_pNpc.SoundBreak();
    }

    public override float GetActionTime()
    {
        float fActiontime = base.GetActionTime();

        if (fActiontime != -1)
        {
            //float moveTime =  Mathf.Abs(m_fHorizontalDis / m_fHorizontalSpeed);
            fActiontime = fActiontime > m_fAnkylosisTime ? fActiontime : m_fAnkylosisTime;
        }
        return fActiontime;        
    }


    public override void Update()
    {
        base.Update();

        if (m_fHorizontalSpeed != 0)
        {
            if (m_pHorDelayTimer.IsExpired(false))
            {
                if (!m_pHorzontalTimer.IsExpired(false))
                {
                    m_pNpc.Move(m_fHorizontalSpeed, true,false);
                }
                else
                {
                    //����Ӱ��
                    if (!m_pNpc.IsInGround)
                    {
                        m_pNpc.Move(0f, true);
                    }
                }
            }

        }
    }
  
    
}
