﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//释放技能npc(仅对释放技能情况下使用)
public class SkillNpc : CBaseNpc
{
    private CBaseNpc m_parentNpc; //寄主npc
    private CObject m_obj;
    private uint m_skillID;
    private string m_szPath;

    public SkillNpc(CBaseNpc parent,uint skillID) 
    {
        m_parentNpc = parent;

        m_skillID = skillID;
    }

    public CBaseNpc ParentNpc
    {
        get { return m_parentNpc; }
    }

    public string Path
    {
        set { m_szPath = value; }
    }

    public override bool Init(BattleScene battlescene, uint index, uint uiNpcID, ushort wLevel, eNpcSort sort, Vector3 position, Quaternion rotation, string tag = DEFINE.UNTAGGED_OBJECT_TAG,List<int> ExtraAiList = null,List<int> ExtraSkillList = null)
    {
        m_npcGroup = m_parentNpc.NpcGroup;
        base.Init(battlescene, index, uiNpcID, wLevel, sort, position, rotation, tag);

        /*m_npcSort = m_parentNpc.NpcSort;*/
        return true;
    }

    protected override void InitCharacterCard(ushort wLevel)
    {
        m_pCard = m_parentNpc.CharacterCard;
        m_pOriginCard = m_pCard;

        m_nHp = m_pCard.nMaxHp;
    }

    protected override void CreateNpc(Vector3 position, Quaternion rotation,bool replace =false)
    {
        string loadPath = string.IsNullOrEmpty(m_szPath) ?  "resources/npc/npc/skillnpc_model.x" : m_szPath;
        if (null != m_pNpcObj)
        {
            m_pNpcObj.DestroyGameObject(eObjectDestroyType.Memory);
        }
        m_pNpcObj = new CObject(loadPath);

        m_pNpcObj.Name = m_uiIndex.ToString();
        m_pNpcObj.CallBack = LoadNpcCompleted;
        m_pNpcObj.IsMemoryFactory = true;
        m_pNpcObj.ObjectType = replace ? eObjectType.ReplaceModel : eObjectType.Npc;
        m_pNpcObj.BornPosition = position;
        m_pNpcObj.BornRotation = rotation;

        m_pNpcObj.LoadObject();

    }

    protected override void LoadNpcCompleted(GameObject o, params object[] args)
    {
        if (null == o)
        {
            m_szPath = "resources/npc/npc/skillnpc_model.x";
            CreateNpc(m_pNpcObj.BornPosition, m_pNpcObj.BornRotation, true);
            return;
        }
        m_myTrans = o.transform;
        m_playerTrans = m_myTrans;

        Transform temp = m_myTrans.Find(DEFINE.OBJECT_NAME_AUDIOSOURCE);

        if (temp == null)
        {
            GameObject audioSourceObject = new GameObject(DEFINE.OBJECT_NAME_AUDIOSOURCE);
            m_audioSourceObject = audioSourceObject;
            m_audioSourceObject.transform.parent = m_myTrans;
        }
        else
            m_audioSourceObject = temp.gameObject;

        m_audioSourceObject.transform.localPosition = Vector3.zero;

        SkillContent pSkillLoader = HolderManager.m_SkillHolder.GetStaticInfo(m_skillID);
        if (null == pSkillLoader)
        {
            return;
        }
        m_myTrans = o.transform;
        m_playerTrans = m_myTrans;

        m_maxAttackRange = pSkillLoader.JudgeArgs[1];
        

        AddBuff(DEFINE.FOREVER_INVINCIBILITY_BUFF_ID);


        m_rangeNpcList.Clear();
        Dictionary<uint,CBaseNpc> dict =  CurrBattleScene.GetNpcDict();
        foreach (var npc in dict.Values)
        {
            AddRangeNpc(npc);
        }
        //List<CBaseNpc> list = m_parentNpc.GetRangeNpcList();
        //m_rangeNpcList = BattleScene.GetNpcDict().Values as List<CBaseNpc>;
        //AddRangeTrigger();

        //CheckAttackRange(pSkillLoader);
        //CheckRangeNpcInclude(pSkillLoader);

        //use skill 用延迟0.05 确保在OnTriggerEnter函数后,尽管不太科学
        //UnityCallBackManager.GetInst().AddCallBack(0.1f, delegate(object[] sargs) 
        //{
            DoUseSkill(new UseSkillCommandArg(m_skillID, null));
        //});       
    }



    public override CSkillupInfo GetSkillUpLoader(SkillContent pUserSkillLoader, bool bPassively)
    {
        if (m_parentNpc.IsDead() )
        {
            return null;
        }
        return m_parentNpc.GetSkillUpLoader(pUserSkillLoader, bPassively);
    }

    public override void SimpleMove(Vector3 dir, float speed)
    {

    }

    public override void Release(eObjectDestroyType type)
    {
        base.Release(eObjectDestroyType.Memory);
    }


    public override eNpcSortType GetNpcSortType()
    {
        return eNpcSortType.Pet;
    }
    public override List<float> GetAniMoveSpeed()
    {
        return null;
    }
    public override float GetMaxMoveSpeed()
    {
        return 0f;
    }

    public override bool IsKill()
    {
        return false;
    }
    public override bool IsHitDown()
    {
        return false;
    }
    public override bool IsBeatFly()
    {
        return false;
    }
    public override bool IsCanStun()
    {
        return false;
    }
    public override bool IsSlow()
    {
        return false;
    }
    public override int GetDeadActID()
    {
        return 0;
    }
    public override float GetRigidity()
    {
        return 0;
    }

    public override string GetName()
    {
        return "";
    }
 
}
