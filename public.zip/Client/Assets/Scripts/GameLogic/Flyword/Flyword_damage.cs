﻿using UnityEngine;
using System.Collections;

public class Flyword_damage : Flyword_base
{
    private eFlyword_damage m_state;

    private Vector3 m_orignposition;

    private float m_horizontalSpeed;//水平速度
    private float m_verticalSpeed;//垂直速度
    private int m_dir;//方向
    private float m_lastTime;//持续时间
    private float m_delay;

    public bool m_bEnemy;//是否敌方
    private float m_fEnemyScale;
    public float EnemyScale
    {
        set
        {
            if (value < 1) m_fEnemyScale = 1;
            else if (value > 2) m_fEnemyScale = 2;
            else m_fEnemyScale = value;
        }
    }

    private float m_startScale;

    public override void Reset()
    {
        base.Reset();

        m_horizontalSpeed = Random.Range(1.5f, 2f);
        

        m_dir = (Random.Range(0, 2) == 0 ? 1 : -1);
        
       

        SetAlpha(1);

        if (m_bEnemy)
        {
            m_delay = 0.8f;
            m_lastTime = 1f;
            m_verticalSpeed = 1;
            m_startScale = 1 * (m_fEnemyScale < 1? 1:m_fEnemyScale);
            myTransform.position += new Vector3(0, 0.5f, 0);
        }
        else
        {
            m_delay = 0.5f;
            m_lastTime = 0.6f;
            m_verticalSpeed = Random.Range(1f, 1.5f);
            m_startScale = 1.2f;
            myTransform.position += new Vector3(m_dir * Random.Range(0, 0.2f), 1.3f, 0);
        }
        SetScale(m_startScale);
    }

    void Update()
    {
        //float horizontalSpeed = easeOutSine(m_horizontalSpeed,0,(Time.time - m_startTime)/(m_lastTime + m_delay));

        if (m_bEnemy)
        {
            myTransform.position += Vector3.up * m_verticalSpeed * Time.deltaTime;
        }
        else
        {
            myTransform.position += m_dir * Vector3.right * m_horizontalSpeed * Time.deltaTime;

            //float verticalSpeed = easeOutSine(m_verticalSpeed, 0, (Time.time - m_startTime) / (m_lastTime + m_delay));
            myTransform.position += Vector3.up * m_verticalSpeed * Time.deltaTime;

            m_verticalSpeed -= 8 * Time.deltaTime;
        }
        

        if (Time.time - m_startTime >= m_delay)
        {
            float percent = Mathf.Clamp01((Time.time - m_startTime) / m_lastTime);
            m_alpha = easeInSine(1, 0, percent);

            SetAlpha(m_alpha);

            if (m_alpha <= 0)
            {
                if (callback != null)
                {
                    callback(new object[] { gameObject });
                }
            }
        }


    }

    //void Update()
    //{


    //}
}
