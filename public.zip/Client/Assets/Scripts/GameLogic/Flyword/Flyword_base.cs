﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Flyword_base : MonoBehaviour
{
    public OnCallBack callback;
    protected float m_startTime;
    protected Transform myTransform;

    private List<Material> m_materials = new List<Material>();

    protected float m_alpha;
    protected float m_scale;

    private bool m_bShow;

    private MeshRenderer[] m_mrs;

    public virtual void Awake()
    {
        myTransform = transform;
        m_mrs = GetComponentsInChildren<MeshRenderer>(true);

        foreach (MeshRenderer mr in m_mrs)
        {
            m_materials.Add(mr.material);
        }

        m_bShow = true;

    }

    public bool Show
    {
        set
        {
            m_bShow = value;

            if (m_mrs != null)
            {
                foreach (MeshRenderer mr in m_mrs)
                {
                    mr.enabled = value;
                }
            }
        }
    }

    public virtual void Reset()
    {
        m_startTime = Time.time;
    }

    protected void SetAlpha(float alpha)
    {
        m_alpha = alpha;

        foreach (Material m in m_materials)
        {
            Color color = m.color;
            color.a = alpha;
            m.color = color;
        }

    }

    protected void SetScale(float scale)
    {
        m_scale = scale;
        myTransform.localScale = Vector3.one * scale;
    }


    protected float easeInSine(float start, float end, float value)
    {
        end -= start;
        return -end * Mathf.Cos(value / 1 * (Mathf.PI / 2)) + end + start;
    }

    protected float easeOutSine(float start, float end, float value)
    {
        end -= start;
        return end * Mathf.Sin(value / 1 * (Mathf.PI / 2)) + start;
    }


    protected float bounce(float start, float end, float value)
    {
        value /= 1f;
        end -= start;
        if (value < (1 / 2.75f))
        {
            return end * (7.5625f * value * value) + start;
        }
        else if (value < (2 / 2.75f))
        {
            value -= (1.5f / 2.75f);
            return end * (7.5625f * (value) * value + .75f) + start;
        }
        else if (value < (2.5 / 2.75))
        {
            value -= (2.25f / 2.75f);
            return end * (7.5625f * (value) * value + .9375f) + start;
        }
        else
        {
            value -= (2.625f / 2.75f);
            return end * (7.5625f * (value) * value + .984375f) + start;
        }
    }


}