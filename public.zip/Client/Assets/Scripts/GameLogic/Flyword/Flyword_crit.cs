﻿using UnityEngine;
using System.Collections;
public enum eFlyword_crit
{
    None,
    ZoomOut,//放大
    Stay,//停留
    ZoomIn,//缩小
}
public class Flyword_crit : Flyword_base
{   
    private eFlyword_crit m_state;
    private float m_scale;


    public override void Reset()
    {
        base.Reset();
        m_state = eFlyword_crit.ZoomOut;
        SetScale(3.5f);
        SetAlpha(1);
    }

    void Update()
    {
        switch (m_state)
        {
            case eFlyword_crit.ZoomOut:
                {
                    float percent = Mathf.Clamp01((Time.time - m_startTime) / 0.5f);
                    m_scale = easeOutSine(4f, 2, percent);

                    SetScale(m_scale);

                    if (m_scale <= 2)
                    {
                        m_state = eFlyword_crit.Stay;
                        m_startTime = Time.time;
                    }
                }
                break;
            case eFlyword_crit.Stay:
                {
                    if (Time.time - m_startTime >= 0.2f)
                    {
                        m_startTime = Time.time;
                        m_state = eFlyword_crit.ZoomIn;
                    }
                }
                break;
            case eFlyword_crit.ZoomIn:
                {
                    float percent = Mathf.Clamp01((Time.time - m_startTime) / 0.5f);
                    m_scale = easeInSine(2, 0, percent);

                    SetScale(m_scale);

                    if (m_scale <= 0)
                    {
                        m_state = eFlyword_crit.None;
                        if (callback != null)
                        {
                            callback(new object[] { gameObject });
                        }
                    }
                }
                break;
        }
    }

}
