﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class FlyWordControl : MonoBehaviour
{
    public GameObject transObj;
    public FlywordMediator m_pFlywordMediator;
    public CPanel m_panel;
    private Vector3 anchorDot = Vector3.zero;
    private bool bStart = false;
    private float factor = 200.0f;
    private Vector2 offset = Vector2.zero;
    private float up = 0.0f;
    private List<GameObject> wordArray = new List<GameObject>();
    private List<UITweenControl<TweenAlpha>> uiAlpha = new List<UITweenControl<TweenAlpha>>();
    private List<UITweenControl<TweenScale>> uiScale = new List<UITweenControl<TweenScale>>();
    private List<UITweenControl<TweenPosition>> uiPosition = new List<UITweenControl<TweenPosition>>();
    private UITweenControl<TweenScale> uiDynaimcScale = new UITweenControl<TweenScale>();
    private List<UITweenControl<TweenColor>> uiColor= new List<UITweenControl<TweenColor>>();                  //针对金币掉落

    
    private float speed = 15.0f;
    public FlyWordType wordType = FlyWordType.None;
    //private UIGrid grid;
	// Use this for initialization

    public bool isOver = false;
	
	// Update is called once per frame
	void Update () {
        if (wordType == FlyWordType.GoldItem)
        {
            TransformPos();
        }
	}
	
	private void TransformPos()
	{
		//Vector3 addNpcPos = new Vector3(npcPos.x, npcPos.y + 2.0f, npcPos.z);

        if (m_pFlywordMediator.GetCamera() == null)
        {
            this.enabled = false;
            return;
        }
        else
        {
            this.enabled = true;
        }
        Vector3 screenPos = m_pFlywordMediator.GetCamera().WorldToScreenPoint(anchorDot);
        Vector3 guiPos = new Vector3(screenPos.x, Screen.height - screenPos.y, screenPos.z);
        float scale_x =  guiPos.x / Screen.width;
        float scale_y = guiPos.y / Screen.height;
		
        Vector3 pos = new Vector2(scale_x * DEFINE.STANDARD_WIDTH, scale_y * DEFINE.STANDARD_HEIGHT);
		float x = pos.x - DEFINE.STANDARD_WIDTH / 2;
        float y = DEFINE.STANDARD_HEIGHT / 2 - pos.y;
        if (bStart)
        {
            factor += speed;
            up += Time.deltaTime * factor;
        }

        //采取高度适应
        AnchorCamera ac = m_pFlywordMediator.MyAnchorCamera;
        if (ac != null)
        {
            x = (x / ac.resolutionScale) * (Screen.width / DEFINE.STANDARD_WIDTH);
        }

        transform.localPosition = new Vector3(x, y+up, transform.localPosition.z);
	}

    private void CritTransform()
    {
        if (m_pFlywordMediator.GetCamera() == null)
        {
            this.enabled = false;
            return;
        }
        else
        {
            this.enabled = true;
        }
        Vector3 screenPos = m_pFlywordMediator.GetCamera().WorldToScreenPoint(anchorDot);
        Vector3 guiPos = new Vector3(screenPos.x, Screen.height - screenPos.y, screenPos.z);
        float scale_x =  guiPos.x / Screen.width;
        float scale_y = guiPos.y / Screen.height;
		
        Vector3 pos = new Vector2(scale_x * DEFINE.STANDARD_WIDTH, scale_y * DEFINE.STANDARD_HEIGHT);
		float x = pos.x - DEFINE.STANDARD_WIDTH / 2;
        float y = DEFINE.STANDARD_HEIGHT / 2 - pos.y;

        //采取高度适应
        AnchorCamera ac = m_pFlywordMediator.MyAnchorCamera;
        if (ac != null)
        {
            x = (x / ac.resolutionScale) * (Screen.width / DEFINE.STANDARD_WIDTH);
        }
        

        transform.localPosition = new Vector3(x, y+up, transform.localPosition.z);
    }

    public void ClearWordList()
    {
        wordArray.Clear();
    }

    public void SetFlyword (CPanel panel,FlywordMediator flyMediator,Vector3 npcPos) 
    {
        m_pFlywordMediator = flyMediator;

        m_panel = panel;

        anchorDot = npcPos;
        up = 0.0f;
        bStart = true;

        if (wordType == FlyWordType.MonsterCritDamage || wordType == FlyWordType.RoleCritDamage)
        {
            anchorDot = new Vector3(anchorDot.x, anchorDot.y + 2.0f, anchorDot.z);
        }
        else if (wordType == FlyWordType.MonsterHeading || wordType == FlyWordType.RoleHeading)
        {
            anchorDot = new Vector3(anchorDot.x +(wordArray.Count*0.2f), anchorDot.y, anchorDot.z);
        }
        //else if (wordType == FlyWordType.MonsterDodgeWord)
        //{
        //    anchorDot = new Vector3(anchorDot.x+1.5f, anchorDot.y+1.0f, anchorDot.z);
        //}
        
    }
    public void SetWordArray(GameObject word)
    {
        //if (grid == null)
        //{
        //    GameObject parent =  word.transform.parent.gameObject;
        //    grid = parent.GetComponent<UIGrid>();
        //    if (grid == null)
        //    {
        //        grid = parent.AddComponent<UIGrid>();
        //    }
        //   SetCellSize(20.0f);
        //}
        wordArray.Add(word);
    }

    //private void SetCellSize(float fwidth, float height = 100.0f)
    //{
    //    grid.cellWidth = fwidth;
    //    grid.cellHeight = height; 
    //    grid.repositionNow = true;
    //    grid.Reposition();
    //}

    private void ResetFlyword()
    {
        for (int i = 0; i < wordArray.Count;i++ )
        {
            wordArray[i].transform.localPosition = new Vector3(i * 20, wordArray[i].transform.localPosition.y, wordArray[i].transform.localPosition.z);
            wordArray[i].transform.localScale = Vector3.one;
        }
        
        
    }


    #region MonsterDamage  RoleDamage BossDamage 以后可能要拆分，
    public void NormalDamageDelegate(FlyWordType tpye = FlyWordType.None ) 
    {
        wordType = tpye;
        int taCount = uiAlpha.Count;
        int waCount = wordArray.Count;
        factor = 400.0f;
        bStart = true;
        if ( taCount < waCount)
        {
            for (int i = taCount; i < waCount; i++)
            {
                uiAlpha.Add(new UITweenControl<TweenAlpha>()); 
            }
        }
        for(int i =0;i<wordArray.Count;i++)
        {
            if (uiAlpha[i] == null)
            {
                uiAlpha[i] = new UITweenControl<TweenAlpha>();
            }
            uiAlpha[i].Begin(wordArray[i], 0.0f, 1.0f, 0.3f, 0.0f, AnimationCurveTool.CurveBaseType.SubCurve);
            uiAlpha[i].SetFinishDelegate(OnDamageAlphaStandFinish);
        }
        
    }
    private void OnDamageAlphaStandFinish()
    {
        for (int i = 0; i < wordArray.Count; i++)
        {
            //if (!string.IsNullOrEmpty(uiAlpha[i].GetTweenOnFinish().finishName))
            {
                uiAlpha[i].RemoveEventDelegate();
            }
            uiAlpha[i].Begin(wordArray[i], 1.0f, 1.0f, 0.15f, 0.0f, AnimationCurveTool.CurveBaseType.SubCurve, UITweener.Method.EaseIn);
            uiAlpha[i].SetFinishDelegate(OnDamageAlphaFinish);
        }
        bStart = false;
    }
    private void OnDamageAlphaFinish()
    {
        bStart = true;
        factor = 50.0f;
        for (int i = 0; i < wordArray.Count; i++)
        {
            //if (!string.IsNullOrEmpty(uiAlpha[i].GetTweenOnFinish().finishName))
            {
                uiAlpha[i].RemoveEventDelegate();
            }
            uiAlpha[i].Begin(wordArray[i], 1.0f, 0.0f, 0.5f, 0.15f, AnimationCurveTool.CurveBaseType.SubCurve, UITweener.Method.EaseIn);
            uiAlpha[i].SetFinishDelegate(OnTweenAlphaFinish);
        }
    }

    private void OnTweenAlphaFinish()
    {
        if (null == m_pFlywordMediator)
        {
            return;
        }
        bStart = false;
        RemoveOnFinish();
        m_pFlywordMediator.RemoveItem(m_panel);
    }
    #endregion 

    #region CritDamage 暴击伤害
    public void CritDamageDelegate(FlyWordType tpye = FlyWordType.None)
    {
        wordType = tpye;
        int tsCount = uiScale.Count;
        int waCount = wordArray.Count;
        //if (grid !=null)
        //{
        //    SetCellSize(22.0f);
        //}

        if (m_panel == null)
        {
            RemoveOnFinish();
            return;
        }
        m_panel.LocalScale = Vector3.zero;
        uiDynaimcScale.Begin(m_panel.ElementObj, Vector3.zero, new Vector3(1.0f, 1.0f, 1.0f), 0.3f, 0.0f, AnimationCurveTool.CurveBaseType.AddCurve, UITweener.Method.BounceIn);
        uiDynaimcScale.SetFinishDelegate(OnCritScaleStanedFinish);
    }
    private void OnCritScaleStanedFinish()
    {

        uiDynaimcScale.Begin(m_panel.ElementObj, new Vector3(1.0f, 1.0f, 1.0f), new Vector3(1.8f, 1.8f, 1.0f), 0.1f, 0.3f, AnimationCurveTool.CurveBaseType.AddCurve, UITweener.Method.BounceIn);
        uiDynaimcScale.SetFinishDelegate(OnCritDamageScaleFinish);
       
        bStart = false;
    }
    private void OnCritScaleFinish()
    {
        uiDynaimcScale.RemoveEventDelegate();

        uiDynaimcScale.Begin(m_panel.ElementObj, new Vector3(1.8f, 1.8f, 1.0f), Vector3.zero, 0.2f, 0.0f, AnimationCurveTool.CurveBaseType.AddCurve, UITweener.Method.BounceIn);
        uiDynaimcScale.SetFinishDelegate(OnCritDamageScaleFinish);

       
    }
    private void OnCritDamageScaleFinish()
    {
        if (null == m_pFlywordMediator)
        {
            return;
        }
        TweenScale pScale = m_panel.ElementObj.GetComponent<TweenScale>();
        if (pScale!=null)
        {
            Destroy(pScale);
        }
        RemoveOnFinish();
        m_pFlywordMediator.RemoveItem(m_panel);
    }
    #endregion 


   
   
    #region ComboWord 连击数
    
    public void ComboDelegate(FlyWordType combo = FlyWordType.ComboWord)
    {
        bStart = false;
        wordType = combo;
        int tsCount = uiScale.Count;
        int waCount = wordArray.Count;
        //if (grid !=null)
        //{
        //    SetCellSize(22.0f);
        //}
        if (tsCount < waCount)
        {
            for (int i = tsCount; i < waCount; i++)
            {
                uiScale.Add(new UITweenControl<TweenScale>());
            }
        }
        for (int i = 0; i < wordArray.Count; i++)
        {
            if (uiScale[i] == null)
            {
                uiScale[i] = new UITweenControl<TweenScale>();
            }
            wordArray[i].transform.localPosition = new Vector3(i * 22, wordArray[i].transform.localPosition.y, wordArray[i].transform.localPosition.z);
            wordArray[i].transform.localScale = Vector3.zero;
            uiScale[i].Begin(wordArray[i], Vector3.zero, new Vector3(1.0f, 1.0f, 1.0f), 0.3f, 0.0f, AnimationCurveTool.CurveBaseType.AddCurve, UITweener.Method.BounceIn);
            uiScale[i].SetFinishDelegate(OnCritScaleStanedFinish);
        }
    }
    private void OnComboPositionFinish(TweenPosition comboPos)
    {
        //if (!string.IsNullOrEmpty(UIalpha.GetTweenOnFinish().finishName))
        //{
        //    UIalpha.RemoveEventDelegate();
        //}
        //UIscale = new UITweenControl<TweenScale>();
        //UIscale.Begin(m_pPanelGo, new Vector3(0.9f, 0.9f, 1f), new Vector3(1.1f, 1.2f, 1f), 0.2f, 0.0f, AnimationCurveTool.CurveBaseType.SubCurve,UITweener.Method.EaseOut,UITweener.Style.PingPong);
        //UIposition.Begin(m_pPanelGo, new Vector3(transform.position.x - 82, transform.position.y, transform.position.z), new Vector3(transform.position.x - 83.0f, transform.position.y + 0.8f, transform.position.z), 0.3f, 0.0f, AnimationCurveTool.CurveBaseType.SubCurve, UITweener.Method.EaseOut, UITweener.Style.PingPong);
        //UIalpha = new UITweenControl<TweenAlpha>();
        //UIalpha.Begin(m_pPanelGo, 1.0f, 0.0f, 0.5f, 2.0f, AnimationCurveTool.CurveBaseType.SubCurve, UITweener.Method.EaseIn);
        //UIalpha.SetFinishDelegate(OnComboAlphaFinish);
    }
    private void OnComboAlphaFinish(TweenAlpha comboAlpha)
    {
        if (null == m_pFlywordMediator)
        {
            return;
        }
        m_pFlywordMediator.RemoveItem(m_panel);
    }

    #endregion

    #region ResultWord 战斗胜利
    public void ResultWordDelegate(FlyWordType combo = FlyWordType.ComboWord)
    {
        //transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z-300);

        //UIposition = new UITweenControl<TweenPosition>();
        //UIposition.Begin(m_pPanelGo, transform.position, new Vector3(transform.position.x, transform.position.y, transform.position.z+300), 0.6f, 0.4f, AnimationCurveTool.CurveBaseType.SubCurve);

        //UIposition.SetFinishDelegate(OnResultWordPositionFinish);
    }
    private void OnResultWordPositionFinish(TweenPosition comboPos)
    {

        //UIalpha = new UITweenControl<TweenAlpha>();
        //UIalpha.Begin(m_pPanelGo, 1.0f, 0.0f, 0.5f, 0.5f, AnimationCurveTool.CurveBaseType.SubCurve, UITweener.Method.EaseIn);
        ////UIalpha.SetFinishDelegate(OnResultWordAlphaFinish);
    }
    private void OnResultWordAlphaFinish(TweenAlpha comboAlpha)
    {
        if (null == m_pFlywordMediator)
        {
            return;
        }
        m_pFlywordMediator.RemoveItem(m_panel);
    }
    #endregion

#region 获取金币
    public void GetGoldItem(FlyWordType type = FlyWordType.GoldItem)
    {
        wordType = type;
        factor = 6.0f;
        speed = 5.0f;
        int taCount = uiColor.Count;
        int waCount = wordArray.Count;
        //SetCellSize(36.0f);
        if (taCount < waCount)
        {
            for (int i = taCount; i < waCount; i++)
            {
                uiColor.Add(new UITweenControl<TweenColor>());
            }
        }

        for (int i = 0; i < wordArray.Count; i++)
        {
            uiColor[i].Begin(wordArray[i], new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 0.2f), 0.4f, 0.8f, AnimationCurveTool.CurveBaseType.SubCurve);
            uiColor[i].SetFinishDelegate(OnGoldItemAlphaFinish);
        }
    }

    private void OnGoldItemAlphaFinish()
    {
        if (null == m_pFlywordMediator)
        {
            return;
        }
        for (int i = 0; i < wordArray.Count; i++)
        {

            //if (!string.IsNullOrEmpty(uiColor[i].GetTweenOnFinish().finishName))
            {
                uiColor[i].RemoveEventDelegate();
            }
        }
        RemoveOnFinish();
        m_pFlywordMediator.RemoveItem(m_panel);
    }

#endregion

    private void RemoveOnFinish()
    {

        ResetFlyword();
        if (uiAlpha != null)
        {
            for (int i = 0; i < uiAlpha.Count; i++)
            {
                //if (!string.IsNullOrEmpty(uiAlpha[i].GetTweenOnFinish().finishName))
                {
                    if (i < wordArray.Count)
                    {
                        uiAlpha[i].Reset(wordArray[i]);
                    }
                    
                    uiAlpha[i].RemoveEventDelegate();
                }
            }
        }
        if (uiScale != null)
        {
            for (int i = 0; i < uiScale.Count; i++)
            {
                //if (!string.IsNullOrEmpty(uiScale[i].GetTweenOnFinish().finishName))
                {
                    if (i < wordArray.Count)
                    {
                        uiScale[i].Reset(wordArray[i]);
                    }
                    uiScale[i].RemoveEventDelegate();
                }
            }
        }
        if (uiPosition != null)
        {
            for (int i = 0; i < uiPosition.Count; i++)
            {
                //if (!string.IsNullOrEmpty(uiPosition[i].GetTweenOnFinish().finishName))
                {
                    if (i < wordArray.Count)
                    {
                        uiPosition[i].Reset(wordArray[i]);
                    }
                    uiPosition[i].RemoveEventDelegate();
                }
            }
        }
        if (uiColor != null)
        {
            for (int i = 0; i < uiColor.Count; i++)
            {
                //if (!string.IsNullOrEmpty(uiColor[i].GetTweenOnFinish().finishName))
                {
                    if (i < wordArray.Count)
                    {
                        uiColor[i].Reset(wordArray[i]);
                    }

                    uiColor[i].RemoveEventDelegate();
                }
            }
        }

    }
}
