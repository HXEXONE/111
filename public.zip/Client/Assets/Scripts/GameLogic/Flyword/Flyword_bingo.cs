﻿using UnityEngine;
using System.Collections;

public enum eFlyword_damage
{
    None,
    Scale,
    Stay,//停留
    FadeOut,//淡出
};

public class Flyword_bingo : Flyword_base
{
    private eFlyword_damage m_state;

    private float m_horizontalSpeed;//水平速度
    private float m_verticalSpeed;//垂直速度
    private int m_dir;//方向
    private float m_lastTime;//持续时间
    private float m_delay;

    private float m_startScale;
    private float m_endScale;

    public bool m_bEnemy;

    public override void Reset()
    {
        base.Reset();

        m_state = eFlyword_damage.Scale;
        myTransform.position += Vector3.up * 1.2f - Vector3.right;
        SetAlpha(1);

        m_startScale = 3;
        m_endScale = 2;
        SetScale(m_startScale);
    }

    void Update()
    {
        switch (m_state)
        {
            case eFlyword_damage.Scale:
                {
                    float percent = Mathf.Clamp01((Time.time - m_startTime) / 0.2f);
                    m_scale = easeOutSine(m_startScale, m_endScale, percent);
                    SetScale(m_scale);
                    if (m_scale <= m_endScale)
                    {
                        m_state = eFlyword_damage.Stay;
                        m_startTime = Time.time;
                    }
                }
                break;
            case eFlyword_damage.Stay:
                {
                    if (Time.time - m_startTime >= 0.2f)
                    {
                        m_state = eFlyword_damage.FadeOut;
                        m_startTime = Time.time;
                    }
                }
                break;
            case eFlyword_damage.FadeOut:
                {
                    m_alpha -= Time.deltaTime / 0.3f;
                    SetAlpha(m_alpha);

                    float speed = 2;

                    myTransform.position += speed * Time.deltaTime * Vector3.up;

                    if (m_alpha <= 0)
                    {
                        if (callback != null)
                        {
                            callback(new object[] { gameObject });
                        }
                        m_state = eFlyword_damage.None;
                    }
                }
                break;
        }
        

    }

    //void Update()
    //{
 

    //}

}
