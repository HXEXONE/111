﻿using UnityEngine;
using System.Collections;

public enum eFlyword_miss
{
    None,
    Scale,
    Move,
}
//闪避,暴击的飘字运动
public class Flyword_miss : Flyword_base 
{
    public int moveDir;//-1向左,1向右

    private bool bComplete;

    private eFlyword_miss m_state;
    private float m_delaytime;

    public override void Reset()
    {
        base.Reset();
        bComplete = false;

        m_delaytime = 0;
        SetAlpha(1);
        SetScale(1.5f);
        EnterState(eFlyword_miss.Scale);
    }

    void EnterState(eFlyword_miss state)
    {
        m_state = state;
    }

    void Update()
    {
        switch (m_state)
        {
            case eFlyword_miss.Scale:
                {
                    float percent = Mathf.Clamp01((Time.time - m_startTime) / 0.2f);
                    m_scale = easeOutSine(1.5f, 1, percent);

                    if (m_scale <= 1)
                    {
                        SetScale(1);
                        EnterState(eFlyword_miss.Move);
                        m_startTime = Time.time;
                        m_delaytime = 0.2f;
                       // m_orignPosition = myTransform.position +Vector3.up *5;
                    }
                    else
                    {
                        SetScale(m_scale);
                    }
                }
                break;
            case eFlyword_miss.Move:
                {
                    if(Time.time - m_startTime < m_delaytime)
                    {
                        break;
                    }
                    m_alpha -= Time.deltaTime / 0.2f;
                    SetAlpha(m_alpha);
                    //Color color = m_material.color;
                    //color.a = m_alpha;
                    //m_material.color = color;

                    //float x = bounce(m_orignPosition.x, moveDir == -1 ? -10 : 10, (Time.time - m_startTime - m_delaytime) / 0.5f);
                    //myTransform.position = new Vector3(x, m_orignPosition.y, m_orignPosition.z);

                    float speed = 5;
                    myTransform.position += speed * moveDir * -myTransform.right * Time.deltaTime;

                    if (m_alpha < 0)
                    {
                        EnterState(eFlyword_miss.None);
                        if (callback != null)
                        {
                            callback(new object[] { gameObject });
                        }
                    }
                }
                break;
        }
    }


}
