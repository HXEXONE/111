﻿using UnityEngine;
using Protocol;
using Network;
using System.IO;
using System.Collections;

public class FatigueManager :SingletonObject<FatigueManager>
{

    private uint onTime;
    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_INDULGE_ONLINE_TIME, getOnlineTime, false);
       
    }

    private void getOnlineTime(BinaryReader br)
    {
        G2CNotifyIndulgeOnlineTime onlineTime = new G2CNotifyIndulgeOnlineTime();
        onlineTime.Read(br);
        onTime = onlineTime.uiOnlineTime;
        MyLog.LogError("" + onTime);
        string tips = "";
        switch (onTime)
        {
            case 0:
                tips = Common.GetText(9955001);
                break;
            case 1:
                tips = Common.GetText(9955002);
                break;
            case 2:
                tips = Common.GetText(9955003);
                break;
            case 3:
                tips = Common.GetText(9955004);
                break;
        }

        SingletonObject<PopFrameMediator>.GetInst().SetPopFrameText(PopFrameType.singleOkButton, tips, fatigueCallback);

       
    }

    private void fatigueCallback(PopFrameMediator.ClickType click)
    {

        if (onTime == 3)
        {
            Application.Quit();
            MyLog.LogError("");
        }
    }
}
