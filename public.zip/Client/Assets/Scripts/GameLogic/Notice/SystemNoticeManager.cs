﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 系统公告管理类：从服务器拉取公告json列表
/// </summary>
public class SystemNoticeManager : SingletonObject<SystemNoticeManager>
{

}
