﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


//引导行为
public enum eGuideBehavior
{
    Free,                   //自由操作
    Lock,                   //锁定,不可做任何操作
    Wait,                  //等待(傻站着被打)
}

public delegate void GuideStateHandler(eGuidTarget state);
public delegate void MoveStateHandler();

//战斗新手引导
public class BattleGuide : SingletonObject<BattleGuide>
{
    private bool m_bPause = false;//是否引导暂停

    private eGuideBehavior m_eBehavior = eGuideBehavior.Free ;

    private Vector3 m_destposition;
    private MoveStateHandler m_moveHandler = null;
    private GuideStateHandler m_guideHandler = null;

    private BattleScene m_pBattleScene = null;

    public BattleScene BattleScene
    {
        set { m_pBattleScene = value; }
    }

    public eGuideBehavior Behavior
    {
        set 
        {
            m_eBehavior = value;
            if (m_eBehavior == eGuideBehavior.Wait)
            {
                //主角进入等待状态
                Avatar pAvatar = SingletonObject<Avatar>.GetInst();
                pAvatar.EnterState(eActionState.Wait);
            }
        }
        get 
        {
            return m_eBehavior;
        }
    }

    public GuideStateHandler GuideHandler 
    {
        set { m_guideHandler = value; }
    }

    //ignoreavatar 不受暂停影响
    public void Pause(eGuidTarget state, bool pause, bool ignoreavatar = false)
    {
        if (m_bPause == pause)
            return;        

        if (!pause)
        {
            if (null != m_guideHandler)
                m_guideHandler(state);
        }

        m_bPause = pause;

        if (null != m_pBattleScene)
            m_pBattleScene.Pause(pause, ignoreavatar);
    }


    public void SetMove(MoveStateHandler handler,Vector3 destposition) 
    {
        m_moveHandler = handler;
        m_destposition = destposition;        
    }

    public bool IsPause
    {
        get { return m_bPause; }
    }

    public void Update() 
    {
        if ( null != m_moveHandler)
        {
            Avatar avatar =  SingletonObject<Avatar>.GetInst();
            if (Common.Get2DVecter3Length(avatar.GetPosition(), m_destposition) < 1f)
            {
                m_moveHandler();
                m_moveHandler = null;
            }

        }
    }

    
}
