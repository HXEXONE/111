﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;

public class CdkManager : SingletonObject<CdkManager>
{
    /*
    private string url = "http://168.168.1.92:8088/cdkey/validCDKey/lqzg";
    private WWWForm form;
    private WWW getData;

    private Dictionary<string, string> mDic = new Dictionary<string, string>();

    public void getWww()
    {
        mDic.Clear();
        mDic.Add("cdkey", "c039735ac64dcec2");
        mDic.Add("userId", "c039735ac64dcec2");
        mDic.Add("playerId", "c039735ac64dcec2");
        mDic.Add("platformId", "84");
        mDic.Add("worldId", "88");
        mDic.Add("activityId", "af23fcec2dc64");
        mDic.Add("sign", "c039735ac64dcec224da39bb868a7269");

        StartCoroutine("postData");
        
    }
    private IEnumerator postData()
    {
        form = new WWWForm();
        foreach (KeyValuePair<string, string> postArg in mDic)
        {
            form.AddField(postArg.Key, postArg.Value);
        }

        getData = new WWW(url, form);

        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("------------" + getData.error);
        }
        else
        {
            MyLog.Log("------------" + getData.text);
        }
    }
    */

    public void RegisteMessages(NetworkClient pClient)
    {
        pClient.AddOnMessageHandler((ushort)ProCG.GAME_ACK_CLIENT_VALID_CDKEY, cdkResult, true);
    }
    public void requestCdk(string key)
    {
        C2GValidCDKey cdkey = new C2GValidCDKey();
        cdkey.ActivityId = "0";
        cdkey.CDKey = key;

        NetworkClient.GetNetworkClient().SendMessage((ushort)ProCG.CLIENT_REQUEST_VALID_CDKEY, (ushort)ProCG.GAME_ACK_CLIENT_VALID_CDKEY, cdkey);
    }

    private void cdkResult(BinaryReader br)
    {
        G2CValidCDKeyResult result = new G2CValidCDKeyResult();
        result.Read(br);

        MyLog.LogError("ok  " + result.bSuccess + "   " + result.Msg);
        if (result.bSuccess == 1)
        {
            SingletonObject<CDKMediator>.GetInst().CdkSeccess();
        }
        else
        {
            string text = result.Msg;
           
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(text);
        }

    }
}
