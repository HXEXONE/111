﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Network;
using Protocol;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using LitJson;

public class FQAManager : MonoSingleton<FQAManager>
{
    private string url;
    private WWWForm form;
    private WWW getData;
    private string contentLine = "- - - - - - - - - - - - - - - - - - - - - - - - - - - \n";

    public List<string> typelist = new List<string>();
    public Dictionary<int, string> typeDic = new Dictionary<int, string>();                                                  //问题种类
    public List<int> orderlist = new List<int>();                                                                            //工单列表
    public Dictionary<int, string> enumDic = new Dictionary<int, string>();  

    private List<SQuestList> questList = new List<SQuestList>();

    public string detail;

    public int orderInt;


    public void getWww(WWWForm tform,string turl,string callback)
    {
        form = tform;
        url = turl;


        MyLog.LogError(turl);
        StartCoroutine(callback);
    }
    public void setTypeDic()
    {
        enumDic.Clear();
        string str1 = Common.GetText(9906015);
        string str2 = Common.GetText(9906016);
        string str3 = Common.GetText(9906017);
        enumDic.Add(1, str1);
        enumDic.Add(2, str2);
        enumDic.Add(3, str3);
    }

    /// <summary>
    /// 获取问题类型数据
    /// </summary>
    /// <returns></returns>
    private IEnumerator postFqaData()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("------------" + getData.error);
           
        }
        else
        {
            MyLog.Log("------------" + getData.text);
            resolveTypeJson(getData.text);
        }

    }
    /// <summary>
    /// 获取问题详细
    /// </summary>
    /// <returns></returns>
    private IEnumerator postFqaList()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("------------" + getData.error);
        }
        else
        {
            MyLog.Log("------------" + getData.text);
            resolveListJson(getData.text);
        }

    }

    /// <summary>
    /// 获取提交bug返回数据
    /// </summary>
    /// <returns></returns>
    private IEnumerator postBugData()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("------------" + getData.error);
        }
        else
        {
            //MyLog.Log("------------" + getData.text);
            resolveBugJson(getData.text);
        }
    }

    /// <summary>
    ///  获取工单列表
    /// </summary>
    /// <returns></returns>
    private IEnumerator postOrderList()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("----无历史问题list--------" + getData.error);
        }
        else
        {
            //Debug.Log("------历史问题list------" + getData.text);
            MyLog.Log("------历史问题list------" + getData.text);
            resolveOderJson(getData.text);
        }
    }

    /// <summary>
    /// 解析历史问题详细
    /// </summary>
    /// <returns></returns>
    private IEnumerator postOrderDetail()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("-------无历史问题-----" + getData.error);
        }
        else
        {

            MyLog.Log("-----历史问题-------" + getData.text);

            detail += resolveDetailJson(getData.text);
            SingletonObject<HelpMediator>.GetInst().setQuestionText1(Common.GetText(9906006), detail);

            orderInt++;
            if (orderlist.Count > orderInt)
            {
                SingletonObject<HelpMediator>.GetInst().getDetailList(orderInt);
            }
           
        }
    }

    private IEnumerator posMaiDian()
    {
        getData = new WWW(url, form);
        yield return getData;

        if (getData.error != null)
        {
            MyLog.Log("Error posMaiDian------------" + getData.error);
        }
        else
        {
            
        }
    }

    /// <summary>
    /// MD5加密
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public string getMd5(string str)
    {
        MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
        byte[] encryptedBytes = md5.ComputeHash(Encoding.ASCII.GetBytes(str));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < encryptedBytes.Length; i++)
        {
            sb.AppendFormat("{0:x2}", encryptedBytes[i]);
        }
        return sb.ToString();
    }
    /// <summary>
    /// 通过playerId获得平台ID
    /// </summary>
    /// <param name="playerId"></param>
    /// <returns></returns>
    public string getPid(ulong playerId)
    {
        ulong pid = (playerId / 10000000) % 1000;
        string pidStr = (pid + 10000).ToString();
        return pidStr;


    }

    /// <summary>
    /// playerId计算服务器Id;
    /// </summary>
    /// <param name="playerId"></param>
    /// <returns></returns>
    public ulong getSid(ulong playerId)
    {
        ulong sid = playerId / 1000 % 10000;//(playerId / 1000) % 10;
        return sid;
    }


    /// <summary>
    /// 解析问题类型数据
    /// </summary>
    /// <param name="str"></param>
    public void resolveTypeJson(string str)
    {
        typeDic.Clear();
        JsonData jd = JsonMapper.ToObject(str);
        if ((int)jd["status"] == 1)
        {
            JsonData tyList = jd["typeList"];
            for (int i = 0; i < tyList.Count; i++)
            {
                if (typeDic.ContainsKey((int)tyList[i]["id"]))
                {
                    continue;
                }
                typeDic.Add((int)tyList[i]["id"], tyList[i]["type_desc"].ToString());
                MyLog.LogError(tyList[i]["id"] + "   " + tyList[i]["type_desc"].ToString());
               
            }
            SingletonObject<HelpMediator>.GetInst().showQuestion();
        }
        else
        {
            MyLog.LogError("！");
            string txt = Common.GetText(9906018);
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(txt);
        }
       
    }

    /// <summary>
    /// 解析问题详细数据
    /// </summary>
    /// <param name="str"></param>
    private void resolveListJson(string str)
    {
        questList.Clear();
        JsonData jd = JsonMapper.ToObject(str);

        if ((int)jd["total"] <= 0)
        {
            return;
        }
        JsonData questlist = jd["questionList"];

        if ((int)jd["status"] == 1)
        {

            for (int i = 0; i < questlist.Count; i++)
            {
                SQuestList mQuest = new SQuestList();
                mQuest.id= (int)questlist[i]["id"];
                mQuest.question = questlist[i]["question"].ToString();
                mQuest.answer = questlist[i]["answer"].ToString();
                mQuest.type_id = (int)questlist[i]["type_id"];
                questList.Add(mQuest);
            }

            string title = typeDic[questList[0].type_id];

            string questh = Common.GetText(9906001);
            string answerh = Common.GetText(9906002);
            string text = null;
            for (int j = 0; j<questList.Count;j++ )
            {
                text += questh+questList[j].question + "\n" +answerh+ questList[j].answer + "\n" + contentLine+"\n";
            }
            SingletonObject<HelpMediator>.GetInst().setQuestionText(title,text);

        }
        else
        {
            MyLog.LogError("");
        }
    }

    /// <summary>
    /// 解析Bug信息
    /// </summary>
    /// <param name="str"></param>
    private void resolveBugJson(string str)
    {
        MyLog.LogError(str);
        JsonData jd = JsonMapper.ToObject(str);
        string statues = jd["status"].ToString();
        if (statues.Equals("1"))
        {
            SingletonObject<HelpMediator>.GetInst().bugCallback();
        }
        else
        {
            MyLog.LogError("");
            string txt = Common.GetText(9906008);
            SingletonObject<HUDTextMediator>.GetInst().ShowTextTip(txt);
        }
    }

    /// <summary>
    /// 解析工单列表
    /// </summary>
    /// <param name="str"></param>
    private void resolveOderJson(string str)
    {
        JsonData jd = JsonMapper.ToObject(str);
        if ((int)jd["status"] == 1)
        {
            MyLog.LogError("");
            if ((int)jd["total"] > 0)
            {
                //MyLog.LogError((int)jd["total"] + "  工单列表 (int)jd[total]");
                JsonData questionList = jd["questionList"];
                for (int i = 0; i < (int)jd["total"]; i++)
                {
                    if (!orderlist.Contains((int)questionList[i]["id"]))
                    {
                        orderlist.Add((int)questionList[i]["id"]);
                    }
                }
                MyLog.LogError("orderlist :" + orderlist.Count);
                if (orderlist.Count >0)
                {
                    SingletonObject<HelpMediator>.GetInst().getDetailList(0);
                }
                
            }
            else
            {
                SingletonObject<HelpMediator>.GetInst().nullOrderList();
            }
        }

    }

    /// <summary>
    /// 解析问题详细
    /// </summary>
    /// <param name="str"></param>
    private string resolveDetailJson(string str)
    {
        JsonData jd = JsonMapper.ToObject(str);
        if ((int)jd["status"] == 1)
        {
            JsonData jdata = jd["data"];
            string qtype = enumDic[(int)jdata["type"]];
            string qtime = jdata["create_time"].ToString();
            //string qtitle = jdata["title"].ToString();
            string time = UnixTimestampToDateTime(qtime).ToString();
            string qcontent = jdata["content"].ToString();

            JsonData replylist = jdata["replyList"];
            int len = replylist.Count;

            //List<string> aSwerlist = new List<string>();
            string aswer = null;
            for (int i = 0; i< len;i++ )
            {
                //aSwerlist.Add(replylist[i]["content"].ToString());
                aswer += Common.GetText(9906002)+replylist[i]["content"].ToString()+"\n";
            }

            string text = Common.GetText(9906003) + qtype + "\n"
                        + Common.GetText(9906014) + time + "\n"
                        + Common.GetText(9906001) + qcontent + "\n"
                        + aswer
                        + contentLine;
            return text;
        }
        else
        {
            return null;
        }
    }
   
    public string UnixTimestampToDateTime(string timestamp)
    {
        DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
        long lTime = long.Parse(timestamp + "0000000");
        TimeSpan toNow = new TimeSpan(lTime);
        return dtStart.Add(toNow).ToString("yyyy-MM-dd");//string.Format("{0:d}", dtStart.Add(toNow));
    }


}

public struct SQuestList
{
    public int id;
    public string question;
    public string answer;
    public int type_id;
}



