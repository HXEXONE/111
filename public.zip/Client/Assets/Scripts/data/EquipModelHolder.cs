using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class EquipModelContent : BaseContent
{
	public string Icon;//
	public List<string> ModelPath;//
	public List<string> TexturePath;//
	public int Describe;//
	public List<BaseFloatContent> Localposition;//
	public List<BaseFloatContent> Localrotation;//
	public Vector3 HeadCameraPosition;//
	public Vector3 HeadCameraRotation;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Icon = element.stringList[0];
		ModelPath = element.stringContentList[0].list;
		TexturePath = element.stringContentList[1].list;
		Describe = element.intList[1];
		Localposition = element.floatContentListList[0].list;
		Localrotation = element.floatContentListList[1].list;
		HeadCameraPosition = element.vector3List[0];
		HeadCameraRotation = element.vector3List[1];
    }

}

public class EquipModelHolder : BaseHolder<EquipModelContent>
{
}