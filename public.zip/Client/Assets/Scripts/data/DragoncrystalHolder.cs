using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class DragoncrystalContent : BaseContent
{
	public int NameID;//
	public int NextID;//
	public List<int> UseType;//
	public int TriggerType;//
	public List<int> TriggerEffect;//����Ч��
	public List<int> CrystalAndEnchantEffect;//������Ч��ʩ����Ч
	public List<int> SkillLevel;//
	public int MaxLevel;//
	public string Icon;//
	public List<int> SkillEffectUP;//����Ч������
	public List<int> TriggerUp;//������������
	public List<int> BuilInCD;//����CD
	public int PassiveAttrID;//��������ID
	public List<int> PassivePercent;//�����ӳ������ٷֱ�
	public List<BaseIntContent> ActivateAttrID;//��������
	public int CurrentDesc;//��ǰ����
	public List<string> CurrentDescArg;//��ǰ��������
	public int LongJingDesc;//
	public List<BaseIntContent> UseItem;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NameID = element.intList[1];
		NextID = element.intList[2];
		UseType = element.intContentList[0].list;
		TriggerType = element.intList[3];
		TriggerEffect = element.intContentList[1].list;
		CrystalAndEnchantEffect = element.intContentList[2].list;
		SkillLevel = element.intContentList[3].list;
		MaxLevel = element.intList[4];
		Icon = element.stringList[0];
		SkillEffectUP = element.intContentList[4].list;
		TriggerUp = element.intContentList[5].list;
		BuilInCD = element.intContentList[6].list;
		PassiveAttrID = element.intList[5];
		PassivePercent = element.intContentList[7].list;
		ActivateAttrID = element.intContentListList[0].list;
		CurrentDesc = element.intList[6];
		CurrentDescArg = element.stringContentList[0].list;
		LongJingDesc = element.intList[7];
		UseItem = element.intContentListList[1].list;
    }

}

public class DragoncrystalHolder : BaseHolder<DragoncrystalContent>
{
}