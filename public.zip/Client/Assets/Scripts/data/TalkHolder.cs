using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TalkContent : BaseContent
{
	public int NpcID;//
	public int Remark;//
	public byte NameType;//
	public int TalkText;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NpcID = element.intList[1];
		Remark = element.intList[2];
		NameType = element.byteList[0];
		TalkText = element.intList[3];
    }

}

public class TalkHolder : BaseHolder<TalkContent>
{
}