using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class UISceneContent : BaseContent
{
	public string ScenePath;//
	public Color FogColor;//
	public byte FogMode;//
	public float FogDensity;//
	public float FogStart;//
	public float FogEnd;//
	public string LightmapPath;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ScenePath = element.stringList[0];
		FogColor = element.colorList[0];
		FogMode = element.byteList[0];
		FogDensity = element.floatList[0];
		FogStart = element.floatList[1];
		FogEnd = element.floatList[2];
		LightmapPath = element.stringList[1];
    }

}

public class UISceneHolder : BaseHolder<UISceneContent>
{
}