using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class LevelUpContent : BaseContent
{
	public int Exp;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Exp = element.intList[1];
    }

}

public class LevelUpHolder : BaseHolder<LevelUpContent>
{
}