using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class NameContent : BaseContent
{
	public int Name1;//
	public int Name2;//
	public int Name3;//
	public int Name4;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name1 = element.intList[1];
		Name2 = element.intList[2];
		Name3 = element.intList[3];
		Name4 = element.intList[4];
    }

}

public class NameHolder : BaseHolder<NameContent>
{
}