using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TriggerContent : BaseContent
{
	public List<byte> Conditions;//
	public List<BaseStringContent> ArgList;//
	public byte Relation;//
	public float Delay;//
	public int Num;//
	public float Interval;//
	public byte IntervalCondition;//
	public string IntervalArg;//
	public List<string> MonsterAreas;//
	public byte MonsterType;//
	public List<BaseIntContent> CreateMonsterList;//
	public List<BaseStringContent> BuffList;//
	public List<int> ScriptIDs;//
	public byte Wave;//
	public List<byte> ActiveDynamicType;//
	public List<string> DynamicNames;//
	public string PortalName;//
	public List<int> CameraList;//
	public int StoryID;//
	public List<string> MechanismParam;//
	public List<int> OtherTriggers;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Conditions = element.byteContentList[0].list;
		ArgList = element.stringContentListList[0].list;
		Relation = element.byteList[0];
		Delay = element.floatList[0];
		Num = element.intList[1];
		Interval = element.floatList[1];
		IntervalCondition = element.byteList[1];
		IntervalArg = element.stringList[0];
		MonsterAreas = element.stringContentList[0].list;
		MonsterType = element.byteList[2];
		CreateMonsterList = element.intContentListList[0].list;
		BuffList = element.stringContentListList[1].list;
		ScriptIDs = element.intContentList[0].list;
		Wave = element.byteList[3];
		ActiveDynamicType = element.byteContentList[1].list;
		DynamicNames = element.stringContentList[1].list;
		PortalName = element.stringList[1];
		CameraList = element.intContentList[1].list;
		StoryID = element.intList[2];
		MechanismParam = element.stringContentList[2].list;
		OtherTriggers = element.intContentList[2].list;
    }

}

public class TriggerHolder : BaseHolder<TriggerContent>
{
}