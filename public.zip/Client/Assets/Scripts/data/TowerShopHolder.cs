using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TowerShopContent : BaseContent
{
	public int ItemId;//
	public string Name;//
	public int Quality;//
	public int Num;//
	public List<BaseIntContent> Prices;//
	public List<int> Condition;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ItemId = element.intList[1];
		Name = element.stringList[0];
		Quality = element.intList[2];
		Num = element.intList[3];
		Prices = element.intContentListList[0].list;
		Condition = element.intContentList[0].list;
    }

}

public class TowerShopHolder : BaseHolder<TowerShopContent>
{
}