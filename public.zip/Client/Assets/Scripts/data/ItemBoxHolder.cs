using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ItemBoxContent : BaseContent
{
	public byte Quality;//
	public List<int> ItemArgs;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Quality = element.byteList[0];
		ItemArgs = element.intContentList[0].list;
    }

}

public class ItemBoxHolder : BaseHolder<ItemBoxContent>
{
}