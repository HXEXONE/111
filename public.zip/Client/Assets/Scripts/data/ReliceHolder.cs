using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ReliceContent : BaseContent
{
	public int ReliceName;//
	public List<BaseIntContent> Hole1Tech;//
	public List<BaseIntContent> Hole1Item;//
	public List<BaseIntContent> Hole2Tech;//
	public List<BaseIntContent> Hole2Item;//
	public List<BaseIntContent> Hole3Tech;//
	public List<BaseIntContent> Hole3Item;//
	public int AddTeach;//
	public int NormalEffect;//
	public int ActiveEffect;//
	public string Modle;//
	public string TexturePath;//
	public Vector3 FromPosition;//
	public Vector3 ToPosition;//
	public Vector3 InitRotation;//
	public int PveID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ReliceName = element.intList[1];
		Hole1Tech = element.intContentListList[0].list;
		Hole1Item = element.intContentListList[1].list;
		Hole2Tech = element.intContentListList[2].list;
		Hole2Item = element.intContentListList[3].list;
		Hole3Tech = element.intContentListList[4].list;
		Hole3Item = element.intContentListList[5].list;
		AddTeach = element.intList[2];
		NormalEffect = element.intList[3];
		ActiveEffect = element.intList[4];
		Modle = element.stringList[0];
		TexturePath = element.stringList[1];
		FromPosition = element.vector3List[0];
		ToPosition = element.vector3List[1];
		InitRotation = element.vector3List[2];
		PveID = element.intList[5];
    }

}

public class ReliceHolder : BaseHolder<ReliceContent>
{
}