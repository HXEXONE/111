using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class QuestContent : BaseContent
{
	public int Name;//
	public int desc;//
	public int QuestType;//
	public int TargetID;//
	public int TargetNpcID;//
	public int MoneyIDNum;//
	public int ExpNum;//
	public List<BaseIntContent> ItemList;//
	public int PlotID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name = element.intList[1];
		desc = element.intList[2];
		QuestType = element.intList[3];
		TargetID = element.intList[4];
		TargetNpcID = element.intList[5];
		MoneyIDNum = element.intList[6];
		ExpNum = element.intList[7];
		ItemList = element.intContentListList[0].list;
		PlotID = element.intList[8];
    }

}

public class QuestHolder : BaseHolder<QuestContent>
{
}