using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class UsualContent : BaseContent
{
	public List<int> OpenLevel;//
	public int Times;//
	public List<int> CostInfo;//
	public List<string> OpenTime;//
	public List<int> Mapid;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		OpenLevel = element.intContentList[0].list;
		Times = element.intList[1];
		CostInfo = element.intContentList[1].list;
		OpenTime = element.stringContentList[0].list;
		Mapid = element.intContentList[2].list;
    }

}

public class UsualHolder : BaseHolder<UsualContent>
{
}