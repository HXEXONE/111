using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class EquipContent : BaseContent
{
	public int Name;//
	public byte UseLevel;//
	public byte EquipType;//
	public byte JobLimit;//
	public byte Quality;//
	public byte QualityLevel;//
	public byte Level;//
	public int NextEquipID;//
	public int TextID;//
	public int RepeatCount;//
	public int MeltingExp;//
	public List<BaseIntContent> IntensifyUse;//
	public int LimitLevel;//
	public int ColletID;//
	public List<BaseIntContent> EnchantProprety;//
	public int ModelLoaderKey;//
	public int LendEnchantExp;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name = element.intList[1];
		UseLevel = element.byteList[0];
		EquipType = element.byteList[1];
		JobLimit = element.byteList[2];
		Quality = element.byteList[3];
		QualityLevel = element.byteList[4];
		Level = element.byteList[5];
		NextEquipID = element.intList[2];
		TextID = element.intList[3];
		RepeatCount = element.intList[4];
		MeltingExp = element.intList[5];
		IntensifyUse = element.intContentListList[0].list;
		LimitLevel = element.intList[6];
		ColletID = element.intList[7];
		EnchantProprety = element.intContentListList[1].list;
		ModelLoaderKey = element.intList[8];
		LendEnchantExp = element.intList[9];
    }
	private EquipModelContent m_modelLoader;
	public EquipModelContent ModelLoader
	{
		get{
			if(null == m_modelLoader) m_modelLoader = HolderManager.m_EquipModelHolder.GetStaticInfo(ModelLoaderKey);
			return m_modelLoader;
		}
	}

}

public class EquipHolder : BaseHolder<EquipContent>
{
}