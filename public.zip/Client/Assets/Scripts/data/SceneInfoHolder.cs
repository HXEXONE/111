using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SceneInfoContent : BaseContent
{
	public string IconPath;//
	public string Path;//
	public int MusicTypeID;//
	public int CameraID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		IconPath = element.stringList[0];
		Path = element.stringList[1];
		MusicTypeID = element.intList[1];
		CameraID = element.intList[2];
    }

}

public class SceneInfoHolder : BaseHolder<SceneInfoContent>
{
}