using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MaiDianContent : BaseContent
{
	public byte TriggerType;//
	public string TriggerArgs;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		TriggerType = element.byteList[0];
		TriggerArgs = element.stringList[0];
    }

}

public class MaiDianHolder : BaseHolder<MaiDianContent>
{
}