using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class HomeGuideContent : BaseContent
{
	public int StoryID;//
	public int OpenID;//
	public byte GuidTarget;//
	public byte Reset;//
	public string GuidTargetArgs;//
	public int GuidEffectID;//
	public Vector3 Position;//
	public Vector3 Scale;//
	public byte GuidFinishNode;//
	public int GuidNextId;//
	public byte ResetNode;//
	public int SaveToServer;//
	public int Condition;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		StoryID = element.intList[1];
		OpenID = element.intList[2];
		GuidTarget = element.byteList[0];
		Reset = element.byteList[1];
		GuidTargetArgs = element.stringList[0];
		GuidEffectID = element.intList[3];
		Position = element.vector3List[0];
		Scale = element.vector3List[1];
		GuidFinishNode = element.byteList[2];
		GuidNextId = element.intList[4];
		ResetNode = element.byteList[3];
		SaveToServer = element.intList[5];
		Condition = element.intList[6];
    }

}

public class HomeGuideHolder : BaseHolder<HomeGuideContent>
{
}