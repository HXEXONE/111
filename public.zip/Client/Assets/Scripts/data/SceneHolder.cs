using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SceneContent : BaseContent
{
	public string SceneName;//
	public string NameDesc;//
	public byte WinCondition;//
	public string WinArg;//
	public List<byte> LoseConditions;//
	public List<string> LoseArgs;//
	public byte SceneLevel;//
	public int CostValue;//
	public int FightBeginText;//
	public int FightEndText;//
	public List<BaseIntContent> AwardList;//
	public List<int> DropItemList;//
	public int ResurrectType;//
	public int ResurrectNum;//
	public List<BaseIntContent> MaxMonsterList;//
	public string TriggerFatherName;//
	public string GuideTrigger;//
	public string ConfigName;//
	public List<BaseIntContent> WeatherParameter;//
	public List<string> WeatherSound;//
	public int MapInfo;//
	public byte BackType;//
	public List<int> SceneBuff;//
	public byte TwoStarCondition;//
	public string TwoStarArg;//
	public byte ThreeStarCondition;//
	public string ThreeStarArg;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SceneName = element.stringList[0];
		NameDesc = element.stringList[1];
		WinCondition = element.byteList[0];
		WinArg = element.stringList[2];
		LoseConditions = element.byteContentList[0].list;
		LoseArgs = element.stringContentList[0].list;
		SceneLevel = element.byteList[1];
		CostValue = element.intList[1];
		FightBeginText = element.intList[2];
		FightEndText = element.intList[3];
		AwardList = element.intContentListList[0].list;
		DropItemList = element.intContentList[0].list;
		ResurrectType = element.intList[4];
		ResurrectNum = element.intList[5];
		MaxMonsterList = element.intContentListList[1].list;
		TriggerFatherName = element.stringList[3];
		GuideTrigger = element.stringList[4];
		ConfigName = element.stringList[5];
		WeatherParameter = element.intContentListList[2].list;
		WeatherSound = element.stringContentList[1].list;
		MapInfo = element.intList[6];
		BackType = element.byteList[2];
		SceneBuff = element.intContentList[1].list;
		TwoStarCondition = element.byteList[3];
		TwoStarArg = element.stringList[6];
		ThreeStarCondition = element.byteList[4];
		ThreeStarArg = element.stringList[7];
    }

}

public class SceneHolder : BaseHolder<SceneContent>
{
}