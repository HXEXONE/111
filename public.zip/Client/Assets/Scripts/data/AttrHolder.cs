using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AttrContent : BaseContent
{
	public byte Target;//
	public byte AttrType;//
	public List<int> HpList;//
	public List<int> MaxHpList;//
	public List<int> AttackList;//
	public List<int> DefenceList;//
	public List<int> HitRateList;//
	public List<int> HitRatePercentList;//
	public List<int> DodgeList;//
	public List<int> DodgePercentList;//
	public List<int> BingoList;//
	public List<int> BingoPercentList;//
	public List<int> DamageList;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Target = element.byteList[0];
		AttrType = element.byteList[1];
		HpList = element.intContentList[0].list;
		MaxHpList = element.intContentList[1].list;
		AttackList = element.intContentList[2].list;
		DefenceList = element.intContentList[3].list;
		HitRateList = element.intContentList[4].list;
		HitRatePercentList = element.intContentList[5].list;
		DodgeList = element.intContentList[6].list;
		DodgePercentList = element.intContentList[7].list;
		BingoList = element.intContentList[8].list;
		BingoPercentList = element.intContentList[9].list;
		DamageList = element.intContentList[10].list;
    }

}

public class AttrHolder : BaseHolder<AttrContent>
{
}