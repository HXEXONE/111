using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TipsContent : BaseContent
{
	public string Picpath;//
	public int Loadtips;//
	public byte LoadType;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Picpath = element.stringList[0];
		Loadtips = element.intList[1];
		LoadType = element.byteList[0];
    }

}

public class TipsHolder : BaseHolder<TipsContent>
{
}