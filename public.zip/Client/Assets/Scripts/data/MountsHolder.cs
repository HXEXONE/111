using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MountsContent : BaseContent
{
	public int MountsName;//
	public int MountsLevel;//
	public int MountsWish;//
	public string ClearTime;//
	public List<int> MountsItems;//
	public List<int> MountsItemsNum;//
	public List<int> UpgradeCondition;//
	public int MountsNextLevelId;//
	public int MountsPropertyID;//
	public int ModelLoaderKey;//
	public int MountsStar;//
	public List<string> M_EffectId;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		MountsName = element.intList[1];
		MountsLevel = element.intList[2];
		MountsWish = element.intList[3];
		ClearTime = element.stringList[0];
		MountsItems = element.intContentList[0].list;
		MountsItemsNum = element.intContentList[1].list;
		UpgradeCondition = element.intContentList[2].list;
		MountsNextLevelId = element.intList[4];
		MountsPropertyID = element.intList[5];
		ModelLoaderKey = element.intList[6];
		MountsStar = element.intList[7];
		M_EffectId = element.stringContentList[0].list;
    }
	private MountModelContent m_modelLoader;
	public MountModelContent ModelLoader
	{
		get{
			if(null == m_modelLoader) m_modelLoader = HolderManager.m_MountModelHolder.GetStaticInfo(ModelLoaderKey);
			return m_modelLoader;
		}
	}

}

public class MountsHolder : BaseHolder<MountsContent>
{
}