using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class BattlePVEContent : BaseContent
{
	public int NormalID;//
	public List<int> UnlockList;//
	public Vector3 AnchorDot;//
	public int Chapter;//
	public Vector3 DragCenter;//
	public Vector3 DragSize;//
	public int BattlePveName;//
	public int PveMapID;//
	public int PevLevelType;//
	public List<int> OpenCondition;//
	public List<int> OpenConditionFactor;//
	public float CameraHight;//
	public float CameraDistance;//
	public Vector3 CameraInitRotation;//
	public Vector3 CameraStayRotation;//
	public int LevelDecr;//
	public List<int> DropList;//
	public int GuideId;//
	public int recommendPartner;//
	public List<int> recommendBoy;//
	public List<int> recommendGirl;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NormalID = element.intList[1];
		UnlockList = element.intContentList[0].list;
		AnchorDot = element.vector3List[0];
		Chapter = element.intList[2];
		DragCenter = element.vector3List[1];
		DragSize = element.vector3List[2];
		BattlePveName = element.intList[3];
		PveMapID = element.intList[4];
		PevLevelType = element.intList[5];
		OpenCondition = element.intContentList[1].list;
		OpenConditionFactor = element.intContentList[2].list;
		CameraHight = element.floatList[0];
		CameraDistance = element.floatList[1];
		CameraInitRotation = element.vector3List[3];
		CameraStayRotation = element.vector3List[4];
		LevelDecr = element.intList[6];
		DropList = element.intContentList[3].list;
		GuideId = element.intList[7];
		recommendPartner = element.intList[8];
		recommendBoy = element.intContentList[4].list;
		recommendGirl = element.intContentList[5].list;
    }

}

public class BattlePVEHolder : BaseHolder<BattlePVEContent>
{
}