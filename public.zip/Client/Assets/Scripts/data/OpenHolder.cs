using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class OpenContent : BaseContent
{
	public int OpenName;//
	public byte OpenMode;//
	public byte OwnButton;//
	public byte Condition;//
	public int ConditionId;//
	public string Icon;//
	public int NpcID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		OpenName = element.intList[1];
		OpenMode = element.byteList[0];
		OwnButton = element.byteList[1];
		Condition = element.byteList[2];
		ConditionId = element.intList[2];
		Icon = element.stringList[0];
		NpcID = element.intList[3];
    }

}

public class OpenHolder : BaseHolder<OpenContent>
{
}