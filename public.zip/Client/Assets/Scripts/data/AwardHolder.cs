using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AwardContent : BaseContent
{
	public List<int> RankSection;//
	public List<BaseIntContent> AwardLsit;//
	public List<int> NpcPartnerInfo;//
	public int NpcMountID;//
	public int NpcPetID;//
	public List<BaseIntContent> TowerAwardLsit;//
	public List<BaseIntContent> SbossAward;//
	public List<BaseIntContent> SSbossAward;//
	public List<BaseIntContent> teamAllHurtAward;//
	public List<BaseIntContent> LeagueAward;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		RankSection = element.intContentList[0].list;
		AwardLsit = element.intContentListList[0].list;
		NpcPartnerInfo = element.intContentList[1].list;
		NpcMountID = element.intList[1];
		NpcPetID = element.intList[2];
		TowerAwardLsit = element.intContentListList[1].list;
		SbossAward = element.intContentListList[2].list;
		SSbossAward = element.intContentListList[3].list;
		teamAllHurtAward = element.intContentListList[4].list;
		LeagueAward = element.intContentListList[5].list;
    }

}

public class AwardHolder : BaseHolder<AwardContent>
{
}