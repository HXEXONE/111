using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class CameraContent : BaseContent
{
	public byte CameraType;//
	public List<string> ExtraArgToSingleList;//
	public float DelayTime;//
	public float LastTime;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		CameraType = element.byteList[0];
		ExtraArgToSingleList = element.stringContentList[0].list;
		DelayTime = element.floatList[0];
		LastTime = element.floatList[1];
    }

}

public class CameraHolder : BaseHolder<CameraContent>
{
}