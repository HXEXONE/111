using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TechContent : BaseContent
{
	public List<int> Livevaluemax;//
	public List<int> Jinlivaluemax;//
	public List<int> Attackvaluemax;//
	public List<int> Fangyuvalue;//
	public List<int> Mingzhongvalue;//
	public List<int> Mingzhonglvvalue;//
	public List<int> Shanbivalue;//
	public List<int> Shanbilvvalue;//
	public List<int> Baoji;//
	public List<int> Baojilv;//
	public List<int> Movespeed;//
	public List<int> Shengminghuifu;//
	public List<int> Jinlihuifu;//
	public List<int> Baojishanghai;//
	public List<int> Shanghaijianmian;//
	public List<int> Shanghaizengjia;//�˺�����
	public List<int> RepressCrit;//
	public List<int> RepressDamage;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Livevaluemax = element.intContentList[0].list;
		Jinlivaluemax = element.intContentList[1].list;
		Attackvaluemax = element.intContentList[2].list;
		Fangyuvalue = element.intContentList[3].list;
		Mingzhongvalue = element.intContentList[4].list;
		Mingzhonglvvalue = element.intContentList[5].list;
		Shanbivalue = element.intContentList[6].list;
		Shanbilvvalue = element.intContentList[7].list;
		Baoji = element.intContentList[8].list;
		Baojilv = element.intContentList[9].list;
		Movespeed = element.intContentList[10].list;
		Shengminghuifu = element.intContentList[11].list;
		Jinlihuifu = element.intContentList[12].list;
		Baojishanghai = element.intContentList[13].list;
		Shanghaijianmian = element.intContentList[14].list;
		Shanghaizengjia = element.intContentList[15].list;
		RepressCrit = element.intContentList[16].list;
		RepressDamage = element.intContentList[17].list;
    }

}

public class TechHolder : BaseHolder<TechContent>
{
}