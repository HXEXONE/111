using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ChannelContent : BaseContent
{
	public bool IsFormalVersion;//
	public byte SdkType;//
	public string ServerList;//
	public int RechargeType;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		IsFormalVersion = element.boolList[0];
		SdkType = element.byteList[0];
		ServerList = element.stringList[0];
		RechargeType = element.intList[1];
    }

}

public class ChannelHolder : BaseHolder<ChannelContent>
{
}