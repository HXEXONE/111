using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PlayerConfigContent : BaseContent
{
	public int Weapon;//
	public int Clothes;//
	public int AssaultID;//
	public List<int> ChargeList;//
	public int GrabID;//
	public int RollID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Weapon = element.intList[1];
		Clothes = element.intList[2];
		AssaultID = element.intList[3];
		ChargeList = element.intContentList[0].list;
		GrabID = element.intList[4];
		RollID = element.intList[5];
    }

}

public class PlayerConfigHolder : BaseHolder<PlayerConfigContent>
{
}