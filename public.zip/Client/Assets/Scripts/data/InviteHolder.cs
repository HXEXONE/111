using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class InviteContent : BaseContent
{
	public int InviteType;//
	public List<int> InviteAgrs;//
	public int InviteText;//
	public int NextInviteID;//
	public int DiamondReward;//
	public int GoldReward;//
	public List<BaseIntContent> ItemReward;//
	public int OpenType;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		InviteType = element.intList[1];
		InviteAgrs = element.intContentList[0].list;
		InviteText = element.intList[2];
		NextInviteID = element.intList[3];
		DiamondReward = element.intList[4];
		GoldReward = element.intList[5];
		ItemReward = element.intContentListList[0].list;
		OpenType = element.intList[6];
    }

}

public class InviteHolder : BaseHolder<InviteContent>
{
}