using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SkillUpContent : BaseContent
{
	public int SkillName;//
	public int NextLevel;//
	public byte Job;//
	public byte SkillType;//
	public int SkillId;//
	public List<byte> CurrentLv;//
	public int SkillMostLevel;//
	public List<int> NeedLevel;//
	public List<int> NeedResource;//
	public string SkillIcon;//
	public List<float> AttrPromotion;//
	public List<float> TimePromotion;//
	public List<float> EffectPromotion;//
	public int CurrentDes;//
	public List<BaseStringContent> CurrentDesArg;//
	public int Describe;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SkillName = element.intList[1];
		NextLevel = element.intList[2];
		Job = element.byteList[0];
		SkillType = element.byteList[1];
		SkillId = element.intList[3];
		CurrentLv = element.byteContentList[0].list;
		SkillMostLevel = element.intList[4];
		NeedLevel = element.intContentList[0].list;
		NeedResource = element.intContentList[1].list;
		SkillIcon = element.stringList[0];
		AttrPromotion = element.floatContentList[0].list;
		TimePromotion = element.floatContentList[1].list;
		EffectPromotion = element.floatContentList[2].list;
		CurrentDes = element.intList[5];
		CurrentDesArg = element.stringContentListList[0].list;
		Describe = element.intList[6];
    }

}

public class SkillUpHolder : BaseHolder<SkillUpContent>
{
}