using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ParticleContent : BaseContent
{
	public byte Sort;//
	public string Path;//
	public string BindPoint;//
	public float DelayTime;//
	public float LastTime;//
	public float OriginTime;//
	public float OffsetAngel;//
	public Vector3 Offset;//
	public Vector2 Scale;//
	public List<float> FlyOrbitList;//
	public List<float> FlySpeed;//
	public List<float> FlyArgs;//
	public byte TowardType;//
	public float ChaseRadius;//
	public int ExlposionID;//
	public bool AffectedByTimeScale;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Sort = element.byteList[0];
		Path = element.stringList[0];
		BindPoint = element.stringList[1];
		DelayTime = element.floatList[0];
		LastTime = element.floatList[1];
		OriginTime = element.floatList[2];
		OffsetAngel = element.floatList[3];
		Offset = element.vector3List[0];
		Scale = element.vector2List[0];
		FlyOrbitList = element.floatContentList[0].list;
		FlySpeed = element.floatContentList[1].list;
		FlyArgs = element.floatContentList[2].list;
		TowardType = element.byteList[1];
		ChaseRadius = element.floatList[4];
		ExlposionID = element.intList[1];
		AffectedByTimeScale = element.boolList[0];
    }

}

public class ParticleHolder : BaseHolder<ParticleContent>
{
}