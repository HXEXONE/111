using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AchieveContent : BaseContent
{
	public int AchieveType;//ID
	public List<int> AchieveFactor;//
	public int AchieveName;//
	public int AchieveText;//
	public int DiamondReward;//
	public int GoldReward;//
	public List<BaseStringContent> ItemAndFactor;//
	public int OpenId;//
	public int SortIndex;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		AchieveType = element.intList[1];
		AchieveFactor = element.intContentList[0].list;
		AchieveName = element.intList[2];
		AchieveText = element.intList[3];
		DiamondReward = element.intList[4];
		GoldReward = element.intList[5];
		ItemAndFactor = element.stringContentListList[0].list;
		OpenId = element.intList[6];
		SortIndex = element.intList[7];
    }

}

public class AchieveHolder : BaseHolder<AchieveContent>
{
}