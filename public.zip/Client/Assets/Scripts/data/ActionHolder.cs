using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ActionContent : BaseContent
{
	public string ActionName;//
	public byte BehitType;//
	public string BeatDownName;//
	public string BeatFlyName;//
	public List<float> BehitPointDelay;//
	public float Speed;//
	public List<int> SelfCameraIDs;//
	public List<string> Sounds;//
	public List<int> RandomEffects;//
	public List<int> FixedEffects;//
	public float AnkylosisTime;//
	public float HorDelayTime;//
	public float Displacement;//
	public float HorSpeed;//
	public List<string> ExtraArgs;//
	public List<string> WeaponAction;//
	public List<string> Rotation;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ActionName = element.stringList[0];
		BehitType = element.byteList[0];
		BeatDownName = element.stringList[1];
		BeatFlyName = element.stringList[2];
		BehitPointDelay = element.floatContentList[0].list;
		Speed = element.floatList[0];
		SelfCameraIDs = element.intContentList[0].list;
		Sounds = element.stringContentList[0].list;
		RandomEffects = element.intContentList[1].list;
		FixedEffects = element.intContentList[2].list;
		AnkylosisTime = element.floatList[1];
		HorDelayTime = element.floatList[2];
		Displacement = element.floatList[3];
		HorSpeed = element.floatList[4];
		ExtraArgs = element.stringContentList[1].list;
		WeaponAction = element.stringContentList[2].list;
		Rotation = element.stringContentList[3].list;
    }

}

public class ActionHolder : BaseHolder<ActionContent>
{
}