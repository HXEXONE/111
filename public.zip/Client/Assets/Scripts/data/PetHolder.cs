using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PetContent : BaseContent
{
	public int PetName;//
	public int PetLevel;//
	public int PetWish;//
	public int ClearTime;//
	public List<int> PetsItems;//
	public List<int> PetItemsNum;//
	public List<int> UpgradeCondition;//
	public int NextID;//
	public int PetTechId;//
	public int ModelLoaderKey;//
	public int PetStar;//
	public List<string> M_EffectId;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		PetName = element.intList[1];
		PetLevel = element.intList[2];
		PetWish = element.intList[3];
		ClearTime = element.intList[4];
		PetsItems = element.intContentList[0].list;
		PetItemsNum = element.intContentList[1].list;
		UpgradeCondition = element.intContentList[2].list;
		NextID = element.intList[5];
		PetTechId = element.intList[6];
		ModelLoaderKey = element.intList[7];
		PetStar = element.intList[8];
		M_EffectId = element.stringContentList[0].list;
    }
	private PetModelContent m_modelLoader;
	public PetModelContent ModelLoader
	{
		get{
			if(null == m_modelLoader) m_modelLoader = HolderManager.m_PetModelHolder.GetStaticInfo(ModelLoaderKey);
			return m_modelLoader;
		}
	}

}

public class PetHolder : BaseHolder<PetContent>
{
}