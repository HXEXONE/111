using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SkillEffectContent : BaseContent
{
	public byte EffectType;//
	public List<string> ExtraArgToSingleList;//
	public float DelayTime;//
	public float LastTime;//
	public string Path;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		EffectType = element.byteList[0];
		ExtraArgToSingleList = element.stringContentList[0].list;
		DelayTime = element.floatList[0];
		LastTime = element.floatList[1];
		Path = element.stringList[0];
    }

}

public class SkillEffectHolder : BaseHolder<SkillEffectContent>
{
}