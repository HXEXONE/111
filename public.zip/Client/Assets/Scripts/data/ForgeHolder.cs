using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ForgeContent : BaseContent
{
	public int SmeltLevel;//
	public int OpenLevel;//
	public int NeedExp;//
	public List<int> UpLevelUse;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SmeltLevel = element.intList[1];
		OpenLevel = element.intList[2];
		NeedExp = element.intList[3];
		UpLevelUse = element.intContentList[0].list;
    }

}

public class ForgeHolder : BaseHolder<ForgeContent>
{
}