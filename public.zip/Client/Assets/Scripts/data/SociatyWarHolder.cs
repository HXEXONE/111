using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SociatyWarContent : BaseContent
{
	public int Chapter;//
	public int Active;//
	public int PassRaward;//
	public List<int> FastItem;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Chapter = element.intList[1];
		Active = element.intList[2];
		PassRaward = element.intList[3];
		FastItem = element.intContentList[0].list;
    }

}

public class SociatyWarHolder : BaseHolder<SociatyWarContent>
{
}