using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MechanismContent : BaseContent
{
	public byte MechanismType;//
	public string Path;//
	public List<string> Args;//
	public List<int> Script;//
	public int TriggerCount;//
	public float SpaceTime;//
	public string NavMeshLayerName;//
	public bool MoveCamera;//
	public Vector3 CameraOffSet;//
	public float AnimationSpeed;//
	public int NextMechanismID;//
	public float ParkTime;//
	public bool CompletedHide;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		MechanismType = element.byteList[0];
		Path = element.stringList[0];
		Args = element.stringContentList[0].list;
		Script = element.intContentList[0].list;
		TriggerCount = element.intList[1];
		SpaceTime = element.floatList[0];
		NavMeshLayerName = element.stringList[1];
		MoveCamera = element.boolList[0];
		CameraOffSet = element.vector3List[0];
		AnimationSpeed = element.floatList[1];
		NextMechanismID = element.intList[2];
		ParkTime = element.floatList[2];
		CompletedHide = element.boolList[1];
    }

}

public class MechanismHolder : BaseHolder<MechanismContent>
{
}