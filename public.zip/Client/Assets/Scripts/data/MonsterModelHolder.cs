using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MonsterModelContent : BaseContent
{
	public byte UnitsType;//
	public List<float> AniMoveSpeed;//
	public bool MoveBehaviour;//
	public string Path;//
	public string TextureName;//
	public int PartsPathID;//
	public int ExploderProbaility;//
	public int ExploderEffectID;//
	public List<BaseIntContent> ExploderType;//
	public int BirthActID;//
	public int UnBirthActID;//
	public int DeadActID;//
	public List<int> BehitSoundID;//
	public bool BehitBlood;//
	public string AniPath;//
	public Vector3 PoltCameraPos;//
	public Vector3 PoltAvatarRation;//
	public Vector3 WorldBossCamera;//
	public int ShowText;//
	public bool HasProvoke;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		UnitsType = element.byteList[0];
		AniMoveSpeed = element.floatContentList[0].list;
		MoveBehaviour = element.boolList[0];
		Path = element.stringList[0];
		TextureName = element.stringList[1];
		PartsPathID = element.intList[1];
		ExploderProbaility = element.intList[2];
		ExploderEffectID = element.intList[3];
		ExploderType = element.intContentListList[0].list;
		BirthActID = element.intList[4];
		UnBirthActID = element.intList[5];
		DeadActID = element.intList[6];
		BehitSoundID = element.intContentList[0].list;
		BehitBlood = element.boolList[1];
		AniPath = element.stringList[2];
		PoltCameraPos = element.vector3List[0];
		PoltAvatarRation = element.vector3List[1];
		WorldBossCamera = element.vector3List[2];
		ShowText = element.intList[7];
		HasProvoke = element.boolList[2];
    }

}

public class MonsterModelHolder : BaseHolder<MonsterModelContent>
{
}