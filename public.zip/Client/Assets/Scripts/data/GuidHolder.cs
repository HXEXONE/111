using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class GuidContent : BaseContent
{
	public byte GuidKind;//
	public byte GuidOperationType;//
	public byte GuidTarget;//
	public string GuidTargetArgs;//
	public Vector3 Position;//
	public Vector3 Rotation;//
	public byte GuidNeedCameraEffect;//
	public int GuidEffectID;//
	public int GuidePixiemodelres;//
	public int OpenFunEffect;//
	public int GuidTipText;//
	public Vector3 GuidTipTextPos;//
	public int Sound;//
	public int nextNode;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		GuidKind = element.byteList[0];
		GuidOperationType = element.byteList[1];
		GuidTarget = element.byteList[2];
		GuidTargetArgs = element.stringList[0];
		Position = element.vector3List[0];
		Rotation = element.vector3List[1];
		GuidNeedCameraEffect = element.byteList[3];
		GuidEffectID = element.intList[1];
		GuidePixiemodelres = element.intList[2];
		OpenFunEffect = element.intList[3];
		GuidTipText = element.intList[4];
		GuidTipTextPos = element.vector3List[2];
		Sound = element.intList[5];
		nextNode = element.intList[6];
    }

}

public class GuidHolder : BaseHolder<GuidContent>
{
}