using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PetSkillContent : BaseContent
{
	public int PetSkillIndex;//
	public int PetSkillReq;//
	public float PetSkillPro;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		PetSkillIndex = element.intList[1];
		PetSkillReq = element.intList[2];
		PetSkillPro = element.floatList[0];
    }

}

public class PetSkillHolder : BaseHolder<PetSkillContent>
{
}