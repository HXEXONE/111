using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SceneStoryNpcContent : BaseContent
{
	public int Job1;//
	public int Job2;//
	public int Job3;//
	public int Job4;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Job1 = element.intList[1];
		Job2 = element.intList[2];
		Job3 = element.intList[3];
		Job4 = element.intList[4];
    }

}

public class SceneStoryNpcHolder : BaseHolder<SceneStoryNpcContent>
{
}