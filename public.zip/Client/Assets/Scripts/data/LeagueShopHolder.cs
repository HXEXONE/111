using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class LeagueShopContent : BaseContent
{
	public int ShopType;//
	public int ItemID;//
	public int ItemName;//
	public int ItemQuality;//
	public int ItemCount;//
	public int ItemLevel;//
	public List<int> BuyPrice;//
	public int UpdateAgrs;//
	public int LevelLimit;//
	public List<int> OpenArgs;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ShopType = element.intList[1];
		ItemID = element.intList[2];
		ItemName = element.intList[3];
		ItemQuality = element.intList[4];
		ItemCount = element.intList[5];
		ItemLevel = element.intList[6];
		BuyPrice = element.intContentList[0].list;
		UpdateAgrs = element.intList[7];
		LevelLimit = element.intList[8];
		OpenArgs = element.intContentList[1].list;
    }

}

public class LeagueShopHolder : BaseHolder<LeagueShopContent>
{
}