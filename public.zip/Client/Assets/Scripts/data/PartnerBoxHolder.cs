using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PartnerBoxContent : BaseContent
{
	public int Partnerid;//
	public List<int> ItemArgs;//
	public List<int> Factor;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Partnerid = element.intList[1];
		ItemArgs = element.intContentList[0].list;
		Factor = element.intContentList[1].list;
    }

}

public class PartnerBoxHolder : BaseHolder<PartnerBoxContent>
{
}