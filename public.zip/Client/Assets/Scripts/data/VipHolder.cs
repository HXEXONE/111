using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class VipContent : BaseContent
{
	public int VipLevel;//
	public int RechargeValue;//
	public int RechargeAlchermyTime;//
	public int RechargeBuyEnergy;//
	public int RechargeEscortTime;//
	public int RechargeEndWildTime;//
	public int RechargeFreeWipeVoluemNum;//
	public int RechargeWipeTenTime;//
	public int RechargeReElietTime;//
	public int RechargeRestorSkillPoint;//
	public int RechargeChallengeArenaTime;//
	public int RechargeAwardOfArena;//
	public int RechargeMiningTreasureNum;//
	public int RechargeWorshipTime;//
	public int RechargeDispatchPartnerNum;//
	public List<int> GiftBagList;//
	public int GaojiQx;//
	public string BagIcon;//
	public int GoldWorship;//
	public int DiamondWorship;//
	public int TheFirstTrialWipeOut;//
	public int AutoAdvance;//
	public int RechargeAwardOfSociaty;//
	public int RefreshTimesOfDragonDiamond;//
	public int WildSaoDang;//
	public int MiJingSaoDang;//
	public int RechargeHigherLevel;//
	public int AshesCanBuyTimes;//
	public int UnLockMiZangFun;//
	public int UnLockFaShi;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		VipLevel = element.intList[1];
		RechargeValue = element.intList[2];
		RechargeAlchermyTime = element.intList[3];
		RechargeBuyEnergy = element.intList[4];
		RechargeEscortTime = element.intList[5];
		RechargeEndWildTime = element.intList[6];
		RechargeFreeWipeVoluemNum = element.intList[7];
		RechargeWipeTenTime = element.intList[8];
		RechargeReElietTime = element.intList[9];
		RechargeRestorSkillPoint = element.intList[10];
		RechargeChallengeArenaTime = element.intList[11];
		RechargeAwardOfArena = element.intList[12];
		RechargeMiningTreasureNum = element.intList[13];
		RechargeWorshipTime = element.intList[14];
		RechargeDispatchPartnerNum = element.intList[15];
		GiftBagList = element.intContentList[0].list;
		GaojiQx = element.intList[16];
		BagIcon = element.stringList[0];
		GoldWorship = element.intList[17];
		DiamondWorship = element.intList[18];
		TheFirstTrialWipeOut = element.intList[19];
		AutoAdvance = element.intList[20];
		RechargeAwardOfSociaty = element.intList[21];
		RefreshTimesOfDragonDiamond = element.intList[22];
		WildSaoDang = element.intList[23];
		MiJingSaoDang = element.intList[24];
		RechargeHigherLevel = element.intList[25];
		AshesCanBuyTimes = element.intList[26];
		UnLockMiZangFun = element.intList[27];
		UnLockFaShi = element.intList[28];
    }

}

public class VipHolder : BaseHolder<VipContent>
{
}