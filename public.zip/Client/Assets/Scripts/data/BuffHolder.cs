using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class BuffContent : BaseContent
{
	public float LastTime;//
	public float Period;//
	public int SpliceNum;//
	public int AttrID;//
	public int SkillID;//
	public float ChangeSpeed;//
	public float DamageAbsorb;//
	public float DamageMakeHP;//
	public float DamageReflex;//
	public float LifeStealblood;//
	public bool IsStun;//
	public bool IsInvincibility;//
	public bool IsOverlord;//
	public bool IsHide;//
	public bool IsFrost;//
	public int SizeChange;//
	public float ChangeAtkSpeed;//
	public List<float> MagicShield;//
	public List<int> LastEffect;//
	public List<int> IntervalEffect;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		LastTime = element.floatList[0];
		Period = element.floatList[1];
		SpliceNum = element.intList[1];
		AttrID = element.intList[2];
		SkillID = element.intList[3];
		ChangeSpeed = element.floatList[2];
		DamageAbsorb = element.floatList[3];
		DamageMakeHP = element.floatList[4];
		DamageReflex = element.floatList[5];
		LifeStealblood = element.floatList[6];
		IsStun = element.boolList[0];
		IsInvincibility = element.boolList[1];
		IsOverlord = element.boolList[2];
		IsHide = element.boolList[3];
		IsFrost = element.boolList[4];
		SizeChange = element.intList[4];
		ChangeAtkSpeed = element.floatList[7];
		MagicShield = element.floatContentList[0].list;
		LastEffect = element.intContentList[0].list;
		IntervalEffect = element.intContentList[1].list;
    }

}

public class BuffHolder : BaseHolder<BuffContent>
{
}