using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ItemContent : BaseContent
{
	public int Name;//
	public byte Level;//
	public byte Sort;//
	public byte Quality;//
	public int MaxPileNum;//
	public bool IsCanUse;//
	public List<int> UseConsume;//
	public int ScriptID;//
	public List<BaseIntContent> ScriptArg;//
	public int ColletID;//
	public string m_icon;//
	public List<string> m_path;//
	public int DescribeID;//
	public List<int> DropLevel1;//
	public int DropLevel2;//
	public int DropLevel3;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name = element.intList[1];
		Level = element.byteList[0];
		Sort = element.byteList[1];
		Quality = element.byteList[2];
		MaxPileNum = element.intList[2];
		IsCanUse = element.boolList[0];
		UseConsume = element.intContentList[0].list;
		ScriptID = element.intList[3];
		ScriptArg = element.intContentListList[0].list;
		ColletID = element.intList[4];
		m_icon = element.stringList[0];
		m_path = element.stringContentList[0].list;
		DescribeID = element.intList[5];
		DropLevel1 = element.intContentList[1].list;
		DropLevel2 = element.intList[6];
		DropLevel3 = element.intList[7];
    }

}

public class ItemHolder : BaseHolder<ItemContent>
{
}