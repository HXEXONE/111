using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ScriptContent : BaseContent
{
	public int ScriptType;//
	public byte Sign1;//
	public int Value1;//
	public byte Relation;//
	public byte Sign2;//
	public int Value2;//
	public int TrueAction;//
	public string TrueValue;//
	public int FalseAction;//
	public string FalseValue;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ScriptType = element.intList[1];
		Sign1 = element.byteList[0];
		Value1 = element.intList[2];
		Relation = element.byteList[1];
		Sign2 = element.byteList[2];
		Value2 = element.intList[3];
		TrueAction = element.intList[4];
		TrueValue = element.stringList[0];
		FalseAction = element.intList[5];
		FalseValue = element.stringList[1];
    }

}

public class ScriptHolder : BaseHolder<ScriptContent>
{
}