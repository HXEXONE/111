using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class LeagueContent : BaseContent
{
	public int Level;//
	public int MinCup;//
	public int MaxCup;//
	public List<BaseIntContent> LeagueReward;//
	public int VictoryArgs;//
	public int FailArgs;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Level = element.intList[1];
		MinCup = element.intList[2];
		MaxCup = element.intList[3];
		LeagueReward = element.intContentListList[0].list;
		VictoryArgs = element.intList[4];
		FailArgs = element.intList[5];
    }

}

public class LeagueHolder : BaseHolder<LeagueContent>
{
}