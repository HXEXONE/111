using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AssetsMapContent : BaseContent
{
	public string PackName;//
	public List<int> ClothMaxIDs;//
	public List<int> WeaponMaxIDs;//
	public int MountMaxID;//
	public int PetMaxID;//
	public List<BaseIntContent> PartnerList;//
	public List<int> PartnerReplaceList;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		PackName = element.stringList[0];
		ClothMaxIDs = element.intContentList[0].list;
		WeaponMaxIDs = element.intContentList[1].list;
		MountMaxID = element.intList[1];
		PetMaxID = element.intList[2];
		PartnerList = element.intContentListList[0].list;
		PartnerReplaceList = element.intContentList[2].list;
    }

}

public class AssetsMapHolder : BaseHolder<AssetsMapContent>
{
}