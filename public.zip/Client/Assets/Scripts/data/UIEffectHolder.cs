using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class UIEffectContent : BaseContent
{
	public string EffectPath;//
	public float Time;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		EffectPath = element.stringList[0];
		Time = element.floatList[0];
    }

}

public class UIEffectHolder : BaseHolder<UIEffectContent>
{
}