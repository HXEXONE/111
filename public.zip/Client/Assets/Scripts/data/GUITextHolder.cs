using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class GUITextContent : BaseContent
{
	public string SimpleChinese;//
	public string TraditionalChinese;//
	public string English;//
	public string YinDu;//
	public string YueNan;//
	public string TaiGuo;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SimpleChinese = element.stringList[0];
		TraditionalChinese = element.stringList[1];
		English = element.stringList[2];
		YinDu = element.stringList[3];
		YueNan = element.stringList[4];
		TaiGuo = element.stringList[5];
    }

}

public class GUITextHolder : BaseHolder<GUITextContent>
{
}