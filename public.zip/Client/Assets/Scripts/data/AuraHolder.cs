using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AuraContent : BaseContent
{
	public float AuraRange;//
	public float Duration;//
	public byte AffectType;//
	public List<int> LockList;//
	public byte AffectEffect;//
	public int BuffID;//
	public int SponsorParticleID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		AuraRange = element.floatList[0];
		Duration = element.floatList[1];
		AffectType = element.byteList[0];
		LockList = element.intContentList[0].list;
		AffectEffect = element.byteList[1];
		BuffID = element.intList[1];
		SponsorParticleID = element.intList[2];
    }

}

public class AuraHolder : BaseHolder<AuraContent>
{
}