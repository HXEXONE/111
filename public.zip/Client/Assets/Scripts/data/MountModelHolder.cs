using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MountModelContent : BaseContent
{
	public int MountsQualityIndex;//
	public List<int> MountsSkill;//
	public float MountsFightTime;//
	public List<int> BuffList;//
	public List<float> MountsShowSpeed;//
	public float MountsMoveSpeed;//
	public float MountsMoveSpeedMax;//
	public string MountsModelPath;//
	public float ModleScale;//
	public List<BaseIntContent> CameraEffects;//
	public int FollowCameraID;//
	public List<float> PetPosition;//
	public int SoundID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		MountsQualityIndex = element.intList[1];
		MountsSkill = element.intContentList[0].list;
		MountsFightTime = element.floatList[0];
		BuffList = element.intContentList[1].list;
		MountsShowSpeed = element.floatContentList[0].list;
		MountsMoveSpeed = element.floatList[1];
		MountsMoveSpeedMax = element.floatList[2];
		MountsModelPath = element.stringList[0];
		ModleScale = element.floatList[3];
		CameraEffects = element.intContentListList[0].list;
		FollowCameraID = element.intList[2];
		PetPosition = element.floatContentList[1].list;
		SoundID = element.intList[3];
    }

}

public class MountModelHolder : BaseHolder<MountModelContent>
{
}