using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PlayerContent : BaseContent
{
	public int NpcName;//
	public byte Sort;//
	public List<float> Hp;//
	public List<float> Attack;//
	public List<float> Defence;//
	public List<float> HitRate;//
	public List<float> Dodge;//
	public List<float> Bingo;//
	public float Rigidity;//
	public List<float> m_AniMoveSpeed;//
	public float m_moveSpeed;//
	public float m_MaxMoveSpeed;//
	public bool IsHitDown;//
	public bool IsBeatFly;//
	public bool IsStun;//
	public bool IsSlow;//
	public int NormalSkill;//
	public int RideNormalSkill;//
	public string Icon;//
	public string AmimatorPath;//
	public int m_DeadActID;//
	public int SkillSoundID;//
	public List<int> BehitSoundID;//
	public int Describe;//
	public int MountWeapon;//
	public int FlyWeapon;//
	public List<int> PoseSound;//
	public float BodyHeight;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NpcName = element.intList[1];
		Sort = element.byteList[0];
		Hp = element.floatContentList[0].list;
		Attack = element.floatContentList[1].list;
		Defence = element.floatContentList[2].list;
		HitRate = element.floatContentList[3].list;
		Dodge = element.floatContentList[4].list;
		Bingo = element.floatContentList[5].list;
		Rigidity = element.floatList[0];
		m_AniMoveSpeed = element.floatContentList[6].list;
		m_moveSpeed = element.floatList[1];
		m_MaxMoveSpeed = element.floatList[2];
		IsHitDown = element.boolList[0];
		IsBeatFly = element.boolList[1];
		IsStun = element.boolList[2];
		IsSlow = element.boolList[3];
		NormalSkill = element.intList[2];
		RideNormalSkill = element.intList[3];
		Icon = element.stringList[0];
		AmimatorPath = element.stringList[1];
		m_DeadActID = element.intList[4];
		SkillSoundID = element.intList[5];
		BehitSoundID = element.intContentList[0].list;
		Describe = element.intList[6];
		MountWeapon = element.intList[7];
		FlyWeapon = element.intList[8];
		PoseSound = element.intContentList[1].list;
		BodyHeight = element.floatList[3];
    }

}

public class PlayerHolder : BaseHolder<PlayerContent>
{
}