using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SociatyIconContent : BaseContent
{
	public string Icon;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Icon = element.stringList[0];
    }

}

public class SociatyIconHolder : BaseHolder<SociatyIconContent>
{
}