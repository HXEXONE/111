using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class HomeNPCContent : BaseContent
{
	public int Name;//
	public float Size;//
	public string UiName;//
	public Vector3 Position;//
	public Vector3 Direction;//
	public string ResPath;//
	public Vector3 NpcCameraPos;//
	public Vector3 NpcSystemOpenCameraPos;//
	public int Open;//
	public int Desc;//
	public List<string> Icon;//
	public List<int> Sounds;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name = element.intList[1];
		Size = element.floatList[0];
		UiName = element.stringList[0];
		Position = element.vector3List[0];
		Direction = element.vector3List[1];
		ResPath = element.stringList[1];
		NpcCameraPos = element.vector3List[2];
		NpcSystemOpenCameraPos = element.vector3List[3];
		Open = element.intList[2];
		Desc = element.intList[3];
		Icon = element.stringContentList[0].list;
		Sounds = element.intContentList[0].list;
    }

}

public class HomeNPCHolder : BaseHolder<HomeNPCContent>
{
}