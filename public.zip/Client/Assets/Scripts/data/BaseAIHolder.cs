using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class BaseAIContent : BaseContent
{
	public float GuideRadius;//
	public bool IsCanMove;//
	public byte Behavior;//
	public bool IscanTurn;//
	public bool IsFollowWayPoint;//
	public bool IsAutoUseSkill;//
	public bool IsAutoBeatBack;//
	public string DefaultTargetTag;//
	public float SkillInterval;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		GuideRadius = element.floatList[0];
		IsCanMove = element.boolList[0];
		Behavior = element.byteList[0];
		IscanTurn = element.boolList[1];
		IsFollowWayPoint = element.boolList[2];
		IsAutoUseSkill = element.boolList[3];
		IsAutoBeatBack = element.boolList[4];
		DefaultTargetTag = element.stringList[0];
		SkillInterval = element.floatList[1];
    }

}

public class BaseAIHolder : BaseHolder<BaseAIContent>
{
}