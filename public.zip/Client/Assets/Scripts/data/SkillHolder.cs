using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SkillContent : BaseContent
{
	public int SkillName;//
	public byte SkillType;//
	public List<int> NextSkill;//
	public int FirstSkillID;//
	public byte MultiSkillType;//
	public byte MouseAction;//
	public bool CanBlink;//
	public byte SkillRange;//
	public List<float> RangeArgs;//
	public List<float> JudgeArgs;//
	public byte SkillAtkType;//
	public byte AffectType;//
	public List<int> LockList;//
	public byte AffectEffect;//
	public byte Priority;//
	public float CD;//
	public bool IsInitCD;//
	public float Interval;//
	public float LastTime;//
	public byte CostType;//
	public int CostValue;//
	public int AttrID;//
	public bool IgnoreCollider;//
	public List<int> TargetScripts;//
	public List<int> SelfScripts;//
	public string Icon;//
	public int AttackID;//
	public int DefenceID;//
	public int DullKnifeProbability;//
	public List<string> ExtraArgs;//
	public string Describe;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SkillName = element.intList[1];
		SkillType = element.byteList[0];
		NextSkill = element.intContentList[0].list;
		FirstSkillID = element.intList[2];
		MultiSkillType = element.byteList[1];
		MouseAction = element.byteList[2];
		CanBlink = element.boolList[0];
		SkillRange = element.byteList[3];
		RangeArgs = element.floatContentList[0].list;
		JudgeArgs = element.floatContentList[1].list;
		SkillAtkType = element.byteList[4];
		AffectType = element.byteList[5];
		LockList = element.intContentList[1].list;
		AffectEffect = element.byteList[6];
		Priority = element.byteList[7];
		CD = element.floatList[0];
		IsInitCD = element.boolList[1];
		Interval = element.floatList[1];
		LastTime = element.floatList[2];
		CostType = element.byteList[8];
		CostValue = element.intList[3];
		AttrID = element.intList[4];
		IgnoreCollider = element.boolList[2];
		TargetScripts = element.intContentList[2].list;
		SelfScripts = element.intContentList[3].list;
		Icon = element.stringList[0];
		AttackID = element.intList[5];
		DefenceID = element.intList[6];
		DullKnifeProbability = element.intList[7];
		ExtraArgs = element.stringContentList[0].list;
		Describe = element.stringList[1];
    }

}

public class SkillHolder : BaseHolder<SkillContent>
{
}