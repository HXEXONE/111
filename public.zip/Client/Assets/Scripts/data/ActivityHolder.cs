using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ActivityContent : BaseContent
{
	public List<BaseIntContent> ItemReward;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ItemReward = element.intContentListList[0].list;
    }

}

public class ActivityHolder : BaseHolder<ActivityContent>
{
}