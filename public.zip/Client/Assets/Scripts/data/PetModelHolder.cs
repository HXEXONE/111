using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PetModelContent : BaseContent
{
	public int PetQualityIndex;//
	public List<int> PetSkills;//
	public int NormalFlySkill;//
	public float PetFollowRadius;//
	public float PetFlyHeight;//
	public List<int> PetHomeWords;//
	public string Path;//
	public int FightTime;//
	public List<int> BuffList;//
	public List<float> AniMoveSpeed;//
	public float MoveSpeed;//
	public float MaxMoveSpeed;//
	public float ModleScale;//
	public float BattleScale;//
	public List<float> PetPosition;//
	public int SoundID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		PetQualityIndex = element.intList[1];
		PetSkills = element.intContentList[0].list;
		NormalFlySkill = element.intList[2];
		PetFollowRadius = element.floatList[0];
		PetFlyHeight = element.floatList[1];
		PetHomeWords = element.intContentList[1].list;
		Path = element.stringList[0];
		FightTime = element.intList[3];
		BuffList = element.intContentList[2].list;
		AniMoveSpeed = element.floatContentList[0].list;
		MoveSpeed = element.floatList[2];
		MaxMoveSpeed = element.floatList[3];
		ModleScale = element.floatList[4];
		BattleScale = element.floatList[5];
		PetPosition = element.floatContentList[1].list;
		SoundID = element.intList[4];
    }

}

public class PetModelHolder : BaseHolder<PetModelContent>
{
}