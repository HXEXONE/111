using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class BossInfoContent : BaseContent
{
	public int BossName;//
	public int BossHp;//
	public string BossLevel;//
	public int BossClass;//
	public int MonsterId;//
	public int MapId;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		BossName = element.intList[1];
		BossHp = element.intList[2];
		BossLevel = element.stringList[0];
		BossClass = element.intList[3];
		MonsterId = element.intList[4];
		MapId = element.intList[5];
    }

}

public class BossInfoHolder : BaseHolder<BossInfoContent>
{
}