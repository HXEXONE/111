using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class AudioContent : BaseContent
{
	public byte SoundType;//
	public float DelayTime;//
	public int LoopCount;//
	public float Interval;//
	public int Random;//
	public string Path;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		SoundType = element.byteList[0];
		DelayTime = element.floatList[0];
		LoopCount = element.intList[1];
		Interval = element.floatList[1];
		Random = element.intList[2];
		Path = element.stringList[0];
    }

}

public class AudioHolder : BaseHolder<AudioContent>
{
}