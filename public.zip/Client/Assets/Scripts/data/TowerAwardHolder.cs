using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TowerAwardContent : BaseContent
{
	public List<int> FinishAward;//
	public List<int> FisrtWinAward;//
	public int MonsterBuff;//
	public int TeamBuff;//
	public int MonsterLevel;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		FinishAward = element.intContentList[0].list;
		FisrtWinAward = element.intContentList[1].list;
		MonsterBuff = element.intList[1];
		TeamBuff = element.intList[2];
		MonsterLevel = element.intList[3];
    }

}

public class TowerAwardHolder : BaseHolder<TowerAwardContent>
{
}