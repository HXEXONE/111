using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TowerMonsterContent : BaseContent
{
	public int MonsterType;//
	public int MonsterId;//
	public int AICount;//
	public List<int> SkillList;//
	public List<int> AIList;//
	public int PackType;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		MonsterType = element.intList[1];
		MonsterId = element.intList[2];
		AICount = element.intList[3];
		SkillList = element.intContentList[0].list;
		AIList = element.intContentList[1].list;
		PackType = element.intList[4];
    }

}

public class TowerMonsterHolder : BaseHolder<TowerMonsterContent>
{
}