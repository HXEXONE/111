using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PartenrContent : BaseContent
{
	public int Name;//
	public int NameDesc;//
	public int JobIndex;//
	public int Star;//
	public List<BaseIntContent> StarneedItems;//
	public int Quality;//
	public List<BaseIntContent> QualityneedItems;//
	public int NextID;//
	public int Kind;//
	public List<int> Attack;//
	public List<int> Defense;//
	public List<int> Hp;//
	public List<int> Skilllist;//
	public int AddPropertyID;//
	public int IllustrationsID;//
	public int GroupIndex;//
	public List<int> TestSkillList;//
	public List<BaseIntContent> CallUse;//
	public int ModelLoaderKey;//
	public int LongJingID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Name = element.intList[1];
		NameDesc = element.intList[2];
		JobIndex = element.intList[3];
		Star = element.intList[4];
		StarneedItems = element.intContentListList[0].list;
		Quality = element.intList[5];
		QualityneedItems = element.intContentListList[1].list;
		NextID = element.intList[6];
		Kind = element.intList[7];
		Attack = element.intContentList[0].list;
		Defense = element.intContentList[1].list;
		Hp = element.intContentList[2].list;
		Skilllist = element.intContentList[3].list;
		AddPropertyID = element.intList[8];
		IllustrationsID = element.intList[9];
		GroupIndex = element.intList[10];
		TestSkillList = element.intContentList[4].list;
		CallUse = element.intContentListList[2].list;
		ModelLoaderKey = element.intList[11];
		LongJingID = element.intList[12];
    }
	private PartnerModelContent m_modelLoader;
	public PartnerModelContent ModelLoader
	{
		get{
			if(null == m_modelLoader) m_modelLoader = HolderManager.m_PartnerModelHolder.GetStaticInfo(ModelLoaderKey);
			return m_modelLoader;
		}
	}

}

public class PartenrHolder : BaseHolder<PartenrContent>
{
}