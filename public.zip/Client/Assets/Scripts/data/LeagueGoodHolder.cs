using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class LeagueGoodContent : BaseContent
{
	public int Type;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Type = element.intList[1];
    }

}

public class LeagueGoodHolder : BaseHolder<LeagueGoodContent>
{
}