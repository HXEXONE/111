using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class DropItemContent : BaseContent
{
	public byte DropType;//
	public List<string> DropList1;//
	public List<string> DropList2;//
	public List<string> DropList3;//
	public List<string> DropList4;//
	public List<string> DropList5;//
	public List<string> DropList6;//
	public List<string> DropList7;//
	public List<string> DropList8;//
	public List<string> DropList9;//
	public List<string> DropList10;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		DropType = element.byteList[0];
		DropList1 = element.stringContentList[0].list;
		DropList2 = element.stringContentList[1].list;
		DropList3 = element.stringContentList[2].list;
		DropList4 = element.stringContentList[3].list;
		DropList5 = element.stringContentList[4].list;
		DropList6 = element.stringContentList[5].list;
		DropList7 = element.stringContentList[6].list;
		DropList8 = element.stringContentList[7].list;
		DropList9 = element.stringContentList[8].list;
		DropList10 = element.stringContentList[9].list;
    }

}

public class DropItemHolder : BaseHolder<DropItemContent>
{
}