using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ShopContent : BaseContent
{
	public int ItemId;//
	public int ChannelType;//
	public int Num;//
	public int Kind;//
	public int AdditionalNum;//
	public int ConsumeId;//
	public int Price;//
	public string SpriteName;//
	public string OverseasID;//
	public string iosID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		ItemId = element.intList[1];
		ChannelType = element.intList[2];
		Num = element.intList[3];
		Kind = element.intList[4];
		AdditionalNum = element.intList[5];
		ConsumeId = element.intList[6];
		Price = element.intList[7];
		SpriteName = element.stringList[0];
		OverseasID = element.stringList[1];
		iosID = element.stringList[2];
    }

}

public class ShopHolder : BaseHolder<ShopContent>
{
}