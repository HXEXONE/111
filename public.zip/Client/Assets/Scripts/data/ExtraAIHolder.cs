using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class ExtraAIContent : BaseContent
{
	public byte Condition;//
	public string Arg;//
	public byte EventType;//
	public string EventArg;//
	public bool IsRepeat;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Condition = element.byteList[0];
		Arg = element.stringList[0];
		EventType = element.byteList[1];
		EventArg = element.stringList[1];
		IsRepeat = element.boolList[0];
    }

}

public class ExtraAIHolder : BaseHolder<ExtraAIContent>
{
}