using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class TargetContent : BaseContent
{
	public int DescID;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		DescID = element.intList[1];
    }

}

public class TargetHolder : BaseHolder<TargetContent>
{
}