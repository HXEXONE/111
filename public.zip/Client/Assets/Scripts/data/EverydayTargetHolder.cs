using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class EverydayTargetContent : BaseContent
{
	public int TargetType;//
	public int TargetFactor;//
	public int TargetName;//
	public int TargetText;//
	public int IosTargetName;//
	public int IosTargetText;//
	public int FormulaIndex;//
	public int RewardDiamond;//
	public int RewardGold;//
	public int RewardExp;//
	public List<BaseStringContent> ItemAndFactor;//
	public int GotoType;//
	public int OpenId;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		TargetType = element.intList[1];
		TargetFactor = element.intList[2];
		TargetName = element.intList[3];
		TargetText = element.intList[4];
		IosTargetName = element.intList[5];
		IosTargetText = element.intList[6];
		FormulaIndex = element.intList[7];
		RewardDiamond = element.intList[8];
		RewardGold = element.intList[9];
		RewardExp = element.intList[10];
		ItemAndFactor = element.stringContentListList[0].list;
		GotoType = element.intList[11];
		OpenId = element.intList[12];
    }

}

public class EverydayTargetHolder : BaseHolder<EverydayTargetContent>
{
}