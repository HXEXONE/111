using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SceneStoryContent : BaseContent
{
	public byte StoryType;//
	public List<string> ExtraArgToSingleList;//
	public bool EndStory;//
	public Vector3 PointDirect;//
	public float DelayTime;//
	public float LastTime;//
	public string PathSource;//
	public List<int> NextStoryEffect;//
	public List<int> Triggers;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		StoryType = element.byteList[0];
		ExtraArgToSingleList = element.stringContentList[0].list;
		EndStory = element.boolList[0];
		PointDirect = element.vector3List[0];
		DelayTime = element.floatList[0];
		LastTime = element.floatList[1];
		PathSource = element.stringList[0];
		NextStoryEffect = element.intContentList[0].list;
		Triggers = element.intContentList[1].list;
    }

}

public class SceneStoryHolder : BaseHolder<SceneStoryContent>
{
}