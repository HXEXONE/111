using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class NoticeContent : BaseContent
{
	public string Title;//
	public string Notice;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Title = element.stringList[0];
		Notice = element.stringList[1];
    }

}

public class NoticeHolder : BaseHolder<NoticeContent>
{
}