using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class MonsterContent : BaseContent
{
	public int NpcName;//
	public int Level;//
	public byte NpcGroup;//
	public byte Sort;//
	public List<int> ActiveList;//
	public float ChangeSize;//
	public List<float> Hp;//
	public List<float> Attack;//
	public List<float> Defence;//
	public List<float> HitRate;//
	public List<float> Dodge;//
	public List<float> Bingo;//
	public float Rigidity;//
	public List<float> WalkMoveSpeed;//
	public bool IsHitDown;//
	public bool m_bKill;//
	public bool IsBeatFly;//
	public bool IsStun;//
	public bool IsSlow;//
	public bool CanBeGrab;//
	public int BaseAI;//
	public List<int> AIex;//
	public List<int> Skilllist;//
	public List<int> BattleDropList;//
	public List<int> DieDropList1;//
	public int WeaponID;//
	public int Clothes;//
	public Color ShaderColor;//
	public int ModelLoaderKey;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NpcName = element.intList[1];
		Level = element.intList[2];
		NpcGroup = element.byteList[0];
		Sort = element.byteList[1];
		ActiveList = element.intContentList[0].list;
		ChangeSize = element.floatList[0];
		Hp = element.floatContentList[0].list;
		Attack = element.floatContentList[1].list;
		Defence = element.floatContentList[2].list;
		HitRate = element.floatContentList[3].list;
		Dodge = element.floatContentList[4].list;
		Bingo = element.floatContentList[5].list;
		Rigidity = element.floatList[1];
		WalkMoveSpeed = element.floatContentList[6].list;
		IsHitDown = element.boolList[0];
		m_bKill = element.boolList[1];
		IsBeatFly = element.boolList[2];
		IsStun = element.boolList[3];
		IsSlow = element.boolList[4];
		CanBeGrab = element.boolList[5];
		BaseAI = element.intList[3];
		AIex = element.intContentList[1].list;
		Skilllist = element.intContentList[2].list;
		BattleDropList = element.intContentList[3].list;
		DieDropList1 = element.intContentList[4].list;
		WeaponID = element.intList[4];
		Clothes = element.intList[5];
		ShaderColor = element.colorList[0];
		ModelLoaderKey = element.intList[6];
    }
	private MonsterModelContent m_modelLoader;
	public MonsterModelContent ModelLoader
	{
		get{
			if(null == m_modelLoader) m_modelLoader = HolderManager.m_MonsterModelHolder.GetStaticInfo(ModelLoaderKey);
			return m_modelLoader;
		}
	}

}

public class MonsterHolder : BaseHolder<MonsterContent>
{
}