using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class PartnerModelContent : BaseContent
{
	public int NormalAtkID;//
	public int RollSkill;//
	public int SwitchCD;//
	public int HpRegenRate;//
	public int Desc;//
	public string ModelRes;//
	public int WeaponID;//
	public string Icon;//
	public int DeadActionID;//
	public int SkillSoundID;//
	public int BehitSoundID;//
	public int GroupName;//
	public byte PlayerSex;//
	public int PartnerDesc;//
	public Vector3 PartnerPos;//
	public Vector3 PartnerRotation;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		NormalAtkID = element.intList[1];
		RollSkill = element.intList[2];
		SwitchCD = element.intList[3];
		HpRegenRate = element.intList[4];
		Desc = element.intList[5];
		ModelRes = element.stringList[0];
		WeaponID = element.intList[6];
		Icon = element.stringList[1];
		DeadActionID = element.intList[7];
		SkillSoundID = element.intList[8];
		BehitSoundID = element.intList[9];
		GroupName = element.intList[10];
		PlayerSex = element.byteList[0];
		PartnerDesc = element.intList[11];
		PartnerPos = element.vector3List[0];
		PartnerRotation = element.vector3List[1];
    }

}

public class PartnerModelHolder : BaseHolder<PartnerModelContent>
{
}