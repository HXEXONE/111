using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class DirtywordContent : BaseContent
{
	public List<string> Content;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Content = element.stringContentList[0].list;
    }

}

public class DirtywordHolder : BaseHolder<DirtywordContent>
{
}