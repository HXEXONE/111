using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class SignContent : BaseContent
{
	public int Acheveid;//
	public int Beizhu;//
	public int Achevenum;//
	public int Premiums;//
	public int PremiumsNum;//
	public int VipLevel;//
	public List<int> EventId;//
	public int DisplayInt;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Acheveid = element.intList[1];
		Beizhu = element.intList[2];
		Achevenum = element.intList[3];
		Premiums = element.intList[4];
		PremiumsNum = element.intList[5];
		VipLevel = element.intList[6];
		EventId = element.intContentList[0].list;
		DisplayInt = element.intList[7];
    }

}

public class SignHolder : BaseHolder<SignContent>
{
}