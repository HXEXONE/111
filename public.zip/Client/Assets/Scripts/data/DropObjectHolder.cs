using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[System.Serializable]
public class DropObjectContent : BaseContent
{
	public float Radius;//
	public byte AdsorbMode;//
	public int DeadScript;//

    public override void Init(FileStreamElement element)
    {
        base.Init(element);
		Radius = element.floatList[0];
		AdsorbMode = element.byteList[0];
		DeadScript = element.intList[1];
    }

}

public class DropObjectHolder : BaseHolder<DropObjectContent>
{
}