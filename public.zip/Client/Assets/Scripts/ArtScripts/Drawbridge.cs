﻿using UnityEngine;
using System.Collections;

public class Drawbridge : MonoBehaviour {

    private float m_delayTime;
    public float DelayTime
    {
        get { return m_delayTime; }
    }

    private int DRAWBRIDGE_LAYER = 5;

    private bool m_enable = false;
    public bool Enable
    {
        get { return m_enable; }
    }

	void Start () {
        AnimationState animState = null;
        if(animation == null)
        {
            m_enable = false;
            this.enabled = false;
            return;
        }
        foreach (AnimationState state in animation)
        {
            animState = state;
            break;
        }
        if (animState == null)
        {
            m_enable = false;
            this.enabled = false;
            return;
        }
        m_delayTime = animState.length;
	}

    public void SetNavMeshAgent(GameObject o,bool active)
    {
        NavMeshAgent[] nmas = o.GetComponentsInChildren<NavMeshAgent>();
        for (int j = 0, len2 = nmas.Length; j < len2; ++j)
        {
            if (active)
                nmas[j].walkableMask |= (1 << DRAWBRIDGE_LAYER);
            else
                nmas[j].walkableMask &= ~(1 << DRAWBRIDGE_LAYER);
        }
    }
}
