﻿using UnityEngine;
using System.Collections;

public class AnimationClipContain : MonoBehaviour {

    [SerializeField]
    private AnimationClip m_clip;

    public AnimationClip Clip
    {
        get { return m_clip; }
    }

    [SerializeField]
    private Material m_material;

    public Material Material
    {
        get { return m_material; }
    }
}
