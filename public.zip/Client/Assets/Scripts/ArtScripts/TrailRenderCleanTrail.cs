﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(TrailRenderer))]
public class TrailRenderCleanTrail : MonoBehaviour 
{
    TrailRenderer _trail;
    float startTime;
    bool _start;
    float _startWidth;
    float _endWidth;

    void Awake()
    {
        _trail = GetComponent<TrailRenderer>();
    }

    void OnEnable()
    {
        startTime = Time.time;
        _startWidth = _trail.startWidth;
        _trail.startWidth = 0;

        _endWidth = _trail.endWidth;
        _trail.endWidth = 0;
        _start = true;
    }

    void OnDisable()
    {
        _trail.startWidth = _startWidth;
        _trail.endWidth = _endWidth;
    }

    void Update()
    {
        if (_start && Time.time - startTime >= _trail.time)
        {
            _start = false;
            _trail.startWidth = _startWidth;
            _trail.endWidth = _endWidth;
        }
    }

}
