﻿using UnityEngine;
using System.Collections;
using UnityEditor;

[CustomEditor(typeof(UIBaseDrawCall), true)]

public class UIParticlesInspector : Editor
{

    private UIBaseDrawCall _uiBaseDrawCall;

    void OnEnable()
    {
        _uiBaseDrawCall = target as UIBaseDrawCall;
    }


    public override void OnInspectorGUI()
    {
        NGUIEditorTools.SetLabelWidth(80f);
        EditorGUILayout.Space();

        serializedObject.Update();

        EditorGUI.BeginDisabledGroup(false);
        DrawDepth();
        EditorGUI.EndDisabledGroup();

        serializedObject.ApplyModifiedProperties();
    }

    void DrawDepth()
    {
        PrefabType type = PrefabUtility.GetPrefabType(_uiBaseDrawCall.gameObject);
        if (type == PrefabType.Prefab) return;

        GUILayout.Space(2f);
        GUILayout.BeginHorizontal();
        {
            EditorGUILayout.PrefixLabel("Depth");

            if (GUILayout.Button("Back", GUILayout.MinWidth(46f)))
            {
                foreach (GameObject go in Selection.gameObjects)
                {
                    UIBaseDrawCall uip = go.GetComponent<UIBaseDrawCall>();
                    if (uip != null) uip.Depth = uip.Depth - 1;
                }
            }

            NGUIEditorTools.DrawProperty("", serializedObject, "mDepth", GUILayout.MinWidth(20f));

            if (GUILayout.Button("Forward", GUILayout.MinWidth(60f)))
            {
                foreach (GameObject go in Selection.gameObjects)
                {
                    UIBaseDrawCall uip = go.GetComponent<UIBaseDrawCall>();
                    if (uip != null) uip.Depth = uip.Depth + 1;
                }
            }
        }
        GUILayout.EndHorizontal();
    }
}
