﻿using UnityEngine;
using System.Collections;
using UnityEditor;


public class RemoveAtlasAndFont {

    [MenuItem("NGUI/RemoveAtlas&Font")]
    public static void Ext()
    {
        foreach (GameObject go in Selection.GetFiltered(typeof(GameObject), SelectionMode.DeepAssets))
        {
            UISprite[] sprites = go.GetComponentsInChildren<UISprite>(true);
            foreach (UISprite spri in sprites)
            {
                spri.atlas = null;
            }

            UILabel[] lable = go.GetComponentsInChildren<UILabel>(true);
            foreach (UILabel l in lable)
            {
                l.font = null;
                l.bitmapFont = null;
                l.ambigiousFont = null;
                l.text = "";

            }
        }
    }

    [MenuItem("NGUI/LabelDepthFront")]
    public static void ExecuteLableDepth()
    {
        foreach (GameObject go in Selection.GetFiltered(typeof(GameObject), SelectionMode.DeepAssets))
        {
            UILabel[] lable = go.GetComponentsInChildren<UILabel>(true);
            UIWidget[] uiwidget = go.GetComponentsInChildren<UIWidget>(true);
            int maxDepth = 0;
            foreach (UILabel l in lable)
            {
                l.depth = maxDepth;
            }
            foreach (UIWidget w in uiwidget)
            {
                if (w.depth > maxDepth)
                {
                    maxDepth = w.depth;
                }
            }
            foreach (UILabel l in lable)
            {
                l.depth = (maxDepth+1);
            }
       }
    }
}
